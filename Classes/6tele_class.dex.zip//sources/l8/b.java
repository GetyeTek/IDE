package l8;

import A8.c;
import P2.a;
import java.util.HashMap;

public final class b extends c {
    public final void b(String str, String str2) {
        HashMap a = com.google.android.gms.measurement.internal.c.a("amount", str, "entrance", "50");
        a.put("notes", str2);
        a(H3.c.e().e(a), new a(this, (a) this.a, str));
    }
}
