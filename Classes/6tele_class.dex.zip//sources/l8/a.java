package l8;

import L2.b;
import com.huawei.digitalpayment.customer.httplib.response.GetQrCodeResp;
import java.util.List;

public final class a extends b<GetQrCodeResp> {
    public final /* synthetic */ String f;
    public final /* synthetic */ b g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(b bVar, P2.a aVar, String str) {
        super(aVar, true);
        this.g = bVar;
        this.f = str;
    }

    public final void b(String str) {
        ((P2.a) this.g.a).d(this.f, (List<GetQrCodeResp.QrCode>) null);
    }

    public final void c(Object obj) {
        ((P2.a) this.g.a).d(this.f, ((GetQrCodeResp) obj).getQrCodes());
    }
}
