package Q7;

public interface c {
}
