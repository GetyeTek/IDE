package Q7;

import android.net.Uri;

public interface a {
    void a(Uri uri, int i, int i2, int i3, int i4);

    void b(Throwable th);
}
