package Q7;

public interface b {
}
