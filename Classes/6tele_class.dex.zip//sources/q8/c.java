package q8;

public final class c extends A8.c {
}
