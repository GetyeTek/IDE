package q8;

import L2.b;
import com.huawei.digitalpayment.customer.httplib.response.ScanQrResp;

public final class a extends b<ScanQrResp> {
    public final /* synthetic */ c f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(c cVar, P2.a aVar) {
        super(aVar, true);
        this.f = cVar;
    }

    public final void b(String str) {
        ((P2.a) this.f.a).l(str);
    }

    public final void c(Object obj) {
        ((P2.a) this.f.a).w((ScanQrResp) obj);
    }
}
