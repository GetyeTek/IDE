package q8;

import P2.a;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;

public final class b extends L2.b<VerifyNumberResp> {
    public final /* synthetic */ c f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public b(c cVar, a aVar) {
        super(aVar, false);
        this.f = cVar;
    }

    public final void b(String str) {
        ((a) this.f.a).b((VerifyNumberResp) null);
    }

    public final void c(Object obj) {
        ((a) this.f.a).b((VerifyNumberResp) obj);
    }
}
