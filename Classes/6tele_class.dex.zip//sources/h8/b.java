package h8;

import S1.d;
import S1.e;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.camera.core.impl.utils.futures.g;
import com.blankj.utilcode.util.A;
import f8.a;
import java.util.HashMap;
import java.util.Iterator;

public final class b implements e {
    public final /* synthetic */ int compareTo(Object obj) {
        return d.a(this, (e) obj);
    }

    public final int d() {
        return 999;
    }

    public final void f(Context context, String str) {
        Uri data;
        HashMap hashMap = a.C0002a.a.a;
        if (hashMap != null) {
            Iterator it = hashMap.keySet().iterator();
            if (it.hasNext()) {
                String str2 = (String) it.next();
                Intent intent = (Intent) hashMap.get(str2);
                if (intent != null && (data = intent.getData()) != null) {
                    A.h(new g(data, 3), 500);
                    hashMap.remove(str2);
                }
            }
        }
    }

    public final void onLogout() {
        HashMap hashMap = a.C0002a.a.a;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public final void e() {
    }
}
