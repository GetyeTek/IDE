package h8;

import S1.e;
import com.huawei.payment.base.App;

public final class a extends S1.a {
    public final Object a() {
        return null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [S1.e, java.lang.Object] */
    public final e c() {
        return new Object();
    }

    public final void d(App app) {
    }
}
