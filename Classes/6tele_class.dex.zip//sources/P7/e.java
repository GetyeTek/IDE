package P7;

import Q7.a;
import android.content.Intent;
import android.net.Uri;
import androidx.annotation.NonNull;
import com.huawei.payment.lib.image.crop.CropActivity;

public final class e implements a {
    public final /* synthetic */ CropActivity a;

    public e(CropActivity cropActivity) {
        this.a = cropActivity;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, com.huawei.payment.lib.image.crop.CropActivity, android.app.Activity] */
    public final void a(@NonNull Uri uri, int i, int i2, int i3, int i4) {
        ? r0 = this.a;
        float targetAspectRatio = r0.n.getTargetAspectRatio();
        r0.getClass();
        r0.setResult(-1, new Intent().putExtra("com.huawei.payment.lib.image.OutputUri", uri).putExtra("com.huawei.payment.lib.image.CropAspectRatio", targetAspectRatio).putExtra("com.huawei.payment.lib.image.ImageWidth", i3).putExtra("com.huawei.payment.lib.image.ImageHeight", i4).putExtra("com.huawei.payment.lib.image.OffsetX", i).putExtra("com.huawei.payment.lib.image.OffsetY", i2));
        r0.finish();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.payment.lib.image.crop.CropActivity, android.app.Activity] */
    public final void b(@NonNull Throwable th) {
        ? r0 = this.a;
        r0.D0(th);
        r0.finish();
    }
}
