package P7;

import com.huawei.payment.lib.image.crop.CropFragment;
import com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView;

public final class j implements HorizontalProgressView.a {
    public final /* synthetic */ CropFragment a;

    public j(CropFragment cropFragment) {
        this.a = cropFragment;
    }

    public final void a() {
        this.a.k.setImageToWrapCropBound(true);
    }

    public final void b(float f) {
        this.a.k.h(f / 42.0f);
    }

    public final void c() {
        this.a.k.e();
    }
}
