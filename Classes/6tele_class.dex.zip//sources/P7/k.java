package P7;

import android.graphics.RectF;
import com.huawei.payment.lib.image.crop.CropFragment;
import com.huawei.payment.lib.image.crop.view.GestureCropImageView;
import com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView;

public final class k implements HorizontalProgressView.a {
    public final /* synthetic */ CropFragment a;

    public k(CropFragment cropFragment) {
        this.a = cropFragment;
    }

    public final void a() {
        this.a.k.setImageToWrapCropBound(true);
    }

    public final void b(float f) {
        CropFragment cropFragment = this.a;
        if (f > 0.0f) {
            GestureCropImageView gestureCropImageView = cropFragment.k;
            float currentScale = gestureCropImageView.getCurrentScale();
            RectF rectF = gestureCropImageView.r;
            gestureCropImageView.j((((cropFragment.k.getMaxScale() - cropFragment.k.getMinScale()) / 15000.0f) * f) + currentScale, rectF.centerX(), rectF.centerY());
            return;
        }
        GestureCropImageView gestureCropImageView2 = cropFragment.k;
        float maxScale = (((cropFragment.k.getMaxScale() - cropFragment.k.getMinScale()) / 15000.0f) * f) + gestureCropImageView2.getCurrentScale();
        RectF rectF2 = gestureCropImageView2.r;
        float centerX = rectF2.centerX();
        float centerY = rectF2.centerY();
        if (maxScale >= gestureCropImageView2.getMinScale()) {
            gestureCropImageView2.i(maxScale / gestureCropImageView2.getCurrentScale(), centerX, centerY);
        }
    }

    public final void c() {
        this.a.k.e();
    }
}
