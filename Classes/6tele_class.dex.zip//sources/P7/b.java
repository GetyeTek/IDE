package P7;

import android.view.View;
import android.view.ViewGroup;
import com.huawei.payment.lib.image.crop.CropActivity;
import com.huawei.payment.lib.image.crop.view.widget.AspectTextView;
import java.util.Iterator;

public final class b implements View.OnClickListener {
    public final /* synthetic */ CropActivity a;

    public b(CropActivity cropActivity) {
        this.a = cropActivity;
    }

    public final void onClick(View view) {
        boolean z;
        CropActivity cropActivity = this.a;
        cropActivity.n.setTargetAspectRatio(((AspectTextView) ((ViewGroup) view).getChildAt(0)).b(view.isSelected()));
        cropActivity.n.setImageToWrapCropBound(true);
        if (!view.isSelected()) {
            Iterator it = cropActivity.a.iterator();
            while (it.hasNext()) {
                ViewGroup viewGroup = (ViewGroup) it.next();
                if (viewGroup == view) {
                    z = true;
                } else {
                    z = false;
                }
                viewGroup.setSelected(z);
            }
        }
    }
}
