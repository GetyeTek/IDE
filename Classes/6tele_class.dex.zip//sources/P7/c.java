package P7;

import com.huawei.payment.lib.image.crop.CropActivity;
import com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView;

public final class c implements HorizontalProgressView.a {
    public final /* synthetic */ CropActivity a;

    public c(CropActivity cropActivity) {
        this.a = cropActivity;
    }

    public final void a() {
        this.a.n.setImageToWrapCropBound(true);
    }

    public final void b(float f) {
        this.a.n.h(f / 42.0f);
    }

    public final void c() {
        this.a.n.e();
    }
}
