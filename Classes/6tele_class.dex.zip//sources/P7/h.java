package P7;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import com.huawei.payment.lib.image.crop.CropFragment;
import com.huawei.payment.lib.image.crop.b;

public final class h implements Toolbar.OnMenuItemClickListener {
    public final /* synthetic */ CropFragment a;

    public h(CropFragment cropFragment) {
        this.a = cropFragment;
    }

    public final boolean onMenuItemClick(MenuItem menuItem) {
        CropFragment cropFragment = this.a;
        if (!cropFragment.isAdded()) {
            return false;
        }
        cropFragment.u.setClickable(true);
        cropFragment.b.a();
        cropFragment.k.f(cropFragment.w, cropFragment.x, new b(cropFragment));
        return false;
    }
}
