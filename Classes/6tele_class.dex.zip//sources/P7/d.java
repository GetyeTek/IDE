package P7;

import android.graphics.RectF;
import com.huawei.payment.lib.image.crop.CropActivity;
import com.huawei.payment.lib.image.crop.view.GestureCropImageView;
import com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView;

public final class d implements HorizontalProgressView.a {
    public final /* synthetic */ CropActivity a;

    public d(CropActivity cropActivity) {
        this.a = cropActivity;
    }

    public final void a() {
        this.a.n.setImageToWrapCropBound(true);
    }

    public final void b(float f) {
        CropActivity cropActivity = this.a;
        if (f > 0.0f) {
            GestureCropImageView gestureCropImageView = cropActivity.n;
            float currentScale = gestureCropImageView.getCurrentScale();
            RectF rectF = gestureCropImageView.r;
            gestureCropImageView.j((((cropActivity.n.getMaxScale() - cropActivity.n.getMinScale()) / 15000.0f) * f) + currentScale, rectF.centerX(), rectF.centerY());
            return;
        }
        GestureCropImageView gestureCropImageView2 = cropActivity.n;
        float maxScale = (((cropActivity.n.getMaxScale() - cropActivity.n.getMinScale()) / 15000.0f) * f) + gestureCropImageView2.getCurrentScale();
        RectF rectF2 = gestureCropImageView2.r;
        float centerX = rectF2.centerX();
        float centerY = rectF2.centerY();
        if (maxScale >= gestureCropImageView2.getMinScale()) {
            gestureCropImageView2.i(maxScale / gestureCropImageView2.getCurrentScale(), centerX, centerY);
        }
    }

    public final void c() {
        this.a.n.e();
    }
}
