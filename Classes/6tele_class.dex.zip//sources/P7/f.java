package P7;

import L9.a;
import android.view.View;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.LiveData;
import ca.e;
import ca.q0;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.customer.login_module.resetpin.ResetPinOtpActivity;
import com.huawei.kbz.chat.chat_room.CameraFragment;
import com.huawei.kbz.chat.contact.ChatGenderSetActivity;
import com.huawei.kbz.chat.contact.SearchNumberActivity;
import com.huawei.kbz.dialog.recyclerdialog.BaseRecyclerDialog;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import com.huawei.payment.lib.image.crop.CropFragment;
import com.huawei.payment.lib.image.crop.view.GestureCropImageView;
import l7.d;
import m7.b;

public final /* synthetic */ class f implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ f(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                CropFragment cropFragment = (CropFragment) obj;
                GestureCropImageView gestureCropImageView = cropFragment.k;
                gestureCropImageView.h(-gestureCropImageView.getCurrentAngle());
                cropFragment.k.setImageToWrapCropBound(true);
                return;
            case 1:
                CameraFragment cameraFragment = (CameraFragment) obj;
                cameraFragment.g = !cameraFragment.g;
                e.b(LifecycleOwnerKt.getLifecycleScope(cameraFragment), (q0) null, new com.huawei.kbz.chat.chat_room.f(cameraFragment, (a) null), 3);
                return;
            case 2:
                ChatGenderSetActivity chatGenderSetActivity = (ChatGenderSetActivity) obj;
                chatGenderSetActivity.b.e.setVisibility(0);
                chatGenderSetActivity.b.b.setVisibility(8);
                chatGenderSetActivity.d = "1";
                chatGenderSetActivity.E0();
                return;
            case 3:
                ((SearchNumberActivity) obj).b.c.setText("");
                return;
            case 4:
                int i = ResetPinOtpActivity.m;
                ResetPinOtpActivity resetPinOtpActivity = (ResetPinOtpActivity) obj;
                resetPinOtpActivity.getClass();
                if (!W2.a.a(1500, view)) {
                    w5.a.a("Reset_Pin_OTP1_confirm_V1");
                    resetPinOtpActivity.j.e.b();
                    resetPinOtpActivity.i.c(resetPinOtpActivity.j.c.getText().toString());
                    return;
                }
                return;
            default:
                BaseRecyclerDialog baseRecyclerDialog = (BaseRecyclerDialog) obj;
                d dVar = baseRecyclerDialog.f;
                if (dVar != null) {
                    CouponBean couponBean = baseRecyclerDialog.h;
                    CheckStandFragment checkStandFragment = dVar.a;
                    checkStandFragment.f = true;
                    checkStandFragment.i = couponBean;
                    CheckStandViewModel checkStandViewModel = checkStandFragment.a;
                    LiveData f = checkStandViewModel.f(couponBean);
                    if (f != null) {
                        checkStandViewModel.b(f, new b(checkStandViewModel, couponBean));
                    }
                }
                baseRecyclerDialog.dismiss();
                return;
        }
    }
}
