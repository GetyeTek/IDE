package P7;

import V1.k;
import W2.h;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.huawei.bank.databinding.ActivityTransferToBankBinding;
import com.huawei.bank.model.TransferBankAccount;
import com.huawei.bank.transfer.activity.TransferToBankActivity;
import com.huawei.bank.transfer.viewmodel.TransferToBankViewModel;
import com.huawei.digitalpayment.customer.login_module.login.NewDeviceVerifyOtpActivity;
import com.huawei.digitalpayment.customer.login_module.login.q;
import com.huawei.kbz.chat.contact.AddContactActivity;
import com.huawei.kbz.chat.contact.SearchMobileContactActivity;
import com.huawei.kbz.chat.groupChat.BanGroupContactActivity;
import com.huawei.module_cash.CashInputPinActivity;
import com.huawei.payment.lib.image.crop.CropActivity;
import com.huawei.payment.lib.image.crop.view.GestureCropImageView;
import com.huawei.requestmoney.AddBlackOrFavorActivity;
import com.huawei.requestmoney.R;
import com.huawei.requestmoney.databinding.ActivityAddBlackOrFavorBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import java.util.HashMap;
import java.util.Map;
import o0.b;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ AppCompatActivity b;

    public /* synthetic */ a(AppCompatActivity appCompatActivity, int i) {
        this.a = i;
        this.b = appCompatActivity;
    }

    public final void onClick(View view) {
        AddBlackOrFavorActivity addBlackOrFavorActivity = this.b;
        switch (this.a) {
            case 0:
                CropActivity cropActivity = (CropActivity) addBlackOrFavorActivity;
                GestureCropImageView gestureCropImageView = cropActivity.n;
                gestureCropImageView.h(-gestureCropImageView.getCurrentAngle());
                cropActivity.n.setImageToWrapCropBound(true);
                return;
            case 1:
                int i = BanGroupContactActivity.k;
                ((BanGroupContactActivity) addBlackOrFavorActivity).finish();
                return;
            case 2:
                int i2 = TransferToBankActivity.l;
                TransferToBankActivity transferToBankActivity = (TransferToBankActivity) addBlackOrFavorActivity;
                TransferBankAccount transferBankAccount = (TransferBankAccount) ((TransferToBankViewModel) transferToBankActivity.c).d.getValue();
                transferBankAccount.setBankAccountNo(((ActivityTransferToBankBinding) transferToBankActivity.b).c.getText());
                transferToBankActivity.E0(transferBankAccount);
                return;
            case 3:
                int i3 = NewDeviceVerifyOtpActivity.n;
                ((NewDeviceVerifyOtpActivity) addBlackOrFavorActivity).V0();
                return;
            case 4:
                int i4 = AddContactActivity.d;
                AddContactActivity addContactActivity = (AddContactActivity) addBlackOrFavorActivity;
                addContactActivity.getClass();
                Bundle bundle = new Bundle();
                bundle.putString("scanPurpose", "Scan");
                b.d(addContactActivity, "/customer/scan_and_pay", bundle, (Map) null);
                return;
            case 5:
                int i5 = SearchMobileContactActivity.d;
                SearchMobileContactActivity searchMobileContactActivity = (SearchMobileContactActivity) addBlackOrFavorActivity;
                searchMobileContactActivity.getClass();
                Y2.a.d(searchMobileContactActivity, new q(searchMobileContactActivity, 1));
                return;
            case 6:
                int i6 = CashInputPinActivity.d;
                ((CashInputPinActivity) addBlackOrFavorActivity).finish();
                return;
            default:
                int i7 = AddBlackOrFavorActivity.e;
                AddBlackOrFavorActivity addBlackOrFavorActivity2 = addBlackOrFavorActivity;
                if (((ActivityAddBlackOrFavorBinding) addBlackOrFavorActivity2.b).e.isChecked()) {
                    String text = ((ActivityAddBlackOrFavorBinding) addBlackOrFavorActivity2.b).b.getText();
                    if (TextUtils.isEmpty(text)) {
                        k.b(1, addBlackOrFavorActivity2.getString(R.string.please_enter_phone_number));
                        return;
                    }
                    String b2 = h.b(text);
                    HashMap hashMap = new HashMap();
                    hashMap.put("relateMsisdn", "251" + b2);
                    hashMap.put("relateType", addBlackOrFavorActivity2.d);
                    ((RequestMoneyViewModel) addBlackOrFavorActivity2.c).d(hashMap);
                    return;
                } else if (((ActivityAddBlackOrFavorBinding) addBlackOrFavorActivity2.b).f.isChecked()) {
                    String text2 = ((ActivityAddBlackOrFavorBinding) addBlackOrFavorActivity2.b).c.getText();
                    if (TextUtils.isEmpty(text2)) {
                        k.b(1, addBlackOrFavorActivity2.getString(R.string.please_input_short_code));
                        return;
                    }
                    HashMap a2 = com.google.android.gms.ads.identifier.a.a("relateShortCode", text2);
                    a2.put("relateType", addBlackOrFavorActivity2.d);
                    ((RequestMoneyViewModel) addBlackOrFavorActivity2.c).d(a2);
                    return;
                } else {
                    return;
                }
        }
    }
}
