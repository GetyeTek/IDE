package P7;

import android.view.View;
import android.view.ViewGroup;
import com.huawei.payment.lib.image.crop.CropFragment;
import com.huawei.payment.lib.image.crop.view.widget.AspectTextView;
import java.util.Iterator;

public final class i implements View.OnClickListener {
    public final /* synthetic */ CropFragment a;

    public i(CropFragment cropFragment) {
        this.a = cropFragment;
    }

    public final void onClick(View view) {
        boolean z;
        CropFragment cropFragment = this.a;
        cropFragment.k.setTargetAspectRatio(((AspectTextView) ((ViewGroup) view).getChildAt(0)).b(view.isSelected()));
        cropFragment.k.setImageToWrapCropBound(true);
        if (!view.isSelected()) {
            Iterator it = cropFragment.a.iterator();
            while (it.hasNext()) {
                ViewGroup viewGroup = (ViewGroup) it.next();
                if (viewGroup == view) {
                    z = true;
                } else {
                    z = false;
                }
                viewGroup.setSelected(z);
            }
        }
    }
}
