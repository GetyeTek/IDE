package P7;

import W2.a;
import W2.n;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import androidx.fragment.app.FragmentActivity;
import c6.k;
import com.blankj.utilcode.util.l;
import com.huawei.astp.macle.ui.MaActionSheet;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.login_module.databinding.ActivityQuickRegisterLayoutBinding;
import com.huawei.digitalpayment.customer.login_module.register.viewmodel.QuickRegisterViewModel;
import com.huawei.digitalpayment.customer.login_module.registerverify.QuickRegisterActivity;
import com.huawei.digitalpayment.customer.login_module.resetpin.ResetPinOtpActivity;
import com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity;
import com.huawei.digitalpayment.schedule.dialog.ScheduleDatePickerDialog;
import com.huawei.kbz.chat.chat_room.CameraFragment;
import com.huawei.kbz.chat.contact.ChatGenderSetActivity;
import com.huawei.kbz.chat.contact.SearchNumberActivity;
import com.huawei.kbz.chat.groupChat.DeleteGroupContactActivity;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;
import com.huawei.payment.lib.image.crop.CropFragment;
import f2.c;
import java.util.Locale;
import java.util.Map;
import kotlin.jvm.internal.h;
import o0.b;

public final /* synthetic */ class g implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ View.OnCreateContextMenuListener b;

    public /* synthetic */ g(View.OnCreateContextMenuListener onCreateContextMenuListener, int i) {
        this.a = i;
        this.b = onCreateContextMenuListener;
    }

    public final void onClick(View view) {
        CheckStandFragment checkStandFragment = this.b;
        switch (this.a) {
            case 0:
                CropFragment cropFragment = (CropFragment) checkStandFragment;
                cropFragment.k.h((float) 90);
                cropFragment.k.setImageToWrapCropBound(true);
                return;
            case 1:
                QuickRegisterActivity quickRegisterActivity = (QuickRegisterActivity) checkStandFragment;
                if (!TextUtils.isEmpty(quickRegisterActivity.d)) {
                    ((QuickRegisterViewModel) quickRegisterActivity.c).d(quickRegisterActivity.d, ((ActivityQuickRegisterLayoutBinding) quickRegisterActivity.b).e.getText().toString(), ((ActivityQuickRegisterLayoutBinding) quickRegisterActivity.b).b.getText().toString(), quickRegisterActivity.e);
                    return;
                }
                return;
            case 2:
                int i = DeleteGroupContactActivity.j;
                ((DeleteGroupContactActivity) checkStandFragment).finish();
                return;
            case 3:
                MaActionSheet.c((MaActionSheet) checkStandFragment, view);
                return;
            case 4:
                int i2 = CreateAutomaticPaymentActivity.r;
                CreateAutomaticPaymentActivity createAutomaticPaymentActivity = (CreateAutomaticPaymentActivity) checkStandFragment;
                l.a(createAutomaticPaymentActivity);
                Locale.setDefault(createAutomaticPaymentActivity.getResources().getConfiguration().locale);
                ScheduleDatePickerDialog scheduleDatePickerDialog = new ScheduleDatePickerDialog(createAutomaticPaymentActivity.j, createAutomaticPaymentActivity.h);
                scheduleDatePickerDialog.m = new k(1, createAutomaticPaymentActivity, scheduleDatePickerDialog);
                scheduleDatePickerDialog.show(createAutomaticPaymentActivity.getSupportFragmentManager(), "");
                return;
            case 5:
                CameraFragment cameraFragment = (CameraFragment) checkStandFragment;
                h.f(cameraFragment, "this$0");
                FragmentActivity activity = cameraFragment.getActivity();
                if (activity != null) {
                    activity.finish();
                    return;
                }
                return;
            case 6:
                ChatGenderSetActivity chatGenderSetActivity = (ChatGenderSetActivity) checkStandFragment;
                chatGenderSetActivity.b.b.setVisibility(0);
                chatGenderSetActivity.b.e.setVisibility(8);
                chatGenderSetActivity.d = "2";
                chatGenderSetActivity.E0();
                return;
            case 7:
                SearchNumberActivity searchNumberActivity = (SearchNumberActivity) checkStandFragment;
                searchNumberActivity.E0(searchNumberActivity.b.c.getText().toString().trim());
                return;
            case 8:
                int i3 = ResetPinOtpActivity.m;
                ResetPinOtpActivity resetPinOtpActivity = (ResetPinOtpActivity) checkStandFragment;
                if (!a.a(1500, view)) {
                    resetPinOtpActivity.l.start();
                    resetPinOtpActivity.i.b(Boolean.FALSE);
                    return;
                }
                return;
            default:
                CheckStandFragment checkStandFragment2 = checkStandFragment;
                checkStandFragment2.getClass();
                ReportViewModel reportViewModel = c.b;
                c.a.a.c("Finance_Confirm_activation_superapp", new String[]{"finance_overdraft", checkStandFragment2.a.h(), "ok"});
                String string = n.b("").a.getString("openOdUrl", "");
                CheckoutResp checkoutResp = (CheckoutResp) checkStandFragment2.a.j.getValue();
                if (checkoutResp != null && !TextUtils.isEmpty(checkoutResp.getOdAgreementUrl())) {
                    string = checkoutResp.getOdAgreementUrl();
                }
                b.d(checkStandFragment2.getActivity(), string, (Bundle) null, (Map) null);
                checkStandFragment2.b.onBackPressed();
                return;
        }
    }
}
