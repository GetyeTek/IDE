package P7;

import okhttp3.OkHttpClient;

public final class l {
    public static final l b = new Object();
    public OkHttpClient a;
}
