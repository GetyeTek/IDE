package X7;

import A8.C;
import android.os.Bundle;
import androidx.fragment.app.FragmentManager;
import com.huawei.module_checkout.batchtransfer.BatchTransferFragment;
import com.huawei.webview.WebViewActivity;
import fa.d;
import fa.x;

public final class a {
    public static void a(long[] jArr, long[] jArr2, long[] jArr3) {
        jArr3[0] = jArr[0] ^ jArr2[0];
        jArr3[1] = jArr[1] ^ jArr2[1];
        jArr3[2] = jArr[2] ^ jArr2[2];
        jArr3[3] = jArr[3] ^ jArr2[3];
        jArr3[4] = jArr[4] ^ jArr2[4];
        jArr3[5] = jArr[5] ^ jArr2[5];
        jArr3[6] = jArr[6] ^ jArr2[6];
        jArr3[7] = jArr2[7] ^ jArr[7];
    }

    public static final x b(Object obj) {
        if (obj != d.a) {
            return (x) obj;
        }
        throw new IllegalStateException("Does not contain segment");
    }

    public static void c(long[] jArr, long[] jArr2) {
        long j = jArr[0];
        long j2 = jArr[1];
        long j3 = jArr[2];
        long j4 = jArr[3];
        jArr2[0] = j & 1152921504606846975L;
        jArr2[1] = ((j >>> 60) ^ (j2 << 4)) & 1152921504606846975L;
        jArr2[2] = ((j2 >>> 56) ^ (j3 << 8)) & 1152921504606846975L;
        jArr2[3] = (j3 >>> 52) ^ (j4 << 12);
    }

    public static void d(long[] jArr, long[] jArr2, long[] jArr3) {
        long[] jArr4 = new long[4];
        long[] jArr5 = new long[4];
        c(jArr, jArr4);
        c(jArr2, jArr5);
        long[] jArr6 = new long[8];
        long[] jArr7 = jArr6;
        long[] jArr8 = jArr3;
        e(jArr7, jArr4[0], jArr5[0], jArr8, 0);
        e(jArr7, jArr4[1], jArr5[1], jArr8, 1);
        e(jArr7, jArr4[2], jArr5[2], jArr8, 2);
        e(jArr7, jArr4[3], jArr5[3], jArr8, 3);
        for (int i = 5; i > 0; i--) {
            jArr3[i] = jArr3[i] ^ jArr3[i - 1];
        }
        e(jArr6, jArr4[0] ^ jArr4[1], jArr5[0] ^ jArr5[1], jArr3, 1);
        e(jArr6, jArr4[2] ^ jArr4[3], jArr5[2] ^ jArr5[3], jArr3, 3);
        for (int i2 = 7; i2 > 1; i2--) {
            jArr3[i2] = jArr3[i2] ^ jArr3[i2 - 2];
        }
        long j = jArr4[0] ^ jArr4[2];
        long j2 = jArr4[1] ^ jArr4[3];
        long j3 = jArr5[0] ^ jArr5[2];
        long j4 = jArr5[3] ^ jArr5[1];
        long[] jArr9 = jArr6;
        e(jArr9, j ^ j2, j3 ^ j4, jArr3, 3);
        long[] jArr10 = new long[3];
        long[] jArr11 = jArr10;
        e(jArr9, j, j3, jArr10, 0);
        e(jArr9, j2, j4, jArr11, 1);
        long j5 = jArr11[0];
        long j6 = jArr11[1];
        long j7 = jArr11[2];
        long j9 = jArr3[2] ^ j5;
        jArr3[2] = j9;
        long j10 = (j5 ^ j6) ^ jArr3[3];
        jArr3[3] = j10;
        long j11 = (j6 ^ j7) ^ jArr3[4];
        jArr3[4] = j11;
        long j12 = j7 ^ jArr3[5];
        jArr3[5] = j12;
        long j13 = jArr3[0];
        long j14 = jArr3[1];
        long j15 = jArr3[6];
        long j16 = jArr3[7];
        jArr3[0] = j13 ^ (j14 << 60);
        jArr3[1] = (j14 >>> 4) ^ (j9 << 56);
        jArr3[2] = (j9 >>> 8) ^ (j10 << 52);
        jArr3[3] = (j10 >>> 12) ^ (j11 << 48);
        jArr3[4] = (j11 >>> 16) ^ (j12 << 44);
        jArr3[5] = (j12 >>> 20) ^ (j15 << 40);
        jArr3[6] = (j15 >>> 24) ^ (j16 << 36);
        jArr3[7] = j16 >>> 28;
    }

    public static void e(long[] jArr, long j, long j2, long[] jArr2, int i) {
        long j3 = j;
        jArr[1] = j2;
        long j4 = j2 << 1;
        jArr[2] = j4;
        long j5 = j4 ^ j2;
        jArr[3] = j5;
        long j6 = j2 << 2;
        jArr[4] = j6;
        jArr[5] = j6 ^ j2;
        long j7 = j5 << 1;
        jArr[6] = j7;
        jArr[7] = j7 ^ j2;
        int i2 = (int) j3;
        long j9 = (jArr[(i2 >>> 3) & 7] << 3) ^ jArr[i2 & 7];
        long j10 = 0;
        int i3 = 54;
        do {
            int i4 = (int) (j3 >>> i3);
            long j11 = (jArr[(i4 >>> 3) & 7] << 3) ^ jArr[i4 & 7];
            j9 ^= j11 << i3;
            j10 ^= j11 >>> (-i3);
            i3 -= 6;
        } while (i3 > 0);
        jArr2[i] = jArr2[i] ^ (1152921504606846975L & j9);
        int i5 = i + 1;
        jArr2[i5] = ((((((j3 & 585610922974906400L) & ((j2 << 4) >> 63)) >>> 5) ^ j10) << 4) ^ (j9 >>> 60)) ^ jArr2[i5];
    }

    public static final boolean f(Object obj) {
        if (obj == d.a) {
            return true;
        }
        return false;
    }

    public static void g(WebViewActivity webViewActivity, String str, String str2, C c) {
        BatchTransferFragment batchTransferFragment = new BatchTransferFragment();
        batchTransferFragment.a = c;
        Bundle bundle = new Bundle();
        bundle.putString("note", str);
        bundle.putString("receiverItems", str2);
        batchTransferFragment.setArguments(bundle);
        FragmentManager supportFragmentManager = webViewActivity.getSupportFragmentManager();
        supportFragmentManager.beginTransaction().add(batchTransferFragment, "BatchTransferFragment").commitAllowingStateLoss();
        supportFragmentManager.executePendingTransactions();
    }

    public static void h(long[] jArr, long[] jArr2, long[] jArr3) {
        long[] jArr4 = new long[8];
        d(jArr, jArr2, jArr4);
        i(jArr4, jArr3);
    }

    public static void i(long[] jArr, long[] jArr2) {
        long j = jArr[0];
        long j2 = jArr[1];
        long j3 = jArr[2];
        long j4 = jArr[3];
        long j5 = jArr[4];
        long j6 = jArr[5];
        long j7 = jArr[6];
        long j9 = jArr[7];
        long j10 = j7 ^ (j9 >>> 17);
        long j11 = (j6 ^ (j9 << 47)) ^ (j10 >>> 17);
        long j12 = ((j5 ^ (j9 >>> 47)) ^ (j10 << 47)) ^ (j11 >>> 17);
        long j13 = j ^ (j12 << 17);
        long j14 = (j2 ^ (j11 << 17)) ^ (j12 >>> 47);
        long j15 = (((j4 ^ (j9 << 17)) ^ (j10 >>> 47)) ^ (j11 << 47)) ^ (j12 >>> 17);
        long j16 = j15 >>> 47;
        jArr2[0] = j13 ^ j16;
        jArr2[1] = j14;
        long j17 = j16 << 30;
        jArr2[2] = j17 ^ (((j3 ^ (j10 << 17)) ^ (j11 >>> 47)) ^ (j12 << 47));
        jArr2[3] = 140737488355327L & j15;
    }

    public static void j(long[] jArr, long[] jArr2) {
        long[] jArr3 = new long[8];
        B2.a.d(4, jArr, jArr3);
        i(jArr3, jArr2);
    }

    public static void k(int i, long[] jArr, long[] jArr2) {
        long[] jArr3 = new long[8];
        B2.a.d(4, jArr, jArr3);
        while (true) {
            i(jArr3, jArr2);
            i--;
            if (i > 0) {
                B2.a.d(4, jArr2, jArr3);
            } else {
                return;
            }
        }
    }
}
