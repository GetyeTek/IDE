package Y7;

import S1.d;
import S1.e;
import V1.h;
import W2.n;
import android.content.Context;
import android.text.TextUtils;
import b8.b;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import org.json.JSONObject;

public final class a implements e {
    public final /* synthetic */ int compareTo(Object obj) {
        return d.a(this, (e) obj);
    }

    public final int d() {
        return 0;
    }

    public final void f(Context context, String str) {
        try {
            String optString = new JSONObject(str).optString("topics");
            h.b();
            if (!TextUtils.isEmpty(optString)) {
                n.b("sp_name_push").g("topics", new JSONObject(optString).toString(), false);
            }
        } catch (Exception e) {
            e.toString();
            h.b();
        }
        b.b(LanguageUtils.getInstance().getCurrentLang());
    }

    public final void onLogout() {
        b.d(LanguageUtils.getInstance().getCurrentLang());
    }

    public final void e() {
    }
}
