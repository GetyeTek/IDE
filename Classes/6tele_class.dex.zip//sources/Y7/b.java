package Y7;

import S1.a;
import S1.e;

public final class b extends a {
    public final Object a() {
        return null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [S1.e, java.lang.Object] */
    public final e c() {
        return new Object();
    }
}
