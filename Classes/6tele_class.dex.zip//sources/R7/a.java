package R7;

import android.graphics.Bitmap;
import android.net.Uri;

public final class a {
    public final int a;
    public final int b;
    public final int c;
    public final Bitmap.CompressFormat d;
    public final String e;
    public final String f;
    public Uri g;
    public Uri h;

    public a(int i, int i2, Bitmap.CompressFormat compressFormat, int i3, String str, String str2) {
        this.a = i;
        this.b = i2;
        this.d = compressFormat;
        this.c = i3;
        this.e = str;
        this.f = str2;
    }
}
