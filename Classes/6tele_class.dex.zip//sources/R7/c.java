package R7;

import android.graphics.RectF;

public final class c {
    public final RectF a;
    public final RectF b;
    public final float c;
    public final float d;

    public c(RectF rectF, RectF rectF2, float f, float f2) {
        this.a = rectF;
        this.b = rectF2;
        this.c = f;
        this.d = f2;
    }
}
