package d8;

import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.push.response.NotificationUnReadCountResp;
import com.huawei.push.viewmodel.NotificationViewModel;

public final class a extends BaseViewModel.a<NotificationUnReadCountResp> {
    public final /* synthetic */ NotificationViewModel b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(NotificationViewModel notificationViewModel) {
        super(notificationViewModel);
        this.b = notificationViewModel;
    }

    public final void onSuccess(Object obj) {
        a.super.onSuccess((NotificationUnReadCountResp) obj);
        this.b.h.setValue((Object) null);
    }
}
