package s8;

import com.huawei.qrcode.databinding.ActivityVerifyPaymentBinding;
import com.huawei.qrcode.verify.VerifyPaymentActivity;

public final class a extends O2.a {
    public final /* synthetic */ VerifyPaymentActivity b;

    public a(VerifyPaymentActivity verifyPaymentActivity) {
        super(2);
        this.b = verifyPaymentActivity;
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        int length = charSequence.length();
        VerifyPaymentActivity verifyPaymentActivity = this.b;
        if (length == 0) {
            int i4 = VerifyPaymentActivity.d;
            ((ActivityVerifyPaymentBinding) verifyPaymentActivity.b).a.setEnabled(false);
            return;
        }
        int i5 = VerifyPaymentActivity.d;
        ((ActivityVerifyPaymentBinding) verifyPaymentActivity.b).a.setEnabled(true);
    }
}
