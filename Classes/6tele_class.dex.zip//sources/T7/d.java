package T7;

import android.graphics.RectF;

public final class d {
    public static RectF a(float[] fArr) {
        RectF rectF = new RectF(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);
        for (int i = 1; i < fArr.length; i += 2) {
            float round = ((float) Math.round(fArr[i - 1] * 10.0f)) / 10.0f;
            float round2 = ((float) Math.round(fArr[i] * 10.0f)) / 10.0f;
            rectF.left = Math.min(round, rectF.left);
            rectF.top = Math.min(round2, rectF.top);
            rectF.right = Math.max(round, rectF.right);
            rectF.bottom = Math.max(round2, rectF.bottom);
        }
        rectF.sort();
        return rectF;
    }
}
