package T7;

import android.net.Uri;
import androidx.annotation.Nullable;
import java.io.Closeable;
import java.io.IOException;

public final class a {
    public static void a(@Nullable Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    public static boolean b(Uri uri) {
        if (uri == null || !"content".equals(uri.getScheme())) {
            return false;
        }
        return true;
    }
}
