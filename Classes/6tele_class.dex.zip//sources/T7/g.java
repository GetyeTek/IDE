package T7;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.Window;

public final class g {
    public static int a = Integer.MAX_VALUE;
    public static int b = Integer.MAX_VALUE;

    public static void a(Activity activity, boolean z) {
        int i;
        if (activity != null && activity.getWindow() != null) {
            Window window = activity.getWindow();
            if (Build.VERSION.SDK_INT >= 23) {
                View decorView = window.getDecorView();
                int systemUiVisibility = decorView.getSystemUiVisibility();
                if (z) {
                    i = systemUiVisibility | 8192;
                } else {
                    i = systemUiVisibility & -8193;
                }
                decorView.setSystemUiVisibility(i);
            }
        }
    }
}
