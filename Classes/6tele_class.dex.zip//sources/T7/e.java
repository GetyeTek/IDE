package T7;

import com.huawei.payment.lib.image.crop.view.GestureCropImageView;

public final class e {
    public final GestureCropImageView.b a;
    public float b;
    public float c;
    public float d;
    public float e;
    public int f = -1;
    public int g = -1;
    public float h;
    public boolean i;

    public static class a {
    }

    public e(GestureCropImageView.b bVar) {
        this.a = bVar;
    }
}
