package T7;

import android.text.TextUtils;
import androidx.exifinterface.media.ExifInterface;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;

public final class c {
    public static final byte[] b = "Exif\u0000\u0000".getBytes(Charset.forName("UTF-8"));
    public static final int[] c = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8};
    public final a a;

    public static class a {
        public final InputStream a;

        public a(InputStream inputStream) {
            this.a = inputStream;
        }
    }

    public c(InputStream inputStream) {
        this.a = new a(inputStream);
    }

    public static void a(ExifInterface exifInterface, ExifInterface exifInterface2, int i, int i2) throws IOException {
        ExifInterface exifInterface3 = exifInterface2;
        String[] strArr = {"FNumber", "DateTime", "DateTimeDigitized", "ExposureTime", "Flash", "FocalLength", "GPSAltitude", "GPSAltitudeRef", "GPSDateStamp", "GPSLatitude", "GPSLatitudeRef", "GPSLongitude", "GPSLongitudeRef", "GPSProcessingMethod", "GPSTimeStamp", "PhotographicSensitivity", "Make", "Model", "SubSecTime", "SubSecTimeDigitized", "SubSecTimeOriginal", "WhiteBalance"};
        for (int i3 = 0; i3 < 22; i3++) {
            String str = strArr[i3];
            String attribute = exifInterface.getAttribute(str);
            if (!TextUtils.isEmpty(attribute)) {
                exifInterface3.setAttribute(str, attribute);
            }
        }
        exifInterface3.setAttribute("ImageWidth", String.valueOf(i));
        exifInterface3.setAttribute("ImageLength", String.valueOf(i2));
        exifInterface3.setAttribute("Orientation", "0");
        exifInterface2.saveAttributes();
    }

    public final int b() throws IOException {
        int i;
        boolean z;
        short s;
        int i2;
        int i3;
        int i4;
        short read;
        InputStream inputStream = this.a.a;
        int read2 = ((inputStream.read() << 8) & 65280) | (inputStream.read() & 255);
        if ((read2 & 65496) != 65496 && read2 != 19789 && read2 != 18761) {
            return -1;
        }
        while (true) {
            if (((short) (inputStream.read() & 255)) == 255 && (read = (short) (inputStream.read() & 255)) != 218 && read != 217) {
                i = (((inputStream.read() << 8) & 65280) | (inputStream.read() & 255)) - 2;
                if (read == 225) {
                    break;
                }
                long j = (long) i;
                long j2 = 0;
                if (j >= 0) {
                    long j3 = j;
                    while (j3 > 0) {
                        long skip = inputStream.skip(j3);
                        if (skip <= 0) {
                            if (inputStream.read() == -1) {
                                break;
                            }
                            skip = 1;
                        }
                        j3 -= skip;
                    }
                    j2 = j - j3;
                }
                if (j2 != j) {
                    break;
                }
            }
        }
        i = -1;
        if (i == -1) {
            return -1;
        }
        byte[] bArr = new byte[i];
        int i5 = i;
        while (i5 > 0) {
            int read3 = inputStream.read(bArr, i - i5, i5);
            if (read3 == -1) {
                break;
            }
            i5 -= read3;
        }
        if (i - i5 != i) {
            return -1;
        }
        byte[] bArr2 = b;
        if (i > bArr2.length) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            int i6 = 0;
            while (true) {
                if (i6 >= bArr2.length) {
                    break;
                } else if (bArr[i6] != bArr2[i6]) {
                    z = false;
                    break;
                } else {
                    i6++;
                }
            }
        }
        if (!z) {
            return -1;
        }
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
        ByteBuffer byteBuffer = (ByteBuffer) wrap.order(byteOrder).limit(i);
        short s2 = byteBuffer.getShort(6);
        if (s2 != 19789 && s2 == 18761) {
            byteOrder = ByteOrder.LITTLE_ENDIAN;
        }
        byteBuffer.order(byteOrder);
        int i7 = byteBuffer.getInt(10);
        short s3 = byteBuffer.getShort(i7 + 6);
        for (int i9 = 0; i9 < s3; i9++) {
            int i10 = (i9 * 12) + i7 + 8;
            if (byteBuffer.getShort(i10) == 274 && (s = byteBuffer.getShort(i10 + 2)) >= 1 && s <= 12 && (i2 = byteBuffer.getInt(i10 + 4)) >= 0 && (i3 = i2 + c[s]) <= 4 && (i4 = i10 + 8) >= 0 && i4 <= byteBuffer.remaining() && i3 >= 0 && i3 + i4 <= byteBuffer.remaining()) {
                return byteBuffer.getShort(i4);
            }
        }
        return -1;
    }
}
