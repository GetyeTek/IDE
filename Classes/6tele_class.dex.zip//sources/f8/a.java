package f8;

import android.content.Intent;
import java.util.HashMap;

public final class a {
    public HashMap a;

    /* renamed from: f8.a$a  reason: collision with other inner class name */
    public static class C0002a {
        public static final a a;

        /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, f8.a] */
        static {
            ? obj = new Object();
            obj.a = new HashMap();
            a = obj;
        }
    }

    public final void a(String str, Intent intent) {
        if (this.a == null) {
            this.a = new HashMap();
        }
        if (this.a.size() > 0) {
            this.a.clear();
        }
        this.a.put(str, intent);
    }
}
