package p8;

public final class a {
    public String a;
    public Class b;
}
