package o8;

import W2.n;
import android.widget.CompoundButton;

public final /* synthetic */ class a implements CompoundButton.OnCheckedChangeListener {
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        n.b("").h("IS_SCAN_GUIDE_CHECKED", z);
    }
}
