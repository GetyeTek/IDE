package o8;

import V1.k;
import androidx.annotation.NonNull;
import com.blankj.utilcode.util.e;
import com.blankj.utilcode.util.q;
import com.huawei.qrcode.R$string;
import com.huawei.qrcode.scan.fragment.ScanGuideFragment;
import java.util.ArrayList;

public final class b implements q.a {
    public final /* synthetic */ ScanGuideFragment a;

    public b(ScanGuideFragment scanGuideFragment) {
        this.a = scanGuideFragment;
    }

    public final void a(@NonNull ArrayList arrayList) {
        this.a.d.F();
    }

    public final void b(@NonNull ArrayList arrayList) {
        e.b();
        k.b(1, this.a.getString(R$string.camera_permission_deny));
    }
}
