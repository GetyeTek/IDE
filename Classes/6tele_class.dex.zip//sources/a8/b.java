package a8;

import S2.a;
import T2.h;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import java.util.ArrayList;
import java.util.HashMap;

public final class b extends h<BaseResp, BaseResp> {
    public final /* synthetic */ ArrayList b;
    public final /* synthetic */ c c;

    public b(c cVar, ArrayList arrayList) {
        this.c = cVar;
        this.b = arrayList;
    }

    public final LiveData<a<BaseResp>> a() {
        HashMap hashMap = new HashMap();
        hashMap.put("msgIds", this.b);
        return this.c.a.a(hashMap);
    }

    public final MutableLiveData b() {
        return this.c.c;
    }

    public final void c(Object obj) {
        this.c.c.postValue((BaseResp) obj);
    }
}
