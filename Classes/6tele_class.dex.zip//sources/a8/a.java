package a8;

import T2.h;
import W2.n;
import W2.r;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.push.response.NotificationUnReadCountResp;
import java.util.HashMap;

public final class a extends h<NotificationUnReadCountResp, NotificationUnReadCountResp> {
    public final /* synthetic */ c b;

    public a(c cVar) {
        this.b = cVar;
    }

    public final LiveData<S2.a<NotificationUnReadCountResp>> a() {
        return this.b.a.b(new HashMap());
    }

    public final MutableLiveData b() {
        return this.b.b;
    }

    public final void c(Object obj) {
        NotificationUnReadCountResp notificationUnReadCountResp = (NotificationUnReadCountResp) obj;
        n.b("sp_name_push").g("unreadCountUpdateTime", notificationUnReadCountResp.getServerTimestamp(), false);
        n b2 = n.b("sp_name_push");
        b2.f(notificationUnReadCountResp.getSystemNotificationCount(), "systemNotificationCount");
        b2.f(notificationUnReadCountResp.getPromotionNotificationCount(), "promotionNotificationCount");
        b2.f(notificationUnReadCountResp.getTransferNotificationCount(), "transactionNotificationCount");
        b2.f(notificationUnReadCountResp.getCommerceMessageCount(), "eCommerceMessageCount");
        b2.f(notificationUnReadCountResp.getDriverMessageCount(), "driverMessageCount");
        this.b.b.postValue(notificationUnReadCountResp);
    }

    public final boolean e(Object obj) {
        long j;
        NotificationUnReadCountResp notificationUnReadCountResp = (NotificationUnReadCountResp) obj;
        String e = n.b("sp_name_push").e("unreadCountUpdateTime");
        long time = r.d().getTime();
        try {
            j = Long.parseLong(e);
        } catch (Exception unused) {
            j = 0;
        }
        V1.h.b();
        V1.h.b();
        V1.h.b();
        c.a();
        V1.h.b();
        c.a();
        V1.h.b();
        if (time - j >= c.a()) {
            return true;
        }
        return false;
    }
}
