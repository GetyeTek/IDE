package a8;

import W2.n;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.push.response.NotificationUnReadCountResp;

public final class c {
    public final b8.c a;
    public final MutableLiveData<NotificationUnReadCountResp> b = new MutableLiveData<>((Object) null);
    public final MutableLiveData<BaseResp> c = new MutableLiveData<>((Object) null);

    public c() {
        H3.c cVar = H3.c.b;
        L2.c.a.getClass();
        this.a = (b8.c) cVar.c("https://www.superapp.ethiomobilemoney.et:38443/appgateway/consumer/appserver/consumer/").b(b8.c.class);
    }

    public static long a() {
        try {
            return Long.parseLong(n.b("sp_name_push").e("UnReadCountUpdateTimeInterval"));
        } catch (NumberFormatException unused) {
            return 300000;
        }
    }
}
