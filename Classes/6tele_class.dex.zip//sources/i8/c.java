package i8;

import P2.a;
import com.huawei.digitalpayment.customer.httplib.response.GetH5AccessTokenResp;

public interface c extends a {
    void e();

    void g(GetH5AccessTokenResp getH5AccessTokenResp);
}
