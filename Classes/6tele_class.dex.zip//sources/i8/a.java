package i8;

import L2.b;
import com.huawei.digitalpayment.customer.httplib.response.GetH5AccessTokenResp;

public final class a extends b<GetH5AccessTokenResp> {
    public final /* synthetic */ b f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(b bVar, P2.a aVar) {
        super(aVar, true);
        this.f = bVar;
    }

    public final void b(String str) {
        ((P2.a) this.f.a).e();
    }

    public final void c(Object obj) {
        ((P2.a) this.f.a).g((GetH5AccessTokenResp) obj);
    }
}
