package i8;

import A8.c;

public final class d extends c {
}
