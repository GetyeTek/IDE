package m8;

import com.huawei.digitalpayment.customer.httplib.response.GetQrCodeResp;
import java.util.List;

public interface a extends P2.a {
    void d(String str, List<GetQrCodeResp.QrCode> list);
}
