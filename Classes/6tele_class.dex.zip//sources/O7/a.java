package O7;

import R5.a;
import S5.h;
import android.os.Bundle;
import android.view.View;
import com.huawei.ethiopia.finance.constants.TransactionType;
import com.huawei.ethiopia.finance.saving.activity.LockedSavingAccountDetailActivity;
import com.huawei.kbz.chat.chat_room.B;
import com.huawei.kbz.chat.chat_room.ChatFragment;
import com.huawei.kbz.chat.chat_room.model.UiMessage;
import com.huawei.kbz.chat.chat_room.view_model.message.BaseMessageViewModel;
import com.huawei.kbz.chat.contact.ContactFriendActivity;
import com.huawei.module_checkout.transfer2merchant.activity.Transfer2MerchantActivity;
import com.huawei.payment.dialog.AddNoteDialog;
import com.huawei.webview.WebViewActivity;
import com.shinemo.chat.CYConversation;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import o0.b;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                ((AddNoteDialog) obj).dismiss();
                return;
            case 1:
                ChatFragment chatFragment = ((B) obj).a;
                ArrayList a2 = chatFragment.b.a();
                if (!J8.a.i(a2)) {
                    h6.a b2 = h6.a.b();
                    String str = chatFragment.g;
                    String str2 = chatFragment.h;
                    b2.getClass();
                    CYConversation a3 = h6.a.a(str, str2);
                    if (a3 != null) {
                        ArrayList arrayList = R5.a.a;
                        a.a.a.getClass();
                        BaseMessageViewModel a4 = R5.a.a();
                        a4.getClass();
                        ArrayList arrayList2 = new ArrayList();
                        Iterator it = a2.iterator();
                        while (it.hasNext()) {
                            arrayList2.add(Long.valueOf(((UiMessage) it.next()).getMessage().getMessageClientId()));
                        }
                        a3.deleteMessage(arrayList2, new h(a4, a2, arrayList2));
                        return;
                    }
                    return;
                }
                return;
            case 2:
                int i = ContactFriendActivity.p;
                ContactFriendActivity contactFriendActivity = (ContactFriendActivity) obj;
                contactFriendActivity.getClass();
                b.d(contactFriendActivity, "/chat/add_contact", (Bundle) null, (Map) null);
                return;
            case 3:
                int i2 = Transfer2MerchantActivity.q;
                ((Transfer2MerchantActivity) obj).W0();
                return;
            case 4:
                int i3 = WebViewActivity.j;
                ((WebViewActivity) obj).onBackPressed();
                return;
            default:
                int i4 = LockedSavingAccountDetailActivity.h;
                LockedSavingAccountDetailActivity lockedSavingAccountDetailActivity = (LockedSavingAccountDetailActivity) obj;
                lockedSavingAccountDetailActivity.getClass();
                lockedSavingAccountDetailActivity.E0(TransactionType.DEPOSIT);
                return;
        }
    }
}
