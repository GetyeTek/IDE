package O7;

import androidx.camera.video.Recorder;
import com.blankj.utilcode.util.l;
import com.huawei.payment.dialog.AddNoteDialog;

public final /* synthetic */ class b implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ b(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void run() {
        switch (this.a) {
            case 0:
                l.d(((AddNoteDialog) this.b).d.d);
                return;
            default:
                ((Recorder) this.b).tryServicePendingRecording();
                return;
        }
    }
}
