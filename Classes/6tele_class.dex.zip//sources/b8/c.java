package b8;

import S2.a;
import androidx.lifecycle.LiveData;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.push.response.NotificationUnReadCountResp;
import ic.o;
import java.util.Map;

public interface c {
    @o("v1/setReadAppNotification")
    LiveData<a<BaseResp>> a(@ic.a Map<String, Object> map);

    @o("v1/getAppNotificationUnreadNumCommon")
    LiveData<a<NotificationUnReadCountResp>> b(@ic.a Map<String, String> map);
}
