package b8;

import B7.e;
import S2.b;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.Observer;
import com.huawei.push.service.NotificationModuleServiceIml;

public final /* synthetic */ class d implements Observer {
    public final /* synthetic */ NotificationModuleServiceIml a;
    public final /* synthetic */ e b;

    public /* synthetic */ d(NotificationModuleServiceIml notificationModuleServiceIml, e eVar) {
        this.a = notificationModuleServiceIml;
        this.b = eVar;
    }

    public final void onChanged(Object obj) {
        d dVar;
        b bVar = (b) obj;
        NotificationModuleServiceIml notificationModuleServiceIml = this.a;
        notificationModuleServiceIml.getClass();
        if (!bVar.d()) {
            boolean f = bVar.f();
            e eVar = this.b;
            if (f) {
                eVar.h();
            }
            if (bVar.b()) {
                eVar.h();
            }
            MediatorLiveData mediatorLiveData = notificationModuleServiceIml.b;
            if (mediatorLiveData != null && (dVar = notificationModuleServiceIml.c) != null) {
                mediatorLiveData.removeObserver(dVar);
                notificationModuleServiceIml.b = null;
                notificationModuleServiceIml.c = null;
            }
        }
    }
}
