package b8;

import V1.h;
import W2.n;
import androidx.annotation.NonNull;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import java.util.Objects;

public final class a implements OnCompleteListener<String> {
    public final void onComplete(@NonNull Task<String> task) {
        if (!task.isSuccessful()) {
            Objects.toString(task.getException());
            h.b();
            return;
        }
        String currentLang = LanguageUtils.getInstance().getCurrentLang();
        b.a(currentLang, currentLang);
        n.b("").g("FIREBASE_TOKEN", (String) task.getResult(), false);
    }
}
