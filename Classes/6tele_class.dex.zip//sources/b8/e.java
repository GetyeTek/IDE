package b8;

import android.app.NotificationChannel;
import android.view.autofill.AutofillManager;

public final /* synthetic */ class e {
    public static /* synthetic */ NotificationChannel b(int i, String str, String str2) {
        return new NotificationChannel(str, str2, i);
    }

    public static /* bridge */ /* synthetic */ AutofillManager c(Object obj) {
        return (AutofillManager) obj;
    }
}
