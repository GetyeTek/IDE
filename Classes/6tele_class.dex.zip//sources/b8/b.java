package b8;

import V1.h;
import W2.f;
import W2.n;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.google.firebase.messaging.FirebaseMessaging;
import com.huawei.push.resp.TopicResp;
import java.util.List;

public final class b {
    public static void a(String str, String str2) {
        if (!TextUtils.isEmpty("all")) {
            FirebaseMessaging instance = FirebaseMessaging.getInstance();
            instance.unsubscribeFromTopic("all_" + str).addOnCompleteListener(new androidx.camera.video.internal.encoder.b(str, str2));
        }
    }

    public static void b(String str) {
        List<String> topics;
        String string = n.b("").a.getString("FIREBASE_TOKEN", "");
        h.b();
        if (!TextUtils.isEmpty(string)) {
            c("loginAll", str);
            try {
                TopicResp topicResp = (TopicResp) f.a(n.b("sp_name_push").e("topics"), TopicResp.class);
                if (topicResp != null && (topics = topicResp.getTopics()) != null && !topics.isEmpty()) {
                    for (String c : topics) {
                        c(c, str);
                    }
                }
            } catch (Exception unused) {
            }
        }
    }

    /* JADX WARNING: type inference failed for: r4v1, types: [java.lang.Object, com.google.android.gms.tasks.OnCompleteListener] */
    public static void c(@NonNull String str, String str2) {
        String string = n.b("").a.getString("FIREBASE_TOKEN", "");
        if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(string)) {
            FirebaseMessaging instance = FirebaseMessaging.getInstance();
            instance.subscribeToTopic(str + "_" + str2).addOnCompleteListener(new Object());
        }
    }

    public static void d(String str) {
        List<String> topics;
        e("loginAll", str);
        try {
            TopicResp topicResp = (TopicResp) f.a(n.b("sp_name_push").e("topics"), TopicResp.class);
            if (!(topicResp == null || (topics = topicResp.getTopics()) == null || topics.isEmpty())) {
                for (String e : topics) {
                    e(e, str);
                }
            }
        } catch (Exception unused) {
        }
        n.b("sp_name_push").a.edit().clear().apply();
    }

    /* JADX WARNING: type inference failed for: r3v1, types: [java.lang.Object, com.google.android.gms.tasks.OnCompleteListener] */
    public static void e(@NonNull String str, String str2) {
        if (!TextUtils.isEmpty(str)) {
            FirebaseMessaging instance = FirebaseMessaging.getInstance();
            instance.unsubscribeFromTopic(str + "_" + str2).addOnCompleteListener(new Object());
        }
    }
}
