package U7;

import Q7.c;
import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import com.huawei.ethiopia.finance.saving.activity.SavingFragment;

public final /* synthetic */ class b implements c {
    public final /* synthetic */ Object a;

    public /* synthetic */ b(Object obj) {
        this.a = obj;
    }

    public void a(SavingActivatableProduct savingActivatableProduct) {
        ((SavingFragment) this.a).v0(savingActivatableProduct);
    }
}
