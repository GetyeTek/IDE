package U7;

import Q7.b;
import com.blankj.utilcode.util.e;
import com.huawei.kbz.dialog.upgrade_dialog.UpgradeAppDialog;

public final /* synthetic */ class a implements b, D2.a {
    public final /* synthetic */ Object a;

    public /* synthetic */ a(Object obj) {
        this.a = obj;
    }

    public void c(boolean z) {
        ((UpgradeAppDialog) this.a).getClass();
        if (!z) {
            e.b();
        }
    }
}
