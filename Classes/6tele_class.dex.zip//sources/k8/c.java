package k8;

import O2.a;
import W2.g;
import com.huawei.qrcode.receive.SetQrCodeAmountActivity;

public final class c extends a {
    public final /* synthetic */ SetQrCodeAmountActivity b;

    public c(SetQrCodeAmountActivity setQrCodeAmountActivity) {
        super(0);
        this.b = setQrCodeAmountActivity;
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        int length = charSequence.length();
        SetQrCodeAmountActivity setQrCodeAmountActivity = this.b;
        if (length == 0) {
            setQrCodeAmountActivity.i.b.setAlpha(0.4f);
            setQrCodeAmountActivity.i.b.setClickable(false);
        } else if (g.a(charSequence.toString())) {
            setQrCodeAmountActivity.i.b.setAlpha(1.0f);
            setQrCodeAmountActivity.i.b.setClickable(true);
        } else {
            setQrCodeAmountActivity.i.b.setAlpha(0.4f);
            setQrCodeAmountActivity.i.b.setClickable(false);
        }
    }
}
