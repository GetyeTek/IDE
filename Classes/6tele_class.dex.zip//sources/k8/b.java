package k8;

import N.c;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.qrcode.receive.ReceiveCodeActivity;

public final class b extends c<Bitmap> {
    public final /* synthetic */ ReceiveCodeActivity a;

    public b(ReceiveCodeActivity receiveCodeActivity) {
        this.a = receiveCodeActivity;
    }

    public final void onResourceReady(@NonNull Object obj, @Nullable O.b bVar) {
        this.a.p = (Bitmap) obj;
    }

    public final void onLoadCleared(@Nullable Drawable drawable) {
    }
}
