package k8;

import W2.s;
import android.widget.PopupWindow;
import com.huawei.qrcode.receive.ReceiveCodeActivity;

public final /* synthetic */ class a implements PopupWindow.OnDismissListener {
    public final /* synthetic */ ReceiveCodeActivity a;

    public /* synthetic */ a(ReceiveCodeActivity receiveCodeActivity) {
        this.a = receiveCodeActivity;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.qrcode.receive.ReceiveCodeActivity, java.lang.Object, android.app.Activity] */
    public final void onDismiss() {
        int i = ReceiveCodeActivity.t;
        ? r0 = this.a;
        r0.getClass();
        s.a(r0, 1.0f);
    }
}
