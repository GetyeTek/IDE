package M7;

import P2.a;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;

public interface c extends a {
    void x(VerifyNumberResp verifyNumberResp);
}
