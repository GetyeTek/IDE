package M7;

import A8.c;
import L2.b;
import R3.e;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;

public final class a extends b {
    public final /* synthetic */ int f = 0;
    public final /* synthetic */ c g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(e eVar, P2.a aVar) {
        super(aVar, true, "sendSmsCode");
        this.g = eVar;
    }

    public final void b(String str) {
        switch (this.f) {
            case 0:
                return;
            default:
                ((P2.a) this.g.a).r();
                return;
        }
    }

    public final void c(Object obj) {
        switch (this.f) {
            case 0:
                ((P2.a) this.g.a).x((VerifyNumberResp) obj);
                return;
            default:
                BaseResp baseResp = (BaseResp) obj;
                ((P2.a) this.g.a).Q();
                return;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(b bVar, P2.a aVar) {
        super(aVar, true, "");
        this.g = bVar;
    }

    private final void d(String str) {
    }
}
