package j8;

import V1.h;
import android.net.Uri;
import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public final class a {
    public static String a(HashMap hashMap) {
        String str;
        if (TextUtils.isEmpty("native://app/pwaModule/mandateGetToken")) {
            return null;
        }
        StringBuilder sb = new StringBuilder("native://app/pwaModule/mandateGetToken");
        if (!hashMap.isEmpty()) {
            for (Map.Entry entry : hashMap.entrySet()) {
                try {
                    if (!TextUtils.isEmpty((CharSequence) entry.getValue())) {
                        if (sb.toString().contains("?")) {
                            str = "&";
                        } else {
                            str = "?";
                        }
                        sb.append(str);
                        sb.append((String) entry.getKey());
                        sb.append("=");
                        sb.append(URLEncoder.encode((String) entry.getValue(), "utf-8"));
                    }
                } catch (UnsupportedEncodingException e) {
                    e.getMessage();
                    h.b();
                }
            }
        }
        return sb.toString();
    }

    public static HashMap<String, String> b(Uri uri) {
        HashMap<String, String> hashMap = new HashMap<>();
        for (String next : uri.getQueryParameterNames()) {
            hashMap.put(next, uri.getQueryParameter(next));
        }
        return hashMap;
    }
}
