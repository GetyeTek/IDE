package S7;

import R7.c;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.net.Uri;
import android.os.AsyncTask;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.File;
import java.lang.ref.WeakReference;

public final class a extends AsyncTask<Void, Void, Throwable> {
    public final WeakReference<Context> a;
    public final RectF b;
    public final RectF c;
    public final int d;
    public final int e;
    public final Bitmap.CompressFormat f;
    public final int g;
    public final String h;
    public final String i;
    public final Uri j;
    public final Uri k;
    public final Q7.a l;
    public Bitmap m;
    public float n;
    public final float o;
    public int p;
    public int q;
    public int r;
    public int s;

    public a(@NonNull Context context, @Nullable Bitmap bitmap, @NonNull c cVar, @NonNull R7.a aVar, @Nullable Q7.a aVar2) {
        this.a = new WeakReference<>(context);
        this.m = bitmap;
        this.b = cVar.a;
        this.c = cVar.b;
        this.n = cVar.c;
        this.o = cVar.d;
        this.d = aVar.a;
        this.e = aVar.b;
        this.f = aVar.d;
        this.g = aVar.c;
        this.h = aVar.e;
        this.i = aVar.f;
        this.j = aVar.g;
        this.k = aVar.h;
        this.l = aVar2;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v1, resolved type: android.os.ParcelFileDescriptor} */
    /* JADX WARNING: type inference failed for: r12v0 */
    /* JADX WARNING: type inference failed for: r12v3, types: [java.io.InputStream] */
    /* JADX WARNING: type inference failed for: r12v4, types: [java.io.InputStream] */
    /* JADX WARNING: type inference failed for: r12v5 */
    /* JADX WARNING: type inference failed for: r12v6 */
    /* JADX WARNING: type inference failed for: r12v7 */
    /* JADX WARNING: type inference failed for: r12v8 */
    /* JADX WARNING: type inference failed for: r12v10, types: [java.io.Closeable] */
    /* JADX WARNING: type inference failed for: r12v11 */
    /* JADX WARNING: type inference failed for: r12v12, types: [java.io.InputStream] */
    /* JADX WARNING: type inference failed for: r12v13 */
    /* JADX WARNING: type inference failed for: r12v14 */
    /* JADX WARNING: type inference failed for: r12v17 */
    /* JADX WARNING: type inference failed for: r12v18 */
    /* JADX WARNING: type inference failed for: r12v19 */
    /* JADX WARNING: type inference failed for: r12v20 */
    /* JADX WARNING: type inference failed for: r12v21 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:100:0x021e A[SYNTHETIC, Splitter:B:100:0x021e] */
    /* JADX WARNING: Removed duplicated region for block: B:177:0x0330  */
    /* JADX WARNING: Removed duplicated region for block: B:179:0x0335  */
    /* JADX WARNING: Removed duplicated region for block: B:184:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x01f7 A[SYNTHETIC, Splitter:B:85:0x01f7] */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x0206 A[SYNTHETIC, Splitter:B:90:0x0206] */
    /* JADX WARNING: Removed duplicated region for block: B:95:0x020f A[SYNTHETIC, Splitter:B:95:0x020f] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a() throws java.io.IOException {
        /*
            r16 = this;
            r1 = r16
            java.lang.ref.WeakReference<android.content.Context> r0 = r1.a
            java.lang.Object r2 = r0.get()
            android.content.Context r2 = (android.content.Context) r2
            if (r2 != 0) goto L_0x000d
            return
        L_0x000d:
            int r3 = r1.d
            int r4 = r1.e
            android.graphics.RectF r5 = r1.b
            if (r3 <= 0) goto L_0x0064
            if (r4 <= 0) goto L_0x0064
            float r6 = r5.width()
            float r7 = r1.n
            float r6 = r6 / r7
            float r7 = r5.height()
            float r8 = r1.n
            float r7 = r7 / r8
            float r8 = (float) r3
            int r8 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r8 > 0) goto L_0x002f
            float r8 = (float) r4
            int r8 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1))
            if (r8 <= 0) goto L_0x0064
        L_0x002f:
            float r8 = (float) r3
            float r8 = r8 / r6
            float r6 = (float) r4
            float r6 = r6 / r7
            float r6 = java.lang.Math.min(r8, r6)
            android.graphics.Bitmap r7 = r1.m
            int r8 = r7.getWidth()
            float r8 = (float) r8
            float r8 = r8 * r6
            int r8 = java.lang.Math.round(r8)
            android.graphics.Bitmap r9 = r1.m
            int r9 = r9.getHeight()
            float r9 = (float) r9
            float r9 = r9 * r6
            int r9 = java.lang.Math.round(r9)
            r10 = 0
            android.graphics.Bitmap r7 = android.graphics.Bitmap.createScaledBitmap(r7, r8, r9, r10)
            android.graphics.Bitmap r8 = r1.m
            if (r8 == r7) goto L_0x005d
            r8.recycle()
        L_0x005d:
            r1.m = r7
            float r7 = r1.n
            float r7 = r7 / r6
            r1.n = r7
        L_0x0064:
            r6 = 0
            float r7 = r1.o
            int r8 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1))
            if (r8 == 0) goto L_0x00a1
            android.graphics.Matrix r14 = new android.graphics.Matrix
            r14.<init>()
            android.graphics.Bitmap r8 = r1.m
            int r8 = r8.getWidth()
            int r8 = r8 / 2
            float r8 = (float) r8
            android.graphics.Bitmap r9 = r1.m
            int r9 = r9.getHeight()
            int r9 = r9 / 2
            float r9 = (float) r9
            r14.setRotate(r7, r8, r9)
            android.graphics.Bitmap r9 = r1.m
            int r12 = r9.getWidth()
            android.graphics.Bitmap r8 = r1.m
            int r13 = r8.getHeight()
            r15 = 1
            r10 = 0
            r11 = 0
            android.graphics.Bitmap r8 = android.graphics.Bitmap.createBitmap(r9, r10, r11, r12, r13, r14, r15)
            android.graphics.Bitmap r9 = r1.m
            if (r9 == r8) goto L_0x009f
            r9.recycle()
        L_0x009f:
            r1.m = r8
        L_0x00a1:
            float r8 = r5.left
            android.graphics.RectF r9 = r1.c
            float r10 = r9.left
            float r8 = r8 - r10
            float r10 = r1.n
            float r8 = r8 / r10
            int r8 = java.lang.Math.round(r8)
            r1.r = r8
            float r8 = r5.top
            float r10 = r9.top
            float r8 = r8 - r10
            float r10 = r1.n
            float r8 = r8 / r10
            int r8 = java.lang.Math.round(r8)
            r1.s = r8
            float r8 = r5.width()
            float r10 = r1.n
            float r8 = r8 / r10
            int r8 = java.lang.Math.round(r8)
            r1.p = r8
            float r8 = r5.height()
            float r10 = r1.n
            float r8 = r8 / r10
            int r8 = java.lang.Math.round(r8)
            r1.q = r8
            int r10 = r1.p
            int r8 = java.lang.Math.max(r10, r8)
            float r8 = (float) r8
            r10 = 1148846080(0x447a0000, float:1000.0)
            float r8 = r8 / r10
            int r8 = java.lang.Math.round(r8)
            int r8 = r8 + 1
            android.net.Uri r10 = r1.j
            android.net.Uri r11 = r1.k
            r12 = 0
            if (r3 <= 0) goto L_0x00f3
            if (r4 <= 0) goto L_0x00f3
            goto L_0x0130
        L_0x00f3:
            float r3 = r5.left
            float r4 = r9.left
            float r3 = r3 - r4
            float r3 = java.lang.Math.abs(r3)
            float r4 = (float) r8
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x0102
            goto L_0x0130
        L_0x0102:
            float r3 = r5.top
            float r8 = r9.top
            float r3 = r3 - r8
            float r3 = java.lang.Math.abs(r3)
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x0110
            goto L_0x0130
        L_0x0110:
            float r3 = r5.bottom
            float r8 = r9.bottom
            float r3 = r3 - r8
            float r3 = java.lang.Math.abs(r3)
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x011e
            goto L_0x0130
        L_0x011e:
            float r3 = r5.right
            float r5 = r9.right
            float r3 = r3 - r5
            float r3 = java.lang.Math.abs(r3)
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x012c
            goto L_0x0130
        L_0x012c:
            int r3 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1))
            if (r3 == 0) goto L_0x02dd
        L_0x0130:
            android.graphics.Bitmap r3 = r1.m
            int r4 = r1.r
            int r5 = r1.s
            int r6 = r1.p
            int r7 = r1.q
            android.graphics.Bitmap r3 = android.graphics.Bitmap.createBitmap(r3, r4, r5, r6, r7)
            java.lang.Object r0 = r0.get()
            android.content.Context r0 = (android.content.Context) r0
            android.graphics.Bitmap$CompressFormat r4 = r1.f
            if (r0 != 0) goto L_0x0149
            goto L_0x0181
        L_0x0149:
            android.content.ContentResolver r0 = r0.getContentResolver()     // Catch:{ IOException -> 0x0177, all -> 0x0174 }
            java.io.OutputStream r5 = r0.openOutputStream(r11)     // Catch:{ IOException -> 0x0177, all -> 0x0174 }
            java.io.ByteArrayOutputStream r6 = new java.io.ByteArrayOutputStream     // Catch:{ IOException -> 0x0172, all -> 0x016f }
            r6.<init>()     // Catch:{ IOException -> 0x0172, all -> 0x016f }
            int r0 = r1.g     // Catch:{ IOException -> 0x0165, all -> 0x016c }
            r3.compress(r4, r0, r6)     // Catch:{ IOException -> 0x0165, all -> 0x016c }
            byte[] r0 = r6.toByteArray()     // Catch:{ IOException -> 0x0165, all -> 0x016c }
            r5.write(r0)     // Catch:{ IOException -> 0x0165, all -> 0x016c }
            r3.recycle()     // Catch:{ IOException -> 0x0165, all -> 0x016c }
        L_0x0165:
            T7.a.a(r5)
            T7.a.a(r6)
            goto L_0x0181
        L_0x016c:
            r0 = move-exception
        L_0x016d:
            r12 = r5
            goto L_0x017a
        L_0x016f:
            r0 = move-exception
            r6 = r12
            goto L_0x016d
        L_0x0172:
            r6 = r12
            goto L_0x0165
        L_0x0174:
            r0 = move-exception
            r6 = r12
            goto L_0x017a
        L_0x0177:
            r5 = r12
            r6 = r5
            goto L_0x0165
        L_0x017a:
            T7.a.a(r12)
            T7.a.a(r6)
            throw r0
        L_0x0181:
            android.graphics.Bitmap$CompressFormat r0 = android.graphics.Bitmap.CompressFormat.JPEG
            boolean r0 = r4.equals(r0)
            if (r0 == 0) goto L_0x031d
            boolean r0 = T7.a.b(r10)
            boolean r3 = T7.a.b(r11)
            java.lang.String r4 = "rw"
            java.lang.String r5 = "ImageHeaderParser"
            if (r0 == 0) goto L_0x022c
            if (r3 == 0) goto L_0x022c
            int r0 = r1.p
            int r3 = r1.q
            byte[] r6 = T7.c.b
            android.content.ContentResolver r6 = r2.getContentResolver()     // Catch:{ IOException -> 0x01ec, all -> 0x01e8 }
            java.io.InputStream r6 = r6.openInputStream(r10)     // Catch:{ IOException -> 0x01ec, all -> 0x01e8 }
            androidx.exifinterface.media.ExifInterface r7 = new androidx.exifinterface.media.ExifInterface     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            r7.<init>(r6)     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            android.content.ContentResolver r2 = r2.getContentResolver()     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            android.os.ParcelFileDescriptor r12 = r2.openFileDescriptor(r11, r4)     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            androidx.exifinterface.media.ExifInterface r2 = new androidx.exifinterface.media.ExifInterface     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            java.io.FileDescriptor r4 = r12.getFileDescriptor()     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            r2.<init>(r4)     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            T7.c.a(r7, r2, r0, r3)     // Catch:{ IOException -> 0x01e4, all -> 0x01df }
            if (r6 == 0) goto L_0x01cf
            r6.close()     // Catch:{ IOException -> 0x01c6 }
            goto L_0x01cf
        L_0x01c6:
            r0 = move-exception
            r2 = r0
            java.lang.String r0 = r2.getMessage()
            android.util.Log.d(r5, r0)
        L_0x01cf:
            r12.close()     // Catch:{ IOException -> 0x01d4 }
            goto L_0x031d
        L_0x01d4:
            r0 = move-exception
            r2 = r0
            java.lang.String r0 = r2.getMessage()
            android.util.Log.d(r5, r0)
            goto L_0x031d
        L_0x01df:
            r0 = move-exception
            r3 = r0
            r2 = r12
            r12 = r6
            goto L_0x020d
        L_0x01e4:
            r0 = move-exception
            r2 = r12
            r12 = r6
            goto L_0x01ee
        L_0x01e8:
            r0 = move-exception
            r3 = r0
            r2 = r12
            goto L_0x020d
        L_0x01ec:
            r0 = move-exception
            r2 = r12
        L_0x01ee:
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x020b }
            android.util.Log.d(r5, r0)     // Catch:{ all -> 0x020b }
            if (r12 == 0) goto L_0x0204
            r12.close()     // Catch:{ IOException -> 0x01fb }
            goto L_0x0204
        L_0x01fb:
            r0 = move-exception
            r3 = r0
            java.lang.String r0 = r3.getMessage()
            android.util.Log.d(r5, r0)
        L_0x0204:
            if (r2 == 0) goto L_0x031d
            r2.close()     // Catch:{ IOException -> 0x01d4 }
            goto L_0x031d
        L_0x020b:
            r0 = move-exception
            r3 = r0
        L_0x020d:
            if (r12 == 0) goto L_0x021c
            r12.close()     // Catch:{ IOException -> 0x0213 }
            goto L_0x021c
        L_0x0213:
            r0 = move-exception
            r4 = r0
            java.lang.String r0 = r4.getMessage()
            android.util.Log.d(r5, r0)
        L_0x021c:
            if (r2 == 0) goto L_0x022b
            r2.close()     // Catch:{ IOException -> 0x0222 }
            goto L_0x022b
        L_0x0222:
            r0 = move-exception
            r2 = r0
            java.lang.String r0 = r2.getMessage()
            android.util.Log.d(r5, r0)
        L_0x022b:
            throw r3
        L_0x022c:
            java.lang.String r6 = r1.i
            if (r0 == 0) goto L_0x026b
            int r0 = r1.p
            int r3 = r1.q
            byte[] r4 = T7.c.b
            android.content.ContentResolver r2 = r2.getContentResolver()     // Catch:{ IOException -> 0x0252 }
            java.io.InputStream r2 = r2.openInputStream(r10)     // Catch:{ IOException -> 0x0252 }
            androidx.exifinterface.media.ExifInterface r4 = new androidx.exifinterface.media.ExifInterface     // Catch:{ all -> 0x0254 }
            r4.<init>(r2)     // Catch:{ all -> 0x0254 }
            androidx.exifinterface.media.ExifInterface r7 = new androidx.exifinterface.media.ExifInterface     // Catch:{ all -> 0x0254 }
            r7.<init>(r6)     // Catch:{ all -> 0x0254 }
            T7.c.a(r4, r7, r0, r3)     // Catch:{ all -> 0x0254 }
            if (r2 == 0) goto L_0x031d
            r2.close()     // Catch:{ IOException -> 0x0252 }
            goto L_0x031d
        L_0x0252:
            r0 = move-exception
            goto L_0x0262
        L_0x0254:
            r0 = move-exception
            r3 = r0
            if (r2 == 0) goto L_0x0261
            r2.close()     // Catch:{ all -> 0x025c }
            goto L_0x0261
        L_0x025c:
            r0 = move-exception
            r2 = r0
            r3.addSuppressed(r2)     // Catch:{ IOException -> 0x0252 }
        L_0x0261:
            throw r3     // Catch:{ IOException -> 0x0252 }
        L_0x0262:
            java.lang.String r0 = r0.getMessage()
            android.util.Log.d(r5, r0)
            goto L_0x031d
        L_0x026b:
            java.lang.String r0 = r1.h
            if (r3 == 0) goto L_0x02c0
            androidx.exifinterface.media.ExifInterface r3 = new androidx.exifinterface.media.ExifInterface
            r3.<init>(r0)
            int r0 = r1.p
            int r6 = r1.q
            byte[] r7 = T7.c.b
            android.content.ContentResolver r2 = r2.getContentResolver()     // Catch:{ IOException -> 0x02a1 }
            android.os.ParcelFileDescriptor r12 = r2.openFileDescriptor(r11, r4)     // Catch:{ IOException -> 0x02a1 }
            androidx.exifinterface.media.ExifInterface r2 = new androidx.exifinterface.media.ExifInterface     // Catch:{ IOException -> 0x02a1 }
            java.io.FileDescriptor r4 = r12.getFileDescriptor()     // Catch:{ IOException -> 0x02a1 }
            r2.<init>(r4)     // Catch:{ IOException -> 0x02a1 }
            T7.c.a(r3, r2, r0, r6)     // Catch:{ IOException -> 0x02a1 }
            r12.close()     // Catch:{ IOException -> 0x0293 }
            goto L_0x031d
        L_0x0293:
            r0 = move-exception
            r2 = r0
            java.lang.String r0 = r2.getMessage()
            android.util.Log.d(r5, r0)
            goto L_0x031d
        L_0x029e:
            r0 = move-exception
            r2 = r0
            goto L_0x02b0
        L_0x02a1:
            r0 = move-exception
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x029e }
            android.util.Log.d(r5, r0)     // Catch:{ all -> 0x029e }
            if (r12 == 0) goto L_0x031d
            r12.close()     // Catch:{ IOException -> 0x0293 }
            goto L_0x031d
        L_0x02b0:
            if (r12 == 0) goto L_0x02bf
            r12.close()     // Catch:{ IOException -> 0x02b6 }
            goto L_0x02bf
        L_0x02b6:
            r0 = move-exception
            r3 = r0
            java.lang.String r0 = r3.getMessage()
            android.util.Log.d(r5, r0)
        L_0x02bf:
            throw r2
        L_0x02c0:
            androidx.exifinterface.media.ExifInterface r2 = new androidx.exifinterface.media.ExifInterface
            r2.<init>(r0)
            int r0 = r1.p
            int r3 = r1.q
            byte[] r4 = T7.c.b
            androidx.exifinterface.media.ExifInterface r4 = new androidx.exifinterface.media.ExifInterface     // Catch:{ IOException -> 0x02d4 }
            r4.<init>(r6)     // Catch:{ IOException -> 0x02d4 }
            T7.c.a(r2, r4, r0, r3)     // Catch:{ IOException -> 0x02d4 }
            goto L_0x031d
        L_0x02d4:
            r0 = move-exception
            java.lang.String r0 = r0.getMessage()
            android.util.Log.d(r5, r0)
            goto L_0x031d
        L_0x02dd:
            boolean r0 = r10.equals(r11)
            if (r0 == 0) goto L_0x02e4
            goto L_0x031d
        L_0x02e4:
            android.content.ContentResolver r0 = r2.getContentResolver()     // Catch:{ all -> 0x032b }
            java.io.InputStream r3 = r0.openInputStream(r10)     // Catch:{ all -> 0x032b }
            android.content.ContentResolver r0 = r2.getContentResolver()     // Catch:{ all -> 0x031e }
            java.io.OutputStream r12 = r0.openOutputStream(r11)     // Catch:{ all -> 0x031e }
            boolean r0 = r3 instanceof java.io.FileInputStream     // Catch:{ all -> 0x031e }
            if (r0 == 0) goto L_0x0323
            boolean r0 = r12 instanceof java.io.FileOutputStream     // Catch:{ all -> 0x031e }
            if (r0 == 0) goto L_0x0323
            r0 = r3
            java.io.FileInputStream r0 = (java.io.FileInputStream) r0     // Catch:{ all -> 0x031e }
            java.nio.channels.FileChannel r4 = r0.getChannel()     // Catch:{ all -> 0x031e }
            r0 = r12
            java.io.FileOutputStream r0 = (java.io.FileOutputStream) r0     // Catch:{ all -> 0x031e }
            java.nio.channels.FileChannel r9 = r0.getChannel()     // Catch:{ all -> 0x031e }
            long r7 = r4.size()     // Catch:{ all -> 0x031e }
            r5 = 0
            r4.transferTo(r5, r7, r9)     // Catch:{ all -> 0x031e }
            if (r3 == 0) goto L_0x0318
            r3.close()
        L_0x0318:
            if (r12 == 0) goto L_0x031d
            r12.close()
        L_0x031d:
            return
        L_0x031e:
            r0 = move-exception
            r2 = r0
            r0 = r12
            r12 = r3
            goto L_0x032e
        L_0x0323:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x031e }
            java.lang.String r2 = "The input or output URI don't represent a file. uCrop requires then to represent files in order to work properly."
            r0.<init>(r2)     // Catch:{ all -> 0x031e }
            throw r0     // Catch:{ all -> 0x031e }
        L_0x032b:
            r0 = move-exception
            r2 = r0
            r0 = r12
        L_0x032e:
            if (r12 == 0) goto L_0x0333
            r12.close()
        L_0x0333:
            if (r0 == 0) goto L_0x0338
            r0.close()
        L_0x0338:
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: S7.a.a():void");
    }

    @Nullable
    public final Object doInBackground(Object[] objArr) {
        Void[] voidArr = (Void[]) objArr;
        Bitmap bitmap = this.m;
        if (bitmap == null) {
            return new NullPointerException("ViewBitmap is null");
        }
        if (bitmap.isRecycled()) {
            return new NullPointerException("ViewBitmap is recycled");
        }
        if (this.c.isEmpty()) {
            return new NullPointerException("CurrentImageRect is empty");
        }
        if (this.k == null) {
            return new NullPointerException("ImageOutputUri is null");
        }
        try {
            a();
            this.m = null;
            return null;
        } catch (Throwable th) {
            return th;
        }
    }

    public final void onPostExecute(@Nullable Object obj) {
        Throwable th = (Throwable) obj;
        Q7.a aVar = this.l;
        if (aVar == null) {
            return;
        }
        if (th == null) {
            Uri uri = this.k;
            if (!T7.a.b(uri)) {
                uri = Uri.fromFile(new File(this.i));
            }
            Uri uri2 = uri;
            this.l.a(uri2, this.r, this.s, this.p, this.q);
            return;
        }
        aVar.b(th);
    }
}
