package S7;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.payment.lib.image.crop.view.GestureCropImageView;
import com.huawei.payment.lib.image.crop.view.TransformView;
import java.lang.ref.WeakReference;

public final class b extends AsyncTask<Void, Void, a> {
    public final WeakReference<Context> a;
    public final int b;
    public final int c;
    public final com.huawei.payment.lib.image.crop.view.a d;
    public Uri e;
    public final Uri f;

    public b(@NonNull Context context, @NonNull Uri uri, @Nullable Uri uri2, int i, int i2, com.huawei.payment.lib.image.crop.view.a aVar) {
        this.a = new WeakReference<>(context);
        this.e = uri;
        this.f = uri2;
        this.b = i;
        this.c = i2;
        this.d = aVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:37:0x00b5  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a() throws java.lang.NullPointerException, java.io.IOException {
        /*
            r7 = this;
            android.net.Uri r0 = r7.e
            java.lang.String r0 = r0.getScheme()
            java.lang.String r1 = "http"
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x0034
            java.lang.String r1 = "https"
            boolean r1 = r1.equals(r0)
            if (r1 == 0) goto L_0x0017
            goto L_0x0034
        L_0x0017:
            java.lang.String r1 = "file"
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x009c
            java.lang.String r1 = "content"
            boolean r1 = r1.equals(r0)
            if (r1 == 0) goto L_0x0028
            goto L_0x009c
        L_0x0028:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "Invalid Uri scheme"
            java.lang.String r0 = V2.b.a(r2, r0)
            r1.<init>(r0)
            throw r1
        L_0x0034:
            android.net.Uri r0 = r7.e
            android.net.Uri r1 = r7.f
            if (r1 == 0) goto L_0x00ce
            java.lang.ref.WeakReference<android.content.Context> r2 = r7.a
            java.lang.Object r2 = r2.get()
            android.content.Context r2 = (android.content.Context) r2
            if (r2 == 0) goto L_0x00c6
            P7.l r3 = P7.l.b
            okhttp3.OkHttpClient r4 = r3.a
            if (r4 != 0) goto L_0x0051
            okhttp3.OkHttpClient r4 = new okhttp3.OkHttpClient
            r4.<init>()
            r3.a = r4
        L_0x0051:
            okhttp3.OkHttpClient r3 = r3.a
            r4 = 0
            okhttp3.Request$Builder r5 = new okhttp3.Request$Builder     // Catch:{ all -> 0x00aa }
            r5.<init>()     // Catch:{ all -> 0x00aa }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x00aa }
            okhttp3.Request$Builder r0 = r5.url(r0)     // Catch:{ all -> 0x00aa }
            okhttp3.Request r0 = r0.build()     // Catch:{ all -> 0x00aa }
            okhttp3.Call r0 = r3.newCall(r0)     // Catch:{ all -> 0x00aa }
            okhttp3.Response r0 = r0.execute()     // Catch:{ all -> 0x00aa }
            okhttp3.ResponseBody r5 = r0.body()     // Catch:{ all -> 0x00a7 }
            okio.BufferedSource r5 = r5.source()     // Catch:{ all -> 0x00a7 }
            android.content.ContentResolver r2 = r2.getContentResolver()     // Catch:{ all -> 0x009d }
            java.io.OutputStream r2 = r2.openOutputStream(r1)     // Catch:{ all -> 0x009d }
            if (r2 == 0) goto L_0x009f
            okio.Sink r4 = okio.Okio.sink(r2)     // Catch:{ all -> 0x009d }
            r5.readAll(r4)     // Catch:{ all -> 0x009d }
            T7.a.a(r4)
            T7.a.a(r5)
            okhttp3.ResponseBody r0 = r0.body()
            T7.a.a(r0)
            okhttp3.Dispatcher r0 = r3.dispatcher()
            r0.cancelAll()
            r7.e = r1
        L_0x009c:
            return
        L_0x009d:
            r2 = move-exception
            goto L_0x00ad
        L_0x009f:
            java.lang.NullPointerException r2 = new java.lang.NullPointerException     // Catch:{ all -> 0x009d }
            java.lang.String r6 = "OutputStream is null"
            r2.<init>(r6)     // Catch:{ all -> 0x009d }
            throw r2     // Catch:{ all -> 0x009d }
        L_0x00a7:
            r2 = move-exception
            r5 = r4
            goto L_0x00ad
        L_0x00aa:
            r2 = move-exception
            r0 = r4
            r5 = r0
        L_0x00ad:
            T7.a.a(r4)
            T7.a.a(r5)
            if (r0 == 0) goto L_0x00bc
            okhttp3.ResponseBody r0 = r0.body()
            T7.a.a(r0)
        L_0x00bc:
            okhttp3.Dispatcher r0 = r3.dispatcher()
            r0.cancelAll()
            r7.e = r1
            throw r2
        L_0x00c6:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Context is null - cannot download image"
            r0.<init>(r1)
            throw r0
        L_0x00ce:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Output Uri is null - cannot download image"
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: S7.b.a():void");
    }

    /* JADX WARNING: type inference failed for: r0v5, types: [java.lang.Object, R7.b] */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x0138  */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x013b  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x013e  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x015e  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x0164  */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x0170  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x018d  */
    @androidx.annotation.NonNull
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object doInBackground(java.lang.Object[] r15) {
        /*
            r14 = this;
            java.lang.Void[] r15 = (java.lang.Void[]) r15
            java.lang.ref.WeakReference<android.content.Context> r15 = r14.a
            java.lang.Object r15 = r15.get()
            android.content.Context r15 = (android.content.Context) r15
            if (r15 != 0) goto L_0x001a
            S7.b$a r15 = new S7.b$a
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "context is null"
            r0.<init>(r1)
            r15.<init>(r0)
            goto L_0x01a3
        L_0x001a:
            android.net.Uri r0 = r14.e
            if (r0 != 0) goto L_0x002c
            S7.b$a r15 = new S7.b$a
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Input Uri cannot be null"
            r0.<init>(r1)
            r15.<init>(r0)
            goto L_0x01a3
        L_0x002c:
            r14.a()     // Catch:{ Exception -> 0x019b }
            android.graphics.BitmapFactory$Options r0 = new android.graphics.BitmapFactory$Options
            r0.<init>()
            r1 = 1
            r0.inJustDecodeBounds = r1
            int r2 = r0.outHeight
            int r3 = r0.outWidth
            int r4 = r14.b
            int r5 = r14.c
            if (r2 > r5) goto L_0x0046
            if (r3 <= r4) goto L_0x0044
            goto L_0x0046
        L_0x0044:
            r6 = 1
            goto L_0x0051
        L_0x0046:
            r6 = 1
        L_0x0047:
            int r7 = r2 / r6
            if (r7 > r5) goto L_0x0197
            int r7 = r3 / r6
            if (r7 <= r4) goto L_0x0051
            goto L_0x0197
        L_0x0051:
            r0.inSampleSize = r6
            r2 = 0
            r0.inJustDecodeBounds = r2
            r3 = 0
            r12 = r3
            r4 = 0
        L_0x0059:
            r5 = 2
            java.lang.String r6 = "Bitmap could not be decoded from the Uri: ["
            java.lang.String r7 = "]"
            r8 = -1
            if (r4 != 0) goto L_0x00e9
            android.content.ContentResolver r9 = r15.getContentResolver()     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            android.net.Uri r10 = r14.e     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            java.io.InputStream r9 = r9.openInputStream(r10)     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            android.graphics.Bitmap r12 = android.graphics.BitmapFactory.decodeStream(r9, r3, r0)     // Catch:{ all -> 0x0097 }
            int r10 = r0.outWidth     // Catch:{ all -> 0x0097 }
            if (r10 == r8) goto L_0x0099
            int r10 = r0.outHeight     // Catch:{ all -> 0x0097 }
            if (r10 != r8) goto L_0x0078
            goto L_0x0099
        L_0x0078:
            T7.a.a(r9)     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            if (r12 == 0) goto L_0x0082
            int r8 = r12.getByteCount()     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            goto L_0x0083
        L_0x0082:
            r8 = 0
        L_0x0083:
            r9 = 104857600(0x6400000, float:3.6111186E-35)
            if (r8 <= r9) goto L_0x008f
            int r8 = r0.inSampleSize     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            int r8 = r8 * 2
            r0.inSampleSize = r8     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            r5 = 1
            goto L_0x0090
        L_0x008f:
            r5 = 0
        L_0x0090:
            if (r5 == 0) goto L_0x0093
            goto L_0x0059
        L_0x0093:
            r4 = 1
            goto L_0x0059
        L_0x0095:
            r15 = move-exception
            goto L_0x00c3
        L_0x0097:
            r8 = move-exception
            goto L_0x00bf
        L_0x0099:
            S7.b$a r8 = new S7.b$a     // Catch:{ all -> 0x0097 }
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0097 }
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ all -> 0x0097 }
            r11.<init>()     // Catch:{ all -> 0x0097 }
            java.lang.String r13 = "Bounds for bitmap could not be retrieved from the Uri: ["
            r11.append(r13)     // Catch:{ all -> 0x0097 }
            android.net.Uri r13 = r14.e     // Catch:{ all -> 0x0097 }
            r11.append(r13)     // Catch:{ all -> 0x0097 }
            r11.append(r7)     // Catch:{ all -> 0x0097 }
            java.lang.String r11 = r11.toString()     // Catch:{ all -> 0x0097 }
            r10.<init>(r11)     // Catch:{ all -> 0x0097 }
            r8.<init>(r10)     // Catch:{ all -> 0x0097 }
            T7.a.a(r9)     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            r15 = r8
            goto L_0x01a3
        L_0x00bf:
            T7.a.a(r9)     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
            throw r8     // Catch:{ OutOfMemoryError -> 0x00e1, IOException -> 0x0095 }
        L_0x00c3:
            S7.b$a r0 = new S7.b$a
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>(r6)
            android.net.Uri r3 = r14.e
            r2.append(r3)
            r2.append(r7)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2, r15)
            r0.<init>(r1)
        L_0x00de:
            r15 = r0
            goto L_0x01a3
        L_0x00e1:
            int r6 = r0.inSampleSize
            int r6 = r6 * 2
            r0.inSampleSize = r6
            goto L_0x0059
        L_0x00e9:
            if (r12 != 0) goto L_0x0108
            S7.b$a r15 = new S7.b$a
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r6)
            android.net.Uri r2 = r14.e
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            r15.<init>(r0)
            goto L_0x01a3
        L_0x0108:
            android.net.Uri r0 = r14.e
            android.content.ContentResolver r15 = r15.getContentResolver()     // Catch:{ IOException -> 0x0129 }
            java.io.InputStream r3 = r15.openInputStream(r0)     // Catch:{ IOException -> 0x0129 }
            if (r3 != 0) goto L_0x0119
        L_0x0114:
            T7.a.a(r3)
            r15 = 0
            goto L_0x0134
        L_0x0119:
            T7.c r15 = new T7.c     // Catch:{ IOException -> 0x0129 }
            r15.<init>(r3)     // Catch:{ IOException -> 0x0129 }
            int r15 = r15.b()     // Catch:{ IOException -> 0x0129 }
            T7.a.a(r3)
            goto L_0x0134
        L_0x0126:
            r15 = move-exception
            goto L_0x0193
        L_0x0129:
            r15 = move-exception
            java.lang.String r0 = "BitmapLoadUtils"
            java.lang.String r15 = r15.getMessage()     // Catch:{ all -> 0x0126 }
            android.util.Log.d(r0, r15)     // Catch:{ all -> 0x0126 }
            goto L_0x0114
        L_0x0134:
            switch(r15) {
                case 3: goto L_0x013e;
                case 4: goto L_0x013e;
                case 5: goto L_0x013b;
                case 6: goto L_0x013b;
                case 7: goto L_0x0138;
                case 8: goto L_0x0138;
                default: goto L_0x0137;
            }
        L_0x0137:
            goto L_0x0140
        L_0x0138:
            r2 = 270(0x10e, float:3.78E-43)
            goto L_0x0140
        L_0x013b:
            r2 = 90
            goto L_0x0140
        L_0x013e:
            r2 = 180(0xb4, float:2.52E-43)
        L_0x0140:
            if (r15 == r5) goto L_0x014c
            r0 = 7
            if (r15 == r0) goto L_0x014c
            r0 = 4
            if (r15 == r0) goto L_0x014c
            r0 = 5
            if (r15 == r0) goto L_0x014c
            r8 = 1
        L_0x014c:
            R7.b r0 = new R7.b
            r0.<init>()
            r0.a = r15
            r0.b = r2
            r0.c = r8
            android.graphics.Matrix r10 = new android.graphics.Matrix
            r10.<init>()
            if (r2 == 0) goto L_0x0162
            float r15 = (float) r2
            r10.preRotate(r15)
        L_0x0162:
            if (r8 == r1) goto L_0x016a
            float r15 = (float) r8
            r1 = 1065353216(0x3f800000, float:1.0)
            r10.postScale(r15, r1)
        L_0x016a:
            boolean r15 = r10.isIdentity()
            if (r15 != 0) goto L_0x018d
            S7.b$a r15 = new S7.b$a
            int r8 = r12.getWidth()     // Catch:{ OutOfMemoryError -> 0x0189 }
            int r9 = r12.getHeight()     // Catch:{ OutOfMemoryError -> 0x0189 }
            r11 = 1
            r6 = 0
            r7 = 0
            r5 = r12
            android.graphics.Bitmap r1 = android.graphics.Bitmap.createBitmap(r5, r6, r7, r8, r9, r10, r11)     // Catch:{ OutOfMemoryError -> 0x0189 }
            boolean r2 = r12.sameAs(r1)     // Catch:{ OutOfMemoryError -> 0x0189 }
            if (r2 != 0) goto L_0x0189
            r12 = r1
        L_0x0189:
            r15.<init>(r12, r0)
            goto L_0x01a3
        L_0x018d:
            S7.b$a r15 = new S7.b$a
            r15.<init>(r12, r0)
            goto L_0x01a3
        L_0x0193:
            T7.a.a(r3)
            throw r15
        L_0x0197:
            int r6 = r6 * 2
            goto L_0x0047
        L_0x019b:
            r15 = move-exception
            S7.b$a r0 = new S7.b$a
            r0.<init>(r15)
            goto L_0x00de
        L_0x01a3:
            return r15
        */
        throw new UnsupportedOperationException("Method not decompiled: S7.b.doInBackground(java.lang.Object[]):java.lang.Object");
    }

    public final void onPostExecute(@NonNull Object obj) {
        String str;
        a aVar = (a) obj;
        Exception exc = aVar.c;
        com.huawei.payment.lib.image.crop.view.a aVar2 = this.d;
        if (exc == null) {
            Uri uri = this.e;
            GestureCropImageView gestureCropImageView = aVar2.a;
            gestureCropImageView.o = uri;
            Uri uri2 = this.f;
            gestureCropImageView.p = uri2;
            gestureCropImageView.m = uri.getPath();
            if (uri2 != null) {
                str = uri2.getPath();
            } else {
                str = null;
            }
            gestureCropImageView.n = str;
            gestureCropImageView.q = aVar.b;
            gestureCropImageView.h = true;
            gestureCropImageView.setImageBitmap(aVar.a);
            return;
        }
        TransformView.a aVar3 = aVar2.a.g;
        if (aVar3 != null) {
            aVar3.c(exc);
        }
    }

    public static class a {
        public final Bitmap a;
        public final R7.b b;
        public final Exception c;

        public a(@NonNull Bitmap bitmap, @NonNull R7.b bVar) {
            this.a = bitmap;
            this.b = bVar;
        }

        public a(@NonNull Exception exc) {
            this.c = exc;
        }
    }
}
