package Z7;

import V1.h;
import V1.k;
import W2.a;
import W2.r;
import Yb.c;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import androidx.fragment.app.FragmentManager;
import com.blankj.utilcode.util.C;
import com.huawei.module_push.R$id;
import com.huawei.module_push.R$string;
import com.huawei.module_push.databinding.CommonFilterDateBinding;
import com.huawei.push.notification.NotificationRecordsActivity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public final class d extends PopupWindow implements View.OnClickListener {
    public View a;
    public CommonFilterDateBinding b;
    public NotificationRecordsActivity c;
    public e d;
    public FragmentManager e;
    public int f;

    public final void dismiss() {
        super.dismiss();
        View view = this.a;
        if (view != null && view.getParent() != null) {
            ((ViewGroup) this.a.getParent()).removeView(this.a);
        }
    }

    /* JADX WARNING: type inference failed for: r8v4, types: [com.huawei.push.notification.NotificationRecordsActivity, android.content.Context] */
    public final void onClick(View view) {
        int i = this.f;
        view.getId();
        h.b();
        int id = view.getId();
        if (id == R$id.ll_content) {
            dismiss();
        } else if (id == R$id.btn_ok && !a.a(1500, view)) {
            e eVar = this.d;
            String a2 = C.a("yyyy-MM-dd", eVar.a.getTime());
            Boolean bool = Boolean.TRUE;
            String f2 = L3.a.f(a2, bool);
            String f3 = L3.a.f(C.a("yyyy-MM-dd", eVar.b.getTime()), bool);
            if (r.b(f2).longValue() > r.b(f3).longValue()) {
                k.a(R$string.history_the_start_time_must_be_less_than_the_end_time);
                return;
            }
            String a3 = C.a("yyyy-MM-dd HH:mm", eVar.a.getTime());
            String a4 = C.a("yyyy-MM-dd HH:mm", eVar.b.getTime());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            try {
                Date parse = simpleDateFormat.parse(a3);
                Date parse2 = simpleDateFormat.parse(a4);
                Calendar instance = Calendar.getInstance();
                instance.setTime(parse2);
                instance.add(5, i * -1);
                if (parse.getTime() < instance.getTimeInMillis()) {
                    k.b(1, this.c.getString(R$string.query_time_rang_cannot_excees_30_days, new Object[]{Integer.valueOf(i)}));
                    return;
                }
                c.b().e(eVar);
                dismiss();
            } catch (ParseException e2) {
                e2.getMessage();
                h.b();
            }
        }
    }
}
