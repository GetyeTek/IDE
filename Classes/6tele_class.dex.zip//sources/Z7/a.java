package Z7;

import android.os.Bundle;
import android.view.View;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.dialog.ScheduleDatePickerDialog;
import com.huawei.digitalpayment.customer.homev6.R;
import com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomePopularServicesBinding;
import com.huawei.digitalpayment.customer.homev6.fragment.MyFragment;
import com.huawei.digitalpayment.customer.login_module.upgrade.UpgradeActivity;
import com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity;
import com.huawei.requestmoney.RequestMoneyConfirmActivity;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;
import o0.b;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                d dVar = (d) obj;
                if (!W2.a.a(1500, view)) {
                    Locale.setDefault(dVar.c.getResources().getConfiguration().locale);
                    ScheduleDatePickerDialog scheduleDatePickerDialog = new ScheduleDatePickerDialog((Calendar) null, Calendar.getInstance(), dVar.d.a);
                    scheduleDatePickerDialog.m = new b(dVar, scheduleDatePickerDialog);
                    scheduleDatePickerDialog.show(dVar.e, "");
                    return;
                }
                return;
            case 1:
                int i = UpgradeActivity.L;
                ((UpgradeActivity) obj).c1();
                return;
            case 2:
                int i2 = P2PTransferPayActivity.r;
                ((P2PTransferPayActivity) obj).c1();
                return;
            case 3:
                int i3 = RequestMoneyConfirmActivity.h;
                b.e((RequestMoneyConfirmActivity) obj, "/requestMoneyModule/requestMoneyInputPin", (Bundle) null, (Map) null, 0, 1);
                return;
            case 4:
                ((Homev6HomePopularServicesBinding) obj).e.performClick();
                return;
            default:
                MyFragment myFragment = (MyFragment) obj;
                w5.a.a("My_Log_out_V1");
                String string = myFragment.getString(R.string.homev5_do_you_confirm_to_log_out);
                String string2 = myFragment.getString(R.string.designstandard_cancel);
                String string3 = myFragment.getString(R.string.login_ok);
                com.huawei.common.widget.banner.b bVar = new com.huawei.common.widget.banner.b(myFragment, 7);
                BaseDialog baseDialog = new BaseDialog();
                baseDialog.g = null;
                baseDialog.h = string;
                baseDialog.i = string2;
                baseDialog.j = string3;
                baseDialog.k = null;
                baseDialog.l = bVar;
                baseDialog.show(myFragment.getChildFragmentManager(), "tipsDialog");
                return;
        }
    }
}
