package Z7;

import java.util.Calendar;

public final class e {
    public Calendar a;
    public Calendar b;

    public e(Calendar calendar, Calendar calendar2) {
        this.a = calendar;
        this.b = calendar2;
    }
}
