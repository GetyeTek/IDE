package Z7;

import L3.a;
import V1.k;
import W2.r;
import android.os.Bundle;
import android.view.View;
import com.blankj.utilcode.util.C;
import com.huawei.digitalpayment.customer.baselib.dialog.ScheduleDatePickerDialog;
import com.huawei.module_push.R$string;
import com.huawei.requestmoney.RequestMoneyDetailActivity;
import com.huawei.requestmoney.bean.RequestMoneyResp;
import com.huawei.requestmoney.s;
import java.util.Calendar;
import java.util.Map;
import o0.b;
import r4.f;

public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;
    public final /* synthetic */ Object c;

    public /* synthetic */ c(int i, Object obj, Object obj2) {
        this.a = i;
        this.b = obj;
        this.c = obj2;
    }

    public final void onClick(View view) {
        Object obj = this.c;
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                d dVar = (d) obj2;
                ScheduleDatePickerDialog scheduleDatePickerDialog = (ScheduleDatePickerDialog) obj;
                scheduleDatePickerDialog.dismiss();
                Calendar x0 = scheduleDatePickerDialog.x0();
                e eVar = dVar.d;
                String a2 = C.a("yyyy-MM-dd", eVar.a.getTime());
                Boolean bool = Boolean.TRUE;
                String f = a.f(a2, bool);
                String f2 = a.f(C.a("yyyy-MM-dd", x0.getTime()), bool);
                if (r.b(f).longValue() > r.b(f2).longValue()) {
                    k.a(R$string.history_the_start_time_must_be_less_than_the_end_time);
                    return;
                }
                eVar.b = x0;
                dVar.b.b.setText(C.a("dd/MM/yyyy", x0.getTime()));
                return;
            default:
                int i = RequestMoneyDetailActivity.i;
                RequestMoneyDetailActivity requestMoneyDetailActivity = (RequestMoneyDetailActivity) obj2;
                if (!"1000".equals(((RequestMoneyResp.RequestMoneyOrderInfoBean) obj).getPayeeIdentityType())) {
                    f.b.a(requestMoneyDetailActivity, new s(requestMoneyDetailActivity));
                    return;
                } else if (requestMoneyDetailActivity.h != null) {
                    Bundle bundle = new Bundle(1);
                    bundle.putSerializable("requestMoneyResp", requestMoneyDetailActivity.h);
                    b.e(requestMoneyDetailActivity, "/requestMoneyModule/requestMoneyPartialPayment", bundle, (Map) null, 0, 1);
                    return;
                } else {
                    return;
                }
        }
    }
}
