package Z7;

import android.view.View;
import com.blankj.utilcode.util.C;
import com.huawei.digitalpayment.customer.baselib.dialog.ScheduleDatePickerDialog;
import java.util.Calendar;

public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ d a;
    public final /* synthetic */ ScheduleDatePickerDialog b;

    public /* synthetic */ b(d dVar, ScheduleDatePickerDialog scheduleDatePickerDialog) {
        this.a = dVar;
        this.b = scheduleDatePickerDialog;
    }

    public final void onClick(View view) {
        d dVar = this.a;
        dVar.getClass();
        ScheduleDatePickerDialog scheduleDatePickerDialog = this.b;
        scheduleDatePickerDialog.dismiss();
        Calendar x0 = scheduleDatePickerDialog.x0();
        dVar.d.a = x0;
        dVar.b.c.setText(C.a("dd/MM/yyyy", x0.getTime()));
    }
}
