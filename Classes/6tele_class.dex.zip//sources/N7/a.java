package N7;

import Ga.e;
import Ga.h;
import Ga.i;
import Ia.l;
import Ya.d;
import ab.c;
import ab.f;
import java.math.BigInteger;
import la.u;
import org.bouncycastle.util.g;
import pa.b;

public final class a {
    public static String a(f fVar, d dVar) {
        c cVar = dVar.a;
        char[] cArr = org.bouncycastle.util.d.a;
        int i = 0;
        byte[] h = fVar.h(false);
        if (cVar != null) {
            byte[] e = org.bouncycastle.util.a.e(h, cVar.b.e(), cVar.c.e(), dVar.c.h(false));
            if (160 % 8 == 0) {
                l lVar = new l(256);
                lVar.d(0, e.length, e);
                int i2 = 160 / 8;
                byte[] bArr = new byte[i2];
                lVar.e(0, i2, bArr);
                StringBuffer stringBuffer = new StringBuffer();
                while (i != bArr.length) {
                    if (i > 0) {
                        stringBuffer.append(":");
                    }
                    stringBuffer.append(cArr[(bArr[i] >>> 4) & 15]);
                    stringBuffer.append(cArr[bArr[i] & 15]);
                    i++;
                }
                return stringBuffer.toString();
            }
            throw new IllegalArgumentException("bitLength must be a multiple of 8");
        } else if (160 % 8 == 0) {
            l lVar2 = new l(256);
            lVar2.d(0, h.length, h);
            int i3 = 160 / 8;
            byte[] bArr2 = new byte[i3];
            lVar2.e(0, i3, bArr2);
            StringBuffer stringBuffer2 = new StringBuffer();
            while (i != bArr2.length) {
                if (i > 0) {
                    stringBuffer2.append(":");
                }
                stringBuffer2.append(cArr[(bArr2[i] >>> 4) & 15]);
                stringBuffer2.append(cArr[bArr2[i] & 15]);
                i++;
            }
            return stringBuffer2.toString();
        } else {
            throw new IllegalArgumentException("bitLength must be a multiple of 8");
        }
    }

    public static String b(u uVar) {
        String str = (String) e.c.get(uVar);
        if (str == null) {
            str = (String) Aa.c.c.get(uVar);
        }
        if (str == null) {
            str = (String) wa.a.b.get(uVar);
        }
        if (str == null) {
            str = (String) Ba.a.c.get(uVar);
        }
        if (str == null) {
            str = (String) ma.a.c.get(uVar);
        }
        if (str == null) {
            str = b.e(uVar);
        }
        if (str == null) {
            str = (String) ra.a.c.get(uVar);
        }
        if (str == null) {
            return (String) Ja.a.d.get(uVar);
        }
        return str;
    }

    public static La.l c(Ra.a aVar, d dVar) {
        if (!(dVar instanceof Ya.b)) {
            return new La.l(dVar.a, dVar.c, dVar.d, dVar.e, dVar.b);
        }
        Ya.b bVar = (Ya.b) dVar;
        u e = e(bVar.f);
        La.l lVar = new La.l(bVar.a, bVar.c, bVar.d, bVar.e, bVar.b);
        lVar.k = e;
        return lVar;
    }

    public static h d(u uVar) {
        h hVar;
        h hVar2;
        i iVar = (i) Ja.a.c.get(uVar);
        h hVar3 = null;
        if (iVar == null) {
            hVar = null;
        } else {
            hVar = iVar.d();
        }
        if (hVar != null) {
            return hVar;
        }
        i iVar2 = (i) e.b.get(uVar);
        if (iVar2 == null) {
            hVar2 = null;
        } else {
            hVar2 = iVar2.d();
        }
        if (hVar2 == null) {
            i iVar3 = (i) Aa.c.b.get(uVar);
            if (iVar3 == null) {
                hVar2 = null;
            } else {
                hVar2 = iVar3.d();
            }
        }
        if (hVar2 == null) {
            i iVar4 = (i) Ba.a.b.get(uVar);
            if (iVar4 == null) {
                hVar2 = null;
            } else {
                hVar2 = iVar4.d();
            }
        }
        if (hVar2 == null) {
            i iVar5 = (i) ma.a.b.get(uVar);
            if (iVar5 == null) {
                hVar2 = null;
            } else {
                hVar2 = iVar5.d();
            }
        }
        if (hVar2 == null) {
            hVar2 = b.d(uVar);
        }
        if (hVar2 != null) {
            return hVar2;
        }
        i iVar6 = (i) ra.a.b.get(uVar);
        if (iVar6 != null) {
            hVar3 = iVar6.d();
        }
        return hVar3;
    }

    public static u e(String str) {
        u uVar = null;
        if (str == null || str.length() < 1) {
            return null;
        }
        int indexOf = str.indexOf(32);
        if (indexOf > 0) {
            str = str.substring(indexOf + 1);
        }
        char charAt = str.charAt(0);
        if (charAt >= '0' && charAt <= '2') {
            try {
                uVar = new u(str);
            } catch (Exception unused) {
            }
        }
        if (uVar != null) {
            return uVar;
        }
        u uVar2 = (u) e.a.get(g.c(str));
        if (uVar2 == null) {
            uVar2 = (u) Aa.c.a.get(g.c(str));
        }
        if (uVar2 == null) {
            uVar2 = wa.a.b(str);
        }
        if (uVar2 == null) {
            uVar2 = (u) Ba.a.a.get(g.c(str));
        }
        if (uVar2 == null) {
            uVar2 = (u) ma.a.a.get(g.c(str));
        }
        if (uVar2 == null) {
            uVar2 = b.f(str);
        }
        if (uVar2 == null) {
            uVar2 = (u) ra.a.a.get(g.c(str));
        }
        if (uVar2 != null || !str.equals("curve25519")) {
            return uVar2;
        }
        return oa.a.a;
    }

    public static int f(Ra.a aVar, BigInteger bigInteger, BigInteger bigInteger2) {
        if (bigInteger != null) {
            return bigInteger.bitLength();
        }
        d a = ((org.bouncycastle.jce.provider.a) aVar).a();
        if (a == null) {
            return bigInteger2.bitLength();
        }
        return a.d.bitLength();
    }

    public static void g(long[] jArr, long[] jArr2) {
        long j = jArr[0];
        long j2 = jArr[1];
        long j3 = jArr[2];
        long j4 = jArr[3];
        long j5 = jArr[4];
        long j6 = jArr[5];
        long j7 = jArr[6];
        jArr2[0] = j & 576460752303423487L;
        jArr2[1] = ((j >>> 59) ^ (j2 << 5)) & 576460752303423487L;
        jArr2[2] = ((j2 >>> 54) ^ (j3 << 10)) & 576460752303423487L;
        jArr2[3] = ((j3 >>> 49) ^ (j4 << 15)) & 576460752303423487L;
        jArr2[4] = ((j4 >>> 44) ^ (j5 << 20)) & 576460752303423487L;
        jArr2[5] = ((j5 >>> 39) ^ (j6 << 25)) & 576460752303423487L;
        jArr2[6] = (j6 >>> 34) ^ (j7 << 30);
    }

    public static void h(long[] jArr, long[] jArr2, long[] jArr3) {
        long[] jArr4 = new long[7];
        long[] jArr5 = new long[7];
        g(jArr, jArr4);
        g(jArr2, jArr5);
        long[] jArr6 = new long[8];
        for (int i = 0; i < 7; i++) {
            i(jArr6, jArr4[i], jArr5[i], jArr3, i << 1);
        }
        long j = jArr3[0];
        long j2 = jArr3[1];
        long j3 = jArr3[2] ^ j;
        long j4 = j3 ^ j2;
        jArr3[1] = j4;
        long j5 = j2 ^ jArr3[3];
        long j6 = j3 ^ jArr3[4];
        long j7 = j6 ^ j5;
        jArr3[2] = j7;
        long j9 = j5 ^ jArr3[5];
        long j10 = j6 ^ jArr3[6];
        long j11 = j10 ^ j9;
        jArr3[3] = j11;
        long j12 = j9 ^ jArr3[7];
        long j13 = j10 ^ jArr3[8];
        long j14 = j13 ^ j12;
        jArr3[4] = j14;
        long j15 = j12 ^ jArr3[9];
        long j16 = j13 ^ jArr3[10];
        long j17 = j16 ^ j15;
        jArr3[5] = j17;
        long j18 = j15 ^ jArr3[11];
        long j19 = j16 ^ jArr3[12];
        long j20 = j19 ^ j18;
        jArr3[6] = j20;
        long j21 = (j18 ^ jArr3[13]) ^ j19;
        jArr3[7] = j ^ j21;
        jArr3[8] = j4 ^ j21;
        jArr3[9] = j7 ^ j21;
        jArr3[10] = j11 ^ j21;
        jArr3[11] = j14 ^ j21;
        jArr3[12] = j17 ^ j21;
        jArr3[13] = j20 ^ j21;
        i(jArr6, jArr4[0] ^ jArr4[1], jArr5[0] ^ jArr5[1], jArr3, 1);
        i(jArr6, jArr4[0] ^ jArr4[2], jArr5[0] ^ jArr5[2], jArr3, 2);
        i(jArr6, jArr4[0] ^ jArr4[3], jArr5[0] ^ jArr5[3], jArr3, 3);
        i(jArr6, jArr4[1] ^ jArr4[2], jArr5[1] ^ jArr5[2], jArr3, 3);
        i(jArr6, jArr4[0] ^ jArr4[4], jArr5[0] ^ jArr5[4], jArr3, 4);
        i(jArr6, jArr4[1] ^ jArr4[3], jArr5[1] ^ jArr5[3], jArr3, 4);
        i(jArr6, jArr4[0] ^ jArr4[5], jArr5[0] ^ jArr5[5], jArr3, 5);
        i(jArr6, jArr4[1] ^ jArr4[4], jArr5[1] ^ jArr5[4], jArr3, 5);
        i(jArr6, jArr4[2] ^ jArr4[3], jArr5[2] ^ jArr5[3], jArr3, 5);
        i(jArr6, jArr4[0] ^ jArr4[6], jArr5[0] ^ jArr5[6], jArr3, 6);
        i(jArr6, jArr4[1] ^ jArr4[5], jArr5[1] ^ jArr5[5], jArr3, 6);
        i(jArr6, jArr4[2] ^ jArr4[4], jArr5[2] ^ jArr5[4], jArr3, 6);
        i(jArr6, jArr4[1] ^ jArr4[6], jArr5[1] ^ jArr5[6], jArr3, 7);
        i(jArr6, jArr4[2] ^ jArr4[5], jArr5[2] ^ jArr5[5], jArr3, 7);
        i(jArr6, jArr4[3] ^ jArr4[4], jArr5[3] ^ jArr5[4], jArr3, 7);
        i(jArr6, jArr4[2] ^ jArr4[6], jArr5[2] ^ jArr5[6], jArr3, 8);
        i(jArr6, jArr4[3] ^ jArr4[5], jArr5[3] ^ jArr5[5], jArr3, 8);
        i(jArr6, jArr4[3] ^ jArr4[6], jArr5[3] ^ jArr5[6], jArr3, 9);
        i(jArr6, jArr4[4] ^ jArr4[5], jArr5[4] ^ jArr5[5], jArr3, 9);
        long[] jArr7 = jArr3;
        i(jArr6, jArr4[4] ^ jArr4[6], jArr5[4] ^ jArr5[6], jArr7, 10);
        i(jArr6, jArr4[5] ^ jArr4[6], jArr5[5] ^ jArr5[6], jArr7, 11);
        long j22 = jArr3[0];
        long j23 = jArr3[1];
        long j24 = jArr3[2];
        long j25 = jArr3[3];
        long j26 = jArr3[4];
        long j27 = jArr3[5];
        long j28 = jArr3[6];
        long j29 = jArr3[7];
        long j30 = jArr3[8];
        long j31 = jArr3[9];
        long j32 = jArr3[10];
        long j33 = jArr3[11];
        long j34 = jArr3[12];
        long j35 = jArr3[13];
        jArr3[0] = j22 ^ (j23 << 59);
        jArr3[1] = (j23 >>> 5) ^ (j24 << 54);
        jArr3[2] = (j24 >>> 10) ^ (j25 << 49);
        jArr3[3] = (j25 >>> 15) ^ (j26 << 44);
        jArr3[4] = (j26 >>> 20) ^ (j27 << 39);
        jArr3[5] = (j27 >>> 25) ^ (j28 << 34);
        jArr3[6] = (j28 >>> 30) ^ (j29 << 29);
        jArr3[7] = (j29 >>> 35) ^ (j30 << 24);
        jArr3[8] = (j30 >>> 40) ^ (j31 << 19);
        jArr3[9] = (j31 >>> 45) ^ (j32 << 14);
        jArr3[10] = (j32 >>> 50) ^ (j33 << 9);
        jArr3[11] = ((j33 >>> 55) ^ (j34 << 4)) ^ (j35 << 63);
        jArr3[12] = j35 >>> 1;
    }

    public static void i(long[] jArr, long j, long j2, long[] jArr2, int i) {
        long j3 = j;
        jArr[1] = j2;
        long j4 = j2 << 1;
        jArr[2] = j4;
        long j5 = j4 ^ j2;
        jArr[3] = j5;
        long j6 = j2 << 2;
        jArr[4] = j6;
        jArr[5] = j6 ^ j2;
        long j7 = j5 << 1;
        jArr[6] = j7;
        jArr[7] = j7 ^ j2;
        int i2 = (int) j3;
        long j9 = (jArr[(i2 >>> 3) & 7] << 3) ^ jArr[i2 & 7];
        long j10 = 0;
        int i3 = 54;
        do {
            int i4 = (int) (j3 >>> i3);
            long j11 = (jArr[(i4 >>> 3) & 7] << 3) ^ jArr[i4 & 7];
            j9 ^= j11 << i3;
            j10 ^= j11 >>> (-i3);
            i3 -= 6;
        } while (i3 > 0);
        jArr2[i] = jArr2[i] ^ (576460752303423487L & j9);
        int i5 = i + 1;
        jArr2[i5] = jArr2[i5] ^ ((j9 >>> 59) ^ (j10 << 5));
    }

    public static void j(long[] jArr, long[] jArr2) {
        B2.a.d(6, jArr, jArr2);
        jArr2[12] = B2.a.c((int) jArr[6]);
    }

    public static String k(String str) {
        if (str.length() < 3) {
            return "";
        }
        return "******" + str.substring(str.length() - 3);
    }

    public static void l(long[] jArr, long[] jArr2, long[] jArr3) {
        long[] jArr4 = new long[14];
        h(jArr, jArr2, jArr4);
        o(jArr4, jArr3);
    }

    public static String m(String str, BigInteger bigInteger, d dVar) {
        StringBuffer stringBuffer = new StringBuffer();
        String str2 = g.a;
        f o = ab.h.a(dVar.c, bigInteger).o();
        stringBuffer.append(str);
        stringBuffer.append(" Private Key [");
        stringBuffer.append(a(o, dVar));
        stringBuffer.append("]");
        stringBuffer.append(str2);
        stringBuffer.append("            X: ");
        o.b();
        stringBuffer.append(o.b.t().toString(16));
        stringBuffer.append(str2);
        stringBuffer.append("            Y: ");
        stringBuffer.append(o.e().t().toString(16));
        stringBuffer.append(str2);
        return stringBuffer.toString();
    }

    public static String n(String str, f fVar, d dVar) {
        StringBuffer stringBuffer = new StringBuffer();
        String str2 = g.a;
        stringBuffer.append(str);
        stringBuffer.append(" Public Key [");
        stringBuffer.append(a(fVar, dVar));
        stringBuffer.append("]");
        stringBuffer.append(str2);
        stringBuffer.append("            X: ");
        fVar.b();
        stringBuffer.append(fVar.b.t().toString(16));
        stringBuffer.append(str2);
        stringBuffer.append("            Y: ");
        stringBuffer.append(fVar.e().t().toString(16));
        stringBuffer.append(str2);
        return stringBuffer.toString();
    }

    public static void o(long[] jArr, long[] jArr2) {
        long j = jArr[0];
        long j2 = jArr[1];
        long j3 = jArr[2];
        long j4 = jArr[3];
        long j5 = jArr[4];
        long j6 = jArr[5];
        long j7 = jArr[6];
        long j9 = jArr[7];
        long j10 = jArr[12];
        long j11 = j7 ^ ((j10 >>> 25) ^ (j10 << 62));
        long j12 = j9 ^ (j10 >>> 2);
        long j13 = jArr[11];
        long j14 = j5 ^ (j13 << 39);
        long j15 = (j6 ^ (j10 << 39)) ^ ((j13 >>> 25) ^ (j13 << 62));
        long j16 = j11 ^ (j13 >>> 2);
        long j17 = jArr[10];
        long j18 = j4 ^ (j17 << 39);
        long j19 = j14 ^ ((j17 >>> 25) ^ (j17 << 62));
        long j20 = j15 ^ (j17 >>> 2);
        long j21 = jArr[9];
        long j22 = j3 ^ (j21 << 39);
        long j23 = j18 ^ ((j21 >>> 25) ^ (j21 << 62));
        long j24 = j19 ^ (j21 >>> 2);
        long j25 = jArr[8];
        long j26 = j ^ (j12 << 39);
        long j27 = (j22 ^ ((j25 >>> 25) ^ (j25 << 62))) ^ (j12 >>> 2);
        long j28 = j16 >>> 25;
        jArr2[0] = j26 ^ j28;
        long j29 = j28 << 23;
        jArr2[1] = j29 ^ ((j2 ^ (j25 << 39)) ^ ((j12 >>> 25) ^ (j12 << 62)));
        jArr2[2] = j27;
        jArr2[3] = j23 ^ (j25 >>> 2);
        jArr2[4] = j24;
        jArr2[5] = j20;
        jArr2[6] = j16 & 33554431;
    }

    public static void p(int i, long[] jArr, long[] jArr2) {
        long[] jArr3 = new long[13];
        j(jArr, jArr3);
        while (true) {
            o(jArr3, jArr2);
            i--;
            if (i > 0) {
                j(jArr2, jArr3);
            } else {
                return;
            }
        }
    }
}
