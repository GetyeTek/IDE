package com.huawei.pwamodule.payment;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutTransparentBinding;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.request.H5CheckoutRequest;
import com.huawei.digitalpayment.customer.httplib.response.ConfigVerifyResp;
import e8.a;
import e8.b;
import f8.a;
import i8.d;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import k3.c;

@Route(path = "/consumer/pwapay")
public class PwaDispatcherActivity extends BaseMvpActivity<d> {
    @Autowired(name = "pawParams")
    H5CheckoutRequest pawParams;
    @Autowired(name = "uri")
    String uri;

    public final void D0() {
    }

    public final void G(String str) {
    }

    /* JADX WARNING: type inference failed for: r1v12, types: [e8.d, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v13, types: [e8.e, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v15, types: [e8.g, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v16, types: [e8.f, java.lang.Object] */
    public final void G0() {
        PwaDispatcherActivity.super.G0();
        f.g(getWindow());
        ArrayList arrayList = a.C0001a.a.a;
        if (arrayList.isEmpty()) {
            ? obj = new Object();
            obj.a = this;
            arrayList.add(obj);
            ? obj2 = new Object();
            obj2.a = this;
            arrayList.add(obj2);
            arrayList.add(new Object());
            ? obj3 = new Object();
            obj3.a = this;
            arrayList.add(obj3);
            ? obj4 = new Object();
            obj4.a = this;
            arrayList.add(obj4);
        } else {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                ((b) it.next()).d(this);
            }
        }
        Intent intent = getIntent();
        if (intent != null) {
            Uri data = intent.getData();
            if (data == null) {
                try {
                    data = Uri.parse(this.uri.replace("#", ""));
                } catch (Exception unused) {
                }
            }
            if (data == null) {
                finish();
            } else if ("telebirrcustomerapp".equals(data.getScheme())) {
                ConfigVerifyResp configVerifyResp = BasicConfig.getInstance().getConfigVerifyResp();
                if (!c.c.b()) {
                    a.C0002a.a.a(data.getHost(), getIntent());
                    if (configVerifyResp != null) {
                        o0.b.d((Activity) null, "/loginModule/login", (Bundle) null, (Map) null);
                    } else {
                        o0.b.d((Activity) null, "/basicUiModule/launcher", (Bundle) null, (Map) null);
                    }
                    finish();
                } else if (configVerifyResp != null) {
                    a.C0001a.a.a(data);
                    finish();
                } else {
                    a.C0002a.a.a(data.getHost(), getIntent());
                    o0.b.d((Activity) null, "/basicUiModule/launcher", (Bundle) null, (Map) null);
                    finish();
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    public final ViewBinding K0() {
        return LayoutTransparentBinding.a(getLayoutInflater());
    }

    public final boolean M0() {
        return true;
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
    }
}
