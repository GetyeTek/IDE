package com.huawei.pwamodule.payment;

import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutTransparentBinding;
import com.huawei.digitalpayment.customer.httplib.response.GetH5AccessTokenResp;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;
import i8.c;
import j8.a;
import java.util.HashMap;
import java.util.Locale;
import o0.b;

@Route(path = "/pwaModule/mandateGetToken")
public class GetAccessTokenActivity extends BaseTitleActivity implements c {
    public PayLoadingDialog i;
    public HashMap<String, String> j;
    @Autowired(name = "appId")
    String mAppId;
    @Autowired(name = "url")
    String mUrl;
    @Autowired(name = "scheme_execute_key")
    String urlString;

    /* JADX WARNING: type inference failed for: r2v4, types: [x9.k, java.lang.Object] */
    public final void D0() {
        Uri uri;
        if (TextUtils.isEmpty(this.urlString)) {
            finish();
            return;
        }
        try {
            uri = Uri.parse(this.urlString);
        } catch (Exception unused) {
            uri = null;
        }
        if (uri != null) {
            String scheme = uri.getScheme();
            if (!TextUtils.isEmpty(scheme)) {
                String lowerCase = scheme.toLowerCase(Locale.ENGLISH);
                this.j = a.b(uri);
                lowerCase.getClass();
                if (!lowerCase.equals("native")) {
                    finish();
                } else if (!TextUtils.isEmpty(this.mAppId)) {
                    A8.c cVar = new A8.c(this);
                    cVar.a(H3.c.e().r0(com.google.android.gms.ads.identifier.a.a("appId", this.mAppId)).b(new Object()), new i8.a(cVar, (P2.a) cVar.a));
                }
            }
        }
    }

    public final void G(String str) {
        this.i.dismiss();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.pwamodule.payment.GetAccessTokenActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity] */
    public final void G0() {
        GetAccessTokenActivity.super.G0();
        f.g(getWindow());
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.pwamodule.payment.GetAccessTokenActivity, android.app.Activity] */
    public final ViewBinding K0() {
        return LayoutTransparentBinding.a(getLayoutInflater());
    }

    public final boolean M0() {
        return true;
    }

    public final void V(String str) {
        PayLoadingDialog payLoadingDialog = new PayLoadingDialog();
        this.i = payLoadingDialog;
        payLoadingDialog.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.pwamodule.payment.GetAccessTokenActivity, android.app.Activity] */
    public final void g(GetH5AccessTokenResp getH5AccessTokenResp) {
        if (getH5AccessTokenResp == null) {
            finish();
            return;
        }
        String accessToken = getH5AccessTokenResp.getAccessToken();
        String tradeType = getH5AccessTokenResp.getTradeType();
        String appId = getH5AccessTokenResp.getAppId();
        String url = getH5AccessTokenResp.getUrl();
        if (TextUtils.isEmpty(accessToken)) {
            finish();
            return;
        }
        if (this.j == null) {
            this.j = new HashMap<>();
        }
        if (TextUtils.isEmpty(url)) {
            url = this.mUrl;
        }
        if (!TextUtils.isEmpty(url)) {
            this.j.put("tradeType", tradeType);
            this.j.put("token", accessToken);
            this.j.put("appId", appId);
            b.d(this, url, (Bundle) null, this.j);
            finish();
            return;
        }
        throw new RuntimeException("url is empty, please config h5 url on portal");
    }
}
