package com.huawei.pwamodule.payment.service;

import android.content.Context;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.ethiopia.component.service.PwaService;
import e8.a;
import e8.b;
import fa.z;
import java.util.Iterator;

@Route(path = "/pwa/PwaService")
public class PwaServiceIml implements PwaService {
    public final void h(String str) {
        z zVar = new z();
        zVar.b = str;
        a aVar = a.C0001a.a;
        aVar.getClass();
        Iterator it = aVar.a.iterator();
        while (it.hasNext()) {
            b bVar = (b) it.next();
            if (bVar.c().equalsIgnoreCase("mandate")) {
                bVar.a(zVar);
            }
        }
    }

    public final void init(Context context) {
    }
}
