package com.huawei.pwamodule.payment;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class GetAccessTokenActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.pwamodule.payment.GetAccessTokenActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (GetAccessTokenActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.mUrl;
        } else {
            str = r4.getIntent().getExtras().getString("url", r4.mUrl);
        }
        r4.mUrl = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.mAppId;
        } else {
            str2 = r4.getIntent().getExtras().getString("appId", r4.mAppId);
        }
        r4.mAppId = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.urlString;
        } else {
            str3 = r4.getIntent().getExtras().getString("scheme_execute_key", r4.urlString);
        }
        r4.urlString = str3;
    }
}
