package com.huawei.pwamodule.payment;

import android.util.Log;
import com.alibaba.android.arouter.facade.model.TypeWrapper;
import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import com.huawei.digitalpayment.customer.httplib.request.H5CheckoutRequest;

public class PwaDispatcherActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    public class a extends TypeWrapper<H5CheckoutRequest> {
    }

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        SerializationService c = e.c(SerializationService.class);
        this.serializationService = c;
        ? r4 = (PwaDispatcherActivity) obj;
        if (c != null) {
            r4.pawParams = (H5CheckoutRequest) c.parseObject(r4.getIntent().getStringExtra("pawParams"), new TypeWrapper().getType());
        } else {
            Log.e("ARouter::", "You want automatic inject the field 'pawParams' in class 'PwaDispatcherActivity' , then you should implement 'SerializationService' to support object auto inject!");
        }
        if (r4.getIntent().getExtras() == null) {
            str = r4.uri;
        } else {
            str = r4.getIntent().getExtras().getString("uri", r4.uri);
        }
        r4.uri = str;
    }
}
