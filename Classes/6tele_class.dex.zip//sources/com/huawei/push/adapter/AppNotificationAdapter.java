package com.huawei.push.adapter;

import V9.a;
import android.text.TextUtils;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.bumptech.glide.c;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.module.BaseLoadMoreModule;
import com.chad.library.adapter.base.module.LoadMoreModule;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import com.huawei.module_push.R$id;

public class AppNotificationAdapter extends BaseQuickAdapter<NotificationMessageBean, BaseViewHolder> implements LoadMoreModule {
    public static final /* synthetic */ int a = 0;

    public AppNotificationAdapter() {
        throw null;
    }

    @NonNull
    public final BaseLoadMoreModule addLoadMoreModule(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter) {
        return new BaseLoadMoreModule(baseQuickAdapter);
    }

    public final void convert(BaseViewHolder baseViewHolder, Object obj) {
        NotificationMessageBean notificationMessageBean = (NotificationMessageBean) obj;
        baseViewHolder.setVisible(R$id.view_mast, !notificationMessageBean.isRead());
        baseViewHolder.setText(R$id.tv_time, a.b(notificationMessageBean.getTimestamp()));
        baseViewHolder.setText(R$id.tv_title, notificationMessageBean.getTitle());
        baseViewHolder.setText(R$id.tv_content, notificationMessageBean.getContent());
        ImageView imageView = (ImageView) baseViewHolder.getView(R$id.img_notify);
        ConstraintLayout view = baseViewHolder.getView(R$id.ll_more);
        if (!TextUtils.isEmpty(notificationMessageBean.getCardExecute())) {
            view.setVisibility(0);
        } else {
            view.setVisibility(8);
        }
        baseViewHolder.itemView.setOnClickListener(new W7.a(this, notificationMessageBean, baseViewHolder));
        if (!TextUtils.isEmpty(notificationMessageBean.getImgUrl())) {
            imageView.setVisibility(0);
            c.i(imageView).load(notificationMessageBean.getImgUrl()).into(imageView);
            return;
        }
        imageView.setVisibility(8);
    }
}
