package com.huawei.push.adapter;

import O9.c;
import V1.h;
import V9.a;
import W7.b;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.blankj.utilcode.util.k;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.module.BaseLoadMoreModule;
import com.chad.library.adapter.base.module.LoadMoreModule;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import com.huawei.module_push.R$id;
import com.huawei.module_push.R$mipmap;
import java.util.ArrayList;
import java.util.List;

public class TransNotificationAdapter extends BaseQuickAdapter<NotificationMessageBean, BaseViewHolder> implements LoadMoreModule {
    public static final /* synthetic */ int a = 0;

    public TransNotificationAdapter() {
        throw null;
    }

    @NonNull
    public final BaseLoadMoreModule addLoadMoreModule(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter) {
        return new BaseLoadMoreModule(baseQuickAdapter);
    }

    public final void convert(BaseViewHolder baseViewHolder, Object obj) {
        String str;
        NotificationMessageBean notificationMessageBean = (NotificationMessageBean) obj;
        baseViewHolder.setVisible(R$id.view_mast, !notificationMessageBean.isRead());
        baseViewHolder.setText(R$id.tv_title, notificationMessageBean.getCardTitle());
        baseViewHolder.setText(R$id.tv_amount, notificationMessageBean.getCardContent());
        String cardShowFields = notificationMessageBean.getCardShowFields();
        List arrayList = new ArrayList();
        try {
            arrayList = (List) k.b(cardShowFields, new TypeToken().getType());
        } catch (JsonSyntaxException e) {
            e.getMessage();
            h.b();
        }
        StringBuilder sb = new StringBuilder();
        if (arrayList != null) {
            for (int i = 0; i < arrayList.size(); i++) {
                if (i == 0) {
                    str = "";
                } else {
                    str = System.lineSeparator();
                }
                sb.append(str);
                NotificationMessageBean.FieldItem fieldItem = (NotificationMessageBean.FieldItem) arrayList.get(i);
                if (fieldItem.getType() != null && fieldItem.getType().equals("timestamp")) {
                    fieldItem.setValue(a.b(fieldItem.getValue()));
                }
                sb.append(fieldItem.getKey());
                sb.append(":");
                sb.append(fieldItem.getValue());
            }
            baseViewHolder.setText(R$id.transaction_object, sb.toString());
            c.c((ImageView) baseViewHolder.getView(R$id.iv_status), notificationMessageBean.getCardIcon(), R$mipmap.icon_notification_success);
            baseViewHolder.itemView.setOnClickListener(new b(this, notificationMessageBean, baseViewHolder));
        }
    }
}
