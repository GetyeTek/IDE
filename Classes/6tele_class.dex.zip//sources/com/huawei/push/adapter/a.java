package com.huawei.push.adapter;

import com.google.gson.reflect.TypeToken;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import java.util.List;

class a extends TypeToken<List<NotificationMessageBean.FieldItem>> {
}
