package com.huawei.push;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class NotificationFilterActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.push.NotificationFilterActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (NotificationFilterActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.execute;
        } else {
            str = r4.getIntent().getExtras().getString("execute", r4.execute);
        }
        r4.execute = str;
    }
}
