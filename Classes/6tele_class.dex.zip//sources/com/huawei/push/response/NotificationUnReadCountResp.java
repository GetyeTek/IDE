package com.huawei.push.response;

import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public class NotificationUnReadCountResp extends BaseResp {
    private int driverMessageCount;
    private int ecommerceMessageCount;
    private int promotionNotificationCount;
    private int systemNotificationCount;
    private int transferNotificationCount;

    public int getCommerceMessageCount() {
        return this.ecommerceMessageCount;
    }

    public int getDriverMessageCount() {
        return this.driverMessageCount;
    }

    public int getEcommerceMessageCount() {
        return this.ecommerceMessageCount;
    }

    public int getPromotionNotificationCount() {
        return this.promotionNotificationCount;
    }

    public int getSystemNotificationCount() {
        return this.systemNotificationCount;
    }

    public int getTransferNotificationCount() {
        return this.transferNotificationCount;
    }

    public void setCommerceMessageCount(int i) {
        this.ecommerceMessageCount = i;
    }

    public void setDriverMessageCount(int i) {
        this.driverMessageCount = i;
    }

    public void setEcommerceMessageCount(int i) {
        this.ecommerceMessageCount = i;
    }

    public void setPromotionNotificationCount(int i) {
        this.promotionNotificationCount = i;
    }

    public void setSystemNotificationCount(int i) {
        this.systemNotificationCount = i;
    }

    public void setTransferNotificationCount(int i) {
        this.transferNotificationCount = i;
    }
}
