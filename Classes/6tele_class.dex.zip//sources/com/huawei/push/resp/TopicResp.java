package com.huawei.push.resp;

import com.huawei.http.BaseResp;
import java.util.List;

public class TopicResp extends BaseResp {
    private List<String> topics;

    public List<String> getTopics() {
        return this.topics;
    }

    public void setTopics(List<String> list) {
        this.topics = list;
    }
}
