package com.huawei.push.viewmodel;

import a8.c;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;

public class NotificationViewModel extends BaseViewModel {
    public final c g = new c();
    public final MutableLiveData<Void> h = new MutableLiveData<>();
    public final MutableLiveData<Void> i = new MutableLiveData<>();
}
