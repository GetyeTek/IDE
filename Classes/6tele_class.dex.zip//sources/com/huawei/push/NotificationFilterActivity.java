package com.huawei.push;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.module_push.R$layout;
import com.huawei.module_push.databinding.ActivityNotificationEmptyBinding;
import java.util.Map;
import o0.b;

@Route(path = "/pushModule/notificationFilter")
public class NotificationFilterActivity extends BaseActivity {
    public static final /* synthetic */ int d = 0;
    @Autowired
    String execute;

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.push.NotificationFilterActivity, android.app.Activity] */
    public final ViewBinding C0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_notification_empty, (ViewGroup) null, false);
        if (inflate != null) {
            return new ActivityNotificationEmptyBinding(inflate);
        }
        throw new NullPointerException("rootView");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.push.NotificationFilterActivity, android.app.Activity] */
    public final void D0() {
        Intent intent = getIntent();
        if (intent != null) {
            String stringExtra = intent.getStringExtra("execute");
            Uri parse = Uri.parse(stringExtra);
            if (TextUtils.isEmpty(stringExtra) || parse == null || parse.getScheme() == null) {
                finish();
                return;
            }
            b.d(this, parse.toString(), (Bundle) null, (Map) null);
        }
        finish();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.push.NotificationFilterActivity, android.app.Activity] */
    public final void G0() {
        f.g(getWindow());
    }
}
