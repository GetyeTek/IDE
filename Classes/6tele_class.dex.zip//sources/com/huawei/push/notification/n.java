package com.huawei.push.notification;

import A8.c;
import L2.b;
import android.text.TextUtils;
import com.huawei.digitalpayment.customer.httplib.request.AppNotificationRequest;
import com.huawei.digitalpayment.customer.httplib.response.AppNotificationResp;
import java.util.ArrayList;

public final class n extends c {

    public class a extends b<AppNotificationResp> {
        public a(P2.a aVar, boolean z) {
            super(aVar, z);
        }

        public final void b(String str) {
            ((P2.a) n.this.a).j(new ArrayList());
        }

        public final void c(Object obj) {
            AppNotificationResp appNotificationResp = (AppNotificationResp) obj;
            ArrayList arrayList = new ArrayList();
            if (!(appNotificationResp == null || appNotificationResp.getRecords() == null)) {
                for (AppNotificationResp.RecordsBean data : appNotificationResp.getRecords()) {
                    arrayList.add(data.getData());
                }
            }
            ((P2.a) n.this.a).j(arrayList);
        }
    }

    public final void b(String str, String str2, String str3, int i, boolean z) {
        AppNotificationRequest appNotificationRequest;
        if (TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            appNotificationRequest = new AppNotificationRequest(str, i, 10);
        } else {
            appNotificationRequest = new AppNotificationRequest(str, i, 10, str2, str3);
        }
        a(H3.c.e().k0(appNotificationRequest), new a((P2.a) this.a, !z));
    }
}
