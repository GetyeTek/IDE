package com.huawei.push.notification;

import P2.a;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import java.util.ArrayList;
import java.util.List;

public interface p extends a {
    void a(List<NotificationMessageBean> list);

    void j(ArrayList arrayList);
}
