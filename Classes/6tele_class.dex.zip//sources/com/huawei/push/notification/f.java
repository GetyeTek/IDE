package com.huawei.push.notification;

import W2.n;
import androidx.lifecycle.Observer;

public final /* synthetic */ class f implements Observer {
    public final /* synthetic */ NotificationRecordsActivity a;

    public /* synthetic */ f(NotificationRecordsActivity notificationRecordsActivity) {
        this.a = notificationRecordsActivity;
    }

    public final void onChanged(Object obj) {
        String str;
        Void voidR = (Void) obj;
        NotificationRecordsActivity notificationRecordsActivity = this.a;
        if ("0".equals(notificationRecordsActivity.pushType)) {
            str = "systemNotificationCount";
        } else if ("1".equals(notificationRecordsActivity.pushType)) {
            str = "transactionNotificationCount";
        } else if ("3".equals(notificationRecordsActivity.pushType)) {
            str = "eCommerceMessageCount";
        } else if ("4".equals(notificationRecordsActivity.pushType)) {
            str = "driverMessageCount";
        } else {
            str = "promotionNotificationCount";
        }
        n.b("sp_name_push").f(n.b("sp_name_push").a.getInt(str, 0) - 1, str);
    }
}
