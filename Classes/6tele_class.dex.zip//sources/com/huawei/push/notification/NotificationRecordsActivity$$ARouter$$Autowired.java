package com.huawei.push.notification;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class NotificationRecordsActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.push.notification.NotificationRecordsActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (NotificationRecordsActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.pushType;
        } else {
            str = r4.getIntent().getExtras().getString("pushType", r4.pushType);
        }
        r4.pushType = str;
    }
}
