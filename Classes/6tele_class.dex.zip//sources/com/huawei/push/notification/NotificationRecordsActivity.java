package com.huawei.push.notification;

import A8.c;
import D4.b;
import Yb.j;
import Z7.a;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.C;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.loadmore.BaseLoadMoreView;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import com.huawei.digitalpayment.customer.httplib.request.TopicNotificationRequest;
import com.huawei.module_push.R$id;
import com.huawei.module_push.R$layout;
import com.huawei.module_push.R$style;
import com.huawei.module_push.databinding.ActivityNotificationRecordsBinding;
import com.huawei.module_push.databinding.CommonFilterDateBinding;
import com.huawei.push.viewmodel.NotificationViewModel;
import h9.e;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.greenrobot.eventbus.ThreadMode;

@Route(path = "/pushModule/notificationRecord")
public class NotificationRecordsActivity extends BaseMvpActivity<n> implements p, e {
    public static final /* synthetic */ int s = 0;
    public ActivityNotificationRecordsBinding j;
    public int k = 0;
    public ArrayList l;
    public BaseQuickAdapter m;
    public boolean n = false;
    public NotificationViewModel o;
    public boolean p = true;
    @Autowired
    String pushType;
    public boolean q = false;
    public Z7.e r;

    /* JADX WARNING: type inference failed for: r1v0, types: [android.view.View$OnClickListener, android.widget.PopupWindow, Z7.d, java.lang.Object] */
    public static void V0(NotificationRecordsActivity notificationRecordsActivity) {
        NotificationRecordsActivity notificationRecordsActivity2 = notificationRecordsActivity;
        Z7.e eVar = notificationRecordsActivity2.r;
        Calendar calendar = eVar.a;
        Calendar calendar2 = eVar.b;
        FragmentManager supportFragmentManager = notificationRecordsActivity.getSupportFragmentManager();
        ? popupWindow = new PopupWindow(-1, -2);
        int parseColor = Color.parseColor("#88000000");
        popupWindow.f = 30;
        popupWindow.e = supportFragmentManager;
        popupWindow.c = notificationRecordsActivity2;
        int intValue = Integer.valueOf((String) BasicConfig.getInstance().getReferenceData().get("notificationQueryRange")).intValue();
        popupWindow.f = intValue;
        popupWindow.setAnimationStyle(R$style.BottomAnimation);
        popupWindow.setOutsideTouchable(false);
        View inflate = LayoutInflater.from(notificationRecordsActivity).inflate(R$layout.common_filter_date, (ViewGroup) null, false);
        int i = R$id.btn_ok;
        RoundTextView findChildViewById = ViewBindings.findChildViewById(inflate, i);
        if (findChildViewById != null) {
            i = R$id.cl_date_picker;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(inflate, i);
            if (linearLayout != null) {
                i = R$id.end_time_string;
                TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
                if (textView != null) {
                    i = R$id.from_time_string;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(inflate, i);
                    if (textView2 != null) {
                        i = R$id.line;
                        if (ViewBindings.findChildViewById(inflate, i) != null) {
                            LinearLayout linearLayout2 = (LinearLayout) inflate;
                            TextView textView3 = textView2;
                            TextView textView4 = textView;
                            LinearLayout linearLayout3 = linearLayout;
                            popupWindow.b = new CommonFilterDateBinding(linearLayout2, findChildViewById, linearLayout, textView4, textView3, linearLayout2);
                            if (calendar == null) {
                                calendar = Calendar.getInstance();
                                calendar.setTime(new Date());
                                calendar.add(5, intValue * -1);
                            }
                            if (calendar2 == null) {
                                calendar2 = Calendar.getInstance();
                            }
                            Z7.e eVar2 = new Z7.e(calendar, calendar2);
                            popupWindow.d = eVar2;
                            linearLayout2.setOnClickListener(new b(popupWindow, 1));
                            TextView textView5 = textView3;
                            textView5.setText(C.a("dd/MM/yyyy", eVar2.a.getTime()));
                            linearLayout3.setOnClickListener((View.OnClickListener) null);
                            findChildViewById.setOnClickListener(popupWindow);
                            textView5.setOnClickListener(new a(popupWindow, 0));
                            TextView textView6 = textView4;
                            textView6.setText(C.a("dd/MM/yyyy", eVar2.b.getTime()));
                            textView6.setOnClickListener(new Y1.a(popupWindow, 1));
                            popupWindow.setContentView(linearLayout2);
                            if (!popupWindow.isShowing()) {
                                popupWindow.showAtLocation((ViewGroup) notificationRecordsActivity2.findViewById(16908290), 80, 0, 0);
                                ViewGroup viewGroup = (ViewGroup) notificationRecordsActivity2.findViewById(16908290);
                                View findViewWithTag = viewGroup.findViewWithTag("maskView");
                                popupWindow.a = findViewWithTag;
                                if (findViewWithTag == null) {
                                    View view = new View(viewGroup.getContext());
                                    popupWindow.a = view;
                                    view.setTag("maskView");
                                    popupWindow.a.setBackgroundColor(parseColor);
                                    popupWindow.a.setOnClickListener(new V6.b(popupWindow, 2));
                                    viewGroup.addView(popupWindow.a, new ViewGroup.LayoutParams(-1, -1));
                                    return;
                                }
                                return;
                            }
                            return;
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final void D0() {
        X0("0".equals(this.pushType));
    }

    public final void G(String str) {
        DialogManager.b(getSupportFragmentManager());
        this.j.i.i();
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [androidx.activity.ComponentActivity, com.huawei.push.notification.NotificationRecordsActivity, android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, androidx.lifecycle.LifecycleOwner, h9.e, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, androidx.lifecycle.ViewModelStoreOwner] */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x009d, code lost:
        if (r11.equals("4") == false) goto L_0x0097;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x004c, code lost:
        if (r9.equals("4") == false) goto L_0x0046;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void G0() {
        /*
            r13 = this;
            r0 = 3
            java.lang.String r1 = "4"
            r2 = 2
            java.lang.String r3 = "3"
            r4 = 1
            java.lang.String r5 = "2"
            java.lang.String r6 = "1"
            r7 = -1
            r8 = 0
            com.huawei.push.notification.NotificationRecordsActivity.super.G0()
            androidx.lifecycle.ViewModelProvider r9 = new androidx.lifecycle.ViewModelProvider
            r9.<init>(r13)
            java.lang.Class<com.huawei.push.viewmodel.NotificationViewModel> r10 = com.huawei.push.viewmodel.NotificationViewModel.class
            androidx.lifecycle.ViewModel r9 = r9.get(r10)
            com.huawei.push.viewmodel.NotificationViewModel r9 = (com.huawei.push.viewmodel.NotificationViewModel) r9
            r13.o = r9
            Z7.e r9 = new Z7.e
            r10 = 0
            r9.<init>(r10, r10)
            r13.r = r9
            androidx.lifecycle.Lifecycle r9 = r13.getLifecycle()
            com.huawei.push.viewmodel.NotificationViewModel r10 = r13.o
            r9.addObserver(r10)
            java.lang.String r9 = r13.pushType
            java.lang.String r10 = "0"
            boolean r9 = r10.equals(r9)
            if (r9 == 0) goto L_0x007e
            java.lang.String r9 = r13.pushType
            r9.getClass()
            int r11 = r9.hashCode()
            switch(r11) {
                case 49: goto L_0x0061;
                case 50: goto L_0x0058;
                case 51: goto L_0x004f;
                case 52: goto L_0x0048;
                default: goto L_0x0046;
            }
        L_0x0046:
            r0 = -1
            goto L_0x0069
        L_0x0048:
            boolean r1 = r9.equals(r1)
            if (r1 != 0) goto L_0x0069
            goto L_0x0046
        L_0x004f:
            boolean r0 = r9.equals(r3)
            if (r0 != 0) goto L_0x0056
            goto L_0x0046
        L_0x0056:
            r0 = 2
            goto L_0x0069
        L_0x0058:
            boolean r0 = r9.equals(r5)
            if (r0 != 0) goto L_0x005f
            goto L_0x0046
        L_0x005f:
            r0 = 1
            goto L_0x0069
        L_0x0061:
            boolean r0 = r9.equals(r6)
            if (r0 != 0) goto L_0x0068
            goto L_0x0046
        L_0x0068:
            r0 = 0
        L_0x0069:
            switch(r0) {
                case 0: goto L_0x0078;
                case 1: goto L_0x0075;
                case 2: goto L_0x0072;
                case 3: goto L_0x006f;
                default: goto L_0x006c;
            }
        L_0x006c:
            int r0 = com.huawei.module_push.R$string.designstandard_system_information
            goto L_0x007a
        L_0x006f:
            int r0 = com.huawei.module_push.R$string.app_driver_message
            goto L_0x007a
        L_0x0072:
            int r0 = com.huawei.module_push.R$string.app_commerce_message
            goto L_0x007a
        L_0x0075:
            int r0 = com.huawei.module_push.R$string.designstandard_promotion_news
            goto L_0x007a
        L_0x0078:
            int r0 = com.huawei.module_push.R$string.designstandard_transaction_message
        L_0x007a:
            r13.O0(r0)
            goto L_0x00dc
        L_0x007e:
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r9 = r13.j
            android.widget.LinearLayout r9 = r9.f
            r9.setVisibility(r8)
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r9 = r13.j
            com.huawei.module_push.databinding.NotificationTitleBarBinding r9 = r9.g
            android.widget.TextView r9 = r9.d
            java.lang.String r11 = r13.pushType
            r11.getClass()
            int r12 = r11.hashCode()
            switch(r12) {
                case 49: goto L_0x00b2;
                case 50: goto L_0x00a9;
                case 51: goto L_0x00a0;
                case 52: goto L_0x0099;
                default: goto L_0x0097;
            }
        L_0x0097:
            r0 = -1
            goto L_0x00ba
        L_0x0099:
            boolean r1 = r11.equals(r1)
            if (r1 != 0) goto L_0x00ba
            goto L_0x0097
        L_0x00a0:
            boolean r0 = r11.equals(r3)
            if (r0 != 0) goto L_0x00a7
            goto L_0x0097
        L_0x00a7:
            r0 = 2
            goto L_0x00ba
        L_0x00a9:
            boolean r0 = r11.equals(r5)
            if (r0 != 0) goto L_0x00b0
            goto L_0x0097
        L_0x00b0:
            r0 = 1
            goto L_0x00ba
        L_0x00b2:
            boolean r0 = r11.equals(r6)
            if (r0 != 0) goto L_0x00b9
            goto L_0x0097
        L_0x00b9:
            r0 = 0
        L_0x00ba:
            switch(r0) {
                case 0: goto L_0x00c9;
                case 1: goto L_0x00c6;
                case 2: goto L_0x00c3;
                case 3: goto L_0x00c0;
                default: goto L_0x00bd;
            }
        L_0x00bd:
            int r0 = com.huawei.module_push.R$string.designstandard_system_information
            goto L_0x00cb
        L_0x00c0:
            int r0 = com.huawei.module_push.R$string.app_driver_message
            goto L_0x00cb
        L_0x00c3:
            int r0 = com.huawei.module_push.R$string.app_commerce_message
            goto L_0x00cb
        L_0x00c6:
            int r0 = com.huawei.module_push.R$string.designstandard_promotion_news
            goto L_0x00cb
        L_0x00c9:
            int r0 = com.huawei.module_push.R$string.designstandard_transaction_message
        L_0x00cb:
            r9.setText(r0)
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            com.huawei.module_push.databinding.NotificationTitleBarBinding r0 = r0.g
            android.widget.ImageView r0 = r0.b
            com.huawei.push.notification.k r1 = new com.huawei.push.notification.k
            r1.<init>(r13)
            r0.setOnClickListener(r1)
        L_0x00dc:
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            com.scwang.smart.refresh.layout.SmartRefreshLayout r0 = r0.i
            r0.S0 = r13
            com.scwang.smart.refresh.header.MaterialHeader r1 = new com.scwang.smart.refresh.header.MaterialHeader
            r1.<init>(r13)
            r0.r(r1)
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox r0 = r0.c
            com.huawei.push.notification.i r1 = new com.huawei.push.notification.i
            r1.<init>(r13)
            r0.setOnCheckedChangeListener(r1)
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox r0 = r0.d
            com.huawei.push.notification.j r1 = new com.huawei.push.notification.j
            r1.<init>(r13)
            r0.setOnCheckedChangeListener(r1)
            java.lang.String r0 = r13.pushType
            boolean r0 = r10.equals(r0)
            if (r0 == 0) goto L_0x0112
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            android.widget.RelativeLayout r0 = r0.e
            r0.setVisibility(r8)
            goto L_0x011b
        L_0x0112:
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            android.widget.RelativeLayout r0 = r0.e
            r1 = 8
            r0.setVisibility(r1)
        L_0x011b:
            com.huawei.push.viewmodel.NotificationViewModel r0 = r13.o
            androidx.lifecycle.MutableLiveData<java.lang.Void> r0 = r0.i
            com.huawei.push.notification.f r1 = new com.huawei.push.notification.f
            r1.<init>(r13)
            r0.observe(r13, r1)
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            com.huawei.module_push.databinding.NotificationTitleBarBinding r0 = r0.g
            android.widget.ImageView r0 = r0.c
            com.huawei.push.notification.l r1 = new com.huawei.push.notification.l
            r1.<init>(r13)
            r0.setOnClickListener(r1)
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r0 = r13.j
            com.huawei.common.widget.round.RoundLinearLayout r0 = r0.b
            com.huawei.push.notification.m r1 = new com.huawei.push.notification.m
            r1.<init>(r13)
            r0.setOnClickListener(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.push.notification.NotificationRecordsActivity.G0():void");
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [com.huawei.push.notification.NotificationRecordsActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004f, code lost:
        r3 = com.huawei.module_push.R$id.notificationTitleBarView;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0090, code lost:
        r3 = com.huawei.module_push.R$id.swipe_refresh;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0019, code lost:
        r1 = com.huawei.module_push.R$id.cb_for_all;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0024, code lost:
        r1 = com.huawei.module_push.R$id.cb_for_me;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r13 = this;
            android.view.LayoutInflater r0 = r13.getLayoutInflater()
            int r1 = com.huawei.module_push.R$layout.activity_notification_records
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_push.R$id.calendarRl
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.huawei.common.widget.round.RoundLinearLayout r5 = (com.huawei.common.widget.round.RoundLinearLayout) r5
            java.lang.String r2 = "Missing required view with ID: "
            if (r5 == 0) goto L_0x00bd
            int r1 = com.huawei.module_push.R$id.cb_for_all
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r3
            com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox r6 = (com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox) r6
            if (r6 == 0) goto L_0x00bd
            int r1 = com.huawei.module_push.R$id.cb_for_me
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r3
            com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox r7 = (com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox) r7
            if (r7 == 0) goto L_0x00bd
            int r1 = com.huawei.module_push.R$id.ivCalendar
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x00bd
            int r3 = com.huawei.module_push.R$id.ll_for_all_me_container
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            r8 = r4
            android.widget.RelativeLayout r8 = (android.widget.RelativeLayout) r8
            if (r8 == 0) goto L_0x00a8
            int r3 = com.huawei.module_push.R$id.notificationTitleBar
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            r9 = r4
            android.widget.LinearLayout r9 = (android.widget.LinearLayout) r9
            if (r9 == 0) goto L_0x00a8
            int r3 = com.huawei.module_push.R$id.notificationTitleBarView
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            if (r4 == 0) goto L_0x00a8
            r3 = r4
            com.google.android.material.appbar.AppBarLayout r3 = (com.google.android.material.appbar.AppBarLayout) r3
            int r10 = com.huawei.module_push.R$id.base_toolbar
            android.view.View r11 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r10)
            androidx.appcompat.widget.Toolbar r11 = (androidx.appcompat.widget.Toolbar) r11
            if (r11 == 0) goto L_0x00aa
            int r10 = com.huawei.module_push.R$id.iv_back
            android.view.View r11 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r10)
            android.widget.ImageView r11 = (android.widget.ImageView) r11
            if (r11 == 0) goto L_0x00aa
            android.view.View r10 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r1)
            android.widget.ImageView r10 = (android.widget.ImageView) r10
            if (r10 == 0) goto L_0x00ab
            int r1 = com.huawei.module_push.R$id.tv_base_title
            android.view.View r12 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r1)
            android.widget.TextView r12 = (android.widget.TextView) r12
            if (r12 == 0) goto L_0x00ab
            com.huawei.module_push.databinding.NotificationTitleBarBinding r1 = new com.huawei.module_push.databinding.NotificationTitleBarBinding
            r1.<init>(r3, r11, r10, r12)
            int r3 = com.huawei.module_push.R$id.rv_system_info
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            r11 = r4
            androidx.recyclerview.widget.RecyclerView r11 = (androidx.recyclerview.widget.RecyclerView) r11
            if (r11 == 0) goto L_0x00a8
            int r3 = com.huawei.module_push.R$id.swipe_refresh
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            r12 = r4
            com.scwang.smart.refresh.layout.SmartRefreshLayout r12 = (com.scwang.smart.refresh.layout.SmartRefreshLayout) r12
            if (r12 == 0) goto L_0x00a8
            com.huawei.module_push.databinding.ActivityNotificationRecordsBinding r2 = new com.huawei.module_push.databinding.ActivityNotificationRecordsBinding
            r4 = r0
            android.widget.LinearLayout r4 = (android.widget.LinearLayout) r4
            r3 = r2
            r10 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r13.j = r2
            return r2
        L_0x00a8:
            r1 = r3
            goto L_0x00bd
        L_0x00aa:
            r1 = r10
        L_0x00ab:
            android.content.res.Resources r0 = r4.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x00bd:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.push.notification.NotificationRecordsActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final boolean L0() {
        if ("0".equals(this.pushType)) {
            return true;
        }
        return false;
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
        DialogManager.d(getSupportFragmentManager(), true);
    }

    public final void W0() {
        if (this.l == null) {
            this.l = new ArrayList();
            if (this.pushType.equals("1")) {
                this.m = new BaseQuickAdapter(R$layout.item_transaction_message, this.l);
            } else {
                this.m = new BaseQuickAdapter(R$layout.item_notification_message, this.l);
            }
            this.m.setOnItemClickListener(new g(this));
            this.m.getLoadMoreModule().setLoadMoreView(new BaseLoadMoreView());
            this.m.getLoadMoreModule().setEnableLoadMoreIfNotFullPage(false);
            this.m.getLoadMoreModule().setOnLoadMoreListener(new h(this));
            this.j.h.setItemAnimator((RecyclerView.ItemAnimator) null);
            this.j.h.setAdapter(this.m);
        }
    }

    public final void X0(boolean z) {
        String str;
        ArrayList arrayList = this.l;
        if (arrayList != null) {
            int size = arrayList.size();
            this.l.clear();
            this.m.notifyItemRangeRemoved(0, size);
        }
        this.k = 0;
        this.n = false;
        if (z) {
            n nVar = this.i;
            nVar.getClass();
            nVar.a(H3.c.e().a0(new TopicNotificationRequest("all", "consumer", 0, 10)), new o(nVar, (P2.a) nVar.a, true));
            return;
        }
        Calendar calendar = this.r.a;
        String str2 = "";
        if (calendar != null) {
            str = L3.a.f(C.a("yyyy-MM-dd", calendar.getTime()), Boolean.TRUE);
        } else {
            str = str2;
        }
        Calendar calendar2 = this.r.b;
        if (calendar2 != null) {
            str2 = L3.a.f(C.a("yyyy-MM-dd", calendar2.getTime()), Boolean.FALSE);
        }
        this.i.b(this.pushType, str, str2, this.k, false);
    }

    public final void Y0(List<NotificationMessageBean> list) {
        this.q = true;
        ArrayList arrayList = (ArrayList) list;
        if (arrayList.size() > 0) {
            String category = ((NotificationMessageBean) arrayList.get(0)).getCategory();
            if ((TextUtils.isEmpty(this.pushType) || !this.pushType.equals(category)) && (!"0".equals(this.pushType) || !this.p)) {
                this.m.getLoadMoreModule().loadMoreComplete();
                return;
            }
            this.k = arrayList.size() + this.k;
            if (!this.n) {
                this.m.getLoadMoreModule().setEnableLoadMoreIfNotFullPage(false);
                this.l.clear();
            } else if (arrayList.isEmpty()) {
                this.m.getLoadMoreModule().loadMoreEnd();
            } else {
                this.m.getLoadMoreModule().loadMoreComplete();
            }
            this.l.addAll(list);
            this.m.notifyDataSetChanged();
            return;
        }
        this.m.getLoadMoreModule().loadMoreComplete();
    }

    public final void a(List<NotificationMessageBean> list) {
        W0();
        Y0(list);
    }

    public final void j(ArrayList arrayList) {
        W0();
        Y0(arrayList);
    }

    @j(threadMode = ThreadMode.MAIN)
    public void onReceiveFilterEvent(Z7.e eVar) {
        boolean z;
        if (!"0".equals(this.pushType) || !this.p) {
            this.r = eVar;
        }
        if (!"0".equals(this.pushType) || !this.p) {
            z = false;
        } else {
            z = true;
        }
        X0(z);
    }

    public final void onRefresh() {
        boolean z;
        if (this.q) {
            if (!"0".equals(this.pushType) || !this.p) {
                z = false;
            } else {
                z = true;
            }
            X0(z);
        }
    }
}
