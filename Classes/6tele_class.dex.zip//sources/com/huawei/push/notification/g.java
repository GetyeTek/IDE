package com.huawei.push.notification;

import A6.e;
import a8.b;
import a8.c;
import android.view.View;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import com.huawei.push.viewmodel.NotificationViewModel;
import java.util.ArrayList;

public final /* synthetic */ class g implements OnItemClickListener {
    public final /* synthetic */ NotificationRecordsActivity a;

    public /* synthetic */ g(NotificationRecordsActivity notificationRecordsActivity) {
        this.a = notificationRecordsActivity;
    }

    public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        int i2 = NotificationRecordsActivity.s;
        NotificationRecordsActivity notificationRecordsActivity = this.a;
        notificationRecordsActivity.getClass();
        ArrayList arrayList = new ArrayList();
        NotificationMessageBean notificationMessageBean = (NotificationMessageBean) notificationRecordsActivity.l.get(i);
        arrayList.add(notificationMessageBean.getMsgId());
        if (!"1".equals(notificationMessageBean.getReadStatus())) {
            NotificationViewModel notificationViewModel = notificationRecordsActivity.o;
            c cVar = notificationViewModel.g;
            cVar.getClass();
            notificationViewModel.b(new b(cVar, arrayList).a, new e(notificationViewModel, 2));
            notificationMessageBean.setReadStatus("1");
            notificationRecordsActivity.m.notifyItemChanged(i);
        }
    }
}
