package com.huawei.push.notification;

import H3.c;
import L3.a;
import com.blankj.utilcode.util.C;
import com.chad.library.adapter.base.listener.OnLoadMoreListener;
import com.huawei.digitalpayment.customer.httplib.request.TopicNotificationRequest;
import java.util.Calendar;

public final /* synthetic */ class h implements OnLoadMoreListener {
    public final /* synthetic */ NotificationRecordsActivity a;

    public /* synthetic */ h(NotificationRecordsActivity notificationRecordsActivity) {
        this.a = notificationRecordsActivity;
    }

    public final void onLoadMore() {
        String str;
        NotificationRecordsActivity notificationRecordsActivity = this.a;
        notificationRecordsActivity.n = true;
        if (!"0".equals(notificationRecordsActivity.pushType) || !notificationRecordsActivity.p) {
            Calendar calendar = notificationRecordsActivity.r.a;
            String str2 = "";
            if (calendar != null) {
                str = a.f(C.a("yyyy-MM-dd", calendar.getTime()), Boolean.TRUE);
            } else {
                str = str2;
            }
            Calendar calendar2 = notificationRecordsActivity.r.b;
            if (calendar2 != null) {
                str2 = a.f(C.a("yyyy-MM-dd", calendar2.getTime()), Boolean.FALSE);
            }
            notificationRecordsActivity.i.b(notificationRecordsActivity.pushType, str, str2, notificationRecordsActivity.k, true);
            return;
        }
        n nVar = notificationRecordsActivity.i;
        int i = notificationRecordsActivity.k;
        nVar.getClass();
        nVar.a(c.e().a0(new TopicNotificationRequest("all", "consumer", i, 10)), new o(nVar, (P2.a) nVar.a, false));
    }
}
