package com.huawei.push.notification;

import A8.c;
import W2.n;
import android.widget.TextView;
import androidx.lifecycle.ViewModelProvider;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.login_module.login.f;
import com.huawei.digitalpayment.customer.login_module.login.g;
import com.huawei.module_push.R$string;
import com.huawei.module_push.databinding.ActivityNotificationBinding;
import com.huawei.push.viewmodel.NotificationViewModel;
import w5.a;

@Route(path = "/pushModule/notification")
public class NotificationActivity extends BaseMvpActivity<e> {
    public static final /* synthetic */ int l = 0;
    public ActivityNotificationBinding j;
    public NotificationViewModel k;

    public static void V0(String str, String str2) {
        a.a(str2);
        n.b("").h("NOTIFICATION_TYPE".concat(str), false);
        n.a.b().getClass();
        n.a.a("/pushModule/notificationRecord").withString("pushType", str).navigation();
    }

    public static void X0(TextView textView, String str) {
        String str2;
        int i = 0;
        int i2 = n.b("sp_name_push").a.getInt(str, 0);
        if (i2 <= 0) {
            i = 8;
        }
        textView.setVisibility(i);
        if (i2 > 99) {
            str2 = "99+";
        } else {
            str2 = String.valueOf(i2);
        }
        textView.setText(str2);
    }

    public final void D0() {
    }

    public final void G(String str) {
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [android.view.View$OnClickListener, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v3, types: [android.view.View$OnClickListener, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v4, types: [android.view.View$OnClickListener, java.lang.Object] */
    public final void G0() {
        NotificationActivity.super.G0();
        O0(R$string.designstandard_notification);
        NotificationViewModel notificationViewModel = new ViewModelProvider(this).get(NotificationViewModel.class);
        this.k = notificationViewModel;
        notificationViewModel.h.observe(this, new a(this, 0));
        this.j.e.setOnClickListener(new Object());
        this.j.d.setOnClickListener(new Object());
        this.j.f.setOnClickListener(new Object());
        this.j.b.setOnClickListener(new f(this, 2));
        this.j.c.setOnClickListener(new g(this, 1));
    }

    /* JADX WARNING: type inference failed for: r15v0, types: [com.huawei.push.notification.NotificationActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0043, code lost:
        r1 = com.huawei.module_push.R$id.tv_commerce_message_red_dot;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004e, code lost:
        r1 = com.huawei.module_push.R$id.tv_driver_message_red_dot;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0059, code lost:
        r1 = com.huawei.module_push.R$id.tv_promotion_red_dot;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0064, code lost:
        r1 = com.huawei.module_push.R$id.tv_system_red_dot;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x006f, code lost:
        r1 = com.huawei.module_push.R$id.tv_transaction_red_dot;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r15 = this;
            android.view.LayoutInflater r0 = r15.getLayoutInflater()
            int r1 = com.huawei.module_push.R$layout.activity_notification
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_push.R$id.ll_commerce_message
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            android.widget.LinearLayout r5 = (android.widget.LinearLayout) r5
            if (r5 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.ll_driver_message
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            if (r6 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.ll_promotion_news
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.LinearLayout r7 = (android.widget.LinearLayout) r7
            if (r7 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.ll_system_information
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            android.widget.LinearLayout r8 = (android.widget.LinearLayout) r8
            if (r8 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.ll_transaction_message
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            android.widget.LinearLayout r9 = (android.widget.LinearLayout) r9
            if (r9 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.tv_commerce_message_red_dot
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            com.huawei.common.widget.round.RoundTextView r10 = (com.huawei.common.widget.round.RoundTextView) r10
            if (r10 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.tv_driver_message_red_dot
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            com.huawei.common.widget.round.RoundTextView r11 = (com.huawei.common.widget.round.RoundTextView) r11
            if (r11 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.tv_promotion_red_dot
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r12 = r2
            com.huawei.common.widget.round.RoundTextView r12 = (com.huawei.common.widget.round.RoundTextView) r12
            if (r12 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.tv_system_red_dot
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r13 = r2
            com.huawei.common.widget.round.RoundTextView r13 = (com.huawei.common.widget.round.RoundTextView) r13
            if (r13 == 0) goto L_0x0086
            int r1 = com.huawei.module_push.R$id.tv_transaction_red_dot
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r14 = r2
            com.huawei.common.widget.round.RoundTextView r14 = (com.huawei.common.widget.round.RoundTextView) r14
            if (r14 == 0) goto L_0x0086
            com.huawei.module_push.databinding.ActivityNotificationBinding r1 = new com.huawei.module_push.databinding.ActivityNotificationBinding
            r4 = r0
            android.widget.LinearLayout r4 = (android.widget.LinearLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14)
            r15.j = r1
            return r1
        L_0x0086:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.push.notification.NotificationActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
    }

    public final void W0() {
        X0(this.j.j, "systemNotificationCount");
        X0(this.j.i, "promotionNotificationCount");
        X0(this.j.k, "transactionNotificationCount");
        X0(this.j.g, "eCommerceMessageCount");
        X0(this.j.h, "driverMessageCount");
    }

    public final void onResume() {
        NotificationActivity.super.onResume();
        W0();
        NotificationViewModel notificationViewModel = this.k;
        a8.c cVar = notificationViewModel.g;
        cVar.getClass();
        notificationViewModel.b(new a8.a(cVar).a, new d8.a(notificationViewModel));
    }
}
