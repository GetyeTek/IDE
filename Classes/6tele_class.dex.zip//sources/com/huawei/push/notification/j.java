package com.huawei.push.notification;

import android.widget.CompoundButton;

public final /* synthetic */ class j implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ NotificationRecordsActivity a;

    public /* synthetic */ j(NotificationRecordsActivity notificationRecordsActivity) {
        this.a = notificationRecordsActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        NotificationRecordsActivity notificationRecordsActivity = this.a;
        if (z) {
            notificationRecordsActivity.j.b.setVisibility(0);
            notificationRecordsActivity.p = false;
            notificationRecordsActivity.j.d.setChecked(true);
            notificationRecordsActivity.j.d.setClickable(false);
            notificationRecordsActivity.j.c.setChecked(false);
            notificationRecordsActivity.j.c.setClickable(true);
            notificationRecordsActivity.X0(false);
            return;
        }
        int i = NotificationRecordsActivity.s;
        notificationRecordsActivity.getClass();
    }
}
