package com.huawei.push.notification;

import android.view.View;

public final /* synthetic */ class c implements View.OnClickListener {
    public final void onClick(View view) {
        int i = NotificationActivity.l;
        NotificationActivity.V0("2", "Notification_Transaction_V1");
    }
}
