package com.huawei.push.notification;

import V7.c;
import android.widget.TextView;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.homev6.balance.MyUsdBalanceActivity;
import com.huawei.digitalpayment.customer.homev6.databinding.ActivityMyUsdBalanceBinding;
import com.huawei.digitalpayment.customer.homev6.model.HomeBalance;
import com.huawei.digitalpayment.customer.homev6.transactionhistory.TransactionReportFragment;
import com.huawei.digitalpayment.customer.homev6.transactionhistory.resp.TransactionStatData;
import java.util.List;
import o3.f;

public final /* synthetic */ class a implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                Void voidR = (Void) obj;
                int i = NotificationActivity.l;
                ((NotificationActivity) obj2).W0();
                return;
            case 1:
                List<HomeBalance> list = (List) obj;
                int i2 = MyUsdBalanceActivity.d;
                MyUsdBalanceActivity myUsdBalanceActivity = (MyUsdBalanceActivity) obj2;
                if (list != null && !list.isEmpty()) {
                    for (HomeBalance homeBalance : list) {
                        if (homeBalance.getForward().contains("home_usd_balance")) {
                            ((ActivityMyUsdBalanceBinding) myUsdBalanceActivity.b).c.setText(homeBalance.getAmountDisplay());
                            ActivityMyUsdBalanceBinding activityMyUsdBalanceBinding = (ActivityMyUsdBalanceBinding) myUsdBalanceActivity.b;
                            activityMyUsdBalanceBinding.c.setMaxWidth(activityMyUsdBalanceBinding.a.getWidth());
                            ((ActivityMyUsdBalanceBinding) myUsdBalanceActivity.b).d.setVisibility(0);
                            ((ActivityMyUsdBalanceBinding) myUsdBalanceActivity.b).a.setOnClickListener(new f(homeBalance));
                            return;
                        }
                    }
                    return;
                }
                return;
            default:
                c cVar = (c) obj;
                TransactionReportFragment transactionReportFragment = (TransactionReportFragment) obj2;
                transactionReportFragment.getClass();
                V7.f.a(transactionReportFragment, cVar);
                if (cVar.b()) {
                    V7.f.c(cVar);
                    return;
                } else if (cVar.f()) {
                    TextView textView = transactionReportFragment.c.i;
                    TransactionStatData transactionStatData = (TransactionStatData) cVar.c;
                    textView.setText(transactionStatData.getTotalTransactionCount());
                    transactionReportFragment.c.j.setText(transactionStatData.getTotalCreditAmount());
                    transactionReportFragment.c.k.setText(transactionStatData.getTotalDebitAmount());
                    transactionReportFragment.c.l.setText(transactionStatData.getNetBalance());
                    TextView textView2 = transactionReportFragment.c.m;
                    k3.a aVar = k3.a.e;
                    textView2.setText(aVar.b());
                    transactionReportFragment.c.n.setText(aVar.b());
                    transactionReportFragment.c.o.setText(aVar.b());
                    if (transactionStatData.getTransactionTypeAmountList() != null) {
                        transactionReportFragment.e.submitList(transactionStatData.getTransactionTypeAmountList());
                        return;
                    }
                    return;
                } else {
                    return;
                }
        }
    }
}
