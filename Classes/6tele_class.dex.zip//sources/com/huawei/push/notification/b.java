package com.huawei.push.notification;

import android.view.View;

public final /* synthetic */ class b implements View.OnClickListener {
    public final void onClick(View view) {
        int i = NotificationActivity.l;
        NotificationActivity.V0("0", "Notification_System_V1");
    }
}
