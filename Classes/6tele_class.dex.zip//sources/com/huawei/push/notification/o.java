package com.huawei.push.notification;

import L2.b;
import P2.a;
import com.huawei.digitalpayment.customer.httplib.response.AppNotificationResp;
import java.util.ArrayList;

public final class o extends b<AppNotificationResp> {
    public final /* synthetic */ n f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public o(n nVar, a aVar, boolean z) {
        super(aVar, z);
        this.f = nVar;
    }

    public final void b(String str) {
        ((a) this.f.a).a(new ArrayList());
    }

    public final void c(Object obj) {
        AppNotificationResp appNotificationResp = (AppNotificationResp) obj;
        ArrayList arrayList = new ArrayList();
        if (!(appNotificationResp == null || appNotificationResp.getRecords() == null)) {
            for (AppNotificationResp.RecordsBean data : appNotificationResp.getRecords()) {
                arrayList.add(data.getData());
            }
        }
        ((a) this.f.a).a(arrayList);
    }
}
