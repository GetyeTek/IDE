package com.huawei.push.notification;

import android.view.View;

public final class k implements View.OnClickListener {
    public final /* synthetic */ NotificationRecordsActivity a;

    public k(NotificationRecordsActivity notificationRecordsActivity) {
        this.a = notificationRecordsActivity;
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.push.notification.NotificationRecordsActivity, android.app.Activity] */
    public final void onClick(View view) {
        this.a.finish();
    }
}
