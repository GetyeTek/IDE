package com.huawei.push.notification;

import W2.a;
import android.view.View;

public final class l implements View.OnClickListener {
    public final /* synthetic */ NotificationRecordsActivity a;

    public l(NotificationRecordsActivity notificationRecordsActivity) {
        this.a = notificationRecordsActivity;
    }

    public final void onClick(View view) {
        if (!a.a(1500, view)) {
            NotificationRecordsActivity.V0(this.a);
        }
    }
}
