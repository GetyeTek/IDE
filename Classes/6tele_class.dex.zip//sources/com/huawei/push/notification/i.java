package com.huawei.push.notification;

import android.widget.CompoundButton;

public final /* synthetic */ class i implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ NotificationRecordsActivity a;

    public /* synthetic */ i(NotificationRecordsActivity notificationRecordsActivity) {
        this.a = notificationRecordsActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        NotificationRecordsActivity notificationRecordsActivity = this.a;
        if (z) {
            notificationRecordsActivity.j.b.setVisibility(8);
            notificationRecordsActivity.p = true;
            notificationRecordsActivity.j.c.setChecked(true);
            notificationRecordsActivity.j.c.setClickable(false);
            notificationRecordsActivity.j.d.setChecked(false);
            notificationRecordsActivity.j.d.setClickable(true);
            notificationRecordsActivity.X0(true);
            return;
        }
        int i = NotificationRecordsActivity.s;
        notificationRecordsActivity.getClass();
    }
}
