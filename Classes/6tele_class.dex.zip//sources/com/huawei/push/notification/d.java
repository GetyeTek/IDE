package com.huawei.push.notification;

import android.view.View;

public final /* synthetic */ class d implements View.OnClickListener {
    public final void onClick(View view) {
        int i = NotificationActivity.l;
        NotificationActivity.V0("1", "Notification_Promotion_V1");
    }
}
