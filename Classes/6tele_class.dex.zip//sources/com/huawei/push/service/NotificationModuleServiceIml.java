package com.huawei.push.service;

import B7.e;
import W2.n;
import a8.a;
import a8.c;
import android.content.Context;
import androidx.lifecycle.MediatorLiveData;
import b8.d;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.ethiopia.component.service.NotificationModuleService;

@Route(path = "/pushModule/notificationModuleService")
public class NotificationModuleServiceIml implements NotificationModuleService {
    public c a;
    public MediatorLiveData b;
    public d c;

    public static int B(String str) {
        return n.b("sp_name_push").a.getInt(str, 0);
    }

    public final int f() {
        return B("systemNotificationCount");
    }

    public final void init(Context context) {
        this.a = new c();
    }

    public final void n(e eVar) {
        d dVar;
        MediatorLiveData mediatorLiveData = this.b;
        if (!(mediatorLiveData == null || (dVar = this.c) == null)) {
            mediatorLiveData.removeObserver(dVar);
            this.b = null;
            this.c = null;
        }
        c cVar = this.a;
        cVar.getClass();
        MediatorLiveData mediatorLiveData2 = new a(cVar).a;
        this.b = mediatorLiveData2;
        d dVar2 = new d(this, eVar);
        this.c = dVar2;
        mediatorLiveData2.observeForever(dVar2);
    }

    public final int r() {
        return B("transactionNotificationCount");
    }

    public final int s() {
        return B("promotionNotificationCount");
    }

    public final int x() {
        return B("eCommerceMessageCount");
    }

    public final int z() {
        return B("driverMessageCount");
    }
}
