package com.huawei.push.service;

import E.p;
import J5.b;
import V1.h;
import W2.n;
import Yb.c;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.SoundPool;
import android.os.Build;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import b8.e;
import com.blankj.utilcode.util.k;
import com.blankj.utilcode.util.q;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import com.huawei.module_push.R$mipmap;
import com.huawei.module_push.R$string;
import com.huawei.push.NotificationFilterActivity;
import java.util.Map;

public class NotificationService extends FirebaseMessagingService {
    public final String a = "homev5_nocache";
    public final String b = "HomeBalanceUpdateTime";
    public final String c = "creditPayBalanceUpdateTime";
    public final String d = "sp_name_push";
    public final String e = "unreadCountUpdateTime";

    public class a implements q.c {
        public final /* synthetic */ NotificationManagerCompat a;
        public final /* synthetic */ NotificationCompat.Builder b;

        public a(NotificationManagerCompat notificationManagerCompat, NotificationCompat.Builder builder) {
            this.a = notificationManagerCompat;
            this.b = builder;
        }

        @SuppressLint({"MissingPermission"})
        public final void a() {
            this.a.notify((int) System.currentTimeMillis(), this.b.build());
        }

        public final void b() {
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.push.service.NotificationService, android.content.Context] */
    @TargetApi(26)
    public final void c(int i, String str, String str2) {
        NotificationChannel b2 = e.b(i, str, str2);
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        if (notificationManager != null) {
            p.b(notificationManager, b2);
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.push.service.NotificationService, android.content.Context] */
    public final void d(PendingIntent pendingIntent, NotificationMessageBean notificationMessageBean) {
        String str;
        String str2;
        CharSequence charSequence;
        if (TextUtils.isEmpty(notificationMessageBean.getCategory())) {
            str = "0";
        } else {
            str = notificationMessageBean.getCategory();
        }
        NotificationCompat.Builder smallIcon = new NotificationCompat.Builder(this, str).setSmallIcon(R$mipmap.icon_logo);
        if (TextUtils.isEmpty(notificationMessageBean.getTitle())) {
            str2 = "";
        } else {
            str2 = notificationMessageBean.getTitle();
        }
        NotificationCompat.Builder contentTitle = smallIcon.setContentTitle(str2);
        if (TextUtils.isEmpty(notificationMessageBean.getContent())) {
            charSequence = getText(R$string.new_message);
        } else {
            charSequence = notificationMessageBean.getContent();
        }
        NotificationCompat.Builder contentIntent = contentTitle.setContentText(charSequence).setPriority(1).setAutoCancel(true).setContentIntent(pendingIntent);
        NotificationManagerCompat from = NotificationManagerCompat.from(this);
        if (from.areNotificationsEnabled()) {
            from.notify((int) System.currentTimeMillis(), contentIntent.build());
            return;
        }
        q.e(new String[]{"android.permission.POST_NOTIFICATIONS"}).b = new a(from, contentIntent);
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.push.service.NotificationService, android.app.Service] */
    public final void onCreate() {
        NotificationService.super.onCreate();
        new SoundPool(1, 5, 0);
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [com.huawei.push.service.NotificationService, android.content.Context] */
    @SuppressLint({"MissingPermission"})
    public final void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        PendingIntent pendingIntent;
        String str = this.a;
        try {
            int i = Build.VERSION.SDK_INT;
            if (i >= 26) {
                c(4, "1", "Transaction Message");
                c(3, "0", "System Information");
                c(3, "2", "Promotion News");
                c(3, "3", "E-commerce Message");
            }
            String json = k.c().toJson(remoteMessage.getData(), Map.class);
            h.b();
            NotificationMessageBean notificationMessageBean = (NotificationMessageBean) k.a(json, NotificationMessageBean.class);
            remoteMessage.getMessageId();
            h.b();
            String systemExecute = notificationMessageBean.getSystemExecute();
            int i2 = NotificationFilterActivity.d;
            Intent intent = new Intent(this, NotificationFilterActivity.class);
            intent.putExtra("execute", systemExecute);
            intent.setFlags(67108864);
            if (i < 31) {
                pendingIntent = PendingIntent.getActivity(this, 0, intent, 134217728);
            } else if (i >= 34) {
                pendingIntent = PendingIntent.getActivity(this, 0, intent, 67108864, b.a(J5.a.a()).toBundle());
            } else {
                pendingIntent = PendingIntent.getActivity(this, 0, intent, 67108864);
            }
            d(pendingIntent, notificationMessageBean);
            if ("1".equals(notificationMessageBean.getCategory())) {
                n.b(str).i(this.b);
                n.b(str).i(this.c);
                n.b(this.d).i(this.e);
            }
            n b2 = n.b("");
            b2.h("NOTIFICATION_TYPE" + notificationMessageBean.getCategory(), true);
            c.b().h(new Object());
        } catch (Exception unused) {
            h.b();
        }
    }

    public final void onNewToken(@NonNull String str) {
        k3.c cVar = k3.c.c;
        n.b("").g("FIREBASE_TOKEN", str, false);
        I3.c.b();
        h.b();
    }
}
