package com.huawei.module_push.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;

public final class ActivityNotificationEmptyBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;

    public ActivityNotificationEmptyBinding(@NonNull ConstraintLayout constraintLayout) {
        this.a = constraintLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
