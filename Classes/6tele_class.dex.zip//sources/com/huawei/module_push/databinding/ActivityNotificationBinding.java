package com.huawei.module_push.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundTextView;

public final class ActivityNotificationBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final LinearLayout b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final LinearLayout d;
    @NonNull
    public final LinearLayout e;
    @NonNull
    public final LinearLayout f;
    @NonNull
    public final RoundTextView g;
    @NonNull
    public final RoundTextView h;
    @NonNull
    public final RoundTextView i;
    @NonNull
    public final RoundTextView j;
    @NonNull
    public final RoundTextView k;

    public ActivityNotificationBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull LinearLayout linearLayout3, @NonNull LinearLayout linearLayout4, @NonNull LinearLayout linearLayout5, @NonNull LinearLayout linearLayout6, @NonNull RoundTextView roundTextView, @NonNull RoundTextView roundTextView2, @NonNull RoundTextView roundTextView3, @NonNull RoundTextView roundTextView4, @NonNull RoundTextView roundTextView5) {
        this.a = linearLayout;
        this.b = linearLayout2;
        this.c = linearLayout3;
        this.d = linearLayout4;
        this.e = linearLayout5;
        this.f = linearLayout6;
        this.g = roundTextView;
        this.h = roundTextView2;
        this.i = roundTextView3;
        this.j = roundTextView4;
        this.k = roundTextView5;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
