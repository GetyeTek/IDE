package com.huawei.module_push.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;

public final class ActivityNotificationRecordsBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final RoundLinearLayout b;
    @NonNull
    public final RoundCheckBox c;
    @NonNull
    public final RoundCheckBox d;
    @NonNull
    public final RelativeLayout e;
    @NonNull
    public final LinearLayout f;
    @NonNull
    public final NotificationTitleBarBinding g;
    @NonNull
    public final RecyclerView h;
    @NonNull
    public final SmartRefreshLayout i;

    public ActivityNotificationRecordsBinding(@NonNull LinearLayout linearLayout, @NonNull RoundLinearLayout roundLinearLayout, @NonNull RoundCheckBox roundCheckBox, @NonNull RoundCheckBox roundCheckBox2, @NonNull RelativeLayout relativeLayout, @NonNull LinearLayout linearLayout2, @NonNull NotificationTitleBarBinding notificationTitleBarBinding, @NonNull RecyclerView recyclerView, @NonNull SmartRefreshLayout smartRefreshLayout) {
        this.a = linearLayout;
        this.b = roundLinearLayout;
        this.c = roundCheckBox;
        this.d = roundCheckBox2;
        this.e = relativeLayout;
        this.f = linearLayout2;
        this.g = notificationTitleBarBinding;
        this.h = recyclerView;
        this.i = smartRefreshLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
