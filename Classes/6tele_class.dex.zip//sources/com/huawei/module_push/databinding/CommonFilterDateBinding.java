package com.huawei.module_push.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundTextView;

public final class CommonFilterDateBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;

    public CommonFilterDateBinding(@NonNull LinearLayout linearLayout, @NonNull RoundTextView roundTextView, @NonNull LinearLayout linearLayout2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull LinearLayout linearLayout3) {
        this.a = linearLayout;
        this.b = textView;
        this.c = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
