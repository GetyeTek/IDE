package com.huawei.module_push.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.google.android.material.appbar.AppBarLayout;

public final class NotificationTitleBarBinding implements ViewBinding {
    @NonNull
    public final AppBarLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final TextView d;

    public NotificationTitleBarBinding(@NonNull AppBarLayout appBarLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull TextView textView) {
        this.a = appBarLayout;
        this.b = imageView;
        this.c = imageView2;
        this.d = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
