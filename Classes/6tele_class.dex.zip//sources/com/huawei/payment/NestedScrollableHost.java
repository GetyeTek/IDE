package com.huawei.payment;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.annotation.Nullable;
import androidx.viewpager2.widget.ViewPager2;

public final class NestedScrollableHost extends FrameLayout {
    public final int a = ViewConfiguration.get(getContext()).getScaledTouchSlop();
    public float b;
    public float c;
    public View d;
    public ViewPager2 e;

    public NestedScrollableHost(Context context) {
        super(context);
    }

    private View getChild() {
        View view;
        View view2 = this.d;
        if (view2 != null) {
            return view2;
        }
        if (getChildCount() > 0) {
            view = getChildAt(0);
        } else {
            view = null;
        }
        this.d = view;
        return view;
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
        	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
        */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0017  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0020 A[EDGE_INSN: B:14:0x0020->B:12:0x0020 ?: BREAK  
    EDGE_INSN: B:15:0x0020->B:12:0x0020 ?: BREAK  ] */
    private androidx.viewpager2.widget.ViewPager2 getParentViewPager() {
        /*
            r3 = this;
            androidx.viewpager2.widget.ViewPager2 r0 = r3.e
            if (r0 == 0) goto L_0x0005
            return r0
        L_0x0005:
            android.view.ViewParent r0 = r3.getParent()
            boolean r1 = r0 instanceof android.view.View
            r2 = 0
            if (r1 != 0) goto L_0x000f
        L_0x000e:
            r0 = r2
        L_0x000f:
            android.view.View r0 = (android.view.View) r0
            if (r0 == 0) goto L_0x0020
            boolean r1 = r0 instanceof androidx.viewpager2.widget.ViewPager2
            if (r1 != 0) goto L_0x0020
            android.view.ViewParent r0 = r0.getParent()
            boolean r1 = r0 instanceof android.view.View
            if (r1 != 0) goto L_0x000f
            goto L_0x000e
        L_0x0020:
            androidx.viewpager2.widget.ViewPager2 r0 = (androidx.viewpager2.widget.ViewPager2) r0
            r3.e = r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.payment.NestedScrollableHost.getParentViewPager():androidx.viewpager2.widget.ViewPager2");
    }

    public final boolean a(int i, float f) {
        View child;
        int i2 = -((int) Math.signum(f));
        if (i == 0) {
            View child2 = getChild();
            if (child2 == null || !child2.canScrollHorizontally(i2)) {
                return false;
            }
        } else if (i == 1 && (child = getChild()) != null && child.canScrollVertically(i2)) {
            return true;
        } else {
            return false;
        }
        return true;
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        float f;
        ViewPager2 parentViewPager = getParentViewPager();
        if (parentViewPager != null) {
            int orientation = parentViewPager.getOrientation();
            float f2 = 1.0f;
            if (a(orientation, -1.0f) || a(orientation, 1.0f)) {
                boolean z2 = true;
                if (motionEvent.getAction() == 0) {
                    this.b = motionEvent.getX();
                    this.c = motionEvent.getY();
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else if (motionEvent.getAction() == 2) {
                    float x = motionEvent.getX() - this.b;
                    float y = motionEvent.getY() - this.c;
                    if (orientation == 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    float abs = Math.abs(x);
                    if (z) {
                        f = 0.5f;
                    } else {
                        f = 1.0f;
                    }
                    float f3 = abs * f;
                    float abs2 = Math.abs(y);
                    if (!z) {
                        f2 = 0.5f;
                    }
                    float f4 = abs2 * f2;
                    float f5 = (float) this.a;
                    if (f3 > f5 || f4 > f5) {
                        if (f4 <= f3) {
                            z2 = false;
                        }
                        if (z == z2) {
                            getParent().requestDisallowInterceptTouchEvent(false);
                        } else {
                            ViewParent parent = getParent();
                            if (!z) {
                                x = y;
                            }
                            parent.requestDisallowInterceptTouchEvent(a(orientation, x));
                        }
                    }
                }
            }
        }
        return super.onInterceptTouchEvent(motionEvent);
    }

    public NestedScrollableHost(Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
