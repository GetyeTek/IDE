package com.huawei.payment;

public final class R$menu {
    public static final int detail_toolbar_menu = 2131689472;
    public static final int main = 2131689473;
    public static final int menu_bank_detail = 2131689474;
    public static final int menu_link_bank_account = 2131689475;
    public static final int menu_request_money_edit = 2131689476;
    public static final int menu_request_money_setting = 2131689477;
    public static final int menu_webview = 2131689478;
    public static final int ucrop_menu = 2131689479;

    private R$menu() {
    }
}
