package com.huawei.payment.mvvm;

public final class R$style {
    public static final int ImageStyle = 2132083012;

    private R$style() {
    }
}
