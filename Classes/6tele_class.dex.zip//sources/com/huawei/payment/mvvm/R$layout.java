package com.huawei.payment.mvvm;

public final class R$layout {
    public static final int common_toolbar = 2131558682;

    private R$layout() {
    }
}
