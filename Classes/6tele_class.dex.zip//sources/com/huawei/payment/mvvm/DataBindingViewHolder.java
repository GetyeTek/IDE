package com.huawei.payment.mvvm;

import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public class DataBindingViewHolder<T extends ViewDataBinding> extends RecyclerView.ViewHolder {
    public final T a;

    public DataBindingViewHolder(T t) {
        super(t.getRoot());
        this.a = t;
    }
}
