package com.huawei.payment.mvvm.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class CommonToolbarBinding extends ViewDataBinding {
    @NonNull
    public final ConstraintLayout a;

    public CommonToolbarBinding(DataBindingComponent dataBindingComponent, View view, ConstraintLayout constraintLayout) {
        super(dataBindingComponent, view, 0);
        this.a = constraintLayout;
    }
}
