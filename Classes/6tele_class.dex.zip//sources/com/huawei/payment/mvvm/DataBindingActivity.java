package com.huawei.payment.mvvm;

import V1.h;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.blankj.utilcode.util.f;
import java.lang.reflect.ParameterizedType;

public abstract class DataBindingActivity<Binding extends ViewDataBinding, VM extends ViewModel> extends AppCompatActivity {
    public DataBindingActivity a;
    public Binding b;
    public VM c;

    public abstract int C0();

    public void D0() {
        try {
            this.c = new ViewModelProvider(this).get((Class) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[1]);
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity] */
    public void finish() {
        DataBindingActivity.super.finish();
        overridePendingTransition(R$anim.activity_close_enter_animation, R$anim.activity_close_exit_animation);
    }

    /* JADX WARNING: type inference failed for: r3v3, types: [java.lang.Object, androidx.core.view.OnApplyWindowInsetsListener] */
    public void onCreate(@Nullable Bundle bundle) {
        Binding binding;
        DataBindingActivity.super.onCreate(bundle);
        overridePendingTransition(R$anim.activity_open_enter_animation, R$anim.activity_open_exit_animation);
        this.a = this;
        try {
            this.b = DataBindingUtil.setContentView(this, C0());
            f.e(this, ContextCompat.getColor(this, R$color.color_background), false);
            f.f(this, true);
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
        D0();
        if (Build.VERSION.SDK_INT >= 35 && (binding = this.b) != null && !binding.getRoot().getFitsSystemWindows()) {
            View root = this.b.getRoot();
            root.setFitsSystemWindows(false);
            ViewCompat.setOnApplyWindowInsetsListener(root, new Object());
        }
    }
}
