package com.huawei.payment.mvvm;

public final class R$id {
    public static final int ivBack = 2131362767;
    public static final int root = 2131363704;
    public static final int tvTitle = 2131364187;

    private R$id() {
    }
}
