package com.huawei.payment.mvvm;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
