package com.huawei.payment.mvvm;

public final class R$color {
    public static final int color_background = 2131099833;

    private R$color() {
    }
}
