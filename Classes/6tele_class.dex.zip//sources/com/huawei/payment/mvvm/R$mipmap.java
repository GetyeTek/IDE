package com.huawei.payment.mvvm;

public final class R$mipmap {
    public static final int ethiopia_icon_back = 2131755184;

    private R$mipmap() {
    }
}
