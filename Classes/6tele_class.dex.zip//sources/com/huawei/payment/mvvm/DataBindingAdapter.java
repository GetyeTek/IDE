package com.huawei.payment.mvvm;

import V7.b;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public abstract class DataBindingAdapter<T, Binding extends ViewDataBinding> extends RecyclerView.Adapter<DataBindingViewHolder<Binding>> {
    public a<T> a;
    public List<T> b;

    public interface a<T> {
        void c(View view, int i, Object obj);
    }

    public abstract int a();

    public abstract void b(Binding binding, int i, T t);

    @NonNull
    /* renamed from: c */
    public DataBindingViewHolder<Binding> onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new DataBindingViewHolder<>(DataBindingUtil.inflate(LayoutInflater.from(viewGroup.getContext()), a(), viewGroup, false));
    }

    public final int getItemCount() {
        List<T> list = this.b;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public final void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        T t;
        DataBindingViewHolder dataBindingViewHolder = (DataBindingViewHolder) viewHolder;
        dataBindingViewHolder.a.getRoot().setOnClickListener(new b(this, i));
        List<T> list = this.b;
        if (list == null) {
            t = null;
        } else {
            t = list.get(i);
        }
        b(dataBindingViewHolder.a, i, t);
    }

    public final void submitList(List<T> list) {
        this.b = list;
        notifyDataSetChanged();
    }
}
