package com.huawei.payment.mvvm;

public final class R$anim {
    public static final int activity_close_enter_animation = 2130771980;
    public static final int activity_close_exit_animation = 2130771981;
    public static final int activity_open_enter_animation = 2130771984;
    public static final int activity_open_exit_animation = 2130771985;

    private R$anim() {
    }
}
