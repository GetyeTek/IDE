package com.huawei.payment.mvvm;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.payment.mvvm.databinding.CommonToolbarBinding;
import com.huawei.payment.mvvm.databinding.CommonToolbarBindingImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(1);
            a = hashMap;
            hashMap.put("layout/common_toolbar_0", Integer.valueOf(R$layout.common_toolbar));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(1);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.common_toolbar, 1);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(3);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new RuntimeException("view must have a tag");
            } else if (i2 == 1) {
                if ("layout/common_toolbar_0".equals(tag)) {
                    Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent, view, 3, (ViewDataBinding.IncludedLayouts) null, CommonToolbarBindingImpl.c);
                    ImageView imageView = (ImageView) mapBindings[1];
                    TextView textView = (TextView) mapBindings[2];
                    ViewDataBinding commonToolbarBinding = new CommonToolbarBinding(dataBindingComponent, view, (ConstraintLayout) mapBindings[0]);
                    commonToolbarBinding.b = -1;
                    commonToolbarBinding.a.setTag((Object) null);
                    commonToolbarBinding.setRootTag(view);
                    commonToolbarBinding.invalidateAll();
                    return commonToolbarBinding;
                }
                throw new IllegalArgumentException(l.a(tag, "The tag for common_toolbar is invalid. Received: "));
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
