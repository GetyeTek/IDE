package com.huawei.payment.lib.image;

public final class R$menu {
    public static final int ucrop_menu = 2131689479;

    private R$menu() {
    }
}
