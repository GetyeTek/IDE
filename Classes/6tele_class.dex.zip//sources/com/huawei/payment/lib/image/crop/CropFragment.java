package com.huawei.payment.lib.image.crop;

import T7.g;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.widget.TextView;
import androidx.annotation.ColorInt;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.huawei.payment.lib.image.R$id;
import com.huawei.payment.lib.image.crop.view.CropView;
import com.huawei.payment.lib.image.crop.view.GestureCropImageView;
import com.huawei.payment.lib.image.crop.view.OverlayView;
import com.huawei.payment.lib.image.crop.view.TransformView;
import java.util.ArrayList;
import java.util.Locale;

public class CropFragment extends Fragment {
    public static final Bitmap.CompressFormat A = Bitmap.CompressFormat.JPEG;
    public final ArrayList a = new ArrayList();
    public c b;
    public int c;
    public int d;
    public int e;
    public int f;
    @ColorInt
    public int g;
    public int h;
    public boolean i;
    public CropView j;
    public GestureCropImageView k;
    public OverlayView l;
    public ViewGroup m;
    public ViewGroup n;
    public ViewGroup o;
    public ViewGroup p;
    public ViewGroup q;
    public ViewGroup r;
    public TextView s;
    public TextView t;
    public View u;
    public final a v = new a();
    public Bitmap.CompressFormat w = A;
    public int x = 90;
    public int[] y = {1, 2, 3};
    public final b z = new b();

    public class a implements TransformView.a {
        public a() {
        }

        public final void a(float f) {
            TextView textView = CropFragment.this.s;
            if (textView != null) {
                textView.setText(String.format(Locale.getDefault(), "%.1f°", new Object[]{Float.valueOf(f)}));
            }
        }

        public final void b() {
            CropFragment cropFragment = CropFragment.this;
            cropFragment.j.animate().alpha(1.0f).setDuration(300).setInterpolator(new AccelerateInterpolator());
            cropFragment.u.setClickable(false);
            cropFragment.b.a();
        }

        public final void c(@NonNull Exception exc) {
            c cVar = CropFragment.this.b;
            CropFragment.v0(exc);
            cVar.b();
        }

        public final void d(float f) {
            TextView textView = CropFragment.this.t;
            if (textView != null) {
                textView.setText(String.format(Locale.getDefault(), "%d%%", new Object[]{Integer.valueOf((int) (f * 100.0f))}));
            }
        }
    }

    public class b implements View.OnClickListener {
        public b() {
        }

        public final void onClick(View view) {
            if (!view.isSelected()) {
                int id = view.getId();
                Bitmap.CompressFormat compressFormat = CropFragment.A;
                CropFragment.this.x0(id);
            }
        }
    }

    public static class c {
    }

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, com.huawei.payment.lib.image.crop.CropFragment$c] */
    public static c v0(Throwable th) {
        new Intent().putExtra("com.huawei.payment.lib.image.Error", th);
        return new Object();
    }

    public final void onAttach(@NonNull Context context) {
        CropFragment.super.onAttach(context);
        if (getParentFragment() instanceof c) {
            this.b = getParentFragment();
        } else if (context instanceof c) {
            this.b = (c) context;
        } else {
            throw new IllegalArgumentException(context + " must implement CropFragmentListener");
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: androidx.fragment.app.Fragment} */
    /* JADX WARNING: type inference failed for: r0v17, types: [com.huawei.payment.lib.image.crop.view.GestureCropImageView, android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
    /* JADX WARNING: Multi-variable type inference failed */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r24, @androidx.annotation.Nullable android.view.ViewGroup r25, @androidx.annotation.Nullable android.os.Bundle r26) {
        /*
            r23 = this;
            r1 = r23
            int r0 = com.huawei.payment.lib.image.R$layout.ucrop_fragment_ucrop
            r2 = 0
            r3 = r24
            r4 = r25
            android.view.View r3 = r3.inflate(r0, r4, r2)
            android.os.Bundle r0 = r23.getArguments()
            androidx.fragment.app.FragmentActivity r4 = r23.getActivity()
            if (r4 == 0) goto L_0x0035
            android.view.Window r5 = r4.getWindow()
            if (r5 == 0) goto L_0x0035
            android.view.Window r5 = r4.getWindow()
            int r5 = r5.getStatusBarColor()
            T7.g.a = r5
            android.view.Window r4 = r4.getWindow()
            android.view.View r4 = r4.getDecorView()
            int r4 = r4.getSystemUiVisibility()
            T7.g.b = r4
        L_0x0035:
            android.content.Context r4 = r3.getContext()
            int r5 = com.huawei.payment.lib.image.R$color.ucrop_color_statusbar
            int r4 = androidx.core.content.ContextCompat.getColor(r4, r5)
            java.lang.String r5 = "com.huawei.payment.lib.image.StatusBarColor"
            int r4 = r0.getInt(r5, r4)
            r1.d = r4
            androidx.fragment.app.FragmentActivity r4 = r23.getActivity()
            int r5 = r1.d
            if (r4 == 0) goto L_0x005c
            android.view.Window r6 = r4.getWindow()
            if (r6 == 0) goto L_0x005c
            android.view.Window r4 = r4.getWindow()
            r4.setStatusBarColor(r5)
        L_0x005c:
            androidx.fragment.app.FragmentActivity r4 = r23.getActivity()
            r5 = 1
            T7.g.a(r4, r5)
            android.content.Context r4 = r3.getContext()
            int r6 = com.huawei.payment.lib.image.R$color.ucrop_color_toolbar
            int r4 = androidx.core.content.ContextCompat.getColor(r4, r6)
            java.lang.String r6 = "com.huawei.payment.lib.image.ToolbarColor"
            int r4 = r0.getInt(r6, r4)
            r1.e = r4
            android.content.Context r4 = r3.getContext()
            int r6 = com.huawei.payment.lib.image.R$color.ucrop_color_toolbar_widget
            int r4 = androidx.core.content.ContextCompat.getColor(r4, r6)
            java.lang.String r6 = "com.huawei.payment.lib.image.UcropToolbarWidgetColor"
            int r4 = r0.getInt(r6, r4)
            r1.f = r4
            int r4 = com.huawei.payment.lib.image.R$id.toolbar
            android.view.View r4 = r3.findViewById(r4)
            androidx.appcompat.widget.Toolbar r4 = (androidx.appcompat.widget.Toolbar) r4
            int r6 = r1.e
            r4.setBackgroundColor(r6)
            int r6 = r1.f
            r4.setTitleTextColor(r6)
            int r6 = com.huawei.payment.lib.image.R$drawable.ucrop_ic_cross
            r4.setNavigationIcon(r6)
            com.huawei.payment.lib.image.crop.a r6 = new com.huawei.payment.lib.image.crop.a
            r6.<init>(r1)
            r4.setNavigationOnClickListener(r6)
            int r6 = com.huawei.payment.lib.image.R$string.ucrop_label_edit_photo
            r4.setTitle(r6)
            int r6 = com.huawei.payment.lib.image.R$menu.ucrop_menu
            r4.inflateMenu(r6)
            android.view.Menu r6 = r4.getMenu()
            int r7 = com.huawei.payment.lib.image.R$id.menu_loader
            android.view.MenuItem r6 = r6.findItem(r7)
            r6.setVisible(r2)
            P7.h r6 = new P7.h
            r6.<init>(r1)
            r4.setOnMenuItemClickListener(r6)
            android.content.Context r4 = r3.getContext()
            int r6 = com.huawei.payment.lib.image.R$color.ucrop_color_widget_active
            int r4 = androidx.core.content.ContextCompat.getColor(r4, r6)
            java.lang.String r6 = "com.huawei.payment.lib.image.UcropColorControlsWidgetActive"
            int r4 = r0.getInt(r6, r4)
            r1.c = r4
            android.content.Context r4 = r3.getContext()
            int r6 = com.huawei.payment.lib.image.R$color.ucrop_color_default_logo
            int r4 = androidx.core.content.ContextCompat.getColor(r4, r6)
            java.lang.String r6 = "com.huawei.payment.lib.image.UcropLogoColor"
            int r4 = r0.getInt(r6, r4)
            r1.h = r4
            java.lang.String r4 = "com.huawei.payment.lib.image.HideBottomControls"
            boolean r4 = r0.getBoolean(r4, r2)
            r4 = r4 ^ r5
            r1.i = r4
            android.content.Context r4 = r3.getContext()
            int r6 = com.huawei.payment.lib.image.R$color.ucrop_color_crop_background
            int r4 = androidx.core.content.ContextCompat.getColor(r4, r6)
            java.lang.String r6 = "com.huawei.payment.lib.image.UcropRootViewBackgroundColor"
            int r4 = r0.getInt(r6, r4)
            r1.g = r4
            int r4 = com.huawei.payment.lib.image.R$id.ucrop
            android.view.View r4 = r3.findViewById(r4)
            com.huawei.payment.lib.image.crop.view.CropView r4 = (com.huawei.payment.lib.image.crop.view.CropView) r4
            r1.j = r4
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r4 = r4.getCropImageView()
            r1.k = r4
            com.huawei.payment.lib.image.crop.view.CropView r4 = r1.j
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r4.getOverlayView()
            r1.l = r4
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r4 = r1.k
            com.huawei.payment.lib.image.crop.CropFragment$a r6 = r1.v
            r4.setTransformImageListener(r6)
            int r4 = com.huawei.payment.lib.image.R$id.image_view_logo
            android.view.View r4 = r3.findViewById(r4)
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            int r6 = r1.h
            android.graphics.PorterDuff$Mode r7 = android.graphics.PorterDuff.Mode.SRC_ATOP
            r4.setColorFilter(r6, r7)
            int r4 = com.huawei.payment.lib.image.R$id.ucrop_frame
            android.view.View r6 = r3.findViewById(r4)
            int r7 = r1.g
            r6.setBackgroundColor(r7)
            com.huawei.payment.lib.image.crop.c r6 = r1.b
            r6.a()
            boolean r6 = r1.i
            r7 = -1
            r9 = 0
            r10 = 0
            java.lang.String r11 = "com.huawei.payment.lib.image.AspectRatioOptions"
            java.lang.String r12 = "com.huawei.payment.lib.image.AspectRatioSelectedByDefault"
            if (r6 == 0) goto L_0x0325
            int r4 = com.huawei.payment.lib.image.R$id.controls_wrapper
            android.view.View r4 = r3.findViewById(r4)
            android.view.ViewGroup r4 = (android.view.ViewGroup) r4
            r4.setVisibility(r2)
            android.content.Context r6 = r23.getContext()
            android.view.LayoutInflater r6 = android.view.LayoutInflater.from(r6)
            int r13 = com.huawei.payment.lib.image.R$layout.ucrop_controls
            r6.inflate(r13, r4, r5)
            int r4 = com.huawei.payment.lib.image.R$id.state_aspect_ratio
            android.view.View r4 = r3.findViewById(r4)
            android.view.ViewGroup r4 = (android.view.ViewGroup) r4
            r1.m = r4
            com.huawei.payment.lib.image.crop.CropFragment$b r6 = r1.z
            r4.setOnClickListener(r6)
            int r4 = com.huawei.payment.lib.image.R$id.state_rotate
            android.view.View r4 = r3.findViewById(r4)
            android.view.ViewGroup r4 = (android.view.ViewGroup) r4
            r1.n = r4
            r4.setOnClickListener(r6)
            int r4 = com.huawei.payment.lib.image.R$id.state_scale
            android.view.View r4 = r3.findViewById(r4)
            android.view.ViewGroup r4 = (android.view.ViewGroup) r4
            r1.o = r4
            r4.setOnClickListener(r6)
            int r4 = com.huawei.payment.lib.image.R$id.layout_aspect_ratio
            android.view.View r6 = r3.findViewById(r4)
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            r1.p = r6
            int r6 = com.huawei.payment.lib.image.R$id.layout_rotate_wheel
            android.view.View r6 = r3.findViewById(r6)
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            r1.q = r6
            int r6 = com.huawei.payment.lib.image.R$id.layout_scale_wheel
            android.view.View r6 = r3.findViewById(r6)
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            r1.r = r6
            int r6 = r0.getInt(r12, r2)
            java.util.ArrayList r13 = r0.getParcelableArrayList(r11)
            r14 = 1065353216(0x3f800000, float:1.0)
            if (r13 == 0) goto L_0x01bf
            boolean r15 = r13.isEmpty()
            if (r15 == 0) goto L_0x0201
        L_0x01bf:
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            com.huawei.payment.lib.image.crop.model.AspectRatio r6 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r6.<init>(r10, r14, r14)
            r13.add(r6)
            com.huawei.payment.lib.image.crop.model.AspectRatio r6 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r15 = 1077936128(0x40400000, float:3.0)
            r8 = 1082130432(0x40800000, float:4.0)
            r6.<init>(r10, r15, r8)
            r13.add(r6)
            com.huawei.payment.lib.image.crop.model.AspectRatio r6 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            int r8 = com.huawei.payment.lib.image.R$string.ucrop_label_original
            java.lang.String r8 = r1.getString(r8)
            java.lang.String r8 = r8.toUpperCase()
            r6.<init>(r8, r9, r9)
            r13.add(r6)
            com.huawei.payment.lib.image.crop.model.AspectRatio r6 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r8 = 1073741824(0x40000000, float:2.0)
            r6.<init>(r10, r15, r8)
            r13.add(r6)
            com.huawei.payment.lib.image.crop.model.AspectRatio r6 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r8 = 1098907648(0x41800000, float:16.0)
            r15 = 1091567616(0x41100000, float:9.0)
            r6.<init>(r10, r8, r15)
            r13.add(r6)
            r6 = 2
        L_0x0201:
            android.view.View r4 = r3.findViewById(r4)
            android.widget.LinearLayout r4 = (android.widget.LinearLayout) r4
            android.widget.LinearLayout$LayoutParams r8 = new android.widget.LinearLayout$LayoutParams
            r8.<init>(r2, r7)
            r8.weight = r14
            java.util.Iterator r13 = r13.iterator()
        L_0x0212:
            boolean r14 = r13.hasNext()
            java.util.ArrayList r15 = r1.a
            if (r14 == 0) goto L_0x0247
            java.lang.Object r14 = r13.next()
            com.huawei.payment.lib.image.crop.model.AspectRatio r14 = (com.huawei.payment.lib.image.crop.model.AspectRatio) r14
            android.view.LayoutInflater r7 = r23.getLayoutInflater()
            int r9 = com.huawei.payment.lib.image.R$layout.ucrop_aspect_ratio
            android.view.View r7 = r7.inflate(r9, r10)
            android.widget.FrameLayout r7 = (android.widget.FrameLayout) r7
            r7.setLayoutParams(r8)
            android.view.View r9 = r7.getChildAt(r2)
            com.huawei.payment.lib.image.crop.view.widget.AspectTextView r9 = (com.huawei.payment.lib.image.crop.view.widget.AspectTextView) r9
            int r10 = r1.c
            r9.setActiveColor(r10)
            r9.setAspectRatio(r14)
            r4.addView(r7)
            r15.add(r7)
            r7 = -1
            r9 = 0
            r10 = 0
            goto L_0x0212
        L_0x0247:
            java.lang.Object r4 = r15.get(r6)
            android.view.ViewGroup r4 = (android.view.ViewGroup) r4
            r4.setSelected(r5)
            java.util.Iterator r4 = r15.iterator()
        L_0x0254:
            boolean r6 = r4.hasNext()
            if (r6 == 0) goto L_0x0269
            java.lang.Object r6 = r4.next()
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            P7.i r7 = new P7.i
            r7.<init>(r1)
            r6.setOnClickListener(r7)
            goto L_0x0254
        L_0x0269:
            int r4 = com.huawei.payment.lib.image.R$id.text_view_rotate
            android.view.View r4 = r3.findViewById(r4)
            android.widget.TextView r4 = (android.widget.TextView) r4
            r1.s = r4
            int r4 = com.huawei.payment.lib.image.R$id.rotate_scroll_wheel
            android.view.View r6 = r3.findViewById(r4)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r6 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r6
            P7.j r7 = new P7.j
            r7.<init>(r1)
            r6.setScrollingListener(r7)
            android.view.View r4 = r3.findViewById(r4)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r4 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r4
            int r6 = r1.c
            r4.setMiddleLineColor(r6)
            int r4 = com.huawei.payment.lib.image.R$id.wrapper_reset_rotate
            android.view.View r4 = r3.findViewById(r4)
            P7.f r6 = new P7.f
            r7 = 0
            r6.<init>(r1, r7)
            r4.setOnClickListener(r6)
            int r4 = com.huawei.payment.lib.image.R$id.wrapper_rotate_by_angle
            android.view.View r4 = r3.findViewById(r4)
            P7.g r6 = new P7.g
            r6.<init>(r1, r7)
            r4.setOnClickListener(r6)
            int r4 = r1.c
            android.widget.TextView r6 = r1.s
            if (r6 == 0) goto L_0x02b4
            r6.setTextColor(r4)
        L_0x02b4:
            int r4 = com.huawei.payment.lib.image.R$id.text_view_scale
            android.view.View r4 = r3.findViewById(r4)
            android.widget.TextView r4 = (android.widget.TextView) r4
            r1.t = r4
            int r4 = com.huawei.payment.lib.image.R$id.scale_scroll_wheel
            android.view.View r6 = r3.findViewById(r4)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r6 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r6
            P7.k r7 = new P7.k
            r7.<init>(r1)
            r6.setScrollingListener(r7)
            android.view.View r4 = r3.findViewById(r4)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r4 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r4
            int r6 = r1.c
            r4.setMiddleLineColor(r6)
            int r4 = r1.c
            android.widget.TextView r6 = r1.t
            if (r6 == 0) goto L_0x02e2
            r6.setTextColor(r4)
        L_0x02e2:
            int r4 = com.huawei.payment.lib.image.R$id.image_view_state_scale
            android.view.View r4 = r3.findViewById(r4)
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            int r6 = com.huawei.payment.lib.image.R$id.image_view_state_rotate
            android.view.View r6 = r3.findViewById(r6)
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            int r7 = com.huawei.payment.lib.image.R$id.image_view_state_aspect_ratio
            android.view.View r7 = r3.findViewById(r7)
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            T7.f r8 = new T7.f
            android.graphics.drawable.Drawable r9 = r4.getDrawable()
            int r10 = r1.c
            r8.<init>(r10, r9)
            r4.setImageDrawable(r8)
            T7.f r4 = new T7.f
            android.graphics.drawable.Drawable r8 = r6.getDrawable()
            int r9 = r1.c
            r4.<init>(r9, r8)
            r6.setImageDrawable(r4)
            T7.f r4 = new T7.f
            android.graphics.drawable.Drawable r6 = r7.getDrawable()
            int r8 = r1.c
            r4.<init>(r8, r6)
            r7.setImageDrawable(r4)
            goto L_0x0338
        L_0x0325:
            android.view.View r6 = r3.findViewById(r4)
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            android.widget.RelativeLayout$LayoutParams r6 = (android.widget.RelativeLayout.LayoutParams) r6
            r6.bottomMargin = r2
            android.view.View r4 = r3.findViewById(r4)
            r4.requestLayout()
        L_0x0338:
            java.lang.String r4 = "com.huawei.payment.lib.image.InputUri"
            android.os.Parcelable r4 = r0.getParcelable(r4)
            r18 = r4
            android.net.Uri r18 = (android.net.Uri) r18
            java.lang.String r4 = "com.huawei.payment.lib.image.OutputUri"
            android.os.Parcelable r4 = r0.getParcelable(r4)
            r19 = r4
            android.net.Uri r19 = (android.net.Uri) r19
            java.lang.String r4 = "com.huawei.payment.lib.image.CompressionFormatName"
            java.lang.String r4 = r0.getString(r4)
            boolean r6 = android.text.TextUtils.isEmpty(r4)
            if (r6 != 0) goto L_0x035d
            android.graphics.Bitmap$CompressFormat r10 = android.graphics.Bitmap.CompressFormat.valueOf(r4)
            goto L_0x035e
        L_0x035d:
            r10 = 0
        L_0x035e:
            if (r10 != 0) goto L_0x0362
            android.graphics.Bitmap$CompressFormat r10 = A
        L_0x0362:
            r1.w = r10
            java.lang.String r4 = "com.huawei.payment.lib.image.CompressionQuality"
            r6 = 90
            int r4 = r0.getInt(r4, r6)
            r1.x = r4
            java.lang.String r4 = "com.huawei.payment.lib.image.AllowedGestures"
            int[] r4 = r0.getIntArray(r4)
            if (r4 == 0) goto L_0x037c
            int r6 = r4.length
            r7 = 3
            if (r6 != r7) goto L_0x037c
            r1.y = r4
        L_0x037c:
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r4 = r1.k
            java.lang.String r6 = "com.huawei.payment.lib.image.MaxBitmapSize"
            int r6 = r0.getInt(r6, r2)
            r4.setMaxBitmapSize(r6)
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r4 = r1.k
            java.lang.String r6 = "com.huawei.payment.lib.image.MaxScaleMultiplier"
            r7 = 1092616192(0x41200000, float:10.0)
            float r6 = r0.getFloat(r6, r7)
            r4.setMaxScaleMultiplier(r6)
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r4 = r1.k
            java.lang.String r6 = "com.huawei.payment.lib.image.ImageToCropBoundsAnimDuration"
            r7 = 500(0x1f4, float:7.0E-43)
            int r6 = r0.getInt(r6, r7)
            long r6 = (long) r6
            r4.setImageToWrapCropBoundsAnimDuration(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            java.lang.String r6 = "com.huawei.payment.lib.image.FreeStyleCrop"
            boolean r6 = r0.getBoolean(r6, r2)
            r4.setFreestyleCropEnabled(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            android.content.res.Resources r6 = r23.getResources()
            int r7 = com.huawei.payment.lib.image.R$color.ucrop_color_default_dimmed
            int r6 = r6.getColor(r7)
            java.lang.String r7 = "com.huawei.payment.lib.image.DimmedLayerColor"
            int r6 = r0.getInt(r7, r6)
            r4.setDimmedColor(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            java.lang.String r6 = "com.huawei.payment.lib.image.CircleDimmedLayer"
            boolean r6 = r0.getBoolean(r6, r2)
            r4.setCircleDimmedLayer(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            java.lang.String r6 = "com.huawei.payment.lib.image.ShowCropFrame"
            boolean r6 = r0.getBoolean(r6, r5)
            r4.setShowCropFrame(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            android.content.res.Resources r6 = r23.getResources()
            int r7 = com.huawei.payment.lib.image.R$color.ucrop_color_default_crop_frame
            int r6 = r6.getColor(r7)
            java.lang.String r7 = "com.huawei.payment.lib.image.CropFrameColor"
            int r6 = r0.getInt(r7, r6)
            r4.setCropFrameColor(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            android.content.res.Resources r6 = r23.getResources()
            int r7 = com.huawei.payment.lib.image.R$dimen.ucrop_default_crop_frame_stoke_width
            int r6 = r6.getDimensionPixelSize(r7)
            java.lang.String r7 = "com.huawei.payment.lib.image.CropFrameStrokeWidth"
            int r6 = r0.getInt(r7, r6)
            r4.setCropFrameStrokeWidth(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            java.lang.String r6 = "com.huawei.payment.lib.image.ShowCropGrid"
            boolean r6 = r0.getBoolean(r6, r5)
            r4.setShowCropGrid(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            java.lang.String r6 = "com.huawei.payment.lib.image.CropGridRowCount"
            r7 = 2
            int r6 = r0.getInt(r6, r7)
            r4.setCropGridRowCount(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            java.lang.String r6 = "com.huawei.payment.lib.image.CropGridColumnCount"
            int r6 = r0.getInt(r6, r7)
            r4.setCropGridColumnCount(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            android.content.res.Resources r6 = r23.getResources()
            int r7 = com.huawei.payment.lib.image.R$color.ucrop_color_default_crop_grid
            int r6 = r6.getColor(r7)
            java.lang.String r7 = "com.huawei.payment.lib.image.CropGridColor"
            int r6 = r0.getInt(r7, r6)
            r4.setCropGridColor(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r4 = r1.l
            android.content.res.Resources r6 = r23.getResources()
            int r7 = com.huawei.payment.lib.image.R$dimen.ucrop_default_crop_grid_stoke_width
            int r6 = r6.getDimensionPixelSize(r7)
            java.lang.String r7 = "com.huawei.payment.lib.image.CropGridStrokeWidth"
            int r6 = r0.getInt(r7, r6)
            r4.setCropGridStrokeWidth(r6)
            java.lang.String r4 = "com.huawei.payment.lib.image.AspectRatioX"
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r4 = r0.getFloat(r4, r6)
            java.lang.String r7 = "com.huawei.payment.lib.image.AspectRatioY"
            float r6 = r0.getFloat(r7, r6)
            int r7 = r0.getInt(r12, r2)
            java.util.ArrayList r8 = r0.getParcelableArrayList(r11)
            r9 = 0
            int r10 = (r4 > r9 ? 1 : (r4 == r9 ? 0 : -1))
            if (r10 < 0) goto L_0x0486
            int r10 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            if (r10 < 0) goto L_0x0486
            android.view.ViewGroup r7 = r1.m
            if (r7 == 0) goto L_0x0476
            r8 = 8
            r7.setVisibility(r8)
        L_0x0476:
            float r4 = r4 / r6
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r6 = r1.k
            boolean r7 = java.lang.Float.isNaN(r4)
            if (r7 == 0) goto L_0x0481
            r9 = 0
            goto L_0x0482
        L_0x0481:
            r9 = r4
        L_0x0482:
            r6.setTargetAspectRatio(r9)
            goto L_0x04b8
        L_0x0486:
            if (r8 == 0) goto L_0x04b2
            int r4 = r8.size()
            if (r7 >= r4) goto L_0x04b2
            java.lang.Object r4 = r8.get(r7)
            com.huawei.payment.lib.image.crop.model.AspectRatio r4 = (com.huawei.payment.lib.image.crop.model.AspectRatio) r4
            float r4 = r4.getAspectRatioX()
            java.lang.Object r6 = r8.get(r7)
            com.huawei.payment.lib.image.crop.model.AspectRatio r6 = (com.huawei.payment.lib.image.crop.model.AspectRatio) r6
            float r6 = r6.getAspectRatioY()
            float r4 = r4 / r6
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r6 = r1.k
            boolean r7 = java.lang.Float.isNaN(r4)
            if (r7 == 0) goto L_0x04ad
            r9 = 0
            goto L_0x04ae
        L_0x04ad:
            r9 = r4
        L_0x04ae:
            r6.setTargetAspectRatio(r9)
            goto L_0x04b8
        L_0x04b2:
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r4 = r1.k
            r6 = 0
            r4.setTargetAspectRatio(r6)
        L_0x04b8:
            java.lang.String r4 = "com.huawei.payment.lib.image.MaxSizeX"
            int r4 = r0.getInt(r4, r2)
            java.lang.String r6 = "com.huawei.payment.lib.image.MaxSizeY"
            int r0 = r0.getInt(r6, r2)
            if (r4 <= 0) goto L_0x04d2
            if (r0 <= 0) goto L_0x04d2
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r6 = r1.k
            r6.setMaxResultImageSizeX(r4)
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r4 = r1.k
            r4.setMaxResultImageSizeY(r0)
        L_0x04d2:
            if (r18 == 0) goto L_0x0502
            if (r19 == 0) goto L_0x0502
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r0 = r1.k     // Catch:{ Exception -> 0x04f8 }
            int r21 = r0.getMaxBitmapSize()     // Catch:{ Exception -> 0x04f8 }
            android.content.Context r17 = r0.getContext()     // Catch:{ Exception -> 0x04f8 }
            com.huawei.payment.lib.image.crop.view.a r4 = new com.huawei.payment.lib.image.crop.view.a     // Catch:{ Exception -> 0x04f8 }
            r4.<init>(r0)     // Catch:{ Exception -> 0x04f8 }
            S7.b r0 = new S7.b     // Catch:{ Exception -> 0x04f8 }
            r16 = r0
            r20 = r21
            r22 = r4
            r16.<init>(r17, r18, r19, r20, r21, r22)     // Catch:{ Exception -> 0x04f8 }
            java.util.concurrent.Executor r4 = android.os.AsyncTask.THREAD_POOL_EXECUTOR     // Catch:{ Exception -> 0x04f8 }
            java.lang.Void[] r6 = new java.lang.Void[r2]     // Catch:{ Exception -> 0x04f8 }
            r0.executeOnExecutor(r4, r6)     // Catch:{ Exception -> 0x04f8 }
            goto L_0x0515
        L_0x04f8:
            r0 = move-exception
            com.huawei.payment.lib.image.crop.c r4 = r1.b
            v0(r0)
            r4.b()
            goto L_0x0515
        L_0x0502:
            com.huawei.payment.lib.image.crop.c r0 = r1.b
            java.lang.NullPointerException r4 = new java.lang.NullPointerException
            int r6 = com.huawei.payment.lib.image.R$string.ucrop_error_input_data
            java.lang.String r6 = r1.getString(r6)
            r4.<init>(r6)
            v0(r4)
            r0.b()
        L_0x0515:
            boolean r0 = r1.i
            if (r0 == 0) goto L_0x052d
            android.view.ViewGroup r0 = r1.m
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x0527
            int r0 = com.huawei.payment.lib.image.R$id.state_aspect_ratio
            r1.x0(r0)
            goto L_0x0530
        L_0x0527:
            int r0 = com.huawei.payment.lib.image.R$id.state_scale
            r1.x0(r0)
            goto L_0x0530
        L_0x052d:
            r1.w0(r2)
        L_0x0530:
            android.view.View r0 = r1.u
            if (r0 != 0) goto L_0x054f
            android.view.View r0 = new android.view.View
            android.content.Context r2 = r23.getContext()
            r0.<init>(r2)
            r1.u = r0
            android.widget.RelativeLayout$LayoutParams r0 = new android.widget.RelativeLayout$LayoutParams
            r2 = -1
            r0.<init>(r2, r2)
            android.view.View r2 = r1.u
            r2.setLayoutParams(r0)
            android.view.View r0 = r1.u
            r0.setClickable(r5)
        L_0x054f:
            int r0 = com.huawei.payment.lib.image.R$id.ucrop_photobox
            android.view.View r0 = r3.findViewById(r0)
            android.widget.RelativeLayout r0 = (android.widget.RelativeLayout) r0
            android.view.View r2 = r1.u
            r0.addView(r2)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.payment.lib.image.crop.CropFragment.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onDestroyView() {
        FragmentActivity activity = getActivity();
        if (!(activity == null || activity.getWindow() == null)) {
            if (g.a != Integer.MAX_VALUE) {
                activity.getWindow().setStatusBarColor(g.a);
            }
            if (g.b != Integer.MAX_VALUE) {
                activity.getWindow().getDecorView().setSystemUiVisibility(g.b);
            }
        }
        CropFragment.super.onDestroyView();
    }

    public final void w0(int i2) {
        boolean z2;
        GestureCropImageView gestureCropImageView = this.k;
        int i3 = this.y[i2];
        boolean z3 = false;
        if (i3 == 3 || i3 == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        gestureCropImageView.setScaleEnabled(z2);
        GestureCropImageView gestureCropImageView2 = this.k;
        int i4 = this.y[i2];
        if (i4 == 3 || i4 == 2) {
            z3 = true;
        }
        gestureCropImageView2.setRotateEnabled(z3);
    }

    public final void x0(@IdRes int i2) {
        boolean z2;
        boolean z3;
        boolean z4;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        if (this.i) {
            ViewGroup viewGroup = this.m;
            int i9 = R$id.state_aspect_ratio;
            if (i2 == i9) {
                z2 = true;
            } else {
                z2 = false;
            }
            viewGroup.setSelected(z2);
            ViewGroup viewGroup2 = this.n;
            int i10 = R$id.state_rotate;
            if (i2 == i10) {
                z3 = true;
            } else {
                z3 = false;
            }
            viewGroup2.setSelected(z3);
            ViewGroup viewGroup3 = this.o;
            int i11 = R$id.state_scale;
            if (i2 == i11) {
                z4 = true;
            } else {
                z4 = false;
            }
            viewGroup3.setSelected(z4);
            ViewGroup viewGroup4 = this.p;
            int i12 = 8;
            if (i2 == i9) {
                i3 = 0;
            } else {
                i3 = 8;
            }
            viewGroup4.setVisibility(i3);
            ViewGroup viewGroup5 = this.q;
            if (i2 == i10) {
                i4 = 0;
            } else {
                i4 = 8;
            }
            viewGroup5.setVisibility(i4);
            ViewGroup viewGroup6 = this.r;
            if (i2 == i11) {
                i5 = 0;
            } else {
                i5 = 8;
            }
            viewGroup6.setVisibility(i5);
            getView();
            View findViewById = this.o.findViewById(R$id.text_view_scale);
            if (i2 == i11) {
                i6 = 0;
            } else {
                i6 = 8;
            }
            findViewById.setVisibility(i6);
            View findViewById2 = this.m.findViewById(R$id.text_view_crop);
            if (i2 == i9) {
                i7 = 0;
            } else {
                i7 = 8;
            }
            findViewById2.setVisibility(i7);
            View findViewById3 = this.n.findViewById(R$id.text_view_rotate);
            if (i2 == i10) {
                i12 = 0;
            }
            findViewById3.setVisibility(i12);
            if (i2 == i11) {
                w0(0);
            } else if (i2 == i10) {
                w0(1);
            } else {
                w0(2);
            }
        }
    }
}
