package com.huawei.payment.lib.image.crop.view;

import Q7.c;
import U7.b;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.ColorInt;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import com.huawei.payment.lib.image.R$dimen;

public class OverlayView extends View {
    public boolean A;
    public final RectF a;
    public final RectF b;
    public final Path c;
    public final Paint d;
    public final Paint e;
    public final Paint f;
    public final Paint g;
    public final int h;
    public final int i;
    public final int j;
    public int k;
    public int l;
    public float[] m;
    public int n;
    public int o;
    public float p;
    public float[] q;
    public boolean r;
    public boolean s;
    public boolean t;
    public int u;
    public int v;
    public float w;
    public float x;
    public int y;
    public c z;

    public OverlayView(Context context) {
        this(context, (AttributeSet) null);
    }

    public final void a() {
        RectF rectF = this.a;
        float f2 = rectF.left;
        float f3 = rectF.top;
        float f4 = rectF.right;
        float f5 = rectF.bottom;
        this.m = new float[]{f2, f3, f4, f3, f4, f5, f2, f5};
        rectF.centerX();
        rectF.centerY();
        this.q = null;
        Path path = this.c;
        path.reset();
        path.addCircle(rectF.centerX(), rectF.centerY(), Math.min(rectF.width(), rectF.height()) / 2.0f, Path.Direction.CW);
    }

    @NonNull
    public RectF getCropViewRect() {
        return this.a;
    }

    public int getFreestyleCropMode() {
        return this.v;
    }

    public c getOverlayViewChangeListener() {
        return this.z;
    }

    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        boolean z2 = this.t;
        RectF rectF = this.a;
        if (z2) {
            canvas.clipPath(this.c, Region.Op.DIFFERENCE);
        } else {
            canvas.clipRect(rectF, Region.Op.DIFFERENCE);
        }
        canvas.drawColor(this.u);
        canvas.restore();
        if (this.t) {
            canvas.drawCircle(rectF.centerX(), rectF.centerY(), Math.min(rectF.width(), rectF.height()) / 2.0f, this.d);
        }
        if (this.s) {
            if (this.q == null && !rectF.isEmpty()) {
                this.q = new float[((this.o * 4) + (this.n * 4))];
                int i2 = 0;
                for (int i3 = 0; i3 < this.n; i3++) {
                    float[] fArr = this.q;
                    fArr[i2] = rectF.left;
                    float f2 = ((float) i3) + 1.0f;
                    fArr[i2 + 1] = ((f2 / ((float) (this.n + 1))) * rectF.height()) + rectF.top;
                    float[] fArr2 = this.q;
                    int i4 = i2 + 3;
                    fArr2[i2 + 2] = rectF.right;
                    i2 += 4;
                    fArr2[i4] = ((f2 / ((float) (this.n + 1))) * rectF.height()) + rectF.top;
                }
                for (int i5 = 0; i5 < this.o; i5++) {
                    float f3 = ((float) i5) + 1.0f;
                    this.q[i2] = ((f3 / ((float) (this.o + 1))) * rectF.width()) + rectF.left;
                    float[] fArr3 = this.q;
                    fArr3[i2 + 1] = rectF.top;
                    int i6 = i2 + 3;
                    fArr3[i2 + 2] = ((f3 / ((float) (this.o + 1))) * rectF.width()) + rectF.left;
                    i2 += 4;
                    this.q[i6] = rectF.bottom;
                }
            }
            float[] fArr4 = this.q;
            if (fArr4 != null) {
                canvas.drawLines(fArr4, this.e);
            }
        }
        if (this.r) {
            canvas.drawRect(rectF, this.f);
        }
        if (this.v != 0) {
            canvas.save();
            RectF rectF2 = this.b;
            rectF2.set(rectF);
            int i7 = this.j;
            float f4 = (float) i7;
            float f5 = (float) (-i7);
            rectF2.inset(f4, f5);
            Region.Op op = Region.Op.DIFFERENCE;
            canvas.clipRect(rectF2, op);
            rectF2.set(rectF);
            rectF2.inset(f5, f4);
            canvas.clipRect(rectF2, op);
            canvas.drawRect(rectF, this.g);
            canvas.restore();
        }
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        if (z2) {
            int paddingLeft = getPaddingLeft();
            int paddingTop = getPaddingTop();
            this.k = (getWidth() - getPaddingRight()) - paddingLeft;
            this.l = (getHeight() - getPaddingBottom()) - paddingTop;
            if (this.A) {
                this.A = false;
                setTargetAspectRatio(this.p);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x0072  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0075  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0080  */
    @android.annotation.SuppressLint({"ClickableViewAccessibility"})
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouchEvent(android.view.MotionEvent r19) {
        /*
            r18 = this;
            r0 = r18
            android.graphics.RectF r1 = r0.a
            boolean r2 = r1.isEmpty()
            if (r2 != 0) goto L_0x000e
            int r2 = r0.v
            if (r2 != 0) goto L_0x0011
        L_0x000e:
            r1 = 0
            goto L_0x01ac
        L_0x0011:
            float r2 = r19.getX()
            float r4 = r19.getY()
            int r5 = r19.getAction()
            r5 = r5 & 255(0xff, float:3.57E-43)
            r6 = 1
            r9 = -1
            if (r5 != 0) goto L_0x008c
            int r5 = r0.h
            double r10 = (double) r5
            r5 = 0
            r12 = -1
        L_0x0028:
            r13 = 8
            if (r5 >= r13) goto L_0x0059
            float[] r13 = r0.m
            r13 = r13[r5]
            float r13 = r2 - r13
            double r13 = (double) r13
            r7 = 4611686018427387904(0x4000000000000000, double:2.0)
            double r13 = java.lang.Math.pow(r13, r7)
            float[] r15 = r0.m
            int r16 = r5 + 1
            r15 = r15[r16]
            float r15 = r4 - r15
            r17 = r4
            double r3 = (double) r15
            double r3 = java.lang.Math.pow(r3, r7)
            double r3 = r3 + r13
            double r3 = java.lang.Math.sqrt(r3)
            int r7 = (r3 > r10 ? 1 : (r3 == r10 ? 0 : -1))
            if (r7 >= 0) goto L_0x0054
            int r12 = r5 / 2
            r10 = r3
        L_0x0054:
            int r5 = r5 + 2
            r4 = r17
            goto L_0x0028
        L_0x0059:
            r17 = r4
            int r3 = r0.v
            if (r3 != r6) goto L_0x006b
            if (r12 >= 0) goto L_0x006b
            r3 = r17
            boolean r1 = r1.contains(r2, r3)
            if (r1 == 0) goto L_0x006d
            r7 = 4
            goto L_0x006e
        L_0x006b:
            r3 = r17
        L_0x006d:
            r7 = r12
        L_0x006e:
            r0.y = r7
            if (r7 == r9) goto L_0x0075
            r16 = 1
            goto L_0x0077
        L_0x0075:
            r16 = 0
        L_0x0077:
            if (r16 != 0) goto L_0x0080
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
            r0.w = r1
            r0.x = r1
            goto L_0x008b
        L_0x0080:
            float r1 = r0.w
            r4 = 0
            int r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r1 >= 0) goto L_0x008b
            r0.w = r2
            r0.x = r3
        L_0x008b:
            return r16
        L_0x008c:
            r3 = r4
            int r4 = r19.getAction()
            r4 = r4 & 255(0xff, float:3.57E-43)
            r5 = 2
            if (r4 != r5) goto L_0x018c
            int r4 = r19.getPointerCount()
            if (r4 != r6) goto L_0x018c
            int r4 = r0.y
            if (r4 == r9) goto L_0x018c
            int r4 = r18.getPaddingLeft()
            float r4 = (float) r4
            float r2 = java.lang.Math.max(r2, r4)
            int r4 = r18.getWidth()
            int r7 = r18.getPaddingRight()
            int r4 = r4 - r7
            float r4 = (float) r4
            float r2 = java.lang.Math.min(r2, r4)
            int r4 = r18.getPaddingTop()
            float r4 = (float) r4
            float r3 = java.lang.Math.max(r3, r4)
            int r4 = r18.getHeight()
            int r7 = r18.getPaddingBottom()
            int r4 = r4 - r7
            float r4 = (float) r4
            float r3 = java.lang.Math.min(r3, r4)
            android.graphics.RectF r4 = r0.b
            r4.set(r1)
            int r7 = r0.y
            if (r7 == 0) goto L_0x013c
            if (r7 == r6) goto L_0x0134
            if (r7 == r5) goto L_0x012c
            r5 = 3
            if (r7 == r5) goto L_0x0124
            r5 = 4
            if (r7 == r5) goto L_0x00e2
            goto L_0x0143
        L_0x00e2:
            float r5 = r0.w
            float r5 = r2 - r5
            float r7 = r0.x
            float r7 = r3 - r7
            r4.offset(r5, r7)
            float r5 = r4.left
            int r7 = r18.getLeft()
            float r7 = (float) r7
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 <= 0) goto L_0x0187
            float r5 = r4.top
            int r7 = r18.getTop()
            float r7 = (float) r7
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 <= 0) goto L_0x0187
            float r5 = r4.right
            int r7 = r18.getRight()
            float r7 = (float) r7
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 >= 0) goto L_0x0187
            float r5 = r4.bottom
            int r7 = r18.getBottom()
            float r7 = (float) r7
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 >= 0) goto L_0x0187
            r1.set(r4)
            r18.a()
            r18.postInvalidate()
            goto L_0x0187
        L_0x0124:
            float r5 = r1.top
            float r7 = r1.right
            r4.set(r2, r5, r7, r3)
            goto L_0x0143
        L_0x012c:
            float r5 = r1.left
            float r7 = r1.top
            r4.set(r5, r7, r2, r3)
            goto L_0x0143
        L_0x0134:
            float r5 = r1.left
            float r7 = r1.bottom
            r4.set(r5, r3, r2, r7)
            goto L_0x0143
        L_0x013c:
            float r5 = r1.right
            float r7 = r1.bottom
            r4.set(r2, r3, r5, r7)
        L_0x0143:
            float r5 = r4.height()
            int r7 = r0.i
            float r7 = (float) r7
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 < 0) goto L_0x0150
            r5 = 1
            goto L_0x0151
        L_0x0150:
            r5 = 0
        L_0x0151:
            float r8 = r4.width()
            int r7 = (r8 > r7 ? 1 : (r8 == r7 ? 0 : -1))
            if (r7 < 0) goto L_0x015c
            r16 = 1
            goto L_0x015e
        L_0x015c:
            r16 = 0
        L_0x015e:
            if (r16 == 0) goto L_0x0163
            float r7 = r4.left
            goto L_0x0165
        L_0x0163:
            float r7 = r1.left
        L_0x0165:
            if (r5 == 0) goto L_0x016a
            float r8 = r4.top
            goto L_0x016c
        L_0x016a:
            float r8 = r1.top
        L_0x016c:
            if (r16 == 0) goto L_0x0171
            float r9 = r4.right
            goto L_0x0173
        L_0x0171:
            float r9 = r1.right
        L_0x0173:
            if (r5 == 0) goto L_0x0178
            float r4 = r4.bottom
            goto L_0x017a
        L_0x0178:
            float r4 = r1.bottom
        L_0x017a:
            r1.set(r7, r8, r9, r4)
            if (r5 != 0) goto L_0x0181
            if (r16 == 0) goto L_0x0187
        L_0x0181:
            r18.a()
            r18.postInvalidate()
        L_0x0187:
            r0.w = r2
            r0.x = r3
            return r6
        L_0x018c:
            int r2 = r19.getAction()
            r2 = r2 & 255(0xff, float:3.57E-43)
            if (r2 != r6) goto L_0x01ab
            r2 = -1082130432(0xffffffffbf800000, float:-1.0)
            r0.w = r2
            r0.x = r2
            r0.y = r9
            Q7.c r2 = r0.z
            if (r2 == 0) goto L_0x01ab
            U7.b r2 = (U7.b) r2
            java.lang.Object r2 = r2.a
            com.huawei.payment.lib.image.crop.view.CropView r2 = (com.huawei.payment.lib.image.crop.view.CropView) r2
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r2.b
            r2.setCropRect(r1)
        L_0x01ab:
            r1 = 0
        L_0x01ac:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.payment.lib.image.crop.view.OverlayView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setCircleDimmedLayer(boolean z2) {
        this.t = z2;
    }

    public void setCropFrameColor(@ColorInt int i2) {
        this.f.setColor(i2);
    }

    public void setCropFrameStrokeWidth(@IntRange(from = 0) int i2) {
        this.f.setStrokeWidth((float) i2);
    }

    public void setCropGridColor(@ColorInt int i2) {
        this.e.setColor(i2);
    }

    public void setCropGridColumnCount(@IntRange(from = 0) int i2) {
        this.o = i2;
        this.q = null;
    }

    public void setCropGridRowCount(@IntRange(from = 0) int i2) {
        this.n = i2;
        this.q = null;
    }

    public void setCropGridStrokeWidth(@IntRange(from = 0) int i2) {
        this.e.setStrokeWidth((float) i2);
    }

    public void setDimmedColor(@ColorInt int i2) {
        this.u = i2;
    }

    public void setFreestyleCropEnabled(boolean z2) {
        this.v = z2 ? 1 : 0;
    }

    public void setFreestyleCropMode(int i2) {
        this.v = i2;
        postInvalidate();
    }

    public void setOverlayViewChangeListener(c cVar) {
        this.z = cVar;
    }

    public void setShowCropFrame(boolean z2) {
        this.r = z2;
    }

    public void setShowCropGrid(boolean z2) {
        this.s = z2;
    }

    public void setTargetAspectRatio(float f2) {
        this.p = f2;
        int i2 = this.k;
        if (i2 > 0) {
            int i3 = (int) (((float) i2) / f2);
            int i4 = this.l;
            RectF rectF = this.a;
            if (i3 > i4) {
                int i5 = (int) (((float) i4) * f2);
                int i6 = (i2 - i5) / 2;
                rectF.set((float) (getPaddingLeft() + i6), (float) getPaddingTop(), (float) (getPaddingLeft() + i5 + i6), (float) (getPaddingTop() + this.l));
            } else {
                int i7 = (i4 - i3) / 2;
                rectF.set((float) getPaddingLeft(), (float) (getPaddingTop() + i7), (float) (getPaddingLeft() + this.k), (float) (getPaddingTop() + i3 + i7));
            }
            c cVar = this.z;
            if (cVar != null) {
                ((CropView) ((b) cVar).a).b.setCropRect(rectF);
            }
            a();
            postInvalidate();
            return;
        }
        this.A = true;
    }

    public OverlayView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.a = new RectF();
        this.b = new RectF();
        this.c = new Path();
        this.d = new Paint(1);
        this.e = new Paint(1);
        this.f = new Paint(1);
        this.g = new Paint(1);
        this.q = null;
        this.v = 0;
        this.w = -1.0f;
        this.x = -1.0f;
        this.y = -1;
        this.h = getResources().getDimensionPixelSize(R$dimen.ucrop_default_crop_rect_corner_touch_threshold);
        this.i = getResources().getDimensionPixelSize(R$dimen.ucrop_default_crop_rect_min_size);
        this.j = getResources().getDimensionPixelSize(R$dimen.ucrop_default_crop_rect_corner_touch_area_line_length);
    }

    public OverlayView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
