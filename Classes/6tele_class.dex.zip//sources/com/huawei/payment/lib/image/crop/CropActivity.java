package com.huawei.payment.lib.image.crop;

import P7.e;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.widget.TextView;
import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import com.huawei.payment.lib.image.R$id;
import com.huawei.payment.lib.image.R$menu;
import com.huawei.payment.lib.image.crop.view.CropView;
import com.huawei.payment.lib.image.crop.view.GestureCropImageView;
import com.huawei.payment.lib.image.crop.view.OverlayView;
import com.huawei.payment.lib.image.crop.view.TransformView;
import java.util.ArrayList;
import java.util.Locale;

public class CropActivity extends AppCompatActivity {
    public static final Bitmap.CompressFormat H = Bitmap.CompressFormat.JPEG;
    public int A = 90;
    public int[] B = {1, 2, 3};
    public final b C = new b();
    public final ArrayList a = new ArrayList();
    public String b;
    public int c;
    public int d;
    public int e;
    public int f;
    @ColorInt
    public int g;
    @DrawableRes
    public int h;
    @DrawableRes
    public int i;
    public int j;
    public boolean k;
    public boolean l = true;
    public CropView m;
    public GestureCropImageView n;
    public OverlayView o;
    public ViewGroup p;
    public ViewGroup q;
    public ViewGroup r;
    public ViewGroup s;
    public ViewGroup t;
    public ViewGroup u;
    public TextView v;
    public TextView w;
    public View x;
    public final a y = new a();
    public Bitmap.CompressFormat z = H;

    public class a implements TransformView.a {
        public a() {
        }

        public final void a(float f) {
            TextView textView = CropActivity.this.v;
            if (textView != null) {
                textView.setText(String.format(Locale.getDefault(), "%.1f°", new Object[]{Float.valueOf(f)}));
            }
        }

        public final void b() {
            CropActivity cropActivity = CropActivity.this;
            cropActivity.m.animate().alpha(1.0f).setDuration(300).setInterpolator(new AccelerateInterpolator());
            cropActivity.x.setClickable(false);
            cropActivity.l = false;
            cropActivity.supportInvalidateOptionsMenu();
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.payment.lib.image.crop.CropActivity, android.app.Activity] */
        public final void c(@NonNull Exception exc) {
            ? r0 = CropActivity.this;
            r0.D0(exc);
            r0.finish();
        }

        public final void d(float f) {
            TextView textView = CropActivity.this.w;
            if (textView != null) {
                textView.setText(String.format(Locale.getDefault(), "%d%%", new Object[]{Integer.valueOf((int) (f * 100.0f))}));
            }
        }
    }

    public class b implements View.OnClickListener {
        public b() {
        }

        public final void onClick(View view) {
            if (!view.isSelected()) {
                int id = view.getId();
                Bitmap.CompressFormat compressFormat = CropActivity.H;
                CropActivity.this.E0(id);
            }
        }
    }

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    public final void C0(int i2) {
        boolean z2;
        GestureCropImageView gestureCropImageView = this.n;
        int i3 = this.B[i2];
        boolean z3 = false;
        if (i3 == 3 || i3 == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        gestureCropImageView.setScaleEnabled(z2);
        GestureCropImageView gestureCropImageView2 = this.n;
        int i4 = this.B[i2];
        if (i4 == 3 || i4 == 2) {
            z3 = true;
        }
        gestureCropImageView2.setRotateEnabled(z3);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.payment.lib.image.crop.CropActivity, android.app.Activity] */
    public final void D0(Throwable th) {
        setResult(96, new Intent().putExtra("com.huawei.payment.lib.image.Error", th));
    }

    public final void E0(@IdRes int i2) {
        boolean z2;
        boolean z3;
        boolean z4;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        if (this.k) {
            ViewGroup viewGroup = this.p;
            int i9 = R$id.state_aspect_ratio;
            if (i2 == i9) {
                z2 = true;
            } else {
                z2 = false;
            }
            viewGroup.setSelected(z2);
            ViewGroup viewGroup2 = this.q;
            int i10 = R$id.state_rotate;
            if (i2 == i10) {
                z3 = true;
            } else {
                z3 = false;
            }
            viewGroup2.setSelected(z3);
            ViewGroup viewGroup3 = this.r;
            int i11 = R$id.state_scale;
            if (i2 == i11) {
                z4 = true;
            } else {
                z4 = false;
            }
            viewGroup3.setSelected(z4);
            ViewGroup viewGroup4 = this.s;
            int i12 = 8;
            if (i2 == i9) {
                i3 = 0;
            } else {
                i3 = 8;
            }
            viewGroup4.setVisibility(i3);
            ViewGroup viewGroup5 = this.t;
            if (i2 == i10) {
                i4 = 0;
            } else {
                i4 = 8;
            }
            viewGroup5.setVisibility(i4);
            ViewGroup viewGroup6 = this.u;
            if (i2 == i11) {
                i5 = 0;
            } else {
                i5 = 8;
            }
            viewGroup6.setVisibility(i5);
            View findViewById = this.r.findViewById(R$id.text_view_scale);
            if (i2 == i11) {
                i6 = 0;
            } else {
                i6 = 8;
            }
            findViewById.setVisibility(i6);
            View findViewById2 = this.p.findViewById(R$id.text_view_crop);
            if (i2 == i9) {
                i7 = 0;
            } else {
                i7 = 8;
            }
            findViewById2.setVisibility(i7);
            View findViewById3 = this.q.findViewById(R$id.text_view_rotate);
            if (i2 == i10) {
                i12 = 0;
            }
            findViewById3.setVisibility(i12);
            if (i2 == i11) {
                C0(0);
            } else if (i2 == i10) {
                C0(1);
            } else {
                C0(2);
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: androidx.appcompat.app.AppCompatActivity} */
    /* JADX WARNING: type inference failed for: r0v17, types: [com.huawei.payment.lib.image.crop.view.GestureCropImageView, android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(android.os.Bundle r24) {
        /*
            r23 = this;
            r1 = r23
            com.huawei.payment.lib.image.crop.CropActivity.super.onCreate(r24)
            int r0 = com.huawei.payment.lib.image.R$layout.ucrop_activity_ucrop
            r1.setContentView(r0)
            android.content.Intent r0 = r23.getIntent()
            int r2 = com.huawei.payment.lib.image.R$color.ucrop_color_statusbar
            int r2 = androidx.core.content.ContextCompat.getColor(r1, r2)
            java.lang.String r3 = "com.huawei.payment.lib.image.StatusBarColor"
            int r2 = r0.getIntExtra(r3, r2)
            r1.d = r2
            int r2 = com.huawei.payment.lib.image.R$color.ucrop_color_toolbar
            int r2 = androidx.core.content.ContextCompat.getColor(r1, r2)
            java.lang.String r3 = "com.huawei.payment.lib.image.ToolbarColor"
            int r2 = r0.getIntExtra(r3, r2)
            r1.c = r2
            int r2 = com.huawei.payment.lib.image.R$color.ucrop_color_active_controls_color
            int r2 = androidx.core.content.ContextCompat.getColor(r1, r2)
            java.lang.String r3 = "com.huawei.payment.lib.image.UcropColorControlsWidgetActive"
            int r2 = r0.getIntExtra(r3, r2)
            r1.e = r2
            int r2 = com.huawei.payment.lib.image.R$color.ucrop_color_toolbar_widget
            int r2 = androidx.core.content.ContextCompat.getColor(r1, r2)
            java.lang.String r3 = "com.huawei.payment.lib.image.UcropToolbarWidgetColor"
            int r2 = r0.getIntExtra(r3, r2)
            r1.f = r2
            java.lang.String r2 = "com.huawei.payment.lib.image.UcropToolbarCancelDrawable"
            int r3 = com.huawei.payment.lib.image.R$drawable.ucrop_ic_cross
            int r2 = r0.getIntExtra(r2, r3)
            r1.h = r2
            java.lang.String r2 = "com.huawei.payment.lib.image.UcropToolbarCropDrawable"
            int r3 = com.huawei.payment.lib.image.R$drawable.ucrop_ic_done
            int r2 = r0.getIntExtra(r2, r3)
            r1.i = r2
            java.lang.String r2 = "com.huawei.payment.lib.image.UcropToolbarTitleText"
            java.lang.String r2 = r0.getStringExtra(r2)
            r1.b = r2
            if (r2 == 0) goto L_0x0065
            goto L_0x006f
        L_0x0065:
            android.content.res.Resources r2 = r23.getResources()
            int r3 = com.huawei.payment.lib.image.R$string.ucrop_label_edit_photo
            java.lang.String r2 = r2.getString(r3)
        L_0x006f:
            r1.b = r2
            int r2 = com.huawei.payment.lib.image.R$color.ucrop_color_default_logo
            int r2 = androidx.core.content.ContextCompat.getColor(r1, r2)
            java.lang.String r3 = "com.huawei.payment.lib.image.UcropLogoColor"
            int r2 = r0.getIntExtra(r3, r2)
            r1.j = r2
            java.lang.String r2 = "com.huawei.payment.lib.image.HideBottomControls"
            r3 = 0
            boolean r2 = r0.getBooleanExtra(r2, r3)
            r4 = 1
            r2 = r2 ^ r4
            r1.k = r2
            int r2 = com.huawei.payment.lib.image.R$color.ucrop_color_crop_background
            int r2 = androidx.core.content.ContextCompat.getColor(r1, r2)
            java.lang.String r5 = "com.huawei.payment.lib.image.UcropRootViewBackgroundColor"
            int r2 = r0.getIntExtra(r5, r2)
            r1.g = r2
            int r2 = r1.d
            android.view.Window r5 = r23.getWindow()
            if (r5 == 0) goto L_0x00a3
            r5.setStatusBarColor(r2)
        L_0x00a3:
            int r2 = com.huawei.payment.lib.image.R$id.toolbar
            android.view.View r2 = r1.findViewById(r2)
            androidx.appcompat.widget.Toolbar r2 = (androidx.appcompat.widget.Toolbar) r2
            int r5 = r1.c
            r2.setBackgroundColor(r5)
            int r5 = r1.f
            r2.setTitleTextColor(r5)
            int r5 = com.huawei.payment.lib.image.R$id.toolbar_title
            android.view.View r5 = r2.findViewById(r5)
            android.widget.TextView r5 = (android.widget.TextView) r5
            int r6 = r1.f
            r5.setTextColor(r6)
            java.lang.String r6 = r1.b
            r5.setText(r6)
            int r5 = r1.h
            android.graphics.drawable.Drawable r5 = androidx.core.content.ContextCompat.getDrawable(r1, r5)
            android.graphics.drawable.Drawable r5 = r5.mutate()
            int r6 = r1.f
            android.graphics.PorterDuff$Mode r7 = android.graphics.PorterDuff.Mode.SRC_ATOP
            r5.setColorFilter(r6, r7)
            r2.setNavigationIcon(r5)
            r1.setSupportActionBar(r2)
            androidx.appcompat.app.ActionBar r2 = r23.getSupportActionBar()
            if (r2 == 0) goto L_0x00e7
            r2.setDisplayShowTitleEnabled(r3)
        L_0x00e7:
            int r2 = com.huawei.payment.lib.image.R$id.ucrop
            android.view.View r2 = r1.findViewById(r2)
            com.huawei.payment.lib.image.crop.view.CropView r2 = (com.huawei.payment.lib.image.crop.view.CropView) r2
            r1.m = r2
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r2.getCropImageView()
            r1.n = r2
            com.huawei.payment.lib.image.crop.view.CropView r2 = r1.m
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r2.getOverlayView()
            r1.o = r2
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r1.n
            com.huawei.payment.lib.image.crop.CropActivity$a r5 = r1.y
            r2.setTransformImageListener(r5)
            int r2 = com.huawei.payment.lib.image.R$id.image_view_logo
            android.view.View r2 = r1.findViewById(r2)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            int r5 = r1.j
            r2.setColorFilter(r5, r7)
            int r2 = com.huawei.payment.lib.image.R$id.ucrop_frame
            android.view.View r5 = r1.findViewById(r2)
            int r6 = r1.g
            r5.setBackgroundColor(r6)
            boolean r5 = r1.k
            if (r5 != 0) goto L_0x0135
            android.view.View r5 = r1.findViewById(r2)
            android.view.ViewGroup$LayoutParams r5 = r5.getLayoutParams()
            android.widget.RelativeLayout$LayoutParams r5 = (android.widget.RelativeLayout.LayoutParams) r5
            r5.bottomMargin = r3
            android.view.View r2 = r1.findViewById(r2)
            r2.requestLayout()
        L_0x0135:
            boolean r2 = r1.k
            r5 = -1
            r6 = 2
            r7 = 0
            r8 = 0
            java.lang.String r9 = "com.huawei.payment.lib.image.AspectRatioOptions"
            java.lang.String r10 = "com.huawei.payment.lib.image.AspectRatioSelectedByDefault"
            if (r2 == 0) goto L_0x031c
            int r2 = com.huawei.payment.lib.image.R$id.ucrop_photobox
            android.view.View r2 = r1.findViewById(r2)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            int r11 = com.huawei.payment.lib.image.R$id.controls_wrapper
            android.view.View r2 = r2.findViewById(r11)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            r2.setVisibility(r3)
            android.view.LayoutInflater r11 = android.view.LayoutInflater.from(r23)
            int r12 = com.huawei.payment.lib.image.R$layout.ucrop_controls
            r11.inflate(r12, r2, r4)
            int r2 = com.huawei.payment.lib.image.R$id.state_aspect_ratio
            android.view.View r2 = r1.findViewById(r2)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            r1.p = r2
            com.huawei.payment.lib.image.crop.CropActivity$b r11 = r1.C
            r2.setOnClickListener(r11)
            int r2 = com.huawei.payment.lib.image.R$id.state_rotate
            android.view.View r2 = r1.findViewById(r2)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            r1.q = r2
            r2.setOnClickListener(r11)
            int r2 = com.huawei.payment.lib.image.R$id.state_scale
            android.view.View r2 = r1.findViewById(r2)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            r1.r = r2
            r2.setOnClickListener(r11)
            int r2 = com.huawei.payment.lib.image.R$id.layout_aspect_ratio
            android.view.View r11 = r1.findViewById(r2)
            android.view.ViewGroup r11 = (android.view.ViewGroup) r11
            r1.s = r11
            int r11 = com.huawei.payment.lib.image.R$id.layout_rotate_wheel
            android.view.View r11 = r1.findViewById(r11)
            android.view.ViewGroup r11 = (android.view.ViewGroup) r11
            r1.t = r11
            int r11 = com.huawei.payment.lib.image.R$id.layout_scale_wheel
            android.view.View r11 = r1.findViewById(r11)
            android.view.ViewGroup r11 = (android.view.ViewGroup) r11
            r1.u = r11
            int r11 = r0.getIntExtra(r10, r3)
            java.util.ArrayList r12 = r0.getParcelableArrayListExtra(r9)
            r13 = 1065353216(0x3f800000, float:1.0)
            if (r12 == 0) goto L_0x01b6
            boolean r14 = r12.isEmpty()
            if (r14 == 0) goto L_0x01f8
        L_0x01b6:
            java.util.ArrayList r12 = new java.util.ArrayList
            r12.<init>()
            com.huawei.payment.lib.image.crop.model.AspectRatio r11 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r11.<init>(r8, r13, r13)
            r12.add(r11)
            com.huawei.payment.lib.image.crop.model.AspectRatio r11 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r14 = 1077936128(0x40400000, float:3.0)
            r15 = 1082130432(0x40800000, float:4.0)
            r11.<init>(r8, r14, r15)
            r12.add(r11)
            com.huawei.payment.lib.image.crop.model.AspectRatio r11 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            int r15 = com.huawei.payment.lib.image.R$string.ucrop_label_original
            java.lang.String r15 = r1.getString(r15)
            java.lang.String r15 = r15.toUpperCase()
            r11.<init>(r15, r7, r7)
            r12.add(r11)
            com.huawei.payment.lib.image.crop.model.AspectRatio r11 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r15 = 1073741824(0x40000000, float:2.0)
            r11.<init>(r8, r14, r15)
            r12.add(r11)
            com.huawei.payment.lib.image.crop.model.AspectRatio r11 = new com.huawei.payment.lib.image.crop.model.AspectRatio
            r14 = 1098907648(0x41800000, float:16.0)
            r15 = 1091567616(0x41100000, float:9.0)
            r11.<init>(r8, r14, r15)
            r12.add(r11)
            r11 = 2
        L_0x01f8:
            android.view.View r2 = r1.findViewById(r2)
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            android.widget.LinearLayout$LayoutParams r14 = new android.widget.LinearLayout$LayoutParams
            r14.<init>(r3, r5)
            r14.weight = r13
            java.util.Iterator r12 = r12.iterator()
        L_0x0209:
            boolean r13 = r12.hasNext()
            java.util.ArrayList r15 = r1.a
            if (r13 == 0) goto L_0x023e
            java.lang.Object r13 = r12.next()
            com.huawei.payment.lib.image.crop.model.AspectRatio r13 = (com.huawei.payment.lib.image.crop.model.AspectRatio) r13
            android.view.LayoutInflater r5 = r23.getLayoutInflater()
            int r7 = com.huawei.payment.lib.image.R$layout.ucrop_aspect_ratio
            android.view.View r5 = r5.inflate(r7, r8)
            android.widget.FrameLayout r5 = (android.widget.FrameLayout) r5
            r5.setLayoutParams(r14)
            android.view.View r7 = r5.getChildAt(r3)
            com.huawei.payment.lib.image.crop.view.widget.AspectTextView r7 = (com.huawei.payment.lib.image.crop.view.widget.AspectTextView) r7
            int r8 = r1.e
            r7.setActiveColor(r8)
            r7.setAspectRatio(r13)
            r2.addView(r5)
            r15.add(r5)
            r5 = -1
            r7 = 0
            r8 = 0
            goto L_0x0209
        L_0x023e:
            java.lang.Object r2 = r15.get(r11)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            r2.setSelected(r4)
            java.util.Iterator r2 = r15.iterator()
        L_0x024b:
            boolean r5 = r2.hasNext()
            if (r5 == 0) goto L_0x0260
            java.lang.Object r5 = r2.next()
            android.view.ViewGroup r5 = (android.view.ViewGroup) r5
            P7.b r7 = new P7.b
            r7.<init>(r1)
            r5.setOnClickListener(r7)
            goto L_0x024b
        L_0x0260:
            int r2 = com.huawei.payment.lib.image.R$id.text_view_rotate
            android.view.View r2 = r1.findViewById(r2)
            android.widget.TextView r2 = (android.widget.TextView) r2
            r1.v = r2
            int r2 = com.huawei.payment.lib.image.R$id.rotate_scroll_wheel
            android.view.View r5 = r1.findViewById(r2)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r5 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r5
            P7.c r7 = new P7.c
            r7.<init>(r1)
            r5.setScrollingListener(r7)
            android.view.View r2 = r1.findViewById(r2)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r2 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r2
            int r5 = r1.e
            r2.setMiddleLineColor(r5)
            int r2 = com.huawei.payment.lib.image.R$id.wrapper_reset_rotate
            android.view.View r2 = r1.findViewById(r2)
            P7.a r5 = new P7.a
            r7 = 0
            r5.<init>(r1, r7)
            r2.setOnClickListener(r5)
            int r2 = com.huawei.payment.lib.image.R$id.wrapper_rotate_by_angle
            android.view.View r2 = r1.findViewById(r2)
            D1.i r5 = new D1.i
            r7 = 2
            r5.<init>(r1, r7)
            r2.setOnClickListener(r5)
            int r2 = r1.e
            android.widget.TextView r5 = r1.v
            if (r5 == 0) goto L_0x02ac
            r5.setTextColor(r2)
        L_0x02ac:
            int r2 = com.huawei.payment.lib.image.R$id.text_view_scale
            android.view.View r2 = r1.findViewById(r2)
            android.widget.TextView r2 = (android.widget.TextView) r2
            r1.w = r2
            int r2 = com.huawei.payment.lib.image.R$id.scale_scroll_wheel
            android.view.View r5 = r1.findViewById(r2)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r5 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r5
            P7.d r7 = new P7.d
            r7.<init>(r1)
            r5.setScrollingListener(r7)
            android.view.View r2 = r1.findViewById(r2)
            com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView r2 = (com.huawei.payment.lib.image.crop.view.widget.HorizontalProgressView) r2
            int r5 = r1.e
            r2.setMiddleLineColor(r5)
            int r2 = r1.e
            android.widget.TextView r5 = r1.w
            if (r5 == 0) goto L_0x02da
            r5.setTextColor(r2)
        L_0x02da:
            int r2 = com.huawei.payment.lib.image.R$id.image_view_state_scale
            android.view.View r2 = r1.findViewById(r2)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            int r5 = com.huawei.payment.lib.image.R$id.image_view_state_rotate
            android.view.View r5 = r1.findViewById(r5)
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            int r7 = com.huawei.payment.lib.image.R$id.image_view_state_aspect_ratio
            android.view.View r7 = r1.findViewById(r7)
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            T7.f r8 = new T7.f
            android.graphics.drawable.Drawable r11 = r2.getDrawable()
            int r12 = r1.e
            r8.<init>(r12, r11)
            r2.setImageDrawable(r8)
            T7.f r2 = new T7.f
            android.graphics.drawable.Drawable r8 = r5.getDrawable()
            int r11 = r1.e
            r2.<init>(r11, r8)
            r5.setImageDrawable(r2)
            T7.f r2 = new T7.f
            android.graphics.drawable.Drawable r5 = r7.getDrawable()
            int r8 = r1.e
            r2.<init>(r8, r5)
            r7.setImageDrawable(r2)
        L_0x031c:
            java.lang.String r2 = "com.huawei.payment.lib.image.InputUri"
            android.os.Parcelable r2 = r0.getParcelableExtra(r2)
            r18 = r2
            android.net.Uri r18 = (android.net.Uri) r18
            java.lang.String r2 = "com.huawei.payment.lib.image.OutputUri"
            android.os.Parcelable r2 = r0.getParcelableExtra(r2)
            r19 = r2
            android.net.Uri r19 = (android.net.Uri) r19
            java.lang.String r2 = "com.huawei.payment.lib.image.CompressionFormatName"
            java.lang.String r2 = r0.getStringExtra(r2)
            boolean r5 = android.text.TextUtils.isEmpty(r2)
            if (r5 != 0) goto L_0x0341
            android.graphics.Bitmap$CompressFormat r8 = android.graphics.Bitmap.CompressFormat.valueOf(r2)
            goto L_0x0342
        L_0x0341:
            r8 = 0
        L_0x0342:
            if (r8 != 0) goto L_0x0346
            android.graphics.Bitmap$CompressFormat r8 = H
        L_0x0346:
            r1.z = r8
            java.lang.String r2 = "com.huawei.payment.lib.image.CompressionQuality"
            r5 = 90
            int r2 = r0.getIntExtra(r2, r5)
            r1.A = r2
            java.lang.String r2 = "com.huawei.payment.lib.image.AllowedGestures"
            int[] r2 = r0.getIntArrayExtra(r2)
            r5 = 3
            if (r2 == 0) goto L_0x0360
            int r7 = r2.length
            if (r7 != r5) goto L_0x0360
            r1.B = r2
        L_0x0360:
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r1.n
            java.lang.String r7 = "com.huawei.payment.lib.image.MaxBitmapSize"
            int r7 = r0.getIntExtra(r7, r3)
            r2.setMaxBitmapSize(r7)
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r1.n
            java.lang.String r7 = "com.huawei.payment.lib.image.MaxScaleMultiplier"
            r8 = 1092616192(0x41200000, float:10.0)
            float r7 = r0.getFloatExtra(r7, r8)
            r2.setMaxScaleMultiplier(r7)
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r1.n
            java.lang.String r7 = "com.huawei.payment.lib.image.ImageToCropBoundsAnimDuration"
            r8 = 500(0x1f4, float:7.0E-43)
            int r7 = r0.getIntExtra(r7, r8)
            long r7 = (long) r7
            r2.setImageToWrapCropBoundsAnimDuration(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            java.lang.String r7 = "com.huawei.payment.lib.image.FreeStyleCrop"
            boolean r7 = r0.getBooleanExtra(r7, r3)
            r2.setFreestyleCropEnabled(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            android.content.res.Resources r7 = r23.getResources()
            int r8 = com.huawei.payment.lib.image.R$color.ucrop_color_default_dimmed
            int r7 = r7.getColor(r8)
            java.lang.String r8 = "com.huawei.payment.lib.image.DimmedLayerColor"
            int r7 = r0.getIntExtra(r8, r7)
            r2.setDimmedColor(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            java.lang.String r7 = "com.huawei.payment.lib.image.CircleDimmedLayer"
            boolean r7 = r0.getBooleanExtra(r7, r3)
            r2.setCircleDimmedLayer(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            java.lang.String r7 = "com.huawei.payment.lib.image.ShowCropFrame"
            boolean r7 = r0.getBooleanExtra(r7, r4)
            r2.setShowCropFrame(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            android.content.res.Resources r7 = r23.getResources()
            int r8 = com.huawei.payment.lib.image.R$color.ucrop_color_default_crop_frame
            int r7 = r7.getColor(r8)
            java.lang.String r8 = "com.huawei.payment.lib.image.CropFrameColor"
            int r7 = r0.getIntExtra(r8, r7)
            r2.setCropFrameColor(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            android.content.res.Resources r7 = r23.getResources()
            int r8 = com.huawei.payment.lib.image.R$dimen.ucrop_default_crop_frame_stoke_width
            int r7 = r7.getDimensionPixelSize(r8)
            java.lang.String r8 = "com.huawei.payment.lib.image.CropFrameStrokeWidth"
            int r7 = r0.getIntExtra(r8, r7)
            r2.setCropFrameStrokeWidth(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            java.lang.String r7 = "com.huawei.payment.lib.image.ShowCropGrid"
            boolean r7 = r0.getBooleanExtra(r7, r4)
            r2.setShowCropGrid(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            java.lang.String r7 = "com.huawei.payment.lib.image.CropGridRowCount"
            int r7 = r0.getIntExtra(r7, r6)
            r2.setCropGridRowCount(r7)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            java.lang.String r7 = "com.huawei.payment.lib.image.CropGridColumnCount"
            int r6 = r0.getIntExtra(r7, r6)
            r2.setCropGridColumnCount(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            android.content.res.Resources r6 = r23.getResources()
            int r7 = com.huawei.payment.lib.image.R$color.ucrop_color_default_crop_grid
            int r6 = r6.getColor(r7)
            java.lang.String r7 = "com.huawei.payment.lib.image.CropGridColor"
            int r6 = r0.getIntExtra(r7, r6)
            r2.setCropGridColor(r6)
            com.huawei.payment.lib.image.crop.view.OverlayView r2 = r1.o
            android.content.res.Resources r6 = r23.getResources()
            int r7 = com.huawei.payment.lib.image.R$dimen.ucrop_default_crop_grid_stoke_width
            int r6 = r6.getDimensionPixelSize(r7)
            java.lang.String r7 = "com.huawei.payment.lib.image.CropGridStrokeWidth"
            int r6 = r0.getIntExtra(r7, r6)
            r2.setCropGridStrokeWidth(r6)
            java.lang.String r2 = "com.huawei.payment.lib.image.AspectRatioX"
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r2 = r0.getFloatExtra(r2, r6)
            java.lang.String r7 = "com.huawei.payment.lib.image.AspectRatioY"
            float r6 = r0.getFloatExtra(r7, r6)
            int r7 = r0.getIntExtra(r10, r3)
            java.util.ArrayList r8 = r0.getParcelableArrayListExtra(r9)
            r9 = 0
            int r10 = (r2 > r9 ? 1 : (r2 == r9 ? 0 : -1))
            if (r10 < 0) goto L_0x0469
            int r10 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            if (r10 < 0) goto L_0x0469
            android.view.ViewGroup r7 = r1.p
            if (r7 == 0) goto L_0x0459
            r8 = 8
            r7.setVisibility(r8)
        L_0x0459:
            float r2 = r2 / r6
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r6 = r1.n
            boolean r7 = java.lang.Float.isNaN(r2)
            if (r7 == 0) goto L_0x0464
            r7 = 0
            goto L_0x0465
        L_0x0464:
            r7 = r2
        L_0x0465:
            r6.setTargetAspectRatio(r7)
            goto L_0x049b
        L_0x0469:
            if (r8 == 0) goto L_0x0495
            int r2 = r8.size()
            if (r7 >= r2) goto L_0x0495
            java.lang.Object r2 = r8.get(r7)
            com.huawei.payment.lib.image.crop.model.AspectRatio r2 = (com.huawei.payment.lib.image.crop.model.AspectRatio) r2
            float r2 = r2.getAspectRatioX()
            java.lang.Object r6 = r8.get(r7)
            com.huawei.payment.lib.image.crop.model.AspectRatio r6 = (com.huawei.payment.lib.image.crop.model.AspectRatio) r6
            float r6 = r6.getAspectRatioY()
            float r2 = r2 / r6
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r6 = r1.n
            boolean r7 = java.lang.Float.isNaN(r2)
            if (r7 == 0) goto L_0x0490
            r7 = 0
            goto L_0x0491
        L_0x0490:
            r7 = r2
        L_0x0491:
            r6.setTargetAspectRatio(r7)
            goto L_0x049b
        L_0x0495:
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r1.n
            r6 = 0
            r2.setTargetAspectRatio(r6)
        L_0x049b:
            java.lang.String r2 = "com.huawei.payment.lib.image.MaxSizeX"
            int r2 = r0.getIntExtra(r2, r3)
            java.lang.String r6 = "com.huawei.payment.lib.image.MaxSizeY"
            int r0 = r0.getIntExtra(r6, r3)
            if (r2 <= 0) goto L_0x04b5
            if (r0 <= 0) goto L_0x04b5
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r6 = r1.n
            r6.setMaxResultImageSizeX(r2)
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r2 = r1.n
            r2.setMaxResultImageSizeY(r0)
        L_0x04b5:
            if (r18 == 0) goto L_0x04e3
            if (r19 == 0) goto L_0x04e3
            com.huawei.payment.lib.image.crop.view.GestureCropImageView r0 = r1.n     // Catch:{ Exception -> 0x04db }
            int r21 = r0.getMaxBitmapSize()     // Catch:{ Exception -> 0x04db }
            android.content.Context r17 = r0.getContext()     // Catch:{ Exception -> 0x04db }
            com.huawei.payment.lib.image.crop.view.a r2 = new com.huawei.payment.lib.image.crop.view.a     // Catch:{ Exception -> 0x04db }
            r2.<init>(r0)     // Catch:{ Exception -> 0x04db }
            S7.b r0 = new S7.b     // Catch:{ Exception -> 0x04db }
            r16 = r0
            r20 = r21
            r22 = r2
            r16.<init>(r17, r18, r19, r20, r21, r22)     // Catch:{ Exception -> 0x04db }
            java.util.concurrent.Executor r2 = android.os.AsyncTask.THREAD_POOL_EXECUTOR     // Catch:{ Exception -> 0x04db }
            java.lang.Void[] r6 = new java.lang.Void[r3]     // Catch:{ Exception -> 0x04db }
            r0.executeOnExecutor(r2, r6)     // Catch:{ Exception -> 0x04db }
            goto L_0x04f4
        L_0x04db:
            r0 = move-exception
            r1.D0(r0)
            r23.finish()
            goto L_0x04f4
        L_0x04e3:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            int r2 = com.huawei.payment.lib.image.R$string.ucrop_error_input_data
            java.lang.String r2 = r1.getString(r2)
            r0.<init>(r2)
            r1.D0(r0)
            r23.finish()
        L_0x04f4:
            boolean r0 = r1.k
            if (r0 == 0) goto L_0x050c
            android.view.ViewGroup r0 = r1.p
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x0506
            int r0 = com.huawei.payment.lib.image.R$id.state_aspect_ratio
            r1.E0(r0)
            goto L_0x050f
        L_0x0506:
            int r0 = com.huawei.payment.lib.image.R$id.state_scale
            r1.E0(r0)
            goto L_0x050f
        L_0x050c:
            r1.C0(r3)
        L_0x050f:
            android.view.View r0 = r1.x
            if (r0 != 0) goto L_0x052f
            android.view.View r0 = new android.view.View
            r0.<init>(r1)
            r1.x = r0
            android.widget.RelativeLayout$LayoutParams r0 = new android.widget.RelativeLayout$LayoutParams
            r2 = -1
            r0.<init>(r2, r2)
            int r2 = com.huawei.payment.lib.image.R$id.toolbar
            r0.addRule(r5, r2)
            android.view.View r2 = r1.x
            r2.setLayoutParams(r0)
            android.view.View r0 = r1.x
            r0.setClickable(r4)
        L_0x052f:
            int r0 = com.huawei.payment.lib.image.R$id.ucrop_photobox
            android.view.View r0 = r1.findViewById(r0)
            android.widget.RelativeLayout r0 = (android.widget.RelativeLayout) r0
            android.view.View r2 = r1.x
            r0.addView(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.payment.lib.image.crop.CropActivity.onCreate(android.os.Bundle):void");
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.payment.lib.image.crop.CropActivity, androidx.appcompat.app.AppCompatActivity] */
    public final boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R$menu.ucrop_menu, menu);
        MenuItem findItem = menu.findItem(R$id.menu_loader);
        Drawable icon = findItem.getIcon();
        if (icon != null) {
            try {
                icon.mutate();
                icon.setColorFilter(this.f, PorterDuff.Mode.SRC_ATOP);
                findItem.setIcon(icon);
            } catch (IllegalStateException unused) {
            }
            ((Animatable) findItem.getIcon()).start();
        }
        MenuItem findItem2 = menu.findItem(R$id.menu_crop);
        Drawable drawable = ContextCompat.getDrawable(this, this.i);
        if (drawable == null) {
            return true;
        }
        drawable.mutate();
        drawable.setColorFilter(this.f, PorterDuff.Mode.SRC_ATOP);
        findItem2.setIcon(drawable);
        return true;
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [androidx.activity.ComponentActivity, com.huawei.payment.lib.image.crop.CropActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity] */
    public final boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        } else if (menuItem.getItemId() != R$id.menu_crop) {
            return CropActivity.super.onOptionsItemSelected(menuItem);
        } else {
            this.x.setClickable(true);
            this.l = true;
            supportInvalidateOptionsMenu();
            this.n.f(this.z, this.A, new e(this));
            return true;
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.payment.lib.image.crop.CropActivity, android.app.Activity] */
    public final boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R$id.menu_crop).setVisible(!this.l);
        menu.findItem(R$id.menu_loader).setVisible(this.l);
        return CropActivity.super.onPrepareOptionsMenu(menu);
    }

    public final void onStop() {
        CropActivity.super.onStop();
        GestureCropImageView gestureCropImageView = this.n;
        if (gestureCropImageView != null) {
            gestureCropImageView.e();
        }
    }
}
