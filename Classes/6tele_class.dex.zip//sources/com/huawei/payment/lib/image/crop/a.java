package com.huawei.payment.lib.image.crop;

import android.view.View;

public final class a implements View.OnClickListener {
    public final /* synthetic */ CropFragment a;

    public a(CropFragment cropFragment) {
        this.a = cropFragment;
    }

    public final void onClick(View view) {
        c cVar = this.a.b;
        CropFragment.v0(new Exception("cancel"));
        cVar.b();
    }
}
