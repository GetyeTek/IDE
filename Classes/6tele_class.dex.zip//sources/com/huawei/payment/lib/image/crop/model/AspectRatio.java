package com.huawei.payment.lib.image.crop.model;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;

public class AspectRatio implements Parcelable {
    public static final Parcelable.Creator<AspectRatio> CREATOR = new Object();
    private final String aspectRatioTitle;
    private final float aspectRatioX;
    private final float aspectRatioY;

    public class a implements Parcelable.Creator<AspectRatio> {
        public final Object createFromParcel(Parcel parcel) {
            return new AspectRatio(parcel);
        }

        public final Object[] newArray(int i) {
            return new AspectRatio[i];
        }
    }

    public AspectRatio(String str, float f, float f2) {
        this.aspectRatioTitle = str;
        this.aspectRatioX = f;
        this.aspectRatioY = f2;
    }

    public int describeContents() {
        return 0;
    }

    @Nullable
    public String getAspectRatioTitle() {
        return this.aspectRatioTitle;
    }

    public float getAspectRatioX() {
        return this.aspectRatioX;
    }

    public float getAspectRatioY() {
        return this.aspectRatioY;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.aspectRatioTitle);
        parcel.writeFloat(this.aspectRatioX);
        parcel.writeFloat(this.aspectRatioY);
    }

    public AspectRatio(Parcel parcel) {
        this.aspectRatioTitle = parcel.readString();
        this.aspectRatioX = parcel.readFloat();
        this.aspectRatioY = parcel.readFloat();
    }
}
