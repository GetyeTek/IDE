package com.huawei.payment.lib.image.crop.view.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.annotation.ColorInt;
import androidx.core.content.ContextCompat;
import com.huawei.payment.lib.image.R$color;
import com.huawei.payment.lib.image.R$dimen;

public class HorizontalProgressView extends View {
    public final Rect a;
    public a b;
    public float c;
    public final Paint d;
    public final Paint e;
    public final int f;
    public final int g;
    public final int h;
    public boolean i;
    public float j;
    public int k;

    public interface a {
        void a();

        void b(float f);

        void c();
    }

    public HorizontalProgressView(Context context) {
        this(context, (AttributeSet) null);
    }

    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Rect rect = this.a;
        canvas.getClipBounds(rect);
        int width = rect.width();
        int i2 = this.f;
        int i3 = this.h;
        int i4 = width / (i2 + i3);
        float f2 = this.j % ((float) (i3 + i2));
        for (int i5 = 0; i5 < i4; i5++) {
            int i6 = i4 / 4;
            if (i5 < i6) {
                this.d.setAlpha((int) ((((float) i5) / ((float) i6)) * 255.0f));
            } else if (i5 > (i4 * 3) / 4) {
                this.d.setAlpha((int) ((((float) (i4 - i5)) / ((float) i6)) * 255.0f));
            } else {
                this.d.setAlpha(255);
            }
            float f3 = -f2;
            Canvas canvas2 = canvas;
            canvas2.drawLine(((float) rect.left) + f3 + ((float) ((this.f + this.h) * i5)), ((float) rect.centerY()) - (((float) this.g) / 4.0f), f3 + ((float) rect.left) + ((float) ((this.f + this.h) * i5)), (((float) this.g) / 4.0f) + ((float) rect.centerY()), this.d);
        }
        float centerX = (float) rect.centerX();
        float centerY = ((float) rect.centerY()) - (((float) this.g) / 2.0f);
        Canvas canvas3 = canvas;
        float f4 = centerY;
        canvas3.drawLine(centerX, f4, (float) rect.centerX(), (((float) this.g) / 2.0f) + ((float) rect.centerY()), this.e);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            this.c = motionEvent.getX();
        } else if (action == 1) {
            a aVar = this.b;
            if (aVar != null) {
                this.i = false;
                aVar.a();
            }
        } else if (action == 2) {
            float x = motionEvent.getX() - this.c;
            if (x != 0.0f) {
                if (!this.i) {
                    this.i = true;
                    a aVar2 = this.b;
                    if (aVar2 != null) {
                        aVar2.c();
                    }
                }
                this.j -= x;
                postInvalidate();
                this.c = motionEvent.getX();
                a aVar3 = this.b;
                if (aVar3 != null) {
                    aVar3.b(-x);
                }
            }
        }
        return true;
    }

    public void setMiddleLineColor(@ColorInt int i2) {
        this.k = i2;
        this.e.setColor(i2);
        invalidate();
    }

    public void setScrollingListener(a aVar) {
        this.b = aVar;
    }

    public HorizontalProgressView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public HorizontalProgressView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.a = new Rect();
        this.k = ContextCompat.getColor(getContext(), R$color.ucrop_color_widget_rotate_mid_line);
        this.f = getContext().getResources().getDimensionPixelSize(R$dimen.ucrop_width_horizontal_wheel_progress_line);
        this.g = getContext().getResources().getDimensionPixelSize(R$dimen.ucrop_height_horizontal_wheel_progress_line);
        this.h = getContext().getResources().getDimensionPixelSize(R$dimen.ucrop_margin_horizontal_wheel_progress_line);
        Paint paint = new Paint(1);
        this.d = paint;
        paint.setStyle(Paint.Style.STROKE);
        this.d.setStrokeWidth((float) this.f);
        this.d.setColor(getResources().getColor(R$color.ucrop_color_progress_wheel_line));
        Paint paint2 = new Paint(this.d);
        this.e = paint2;
        paint2.setColor(this.k);
        this.e.setStrokeCap(Paint.Cap.ROUND);
        this.e.setStrokeWidth((float) getContext().getResources().getDimensionPixelSize(R$dimen.ucrop_width_middle_wheel_progress_line));
    }
}
