package com.huawei.payment.lib.image.crop.view;

import T7.e;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Matrix;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import com.huawei.payment.lib.image.crop.view.CropImageView;
import com.huawei.payment.lib.image.crop.view.TransformView;

public class GestureCropImageView extends CropImageView {
    public float B0;
    public boolean C0;
    public boolean D0;
    public boolean E0;
    public int F0;
    public final ScaleGestureDetector H;
    public final e L;
    public final GestureDetector M;
    public float Q;

    public class a extends GestureDetector.SimpleOnGestureListener {
        public a() {
        }

        /* JADX WARNING: type inference failed for: r6v0, types: [com.huawei.payment.lib.image.crop.view.CropImageView, com.huawei.payment.lib.image.crop.view.GestureCropImageView, android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
        public final boolean onDoubleTap(MotionEvent motionEvent) {
            ? r6 = GestureCropImageView.this;
            float doubleTapTargetScale = r6.getDoubleTapTargetScale();
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            if (doubleTapTargetScale > r6.getMaxScale()) {
                doubleTapTargetScale = r6.getMaxScale();
            }
            float currentScale = r6.getCurrentScale();
            CropImageView.b bVar = new CropImageView.b(r6, currentScale, doubleTapTargetScale - currentScale, x, y);
            r6.x = bVar;
            r6.post(bVar);
            return super.onDoubleTap(motionEvent);
        }

        public final boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            GestureCropImageView.this.c(-f, -f2);
            return true;
        }
    }

    public class b extends e.a {
        public b() {
        }
    }

    public class c extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        public c() {
        }

        public final boolean onScale(ScaleGestureDetector scaleGestureDetector) {
            float scaleFactor = scaleGestureDetector.getScaleFactor();
            GestureCropImageView gestureCropImageView = GestureCropImageView.this;
            gestureCropImageView.i(scaleFactor, gestureCropImageView.Q, gestureCropImageView.B0);
            return true;
        }
    }

    public GestureCropImageView(Context context) {
        this(context, (AttributeSet) null);
    }

    public int getDoubleTapScaleSteps() {
        return this.F0;
    }

    public float getDoubleTapTargetScale() {
        return getCurrentScale() * ((float) Math.pow((double) (getMaxScale() / getMinScale()), (double) (1.0f / ((float) this.F0))));
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if ((motionEvent.getAction() & 255) == 0) {
            e();
        }
        if (motionEvent.getPointerCount() > 1) {
            this.Q = (motionEvent.getX(1) + motionEvent.getX(0)) / 2.0f;
            this.B0 = (motionEvent.getY(1) + motionEvent.getY(0)) / 2.0f;
        }
        if (this.E0) {
            this.M.onTouchEvent(motionEvent);
        }
        if (this.D0) {
            this.H.onTouchEvent(motionEvent);
        }
        if (this.C0) {
            e eVar = this.L;
            eVar.getClass();
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked == 0) {
                eVar.d = motionEvent.getX();
                eVar.e = motionEvent.getY();
                eVar.f = motionEvent.findPointerIndex(motionEvent.getPointerId(0));
                eVar.h = 0.0f;
                eVar.i = true;
            } else if (actionMasked == 1) {
                eVar.f = -1;
            } else if (actionMasked != 2) {
                if (actionMasked == 5) {
                    eVar.b = motionEvent.getX();
                    eVar.c = motionEvent.getY();
                    eVar.g = motionEvent.findPointerIndex(motionEvent.getPointerId(motionEvent.getActionIndex()));
                    eVar.h = 0.0f;
                    eVar.i = true;
                } else if (actionMasked == 6) {
                    eVar.g = -1;
                }
            } else if (!(eVar.f == -1 || eVar.g == -1 || motionEvent.getPointerCount() <= eVar.g)) {
                float x = motionEvent.getX(eVar.f);
                float y = motionEvent.getY(eVar.f);
                float x2 = motionEvent.getX(eVar.g);
                float y2 = motionEvent.getY(eVar.g);
                if (eVar.i) {
                    eVar.h = 0.0f;
                    eVar.i = false;
                } else {
                    float f = eVar.b;
                    float degrees = (((float) Math.toDegrees((double) ((float) Math.atan2((double) (y2 - y), (double) (x2 - x))))) % 360.0f) - (((float) Math.toDegrees((double) ((float) Math.atan2((double) (eVar.c - eVar.e), (double) (f - eVar.d))))) % 360.0f);
                    eVar.h = degrees;
                    if (degrees < -180.0f) {
                        eVar.h = degrees + 360.0f;
                    } else if (degrees > 180.0f) {
                        eVar.h = degrees - 360.0f;
                    }
                }
                b bVar = eVar.a;
                float f2 = eVar.h;
                GestureCropImageView gestureCropImageView = GestureCropImageView.this;
                float f3 = gestureCropImageView.Q;
                float f4 = gestureCropImageView.B0;
                if (f2 != 0.0f) {
                    Matrix matrix = gestureCropImageView.d;
                    matrix.postRotate(f2, f3, f4);
                    gestureCropImageView.setImageMatrix(matrix);
                    TransformView.a aVar = gestureCropImageView.g;
                    if (aVar != null) {
                        float[] fArr = gestureCropImageView.c;
                        matrix.getValues(fArr);
                        matrix.getValues(fArr);
                        aVar.a((float) (-(Math.atan2((double) fArr[1], (double) fArr[0]) * 57.29577951308232d)));
                    }
                }
                eVar.b = x2;
                eVar.c = y2;
                eVar.d = x;
                eVar.e = y;
            }
        }
        if ((motionEvent.getAction() & 255) == 1) {
            setImageToWrapCropBound(true);
        }
        return true;
    }

    public void setDoubleTapScaleSteps(int i) {
        this.F0 = i;
    }

    public void setGestureEnabled(boolean z) {
        this.E0 = z;
    }

    public void setRotateEnabled(boolean z) {
        this.C0 = z;
    }

    public void setScaleEnabled(boolean z) {
        this.D0 = z;
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.payment.lib.image.crop.view.GestureCropImageView, android.view.View] */
    public GestureCropImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.C0 = true;
        this.D0 = true;
        this.E0 = true;
        this.F0 = 5;
        this.M = new GestureDetector(getContext(), new a(), (Handler) null, true);
        this.H = new ScaleGestureDetector(getContext(), new c());
        this.L = new e(new b());
    }

    public GestureCropImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
