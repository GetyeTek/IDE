package com.huawei.payment.lib.image.crop;

import Q7.a;
import android.content.Intent;
import android.net.Uri;
import androidx.annotation.NonNull;

public final class b implements a {
    public final /* synthetic */ CropFragment a;

    public b(CropFragment cropFragment) {
        this.a = cropFragment;
    }

    public final void a(@NonNull Uri uri, int i, int i2, int i3, int i4) {
        CropFragment cropFragment = this.a;
        c cVar = cropFragment.b;
        new Intent().putExtra("com.huawei.payment.lib.image.OutputUri", uri).putExtra("com.huawei.payment.lib.image.CropAspectRatio", cropFragment.k.getTargetAspectRatio()).putExtra("com.huawei.payment.lib.image.ImageWidth", i3).putExtra("com.huawei.payment.lib.image.ImageHeight", i4).putExtra("com.huawei.payment.lib.image.OffsetX", i).putExtra("com.huawei.payment.lib.image.OffsetY", i2);
        cVar.b();
        cropFragment.b.a();
    }

    public final void b(@NonNull Throwable th) {
        c cVar = this.a.b;
        CropFragment.v0(th);
        cVar.b();
    }
}
