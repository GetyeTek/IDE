package com.huawei.payment.lib.image.crop.view.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import com.huawei.payment.lib.image.R$color;
import com.huawei.payment.lib.image.R$dimen;
import com.huawei.payment.lib.image.R$styleable;
import com.huawei.payment.lib.image.crop.model.AspectRatio;
import java.util.Locale;

public class AspectTextView extends AppCompatTextView {
    public final Rect a;
    public final Paint b;
    public final int c;
    public float d;
    public String e;
    public float f;
    public float g;

    public AspectTextView(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.payment.lib.image.crop.view.widget.AspectTextView, android.widget.TextView, android.view.View] */
    public final void a(@ColorInt int i) {
        Paint paint = this.b;
        if (paint != null) {
            paint.setColor(i);
        }
        setTextColor(new ColorStateList(new int[][]{new int[]{16842913}, new int[]{0}}, new int[]{i, ContextCompat.getColor(getContext(), R$color.ucrop_color_widget)}));
    }

    public final float b(boolean z) {
        if (z) {
            if (this.d != 0.0f) {
                float f2 = this.f;
                float f3 = this.g;
                this.f = f3;
                this.g = f2;
                this.d = f3 / f2;
            }
            c();
        }
        return this.d;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.payment.lib.image.crop.view.widget.AspectTextView, android.widget.TextView] */
    public final void c() {
        if (!TextUtils.isEmpty(this.e)) {
            setText(this.e);
            return;
        }
        Locale locale = Locale.US;
        setText(((int) this.f) + ":" + ((int) this.g));
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [com.huawei.payment.lib.image.crop.view.widget.AspectTextView, android.widget.TextView, android.view.View] */
    public final void onDraw(Canvas canvas) {
        AspectTextView.super.onDraw(canvas);
        if (isSelected()) {
            Rect rect = this.a;
            canvas.getClipBounds(rect);
            float f2 = ((float) rect.bottom) - (((float) rect.top) / 2.0f);
            int i = this.c;
            canvas.drawCircle(((float) (rect.right - rect.left)) / 2.0f, f2 - (((float) i) * 1.5f), ((float) i) / 2.0f, this.b);
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.payment.lib.image.crop.view.widget.AspectTextView, android.view.View] */
    public void setActiveColor(@ColorInt int i) {
        a(i);
        invalidate();
    }

    public void setAspectRatio(@NonNull AspectRatio aspectRatio) {
        this.e = aspectRatio.getAspectRatioTitle();
        this.f = aspectRatio.getAspectRatioX();
        float aspectRatioY = aspectRatio.getAspectRatioY();
        this.g = aspectRatioY;
        float f2 = this.f;
        if (f2 == 0.0f || aspectRatioY == 0.0f) {
            this.d = 0.0f;
        } else {
            this.d = f2 / aspectRatioY;
        }
        c();
    }

    public AspectTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.payment.lib.image.crop.view.widget.AspectTextView, android.widget.TextView, android.view.View] */
    public AspectTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = new Rect();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ucrop_AspectTextView);
        setGravity(1);
        this.e = obtainStyledAttributes.getString(R$styleable.ucrop_AspectTextView_ucrop_artv_ratio_title);
        this.f = obtainStyledAttributes.getFloat(R$styleable.ucrop_AspectTextView_ucrop_artv_ratio_x, 0.0f);
        float f2 = obtainStyledAttributes.getFloat(R$styleable.ucrop_AspectTextView_ucrop_artv_ratio_y, 0.0f);
        this.g = f2;
        float f3 = this.f;
        if (f3 == 0.0f || f2 == 0.0f) {
            this.d = 0.0f;
        } else {
            this.d = f3 / f2;
        }
        this.c = getContext().getResources().getDimensionPixelSize(R$dimen.ucrop_size_dot_scale_text_view);
        Paint paint = new Paint(1);
        this.b = paint;
        paint.setStyle(Paint.Style.FILL);
        c();
        a(getResources().getColor(R$color.ucrop_color_widget_active));
        obtainStyledAttributes.recycle();
    }
}
