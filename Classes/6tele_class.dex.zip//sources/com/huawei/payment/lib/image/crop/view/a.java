package com.huawei.payment.lib.image.crop.view;

public final class a {
    public final /* synthetic */ GestureCropImageView a;

    public a(GestureCropImageView gestureCropImageView) {
        this.a = gestureCropImageView;
    }
}
