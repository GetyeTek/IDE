package com.huawei.payment.lib.image.crop;

public interface c {
    void a();

    void b();
}
