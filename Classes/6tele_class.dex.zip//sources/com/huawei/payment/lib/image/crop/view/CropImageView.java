package com.huawei.payment.lib.image.crop.view;

import R7.c;
import R9.h;
import T7.d;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.AttributeSet;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.payment.lib.image.crop.view.TransformView;
import java.lang.ref.WeakReference;
import java.util.Arrays;

public class CropImageView extends TransformView {
    public int A;
    public int B;
    public long C;
    public final RectF r;
    public final Matrix s;
    public float t;
    public float u;
    public Q7.b v;
    public a w;
    public b x;
    public float y;
    public float z;

    public static class a implements Runnable {
        public final WeakReference<CropImageView> a;
        public final long b;
        public final long c = System.currentTimeMillis();
        public final float d;
        public final float e;
        public final float f;
        public final float g;
        public final float h;
        public final float i;
        public final boolean j;

        public a(CropImageView cropImageView, long j2, float f2, float f3, float f4, float f5, float f6, float f7, boolean z) {
            this.a = new WeakReference<>(cropImageView);
            this.b = j2;
            this.d = f2;
            this.e = f3;
            this.f = f4;
            this.g = f5;
            this.h = f6;
            this.i = f7;
            this.j = z;
        }

        /* JADX WARNING: type inference failed for: r0v2, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
        public final void run() {
            ? r0 = this.a.get();
            if (r0 != 0) {
                long currentTimeMillis = System.currentTimeMillis() - this.c;
                long j2 = this.b;
                float min = (float) Math.min(j2, currentTimeMillis);
                float f2 = (float) j2;
                float f3 = (min / f2) - 1.0f;
                float f4 = (f3 * f3 * f3) + 1.0f;
                float f5 = (this.f * f4) + 0.0f;
                float f6 = (f4 * this.g) + 0.0f;
                float b2 = h.b(min, this.i, f2);
                if (min < f2) {
                    float[] fArr = r0.b;
                    r0.c(f5 - (fArr[0] - this.d), f6 - (fArr[1] - this.e));
                    if (!this.j) {
                        RectF rectF = r0.r;
                        r0.j(this.h + b2, rectF.centerX(), rectF.centerY());
                    }
                    if (!r0.g(r0.a)) {
                        r0.post(this);
                    }
                }
            }
        }
    }

    public static class b implements Runnable {
        public final WeakReference<CropImageView> a;
        public final long b = 200;
        public final long c = System.currentTimeMillis();
        public final float d;
        public final float e;
        public final float f;
        public final float g;

        public b(CropImageView cropImageView, float f2, float f3, float f4, float f5) {
            this.a = new WeakReference<>(cropImageView);
            this.d = f2;
            this.e = f3;
            this.f = f4;
            this.g = f5;
        }

        /* JADX WARNING: type inference failed for: r0v2, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.view.View] */
        public final void run() {
            ? r0 = this.a.get();
            if (r0 != 0) {
                long currentTimeMillis = System.currentTimeMillis() - this.c;
                long j = this.b;
                float min = (float) Math.min(j, currentTimeMillis);
                float f2 = (float) j;
                float b2 = h.b(min, this.e, f2);
                if (min < f2) {
                    r0.j(this.d + b2, this.f, this.g);
                    r0.post(this);
                    return;
                }
                r0.setImageToWrapCropBound(true);
            }
        }
    }

    public CropImageView(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.widget.ImageView, com.huawei.payment.lib.image.crop.view.TransformView] */
    public final void b() {
        super.b();
        Drawable drawable = getDrawable();
        if (drawable != null) {
            float intrinsicWidth = (float) drawable.getIntrinsicWidth();
            float intrinsicHeight = (float) drawable.getIntrinsicHeight();
            if (this.t == 0.0f) {
                this.t = intrinsicWidth / intrinsicHeight;
            }
            int i = this.e;
            float f = (float) i;
            float f2 = this.t;
            int i2 = (int) (f / f2);
            int i3 = this.f;
            RectF rectF = this.r;
            if (i2 > i3) {
                float f3 = (float) i3;
                int i4 = (int) (f2 * f3);
                int i5 = (i - i4) / 2;
                rectF.set((float) i5, 0.0f, (float) (i4 + i5), f3);
            } else {
                int i6 = (i3 - i2) / 2;
                rectF.set(0.0f, (float) i6, f, (float) (i2 + i6));
            }
            d(intrinsicWidth, intrinsicHeight);
            float width = rectF.width();
            float height = rectF.height();
            float max = Math.max(rectF.width() / intrinsicWidth, rectF.height() / intrinsicHeight);
            float f4 = ((height - (intrinsicHeight * max)) / 2.0f) + rectF.top;
            Matrix matrix = this.d;
            matrix.reset();
            matrix.postScale(max, max);
            matrix.postTranslate(((width - (intrinsicWidth * max)) / 2.0f) + rectF.left, f4);
            setImageMatrix(matrix);
            Q7.b bVar = this.v;
            if (bVar != null) {
                ((OverlayView) ((U7.a) bVar).a).setTargetAspectRatio(this.t);
            }
            TransformView.a aVar = this.g;
            if (aVar != null) {
                aVar.d(getCurrentScale());
                this.g.a(getCurrentAngle());
            }
        }
    }

    public final void d(float f, float f2) {
        RectF rectF = this.r;
        float min = Math.min(Math.min(rectF.width() / f, rectF.width() / f2), Math.min(rectF.height() / f2, rectF.height() / f));
        this.z = min;
        this.y = min * this.u;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.view.View] */
    public final void e() {
        removeCallbacks(this.w);
        removeCallbacks(this.x);
    }

    /* JADX WARNING: type inference failed for: r14v0, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
    public final void f(@NonNull Bitmap.CompressFormat compressFormat, int i, @Nullable Q7.a aVar) {
        e();
        setImageToWrapCropBound(false);
        c cVar = new c(this.r, d.a(this.a), getCurrentScale(), getCurrentAngle());
        int i2 = this.A;
        int i3 = this.B;
        String imageInputPath = getImageInputPath();
        String imageOutputPath = getImageOutputPath();
        getExifInfo();
        R7.a aVar2 = new R7.a(i2, i3, compressFormat, i, imageInputPath, imageOutputPath);
        aVar2.g = getImageInputUri();
        aVar2.h = getImageOutputUri();
        new S7.a(getContext(), getViewBitmap(), cVar, aVar2, aVar).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    public final boolean g(float[] fArr) {
        Matrix matrix = this.s;
        matrix.reset();
        matrix.setRotate(-getCurrentAngle());
        float[] copyOf = Arrays.copyOf(fArr, fArr.length);
        matrix.mapPoints(copyOf);
        RectF rectF = this.r;
        float f = rectF.left;
        float f2 = rectF.top;
        float f3 = rectF.right;
        float f4 = rectF.bottom;
        float[] fArr2 = {f, f2, f3, f2, f3, f4, f, f4};
        matrix.mapPoints(fArr2);
        return d.a(copyOf).contains(d.a(fArr2));
    }

    @Nullable
    public Q7.b getCropBoundsChangeListener() {
        return this.v;
    }

    public float getMaxScale() {
        return this.y;
    }

    public float getMinScale() {
        return this.z;
    }

    public float getTargetAspectRatio() {
        return this.t;
    }

    public final void h(float f) {
        RectF rectF = this.r;
        float centerX = rectF.centerX();
        float centerY = rectF.centerY();
        if (f != 0.0f) {
            Matrix matrix = this.d;
            matrix.postRotate(f, centerX, centerY);
            setImageMatrix(matrix);
            TransformView.a aVar = this.g;
            if (aVar != null) {
                float[] fArr = this.c;
                matrix.getValues(fArr);
                matrix.getValues(fArr);
                aVar.a((float) (-(Math.atan2((double) fArr[1], (double) fArr[0]) * 57.29577951308232d)));
            }
        }
    }

    public final void i(float f, float f2, float f3) {
        if (f <= 1.0f || getCurrentScale() * f > getMaxScale()) {
            if (f < 1.0f && getCurrentScale() * f >= getMinScale() && f != 0.0f) {
                Matrix matrix = this.d;
                matrix.postScale(f, f, f2, f3);
                setImageMatrix(matrix);
                TransformView.a aVar = this.g;
                if (aVar != null) {
                    aVar.d(a(matrix));
                }
            }
        } else if (f != 0.0f) {
            Matrix matrix2 = this.d;
            matrix2.postScale(f, f, f2, f3);
            setImageMatrix(matrix2);
            TransformView.a aVar2 = this.g;
            if (aVar2 != null) {
                aVar2.d(a(matrix2));
            }
        }
    }

    public final void j(float f, float f2, float f3) {
        if (f <= getMaxScale()) {
            i(f / getCurrentScale(), f2, f3);
        }
    }

    public void setCropBoundsChangeListener(@Nullable Q7.b bVar) {
        this.v = bVar;
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.widget.ImageView, android.view.View] */
    public void setCropRect(RectF rectF) {
        this.t = rectF.width() / rectF.height();
        this.r.set(rectF.left - ((float) getPaddingLeft()), rectF.top - ((float) getPaddingTop()), rectF.right - ((float) getPaddingRight()), rectF.bottom - ((float) getPaddingBottom()));
        Drawable drawable = getDrawable();
        if (drawable != null) {
            d((float) drawable.getIntrinsicWidth(), (float) drawable.getIntrinsicHeight());
        }
        setImageToWrapCropBound(true);
    }

    /* JADX WARNING: type inference failed for: r11v0, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
    public void setImageToWrapCropBound(boolean z2) {
        float f;
        float f2;
        float f3;
        if (this.i) {
            float[] fArr = this.a;
            if (!g(fArr)) {
                float[] fArr2 = this.b;
                float f4 = fArr2[0];
                float f5 = fArr2[1];
                float currentScale = getCurrentScale();
                RectF rectF = this.r;
                float centerX = rectF.centerX() - f4;
                float centerY = rectF.centerY() - f5;
                Matrix matrix = this.s;
                matrix.reset();
                matrix.setTranslate(centerX, centerY);
                float[] copyOf = Arrays.copyOf(fArr, fArr.length);
                matrix.mapPoints(copyOf);
                boolean g = g(copyOf);
                if (g) {
                    matrix.reset();
                    matrix.setRotate(-getCurrentAngle());
                    float[] copyOf2 = Arrays.copyOf(fArr, fArr.length);
                    float f6 = rectF.left;
                    float f7 = rectF.top;
                    float f9 = rectF.right;
                    float f10 = rectF.bottom;
                    float[] fArr3 = {f6, f7, f9, f7, f9, f10, f6, f10};
                    matrix.mapPoints(copyOf2);
                    matrix.mapPoints(fArr3);
                    RectF a2 = d.a(copyOf2);
                    RectF a3 = d.a(fArr3);
                    float f11 = a2.left - a3.left;
                    float f12 = a2.top - a3.top;
                    float f13 = a2.right - a3.right;
                    float f14 = a2.bottom - a3.bottom;
                    if (f11 <= 0.0f) {
                        f11 = 0.0f;
                    }
                    if (f12 <= 0.0f) {
                        f12 = 0.0f;
                    }
                    if (f13 >= 0.0f) {
                        f13 = 0.0f;
                    }
                    if (f14 >= 0.0f) {
                        f14 = 0.0f;
                    }
                    float[] fArr4 = {f11, f12, f13, f14};
                    matrix.reset();
                    matrix.setRotate(getCurrentAngle());
                    matrix.mapPoints(fArr4);
                    f3 = -(fArr4[0] + fArr4[2]);
                    f2 = -(fArr4[1] + fArr4[3]);
                    f = 0.0f;
                } else {
                    RectF rectF2 = new RectF(rectF);
                    matrix.reset();
                    matrix.setRotate(getCurrentAngle());
                    matrix.mapRect(rectF2);
                    float f15 = centerY;
                    float[] fArr5 = {(float) Math.sqrt(Math.pow((double) (fArr[1] - fArr[3]), 2.0d) + Math.pow((double) (fArr[0] - fArr[2]), 2.0d)), (float) Math.sqrt(Math.pow((double) (fArr[3] - fArr[5]), 2.0d) + Math.pow((double) (fArr[2] - fArr[4]), 2.0d))};
                    f = (Math.max(rectF2.width() / fArr5[0], rectF2.height() / fArr5[1]) * currentScale) - currentScale;
                    f3 = centerX;
                    f2 = f15;
                }
                if (z2) {
                    a aVar = new a(this, this.C, f4, f5, f3, f2, currentScale, f, g);
                    this.w = aVar;
                    post(aVar);
                    return;
                }
                c(f3, f2);
                if (!g) {
                    j(currentScale + f, rectF.centerX(), rectF.centerY());
                }
            }
        }
    }

    public void setImageToWrapCropBoundsAnimDuration(@IntRange(from = 100) long j) {
        if (j > 0) {
            this.C = j;
            return;
        }
        throw new IllegalArgumentException("Animation duration cannot be negative value.");
    }

    public void setMaxResultImageSizeX(@IntRange(from = 10) int i) {
        this.A = i;
    }

    public void setMaxResultImageSizeY(@IntRange(from = 10) int i) {
        this.B = i;
    }

    public void setMaxScaleMultiplier(float f) {
        this.u = f;
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.payment.lib.image.crop.view.CropImageView, android.widget.ImageView] */
    public void setTargetAspectRatio(float f) {
        Drawable drawable = getDrawable();
        if (drawable == null) {
            this.t = f;
            return;
        }
        if (f == 0.0f) {
            this.t = ((float) drawable.getIntrinsicWidth()) / ((float) drawable.getIntrinsicHeight());
        } else {
            this.t = f;
        }
        Q7.b bVar = this.v;
        if (bVar != null) {
            ((OverlayView) ((U7.a) bVar).a).setTargetAspectRatio(this.t);
        }
    }

    public CropImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.r = new RectF();
        this.s = new Matrix();
        this.u = 10.0f;
        this.A = 0;
        this.B = 0;
        this.C = 500;
    }

    public CropImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
