package com.huawei.payment.lib.image.crop.view;

import U7.a;
import U7.b;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import com.huawei.payment.lib.image.R$color;
import com.huawei.payment.lib.image.R$dimen;
import com.huawei.payment.lib.image.R$id;
import com.huawei.payment.lib.image.R$layout;
import com.huawei.payment.lib.image.R$styleable;

public class CropView extends FrameLayout {
    public final OverlayView a;
    public final GestureCropImageView b;

    public CropView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @NonNull
    public GestureCropImageView getCropImageView() {
        return this.b;
    }

    @NonNull
    public OverlayView getOverlayView() {
        return this.a;
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public CropView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        LayoutInflater.from(context).inflate(R$layout.ucrop_view, this, true);
        GestureCropImageView gestureCropImageView = (GestureCropImageView) findViewById(R$id.image_view_crop);
        this.b = gestureCropImageView;
        OverlayView overlayView = (OverlayView) findViewById(R$id.view_overlay);
        this.a = overlayView;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ucrop_UCropView);
        overlayView.getClass();
        overlayView.t = obtainStyledAttributes.getBoolean(R$styleable.ucrop_UCropView_ucrop_circle_dimmed_layer, false);
        int color = obtainStyledAttributes.getColor(R$styleable.ucrop_UCropView_ucrop_dimmed_color, overlayView.getResources().getColor(R$color.ucrop_color_default_dimmed));
        overlayView.u = color;
        Paint paint = overlayView.d;
        paint.setColor(color);
        Paint.Style style = Paint.Style.STROKE;
        paint.setStyle(style);
        paint.setStrokeWidth(1.0f);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(R$styleable.ucrop_UCropView_ucrop_frame_stroke_size, overlayView.getResources().getDimensionPixelSize(R$dimen.ucrop_default_crop_frame_stoke_width));
        int color2 = obtainStyledAttributes.getColor(R$styleable.ucrop_UCropView_ucrop_frame_color, overlayView.getResources().getColor(R$color.ucrop_color_default_crop_frame));
        Paint paint2 = overlayView.f;
        paint2.setStrokeWidth((float) dimensionPixelSize);
        paint2.setColor(color2);
        paint2.setStyle(style);
        Paint paint3 = overlayView.g;
        paint3.setStrokeWidth((float) (dimensionPixelSize * 3));
        paint3.setColor(color2);
        paint3.setStyle(style);
        overlayView.r = obtainStyledAttributes.getBoolean(R$styleable.ucrop_UCropView_ucrop_show_frame, true);
        int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(R$styleable.ucrop_UCropView_ucrop_grid_stroke_size, overlayView.getResources().getDimensionPixelSize(R$dimen.ucrop_default_crop_grid_stoke_width));
        int color3 = obtainStyledAttributes.getColor(R$styleable.ucrop_UCropView_ucrop_grid_color, overlayView.getResources().getColor(R$color.ucrop_color_default_crop_grid));
        Paint paint4 = overlayView.e;
        paint4.setStrokeWidth((float) dimensionPixelSize2);
        paint4.setColor(color3);
        overlayView.n = obtainStyledAttributes.getInt(R$styleable.ucrop_UCropView_ucrop_grid_row_count, 2);
        overlayView.o = obtainStyledAttributes.getInt(R$styleable.ucrop_UCropView_ucrop_grid_column_count, 2);
        overlayView.s = obtainStyledAttributes.getBoolean(R$styleable.ucrop_UCropView_ucrop_show_grid, true);
        gestureCropImageView.getClass();
        float abs = Math.abs(obtainStyledAttributes.getFloat(R$styleable.ucrop_UCropView_ucrop_aspect_ratio_x, 0.0f));
        float abs2 = Math.abs(obtainStyledAttributes.getFloat(R$styleable.ucrop_UCropView_ucrop_aspect_ratio_y, 0.0f));
        if (abs == 0.0f || abs2 == 0.0f) {
            gestureCropImageView.t = 0.0f;
        } else {
            gestureCropImageView.t = abs / abs2;
        }
        obtainStyledAttributes.recycle();
        gestureCropImageView.setCropBoundsChangeListener(new a(overlayView));
        overlayView.setOverlayViewChangeListener(new b(this));
    }
}
