package com.huawei.payment.lib.image;

public final class R$string {
    public static final int abc_action_bar_home_description = 2132017182;
    public static final int abc_action_bar_up_description = 2132017183;
    public static final int abc_action_menu_overflow_description = 2132017184;
    public static final int abc_action_mode_done = 2132017185;
    public static final int abc_activity_chooser_view_see_all = 2132017186;
    public static final int abc_activitychooserview_choose_application = 2132017187;
    public static final int abc_capital_off = 2132017188;
    public static final int abc_capital_on = 2132017189;
    public static final int abc_menu_alt_shortcut_label = 2132017190;
    public static final int abc_menu_ctrl_shortcut_label = 2132017191;
    public static final int abc_menu_delete_shortcut_label = 2132017192;
    public static final int abc_menu_enter_shortcut_label = 2132017193;
    public static final int abc_menu_function_shortcut_label = 2132017194;
    public static final int abc_menu_meta_shortcut_label = 2132017195;
    public static final int abc_menu_shift_shortcut_label = 2132017196;
    public static final int abc_menu_space_shortcut_label = 2132017197;
    public static final int abc_menu_sym_shortcut_label = 2132017198;
    public static final int abc_prepend_shortcut_label = 2132017199;
    public static final int abc_search_hint = 2132017200;
    public static final int abc_searchview_description_clear = 2132017201;
    public static final int abc_searchview_description_query = 2132017202;
    public static final int abc_searchview_description_search = 2132017203;
    public static final int abc_searchview_description_submit = 2132017204;
    public static final int abc_searchview_description_voice = 2132017205;
    public static final int abc_shareactionprovider_share_with = 2132017206;
    public static final int abc_shareactionprovider_share_with_application = 2132017207;
    public static final int abc_toolbar_collapse_description = 2132017208;
    public static final int search_menu_title = 2132020773;
    public static final int status_bar_notification_info_overflow = 2132020980;
    public static final int ucrop_crop = 2132021245;
    public static final int ucrop_error_input_data = 2132021246;
    public static final int ucrop_exception_hint = 2132021247;
    public static final int ucrop_label_edit_photo = 2132021248;
    public static final int ucrop_label_original = 2132021249;
    public static final int ucrop_rotate = 2132021250;
    public static final int ucrop_scale = 2132021251;

    private R$string() {
    }
}
