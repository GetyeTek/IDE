package com.huawei.payment.lib.image.crop.view;

import R7.b;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.WindowManager;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;

public class TransformView extends AppCompatImageView {
    public final float[] a;
    public final float[] b;
    public final float[] c;
    public final Matrix d;
    public int e;
    public int f;
    public a g;
    public boolean h;
    public boolean i;
    public float[] j;
    public float[] k;
    public int l;
    public String m;
    public String n;
    public Uri o;
    public Uri p;
    public b q;

    public interface a {
        void a(float f);

        void b();

        void c(@NonNull Exception exc);

        void d(float f);
    }

    public TransformView(Context context) {
        this(context, (AttributeSet) null);
    }

    public final float a(@NonNull Matrix matrix) {
        float[] fArr = this.c;
        matrix.getValues(fArr);
        double pow = Math.pow((double) fArr[0], 2.0d);
        matrix.getValues(fArr);
        return (float) Math.sqrt(Math.pow((double) fArr[3], 2.0d) + pow);
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [android.widget.ImageView, com.huawei.payment.lib.image.crop.view.TransformView] */
    public void b() {
        Drawable drawable = getDrawable();
        if (drawable != null) {
            RectF rectF = new RectF(0.0f, 0.0f, (float) drawable.getIntrinsicWidth(), (float) drawable.getIntrinsicHeight());
            float f2 = rectF.left;
            float f3 = rectF.top;
            float f4 = rectF.right;
            float f5 = rectF.bottom;
            this.j = new float[]{f2, f3, f4, f3, f4, f5, f2, f5};
            this.k = new float[]{rectF.centerX(), rectF.centerY()};
            this.i = true;
            a aVar = this.g;
            if (aVar != null) {
                aVar.b();
            }
        }
    }

    public final void c(float f2, float f3) {
        if (f2 != 0.0f || f3 != 0.0f) {
            Matrix matrix = this.d;
            matrix.postTranslate(f2, f3);
            setImageMatrix(matrix);
        }
    }

    public float getCurrentAngle() {
        Matrix matrix = this.d;
        float[] fArr = this.c;
        matrix.getValues(fArr);
        matrix.getValues(fArr);
        return (float) (-(Math.atan2((double) fArr[1], (double) fArr[0]) * 57.29577951308232d));
    }

    public float getCurrentScale() {
        return a(this.d);
    }

    public b getExifInfo() {
        return this.q;
    }

    public String getImageInputPath() {
        return this.m;
    }

    public Uri getImageInputUri() {
        return this.o;
    }

    public String getImageOutputPath() {
        return this.n;
    }

    public Uri getImageOutputUri() {
        return this.p;
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
    public int getMaxBitmapSize() {
        int i2;
        if (this.l <= 0) {
            WindowManager windowManager = (WindowManager) getContext().getSystemService("window");
            Point point = new Point();
            if (windowManager != null) {
                windowManager.getDefaultDisplay().getSize(point);
            }
            int i3 = point.x;
            int i4 = point.y;
            int sqrt = (int) Math.sqrt(Math.pow((double) i4, 2.0d) + Math.pow((double) i3, 2.0d));
            Canvas canvas = new Canvas();
            int min = Math.min(canvas.getMaximumBitmapWidth(), canvas.getMaximumBitmapHeight());
            if (min > 0) {
                sqrt = Math.min(sqrt, min);
            }
            try {
                i2 = Rb.a.k();
            } catch (Exception unused) {
                i2 = 0;
            }
            if (i2 > 0) {
                sqrt = Math.min(sqrt, i2);
            }
            this.l = sqrt;
        }
        return this.l;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.widget.ImageView, com.huawei.payment.lib.image.crop.view.TransformView] */
    @Nullable
    public Bitmap getViewBitmap() {
        if (getDrawable() == null || !(getDrawable() instanceof T7.b)) {
            return null;
        }
        return ((T7.b) getDrawable()).b;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.widget.ImageView, android.view.View, com.huawei.payment.lib.image.crop.view.TransformView] */
    public final void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        TransformView.super.onLayout(z, i2, i3, i4, i5);
        if (z || (this.h && !this.i)) {
            int paddingLeft = getPaddingLeft();
            int paddingTop = getPaddingTop();
            this.e = (getWidth() - getPaddingRight()) - paddingLeft;
            this.f = (getHeight() - getPaddingBottom()) - paddingTop;
            b();
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        setImageDrawable(new T7.b(bitmap));
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.widget.ImageView, com.huawei.payment.lib.image.crop.view.TransformView] */
    public void setImageMatrix(Matrix matrix) {
        TransformView.super.setImageMatrix(matrix);
        Matrix matrix2 = this.d;
        matrix2.set(matrix);
        matrix2.mapPoints(this.a, this.j);
        matrix2.mapPoints(this.b, this.k);
    }

    public void setMaxBitmapSize(int i2) {
        this.l = i2;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.widget.ImageView, com.huawei.payment.lib.image.crop.view.TransformView] */
    public void setScaleType(ImageView.ScaleType scaleType) {
        if (scaleType == ImageView.ScaleType.MATRIX) {
            TransformView.super.setScaleType(scaleType);
        }
    }

    public void setTransformImageListener(a aVar) {
        this.g = aVar;
    }

    public TransformView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TransformView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.a = new float[8];
        this.b = new float[2];
        this.c = new float[9];
        this.d = new Matrix();
        this.h = false;
        this.i = false;
        this.l = 0;
        setScaleType(ImageView.ScaleType.MATRIX);
    }
}
