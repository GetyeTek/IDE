package com.huawei.payment.refresh;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.AnimationDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.ethiopialib.R;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import com.scwang.smart.refresh.layout.constant.RefreshState;
import f9.c;
import f9.d;
import g9.b;

@SuppressLint({"RestrictedApi"})
public class MainClassicsHeader extends LinearLayout implements c {
    public ImageView a;
    public ImageView b;
    public AnimationDrawable c;
    public int d = R.drawable.main_freshing1;
    public int e = R.drawable.main_fresh_finish1;
    public int f;

    public static /* synthetic */ class a {
        public static final /* synthetic */ int[] a;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            /*
                com.scwang.smart.refresh.layout.constant.RefreshState[] r0 = com.scwang.smart.refresh.layout.constant.RefreshState.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                a = r0
                com.scwang.smart.refresh.layout.constant.RefreshState r1 = com.scwang.smart.refresh.layout.constant.RefreshState.None     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.scwang.smart.refresh.layout.constant.RefreshState r1 = com.scwang.smart.refresh.layout.constant.RefreshState.PullDownToRefresh     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.scwang.smart.refresh.layout.constant.RefreshState r1 = com.scwang.smart.refresh.layout.constant.RefreshState.Refreshing     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.scwang.smart.refresh.layout.constant.RefreshState r1 = com.scwang.smart.refresh.layout.constant.RefreshState.ReleaseToRefresh     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.huawei.payment.refresh.MainClassicsHeader.a.<clinit>():void");
        }
    }

    public MainClassicsHeader(Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        j(context, attributeSet);
    }

    public final void a(SmartRefreshLayout smartRefreshLayout, RefreshState refreshState, RefreshState refreshState2) {
        int i = a.a[refreshState2.ordinal()];
        if (i == 1 || i == 2) {
            this.b.setVisibility(4);
            this.a.setVisibility(0);
        } else if (i == 3) {
            this.a.setVisibility(8);
            this.b.setVisibility(0);
            this.b.setImageResource(this.d);
        }
    }

    public final void b(SmartRefreshLayout smartRefreshLayout, int i, int i2) {
        if (this.c.isRunning()) {
            this.c.stop();
        }
    }

    public final void d(float f2, int i, int i2) {
    }

    public final boolean e() {
        return false;
    }

    public final int f(@NonNull d dVar, boolean z) {
        this.a.setVisibility(4);
        this.b.setVisibility(0);
        this.b.setImageResource(this.e);
        return 800;
    }

    public final void g(boolean z, int i, int i2, int i3, float f2) {
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        if (f2 > 0.0f && f2 <= 1.0f) {
            this.c.selectDrawable((int) (f2 * 23.0f));
        }
    }

    @NonNull
    public b getSpinnerStyle() {
        return b.d;
    }

    @NonNull
    public View getView() {
        return this;
    }

    public final void h(@NonNull SmartRefreshLayout.h hVar, int i, int i2) {
        hVar.c(this, this.f);
    }

    public final void j(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.MainClassicsHeader);
        this.f = obtainStyledAttributes.getColor(R.styleable.MainClassicsHeader_srlPrimaryColor, -1);
        obtainStyledAttributes.recycle();
        setGravity(17);
        View inflate = LayoutInflater.from(context).inflate(R.layout.ethiopia_main_refresh_header, this, false);
        this.a = (ImageView) inflate.findViewById(R.id.iv_progress);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.iv_freshing);
        this.b = imageView;
        imageView.setVisibility(4);
        addView(inflate);
        AnimationDrawable animationDrawable = this.c;
        if (animationDrawable == null) {
            this.c = (AnimationDrawable) this.a.getBackground();
        } else {
            this.a.setBackground(animationDrawable);
        }
    }

    public void setFinishDrawable(int i) {
        if (i != -1) {
            this.e = i;
        }
    }

    public void setPrimaryColors(int... iArr) {
    }

    public void setRefreshingDrawable(int i) {
        if (i != -1) {
            this.d = i;
        }
    }

    public MainClassicsHeader(Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        j(context, attributeSet);
    }

    public final void i(@NonNull d dVar, int i, int i2) {
    }
}
