package com.huawei.payment.base;

import android.app.Application;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class App extends Application {
    static {
        System.loadLibrary("sqlcipher");
    }

    public final Resources getResources() {
        Resources resources = super.getResources();
        if (resources.getConfiguration().fontScale != 1.0f) {
            Configuration configuration = new Configuration();
            configuration.setToDefaults();
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        }
        return resources;
    }

    public final void onConfigurationChanged(@NonNull Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (configuration.fontScale != 1.0f) {
            getResources();
        }
    }

    /* JADX WARNING: type inference failed for: r5v2, types: [n0.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r5v6, types: [L3.b, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r7v3, types: [s6.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r7v8, types: [androidx.lifecycle.LifecycleObserver, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r5v27, types: [java.lang.Object, F0.a] */
    /* JADX WARNING: type inference failed for: r5v31, types: [java.lang.Object, B2.a] */
    /* JADX WARNING: type inference failed for: r3v1, types: [java.lang.Object, com.google.android.gms.tasks.OnCompleteListener] */
    /* JADX WARNING: type inference failed for: r8v17, types: [u6.b, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r8v18, types: [java.lang.Object, q6.c$c] */
    /* JADX WARNING: type inference failed for: r9v4, types: [com.huawei.kbz.jobqueue.persistentQueue.sqlite.b$b, java.lang.Object] */
    /* JADX WARNING: Can't wrap try/catch for region: R(30:12|13|14|15|16|17|18|19|(1:23)|24|25|26|27|28|29|(1:33)|34|35|(1:38)|39|(1:41)|42|187|(2:50|51)|52|(2:54|55)|58|(1:60)|61|70) */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x0094 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:28:0x00e0 */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:71:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate() {
        /*
            r12 = this;
            r0 = 0
            r2 = 10
            r3 = -4
            r4 = 0
            super.onCreate()
            int r5 = android.os.Process.myPid()
            java.lang.String r6 = "activity"
            java.lang.Object r6 = r12.getSystemService(r6)
            android.app.ActivityManager r6 = (android.app.ActivityManager) r6
            java.util.List r6 = r6.getRunningAppProcesses()
            if (r6 != 0) goto L_0x001d
        L_0x001b:
            r5 = r4
            goto L_0x0033
        L_0x001d:
            java.util.Iterator r6 = r6.iterator()
        L_0x0021:
            boolean r7 = r6.hasNext()
            if (r7 == 0) goto L_0x001b
            java.lang.Object r7 = r6.next()
            android.app.ActivityManager$RunningAppProcessInfo r7 = (android.app.ActivityManager.RunningAppProcessInfo) r7
            int r8 = r7.pid
            if (r8 != r5) goto L_0x0021
            java.lang.String r5 = r7.processName
        L_0x0033:
            if (r5 == 0) goto L_0x0041
            java.lang.String r6 = r12.getPackageName()
            boolean r5 = r5.equals(r6)
            if (r5 != 0) goto L_0x0041
            goto L_0x02ee
        L_0x0041:
            n0.a r5 = new n0.a
            r5.<init>()
            java.lang.Thread$UncaughtExceptionHandler r6 = java.lang.Thread.getDefaultUncaughtExceptionHandler()
            android.os.Handler r7 = new android.os.Handler
            android.os.Looper r8 = android.os.Looper.getMainLooper()
            r7.<init>(r8)
            V1.c r8 = new V1.c
            r8.<init>(r6, r5)
            r7.post(r8)
            V1.d r7 = new V1.d
            r7.<init>(r6, r5)
            java.lang.Thread.setDefaultUncaughtExceptionHandler(r7)
            r5 = 17
            V1.k.c = r5
            int r5 = com.huawei.ethiopia.allmodule.R.drawable.toast_bg
            V1.k.e = r5
            r5 = -1
            V1.k.f = r5
            L3.b r5 = new L3.b
            r5.<init>()
            java.lang.String r6 = "PIN_KEY"
            java.lang.String r7 = "SIGN_KEY"
            java.lang.String r8 = ""
            r9 = 1
            L3.a.c = r5     // Catch:{ Exception -> 0x0114 }
            W2.n r5 = W2.n.b(r8)     // Catch:{ Exception -> 0x0114 }
            java.lang.String r5 = r5.e(r7)     // Catch:{ Exception -> 0x0114 }
            M1.e r10 = M1.e.a     // Catch:{ Exception -> 0x0114 }
            java.lang.String r5 = r10.b(r5)     // Catch:{ Exception -> 0x0114 }
            java.lang.Class<com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean> r10 = com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean.class
            java.lang.Object r5 = com.blankj.utilcode.util.k.a(r5, r10)     // Catch:{ Exception -> 0x0094 }
            com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean r5 = (com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean) r5     // Catch:{ Exception -> 0x0094 }
            L3.a.a = r5     // Catch:{ Exception -> 0x0094 }
        L_0x0094:
            com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean r5 = L3.a.a     // Catch:{ Exception -> 0x0114 }
            if (r5 == 0) goto L_0x00a2
            java.lang.String r5 = r5.getSignKey()     // Catch:{ Exception -> 0x0114 }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ Exception -> 0x0114 }
            if (r5 == 0) goto L_0x00c0
        L_0x00a2:
            com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean r5 = new com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean     // Catch:{ Exception -> 0x0114 }
            java.lang.String r10 = "01"
            java.lang.String r11 = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAmHeA4cFyHpVp1s4os4h2JeU2Te2zpbaBpzhV8x9J43r8hqferIi21fdudc70XkolpEOQERzSegh6QR9MA3TlPjRTdaW2WSKwx+D9IX9N6Uty6EL6tS39v0b76+EV7qJAedXvtb78KlPTonguq1kpUq08K8gF12ifUA/u/Iejcj6fK82vGBmgtlY2EbeaeAIkwLBBWDmHIkexgzf003+a1M0/+XHVUaaOxWkcmpOrdTPA9TeVPRX4TIYQLMBMPd0y+9DJPoTGpbJYJf/J0xvUSwP285QDpxR+1ZLg7FREqgkOTC/DgJ1cL/aX8LnxpCU3DG+608RNp6MJa2AF+y+x5nTs5zKKVLPd1U4Vjh2dXa/ETN32HtfFjY670fLDjlwM7chIRLX2RL6RD3YSeEH2TBT/TMlCxLcaG+E0O1rzcSKyBPCjj5clwVQ3mQ2u7dtCm4zz2nAyyLIpR+WId0nS7egTsHokeV7fpU6kvdNVfamACDxQzFb9nLrJmj6y2YUnXhbyquhWt8XjzDEZneKDDyS6jQddkz8Az0u8khckM1V3YzEYlXpvesCc5r63QXqri5McWEzfL9TCWkufa3WBKVVSp4B2sxP5Z6GvAyrzNycjycIFkgqa/AeLN76xEssyPHMUtgx6cPnwmy1aa0X+xbFl/ovpywgR3h5GVqy0oR8CAwEAAQ=="
            r5.<init>(r10, r11)     // Catch:{ Exception -> 0x0114 }
            L3.a.a = r5     // Catch:{ Exception -> 0x0114 }
            W2.n r5 = W2.n.b(r8)     // Catch:{ Exception -> 0x0114 }
            M1.e r10 = M1.e.a     // Catch:{ Exception -> 0x0114 }
            com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean r11 = L3.a.a     // Catch:{ Exception -> 0x0114 }
            java.lang.String r11 = com.blankj.utilcode.util.k.d(r11)     // Catch:{ Exception -> 0x0114 }
            java.lang.String r10 = r10.a(r11)     // Catch:{ Exception -> 0x0114 }
            r5.g(r7, r10, r9)     // Catch:{ Exception -> 0x0114 }
        L_0x00c0:
            com.huawei.digitalpayment.customer.httplib.bean.SignKeyBean r5 = L3.a.a     // Catch:{ Exception -> 0x0114 }
            com.blankj.utilcode.util.k.d(r5)     // Catch:{ Exception -> 0x0114 }
            V1.h.b()     // Catch:{ Exception -> 0x0114 }
            W2.n r5 = W2.n.b(r8)     // Catch:{ Exception -> 0x0114 }
            java.lang.String r5 = r5.e(r6)     // Catch:{ Exception -> 0x0114 }
            M1.e r7 = M1.e.a     // Catch:{ Exception -> 0x0114 }
            java.lang.String r5 = r7.b(r5)     // Catch:{ Exception -> 0x0114 }
            java.lang.Class<com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean> r7 = com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean.class
            java.lang.Object r5 = com.blankj.utilcode.util.k.a(r5, r7)     // Catch:{ Exception -> 0x00e0 }
            com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean r5 = (com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean) r5     // Catch:{ Exception -> 0x00e0 }
            L3.a.b = r5     // Catch:{ Exception -> 0x00e0 }
        L_0x00e0:
            com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean r5 = L3.a.b     // Catch:{ Exception -> 0x0114 }
            if (r5 == 0) goto L_0x00ee
            java.lang.String r5 = r5.getPinKey()     // Catch:{ Exception -> 0x0114 }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ Exception -> 0x0114 }
            if (r5 == 0) goto L_0x010c
        L_0x00ee:
            com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean r5 = new com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean     // Catch:{ Exception -> 0x0114 }
            java.lang.String r7 = "01"
            java.lang.String r10 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqLcFdVcV7HdEOotsNLoMPhD74CX1ejzcgfNuiJNy9pTySxbszRBCWxmok3Unul4rX/zyVD/6vDb9nbqRywZIgR46UOn+tR3vGXXPX6igxgS6DYTaQV8W858yOGLuoYwRi5xeQJfczAMU4o+sCxlBbMCqYs4nzW81fi8iF2OEUdrfJcbamhSnksdgfD/nomWy9MESAz1QufrOBnaRX2N0CKsi8SNmzsghpfP15VLiIVV8YXPFKtd9sY37FpY28OKGjKG5wdije/bzFL8qEcPDhqYGuVaGkhX1bkI0iH+UcFtYYrZv/Fyb5jRHXmNLiq4mMG0fMH8ENxNACFtRZTDIIQIDAQAB"
            r5.<init>(r7, r10)     // Catch:{ Exception -> 0x0114 }
            L3.a.b = r5     // Catch:{ Exception -> 0x0114 }
            W2.n r5 = W2.n.b(r8)     // Catch:{ Exception -> 0x0114 }
            M1.e r7 = M1.e.a     // Catch:{ Exception -> 0x0114 }
            com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean r8 = L3.a.b     // Catch:{ Exception -> 0x0114 }
            java.lang.String r8 = com.blankj.utilcode.util.k.d(r8)     // Catch:{ Exception -> 0x0114 }
            java.lang.String r7 = r7.a(r8)     // Catch:{ Exception -> 0x0114 }
            r5.g(r6, r7, r9)     // Catch:{ Exception -> 0x0114 }
        L_0x010c:
            com.huawei.digitalpayment.customer.httplib.bean.PinKeyBean r5 = L3.a.b     // Catch:{ Exception -> 0x0114 }
            com.blankj.utilcode.util.k.d(r5)     // Catch:{ Exception -> 0x0114 }
            V1.h.b()     // Catch:{ Exception -> 0x0114 }
        L_0x0114:
            E2.a r5 = E2.a.a()
            r5.a = r12
            F2.a r5 = E2.a.c
            r12.registerActivityLifecycleCallbacks(r5)
            int r5 = com.huawei.digitalpayment.customer.baselib.base.BaseActivity.c
            java.lang.String r5 = "telebirrchat.ethiomobilemoney.et"
            n2.a.a = r5
            java.lang.String r5 = "13000"
            n2.a.b = r5
            java.lang.String r5 = "https://telebirrchat.ethiomobilemoney.et:21006"
            n2.a.c = r5
            java.lang.String r5 = "1012673623603201"
            n2.a.d = r5
            q6.e r5 = q6.e.a.a
            r5.a = r12
            android.content.Context r6 = r12.getApplicationContext()
            s6.a r7 = new s6.a
            r7.<init>()
            r7.b = r9
            r8 = 3
            r7.a = r8
            r8 = 120(0x78, float:1.68E-43)
            r7.c = r8
            q6.c$c r8 = r7.d
            if (r8 != 0) goto L_0x0159
            q6.c$c r8 = new q6.c$c
            r8.<init>()
            com.huawei.kbz.jobqueue.persistentQueue.sqlite.b$b r9 = new com.huawei.kbz.jobqueue.persistentQueue.sqlite.b$b
            r9.<init>()
            r8.a = r9
            r7.d = r8
        L_0x0159:
            u6.b r8 = r7.e
            if (r8 != 0) goto L_0x0166
            u6.b r8 = new u6.b
            r8.<init>()
            r8.b = r6
            r7.e = r8
        L_0x0166:
            q6.c r6 = new q6.c
            com.huawei.payment.base.App r8 = r5.a
            r6.<init>(r8, r7)
            r5.b = r6
            java.util.LinkedList r5 = E6.a.a
            E6.a$a r5 = E6.a.b
            r12.registerActivityLifecycleCallbacks(r5)
            java.lang.String r5 = "chat_database_guest"
            java.lang.String r6 = "guestAccessKey"
            com.huawei.kbz.chat.storage.l.i(r12, r5, r6)
            J8.b r5 = J8.b.a()
            r5.a = r12
            android.os.Handler r5 = a9.a.a
            java.lang.Class<a9.a> r5 = a9.a.class
            monitor-enter(r5)
            a9.a.c = r12     // Catch:{ all -> 0x01a8 }
            android.os.HandlerThread r6 = a9.a.b     // Catch:{ all -> 0x01a8 }
            if (r6 != 0) goto L_0x01ab
            android.os.HandlerThread r6 = new android.os.HandlerThread     // Catch:{ all -> 0x01a8 }
            java.lang.String r7 = "db-thread"
            r6.<init>(r7)     // Catch:{ all -> 0x01a8 }
            a9.a.b = r6     // Catch:{ all -> 0x01a8 }
            r6.start()     // Catch:{ all -> 0x01a8 }
            android.os.Handler r6 = new android.os.Handler     // Catch:{ all -> 0x01a8 }
            android.os.HandlerThread r7 = a9.a.b     // Catch:{ all -> 0x01a8 }
            android.os.Looper r7 = r7.getLooper()     // Catch:{ all -> 0x01a8 }
            r6.<init>(r7)     // Catch:{ all -> 0x01a8 }
            a9.a.a = r6     // Catch:{ all -> 0x01a8 }
            goto L_0x01ab
        L_0x01a8:
            r0 = move-exception
            goto L_0x02ef
        L_0x01ab:
            monitor-exit(r5)
            java.lang.String r5 = n2.a.a     // Catch:{ NumberFormatException -> 0x01b8 }
            java.lang.String r6 = n2.a.b     // Catch:{ NumberFormatException -> 0x01b8 }
            int r6 = java.lang.Integer.parseInt(r6)     // Catch:{ NumberFormatException -> 0x01b8 }
            J8.a.a = r5     // Catch:{ NumberFormatException -> 0x01b8 }
            J8.a.b = r6     // Catch:{ NumberFormatException -> 0x01b8 }
        L_0x01b8:
            com.shinemo.chat.CYClient r5 = com.shinemo.chat.CYClient.getInstance()
            r6 = 0
            r5.init(r12, r6)
            com.onemdos.contact.MDOSContact.init(r12)
            androidx.lifecycle.ViewModelStore r5 = new androidx.lifecycle.ViewModelStore
            r5.<init>()
            com.huawei.kbz.chat.storage.l.o = r5
            androidx.lifecycle.ViewModelProvider$AndroidViewModelFactory r5 = androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(r12)
            androidx.lifecycle.ViewModelProvider r7 = new androidx.lifecycle.ViewModelProvider
            androidx.lifecycle.ViewModelStore r8 = com.huawei.kbz.chat.storage.l.o
            r7.<init>(r8, r5)
            com.huawei.kbz.chat.storage.l.n = r7
            com.huawei.kbz.chat.storage.l r5 = com.huawei.kbz.chat.storage.l.a.a
            java.lang.Class<com.huawei.kbz.chat.chat_list.view_model.ChatListViewModel> r7 = com.huawei.kbz.chat.chat_list.view_model.ChatListViewModel.class
            androidx.lifecycle.ViewModel r7 = com.huawei.kbz.chat.storage.l.f(r7)
            com.huawei.kbz.chat.chat_list.view_model.ChatListViewModel r7 = (com.huawei.kbz.chat.chat_list.view_model.ChatListViewModel) r7
            r5.m = r7
            androidx.lifecycle.LifecycleOwner r5 = androidx.lifecycle.ProcessLifecycleOwner.get()
            androidx.lifecycle.Lifecycle r5 = r5.getLifecycle()
            com.huawei.kbz.chat.storage.ChatLifeObserver r7 = new com.huawei.kbz.chat.storage.ChatLifeObserver
            r7.<init>()
            r5.addObserver(r7)
            F0.a r5 = new F0.a
            r5.<init>()
            java.io.File r7 = new java.io.File
            java.io.File r8 = r12.getFilesDir()
            java.lang.String r9 = "sticker"
            r7.<init>(r8, r9)
            java.lang.String r7 = r7.getAbsolutePath()
            android.content.Context r8 = r12.getApplicationContext()
            a6.j.a = r8
            android.content.Context r8 = r12.getApplicationContext()
            android.content.res.Resources r8 = r8.getResources()
            android.util.DisplayMetrics r8 = r8.getDisplayMetrics()
            float r8 = r8.density
            a6.j.b = r7
            a6.j.a(r9)
            a6.j.c = r5
            com.shinemo.chat.CYClient r5 = com.shinemo.chat.CYClient.getInstance()
            r5.logout()
            java.lang.String r5 = "apigm-beta.huawei.com/ws/MESSAGE/message/test/oa"
            i2.a.d = r5
            java.lang.String r5 = "mcloud-uat.huawei.com/mcloud/mag/FreeProxyForUpload/KBZ_112_TEST_UPLOAD/message/test/oa"
            i2.a.e = r5
            B2.a r5 = new B2.a
            r5.<init>()
            L2.c.a = r5
            n0.d.a(r12)
            r3.a r5 = new r3.a
            r5.<init>()
            com.huawei.digitalpayment.customer.homev6.viewmodel.HomeViewModel r7 = com.huawei.digitalpayment.customer.homev6.viewmodel.HomeViewModel.e()
            r7.getClass()
            D3.b r8 = new D3.b
            java.lang.String r9 = ""
            r8.<init>(r7, r9)
            java.util.concurrent.ExecutorService r9 = com.blankj.utilcode.util.A.f(r3, r2)
            com.blankj.utilcode.util.A.b(r9, r8, r0, r4)
            D3.d r8 = new D3.d
            r8.<init>(r7)
            java.util.concurrent.ExecutorService r7 = com.blankj.utilcode.util.A.f(r3, r2)
            com.blankj.utilcode.util.A.b(r7, r8, r0, r4)
            S1.a.b(r5)
            n0.c r5 = new n0.c
            r5.<init>(r12)
            java.util.concurrent.ExecutorService r2 = com.blankj.utilcode.util.A.f(r3, r2)
            com.blankj.utilcode.util.A.b(r2, r5, r0, r4)
            android.webkit.WebView r0 = new android.webkit.WebView     // Catch:{ Exception -> 0x0279 }
            r0.<init>(r12)     // Catch:{ Exception -> 0x0279 }
            r0.destroy()     // Catch:{ Exception -> 0x0279 }
            goto L_0x0280
        L_0x0279:
            r0 = move-exception
            r0.toString()
            V1.h.b()
        L_0x0280:
            com.google.firebase.FirebaseApp.initializeApp(r12)
            V1.h.b()
            java.lang.String r0 = ""
            W2.n r1 = W2.n.b(r0)
            android.content.SharedPreferences r1 = r1.a
            java.lang.String r2 = "FIREBASE_TOKEN"
            java.lang.String r1 = r1.getString(r2, r0)
            V1.h.b()
            com.google.firebase.messaging.FirebaseMessaging r2 = com.google.firebase.messaging.FirebaseMessaging.getInstance()
            com.google.android.gms.tasks.Task r2 = r2.getToken()
            b8.a r3 = new b8.a
            r3.<init>()
            r2.addOnCompleteListener(r3)
            if (r1 != 0) goto L_0x02aa
            goto L_0x02ab
        L_0x02aa:
            r0 = r1
        L_0x02ab:
            k3.c r1 = k3.c.c
            java.lang.String r1 = ""
            W2.n r1 = W2.n.b(r1)
            java.lang.String r2 = "FIREBASE_TOKEN"
            r1.g(r2, r0, r6)
            I3.c.b()
            java.lang.String r0 = "prod"
            Rb.a.a = r0
            java.lang.String r0 = "window"
            java.lang.Object r0 = r12.getSystemService(r0)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            android.util.DisplayMetrics r1 = new android.util.DisplayMetrics
            r1.<init>()
            android.view.Display r0 = r0.getDefaultDisplay()
            r0.getMetrics(r1)
            java.lang.String r0 = android.os.Build.VERSION.RELEASE
            java.lang.String r0 = android.os.Build.MODEL
            java.lang.String r0 = android.os.Build.BRAND
            V1.h.b()
            com.huawei.http.b.setDEBUG(r6)
            E8.a r0 = E8.a.c
            B2.a.a(r0)
            E4.a r0 = E4.a.c
            B2.a.a(r0)
            K2.a r0 = K2.a.c
            B2.a.a(r0)
        L_0x02ee:
            return
        L_0x02ef:
            monitor-exit(r5)     // Catch:{ all -> 0x01a8 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.payment.base.App.onCreate():void");
    }

    public final void startActivity(Intent intent) {
        intent.addFlags(268435456);
        super.startActivity(intent);
    }

    public final void startActivity(Intent intent, @Nullable Bundle bundle) {
        intent.addFlags(268435456);
        super.startActivity(intent, bundle);
    }
}
