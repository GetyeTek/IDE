package com.huawei.payment;

public final class R$navigation {
    public static final int in_app_nav = 2131820544;
    public static final int nav_camera = 2131820545;

    private R$navigation() {
    }
}
