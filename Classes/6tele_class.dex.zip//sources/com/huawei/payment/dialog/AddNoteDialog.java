package com.huawei.payment.dialog;

import B3.b;
import D6.k;
import H1.c;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import com.huawei.ethiopia.ethiopialib.R;
import com.huawei.ethiopia.ethiopialib.databinding.EthiopiaDialogAddNoteBinding;

public class AddNoteDialog extends DialogFragment {
    public final String a;
    public final b b;
    public final String c;
    public EthiopiaDialogAddNoteBinding d;
    public int e;

    public class a implements InputFilter {
        public a() {
        }

        public final CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
            while (i < i2) {
                char charAt = charSequence.charAt(i);
                AddNoteDialog.this.getClass();
                if (charAt == '<' || charAt == '>' || charAt == '(' || charAt == ')' || charAt == '=') {
                    return "";
                }
                i++;
            }
            return null;
        }
    }

    public AddNoteDialog(String str, String str2, b bVar, int i) {
        this.c = str;
        this.a = str2;
        this.b = bVar;
        this.e = i;
    }

    public final void onAttach(@NonNull Context context) {
        AddNoteDialog.super.onAttach(context);
        FragmentActivity fragmentActivity = (FragmentActivity) context;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0012, code lost:
        r8 = com.huawei.ethiopia.ethiopialib.R.id.btn_sure;
     */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r7, @androidx.annotation.Nullable android.view.ViewGroup r8, @androidx.annotation.Nullable android.os.Bundle r9) {
        /*
            r6 = this;
            int r9 = com.huawei.ethiopia.ethiopialib.R.layout.ethiopia_dialog_add_note
            r0 = 0
            android.view.View r7 = r7.inflate(r9, r8, r0)
            int r8 = com.huawei.ethiopia.ethiopialib.R.id.btn_cancel
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r2 = r9
            com.huawei.common.widget.round.RoundTextView r2 = (com.huawei.common.widget.round.RoundTextView) r2
            if (r2 == 0) goto L_0x0049
            int r8 = com.huawei.ethiopia.ethiopialib.R.id.btn_sure
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r3 = r9
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            if (r3 == 0) goto L_0x0049
            int r8 = com.huawei.ethiopia.ethiopialib.R.id.etNote
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r4 = r9
            android.widget.EditText r4 = (android.widget.EditText) r4
            if (r4 == 0) goto L_0x0049
            int r8 = com.huawei.ethiopia.ethiopialib.R.id.line
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            com.huawei.common.widget.round.RoundTextView r9 = (com.huawei.common.widget.round.RoundTextView) r9
            if (r9 == 0) goto L_0x0049
            int r8 = com.huawei.ethiopia.ethiopialib.R.id.tv_title
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r5 = r9
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x0049
            com.huawei.ethiopia.ethiopialib.databinding.EthiopiaDialogAddNoteBinding r8 = new com.huawei.ethiopia.ethiopialib.databinding.EthiopiaDialogAddNoteBinding
            com.huawei.common.widget.round.RoundConstraintLayout r7 = (com.huawei.common.widget.round.RoundConstraintLayout) r7
            r0 = r8
            r1 = r7
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r8
            return r7
        L_0x0049:
            android.content.res.Resources r7 = r7.getResources()
            java.lang.String r7 = r7.getResourceName(r8)
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            java.lang.String r9 = "Missing required view with ID: "
            java.lang.String r7 = r9.concat(r7)
            r8.<init>(r7)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.payment.dialog.AddNoteDialog.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onStart() {
        Window window;
        AddNoteDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            window.setBackgroundDrawableResource(17170445);
            c.b(window, R.style.BottomAnimation, dialog, true, true);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        AddNoteDialog.super.onViewCreated(view, bundle);
        this.d.e.setText(this.c);
        this.d.d.setInputType(1);
        if (this.e <= 0) {
            this.e = 50;
        }
        this.d.d.setFilters(new InputFilter[]{new a(), new InputFilter.LengthFilter(this.e)});
        this.d.d.requestFocus();
        this.d.d.setFocusableInTouchMode(true);
        this.d.b.setOnClickListener(new O7.a(this, 0));
        EditText editText = this.d.d;
        String str = this.a;
        editText.setText(str);
        if (str != null) {
            EditText editText2 = this.d.d;
            editText2.setSelection(editText2.getText().length());
        }
        this.d.c.setOnClickListener(new k(this, 1));
        this.d.d.post(new O7.b(this, 0));
    }
}
