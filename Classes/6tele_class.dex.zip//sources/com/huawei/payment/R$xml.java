package com.huawei.payment;

public final class R$xml {
    public static final int common_file_path = 2132213760;
    public static final int file_paths = 2132213761;
    public static final int network_security_config = 2132213762;
    public static final int share_file_path = 2132213763;
    public static final int update_file_path = 2132213764;
    public static final int util_code_provider_paths = 2132213765;

    private R$xml() {
    }
}
