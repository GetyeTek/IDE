package com.huawei.qrcode.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class ActivityVerifyPaymentResultBinding extends ViewDataBinding {
    @NonNull
    public final ImageView a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final HFRecyclerView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;

    public ActivityVerifyPaymentResultBinding(DataBindingComponent dataBindingComponent, View view, ImageView imageView, LoadingButton loadingButton, HFRecyclerView hFRecyclerView, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = imageView;
        this.b = loadingButton;
        this.c = hFRecyclerView;
        this.d = textView;
        this.e = textView2;
        this.f = textView3;
        this.g = textView4;
    }
}
