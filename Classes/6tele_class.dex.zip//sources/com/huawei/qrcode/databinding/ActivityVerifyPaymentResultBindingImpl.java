package com.huawei.qrcode.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.qrcode.R$id;

public class ActivityVerifyPaymentResultBindingImpl extends ActivityVerifyPaymentResultBinding {
    @Nullable
    public static final SparseIntArray i;
    public long h;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        i = sparseIntArray;
        sparseIntArray.put(R$id.iv_status, 1);
        sparseIntArray.put(R$id.tv_subtitle, 2);
        sparseIntArray.put(R$id.tvCurrency, 3);
        sparseIntArray.put(R$id.currencylayout, 4);
        sparseIntArray.put(R$id.tv_amount, 5);
        sparseIntArray.put(R$id.tv_currency_pre, 6);
        sparseIntArray.put(R$id.tv_coupon_pay, 7);
        sparseIntArray.put(R$id.tv_hint, 8);
        sparseIntArray.put(R$id.tv_title, 9);
        sparseIntArray.put(R$id.cl_other_info, 10);
        sparseIntArray.put(R$id.id_view, 11);
        sparseIntArray.put(R$id.rv_other_info, 12);
        sparseIntArray.put(R$id.lb_finish, 13);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.h = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.h != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.h = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i2, Object obj, int i3) {
        return false;
    }

    public final boolean setVariable(int i2, @Nullable Object obj) {
        return true;
    }
}
