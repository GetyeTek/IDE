package com.huawei.qrcode.databinding;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import androidx.viewpager.widget.ViewPager;

public final class ActivityScanAndPayBinding implements ViewBinding {
    @NonNull
    public final FrameLayout a;
    @NonNull
    public final ImageButton b;
    @NonNull
    public final ViewPager c;

    public ActivityScanAndPayBinding(@NonNull FrameLayout frameLayout, @NonNull ImageButton imageButton, @NonNull ViewPager viewPager) {
        this.a = frameLayout;
        this.b = imageButton;
        this.c = viewPager;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
