package com.huawei.qrcode.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.viewbinding.ViewBinding;

public final class FragmentScanGuideBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final AppCompatCheckBox b;
    @NonNull
    public final LinearLayout c;

    public FragmentScanGuideBinding(@NonNull LinearLayout linearLayout, @NonNull AppCompatCheckBox appCompatCheckBox, @NonNull LinearLayout linearLayout2) {
        this.a = linearLayout;
        this.b = appCompatCheckBox;
        this.c = linearLayout2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
