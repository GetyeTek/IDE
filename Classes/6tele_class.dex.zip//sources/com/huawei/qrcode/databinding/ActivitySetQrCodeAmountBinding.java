package com.huawei.qrcode.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public final class ActivitySetQrCodeAmountBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final Button b;
    @NonNull
    public final InputItemEditText c;
    @NonNull
    public final EditText d;

    public ActivitySetQrCodeAmountBinding(@NonNull LinearLayout linearLayout, @NonNull Button button, @NonNull InputItemEditText inputItemEditText, @NonNull EditText editText) {
        this.a = linearLayout;
        this.b = button;
        this.c = inputItemEditText;
        this.d = editText;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
