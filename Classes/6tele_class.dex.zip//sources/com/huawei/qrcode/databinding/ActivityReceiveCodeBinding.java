package com.huawei.qrcode.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.common.widget.round.RoundTextView;

public final class ActivityReceiveCodeBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final RoundImageView b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final RoundTextView h;
    @NonNull
    public final RoundTextView i;

    public ActivityReceiveCodeBinding(@NonNull ConstraintLayout constraintLayout, @NonNull RoundImageView roundImageView, @NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull RoundTextView roundTextView, @NonNull RoundTextView roundTextView2) {
        this.a = constraintLayout;
        this.b = roundImageView;
        this.c = linearLayout;
        this.d = textView;
        this.e = textView2;
        this.f = textView3;
        this.g = textView4;
        this.h = roundTextView;
        this.i = roundTextView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
