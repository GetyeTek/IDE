package com.huawei.qrcode.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.input.CommonInputView;

public abstract class ActivityVerifyPaymentBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final CommonInputView b;

    public ActivityVerifyPaymentBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, CommonInputView commonInputView) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = commonInputView;
    }
}
