package com.huawei.qrcode.receive;

import V1.k;
import W2.g;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.qrcode.R$string;
import com.huawei.qrcode.databinding.ActivitySetQrCodeAmountBinding;
import k3.a;
import k8.c;

public class SetQrCodeAmountActivity extends BaseTitleActivity {
    public ActivitySetQrCodeAmountBinding i;

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r1v4, types: [k8.c, android.text.TextWatcher] */
    public final void G0() {
        SetQrCodeAmountActivity.super.G0();
        O0(R$string.designstandard_set_amount);
        InputItemEditText inputItemEditText = this.i.c;
        inputItemEditText.setCurrency("(" + a.e.b() + ")");
        this.i.b.setAlpha(0.4f);
        this.i.b.setClickable(false);
        this.i.c.addTextChangedListener(new c(this));
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [com.huawei.qrcode.receive.SetQrCodeAmountActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.qrcode.R$id.edit_amount;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r6 = this;
            android.view.LayoutInflater r0 = r6.getLayoutInflater()
            int r1 = com.huawei.qrcode.R$layout.activity_set_qr_code_amount
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.qrcode.R$id.btn_ok
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.Button r2 = (android.widget.Button) r2
            if (r2 == 0) goto L_0x0046
            int r1 = com.huawei.qrcode.R$id.edit_amount
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r3 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r3
            if (r3 == 0) goto L_0x0046
            int r1 = com.huawei.qrcode.R$id.et_add_note
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.EditText r4 = (android.widget.EditText) r4
            if (r4 == 0) goto L_0x0046
            int r1 = com.huawei.qrcode.R$id.line
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r5 == 0) goto L_0x0046
            int r1 = com.huawei.qrcode.R$id.tv_amount
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x0046
            com.huawei.qrcode.databinding.ActivitySetQrCodeAmountBinding r1 = new com.huawei.qrcode.databinding.ActivitySetQrCodeAmountBinding
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r1.<init>(r0, r2, r3, r4)
            r6.i = r1
            return r1
        L_0x0046:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.qrcode.receive.SetQrCodeAmountActivity.K0():androidx.viewbinding.ViewBinding");
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.qrcode.receive.SetQrCodeAmountActivity, android.app.Activity] */
    public void onViewClick(View view) {
        String obj = this.i.c.getText().toString();
        if (!g.a(obj)) {
            k.b(1, getString(R$string.designstandard_incorrect_amount_format));
            return;
        }
        Intent intent = new Intent();
        intent.putExtra("amount", obj);
        String obj2 = this.i.d.getText().toString();
        if (!TextUtils.isEmpty(obj2) && obj2.length() > 128) {
            obj2 = obj2.substring(0, 128);
        }
        intent.putExtra("notes", obj2);
        setResult(-1, intent);
        finish();
    }
}
