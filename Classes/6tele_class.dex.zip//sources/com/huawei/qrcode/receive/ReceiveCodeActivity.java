package com.huawei.qrcode.receive;

import E0.c;
import M.g;
import R9.h;
import W2.j;
import W2.n;
import W2.r;
import W2.s;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.camera.core.m;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.k;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.common.widget.dialog.SetAmountPop;
import com.huawei.digitalpayment.customer.baselib.R;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.httplib.pic.GlideApp;
import com.huawei.digitalpayment.customer.httplib.response.GetQrCodeResp;
import com.huawei.image.glide.Base64Mode;
import com.huawei.qrcode.R$color;
import com.huawei.qrcode.R$id;
import com.huawei.qrcode.R$string;
import com.huawei.qrcode.databinding.ActivityReceiveCodeBinding;
import java.util.ArrayList;
import java.util.List;
import l8.b;

@Route(path = "/qrCodeModule/receive")
public class ReceiveCodeActivity extends BaseMvpActivity<b> implements m8.a {
    public static final /* synthetic */ int t = 0;
    public ActivityReceiveCodeBinding j;
    public Bitmap k;
    public final ArrayList l = new ArrayList();
    public String m;
    public String n = "";
    public Handler o = new Handler();
    public Bitmap p;
    public SetAmountPop q;
    public boolean r;
    public final a s = new a();

    public class a implements Runnable {
        public a() {
        }

        public final void run() {
            int i = ReceiveCodeActivity.t;
            ReceiveCodeActivity receiveCodeActivity = ReceiveCodeActivity.this;
            receiveCodeActivity.W0();
            if (!"0".equals(receiveCodeActivity.m)) {
                receiveCodeActivity.o.postDelayed(this, Long.parseLong(receiveCodeActivity.m) - r.d().getTime());
            }
        }
    }

    public final void D0() {
        this.i.b(this.n, "");
    }

    public final void F0() {
        if (this.a == null) {
            this.a = W1.b.b().c(this.j.b);
        }
    }

    public final void G(String str) {
        DialogManager.b(getSupportFragmentManager());
        this.r = false;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.qrcode.receive.ReceiveCodeActivity, android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void G0() {
        ReceiveCodeActivity.super.G0();
        O0(R$string.received_payment);
        int i = R$color.black;
        P0(i);
        int i2 = R$color.colorPageBackgroundDark;
        S0(i2);
        R0(i);
        f.e(this, getResources().getColor(i2), false);
        SetAmountPop setAmountPop = new SetAmountPop(this);
        this.q = setAmountPop;
        String b = k3.a.e.b();
        setAmountPop.c = b;
        setAmountPop.a.g.setText(b);
        SetAmountPop setAmountPop2 = this.q;
        setAmountPop2.b = new m(this, 3);
        setAmountPop2.setOnDismissListener(new k8.a(this));
        Customer f = c.f();
        if (f != null) {
            String nickName = f.getNickName();
            String msisdn = f.getMsisdn();
            this.j.e.setText(nickName + " (+" + msisdn + ")");
            this.j.h.setOnClickListener(new J6.b(this, 7));
        }
        g gVar = new g();
        int i3 = R.mipmap.icon_drawer_head;
        GlideApp.with(this).asBitmap().load(Base64Mode.getConsumerMode(c.f().getAvatar())).apply(gVar.error(i3).placeholder(i3).circleCrop()).into(new k8.b(this));
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [com.huawei.qrcode.receive.ReceiveCodeActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0058, code lost:
        r1 = com.huawei.qrcode.R$id.tv_save_image;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0063, code lost:
        r1 = com.huawei.qrcode.R$id.tv_set_amount;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r13 = this;
            android.view.LayoutInflater r0 = r13.getLayoutInflater()
            int r1 = com.huawei.qrcode.R$layout.activity_receive_code
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.qrcode.R$id.iv_qr
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.huawei.common.widget.round.RoundImageView r5 = (com.huawei.common.widget.round.RoundImageView) r5
            if (r5 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.ll_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            if (r6 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.recivelinear
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            if (r2 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.tv_currency
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            if (r7 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.tv_name
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.tv_notes
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.tv_receive_num
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            android.widget.TextView r10 = (android.widget.TextView) r10
            if (r10 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.tv_save_image
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            com.huawei.common.widget.round.RoundTextView r11 = (com.huawei.common.widget.round.RoundTextView) r11
            if (r11 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.tv_set_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r12 = r2
            com.huawei.common.widget.round.RoundTextView r12 = (com.huawei.common.widget.round.RoundTextView) r12
            if (r12 == 0) goto L_0x0084
            int r1 = com.huawei.qrcode.R$id.tv_title_label
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0084
            com.huawei.qrcode.databinding.ActivityReceiveCodeBinding r1 = new com.huawei.qrcode.databinding.ActivityReceiveCodeBinding
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r13.j = r1
            return r1
        L_0x0084:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.qrcode.receive.ReceiveCodeActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        DialogManager.d(getSupportFragmentManager(), true);
        this.r = true;
    }

    public final void V0() {
        this.j.f.setText("");
        this.j.g.setText("");
        this.j.d.setText("");
        this.j.f.setVisibility(8);
        this.j.c.setVisibility(8);
        this.q.a.b.setText("");
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [com.huawei.qrcode.receive.ReceiveCodeActivity, android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity] */
    public final void W0() {
        boolean z = true;
        while (z) {
            ArrayList arrayList = this.l;
            if (arrayList == null || arrayList.size() <= 0) {
                this.m = "0";
                this.i.b(this.n, "");
            } else if (Long.parseLong(((GetQrCodeResp.QrCode) arrayList.get(0)).getRefreshTime()) > r.d().getTime()) {
                this.k = j.c(h.a(this, 213.0f), h.a(this, 213.0f), ((GetQrCodeResp.QrCode) arrayList.get(0)).getQrCode());
                this.m = ((GetQrCodeResp.QrCode) arrayList.get(0)).getRefreshTime();
                if (this.p == null) {
                    this.p = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_drawer_head);
                }
                Bitmap a2 = j.a(this.k, j.b(this.p));
                this.k = a2;
                this.j.b.setImageBitmap(a2);
                arrayList.remove(0);
                if (TextUtils.isEmpty(this.n)) {
                    n.b("").g("RECEIVER_CODE", k.d(arrayList), false);
                }
            } else {
                arrayList.remove(0);
                if (TextUtils.isEmpty(this.n)) {
                    n.b("").g("RECEIVER_CODE", k.d(arrayList), false);
                }
            }
            z = false;
        }
    }

    public final void d(String str, List<GetQrCodeResp.QrCode> list) {
        if (list != null) {
            this.n = str;
            if (!TextUtils.isEmpty(str)) {
                this.j.i.setText(getResources().getString(R$string.designstandard_clear_amount));
                this.j.c.setVisibility(0);
            } else {
                this.j.i.setText(getResources().getString(R$string.designstandard_set_amount));
                this.j.c.setVisibility(8);
            }
            ArrayList arrayList = this.l;
            arrayList.clear();
            arrayList.addAll(list);
            W0();
            Handler handler = this.o;
            a aVar = this.s;
            handler.removeCallbacks(aVar);
            this.o.postDelayed(aVar, Long.parseLong(this.m) - r.d().getTime());
        }
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        ReceiveCodeActivity.super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null) {
            this.n = intent.getStringExtra("amount");
            String stringExtra = intent.getStringExtra("notes");
            if (!TextUtils.isEmpty(this.n)) {
                if (W2.g.a(this.n)) {
                    this.j.c.setVisibility(0);
                    TextView textView = this.j.d;
                    textView.setText("(" + k3.a.e.b() + ")");
                    this.j.g.setText(W2.c.d(this.n));
                    if (!TextUtils.isEmpty(stringExtra)) {
                        this.j.f.setVisibility(0);
                        this.j.f.setText(stringExtra);
                    } else {
                        this.j.f.setText("");
                        this.j.f.setVisibility(8);
                    }
                    this.i.b(this.n, stringExtra);
                    return;
                }
                this.i.b("", "");
                V0();
            }
        }
    }

    public final void onBackPressed() {
        SetAmountPop setAmountPop = this.q;
        if (setAmountPop == null || !setAmountPop.isShowing()) {
            ReceiveCodeActivity.super.onBackPressed();
            return;
        }
        SetAmountPop setAmountPop2 = this.q;
        if (setAmountPop2.isShowing()) {
            setAmountPop2.dismiss();
        }
    }

    public final void onDestroy() {
        ReceiveCodeActivity.super.onDestroy();
        Handler handler = this.o;
        if (handler != null) {
            handler.removeCallbacks(this.s);
            this.o = null;
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.qrcode.receive.ReceiveCodeActivity, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public void onViewClick(View view) {
        if (this.r || view.getId() != R$id.tv_set_amount) {
            return;
        }
        if (this.j.c.getVisibility() == 0) {
            this.j.g.setText("");
            this.i.b("", "");
            return;
        }
        this.q.a.b.setText("");
        s.a(this, 0.67f);
        this.q.c(this);
    }
}
