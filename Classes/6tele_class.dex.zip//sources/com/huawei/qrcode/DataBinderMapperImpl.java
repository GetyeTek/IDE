package com.huawei.qrcode;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.qrcode.databinding.ActivityVerifyPaymentBinding;
import com.huawei.qrcode.databinding.ActivityVerifyPaymentBindingImpl;
import com.huawei.qrcode.databinding.ActivityVerifyPaymentResultBinding;
import com.huawei.qrcode.databinding.ActivityVerifyPaymentResultBindingImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(2);
            a = hashMap;
            hashMap.put("layout/activity_verify_payment_0", Integer.valueOf(R$layout.activity_verify_payment));
            hashMap.put("layout/activity_verify_payment_result_0", Integer.valueOf(R$layout.activity_verify_payment_result));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(2);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_verify_payment, 1);
        sparseIntArray.put(R$layout.activity_verify_payment_result, 2);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(8);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new RuntimeException("view must have a tag");
            } else if (i2 != 1) {
                if (i2 == 2) {
                    if ("layout/activity_verify_payment_result_0".equals(tag)) {
                        Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 14, (ViewDataBinding.IncludedLayouts) null, ActivityVerifyPaymentResultBindingImpl.i);
                        ConstraintLayout constraintLayout = (ConstraintLayout) mapBindings[10];
                        ConstraintLayout constraintLayout2 = (ConstraintLayout) mapBindings[4];
                        View view3 = (View) mapBindings[11];
                        TextView textView = (TextView) mapBindings[7];
                        TextView textView2 = (TextView) mapBindings[3];
                        TextView textView3 = (TextView) mapBindings[8];
                        ActivityVerifyPaymentResultBinding activityVerifyPaymentResultBinding = new ActivityVerifyPaymentResultBinding(dataBindingComponent, view, (ImageView) mapBindings[1], (LoadingButton) mapBindings[13], (HFRecyclerView) mapBindings[12], (TextView) mapBindings[5], (TextView) mapBindings[6], (TextView) mapBindings[2], (TextView) mapBindings[9]);
                        activityVerifyPaymentResultBinding.h = -1;
                        ((ConstraintLayout) mapBindings[0]).setTag((Object) null);
                        activityVerifyPaymentResultBinding.setRootTag(view2);
                        activityVerifyPaymentResultBinding.invalidateAll();
                        return activityVerifyPaymentResultBinding;
                    }
                    throw new IllegalArgumentException(l.a(tag, "The tag for activity_verify_payment_result is invalid. Received: "));
                }
            } else if ("layout/activity_verify_payment_0".equals(tag)) {
                Object[] mapBindings2 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 3, (ViewDataBinding.IncludedLayouts) null, ActivityVerifyPaymentBindingImpl.d);
                ViewDataBinding activityVerifyPaymentBinding = new ActivityVerifyPaymentBinding(dataBindingComponent2, view2, (LoadingButton) mapBindings2[2], (CommonInputView) mapBindings2[1]);
                activityVerifyPaymentBinding.c = -1;
                ((ConstraintLayout) mapBindings2[0]).setTag((Object) null);
                activityVerifyPaymentBinding.setRootTag(view2);
                activityVerifyPaymentBinding.invalidateAll();
                return activityVerifyPaymentBinding;
            } else {
                throw new IllegalArgumentException(l.a(tag, "The tag for activity_verify_payment is invalid. Received: "));
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
