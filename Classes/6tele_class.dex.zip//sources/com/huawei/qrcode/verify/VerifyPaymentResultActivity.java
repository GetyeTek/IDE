package com.huawei.qrcode.verify;

import J8.a;
import S3.g;
import S3.h;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.qrcode.R$color;
import com.huawei.qrcode.R$layout;
import com.huawei.qrcode.R$mipmap;
import com.huawei.qrcode.databinding.ActivityVerifyPaymentResultBinding;
import com.huawei.qrcode.verify.VerifyPaymentResp;
import java.util.List;

@Route(path = "/qrCodeModule/verifyPaymentResult")
public class VerifyPaymentResultActivity extends DataBindingActivity<ActivityVerifyPaymentResultBinding, VerifyPaymentViewModel> {
    public static final /* synthetic */ int d = 0;

    public final int C0() {
        return R$layout.activity_verify_payment_result;
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.qrcode.verify.VerifyPaymentResultActivity, com.huawei.payment.mvvm.DataBindingActivity] */
    public final void E0(VerifyPaymentResp verifyPaymentResp) {
        if (TextUtils.equals("success", verifyPaymentResp.getState())) {
            ((ActivityVerifyPaymentResultBinding) this.b).a.setBackgroundResource(R$mipmap.qr_code_icon_result_success);
            ((ActivityVerifyPaymentResultBinding) this.b).g.setTextColor(ContextCompat.getColor(this, R$color.colorPrimary));
            ((ActivityVerifyPaymentResultBinding) this.b).c.setVisibility(0);
            ((ActivityVerifyPaymentResultBinding) this.b).d.setVisibility(0);
            ((ActivityVerifyPaymentResultBinding) this.b).e.setVisibility(0);
            ((ActivityVerifyPaymentResultBinding) this.b).f.setVisibility(0);
            ((ActivityVerifyPaymentResultBinding) this.b).f.setText(verifyPaymentResp.getSubTitle());
            ((ActivityVerifyPaymentResultBinding) this.b).d.setText(verifyPaymentResp.getAmount());
            ((ActivityVerifyPaymentResultBinding) this.b).e.setText(verifyPaymentResp.getCurrency());
            List<VerifyPaymentResp.DisplayItemBean> displayItems = verifyPaymentResp.getDisplayItems();
            if (a.i(displayItems)) {
                ((ActivityVerifyPaymentResultBinding) this.b).c.setVisibility(8);
            } else {
                ((ActivityVerifyPaymentResultBinding) this.b).c.setVisibility(0);
                BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_common_success, displayItems);
                ((ActivityVerifyPaymentResultBinding) this.b).c.setLayoutManager(new LinearLayoutManager(this));
                ((ActivityVerifyPaymentResultBinding) this.b).c.setAdapter(baseQuickAdapter);
            }
        } else {
            ((ActivityVerifyPaymentResultBinding) this.b).a.setBackgroundResource(R$mipmap.qr_code_icon_result_fail);
            ((ActivityVerifyPaymentResultBinding) this.b).g.setTextColor(ContextCompat.getColor(this, R$color.colorError));
            ((ActivityVerifyPaymentResultBinding) this.b).c.setVisibility(8);
            ((ActivityVerifyPaymentResultBinding) this.b).d.setVisibility(8);
            ((ActivityVerifyPaymentResultBinding) this.b).e.setVisibility(8);
            ((ActivityVerifyPaymentResultBinding) this.b).f.setVisibility(8);
        }
        ((ActivityVerifyPaymentResultBinding) this.b).g.setText(verifyPaymentResp.getTitle());
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [androidx.lifecycle.LifecycleOwner, com.huawei.qrcode.verify.VerifyPaymentResultActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        String stringExtra = getIntent().getStringExtra("tranID");
        if (!TextUtils.isEmpty(stringExtra)) {
            ((VerifyPaymentViewModel) this.c).a(stringExtra);
        }
        VerifyPaymentResp verifyPaymentResp = (VerifyPaymentResp) getIntent().getSerializableExtra("verifyPaymentResp");
        if (verifyPaymentResp != null) {
            E0(verifyPaymentResp);
        }
        ((ActivityVerifyPaymentResultBinding) this.b).b.setOnClickListener(new h(this, 7));
        ((VerifyPaymentViewModel) this.c).a.observe(this, new g(this, 2));
    }
}
