package com.huawei.qrcode.verify;

import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class VerifyPaymentResp extends BaseResp {
    private String amount;
    private String currency;
    private List<DisplayItemBean> displayItems;
    private String mmState;
    private String state;
    private String subTitle;
    private String title;

    public static class DisplayItemBean implements Serializable {
        private String key;
        private String label;
        private String value;

        public String getKey() {
            return this.key;
        }

        public String getLabel() {
            return this.label;
        }

        public String getValue() {
            return this.value;
        }

        public void setKey(String str) {
            this.key = str;
        }

        public void setLabel(String str) {
            this.label = str;
        }

        public void setValue(String str) {
            this.value = str;
        }
    }

    public String getAmount() {
        return this.amount;
    }

    public String getCurrency() {
        return this.currency;
    }

    public List<DisplayItemBean> getDisplayItems() {
        return this.displayItems;
    }

    public String getMmState() {
        return this.mmState;
    }

    public String getState() {
        return this.state;
    }

    public String getSubTitle() {
        return this.subTitle;
    }

    public String getTitle() {
        return this.title;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setDisplayItems(List<DisplayItemBean> list) {
        this.displayItems = list;
    }

    public void setMmState(String str) {
        this.mmState = str;
    }

    public void setState(String str) {
        this.state = str;
    }

    public void setSubTitle(String str) {
        this.subTitle = str;
    }

    public void setTitle(String str) {
        this.title = str;
    }
}
