package com.huawei.qrcode.verify;

import com.huawei.http.b;

public class VerifyPaymentRepository extends b<VerifyPaymentResp, VerifyPaymentResp> {
    public final String getApiPath() {
        return "v1/ethiopia/verifyTransaction";
    }
}
