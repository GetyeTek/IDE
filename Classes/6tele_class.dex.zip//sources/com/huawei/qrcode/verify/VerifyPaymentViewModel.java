package com.huawei.qrcode.verify;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.http.b;

public class VerifyPaymentViewModel extends ViewModel {
    public final MutableLiveData<c<VerifyPaymentResp>> a = new MutableLiveData<>();
    public VerifyPaymentRepository b;

    public class a implements R1.a<VerifyPaymentResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            VerifyPaymentViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            VerifyPaymentViewModel.this.a.setValue(c.e((VerifyPaymentResp) obj));
        }
    }

    public final void a(String str) {
        this.a.setValue(c.c());
        if (this.b == null) {
            b bVar = new b();
            bVar.addParams("receiptNumber", str);
            this.b = bVar;
        }
        this.b.sendRequest(new a());
    }

    public final void onCleared() {
        VerifyPaymentViewModel.super.onCleared();
        VerifyPaymentRepository verifyPaymentRepository = this.b;
        if (verifyPaymentRepository != null) {
            verifyPaymentRepository.cancel();
        }
    }
}
