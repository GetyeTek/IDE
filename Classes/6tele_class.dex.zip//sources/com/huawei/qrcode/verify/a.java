package com.huawei.qrcode.verify;

import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.qrcode.R$id;
import com.huawei.qrcode.verify.VerifyPaymentResp;

public final class a extends BaseQuickAdapter<VerifyPaymentResp.DisplayItemBean, BaseViewHolder> {
    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        VerifyPaymentResp.DisplayItemBean displayItemBean = (VerifyPaymentResp.DisplayItemBean) obj;
        baseViewHolder.setText(R$id.tv_label, displayItemBean.getLabel()).setText(R$id.tv_value, displayItemBean.getValue());
    }
}
