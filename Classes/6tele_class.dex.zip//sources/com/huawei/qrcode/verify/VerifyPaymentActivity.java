package com.huawei.qrcode.verify;

import N0.E;
import N0.F;
import V7.e;
import Y4.u;
import android.os.Bundle;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.qrcode.R$layout;
import com.huawei.qrcode.R$string;
import com.huawei.qrcode.databinding.ActivityVerifyPaymentBinding;
import s8.a;

@Route(path = "/qrCodeModule/verifyPayment")
public class VerifyPaymentActivity extends DataBindingActivity<ActivityVerifyPaymentBinding, VerifyPaymentViewModel> {
    public static final /* synthetic */ int d = 0;

    public final int C0() {
        return R$layout.activity_verify_payment;
    }

    /* JADX WARNING: type inference failed for: r0v6, types: [s8.a, android.text.TextWatcher] */
    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        e.a(this, getString(R$string.verify_payment), com.huawei.payment.mvvm.R$layout.common_toolbar);
        this.b.b.setError((String) null);
        this.b.a.setOnClickListener(new E(this, 5));
        this.b.b.getEditText().setInputType(1);
        this.b.b.getIvIcon().setOnClickListener(new F(this, 14));
        this.b.a.setEnabled(false);
        this.b.b.getEditText().addTextChangedListener(new a(this));
        this.c.a.observe(this, new u(this, 2));
    }
}
