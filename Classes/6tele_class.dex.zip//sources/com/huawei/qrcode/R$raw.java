package com.huawei.qrcode;

public final class R$raw {
    public static final int area_am = 2131951616;
    public static final int area_en = 2131951617;
    public static final int area_om = 2131951618;
    public static final int area_so = 2131951619;
    public static final int area_ti = 2131951620;
    public static final int digital_keyboard_config = 2131951622;
    public static final int keep = 2131951625;
    public static final int new_area_am = 2131951627;
    public static final int new_area_en = 2131951628;
    public static final int new_area_om = 2131951629;
    public static final int new_area_so = 2131951630;
    public static final int new_area_ti = 2131951631;
    public static final int places_keep = 2131951632;

    private R$raw() {
    }
}
