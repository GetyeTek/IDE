package com.huawei.qrcode.scan.model;

import java.io.Serializable;

public enum TradeTypeEnum implements Serializable {
    CUSTOMER_BUY_GOODS("CustomerBuyGoods", "customerBuyGoods"),
    P2P_TRANSFER("P2PTransfer", "p2pTransfer"),
    CASH_OUT("CashOut", "cashOut"),
    WITHDRAW_TO_BANK_CARD("WithdrawToBankCard", "withdrawToBankCard"),
    DEPOSIT_FROM_BANK_CARD("DepositFromBankCard", "depositFromBankCard");
    
    private String checkoutParam;
    private String transferParam;

    private TradeTypeEnum(String str, String str2) {
        this.checkoutParam = str;
        this.transferParam = str2;
    }

    public String getCheckoutParam() {
        return this.checkoutParam;
    }

    public String getTransferParam() {
        return this.transferParam;
    }
}
