package com.huawei.qrcode.scan;

import D6.a;
import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.astp.macle.ui.w;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.qrcode.R$id;
import com.huawei.qrcode.R$layout;

public class QrCodeTipsDialog extends BaseDialog {
    public TextView c;
    public TextView d;
    public TextView e;

    public final void onStart() {
        Window window;
        QrCodeTipsDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setLayout((BaseDialog.w0(window) * 8) / 10, -2);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        QrCodeTipsDialog.super.onViewCreated(view, bundle);
        this.c = (TextView) view.findViewById(R$id.tv_left_button);
        this.d = (TextView) view.findViewById(R$id.tv_right_button);
        this.e = (TextView) view.findViewById(R$id.tv_tips_content);
        this.c.setOnClickListener(new w(this, 3));
        this.d.setOnClickListener(new a(this, 6));
        if (!TextUtils.isEmpty((CharSequence) null)) {
            this.e.setText((CharSequence) null);
        }
        if (!TextUtils.isEmpty((CharSequence) null)) {
            this.c.setVisibility(0);
            this.c.setText((CharSequence) null);
        }
        if (!TextUtils.isEmpty((CharSequence) null)) {
            this.d.setText((CharSequence) null);
        }
    }

    public final int v0() {
        return R$layout.dialog_common_tips;
    }
}
