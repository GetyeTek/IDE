package com.huawei.qrcode.scan.fragment;

import B7.f;
import V1.h;
import V1.k;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Vibrator;
import android.text.TextUtils;
import android.view.View;
import androidx.camera.camera2.internal.P;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import c6.n;
import cn.bingoogolapple.qrcode.core.CameraPreview;
import cn.bingoogolapple.qrcode.core.QRCodeView;
import cn.bingoogolapple.qrcode.core.ScanBoxView;
import cn.bingoogolapple.qrcode.zxing.ZXingView;
import com.google.gson.Gson;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpFragment;
import com.huawei.digitalpayment.customer.httplib.request.ScanQrRequest;
import com.huawei.digitalpayment.customer.httplib.response.ScanQrResp;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;
import com.huawei.qrcode.R$mipmap;
import com.huawei.qrcode.R$string;
import com.huawei.qrcode.databinding.FragmentScanBinding;
import com.huawei.qrcode.scan.view.ScanNormalDataSelectDialog;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import o0.b;
import q8.c;

public class ScanFragment extends BaseMvpFragment<c> implements QRCodeView.b, r8.a {
    public FragmentScanBinding d;
    public boolean e;
    public PayLoadingDialog f;
    public final String g = "false";
    public final String h = "firstKey";
    public final String i = "yes";
    public boolean j = false;
    public final String k = "http";
    public final String l = "businessType";
    public final String m = "macleId";
    public final String n = "relativePath";
    public ScanNormalDataSelectDialog o;
    public final String p = "shortCode";
    public final String q = "prePayId";
    public final String r = "params";
    public final String s = "operatorId";
    public final String t = "amount";
    public final String u = "operationNumber";
    public final String v = "publicName";
    public String w = "";
    public String x = "";
    public String y = "Scan";
    public String z;

    public final class a extends AsyncTask<Void, Void, String> {
        public final PayLoadingDialog a;
        public final Bitmap b;

        public a(Bitmap bitmap, ScanFragment scanFragment) {
            this.b = bitmap;
            WeakReference weakReference = new WeakReference(scanFragment);
            PayLoadingDialog payLoadingDialog = new PayLoadingDialog();
            this.a = payLoadingDialog;
            payLoadingDialog.setCancelable(true);
            payLoadingDialog.show(((Fragment) weakReference.get()).getActivity().getSupportFragmentManager(), "");
        }

        public final Object doInBackground(Object[] objArr) {
            Void[] voidArr = (Void[]) objArr;
            return k.a.a(this.b);
        }

        public final void onPostExecute(Object obj) {
            this.a.dismiss();
            ScanFragment scanFragment = ScanFragment.this;
            scanFragment.j = true;
            scanFragment.B0((String) obj);
        }
    }

    public final void A0() {
        FragmentScanBinding fragmentScanBinding = this.d;
        if (fragmentScanBinding != null) {
            fragmentScanBinding.e.setVisibility(0);
            this.d.e.f();
            ZXingView zXingView = this.d.e;
            zXingView.e = true;
            zXingView.f();
            if (zXingView.e && zXingView.b.c()) {
                try {
                    zXingView.a.setOneShotPreviewCallback(zXingView);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            ScanBoxView scanBoxView = zXingView.c;
            if (scanBoxView != null) {
                scanBoxView.setVisibility(0);
            }
        }
    }

    public final void B0(String str) {
        Set<String> queryParameterNames;
        Set<String> queryParameterNames2;
        if (!TextUtils.isEmpty(str)) {
            if (W2.a.a(1200, this.d.e)) {
                A0();
                return;
            }
            z0();
            this.d.e.i();
            ((Vibrator) getActivity().getSystemService("vibrator")).vibrate(200);
            FragmentActivity activity = getActivity();
            A2.a aVar = B2.a.a;
            while (aVar != null) {
                if (!aVar.a(activity, str)) {
                    aVar = aVar.a;
                } else {
                    return;
                }
            }
            if (str.startsWith("coupon")) {
                b.d(getActivity(), str, (Bundle) null, (Map) null);
            } else if (str.startsWith("macle")) {
                b.d(getActivity(), str, (Bundle) null, (Map) null);
            } else if (str.startsWith(this.k)) {
                Uri parse = Uri.parse(str.replace("#", ""));
                if (!(parse == null || (queryParameterNames2 = parse.getQueryParameterNames()) == null || queryParameterNames2.size() <= 0)) {
                    String str2 = this.l;
                    if (queryParameterNames2.contains(str2) && "h5Pay".equals(parse.getQueryParameter(str2))) {
                        HashMap hashMap = new HashMap();
                        for (String next : queryParameterNames2) {
                            hashMap.put(next, parse.getQueryParameter(next));
                        }
                        b.d(getActivity(), "native://app/consumer/webCheckout", (Bundle) null, hashMap);
                        return;
                    }
                }
                Uri parse2 = Uri.parse(str.replace("#", ""));
                if (!(parse2 == null || (queryParameterNames = parse2.getQueryParameterNames()) == null || queryParameterNames.size() <= 0)) {
                    String str3 = this.m;
                    if (queryParameterNames.contains(str3)) {
                        b.d(getActivity(), P.a("macle://", parse2.getQueryParameter(str3), parse2.getQueryParameter(this.n)), (Bundle) null, (Map) null);
                        return;
                    }
                }
                b.d((Activity) null, str, (Bundle) null, (Map) null);
            } else {
                this.z = str;
                c cVar = this.c;
                String str4 = this.y;
                cVar.getClass();
                cVar.a(H3.c.e().j(new ScanQrRequest(str, str4)), new q8.a(cVar, (P2.a) cVar.a));
            }
        }
    }

    public final void G(String str) {
    }

    public final void V(String str) {
        PayLoadingDialog payLoadingDialog = new PayLoadingDialog();
        this.f = payLoadingDialog;
        payLoadingDialog.show(getActivity().getSupportFragmentManager(), "payLoading");
    }

    public final void b(VerifyNumberResp verifyNumberResp) {
        PayLoadingDialog payLoadingDialog = this.f;
        if (payLoadingDialog != null) {
            payLoadingDialog.dismiss();
        }
        if (verifyNumberResp != null && verifyNumberResp.getResponseCode().equals("SYS00000")) {
            HashMap hashMap = new HashMap();
            hashMap.put(this.p, verifyNumberResp.getShortCode());
            hashMap.put(this.v, verifyNumberResp.getPublicName());
            hashMap.put(this.t, this.x);
            hashMap.put(this.s, this.w);
            hashMap.put(this.u, this.z);
            b.d(getActivity(), "/cashModule/inputmoney", (Bundle) null, hashMap);
        }
    }

    public final void l(String str) {
        PayLoadingDialog payLoadingDialog = this.f;
        if (payLoadingDialog != null) {
            payLoadingDialog.dismiss();
        }
        if (TextUtils.isEmpty(str)) {
            k.a(R$string.qrcode_Invalid_qr_code_please_check_and_try_again);
        } else {
            k.b(1, str);
        }
        this.j = false;
        A0();
    }

    public final void onActivityResult(int i2, int i3, Intent intent) {
        Bitmap bitmap;
        ScanFragment.super.onActivityResult(i2, i3, intent);
        if (i3 == -1 && i2 == 2) {
            System.currentTimeMillis();
            if (intent != null) {
                try {
                    bitmap = BitmapFactory.decodeStream(requireActivity().getContentResolver().openInputStream(intent.getData()));
                } catch (Exception e2) {
                    e2.getMessage();
                    h.b();
                    bitmap = null;
                }
                new a(bitmap, this).execute(new Void[0]);
            }
        }
    }

    public final void onDestroy() {
        ScanFragment.super.onDestroy();
        ZXingView zXingView = this.d.e;
        zXingView.h();
        zXingView.d = null;
        ObjectAnimator objectAnimator = (ObjectAnimator) this.d.d.getTag();
        if (objectAnimator != null && objectAnimator.isRunning()) {
            objectAnimator.cancel();
        }
        getActivity();
        BaseException baseException = new BaseException("cancel");
        for (A2.a aVar = B2.a.a; aVar != null; aVar = aVar.a) {
            aVar.c(baseException);
        }
    }

    public final void onResume() {
        ScanFragment.super.onResume();
        A0();
    }

    public final void onStop() {
        ScanFragment.super.onStop();
        this.d.e.h();
        ObjectAnimator objectAnimator = (ObjectAnimator) this.d.d.getTag();
        if (objectAnimator != null && objectAnimator.isRunning()) {
            objectAnimator.cancel();
        }
    }

    public final void setUserVisibleHint(boolean z2) {
        ScanFragment.super.setUserVisibleHint(z2);
        if (z2) {
            A0();
            return;
        }
        z0();
        FragmentScanBinding fragmentScanBinding = this.d;
        if (fragmentScanBinding != null) {
            fragmentScanBinding.e.h();
        }
    }

    public final void v(BaseResp baseResp) {
        if (!this.j) {
            k.b(1, baseResp.getResponseDesc());
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0041, code lost:
        r0 = com.huawei.qrcode.R$id.zxingview;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding v0(android.view.LayoutInflater r9) {
        /*
            r8 = this;
            android.view.LayoutInflater r9 = r8.getLayoutInflater()
            int r0 = com.huawei.qrcode.R$layout.fragment_scan
            r1 = 0
            r2 = 0
            android.view.View r9 = r9.inflate(r0, r2, r1)
            int r0 = com.huawei.qrcode.R$id.iv_album
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r0)
            r4 = r1
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            if (r4 == 0) goto L_0x0058
            int r0 = com.huawei.qrcode.R$id.iv_flashlight
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r0)
            r5 = r1
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            if (r5 == 0) goto L_0x0058
            int r0 = com.huawei.qrcode.R$id.iv_scan_line
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r0)
            r6 = r1
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x0058
            int r0 = com.huawei.qrcode.R$id.tv_album
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r0)
            android.widget.TextView r1 = (android.widget.TextView) r1
            if (r1 == 0) goto L_0x0058
            int r0 = com.huawei.qrcode.R$id.tv_flashlight
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r0)
            android.widget.TextView r1 = (android.widget.TextView) r1
            if (r1 == 0) goto L_0x0058
            int r0 = com.huawei.qrcode.R$id.zxingview
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r0)
            r7 = r1
            cn.bingoogolapple.qrcode.zxing.ZXingView r7 = (cn.bingoogolapple.qrcode.zxing.ZXingView) r7
            if (r7 == 0) goto L_0x0058
            com.huawei.qrcode.databinding.FragmentScanBinding r0 = new com.huawei.qrcode.databinding.FragmentScanBinding
            r3 = r9
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r2 = r0
            r2.<init>(r3, r4, r5, r6, r7)
            r8.d = r0
            return r0
        L_0x0058:
            android.content.res.Resources r9 = r9.getResources()
            java.lang.String r9 = r9.getResourceName(r0)
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Missing required view with ID: "
            java.lang.String r9 = r1.concat(r9)
            r0.<init>(r9)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.qrcode.scan.fragment.ScanFragment.v0(android.view.LayoutInflater):androidx.viewbinding.ViewBinding");
    }

    public final void w(ScanQrResp scanQrResp) {
        if (scanQrResp != null) {
            FragmentActivity activity = getActivity();
            String str = this.z;
            scanQrResp.getExecute();
            String json = new Gson().toJson(scanQrResp);
            A2.a aVar = B2.a.a;
            while (aVar != null) {
                if (!aVar.b(activity, str, json)) {
                    aVar = aVar.a;
                } else {
                    return;
                }
            }
            scanQrResp.addParams(this.z);
            if ("native://app/consumer/cashOutAmount".equals(scanQrResp.getExecute())) {
                this.w = (String) scanQrResp.getParams().get(this.s);
                this.x = (String) scanQrResp.getParams().get(this.t);
                c cVar = this.c;
                String str2 = this.w;
                cVar.getClass();
                HashMap hashMap = new HashMap();
                hashMap.put("receiverShortCode", (String) scanQrResp.getParams().get(this.p));
                hashMap.put("operatorId", str2);
                cVar.a(H3.c.e().x(hashMap), new q8.b(cVar, (P2.a) cVar.a));
                return;
            }
            PayLoadingDialog payLoadingDialog = this.f;
            if (payLoadingDialog != null) {
                payLoadingDialog.dismiss();
            }
            boolean equals = "native://app/consumer/cNet".equals(scanQrResp.getExecute());
            String str3 = this.r;
            if (equals) {
                Bundle bundle = new Bundle();
                bundle.putString(str3, new Gson().toJson(scanQrResp));
                b.d(getActivity(), "native://app/consumer/cNet", bundle, (Map) null);
            } else if ("native://app/consumer/requestMoneyConfirm".equals(scanQrResp.getExecute())) {
                HashMap hashMap2 = new HashMap();
                hashMap2.put(str3, com.blankj.utilcode.util.k.d(scanQrResp));
                b.d(requireActivity(), scanQrResp.getExecute(), (Bundle) null, hashMap2);
            } else {
                Map params = scanQrResp.getParams();
                String str4 = this.q;
                if (!params.containsKey(str4) || TextUtils.isEmpty((CharSequence) params.get(str4))) {
                    b.d(getActivity(), scanQrResp.getExecute(), (Bundle) null, params);
                } else {
                    b.d(getActivity(), "/checkoutModule/yijieH5PayComfirm", (Bundle) null, params);
                }
            }
        } else {
            PayLoadingDialog payLoadingDialog2 = this.f;
            if (payLoadingDialog2 != null) {
                payLoadingDialog2.dismiss();
            }
            ZXingView zXingView = this.d.e;
            zXingView.e = true;
            zXingView.f();
            if (zXingView.e && zXingView.b.c()) {
                try {
                    zXingView.a.setOneShotPreviewCallback(zXingView);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    public final void w0() {
    }

    public final void x0(View view) {
        ScanFragment.super.x0(view);
        this.d.e.setDelegate(this);
        this.d.c.setOnClickListener(new B7.c(this, 8));
        this.d.b.setOnClickListener(new n(this, 5));
        if (TextUtils.isEmpty(this.g)) {
            FragmentActivity activity = getActivity();
            BaseDialog baseDialog = new BaseDialog();
            new LinearLayoutManager(activity);
            this.o = baseDialog;
            baseDialog.show(getActivity().getSupportFragmentManager(), "");
            this.o.c = new f(this);
        } else {
            this.d.e.f();
            ZXingView zXingView = this.d.e;
            zXingView.e = true;
            zXingView.f();
            if (zXingView.e && zXingView.b.c()) {
                try {
                    zXingView.a.setOneShotPreviewCallback(zXingView);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            ScanBoxView scanBoxView = zXingView.c;
            if (scanBoxView != null) {
                scanBoxView.setVisibility(0);
            }
        }
        String stringExtra = requireActivity().getIntent().getStringExtra("scanPurpose");
        if (!TextUtils.isEmpty(stringExtra)) {
            this.y = stringExtra;
        }
    }

    public final A8.c y0() {
        return new A8.c(this);
    }

    public final void z0() {
        boolean z2;
        FragmentScanBinding fragmentScanBinding = this.d;
        if (fragmentScanBinding != null) {
            CameraPreview cameraPreview = fragmentScanBinding.e.b;
            if (!cameraPreview.c() || !cameraPreview.getContext().getPackageManager().hasSystemFeature("android.hardware.camera.flash")) {
                z2 = false;
            } else {
                z2 = true;
            }
            if (z2) {
                j.b bVar = cameraPreview.f;
                Camera camera = cameraPreview.a;
                bVar.getClass();
                j.b.a(false, camera);
            }
            this.e = false;
            this.d.c.setImageResource(R$mipmap.icon_flashlight);
        }
    }
}
