package com.huawei.qrcode.scan;

import H6.i;
import android.os.Build;
import android.widget.FrameLayout;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.FragmentStatePagerAdapter;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.qrcode.R$string;
import com.huawei.qrcode.databinding.ActivityScanAndPayBinding;
import com.huawei.qrcode.scan.adapter.FmPagerAdapter;
import com.huawei.qrcode.scan.fragment.ScanFragment;
import com.huawei.qrcode.scan.fragment.ScanGuideFragment;
import java.util.ArrayList;

@Route(extras = 1, path = "/qrCodeModule/scan")
public class ScanAndPayActivity extends BaseTitleActivity implements ScanGuideFragment.a {
    public static final /* synthetic */ int l = 0;
    public ActivityScanAndPayBinding i;
    public ArrayList j;
    public FmPagerAdapter k;

    public final void D0() {
    }

    public final void F() {
        U0();
        this.k.notifyDataSetChanged();
        V0();
    }

    /* JADX WARNING: type inference failed for: r1v7, types: [java.lang.Object, androidx.core.view.OnApplyWindowInsetsListener] */
    public final void G0() {
        ScanAndPayActivity.super.G0();
        setContentView(this.i.a);
        f.g(getWindow());
        U0();
        V0();
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.i.b.getLayoutParams();
        layoutParams.topMargin = f.c();
        this.i.b.setLayoutParams(layoutParams);
        this.i.b.setOnClickListener(new i(this, 7));
        FrameLayout frameLayout = this.i.a;
        if (Build.VERSION.SDK_INT >= 35 && frameLayout != null && !frameLayout.getFitsSystemWindows()) {
            frameLayout.setFitsSystemWindows(false);
            ViewCompat.setOnApplyWindowInsetsListener(frameLayout, new Object());
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.qrcode.scan.ScanAndPayActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.qrcode.R$id.view_pager;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r5 = this;
            android.view.LayoutInflater r0 = r5.getLayoutInflater()
            int r1 = com.huawei.qrcode.R$layout.activity_scan_and_pay
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r2, r3)
            int r1 = com.huawei.qrcode.R$id.iv_back
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageButton r3 = (android.widget.ImageButton) r3
            if (r3 == 0) goto L_0x002a
            int r1 = com.huawei.qrcode.R$id.view_pager
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.viewpager.widget.ViewPager r4 = (androidx.viewpager.widget.ViewPager) r4
            if (r4 == 0) goto L_0x002a
            com.huawei.qrcode.databinding.ActivityScanAndPayBinding r1 = new com.huawei.qrcode.databinding.ActivityScanAndPayBinding
            android.widget.FrameLayout r0 = (android.widget.FrameLayout) r0
            r1.<init>(r0, r3, r4)
            r5.i = r1
            return r2
        L_0x002a:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.qrcode.scan.ScanAndPayActivity.K0():androidx.viewbinding.ViewBinding");
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [p8.a, java.lang.Object] */
    public final void U0() {
        ArrayList arrayList = new ArrayList(1);
        this.j = arrayList;
        String string = getResources().getString(R$string.designstandard_scan);
        ? obj = new Object();
        obj.a = string;
        obj.b = ScanFragment.class;
        arrayList.add(obj);
    }

    public final void V0() {
        ArrayList arrayList = this.j;
        FragmentStatePagerAdapter fragmentStatePagerAdapter = new FragmentStatePagerAdapter(getSupportFragmentManager());
        fragmentStatePagerAdapter.a = arrayList;
        this.k = fragmentStatePagerAdapter;
        this.i.c.setOffscreenPageLimit(fragmentStatePagerAdapter.getCount());
        this.i.c.setAdapter(this.k);
    }
}
