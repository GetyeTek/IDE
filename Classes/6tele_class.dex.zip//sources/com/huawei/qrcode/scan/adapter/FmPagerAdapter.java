package com.huawei.qrcode.scan.adapter;

import V1.h;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import java.util.ArrayList;
import p8.a;

public class FmPagerAdapter extends FragmentStatePagerAdapter {
    public ArrayList a;

    public FmPagerAdapter() {
        throw null;
    }

    public final int getCount() {
        ArrayList arrayList = this.a;
        if (arrayList == null || arrayList.isEmpty()) {
            return 0;
        }
        return arrayList.size();
    }

    public final Fragment getItem(int i) {
        try {
            return (Fragment) ((a) this.a.get(i)).b.newInstance();
        } catch (InstantiationException e) {
            e.toString();
            h.b();
            return null;
        } catch (IllegalAccessException e2) {
            e2.toString();
            h.b();
            return null;
        }
    }

    public final int getItemPosition(Object obj) {
        return -2;
    }

    @Nullable
    public final CharSequence getPageTitle(int i) {
        return ((a) this.a.get(i)).a;
    }
}
