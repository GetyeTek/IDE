package com.huawei.qrcode.scan.fragment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import b4.i;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.qrcode.R$id;
import com.huawei.qrcode.R$layout;
import com.huawei.qrcode.databinding.FragmentScanGuideBinding;

public class ScanGuideFragment extends BaseFragment {
    public FragmentScanGuideBinding c;
    public a d;

    public interface a {
        void F();
    }

    public final void onAttach(@NonNull Context context) {
        ScanGuideFragment.super.onAttach(context);
        if (context instanceof a) {
            this.d = (a) context;
        }
    }

    public final ViewBinding v0(LayoutInflater layoutInflater) {
        View inflate = getLayoutInflater().inflate(R$layout.fragment_scan_guide, (ViewGroup) null, false);
        int i = R$id.checkbox;
        AppCompatCheckBox findChildViewById = ViewBindings.findChildViewById(inflate, i);
        if (findChildViewById != null) {
            i = R$id.ll_scan;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(inflate, i);
            if (linearLayout != null) {
                FragmentScanGuideBinding fragmentScanGuideBinding = new FragmentScanGuideBinding((LinearLayout) inflate, findChildViewById, linearLayout);
                this.c = fragmentScanGuideBinding;
                return fragmentScanGuideBinding;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final void w0() {
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, android.widget.CompoundButton$OnCheckedChangeListener] */
    public final void x0(View view) {
        this.c.c.setOnClickListener(new i(this, 6));
        this.c.b.setOnCheckedChangeListener(new Object());
    }
}
