package com.huawei.qrcode.scan.view;

import B7.f;
import H1.c;
import W2.n;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import com.blankj.utilcode.util.A;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.qrcode.R$id;
import com.huawei.qrcode.R$layout;
import com.huawei.qrcode.R$style;
import com.huawei.qrcode.scan.fragment.ScanFragment;

public class ScanNormalDataSelectDialog extends BaseDialog {
    public f c;

    public class a implements View.OnClickListener {

        /* renamed from: com.huawei.qrcode.scan.view.ScanNormalDataSelectDialog$a$a  reason: collision with other inner class name */
        public class C0000a implements Runnable {
            public C0000a() {
            }

            public final void run() {
                ScanNormalDataSelectDialog scanNormalDataSelectDialog = ScanNormalDataSelectDialog.this;
                scanNormalDataSelectDialog.getDialog().dismiss();
                f fVar = scanNormalDataSelectDialog.c;
                fVar.getClass();
                n b = n.b("");
                ScanFragment scanFragment = (ScanFragment) fVar.a;
                b.g(scanFragment.h, scanFragment.i, false);
                scanFragment.A0();
            }
        }

        public a() {
        }

        public final void onClick(View view) {
            A.h(new C0000a(), 300);
        }
    }

    public final void onStart() {
        Window window;
        ScanNormalDataSelectDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            window.setBackgroundDrawableResource(17170445);
            c.b(window, R$style.BottomAnimation, dialog, false, true);
        }
    }

    public final void onViewCreated(View view, Bundle bundle) {
        ScanNormalDataSelectDialog.super.onViewCreated(view, bundle);
        ((Button) view.findViewById(R$id.btn_confirm)).setOnClickListener(new a());
    }

    public final int v0() {
        return R$layout.layout_sacn_select_dialog;
    }
}
