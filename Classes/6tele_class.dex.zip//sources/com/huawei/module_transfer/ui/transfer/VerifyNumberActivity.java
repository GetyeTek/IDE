package com.huawei.module_transfer.ui.transfer;

import M7.b;
import M7.c;
import V1.k;
import W2.g;
import W2.n;
import android.text.TextUtils;
import android.view.View;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;
import com.huawei.kbz.chat.chat_room.view_holder.h;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import com.huawei.module_transfer.R$string;
import com.huawei.module_transfer.databinding.ActivityTransferByNumberBinding;
import com.huawei.module_transfer.ui.transfer.bean.CustomerType;
import com.huawei.module_transfer.ui.transfer.bean.PayTradeTypeEnum;
import java.util.HashMap;
import n.a;

public class VerifyNumberActivity extends BaseMvpActivity<b> implements c {
    public static final /* synthetic */ int l = 0;
    public ActivityTransferByNumberBinding j;
    public String k;

    public final void D0() {
    }

    public final void G(String str) {
        this.j.c.a();
    }

    public final void G0() {
        VerifyNumberActivity.super.G0();
        O0(R$string.designstandard_transfer);
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.module_transfer.ui.transfer.VerifyNumberActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.module_transfer.R$id.lb_start;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r5 = this;
            android.view.LayoutInflater r0 = r5.getLayoutInflater()
            int r1 = com.huawei.module_transfer.R$layout.activity_transfer_by_number
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_transfer.R$id.et_phone_num
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.EditText r2 = (android.widget.EditText) r2
            if (r2 == 0) goto L_0x0034
            int r1 = com.huawei.module_transfer.R$id.lb_start
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r3 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r3
            if (r3 == 0) goto L_0x0034
            int r1 = com.huawei.module_transfer.R$id.tv_phone_num
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r4 = (android.widget.TextView) r4
            if (r4 == 0) goto L_0x0034
            com.huawei.module_transfer.databinding.ActivityTransferByNumberBinding r1 = new com.huawei.module_transfer.databinding.ActivityTransferByNumberBinding
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1.<init>(r0, r2, r3)
            r5.j = r1
            return r1
        L_0x0034:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_transfer.ui.transfer.VerifyNumberActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        this.j.c.b();
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_transfer.ui.transfer.VerifyNumberActivity] */
    public final void V0(VerifyNumberResp verifyNumberResp) {
        a.b().getClass();
        a.a("/checkoutModule/transferAmount").withString("msisdn", verifyNumberResp.getMsisdn()).withString("publicName", verifyNumberResp.getPublicName()).withString("tradeType", PayTradeTypeEnum.NATIVE_APP.getTradeType()).withString("customerType", verifyNumberResp.getCustomerType()).navigation(this);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.module_transfer.ui.transfer.VerifyNumberActivity] */
    public void onViewClick(View view) {
        this.k = this.j.b.getText().toString();
        if (n.b("").e("recent_login_phone_number").equals(this.k)) {
            k.b(1, getString(R$string.designstandard_sorry_you_cannot_send_money_to_your));
        } else if (TextUtils.isEmpty(this.k)) {
            k.b(1, getString(R$string.designstandard_please_input_phone_number));
        } else if (!g.c(this.k)) {
            k.b(1, getString(R$string.transfer_incorrect_phone_number_format));
        } else {
            b bVar = this.i;
            String str = this.k;
            bVar.getClass();
            HashMap hashMap = new HashMap();
            hashMap.put("receiverMsisdn", str);
            bVar.a(H3.c.e().t0(TradeTypeEnum.P2P_TRANSFER.getCheckoutParam(), hashMap), new M7.a(bVar, (P2.a) bVar.a));
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, com.huawei.module_transfer.ui.transfer.VerifyNumberActivity, java.lang.Object, androidx.fragment.app.FragmentActivity] */
    public final void x(VerifyNumberResp verifyNumberResp) {
        if (verifyNumberResp != null) {
            if (CustomerType.REGISTERED.getName().equals(verifyNumberResp.getCustomerType())) {
                V0(verifyNumberResp);
                return;
            }
            String string = getString(R$string.transfer_this_phone_number_havent_registered_yet_do_you);
            String string2 = getString(R$string.designstandard_no_give_up);
            String string3 = getString(R$string.designstandard_yes_still_transfer);
            h hVar = new h(this, verifyNumberResp, 1);
            BaseDialog baseDialog = new BaseDialog();
            baseDialog.g = null;
            baseDialog.h = string;
            baseDialog.i = string2;
            baseDialog.j = string3;
            baseDialog.k = null;
            baseDialog.l = hVar;
            baseDialog.show(getSupportFragmentManager(), "tipsDialog");
        }
    }
}
