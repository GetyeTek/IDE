package com.huawei.module_transfer.ui.transfer.bean;

public enum CustomerType {
    REGISTERED("Register", "01"),
    UN_REGISTERED("Unregister", "02");
    
    private String code;
    private String name;

    private CustomerType(String str, String str2) {
        this.name = str;
        this.code = str2;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
