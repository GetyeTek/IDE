package com.huawei.module_transfer.ui.transfer.bean;

public enum PayTradeTypeEnum {
    NATIVE_APP("NativeApp"),
    QR_CODE("QrCode"),
    BANK_TRADE("BankTrade");
    
    private String tradeType;

    private PayTradeTypeEnum(String str) {
        this.tradeType = str;
    }

    public String getTradeType() {
        return this.tradeType;
    }
}
