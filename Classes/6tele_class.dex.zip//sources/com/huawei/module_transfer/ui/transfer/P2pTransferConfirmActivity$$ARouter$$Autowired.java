package com.huawei.module_transfer.ui.transfer;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class P2pTransferConfirmActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_transfer.ui.transfer.P2pTransferConfirmActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (P2pTransferConfirmActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.msisdn;
        } else {
            str = r4.getIntent().getExtras().getString("msisdn", r4.msisdn);
        }
        r4.msisdn = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.publicName;
        } else {
            str2 = r4.getIntent().getExtras().getString("publicName", r4.publicName);
        }
        r4.publicName = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.amount;
        } else {
            str3 = r4.getIntent().getExtras().getString("amount", r4.amount);
        }
        r4.amount = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.notes;
        } else {
            str4 = r4.getIntent().getExtras().getString("notes", r4.notes);
        }
        r4.notes = str4;
        if (r4.getIntent().getExtras() == null) {
            str5 = r4.tradeType;
        } else {
            str5 = r4.getIntent().getExtras().getString("tradeType", r4.tradeType);
        }
        r4.tradeType = str5;
        if (r4.getIntent().getExtras() == null) {
            str6 = r4.customerType;
        } else {
            str6 = r4.getIntent().getExtras().getString("customerType", r4.customerType);
        }
        r4.customerType = str6;
    }
}
