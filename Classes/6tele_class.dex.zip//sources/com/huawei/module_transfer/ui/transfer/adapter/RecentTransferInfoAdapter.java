package com.huawei.module_transfer.ui.transfer.adapter;

import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.pic.GlideApp;
import com.huawei.digitalpayment.customer.httplib.response.RecentTransfersResp;
import com.huawei.image.glide.Base64Mode;
import com.huawei.module_transfer.R$id;
import com.huawei.module_transfer.R$mipmap;

public class RecentTransferInfoAdapter extends BaseQuickAdapter<RecentTransfersResp.RecentTransferInfo, BaseViewHolder> {
    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        RecentTransfersResp.RecentTransferInfo recentTransferInfo = (RecentTransfersResp.RecentTransferInfo) obj;
        baseViewHolder.setText(R$id.tv_name, recentTransferInfo.getName());
        baseViewHolder.setText(R$id.tv_phone_display, recentTransferInfo.getMsisdnDisplay());
        ImageView imageView = (ImageView) baseViewHolder.getView(R$id.iv_head);
        GlideApp.with(imageView).load(Base64Mode.getConsumerMode(recentTransferInfo.getAvatar())).optionalCircleCrop().placeholder(R$mipmap.icon_drawer_head).into(imageView);
    }
}
