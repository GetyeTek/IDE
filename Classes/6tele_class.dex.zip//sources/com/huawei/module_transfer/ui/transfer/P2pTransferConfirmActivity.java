package com.huawei.module_transfer.ui.transfer;

import A8.c;
import N7.a;
import V1.k;
import W2.g;
import W2.n;
import android.text.TextUtils;
import android.view.View;
import androidx.camera.camera2.internal.D1;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import com.huawei.module_transfer.R$string;
import com.huawei.module_transfer.databinding.ActivityTransferConfirmBinding;
import com.huawei.module_transfer.ui.transfer.bean.CustomerType;
import h7.d;
import java.util.HashMap;

@Route(path = "/transferModule/transferAmount")
public class P2pTransferConfirmActivity extends BaseMvpActivity<d> {
    @Autowired(name = "amount")
    String amount;
    @Autowired(name = "customerType")
    String customerType;
    public ActivityTransferConfirmBinding j;
    public PayLoadingDialog k;
    @Autowired(name = "msisdn")
    String msisdn;
    @Autowired(name = "notes")
    String notes;
    @Autowired(name = "publicName")
    String publicName;
    @Autowired(name = "tradeType")
    String tradeType;

    public final void D0() {
    }

    public final void G(String str) {
        this.k.dismiss();
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, java.lang.Object, com.huawei.module_transfer.ui.transfer.P2pTransferConfirmActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        P2pTransferConfirmActivity.super.G0();
        N0(getString(R$string.designstandard_transfer));
        this.k = new PayLoadingDialog();
        if (CustomerType.REGISTERED.getName().equals(this.customerType)) {
            this.j.e.setText(a.k(this.msisdn));
            this.j.d.setText(this.publicName);
        } else {
            this.j.e.setText(getString(R$string.transfer_phone_number));
            this.j.d.setText(a.k(this.msisdn));
        }
        if (!TextUtils.isEmpty(this.notes)) {
            this.j.b.setText(this.notes);
            this.j.b.setEnabled(false);
        }
        if (!TextUtils.isEmpty(this.amount)) {
            this.j.c.setText(this.amount);
            this.j.c.setEnabled(false);
        }
        this.j.c.postDelayed(new D1(this, 2), 250);
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.module_transfer.ui.transfer.P2pTransferConfirmActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0021, code lost:
        r1 = com.huawei.module_transfer.R$id.et_amount;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r9 = this;
            android.view.LayoutInflater r0 = r9.getLayoutInflater()
            int r1 = com.huawei.module_transfer.R$layout.activity_transfer_confirm
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_transfer.R$id.card_view
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.cardview.widget.CardView r2 = (androidx.cardview.widget.CardView) r2
            if (r2 == 0) goto L_0x006a
            int r1 = com.huawei.module_transfer.R$id.et_add_notes
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            android.widget.EditText r5 = (android.widget.EditText) r5
            if (r5 == 0) goto L_0x006a
            int r1 = com.huawei.module_transfer.R$id.et_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r6 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r6
            if (r6 == 0) goto L_0x006a
            int r1 = com.huawei.module_transfer.R$id.line
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x006a
            int r1 = com.huawei.module_transfer.R$id.ll_info
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            if (r2 == 0) goto L_0x006a
            int r1 = com.huawei.module_transfer.R$id.tv_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x006a
            int r1 = com.huawei.module_transfer.R$id.tv_org_name
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            if (r7 == 0) goto L_0x006a
            int r1 = com.huawei.module_transfer.R$id.tv_transfer_to
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x006a
            com.huawei.module_transfer.databinding.ActivityTransferConfirmBinding r1 = new com.huawei.module_transfer.databinding.ActivityTransferConfirmBinding
            r4 = r0
            android.widget.LinearLayout r4 = (android.widget.LinearLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8)
            r9.j = r1
            return r1
        L_0x006a:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_transfer.ui.transfer.P2pTransferConfirmActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
        this.k.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.module_transfer.ui.transfer.P2pTransferConfirmActivity, androidx.appcompat.app.AppCompatActivity] */
    public void onViewClick(View view) {
        String obj = this.j.c.getEditableText().toString();
        this.amount = obj;
        if (TextUtils.isEmpty(obj)) {
            k.b(1, getString(R$string.designstandard_please_input_amount));
        } else if (!g.a(this.amount)) {
            k.b(1, getString(R$string.designstandard_incorrect_amount_format));
        } else {
            this.j.b.getText().toString().getClass();
            HashMap hashMap = new HashMap();
            hashMap.put("amount", this.amount);
            hashMap.put("note", this.notes);
            hashMap.put("tradeType", this.tradeType);
            hashMap.put("receiverMsisdn", this.msisdn);
            if (n.b("").e("recent_login_phone_number").equals(this.msisdn)) {
                k.b(1, getString(R$string.designstandard_sorry_you_cannot_send_money_to_your));
            } else {
                this.i.b(this, TradeTypeEnum.P2P_TRANSFER, hashMap);
            }
        }
    }
}
