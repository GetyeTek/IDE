package com.huawei.module_transfer.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public final class ActivityTransferConfirmBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final EditText b;
    @NonNull
    public final InputItemEditText c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public ActivityTransferConfirmBinding(@NonNull LinearLayout linearLayout, @NonNull EditText editText, @NonNull InputItemEditText inputItemEditText, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = linearLayout;
        this.b = editText;
        this.c = inputItemEditText;
        this.d = textView;
        this.e = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
