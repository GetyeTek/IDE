package W7;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import com.huawei.push.adapter.AppNotificationAdapter;
import java.util.Map;
import o0.b;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ AppNotificationAdapter a;
    public final /* synthetic */ NotificationMessageBean b;
    public final /* synthetic */ BaseViewHolder c;

    public /* synthetic */ a(AppNotificationAdapter appNotificationAdapter, NotificationMessageBean notificationMessageBean, BaseViewHolder baseViewHolder) {
        this.a = appNotificationAdapter;
        this.b = notificationMessageBean;
        this.c = baseViewHolder;
    }

    public final void onClick(View view) {
        int i = AppNotificationAdapter.a;
        AppNotificationAdapter appNotificationAdapter = this.a;
        NotificationMessageBean notificationMessageBean = this.b;
        if (!TextUtils.isEmpty(notificationMessageBean.getCardExecute())) {
            b.d((Activity) null, notificationMessageBean.getCardExecute(), (Bundle) null, (Map) null);
        }
        if (appNotificationAdapter.getOnItemClickListener() != null) {
            OnItemClickListener onItemClickListener = appNotificationAdapter.getOnItemClickListener();
            BaseViewHolder baseViewHolder = this.c;
            onItemClickListener.onItemClick(appNotificationAdapter, baseViewHolder.itemView, baseViewHolder.getAdapterPosition());
        }
    }
}
