package W7;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.bean.NotificationMessageBean;
import com.huawei.push.adapter.TransNotificationAdapter;
import java.util.Map;

public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ TransNotificationAdapter a;
    public final /* synthetic */ NotificationMessageBean b;
    public final /* synthetic */ BaseViewHolder c;

    public /* synthetic */ b(TransNotificationAdapter transNotificationAdapter, NotificationMessageBean notificationMessageBean, BaseViewHolder baseViewHolder) {
        this.a = transNotificationAdapter;
        this.b = notificationMessageBean;
        this.c = baseViewHolder;
    }

    public final void onClick(View view) {
        int i = TransNotificationAdapter.a;
        TransNotificationAdapter transNotificationAdapter = this.a;
        NotificationMessageBean notificationMessageBean = this.b;
        if (!TextUtils.isEmpty(notificationMessageBean.getCardExecute())) {
            o0.b.d((Activity) null, notificationMessageBean.getCardExecute(), (Bundle) null, (Map) null);
        }
        if (transNotificationAdapter.getOnItemClickListener() != null) {
            OnItemClickListener onItemClickListener = transNotificationAdapter.getOnItemClickListener();
            BaseViewHolder baseViewHolder = this.c;
            onItemClickListener.onItemClick(transNotificationAdapter, baseViewHolder.itemView, baseViewHolder.getAdapterPosition());
        }
    }
}
