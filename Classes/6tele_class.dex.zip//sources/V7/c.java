package V7;

import androidx.annotation.NonNull;
import com.huawei.common.exception.BaseException;
import com.huawei.payment.mvvm.Status;

public final class c<T> {
    public Status a;
    public BaseException b;
    public T c;

    public c() {
        throw null;
    }

    public c(Status status, T t) {
        this.a = status;
        this.c = t;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [V7.c, java.lang.Object] */
    public static c a(BaseException baseException) {
        Status status = Status.ERROR;
        ? obj = new Object();
        obj.a = status;
        obj.c = null;
        obj.b = baseException;
        return obj;
    }

    public static c c() {
        return new c(Status.LOADING, (Object) null);
    }

    public static <T> c<T> e(T t) {
        return new c<>(Status.SUCCESS, t);
    }

    public final boolean b() {
        if (this.a == Status.ERROR) {
            return true;
        }
        return false;
    }

    public final boolean d() {
        if (this.a == Status.LOADING) {
            return true;
        }
        return false;
    }

    public final boolean f() {
        if (this.a == Status.SUCCESS) {
            return true;
        }
        return false;
    }

    @NonNull
    public final String toString() {
        return "Resource{status=" + this.a + ", exception=" + this.b + ", data=" + this.c + '}';
    }
}
