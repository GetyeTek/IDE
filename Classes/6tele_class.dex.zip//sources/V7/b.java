package V7;

import android.view.View;
import com.huawei.payment.mvvm.DataBindingAdapter;
import java.util.List;

public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ DataBindingAdapter a;
    public final /* synthetic */ int b;

    public /* synthetic */ b(DataBindingAdapter dataBindingAdapter, int i) {
        this.a = dataBindingAdapter;
        this.b = i;
    }

    public final void onClick(View view) {
        T t;
        DataBindingAdapter dataBindingAdapter = this.a;
        DataBindingAdapter.a<T> aVar = dataBindingAdapter.a;
        if (aVar != null) {
            List<T> list = dataBindingAdapter.b;
            int i = this.b;
            if (list == null) {
                t = null;
            } else {
                t = list.get(i);
            }
            aVar.c(view, i, t);
        }
    }
}
