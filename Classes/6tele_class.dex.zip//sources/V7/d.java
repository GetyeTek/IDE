package V7;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public final /* synthetic */ class d implements Runnable {
    public final /* synthetic */ ViewGroup a;
    public final /* synthetic */ View b;
    public final /* synthetic */ int c;

    public /* synthetic */ d(int i, View view, ViewGroup viewGroup) {
        this.a = viewGroup;
        this.b = view;
        this.c = i;
    }

    public final void run() {
        int i = 0;
        while (true) {
            ViewGroup viewGroup = this.a;
            if (i < viewGroup.getChildCount()) {
                View childAt = viewGroup.getChildAt(i);
                if (!"tag_toolbar".equals(childAt.getTag()) && !"TAG_STATUS_BAR".equals(childAt.getTag())) {
                    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                    layoutParams.topMargin = this.b.getHeight() + this.c + layoutParams.topMargin;
                    childAt.setLayoutParams(layoutParams);
                    i++;
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }
}
