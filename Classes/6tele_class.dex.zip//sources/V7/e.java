package V7;

import D4.m;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.f;
import com.huawei.payment.mvvm.R$id;

public final class e {
    public static void a(FragmentActivity fragmentActivity, String str, @LayoutRes int i) {
        int i2;
        ViewGroup viewGroup = (ViewGroup) fragmentActivity.findViewById(16908290);
        View findViewWithTag = viewGroup.findViewWithTag("TAG_STATUS_BAR");
        if (findViewWithTag != null) {
            i2 = f.c();
        } else {
            i2 = 0;
        }
        View findViewWithTag2 = viewGroup.findViewWithTag("tag_toolbar");
        if (findViewWithTag2 == null) {
            findViewWithTag2 = LayoutInflater.from(fragmentActivity).inflate(i, viewGroup, false);
            findViewWithTag2.setTag("tag_toolbar");
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) findViewWithTag2.getLayoutParams();
            marginLayoutParams.topMargin += i2;
            findViewWithTag2.setLayoutParams(marginLayoutParams);
            findViewWithTag2.findViewById(R$id.ivBack).setOnClickListener(new m(fragmentActivity, 1));
            if (findViewWithTag != null) {
                findViewWithTag2.setBackground(findViewWithTag.getBackground());
            }
            viewGroup.addView(findViewWithTag2);
            findViewWithTag2.post(new d(i2, findViewWithTag2, viewGroup));
        }
        ((TextView) findViewWithTag2.findViewById(R$id.tvTitle)).setText(str);
    }
}
