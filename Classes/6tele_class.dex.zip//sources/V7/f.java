package V7;

import V1.k;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.huawei.common.widget.dialog.DialogManager;

public final class f {
    public static <T> void a(Fragment fragment, c<T> cVar) {
        if (cVar.d()) {
            DialogManager.d(fragment.getChildFragmentManager(), true);
        } else {
            DialogManager.b(fragment.getChildFragmentManager());
        }
    }

    public static <T> void b(FragmentActivity fragmentActivity, c<T> cVar) {
        if (cVar.d()) {
            DialogManager.d(fragmentActivity.getSupportFragmentManager(), true);
        } else {
            DialogManager.a(fragmentActivity);
        }
    }

    public static <T> void c(c<T> cVar) {
        if (cVar.b()) {
            k.b(1, cVar.b.getMessage());
        }
    }
}
