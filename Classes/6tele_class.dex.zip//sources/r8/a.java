package r8;

import com.huawei.digitalpayment.customer.httplib.response.ScanQrResp;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;

public interface a extends P2.a {
    void b(VerifyNumberResp verifyNumberResp);

    void l(String str);

    void w(ScanQrResp scanQrResp);
}
