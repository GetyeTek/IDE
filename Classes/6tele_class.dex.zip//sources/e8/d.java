package e8;

import E0.c;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import com.huawei.pwamodule.payment.PwaDispatcherActivity;
import fa.z;
import j8.a;
import java.util.HashMap;
import o0.b;

public final class d implements b {
    public PwaDispatcherActivity a;
    public String b;
    public String c;
    public String d;

    /* JADX WARNING: type inference failed for: r5v2, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    public final void a(z zVar) {
        String str = this.c;
        String str2 = this.b;
        if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2)) {
            Intent intent = new Intent(this.d);
            intent.addCategory("android.intent.category.DEFAULT");
            intent.setFlags(268435456);
            intent.setComponent(new ComponentName(str2, str));
            intent.putExtra("msg", "success");
            intent.putExtra("code", "0");
            intent.putExtra("data", zVar.b);
            this.a.startActivity(intent);
        }
    }

    /* JADX WARNING: type inference failed for: r1v7, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    /* JADX WARNING: type inference failed for: r5v3, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    public final void b(Uri uri) {
        if ("mandate".equalsIgnoreCase(uri.getHost())) {
            HashMap<String, String> b2 = a.b(uri);
            this.b = b2.get("packageName");
            this.c = b2.get("activity");
            this.d = b2.get("action");
            b2.remove("packageName");
            b2.remove("activity");
            b2.remove("action");
            if (c.g()) {
                String a2 = a.a(b2);
                if (!TextUtils.isEmpty(b2.get("thirdAppId"))) {
                    b2.put("appId", b2.get("thirdAppId"));
                    b.d(this.a, a2, (Bundle) null, b2);
                    this.a.finish();
                    return;
                }
                throw new RuntimeException("appId is empty");
            }
        }
    }

    public final String c() {
        return "mandate";
    }

    public final void d(PwaDispatcherActivity pwaDispatcherActivity) {
        this.a = pwaDispatcherActivity;
    }
}
