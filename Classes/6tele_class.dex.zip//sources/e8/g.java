package e8;

import W2.c;
import android.net.Uri;
import android.os.Bundle;
import com.huawei.pwamodule.payment.PwaDispatcherActivity;
import fa.z;
import j8.a;
import java.util.HashMap;
import java.util.Map;
import o0.b;

public final class g implements b {
    public PwaDispatcherActivity a;

    /* JADX WARNING: type inference failed for: r0v4, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    public final void b(Uri uri) {
        if ("openMacle".equalsIgnoreCase(uri.getHost())) {
            Uri parse = Uri.parse(uri.toString().replace("#", ""));
            HashMap<String, String> b = a.b(parse);
            String path = parse.getPath();
            if (path.startsWith("/")) {
                path = path.substring(1);
            }
            b.d(this.a, c.b(path, b), (Bundle) null, (Map) null);
        }
    }

    public final String c() {
        return "openMacle";
    }

    public final void d(PwaDispatcherActivity pwaDispatcherActivity) {
        this.a = pwaDispatcherActivity;
    }

    public final void a(z zVar) {
    }
}
