package e8;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import com.huawei.pwamodule.payment.PwaDispatcherActivity;
import fa.z;
import j8.a;
import o0.b;

public final class c implements b {
    public final void b(Uri uri) {
        if ("h5checkout".equalsIgnoreCase(uri.getHost())) {
            b.d((Activity) null, "/checkoutModule/h5CrossAppPayEnter", (Bundle) null, a.b(uri));
        }
    }

    public final String c() {
        return "h5checkout";
    }

    public final void a(z zVar) {
    }

    public final void d(PwaDispatcherActivity pwaDispatcherActivity) {
    }
}
