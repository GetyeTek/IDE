package e8;

import E0.c;
import android.net.Uri;
import android.os.Bundle;
import com.huawei.pwamodule.payment.PwaDispatcherActivity;
import fa.z;
import j8.a;
import java.util.HashMap;
import o0.b;

public final class e implements b {
    public PwaDispatcherActivity a;

    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    /* JADX WARNING: type inference failed for: r4v2, types: [com.huawei.pwamodule.payment.PwaDispatcherActivity, android.app.Activity] */
    public final void b(Uri uri) {
        if ("mandateAndPay".equalsIgnoreCase(uri.getHost())) {
            HashMap<String, String> b = a.b(uri);
            if (c.g()) {
                b.d(this.a, a.a(b), (Bundle) null, b);
                this.a.finish();
            }
        }
    }

    public final String c() {
        return "mandateAndPay";
    }

    public final void d(PwaDispatcherActivity pwaDispatcherActivity) {
        this.a = pwaDispatcherActivity;
    }

    public final void a(z zVar) {
    }
}
