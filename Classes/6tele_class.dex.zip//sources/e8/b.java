package e8;

import android.net.Uri;
import com.huawei.pwamodule.payment.PwaDispatcherActivity;
import fa.z;

public interface b {
    void a(z zVar);

    void b(Uri uri);

    String c();

    void d(PwaDispatcherActivity pwaDispatcherActivity);
}
