package e8;

import android.net.Uri;
import java.util.ArrayList;
import java.util.Iterator;

public final class a {
    public final ArrayList a = new ArrayList();

    /* renamed from: e8.a$a  reason: collision with other inner class name */
    public static class C0001a {
        public static final a a = new a();
    }

    public final void a(Uri uri) {
        String host = uri.getHost();
        Iterator it = this.a.iterator();
        while (it.hasNext()) {
            b bVar = (b) it.next();
            if (bVar.c().equalsIgnoreCase(host)) {
                bVar.b(uri);
            }
        }
    }
}
