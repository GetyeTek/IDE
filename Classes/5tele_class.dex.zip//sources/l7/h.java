package l7;

import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.checkstand.fragment.PayPinFragment;

public final class h implements Observer<CheckoutResp> {
    public final /* synthetic */ PayPinFragment a;

    public h(PayPinFragment payPinFragment) {
        this.a = payPinFragment;
    }

    public final void onChanged(Object obj) {
        CheckoutResp checkoutResp = (CheckoutResp) obj;
        PayPinFragment payPinFragment = this.a;
        payPinFragment.c.d.setText(checkoutResp.getActualAmountDisplay());
        payPinFragment.c.e.setText(checkoutResp.getUnit());
    }
}
