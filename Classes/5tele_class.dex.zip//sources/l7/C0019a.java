package l7;

import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;

/* renamed from: l7.a  reason: case insensitive filesystem */
public final /* synthetic */ class C0019a implements Observer {
    public final /* synthetic */ CheckStandFragment a;

    public /* synthetic */ C0019a(CheckStandFragment checkStandFragment) {
        this.a = checkStandFragment;
    }

    public final void onChanged(Object obj) {
        this.a.F0((CheckoutResp) obj);
    }
}
