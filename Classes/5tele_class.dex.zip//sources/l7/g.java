package l7;

import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.checkstand.fragment.PayMethodFragment;

public final class g implements Observer<CheckoutResp> {
    public final /* synthetic */ PayMethodFragment a;

    public g(PayMethodFragment payMethodFragment) {
        this.a = payMethodFragment;
    }

    public final void onChanged(Object obj) {
        CheckoutResp checkoutResp = (CheckoutResp) obj;
        PayMethodFragment payMethodFragment = this.a;
        if (payMethodFragment.e) {
            payMethodFragment.e = false;
            payMethodFragment.a.k(payMethodFragment.d.a);
            payMethodFragment.requireActivity().onBackPressed();
        }
    }
}
