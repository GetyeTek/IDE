package l7;

import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.checkstand.fragment.DiscountTypeFragment;

public final /* synthetic */ class e implements Observer {
    public final /* synthetic */ DiscountTypeFragment a;

    public /* synthetic */ e(DiscountTypeFragment discountTypeFragment) {
        this.a = discountTypeFragment;
    }

    public final void onChanged(Object obj) {
        DiscountTypeFragment discountTypeFragment = this.a;
        discountTypeFragment.getClass();
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_in_app_discount_type_select, ((CheckoutResp) obj).getUserCoupons());
        baseQuickAdapter.a = (CouponBean) discountTypeFragment.a.l.getValue();
        discountTypeFragment.d = baseQuickAdapter;
        discountTypeFragment.c.d.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(discountTypeFragment.requireContext(), R$color.colorDividerDark), 1));
        discountTypeFragment.c.d.setAdapter(discountTypeFragment.d);
    }
}
