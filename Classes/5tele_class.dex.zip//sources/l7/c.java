package l7;

import V1.h;
import W2.j;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.fuel.activity.FuelPaymentQrCodeActivity;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;

public final /* synthetic */ class c implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                CheckoutResp checkoutResp = (CheckoutResp) obj;
                CheckStandFragment checkStandFragment = (CheckStandFragment) obj2;
                if (checkStandFragment.d) {
                    checkStandFragment.d = false;
                    checkStandFragment.a.k(checkStandFragment.g);
                    checkStandFragment.h.f(checkStandFragment.g);
                    checkStandFragment.g = null;
                }
                checkStandFragment.k = true;
                checkStandFragment.F0(checkoutResp);
                checkStandFragment.k = false;
                return;
            default:
                BaseResp baseResp = (BaseResp) obj;
                int i = FuelPaymentQrCodeActivity.r;
                FuelPaymentQrCodeActivity fuelPaymentQrCodeActivity = (FuelPaymentQrCodeActivity) obj2;
                fuelPaymentQrCodeActivity.k.getQrCode();
                h.b();
                fuelPaymentQrCodeActivity.j.c.setImageBitmap(j.c(fuelPaymentQrCodeActivity.j.c.getWidth(), fuelPaymentQrCodeActivity.j.c.getWidth(), fuelPaymentQrCodeActivity.k.getQrCode()));
                fuelPaymentQrCodeActivity.U0();
                return;
        }
    }
}
