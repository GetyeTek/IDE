package l7;

import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;

public final class d {
    public final /* synthetic */ CheckStandFragment a;

    public d(CheckStandFragment checkStandFragment) {
        this.a = checkStandFragment;
    }
}
