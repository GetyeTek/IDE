package l7;

import android.view.View;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;

public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ CheckStandFragment a;
    public final /* synthetic */ View b;

    public /* synthetic */ b(CheckStandFragment checkStandFragment, View view) {
        this.a = checkStandFragment;
        this.b = view;
    }

    public final void onClick(View view) {
        this.a.y0(this.b);
    }
}
