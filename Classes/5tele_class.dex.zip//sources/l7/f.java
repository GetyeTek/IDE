package l7;

import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.module_checkout.checkstand.fragment.DiscountTypeFragment;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;

public final /* synthetic */ class f implements Observer {
    public final /* synthetic */ DiscountTypeFragment a;

    public /* synthetic */ f(DiscountTypeFragment discountTypeFragment) {
        this.a = discountTypeFragment;
    }

    public final void onChanged(Object obj) {
        CheckoutResp checkoutResp = (CheckoutResp) obj;
        DiscountTypeFragment discountTypeFragment = this.a;
        if (discountTypeFragment.f) {
            discountTypeFragment.f = false;
            CheckStandViewModel checkStandViewModel = discountTypeFragment.a;
            CouponBean couponBean = discountTypeFragment.e;
            if (couponBean != null) {
                checkStandViewModel.l.setValue(couponBean);
            } else {
                checkStandViewModel.getClass();
            }
            discountTypeFragment.b.onBackPressed();
        }
    }
}
