package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.HomeFuncList;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class k extends a {
    public final String a() {
        return "functionConfigOld";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        HomeFuncList functionConfigOld = basicConfigResp.getJsonContent().getFunctionConfigOld();
        if (functionConfigOld != null) {
            BasicConfig.getInstance().setFunctionConfigOld(functionConfigOld);
        }
    }
}
