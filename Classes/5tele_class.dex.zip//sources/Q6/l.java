package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.MerchantAppIdBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class l extends a {
    public final String a() {
        return "merchantAppIdConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        MerchantAppIdBean merchantAppIdConfig = basicConfigResp.getJsonContent().getMerchantAppIdConfig();
        if (merchantAppIdConfig != null) {
            BasicConfig.getInstance().setMerchantAppIdConfig(merchantAppIdConfig);
        }
    }
}
