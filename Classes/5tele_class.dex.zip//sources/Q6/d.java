package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.AmountConfigBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class d extends a {
    public final String a() {
        return "cashInConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        AmountConfigBean cashInConfig = basicConfigResp.getJsonContent().getCashInConfig();
        if (cashInConfig != null) {
            BasicConfig.getInstance().setCashInConfig(cashInConfig);
        }
    }
}
