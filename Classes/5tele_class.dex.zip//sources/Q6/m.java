package Q6;

import W2.n;
import com.blankj.utilcode.util.k;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class m extends a {
    public final String a() {
        return "OpenPageConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        n.b("").g("open_page_img", k.d(basicConfigResp.getJsonContent().getOpenPageConfig()), false);
    }
}
