package Q6;

import V1.h;
import W2.n;
import android.text.TextUtils;
import com.blankj.utilcode.util.k;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;

public final class j extends a {
    public final String a() {
        return "financeMarketBankConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        FinanceMarketBankConfig financeMarketBankConfig = basicConfigResp.getJsonContent().getFinanceMarketBankConfig();
        String e = n.b("").e("finance_market_bank_config");
        if (!TextUtils.isEmpty(e)) {
            try {
                FinanceMarketBankConfig financeMarketBankConfig2 = (FinanceMarketBankConfig) k.a(e, FinanceMarketBankConfig.class);
                if (financeMarketBankConfig2 != null && TextUtils.equals(financeMarketBankConfig2.getVersion(), financeMarketBankConfig.getVersion())) {
                    return;
                }
            } catch (Exception e2) {
                e2.getMessage();
                h.b();
            }
        }
        n.b("").g("finance_market_bank_config", k.d(basicConfigResp.getJsonContent().getFinanceMarketBankConfig()), false);
    }
}
