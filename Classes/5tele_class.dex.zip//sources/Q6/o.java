package Q6;

import V1.h;
import W2.n;
import android.text.TextUtils;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.ParameterLimitBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class o extends a {
    public final String a() {
        return "parameterLimits";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        ParameterLimitBean parameterLimits = basicConfigResp.getJsonContent().getParameterLimits();
        if (parameterLimits != null) {
            BasicConfig.getInstance().setParameterLimit(parameterLimits);
            String notificationRefreshInterval = parameterLimits.getNotificationRefreshInterval();
            h.b();
            if (!TextUtils.isEmpty(notificationRefreshInterval)) {
                n.b("homev5_cache").g("HomeBalanceUpdateTimeInterval", notificationRefreshInterval, false);
                n.b("sp_name_push").g("UnReadCountUpdateTimeInterval", notificationRefreshInterval, false);
            }
            String sessionTimeoutSecond = parameterLimits.getSessionTimeoutSecond();
            h.b();
            if (!TextUtils.isEmpty(sessionTimeoutSecond)) {
                n.b("").g("sessionTimeoutSecond", sessionTimeoutSecond, false);
            }
        }
    }
}
