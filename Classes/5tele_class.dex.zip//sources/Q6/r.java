package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import java.util.List;

public final class r extends a {
    public final String a() {
        return "SettingsConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        List settingsConfig = basicConfigResp.getJsonContent().getSettingsConfig();
        if (settingsConfig != null) {
            BasicConfig.getInstance().setLoginPageSettingConfig(settingsConfig);
        }
    }
}
