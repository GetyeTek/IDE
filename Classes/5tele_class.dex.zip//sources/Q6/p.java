package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.digitalpayment.customer.httplib.response.PocketMoneyBizConfigResp;

public final class p extends a {
    public final String a() {
        return "PocketMoneyBizConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        PocketMoneyBizConfigResp pocketMoneyBizConfigResp = basicConfigResp.getJsonContent().getPocketMoneyBizConfigResp();
        if (pocketMoneyBizConfigResp != null) {
            BasicConfig.getInstance().savePocketMoneyBizConfig(pocketMoneyBizConfigResp);
        }
    }
}
