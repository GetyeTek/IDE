package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class n extends a {
    public final String a() {
        return "OpenUrlWhiteListConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        BasicConfig.getInstance().setOpenUrlWhiteList(basicConfigResp.getJsonContent().getOpenUrlWhiteList());
    }
}
