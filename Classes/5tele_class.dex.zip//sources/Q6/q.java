package Q6;

import R6.a;
import R6.b;
import V1.h;
import W2.f;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.s;
import com.huawei.digitalpayment.customer.bean.homeconfig.HomeSearch;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.ethiopia.component.service.AppService;

public final class q extends a {
    public final String a() {
        return "searchContentConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        if (b.a == null) {
            synchronized (b.class) {
                try {
                    if (b.a == null) {
                        b.a = new b();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        b bVar = b.a;
        bVar.getClass();
        String url = basicConfigResp.getJsonContent().getSearchContentConfig().getUrl();
        String version = basicConfigResp.getJsonContent().getSearchContentConfig().getVersion();
        HomeSearch homeSearch = (HomeSearch) f.a(s.a("").b("HOME_SEARCHCONFIG"), HomeSearch.class);
        if (homeSearch != null) {
            try {
                if (homeSearch.getVersion() != null) {
                    if (Double.parseDouble(homeSearch.getVersion()) >= Double.parseDouble(version)) {
                        return;
                    }
                }
            } catch (Exception e) {
                e.getMessage();
                h.b();
                return;
            }
        }
        A.d(new a(bVar, url, basicConfigResp));
        s a = s.a("");
        String g = o0.b.c(AppService.class).g();
        a.c(g + "_homesearchhistory", "");
    }
}
