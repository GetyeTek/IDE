package Q6;

import java.util.ArrayList;
import java.util.Iterator;

public final class b {
    public final ArrayList a = new ArrayList();

    public final void a(a aVar) {
        this.a.add(aVar);
    }

    public final ArrayList b() {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.a.iterator();
        while (it.hasNext()) {
            arrayList.add(((a) it.next()).a());
        }
        return arrayList;
    }
}
