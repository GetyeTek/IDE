package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class i extends a {
    public final String a() {
        return "enableBiometricPayTimes";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        BasicConfig.getInstance().saveEnableBiometricPayTimes(basicConfigResp.getJsonContent().getEnableBiometricPayTimes());
    }
}
