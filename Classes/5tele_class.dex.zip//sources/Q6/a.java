package Q6;

import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public abstract class a {
    public abstract String a();

    public abstract void b(BasicConfigResp basicConfigResp);
}
