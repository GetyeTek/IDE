package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.CreditPayConfigBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class g extends a {
    public final String a() {
        return "creditPayConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        CreditPayConfigBean creditPayConfig = basicConfigResp.getJsonContent().getCreditPayConfig();
        if (creditPayConfig != null) {
            BasicConfig.getInstance().setCreditPayConfig(creditPayConfig);
        }
    }
}
