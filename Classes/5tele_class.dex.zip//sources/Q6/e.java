package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.AmountConfigBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class e extends a {
    public final String a() {
        return "cashOutConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        AmountConfigBean cashOutConfig = basicConfigResp.getJsonContent().getCashOutConfig();
        if (cashOutConfig != null) {
            BasicConfig.getInstance().setCashOutConfig(cashOutConfig);
        }
    }
}
