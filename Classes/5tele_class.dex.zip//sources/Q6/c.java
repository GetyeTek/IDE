package Q6;

import W2.n;
import android.text.TextUtils;
import com.huawei.digitalpayment.customer.httplib.response.AppDownloadIntroductionBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class c extends a {
    public final String a() {
        return "AppDownloadIntroduction";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        AppDownloadIntroductionBean appDownloadIntroduction = basicConfigResp.getJsonContent().getAppDownloadIntroduction();
        if (appDownloadIntroduction != null) {
            String appDownloadIntroductionURL = appDownloadIntroduction.getAppDownloadIntroductionURL();
            if (!TextUtils.isEmpty(appDownloadIntroductionURL)) {
                n.b("").g("AppDownloadIntroduction", appDownloadIntroductionURL, false);
            }
        }
    }
}
