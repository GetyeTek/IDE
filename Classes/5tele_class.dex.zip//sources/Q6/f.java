package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.digitalpayment.customer.httplib.response.ChatBizConfigResp;

public final class f extends a {
    public final String a() {
        return "ChatBizConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        ChatBizConfigResp chatBizConfig = basicConfigResp.getJsonContent().getChatBizConfig();
        if (chatBizConfig != null) {
            BasicConfig.getInstance().saveChatBizConfig(chatBizConfig);
        }
    }
}
