package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class h extends a {
    public final String a() {
        return "easierDownloadConfig";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        BasicConfig.getInstance().setEasierDownloadConfigBean(basicConfigResp.getJsonContent().getEasierDownloadConfigBean());
    }
}
