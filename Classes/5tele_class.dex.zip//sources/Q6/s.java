package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class s extends a {
    public final String a() {
        return "shareAppMSG";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        String shareAppMSG = basicConfigResp.getJsonContent().getShareAppMSG();
        if (shareAppMSG != null) {
            BasicConfig.getInstance().setShareAppMSG(shareAppMSG);
        }
    }
}
