package Q6;

import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class t extends a {
    public final String a() {
        return "staticPageUrl";
    }

    public final void b(BasicConfigResp basicConfigResp) {
        BasicConfigResp.StaticPageUrl staticPageUrl = basicConfigResp.getJsonContent().getStaticPageUrl();
        if (staticPageUrl != null) {
            BasicConfig.getInstance().setStaticPageUrl(staticPageUrl);
        }
    }
}
