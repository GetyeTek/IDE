package O6;

public final class c extends A8.c {
}
