package O6;

import R1.a;
import V1.k;
import W2.h;
import com.blankj.utilcode.util.l;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.utils.exception.PhoneNumberException;
import com.huawei.kbz.chat.chat_room.ChatFragment;
import com.huawei.kbz.chat.contact.model.ContactFriendInfo;
import com.huawei.kbz.chat.contact.response.QueryChatUserInfoResponse;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.share.ShareAppMessageDialogFragment;
import java.util.List;

public final class f implements a {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ f(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    private final /* synthetic */ void a() {
    }

    private final /* synthetic */ void b() {
    }

    private final /* synthetic */ void c(Object obj) {
    }

    private final /* synthetic */ void d(Object obj) {
    }

    public /* synthetic */ void onComplete() {
        int i = this.a;
    }

    public void onError(BaseException baseException) {
        switch (this.a) {
            case 0:
                k.b(1, baseException.getResponseDesc());
                return;
            default:
                k.b(1, baseException.getMessage());
                return;
        }
    }

    public /* synthetic */ void onLoading(Object obj) {
        int i = this.a;
    }

    public void onSuccess(Object obj) {
        switch (this.a) {
            case 0:
                String str = (String) obj;
                ShareAppMessageDialogFragment shareAppMessageDialogFragment = (ShareAppMessageDialogFragment) this.b;
                try {
                    shareAppMessageDialogFragment.d.b.getEditText().setText(h.a(str, (Integer) null));
                    shareAppMessageDialogFragment.d.b.getEditText().setSelection(shareAppMessageDialogFragment.d.b.getEditText().getText().length());
                    l.d(shareAppMessageDialogFragment.d.b.getEditText());
                    return;
                } catch (PhoneNumberException unused) {
                    k.a(R$string.checkout_invalid_phone_number_please_check);
                    return;
                }
            default:
                QueryChatUserInfoResponse queryChatUserInfoResponse = (QueryChatUserInfoResponse) obj;
                if ("SYS00000".equals(queryChatUserInfoResponse.getResponseCode())) {
                    List<ContactFriendInfo> chatUserInfos = queryChatUserInfoResponse.getChatUserInfos();
                    ChatFragment chatFragment = (ChatFragment) this.b;
                    chatFragment.getClass();
                    for (ContactFriendInfo b2 : chatUserInfos) {
                        chatFragment.m.b(b2);
                    }
                    chatFragment.b.notifyDataSetChanged();
                    return;
                }
                k.b(1, queryChatUserInfoResponse.getResponseDesc());
                return;
        }
    }
}
