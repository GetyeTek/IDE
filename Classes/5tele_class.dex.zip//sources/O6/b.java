package O6;

import P2.a;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public final class b extends L2.b<BaseResp> {
    public final /* synthetic */ c f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public b(c cVar, a aVar) {
        super(aVar, true);
        this.f = cVar;
    }

    public final void c(Object obj) {
        BaseResp baseResp = (BaseResp) obj;
        ((a) this.f.a).X();
    }

    public final void b(String str) {
    }
}
