package O6;

public final /* synthetic */ class a {
}
