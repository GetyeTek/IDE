package O6;

import android.os.Message;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.camera.video.internal.encoder.EncoderImpl;
import com.blankj.utilcode.util.l;
import com.huawei.module_basic_ui.share.ShareAppMessageDialogFragment;
import com.huawei.module_checkout.startpay.activity.StartPayEnterActivity;
import h0.e;
import h0.f;
import y4.a;

public final /* synthetic */ class e implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ e(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void run() {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                ShareAppMessageDialogFragment shareAppMessageDialogFragment = (ShareAppMessageDialogFragment) obj;
                shareAppMessageDialogFragment.d.b.getEditText().performClick();
                shareAppMessageDialogFragment.d.b.getEditText().requestFocus();
                shareAppMessageDialogFragment.d.b.getEditText().setFocusableInTouchMode(true);
                l.d(shareAppMessageDialogFragment.d.b.getEditText());
                return;
            case 1:
                EncoderImpl.b((EncoderImpl) obj);
                return;
            case 2:
                int i = StartPayEnterActivity.q;
                ((StartPayEnterActivity) obj).finish();
                return;
            case 3:
                e.b bVar = ((f) obj).a;
                Message obtain = Message.obtain(bVar.f.b);
                obtain.what = 6;
                obtain.obj = 0;
                obtain.sendToTarget();
                Message obtain2 = Message.obtain(bVar.f.b);
                obtain2.what = 4;
                obtain2.sendToTarget();
                AppCompatImageView appCompatImageView = bVar.e;
                if (appCompatImageView.getAlpha() != 1.0f) {
                    appCompatImageView.setAlpha(1.0f);
                    return;
                }
                return;
            default:
                a.a.a.a.b((String) obj);
                return;
        }
    }
}
