package O6;

import P2.a;

public interface d extends a {
    void X();
}
