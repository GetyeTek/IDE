package B7;

import Ea.b;
import F0.h;
import V1.k;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import androidx.camera.core.imagecapture.u;
import androidx.lifecycle.LiveData;
import c6.r;
import cn.bingoogolapple.qrcode.zxing.ZXingView;
import com.huawei.bank.transfer.activity.TransferToWalletActivity;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.customer.httplib.response.RegisterVerifySmsResp;
import com.huawei.digitalpayment.customer.httplib.response.VehicleBean;
import com.huawei.digitalpayment.customer.login_module.databinding.ActivityUpgradeBinding;
import com.huawei.digitalpayment.customer.login_module.upgrade.UpGradeSubActivity;
import com.huawei.digitalpayment.customer.login_module.upgrade.UpgradeActivity;
import com.huawei.digitalpayment.fuel.activity.NewOrEditVehicleActivity;
import com.huawei.kbz.chat.R;
import com.huawei.kbz.chat.chat_room.ChatFragment;
import com.huawei.kbz.chat.contact.ChatPhotoProfileSetActivity;
import com.huawei.kbz.chat.contact.UserInfoActivity;
import com.huawei.kbz.chat.contact.model.ContactFriendInfo;
import com.huawei.kbz.chat.groupChat.GroupChatInfoActivity;
import com.huawei.module_checkout.checkstand.fragment.DiscountTypeFragment;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import com.huawei.module_checkout.requestpin.BaseRequestPinActivity;
import com.huawei.qrcode.scan.fragment.ScanFragment;
import com.shinemo.chat.CYConversation;
import h6.a;
import j.d;
import java.util.Map;

public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onClick(View view) {
        long j;
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = BaseRequestPinActivity.f;
                ((BaseRequestPinActivity) obj).K();
                return;
            case 1:
                int i2 = GroupChatInfoActivity.m;
                GroupChatInfoActivity groupChatInfoActivity = (GroupChatInfoActivity) obj;
                a b2 = a.b();
                String str = groupChatInfoActivity.e;
                b2.getClass();
                CYConversation a2 = a.a(str, "GroupChat");
                b.g(groupChatInfoActivity, String.format(groupChatInfoActivity.getString(R.string.clear_history_info), new Object[]{a2.getName()}), groupChatInfoActivity.getString(R.string.cancel), (n6.a) null, groupChatInfoActivity.getString(R.string.clear), new r(groupChatInfoActivity, a2));
                return;
            case 2:
                int i3 = TransferToWalletActivity.l;
                TransferToWalletActivity transferToWalletActivity = (TransferToWalletActivity) obj;
                String string = transferToWalletActivity.getString(com.huawei.bank.R.string.are_you_sure_you_want_to_clear_the_recent_transfer_history);
                String string2 = transferToWalletActivity.getString(com.huawei.bank.R.string.no);
                String string3 = transferToWalletActivity.getString(com.huawei.bank.R.string.yes);
                h hVar = new h(transferToWalletActivity, 3);
                BaseDialog baseDialog = new BaseDialog();
                baseDialog.g = null;
                baseDialog.h = string;
                baseDialog.i = string2;
                baseDialog.j = string3;
                baseDialog.k = null;
                baseDialog.l = hVar;
                baseDialog.show(transferToWalletActivity.getSupportFragmentManager(), "");
                return;
            case 3:
                int i4 = UpgradeActivity.L;
                UpgradeActivity upgradeActivity = (UpgradeActivity) obj;
                upgradeActivity.getClass();
                w5.a.a("Create_AddIDinfo_Next_V1");
                String text = upgradeActivity.j.i.getText();
                String text2 = upgradeActivity.j.A.getText();
                RegisterVerifySmsResp.FieldValidateConfigs fieldValidateConfigs = upgradeActivity.u;
                if (fieldValidateConfigs == null || fieldValidateConfigs.getIdTypeValue1() == null || (!TextUtils.isEmpty(text) && !text.equals(upgradeActivity.getString(com.huawei.digitalpayment.customer.login_module.R.string.login_please_choose)))) {
                    RegisterVerifySmsResp.FieldValidateConfigs fieldValidateConfigs2 = upgradeActivity.u;
                    if (fieldValidateConfigs2 != null && fieldValidateConfigs2.getIdNumber1() != null && !upgradeActivity.j.A.b()) {
                        k.a(com.huawei.digitalpayment.customer.login_module.R.string.login_please_enter_the_correct_id_number);
                        upgradeActivity.j.A.setError(upgradeActivity.u.getIdNumber().getDesc());
                        ActivityUpgradeBinding activityUpgradeBinding = upgradeActivity.j;
                        activityUpgradeBinding.s.post(new u(2, upgradeActivity, activityUpgradeBinding.g));
                        return;
                    } else if (!"17".equals(upgradeActivity.s) || !TextUtils.isEmpty(upgradeActivity.z)) {
                        RegisterVerifySmsResp.FieldValidateConfigs fieldValidateConfigs3 = upgradeActivity.u;
                        if (fieldValidateConfigs3 != null && fieldValidateConfigs3.getIdFrontPhoto() != null && TextUtils.isEmpty(upgradeActivity.n) && !"17".equals(upgradeActivity.s)) {
                            k.a(com.huawei.digitalpayment.customer.login_module.R.string.designstandard_please_upload_the_front_id_picture);
                            return;
                        } else if (!upgradeActivity.x || !TextUtils.isEmpty(upgradeActivity.o) || "17".equals(upgradeActivity.s)) {
                            RegisterVerifySmsResp.FieldValidateConfigs fieldValidateConfigs4 = upgradeActivity.u;
                            if (fieldValidateConfigs4 == null || fieldValidateConfigs4.getPersonalPhoto() == null || !TextUtils.isEmpty(upgradeActivity.p)) {
                                Intent intent = new Intent(upgradeActivity, UpGradeSubActivity.class);
                                intent.putExtra("idType", upgradeActivity.s);
                                intent.putExtra("idNumber", text2);
                                intent.putExtra("hasBackPic", upgradeActivity.x);
                                upgradeActivity.startActivity(intent);
                                w5.a.a("Upgrade_Sub_Activity_created");
                                return;
                            }
                            k.a(com.huawei.digitalpayment.customer.login_module.R.string.login_please_upload_the_personal_picture);
                            return;
                        } else {
                            k.a(com.huawei.digitalpayment.customer.login_module.R.string.designstandard_please_upload_the_back_id_picture);
                            return;
                        }
                    } else {
                        k.a(com.huawei.digitalpayment.customer.login_module.R.string.login_please_verify_national_id);
                        return;
                    }
                } else {
                    k.a(com.huawei.digitalpayment.customer.login_module.R.string.login_please_select_your_idtype);
                    upgradeActivity.j.i.setError(upgradeActivity.u.getIdTypeValue().getDesc());
                    ActivityUpgradeBinding activityUpgradeBinding2 = upgradeActivity.j;
                    activityUpgradeBinding2.s.post(new u(2, upgradeActivity, activityUpgradeBinding2.e));
                    return;
                }
            case 4:
                ChatFragment chatFragment = (ChatFragment) obj;
                a b3 = a.b();
                String str2 = chatFragment.g;
                String str3 = chatFragment.h;
                b3.getClass();
                CYConversation a3 = a.a(str2, str3);
                if (a3.isBlack()) {
                    chatFragment.T0(chatFragment.getString(R.string.sending_to_blocked_user_is_not_allowed), a3);
                    return;
                }
                ContactFriendInfo a4 = chatFragment.m.a(chatFragment.A0());
                String msisdn = a4.getMsisdn();
                if (TextUtils.isEmpty(msisdn)) {
                    chatFragment.C0("Pay Bill");
                    chatFragment.w.a(a4.getOpenId());
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putString("entrance", "chat");
                bundle.putString("msisdn", msisdn);
                o0.b.d(chatFragment.requireActivity(), "/topUpModule/PayBill", bundle, (Map) null);
                return;
            case 5:
                int i5 = ChatPhotoProfileSetActivity.e;
                ((ChatPhotoProfileSetActivity) obj).finish();
                return;
            case 6:
                int i6 = UserInfoActivity.i;
                UserInfoActivity userInfoActivity = (UserInfoActivity) obj;
                userInfoActivity.getClass();
                Bundle bundle2 = new Bundle();
                bundle2.putString("openId", userInfoActivity.c);
                o0.b.d(userInfoActivity, "/chat/edit_note_name", bundle2, (Map) null);
                return;
            case 7:
                DiscountTypeFragment discountTypeFragment = (DiscountTypeFragment) obj;
                Object value = discountTypeFragment.a.l.getValue();
                CouponBean couponBean = discountTypeFragment.d.a;
                if (value == couponBean) {
                    discountTypeFragment.b.onBackPressed();
                    return;
                }
                discountTypeFragment.f = true;
                discountTypeFragment.e = couponBean;
                CheckStandViewModel checkStandViewModel = discountTypeFragment.a;
                LiveData<S2.b<CheckoutResp>> f = checkStandViewModel.f(couponBean);
                if (f != null) {
                    checkStandViewModel.b(f, new m7.b(checkStandViewModel, couponBean));
                    return;
                }
                return;
            case 8:
                ScanFragment scanFragment = (ScanFragment) obj;
                if (!scanFragment.e) {
                    ZXingView zXingView = scanFragment.d.e;
                    d dVar = new d(zXingView);
                    if (zXingView.b.c()) {
                        j = 0;
                    } else {
                        j = 500;
                    }
                    zXingView.postDelayed(dVar, j);
                    scanFragment.e = true;
                    scanFragment.d.c.setImageResource(com.huawei.qrcode.R.mipmap.icon_flashlight2);
                    return;
                }
                scanFragment.z0();
                return;
            default:
                NewOrEditVehicleActivity newOrEditVehicleActivity = (NewOrEditVehicleActivity) obj;
                if (newOrEditVehicleActivity.b.b.isEnabled()) {
                    VehicleBean vehicleBean = new VehicleBean();
                    vehicleBean.setFuelType(newOrEditVehicleActivity.b.d.getText());
                    vehicleBean.setPlateNumber(newOrEditVehicleActivity.b.c.c());
                    Bundle bundle3 = new Bundle(1);
                    bundle3.putSerializable("vehicleBean", vehicleBean);
                    o0.b.d(newOrEditVehicleActivity, "/topUpModule/fuelPaymentVehicleAmount", bundle3, (Map) null);
                    return;
                }
                return;
        }
    }
}
