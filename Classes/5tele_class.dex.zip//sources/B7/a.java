package B7;

import android.text.TextUtils;
import com.huawei.module_checkout.requestpin.BaseRequestPinActivity;
import com.huawei.module_checkout.view.CheckOutPinEditText;

public final /* synthetic */ class a implements CheckOutPinEditText.a {
    public final /* synthetic */ BaseRequestPinActivity a;

    public /* synthetic */ a(BaseRequestPinActivity baseRequestPinActivity) {
        this.a = baseRequestPinActivity;
    }

    public final void c(String str) {
        BaseRequestPinActivity baseRequestPinActivity = this.a;
        if (TextUtils.isEmpty(baseRequestPinActivity.b) || baseRequestPinActivity.b.contains(",")) {
            if (baseRequestPinActivity.a.g.isChecked()) {
                baseRequestPinActivity.c = baseRequestPinActivity.a.g.getTag() + "";
            } else if (baseRequestPinActivity.a.f.isChecked()) {
                baseRequestPinActivity.c = baseRequestPinActivity.a.f.getTag() + "";
            }
        }
        baseRequestPinActivity.D0(str);
    }
}
