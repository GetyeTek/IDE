package o7;

import T2.h;
import android.util.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;

public final class a extends h<TransferResp, TransferResp> {
    public final /* synthetic */ ArrayMap b;
    public final /* synthetic */ c c;

    public a(c cVar, ArrayMap arrayMap) {
        this.c = cVar;
        this.b = arrayMap;
    }

    public final LiveData<S2.a<TransferResp>> a() {
        return this.c.a.t(this.b);
    }

    public final MutableLiveData b() {
        return this.c.c;
    }

    public final void c(Object obj) {
        this.c.c.postValue((TransferResp) obj);
    }
}
