package o7;

import H3.a;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;

public final class c {
    public final a a = H3.c.e();
    public final MutableLiveData<CheckoutResp> b = new MutableLiveData<>((Object) null);
    public final MutableLiveData<TransferResp> c = new MutableLiveData<>((Object) null);
}
