package o7;

import S2.a;
import T2.h;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import java.util.HashMap;

public final class b extends h<CheckoutResp, CheckoutResp> {
    public final /* synthetic */ HashMap b;
    public final /* synthetic */ c c;

    public b(c cVar, HashMap hashMap) {
        this.c = cVar;
        this.b = hashMap;
    }

    public final LiveData<a<CheckoutResp>> a() {
        return this.c.a.W(this.b);
    }

    public final MutableLiveData b() {
        return this.c.b;
    }

    public final void c(Object obj) {
        this.c.b.postValue((CheckoutResp) obj);
    }
}
