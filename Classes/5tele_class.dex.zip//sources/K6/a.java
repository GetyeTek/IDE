package K6;

import H3.c;
import W2.h;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.huawei.digitalpayment.customer.login_module.R;
import com.huawei.digitalpayment.customer.login_module.activation.SetEncryptedProblemActivity;
import com.huawei.digitalpayment.customer.login_module.resetpin.ResetPinCommitActivity;
import com.huawei.ethiopia.finance.market.dialog.FinanceSelectBankDialog;
import com.huawei.ethiopia.finance.repayment.activity.FinanceRepaymentActivity;
import com.huawei.ethiopia.finance.repayment.viewmodel.FinanceRepaymentViewModel;
import com.huawei.ethiopia.finance.saving.activity.LockedSavingAccountActivity;
import com.huawei.ethiopia.finance.saving.activity.SavingFragment;
import com.huawei.kbz.chat.chat_room.F;
import com.huawei.kbz.chat.contact.NewFriendActivity;
import com.huawei.module_basic_ui.balance.MyBalanceActivity;
import com.huawei.module_basic_ui.successpage.CommonSuccessActivity;
import g4.e;
import g4.f;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import o0.b;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    /* JADX WARNING: type inference failed for: r9v2, types: [com.huawei.module_basic_ui.balance.MyBalanceActivity, android.app.Activity] */
    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = MyBalanceActivity.j;
                b.d((MyBalanceActivity) obj, "/cashModule/cashOut", (Bundle) null, (Map) null);
                return;
            case 1:
                ((FinanceSelectBankDialog) obj).dismiss();
                return;
            case 2:
                int i2 = NewFriendActivity.h;
                ((NewFriendActivity) obj).finish();
                return;
            case 3:
                ((CommonSuccessActivity) obj).i.k.performClick();
                return;
            case 4:
                ResetPinCommitActivity resetPinCommitActivity = (ResetPinCommitActivity) obj;
                String trim = resetPinCommitActivity.j.d.getText().trim();
                String trim2 = resetPinCommitActivity.j.c.getText().trim();
                if (!trim.equals(trim2)) {
                    resetPinCommitActivity.j.c.setError(resetPinCommitActivity.getString(R.string.login_reset_input_same_pins));
                    return;
                }
                String trim3 = resetPinCommitActivity.j.e.getText().toString().trim();
                if (resetPinCommitActivity.n) {
                    f fVar = resetPinCommitActivity.i;
                    fVar.getClass();
                    HashMap hashMap = new HashMap();
                    hashMap.put("forgetPinToken", fVar.c);
                    hashMap.put("initiatorMsisdn", fVar.d);
                    hashMap.put("pinVersion", L3.a.b.getPinKeyVersion());
                    hashMap.put("temporaryPin", L3.a.g(trim3));
                    hashMap.put("newPin", L3.a.g(trim2));
                    fVar.a(c.e().Q(hashMap), new e(fVar, (P2.a) fVar.a));
                    w5.a.a("Reset_Pin_Final_confirm_V1");
                    return;
                }
                Pattern pattern = SetEncryptedProblemActivity.r;
                Intent intent = new Intent(resetPinCommitActivity, SetEncryptedProblemActivity.class);
                intent.putExtra("newPin", trim);
                intent.putExtra("temporaryPin", trim3);
                intent.putExtra("register_event_prefix", "Reset_Pin_Final_confirm_V1");
                resetPinCommitActivity.startActivity(intent);
                return;
            case 5:
                int i3 = FinanceRepaymentActivity.e;
                FinanceRepaymentActivity financeRepaymentActivity = (FinanceRepaymentActivity) obj;
                HashMap hashMap2 = new HashMap();
                hashMap2.put("rePaymentType", financeRepaymentActivity.b.c.getText());
                hashMap2.put("identifierType", financeRepaymentActivity.b.b.getText());
                if ("01".equals(financeRepaymentActivity.b.b.getText())) {
                    hashMap2.put("identifier", "251" + h.b(financeRepaymentActivity.d.getText().toString()));
                } else {
                    hashMap2.put("identifier", financeRepaymentActivity.d.getText().toString());
                }
                hashMap2.put("contractNo", financeRepaymentActivity.b.a.getText());
                FinanceRepaymentViewModel financeRepaymentViewModel = financeRepaymentActivity.c;
                financeRepaymentViewModel.a.setValue(V7.c.c());
                com.huawei.http.b bVar = new com.huawei.http.b();
                bVar.addParams(hashMap2);
                bVar.sendRequest(new F(financeRepaymentViewModel, 2));
                return;
            default:
                SavingFragment savingFragment = (SavingFragment) obj;
                savingFragment.getClass();
                Intent intent2 = new Intent(savingFragment.requireContext(), LockedSavingAccountActivity.class);
                intent2.putExtra("bankCode", savingFragment.h);
                intent2.putExtra("fundsLenderId", savingFragment.e);
                savingFragment.startActivity(intent2);
                return;
        }
    }
}
