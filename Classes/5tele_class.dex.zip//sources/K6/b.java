package K6;

import D2.e;
import H3.c;
import a5.l;
import android.os.Bundle;
import android.view.View;
import com.huawei.digitalpayment.customer.login_module.resetpin.ResetPinCommitActivity;
import com.huawei.digitalpayment.fuel.activity.FuelPaymentActivity;
import com.huawei.kbz.chat.chat_room.view_holder.SystemInfoMessageContentViewHolder;
import com.huawei.module_basic_ui.balance.MyBalanceActivity;
import com.huawei.module_basic_ui.successpage.CommonSuccessActivity;
import com.huawei.module_basic_ui.successpage.a;
import g4.d;
import g4.f;
import java.util.HashMap;
import java.util.Map;

public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ b(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.module_basic_ui.balance.MyBalanceActivity, android.app.Activity] */
    /* JADX WARNING: type inference failed for: r0v3, types: [java.lang.Object, com.huawei.module_basic_ui.successpage.CommonSuccessActivity, android.app.Activity] */
    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = MyBalanceActivity.j;
                o0.b.d((MyBalanceActivity) obj, "/cashModule/cashIn", (Bundle) null, (Map) null);
                return;
            case 1:
                SystemInfoMessageContentViewHolder.a((P5.b) obj, view);
                return;
            case 2:
                int i2 = CommonSuccessActivity.n;
                ? r0 = (CommonSuccessActivity) obj;
                r0.getClass();
                new e(r0).a(new a(r0));
                return;
            case 3:
                int i3 = ResetPinCommitActivity.q;
                ResetPinCommitActivity resetPinCommitActivity = (ResetPinCommitActivity) obj;
                if (!W2.a.a(1500, view)) {
                    resetPinCommitActivity.o.start();
                    f fVar = resetPinCommitActivity.i;
                    fVar.getClass();
                    HashMap hashMap = new HashMap();
                    hashMap.put("initiatorMsisdn", fVar.d);
                    hashMap.put("forgetPinToken", fVar.c);
                    fVar.a(c.e().v0(hashMap), new d(fVar, (P2.a) fVar.a));
                    return;
                }
                return;
            default:
                int i4 = FuelPaymentActivity.e;
                FuelPaymentActivity fuelPaymentActivity = (FuelPaymentActivity) obj;
                r4.f.b.a(fuelPaymentActivity, new l(fuelPaymentActivity, 6));
                return;
        }
    }
}
