package K6;

import android.os.Bundle;
import android.view.View;
import com.huawei.astp.macle.ui.video.MaVideoPlayer;
import com.huawei.kbz.chat.chat_room.view_holder.TransactionInfoMessageContentViewHolder;
import com.huawei.module_basic_ui.balance.MyBalanceActivity;
import com.huawei.module_basic_ui.successpage.CommonSuccessActivity;
import java.util.Map;
import o0.b;

public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.module_basic_ui.balance.MyBalanceActivity, android.app.Activity] */
    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = MyBalanceActivity.j;
                b.d((MyBalanceActivity) obj, "/historyModule/history", (Bundle) null, (Map) null);
                return;
            case 1:
                MaVideoPlayer.a((MaVideoPlayer) obj, view);
                return;
            case 2:
                TransactionInfoMessageContentViewHolder.a((P5.b) obj, view);
                return;
            default:
                ((CommonSuccessActivity) obj).i.n.performClick();
                return;
        }
    }
}
