package C7;

import T2.h;
import android.util.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import java.util.HashMap;
import java.util.Map;
import t7.b;

public final class a extends h {
    public final /* synthetic */ int b;
    public final /* synthetic */ Map c;
    public final /* synthetic */ Object d;

    public /* synthetic */ a(Object obj, Map map, int i) {
        this.b = i;
        this.d = obj;
        this.c = map;
    }

    public final LiveData a() {
        switch (this.b) {
            case 0:
                return ((b) this.d).a.W((HashMap) this.c);
            default:
                return ((b) this.d).a.W((ArrayMap) this.c);
        }
    }

    public final MutableLiveData b() {
        switch (this.b) {
            case 0:
                return ((b) this.d).b;
            default:
                return ((b) this.d).c;
        }
    }

    public final void c(Object obj) {
        switch (this.b) {
            case 0:
                ((b) this.d).b.postValue((CheckoutResp) obj);
                return;
            default:
                ((b) this.d).c.postValue((CheckoutResp) obj);
                return;
        }
    }
}
