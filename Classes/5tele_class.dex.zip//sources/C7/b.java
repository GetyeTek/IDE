package C7;

import H3.a;
import H3.c;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;

public final class b {
    public final a a = c.e();
    public final MutableLiveData<CheckoutResp> b = new MutableLiveData<>((Object) null);
}
