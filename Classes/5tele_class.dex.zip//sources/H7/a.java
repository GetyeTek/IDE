package H7;

import android.net.Uri;
import android.text.TextUtils;
import androidx.camera.core.c;
import com.blankj.utilcode.util.n;
import com.blankj.utilcode.util.s;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.ConfigVerifyResp;
import com.huawei.module_checkout.R$string;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public final class a implements R1.a {
    public static String a(StackTraceElement[] stackTraceElementArr) {
        StringBuilder sb = new StringBuilder();
        for (StackTraceElement stackTraceElement : stackTraceElementArr) {
            sb.append("    at ");
            sb.append(stackTraceElement.toString());
            sb.append("\n");
        }
        return sb.toString();
    }

    public static HashMap b(Uri uri) {
        HashMap hashMap = new HashMap();
        for (String next : uri.getQueryParameterNames()) {
            hashMap.put(next, uri.getQueryParameter(next));
        }
        return hashMap;
    }

    public static String c(long j) {
        Locale locale;
        Calendar instance = Calendar.getInstance();
        instance.setTime(new Date());
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        long time = instance.getTime().getTime();
        String b = s.a("Utils").b("KEY_LOCALE");
        if (TextUtils.isEmpty(b) || "VALUE_FOLLOW_SYSTEM".equals(b)) {
            locale = null;
        } else {
            locale = n.a(b);
        }
        if (j >= time) {
            return String.format(locale, "%s %tT", new Object[]{E2.a.c.a.getString(R$string.designstandard_today), Long.valueOf(j)});
        } else if (j >= time - 86400000) {
            return String.format(locale, "%s %tT", new Object[]{E2.a.c.a.getString(R$string.designstandard_yesterday), Long.valueOf(j)});
        } else {
            return c.a(String.format(locale, "%tF", new Object[]{Long.valueOf(j)}).substring(5), String.format(locale, " %tT", new Object[]{Long.valueOf(j)}));
        }
    }

    public static String[] d(Map map) {
        ArrayList arrayList = new ArrayList();
        if (map == null) {
            return new String[1];
        }
        for (String str : map.keySet()) {
            arrayList.add((String) map.get(str));
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    public static boolean e(CharSequence charSequence) {
        if (charSequence == null || charSequence.length() == 0) {
            return true;
        }
        return false;
    }

    public static Map f(Uri uri) {
        String str;
        String encodedQuery = uri.getEncodedQuery();
        if (encodedQuery == null) {
            return Collections.emptyMap();
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        int i = 0;
        do {
            int indexOf = encodedQuery.indexOf(38, i);
            if (indexOf == -1) {
                indexOf = encodedQuery.length();
            }
            int indexOf2 = encodedQuery.indexOf(61, i);
            if (indexOf2 > indexOf || indexOf2 == -1) {
                indexOf2 = indexOf;
            }
            String substring = encodedQuery.substring(i, indexOf2);
            if (!TextUtils.isEmpty(substring)) {
                if (indexOf2 == indexOf) {
                    str = "";
                } else {
                    str = encodedQuery.substring(indexOf2 + 1, indexOf);
                }
                linkedHashMap.put(Uri.decode(substring), Uri.decode(str));
            }
            i = indexOf + 1;
        } while (i < encodedQuery.length());
        return Collections.unmodifiableMap(linkedHashMap);
    }

    public /* synthetic */ void onComplete() {
    }

    public /* bridge */ /* synthetic */ void onLoading(Object obj) {
        ConfigVerifyResp configVerifyResp = (ConfigVerifyResp) obj;
    }

    public /* bridge */ /* synthetic */ void onSuccess(Object obj) {
        ConfigVerifyResp configVerifyResp = (ConfigVerifyResp) obj;
    }

    public void onError(BaseException baseException) {
    }
}
