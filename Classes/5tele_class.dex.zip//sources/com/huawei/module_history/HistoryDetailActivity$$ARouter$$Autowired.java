package com.huawei.module_history;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class HistoryDetailActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [android.app.Activity, com.huawei.module_history.HistoryDetailActivity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (HistoryDetailActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.mOrderId;
        } else {
            str = r4.getIntent().getExtras().getString("orderId", r4.mOrderId);
        }
        r4.mOrderId = str;
    }
}
