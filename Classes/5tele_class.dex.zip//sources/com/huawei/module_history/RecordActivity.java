package com.huawei.module_history;

import G7.g;
import G7.h;
import H3.c;
import N0.E;
import N0.F;
import W1.b;
import Yb.j;
import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.graphics.Paint;
import android.text.TextPaint;
import android.widget.PopupWindow;
import androidx.recyclerview.widget.RecyclerView;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.C;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.loadmore.BaseLoadMoreView;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.bean.TradeTypeConfigBean;
import com.huawei.digitalpayment.customer.httplib.bean.TransRecordBean;
import com.huawei.digitalpayment.paybill.activity.i;
import com.huawei.ethiopia.finance.market.f;
import com.huawei.module_history.adapter.TransactionRecordAdapter;
import com.huawei.module_history.databinding.ActivityRecordBinding;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import com.scwang.smart.refresh.layout.constant.RefreshState;
import h9.e;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.greenrobot.eventbus.ThreadMode;

@J2.a
@Route(path = "/historyModule/history")
public class RecordActivity extends BaseMvpActivity<g> implements h, e, PopupWindow.OnDismissListener {
    public static final /* synthetic */ int r = 0;
    public ActivityRecordBinding j;
    public int k = 0;
    public TransactionRecordAdapter l;
    public ArrayList m;
    public final ArrayList n = new ArrayList();
    public ArrayList<TradeTypeConfigBean> o;
    public boolean p;
    public g q;

    public class a {
        public a() {
        }

        public final String a(int i) {
            RecordActivity recordActivity = RecordActivity.this;
            if (i >= recordActivity.n.size() || recordActivity.n.get(i) == null) {
                return "";
            }
            return (String) recordActivity.n.get(i);
        }

        public final String b(int i) {
            RecordActivity recordActivity = RecordActivity.this;
            if (i >= recordActivity.n.size() || recordActivity.n.get(i) == null) {
                return "";
            }
            return (String) recordActivity.n.get(i);
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, com.huawei.module_history.g] */
    public final void D0() {
        this.m = new ArrayList();
        ? obj = new Object();
        obj.a = null;
        obj.b = null;
        obj.c = null;
        this.q = obj;
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_transaction_record, this.m);
        this.l = baseQuickAdapter;
        baseQuickAdapter.getLoadMoreModule().setOnLoadMoreListener(new f(this));
        this.l.setOnItemClickListener(new i(this, 3));
        this.j.f.setAdapter(this.l);
        RecyclerView recyclerView = this.j.f;
        ArrayList arrayList = this.n;
        a aVar = new a();
        RecyclerView.ItemDecoration itemDecoration = new RecyclerView.ItemDecoration();
        Resources resources = getResources();
        itemDecoration.a = arrayList;
        itemDecoration.b = aVar;
        Paint paint = new Paint();
        itemDecoration.d = paint;
        paint.setColor(resources.getColor(R$color.color_F4F4F4));
        TextPaint textPaint = new TextPaint();
        itemDecoration.c = textPaint;
        textPaint.setAntiAlias(true);
        textPaint.setTextSize((float) R9.h.a(this, 14.0f));
        textPaint.setColor(-16777216);
        textPaint.setTextAlign(Paint.Align.LEFT);
        itemDecoration.e = resources.getDimensionPixelSize(R$dimen.sectioned_top2);
        itemDecoration.f = resources.getDimensionPixelSize(R$dimen.sectioned_alignBottom2);
        itemDecoration.g = R9.h.a(this, 16.0f);
        recyclerView.addItemDecoration(itemDecoration);
        this.l.getLoadMoreModule().setLoadMoreView(new BaseLoadMoreView());
        this.p = true;
        g gVar = this.q;
        this.i.b(gVar.a, gVar.b, this.k, gVar.c, false);
        g gVar2 = this.i;
        gVar2.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("configTypes", new String[]{"tradeTypeConfig"});
        gVar2.a(c.e().z0(hashMap), new G7.f(gVar2, (P2.a) gVar2.a));
    }

    public final void F0() {
        if (this.a == null) {
            this.a = b.b().c(this.j.g);
        }
    }

    public final void G(String str) {
        if (this.p) {
            F0();
            this.a.a(2);
            this.p = false;
            return;
        }
        this.j.g.i();
    }

    public final void G0() {
        RecordActivity.super.G0();
        O0(R$string.history_history);
        this.j.c.setOnClickListener(new S3.e(this, 6));
        this.j.d.setOnClickListener(new E(this, 4));
        ActivityRecordBinding activityRecordBinding = this.j;
        activityRecordBinding.g.S0 = this;
        activityRecordBinding.i.setOnClickListener(new F(this, 9));
    }

    public final void I(List<TransRecordBean> list) {
        if (list == null) {
            this.j.b.setVisibility(0);
            this.j.f.setVisibility(8);
            return;
        }
        this.j.b.setVisibility(8);
        this.j.f.setVisibility(0);
        this.k = 0;
        this.k = list.size();
        this.m.clear();
        this.m.addAll(list);
        V0(this.m);
        this.l.getLoadMoreModule().setEnableLoadMoreIfNotFullPage(false);
        this.l.notifyDataSetChanged();
    }

    public final void J(ArrayList<TradeTypeConfigBean> arrayList) {
        this.o = arrayList;
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [com.huawei.module_history.RecordActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0049, code lost:
        r1 = com.huawei.module_history.R$id.rv_record;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0054, code lost:
        r1 = com.huawei.module_history.R$id.swipe_refresh;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0037, code lost:
        r1 = com.huawei.module_history.R$id.line_filter;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r13 = this;
            android.view.LayoutInflater r0 = r13.getLayoutInflater()
            int r1 = com.huawei.module_history.R$layout.activity_record
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_history.R$id.empty_view
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            android.widget.LinearLayout r5 = (android.widget.LinearLayout) r5
            if (r5 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.imageView3
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            if (r2 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.img_date_picker
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.img_filter
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            if (r7 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.line_filter
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r8 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.rl_top
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.RelativeLayout r2 = (android.widget.RelativeLayout) r2
            if (r2 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.rv_record
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            androidx.recyclerview.widget.RecyclerView r9 = (androidx.recyclerview.widget.RecyclerView) r9
            if (r9 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.swipe_refresh
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            com.scwang.smart.refresh.layout.SmartRefreshLayout r10 = (com.scwang.smart.refresh.layout.SmartRefreshLayout) r10
            if (r10 == 0) goto L_0x008b
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            int r1 = com.huawei.module_history.R$id.textView7
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.tv_time
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            android.widget.TextView r11 = (android.widget.TextView) r11
            if (r11 == 0) goto L_0x008b
            int r1 = com.huawei.module_history.R$id.view_all
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r12 = r2
            android.widget.Button r12 = (android.widget.Button) r12
            if (r12 == 0) goto L_0x008b
            com.huawei.module_history.databinding.ActivityRecordBinding r0 = new com.huawei.module_history.databinding.ActivityRecordBinding
            r3 = r0
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r13.j = r0
            return r0
        L_0x008b:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_history.RecordActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        int i;
        if (this.p) {
            F0();
            this.a.a(1);
            return;
        }
        SmartRefreshLayout smartRefreshLayout = this.j.g;
        if (smartRefreshLayout.v1) {
            i = 0;
        } else {
            i = 400;
        }
        float f = (smartRefreshLayout.f1 + smartRefreshLayout.h1) / 2.0f;
        if (smartRefreshLayout.q1 == RefreshState.None && smartRefreshLayout.l(smartRefreshLayout.B)) {
            e9.e eVar = new e9.e(smartRefreshLayout, f, smartRefreshLayout.f);
            smartRefreshLayout.setViceState(RefreshState.Refreshing);
            if (i > 0) {
                smartRefreshLayout.o1.postDelayed(eVar, (long) i);
            } else {
                eVar.run();
            }
        }
    }

    public final void V0(ArrayList arrayList) {
        ArrayList arrayList2 = this.n;
        arrayList2.clear();
        for (int i = 0; i < arrayList.size(); i++) {
            arrayList2.add(String.format(getResources().getConfiguration().locale, "%tB", new Object[]{Long.valueOf(((TransRecordBean) arrayList.get(i)).getTransTime())}));
        }
    }

    public final void onDismiss() {
        g gVar = this.q;
        if (gVar.a == null && gVar.b == null) {
            this.j.c.setSelected(false);
        } else {
            this.j.c.setSelected(true);
        }
        if (this.q.c != null) {
            this.j.d.setSelected(true);
        } else {
            this.j.d.setSelected(false);
        }
    }

    @j(threadMode = ThreadMode.MAIN)
    @SuppressLint({"StringFormatInvalid"})
    public void onReceiveFilterEvent(g gVar) {
        this.k = 0;
        this.q = gVar;
        if (!(gVar.a == null || gVar.b == null)) {
            this.j.h.setText(String.format(getResources().getString(R$string.history_1s_to_2s), new Object[]{C.a("yyyy-MM-dd", this.q.a.getTime()), C.a("yyyy-MM-dd", this.q.b.getTime())}));
        }
        g gVar2 = this.q;
        this.i.b(gVar2.a, gVar2.b, this.k, gVar2.c, false);
        g gVar3 = this.q;
        if (gVar3.c == null && gVar3.a == null && gVar3.b == null) {
            this.j.i.setVisibility(8);
        } else {
            this.j.i.setVisibility(0);
        }
    }

    public final void onRefresh() {
        this.k = 0;
        g gVar = this.q;
        this.i.b(gVar.a, gVar.b, 0, gVar.c, false);
    }

    public final void q(List<TransRecordBean> list) {
        if (list == null || list.isEmpty()) {
            this.l.getLoadMoreModule().loadMoreEnd();
            return;
        }
        this.l.getLoadMoreModule().loadMoreComplete();
        this.m.addAll(list);
        V0(this.m);
        this.k = list.size() + this.k;
        this.l.notifyDataSetChanged();
    }
}
