package com.huawei.module_history;

import java.util.ArrayList;
import java.util.Calendar;

public final class g {
    public Calendar a;
    public Calendar b;
    public ArrayList c;
}
