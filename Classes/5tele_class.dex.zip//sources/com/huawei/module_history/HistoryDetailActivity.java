package com.huawei.module_history;

import G7.c;
import G7.d;
import J2.a;
import V1.k;
import Y4.m;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.response.TransRecordDetailResponse;
import com.huawei.module_history.databinding.ActivityHistoryDetailBinding;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

@a
@Route(path = "/historyModule/historyDetails")
public class HistoryDetailActivity extends BaseMvpActivity<c> implements d {
    public static final /* synthetic */ int m = 0;
    public TransRecordDetailResponse j;
    public ActivityHistoryDetailBinding k;
    public final String l = "";
    @Autowired(name = "orderId")
    String mOrderId;

    /* JADX WARNING: type inference failed for: r1v0, types: [android.app.Activity, com.huawei.module_history.HistoryDetailActivity] */
    public final void D(String str) {
        finish();
        k.b(1, str);
    }

    public final void D0() {
        c cVar = this.i;
        String str = this.mOrderId;
        cVar.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("orderId", str);
        cVar.a(H3.c.e().f(hashMap), new G7.a(cVar, (P2.a) cVar.a));
    }

    public final void G(String str) {
    }

    public final void G0() {
        HistoryDetailActivity.super.G0();
        O0(R$string.history_details);
        this.k.b.setOnClickListener(new m(this, 5));
    }

    public final void I0() {
        c cVar = this.i;
        String str = this.mOrderId;
        cVar.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("orderId", str);
        cVar.a(H3.c.e().f(hashMap), new G7.a(cVar, (P2.a) cVar.a));
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [android.app.Activity, com.huawei.module_history.HistoryDetailActivity] */
    public final ViewBinding K0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_history_detail, (ViewGroup) null, false);
        int i = R$id.btn_ok;
        if (((Button) ViewBindings.findChildViewById(inflate, i)) != null) {
            i = R$id.btn_refund;
            Button button = (Button) ViewBindings.findChildViewById(inflate, i);
            if (button != null) {
                i = R$id.img_status;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i);
                if (imageView != null) {
                    i = R$id.line;
                    if (ViewBindings.findChildViewById(inflate, i) != null) {
                        i = R$id.ll_field_list;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(inflate, i);
                        if (linearLayout != null) {
                            i = R$id.ll_top;
                            if (((LinearLayout) ViewBindings.findChildViewById(inflate, i)) != null) {
                                ConstraintLayout constraintLayout = inflate;
                                i = R$id.tv_currency;
                                TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
                                if (textView != null) {
                                    i = R$id.tv_currency_pre;
                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(inflate, i);
                                    if (textView2 != null) {
                                        i = R$id.tv_desc;
                                        TextView textView3 = (TextView) ViewBindings.findChildViewById(inflate, i);
                                        if (textView3 != null) {
                                            i = R$id.tv_status;
                                            TextView textView4 = (TextView) ViewBindings.findChildViewById(inflate, i);
                                            if (textView4 != null) {
                                                i = R$id.tv_title_amount;
                                                TextView textView5 = (TextView) ViewBindings.findChildViewById(inflate, i);
                                                if (textView5 != null) {
                                                    ActivityHistoryDetailBinding activityHistoryDetailBinding = new ActivityHistoryDetailBinding(constraintLayout, button, imageView, linearLayout, textView, textView2, textView3, textView4, textView5);
                                                    this.k = activityHistoryDetailBinding;
                                                    return activityHistoryDetailBinding;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    /* JADX WARNING: type inference failed for: r0v9, types: [java.lang.Object, java.util.Comparator] */
    public final void N(TransRecordDetailResponse transRecordDetailResponse) {
        if (transRecordDetailResponse != null) {
            this.j = transRecordDetailResponse;
            if (transRecordDetailResponse.getTradeStatus() == null) {
                E0(this.k.a);
                this.a.a(3);
                return;
            }
            E0(this.k.a);
            this.a.a(2);
            try {
                Collections.sort(transRecordDetailResponse.getTradeDetails(), new Object());
            } catch (Exception unused) {
            }
            this.k.i.setText(this.j.getAmount());
            this.k.h.setText(this.j.getTradeStatusDesc());
            if (!TextUtils.isEmpty(this.j.getUnit())) {
                if ("Prefix".equals(this.j.getUnitType())) {
                    this.k.f.setVisibility(0);
                    this.k.f.setText(this.j.getUnit());
                } else {
                    this.k.e.setVisibility(0);
                    this.k.e.setText(this.j.getUnit());
                }
            }
            this.k.e.setText(this.j.getCurrency());
            if (!TextUtils.isEmpty(this.j.getTradeDesc())) {
                this.k.g.setVisibility(0);
                this.k.g.setText(this.j.getTradeDesc());
            }
            String tradeStatus = this.j.getTradeStatus();
            tradeStatus.getClass();
            if (tradeStatus.equals("Success")) {
                this.k.c.setImageResource(R$mipmap.icon_success);
            } else if (!tradeStatus.equals("Canceled")) {
                this.k.c.setImageResource(R$mipmap.icon_history_processing);
            } else {
                this.k.c.setImageResource(R$mipmap.icon_warning_red);
            }
            if ("refundable".equals(this.j.getRefundStatus())) {
                this.k.b.setVisibility(0);
            } else {
                this.k.b.setVisibility(8);
            }
            ArrayList arrayList = new ArrayList();
            if (this.j.getTradeDetails() != null && !this.j.getTradeDetails().isEmpty()) {
                for (TransRecordDetailResponse.Field field : this.j.getTradeDetails()) {
                    if (TextUtils.isEmpty(field.getGroup())) {
                        arrayList.add(field);
                    }
                }
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    this.k.d.addView(V0((TransRecordDetailResponse.Field) it.next()));
                }
            }
            HashMap hashMap = new HashMap();
            ArrayList arrayList2 = new ArrayList();
            if (this.j.getTradeDetails() != null && !this.j.getTradeDetails().isEmpty()) {
                for (TransRecordDetailResponse.Field field2 : this.j.getTradeDetails()) {
                    if (!TextUtils.isEmpty(field2.getGroup())) {
                        List list = (List) hashMap.get(field2.getGroup());
                        if (list == null) {
                            list = new ArrayList();
                            hashMap.put(field2.getGroup(), list);
                            arrayList2.add(field2.getGroup());
                        }
                        list.add(field2);
                    }
                }
                Iterator it2 = arrayList2.iterator();
                while (it2.hasNext()) {
                    String str = (String) it2.next();
                    View inflate = getLayoutInflater().inflate(R$layout.item_detail_group_field, this.k.d, false);
                    ((TextView) inflate.findViewById(R$id.tv_group_name)).setText(str);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R$id.ll_group_info);
                    for (TransRecordDetailResponse.Field V0 : (List) hashMap.get(str)) {
                        linearLayout.addView(V0(V0));
                    }
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R$id.ll_group_title);
                    LinearLayout linearLayout3 = (LinearLayout) inflate.findViewById(R$id.ll_group_info);
                    linearLayout3.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
                    linearLayout3.setTag(Integer.valueOf(linearLayout3.getMeasuredHeight()));
                    linearLayout2.setOnClickListener(new b(this, linearLayout2, (ImageView) inflate.findViewById(R$id.iv_down), linearLayout3));
                    this.k.d.addView(inflate);
                }
            }
        }
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        E0(this.k.a);
        this.a.a(1);
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.app.Activity, com.huawei.module_history.HistoryDetailActivity] */
    public final View V0(TransRecordDetailResponse.Field field) {
        String str;
        View inflate = getLayoutInflater().inflate(R$layout.item_detail_field, this.k.d, false);
        TextView textView = (TextView) inflate.findViewById(R$id.tv_field_name);
        TextView textView2 = (TextView) inflate.findViewById(R$id.tv_field_value);
        String fieldName = field.getFieldName();
        if ("timestamp".equals(field.getType())) {
            try {
                str = H7.a.c(Long.parseLong(field.getFieldValue()));
            } catch (NumberFormatException unused) {
                str = field.getFieldValue();
            }
        } else {
            str = field.getFieldValue();
        }
        textView.setText(fieldName);
        textView2.setText(str);
        return inflate;
    }

    public final void a0(String str) {
        F0();
        this.a.a(3);
        k.b(1, str);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.app.Activity, com.huawei.module_history.HistoryDetailActivity] */
    public void onViewClicked(View view) {
        if (view.getId() == R$id.btn_ok) {
            finish();
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, android.app.Activity, com.huawei.module_history.HistoryDetailActivity] */
    public final void u0() {
        finish();
        k.b(1, getString(R$string.designstandard_success));
    }
}
