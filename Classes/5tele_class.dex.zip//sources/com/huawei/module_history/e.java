package com.huawei.module_history;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.widget.LinearLayout;

public final class e extends AnimatorListenerAdapter {
    public final /* synthetic */ LinearLayout a;

    public e(LinearLayout linearLayout) {
        this.a = linearLayout;
    }

    public final void onAnimationEnd(Animator animator) {
        this.a.setTag("true");
    }
}
