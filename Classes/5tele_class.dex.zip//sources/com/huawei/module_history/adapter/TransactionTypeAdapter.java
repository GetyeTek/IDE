package com.huawei.module_history.adapter;

import android.util.SparseBooleanArray;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.bean.TradeTypeConfigBean;
import com.huawei.module_history.R$id;
import java.util.List;

public class TransactionTypeAdapter extends BaseQuickAdapter<TradeTypeConfigBean, BaseViewHolder> {
    public List<TradeTypeConfigBean> a;
    public SparseBooleanArray b;

    public TransactionTypeAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i = R$id.transaction_type_name;
        baseViewHolder.setText(i, ((TradeTypeConfigBean) obj).getServiceName());
        if (this.b.get(baseViewHolder.getAdapterPosition())) {
            baseViewHolder.getView(i).setSelected(true);
        } else {
            baseViewHolder.getView(i).setSelected(false);
        }
    }
}
