package com.huawei.module_history.adapter;

import H7.a;
import O9.c;
import android.text.TextUtils;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.module.BaseLoadMoreModule;
import com.chad.library.adapter.base.module.LoadMoreModule;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.bean.TransRecordBean;
import com.huawei.module_history.R$id;
import com.huawei.module_history.R$mipmap;

public class TransactionRecordAdapter extends BaseQuickAdapter<TransRecordBean, BaseViewHolder> implements LoadMoreModule {
    public TransactionRecordAdapter() {
        throw null;
    }

    @NonNull
    public final BaseLoadMoreModule addLoadMoreModule(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter) {
        return new BaseLoadMoreModule(baseQuickAdapter);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        String str;
        TransRecordBean transRecordBean = (TransRecordBean) obj;
        BaseViewHolder text = baseViewHolder.setText(R$id.tv_trans_type, transRecordBean.getTransTypeDisplay());
        int i = R$id.tv_from;
        if (TextUtils.isEmpty(transRecordBean.getExecuteOperatorName())) {
            str = "";
        } else {
            str = transRecordBean.getExecuteOperatorName();
        }
        text.setText(i, str).setText(R$id.tv_amount, transRecordBean.getAmountDisplay()).setText(R$id.tv_trans_time, a.c(transRecordBean.getTransTime()));
        c.c((ImageView) baseViewHolder.getView(R$id.iv_logo), transRecordBean.getLogo(), R$mipmap.icon_history_cashin);
    }
}
