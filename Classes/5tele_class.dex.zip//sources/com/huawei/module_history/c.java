package com.huawei.module_history;

import L3.a;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import com.huawei.digitalpayment.customer.viewlib.EnterPinFragment;
import java.util.HashMap;
import java.util.Map;
import o0.b;

public final /* synthetic */ class c implements EnterPinFragment.b {
    public final /* synthetic */ HistoryDetailActivity a;

    public /* synthetic */ c(HistoryDetailActivity historyDetailActivity) {
        this.a = historyDetailActivity;
    }

    public final void a(String str) {
        int i = HistoryDetailActivity.m;
        FragmentActivity fragmentActivity = this.a;
        fragmentActivity.getSupportFragmentManager().popBackStack();
        if ("forget".equals(str)) {
            b.d(fragmentActivity, "/loginModule/reSetPin", (Bundle) null, (Map) null);
            return;
        }
        G7.c cVar = fragmentActivity.i;
        String str2 = fragmentActivity.mOrderId;
        cVar.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("initiatorPin", a.g(str));
        hashMap.put("pinVersion", a.b.getPinKeyVersion());
        hashMap.put("orderId", str2);
        hashMap.put("note", fragmentActivity.l);
        cVar.a(H3.c.e().b0(hashMap), new G7.b(cVar, (P2.a) cVar.a, 0));
    }
}
