package com.huawei.module_history.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;

public final class PopupDatePickerBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;

    public PopupDatePickerBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull ConstraintLayout constraintLayout, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull ImageView imageView, @NonNull LinearLayout linearLayout2) {
        this.a = linearLayout;
        this.b = textView2;
        this.c = textView3;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
