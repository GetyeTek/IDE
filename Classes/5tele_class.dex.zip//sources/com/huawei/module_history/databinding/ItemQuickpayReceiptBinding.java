package com.huawei.module_history.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ItemQuickpayReceiptBinding implements ViewBinding {
    @NonNull
    public final /* bridge */ /* synthetic */ View getRoot() {
        return null;
    }
}
