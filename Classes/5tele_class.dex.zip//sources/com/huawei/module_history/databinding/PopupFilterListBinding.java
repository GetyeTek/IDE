package com.huawei.module_history.databinding;

import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;

public final class PopupFilterListBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final Button b;
    @NonNull
    public final RecyclerView c;
    @NonNull
    public final Button d;

    public PopupFilterListBinding(@NonNull ConstraintLayout constraintLayout, @NonNull Button button, @NonNull RecyclerView recyclerView, @NonNull Button button2) {
        this.a = constraintLayout;
        this.b = button;
        this.c = recyclerView;
        this.d = button2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
