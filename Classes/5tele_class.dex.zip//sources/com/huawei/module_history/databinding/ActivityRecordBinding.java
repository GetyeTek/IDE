package com.huawei.module_history.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;

public final class ActivityRecordBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final LinearLayout b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final View e;
    @NonNull
    public final RecyclerView f;
    @NonNull
    public final SmartRefreshLayout g;
    @NonNull
    public final TextView h;
    @NonNull
    public final Button i;

    public ActivityRecordBinding(@NonNull ConstraintLayout constraintLayout, @NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull View view, @NonNull RecyclerView recyclerView, @NonNull SmartRefreshLayout smartRefreshLayout, @NonNull TextView textView, @NonNull Button button) {
        this.a = constraintLayout;
        this.b = linearLayout;
        this.c = imageView;
        this.d = imageView2;
        this.e = view;
        this.f = recyclerView;
        this.g = smartRefreshLayout;
        this.h = textView;
        this.i = button;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
