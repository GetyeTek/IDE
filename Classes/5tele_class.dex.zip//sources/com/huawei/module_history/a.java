package com.huawei.module_history;

import com.huawei.digitalpayment.customer.httplib.response.TransRecordDetailResponse;
import java.util.Comparator;

public final /* synthetic */ class a implements Comparator {
    public final int compare(Object obj, Object obj2) {
        int i = HistoryDetailActivity.m;
        return ((TransRecordDetailResponse.Field) obj).getOrder().compareTo(((TransRecordDetailResponse.Field) obj2).getOrder());
    }
}
