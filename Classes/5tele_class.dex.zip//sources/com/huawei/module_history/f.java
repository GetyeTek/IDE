package com.huawei.module_history;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.widget.LinearLayout;

public final class f extends AnimatorListenerAdapter {
    public final /* synthetic */ LinearLayout a;
    public final /* synthetic */ LinearLayout b;

    public f(LinearLayout linearLayout, LinearLayout linearLayout2) {
        this.a = linearLayout;
        this.b = linearLayout2;
    }

    public final void onAnimationEnd(Animator animator) {
        this.a.setVisibility(8);
        this.b.setTag("false");
    }
}
