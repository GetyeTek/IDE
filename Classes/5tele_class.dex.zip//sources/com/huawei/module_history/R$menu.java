package com.huawei.module_history;

public final class R$menu {
    public static final int main = 2131689473;
    public static final int ucrop_menu = 2131689479;

    private R$menu() {
    }
}
