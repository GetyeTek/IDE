package com.huawei.module_history;

public final class R$plurals {
    public static final int mtrl_badge_content_description = 2131886080;

    private R$plurals() {
    }
}
