package com.huawei.module_history;

import android.animation.ValueAnimator;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ HistoryDetailActivity a;
    public final /* synthetic */ LinearLayout b;
    public final /* synthetic */ ImageView c;
    public final /* synthetic */ LinearLayout d;

    public /* synthetic */ b(HistoryDetailActivity historyDetailActivity, LinearLayout linearLayout, ImageView imageView, LinearLayout linearLayout2) {
        this.a = historyDetailActivity;
        this.b = linearLayout;
        this.c = imageView;
        this.d = linearLayout2;
    }

    public final void onClick(View view) {
        int i = HistoryDetailActivity.m;
        this.a.getClass();
        LinearLayout linearLayout = this.b;
        boolean equals = "true".equals(linearLayout.getTag());
        LinearLayout linearLayout2 = this.d;
        ImageView imageView = this.c;
        if (equals) {
            imageView.setImageResource(R$mipmap.icon_history_arrow_up_gray);
            ValueAnimator ofInt = ValueAnimator.ofInt(new int[]{linearLayout2.getHeight(), 0});
            ofInt.addUpdateListener(new d(linearLayout2));
            ofInt.addListener(new f(linearLayout2, linearLayout));
            ofInt.start();
            return;
        }
        imageView.setImageResource(R$mipmap.icon_history_arrow_down);
        linearLayout2.setVisibility(0);
        ValueAnimator ofInt2 = ValueAnimator.ofInt(new int[]{0, ((Integer) linearLayout2.getTag()).intValue()});
        ofInt2.addUpdateListener(new d(linearLayout2));
        ofInt2.addListener(new e(linearLayout));
        ofInt2.start();
    }
}
