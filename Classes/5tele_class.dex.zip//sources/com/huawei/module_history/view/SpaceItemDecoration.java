package com.huawei.module_history.view;

import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public class SpaceItemDecoration extends RecyclerView.ItemDecoration {
    public int a;
    public int b;

    public final void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        int i = this.a;
        rect.top = i / 2;
        int childLayoutPosition = recyclerView.getChildLayoutPosition(view);
        int childCount = recyclerView.getChildCount();
        int i2 = this.b;
        if (childLayoutPosition < i2) {
            rect.top = 0;
        }
        if (childCount - childLayoutPosition <= i2) {
            rect.bottom = 5;
        }
        if (i2 != Integer.MAX_VALUE) {
            float f = (((float) ((i2 - 1) * i)) * 1.0f) / ((float) i2);
            float f2 = (((float) i) - f) * ((float) (childLayoutPosition % i2));
            rect.left = (int) f2;
            rect.right = (int) (f - f2);
        }
    }
}
