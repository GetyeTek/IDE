package com.huawei.module_history.view;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.module_history.RecordActivity;
import java.util.ArrayList;

public class TransactionDateDecoration extends RecyclerView.ItemDecoration {
    public ArrayList a;
    public RecordActivity.a b;
    public TextPaint c;
    public Paint d;
    public int e;
    public int f;
    public int g;

    public TransactionDateDecoration() {
        throw null;
    }

    public final void getItemOffsets(@NonNull Rect rect, @NonNull View view, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.State state) {
        TransactionDateDecoration.super.getItemOffsets(rect, view, recyclerView, state);
        int childAdapterPosition = recyclerView.getChildAdapterPosition(view);
        ArrayList arrayList = this.a;
        if (childAdapterPosition < arrayList.size() && !this.b.b(childAdapterPosition).equals("-1")) {
            if (childAdapterPosition != 0) {
                boolean z = true;
                if (childAdapterPosition != 0) {
                    RecordActivity.a aVar = this.b;
                    z = true ^ TextUtils.equals(aVar.b(childAdapterPosition - 1), aVar.b(childAdapterPosition));
                }
                if (!z) {
                    rect.top = 0;
                    return;
                }
            }
            rect.top = this.e;
            if ("".equals(arrayList.get(childAdapterPosition))) {
                rect.top = 0;
            }
        }
    }

    public final void onDraw(@NonNull Canvas canvas, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.State state) {
        TransactionDateDecoration.super.onDraw(canvas, recyclerView, state);
        int width = recyclerView.getWidth() - recyclerView.getPaddingRight();
        int childCount = recyclerView.getChildCount();
        int paddingLeft = recyclerView.getPaddingLeft();
        int i = 0;
        while (i < childCount) {
            View childAt = recyclerView.getChildAt(i);
            int childAdapterPosition = recyclerView.getChildAdapterPosition(childAt);
            if (childAdapterPosition < this.a.size()) {
                RecordActivity.a aVar = this.b;
                if (!aVar.b(childAdapterPosition).equals("-1")) {
                    boolean equals = "".equals(aVar.a(childAdapterPosition));
                    Paint paint = this.d;
                    if (equals) {
                        Canvas canvas2 = canvas;
                        canvas2.drawRect((float) paddingLeft, (float) childAt.getTop(), (float) width, (float) childAt.getTop(), paint);
                        return;
                    }
                    if (childAdapterPosition != 0) {
                        boolean z = true;
                        if (childAdapterPosition != 0) {
                            RecordActivity.a aVar2 = this.b;
                            z = true ^ TextUtils.equals(aVar2.b(childAdapterPosition - 1), aVar2.b(childAdapterPosition));
                        }
                        if (!z) {
                            i++;
                        }
                    }
                    int top = childAt.getTop();
                    int i2 = this.e;
                    Canvas canvas3 = canvas;
                    canvas3.drawRect((float) paddingLeft, ((float) (top - i2)) - ((float) i2), (float) width, (float) childAt.getTop(), paint);
                    i++;
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    public final void onDrawOver(@NonNull Canvas canvas, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.State state) {
        RecyclerView recyclerView2 = recyclerView;
        TransactionDateDecoration.super.onDrawOver(canvas, recyclerView, state);
        int itemCount = state.getItemCount();
        int childCount = recyclerView.getChildCount();
        int paddingLeft = recyclerView.getPaddingLeft();
        int width = recyclerView.getWidth() - recyclerView.getPaddingRight();
        String str = "-1";
        for (int i = 0; i < childCount; i++) {
            View childAt = recyclerView2.getChildAt(i);
            int childAdapterPosition = recyclerView2.getChildAdapterPosition(childAt);
            if (childAdapterPosition >= this.a.size()) {
                Canvas canvas2 = canvas;
            } else {
                RecordActivity.a aVar = this.b;
                String b2 = aVar.b(childAdapterPosition);
                if (!b2.equals("-1") && !b2.equals(str)) {
                    String a2 = aVar.a(childAdapterPosition);
                    if (!TextUtils.isEmpty(a2)) {
                        int bottom = childAt.getBottom();
                        int top = childAt.getTop();
                        int i2 = this.e;
                        float max = (float) Math.max(i2, top);
                        int i3 = childAdapterPosition + 1;
                        if (i3 < itemCount && !aVar.b(i3).equals(b2)) {
                            float f2 = (float) bottom;
                            if (f2 < max) {
                                max = f2;
                            }
                        }
                        canvas.drawRect((float) paddingLeft, max - ((float) i2), (float) width, max, this.d);
                        canvas.drawText(a2, (float) (this.g + paddingLeft), max - ((float) this.f), this.c);
                        str = b2;
                    }
                }
                Canvas canvas3 = canvas;
                str = b2;
            }
        }
    }
}
