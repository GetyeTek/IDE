package com.huawei.module_profile;

import E0.c;
import J2.a;
import W2.n;
import Yb.j;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.module_profile.databinding.ActivityProfileBinding;
import i3.d;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.ThreadMode;

@a
@Route(path = "/profileModule/profile")
public class ProfileActivity extends BaseTitleActivity {
    public ActivityProfileBinding i;
    public ProfilesAdapter j;
    public final ArrayList k = new ArrayList();

    public final void D0() {
    }

    public final void G0() {
        ProfileActivity.super.G0();
        O0(R$string.profile_my_profile);
        ArrayList arrayList = this.k;
        arrayList.clear();
        if (c.b == null) {
            n.b("");
            c.b = (List) n.d(c.e("consumer_profiles"));
        }
        List list = c.b;
        if (list != null) {
            arrayList.addAll(list);
        }
        if (arrayList != null) {
            BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_profiles, arrayList);
            this.j = baseQuickAdapter;
            this.i.b.setAdapter(baseQuickAdapter);
            this.j.setOnItemClickListener(new J7.c(this));
        }
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_profile.ProfileActivity, android.app.Activity] */
    public final ViewBinding K0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_profile, (ViewGroup) null, false);
        int i2 = R$id.profiles_List;
        RecyclerView findChildViewById = ViewBindings.findChildViewById(inflate, i2);
        if (findChildViewById != null) {
            ActivityProfileBinding activityProfileBinding = new ActivityProfileBinding(inflate, findChildViewById);
            this.i = activityProfileBinding;
            return activityProfileBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }

    @j(sticky = true, threadMode = ThreadMode.MAIN)
    public void onEvent(d dVar) {
    }

    @j(sticky = true, threadMode = ThreadMode.MAIN)
    public void onEvent(i3.c cVar) {
        List a = k3.a.e.a();
        if (a != null) {
            ArrayList arrayList = this.k;
            arrayList.clear();
            arrayList.addAll(a);
            this.j.notifyDataSetChanged();
        }
    }
}
