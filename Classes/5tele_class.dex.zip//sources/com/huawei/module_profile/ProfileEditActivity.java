package com.huawei.module_profile;

import J2.a;
import K7.b;
import K7.c;
import W2.n;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.k;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.bean.Profiles;
import com.huawei.digitalpayment.customer.httplib.response.ChangeProfileResp;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;
import com.huawei.module_profile.databinding.ActivityProfileEditBinding;
import java.util.List;

@a
@Route(path = "/profileModule/profileEdit")
public class ProfileEditActivity extends BaseMvpActivity<b> implements c {
    public static final /* synthetic */ int l = 0;
    public ActivityProfileEditBinding j;
    public Profiles k;

    public final void D0() {
    }

    public final void G(String str) {
        this.j.b.a();
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity, com.huawei.module_profile.ProfileEditActivity] */
    public final void G0() {
        ProfileEditActivity.super.G0();
        O0(R$string.profile_my_profile);
        try {
            Intent intent = getIntent();
            if (intent != null) {
                Profiles serializable = intent.getExtras().getSerializable("profiles");
                this.k = serializable;
                if (serializable != null) {
                    this.j.c.setText(serializable.getName());
                    this.j.d.setText(this.k.getValue());
                }
            }
        } catch (Exception unused) {
        }
        this.j.b.setOnClickListener(new A6.a(this, 2));
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.app.Activity, com.huawei.module_profile.ProfileEditActivity] */
    public final ViewBinding K0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_profile_edit, (ViewGroup) null, false);
        int i = R$id.lb_save;
        LoadingButton findChildViewById = ViewBindings.findChildViewById(inflate, i);
        if (findChildViewById != null) {
            i = R$id.tv_name;
            TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
            if (textView != null) {
                i = R$id.tv_value;
                EditText editText = (EditText) ViewBindings.findChildViewById(inflate, i);
                if (editText != null) {
                    ActivityProfileEditBinding activityProfileEditBinding = new ActivityProfileEditBinding((LinearLayout) inflate, findChildViewById, textView, editText);
                    this.j = activityProfileEditBinding;
                    return activityProfileEditBinding;
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, android.app.Activity, com.huawei.module_profile.ProfileEditActivity] */
    public final void M(ChangeProfileResp changeProfileResp) {
        if (changeProfileResp != null) {
            ChangeProfileResp.CustomerInfoBean customerInfo = changeProfileResp.getCustomerInfo();
            if (customerInfo != null) {
                E0.c.i(customerInfo.getCustomer());
                k3.a aVar = k3.a.e;
                List customerProfiles = customerInfo.getCustomerProfiles();
                if (customerProfiles != null) {
                    n.b("").g(k3.a.c("consumer_profiles"), k.d(customerProfiles), false);
                }
                aVar.c = customerProfiles;
                Yb.c.b().h(new Object());
            }
            V1.k.b(1, getString(R$string.profile_success));
            finish();
        }
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        this.j.b.b();
    }
}
