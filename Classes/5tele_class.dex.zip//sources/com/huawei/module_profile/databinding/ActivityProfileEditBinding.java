package com.huawei.module_profile.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityProfileEditBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final TextView c;
    @NonNull
    public final EditText d;

    public ActivityProfileEditBinding(@NonNull LinearLayout linearLayout, @NonNull LoadingButton loadingButton, @NonNull TextView textView, @NonNull EditText editText) {
        this.a = linearLayout;
        this.b = loadingButton;
        this.c = textView;
        this.d = editText;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
