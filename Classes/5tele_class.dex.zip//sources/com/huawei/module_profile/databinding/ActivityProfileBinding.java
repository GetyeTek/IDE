package com.huawei.module_profile.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;

public final class ActivityProfileBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final RecyclerView b;

    public ActivityProfileBinding(@NonNull ConstraintLayout constraintLayout, @NonNull RecyclerView recyclerView) {
        this.a = constraintLayout;
        this.b = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
