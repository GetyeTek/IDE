package com.huawei.module_profile.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityPhotoProfileBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final LoadingButton c;
    @NonNull
    public final RoundImageView d;

    public ActivityPhotoProfileBinding(@NonNull LinearLayout linearLayout, @NonNull LoadingButton loadingButton, @NonNull LoadingButton loadingButton2, @NonNull RoundImageView roundImageView) {
        this.a = linearLayout;
        this.b = loadingButton;
        this.c = loadingButton2;
        this.d = roundImageView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
