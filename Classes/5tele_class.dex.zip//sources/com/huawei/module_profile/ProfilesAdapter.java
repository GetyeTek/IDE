package com.huawei.module_profile;

import E0.c;
import android.content.Context;
import android.text.TextUtils;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.httplib.bean.Profiles;
import com.huawei.digitalpayment.customer.httplib.pic.GlideApp;
import com.huawei.digitalpayment.customer.httplib.pic.GlideRequests;
import com.huawei.image.glide.Base64Mode;
import k3.a;
import x.l;

public class ProfilesAdapter extends BaseQuickAdapter<Profiles, BaseViewHolder> {
    public ImageView a;

    public ProfilesAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        Profiles profiles = (Profiles) obj;
        baseViewHolder.setText(R$id.profiles_name, profiles.getName());
        baseViewHolder.itemView.setTag(profiles.getType());
        if ("picture".equals(profiles.getType())) {
            baseViewHolder.setVisible(R$id.profiles_value, false);
            int i = R$id.profiles_img;
            baseViewHolder.setVisible(i, true);
            ImageView imageView = (ImageView) baseViewHolder.getView(i);
            this.a = imageView;
            Context context = imageView.getContext();
            ImageView imageView2 = this.a;
            Customer f = c.f();
            if (f != null) {
                String str = a.e.b;
                GlideRequests with = GlideApp.with(context);
                if (str == null) {
                    str = f.getAvatar();
                }
                with.load(Base64Mode.getConsumerMode(str)).optionalCircleCrop().diskCacheStrategy(l.b).placeholder(R$mipmap.icon_home_drawer_head).into(imageView2);
            }
        } else {
            int i2 = R$id.profiles_value;
            baseViewHolder.setVisible(i2, true);
            baseViewHolder.setGone(R$id.profiles_img, false);
            baseViewHolder.setText(i2, profiles.getValue());
        }
        String editEnable = profiles.getEditEnable();
        if (TextUtils.isEmpty(editEnable) || !Boolean.parseBoolean(editEnable)) {
            baseViewHolder.setVisible(R$id.iv_edit_more, false);
            baseViewHolder.itemView.setClickable(false);
            return;
        }
        baseViewHolder.setVisible(R$id.iv_edit_more, true);
        baseViewHolder.itemView.setClickable(true);
    }
}
