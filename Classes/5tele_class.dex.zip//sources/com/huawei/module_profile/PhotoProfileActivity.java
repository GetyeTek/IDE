package com.huawei.module_profile;

import H3.c;
import J7.d;
import J7.e;
import J7.f;
import T1.b;
import V1.h;
import V1.k;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.httplib.pic.Base64ConvertIml;
import com.huawei.digitalpayment.customer.httplib.response.UploadResp;
import com.huawei.image.glide.Base64Mode;
import com.huawei.module_profile.databinding.ActivityPhotoProfileBinding;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

@Route(path = "/profileModule/photoProfile")
public class PhotoProfileActivity extends BaseMvpActivity<e> implements f {
    public static final /* synthetic */ int m = 0;
    public ActivityPhotoProfileBinding j;
    public String k;
    public LoadingDialog l;

    public class a implements R1.a<Uri> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            k.b(1, baseException.getResponseDesc());
            if (baseException.getCode() == 5 || baseException.getCode() == 6) {
                com.blankj.utilcode.util.e.b();
            }
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            String str;
            Uri uri = (Uri) obj;
            BaseMvpActivity baseMvpActivity = PhotoProfileActivity.this;
            InputStream inputStream = null;
            try {
                InputStream openInputStream = baseMvpActivity.getContentResolver().openInputStream(uri);
                str = L7.a.a(BitmapFactory.decodeStream(openInputStream));
                if (openInputStream != null) {
                    try {
                        openInputStream.close();
                    } catch (IOException e) {
                        e.getMessage();
                        h.b();
                    }
                }
            } catch (FileNotFoundException e2) {
                e2.getMessage();
                h.b();
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e3) {
                        e3.getMessage();
                        h.b();
                    }
                }
                str = "";
            } catch (Throwable th) {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e4) {
                        e4.getMessage();
                        h.b();
                    }
                }
                throw th;
            }
            baseMvpActivity.k = str;
            if (!TextUtils.isEmpty(str)) {
                e eVar = baseMvpActivity.i;
                String str2 = baseMvpActivity.k;
                eVar.getClass();
                HashMap hashMap = new HashMap();
                hashMap.put("fileContent", str2);
                hashMap.put("name", "crop_photo.jpg");
                eVar.a(c.e().u(hashMap), new d(eVar, (P2.a) eVar.a));
                return;
            }
            k.b(1, "photo encode to base64 failed");
        }
    }

    public final void D0() {
        a aVar = new a();
        b.a aVar2 = new b.a();
        aVar2.d = 400;
        aVar2.e = 400;
        b bVar = new b(aVar2);
        this.j.c.setOnClickListener(new J7.a(this, bVar, aVar));
        this.j.b.setOnClickListener(new J7.b(this, bVar, aVar));
        Customer f = E0.c.f();
        f.getAvatar();
        h.b();
        Base64Mode consumerMode = Base64Mode.getConsumerMode(f.getAvatar());
        RoundImageView roundImageView = this.j.d;
        int i = R$mipmap.icon_big_head;
        y5.b.a(consumerMode, roundImageView, i, i);
    }

    public final void G(String str) {
        LoadingDialog loadingDialog = this.l;
        if (loadingDialog != null && loadingDialog.a) {
            loadingDialog.dismiss();
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.module_profile.PhotoProfileActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        PhotoProfileActivity.super.G0();
        N0(getString(R$string.designstandard_set_photo));
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.module_profile.PhotoProfileActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.module_profile.R$id.btn_take_photo;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0020, code lost:
        r1 = com.huawei.module_profile.R$id.img_profile_photo;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r5 = this;
            android.view.LayoutInflater r0 = r5.getLayoutInflater()
            int r1 = com.huawei.module_profile.R$layout.activity_photo_profile
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_profile.R$id.btn_choose_album
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r2 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r2
            if (r2 == 0) goto L_0x0034
            int r1 = com.huawei.module_profile.R$id.btn_take_photo
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r3 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r3
            if (r3 == 0) goto L_0x0034
            int r1 = com.huawei.module_profile.R$id.img_profile_photo
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundImageView r4 = (com.huawei.common.widget.round.RoundImageView) r4
            if (r4 == 0) goto L_0x0034
            com.huawei.module_profile.databinding.ActivityPhotoProfileBinding r1 = new com.huawei.module_profile.databinding.ActivityPhotoProfileBinding
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r1.<init>(r0, r2, r3, r4)
            r5.j = r1
            return r1
        L_0x0034:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_profile.PhotoProfileActivity.K0():androidx.viewbinding.ViewBinding");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.module_profile.PhotoProfileActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity] */
    public final void O(UploadResp uploadResp) {
        if (uploadResp != null) {
            k3.a.e.b = uploadResp.getDocId();
            Base64ConvertIml.addBase64ContentCache(Base64Mode.getConsumerMode(uploadResp.getDocId()), this.k);
            String docId = uploadResp.getDocId();
            Customer f = E0.c.f();
            f.setAvatar(docId);
            E0.c.i(f);
            Base64Mode consumerMode = Base64Mode.getConsumerMode(uploadResp.getDocId());
            RoundImageView roundImageView = this.j.d;
            com.bumptech.glide.c.i(roundImageView).load(consumerMode).into(roundImageView);
            F0();
            this.a.a(2);
            k.b(1, getString(R$string.designstandard_upload_success));
        }
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        if (this.l == null) {
            this.l = new LoadingDialog();
        }
        LoadingDialog loadingDialog = this.l;
        if (!loadingDialog.a) {
            loadingDialog.show(getSupportFragmentManager(), "");
        }
    }
}
