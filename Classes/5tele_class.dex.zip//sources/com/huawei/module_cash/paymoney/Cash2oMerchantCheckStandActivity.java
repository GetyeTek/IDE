package com.huawei.module_cash.paymoney;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;

@Route(path = "/cashModule/showmoney")
public class Cash2oMerchantCheckStandActivity extends CheckStandActivity<Cashin2MerchantViewModel> {
    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.paymoney.Cash2oMerchantCheckStandActivity, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void D0() {
        super.D0();
        getIntent().getStringExtra("amount");
        String stringExtra = getIntent().getStringExtra("notes");
        String stringExtra2 = getIntent().getStringExtra("tradeType");
        getIntent().getStringExtra("shortCode");
        getIntent().getStringExtra("operatorId");
        Cashin2MerchantViewModel cashin2MerchantViewModel = (Cashin2MerchantViewModel) this.b;
        cashin2MerchantViewModel.w.setValue(stringExtra);
        cashin2MerchantViewModel.v = stringExtra2;
    }
}
