package com.huawei.module_cash.paymoney;

import E7.a;
import S2.b;
import a7.C0003a;
import a7.C0004b;
import android.util.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import java.util.HashMap;

public class Cashin2MerchantViewModel extends CheckStandViewModel {
    public final C0004b u = new C0004b();
    public String v;
    public final MutableLiveData<String> w = new MutableLiveData<>();

    public final LiveData<b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        HashMap hashMap = new HashMap();
        hashMap.put("tradeType", this.v);
        hashMap.put("prepayId", this.s);
        if (fundsSourceInfoDisplay != null) {
            hashMap.put("accountType", fundsSourceInfoDisplay.getAccountType());
            hashMap.put("fundsSource", fundsSourceInfoDisplay.getFundsSource());
        }
        C0004b bVar = this.u;
        bVar.getClass();
        return new a(bVar, hashMap, 1).a;
    }

    public final LiveData<b<TransferResp>> i(String str) {
        ArrayMap arrayMap = new ArrayMap();
        arrayMap.put("initiatorPin", L3.a.g(str));
        arrayMap.put("pinVersion", L3.a.b.getPinKeyVersion());
        arrayMap.put("prepayId", this.s);
        C0004b bVar = this.u;
        bVar.getClass();
        return new C0003a(bVar, arrayMap).a;
    }
}
