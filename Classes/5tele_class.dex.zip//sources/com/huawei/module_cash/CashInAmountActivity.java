package com.huawei.module_cash;

import A8.c;
import R9.h;
import V1.k;
import W2.g;
import Z6.e;
import android.text.TextUtils;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.GridLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.AmountConfigBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.module_cash.databinding.ActivityCashInAmountBinding;
import com.huawei.module_cash.view.SpaceItemDecoration;
import java.util.ArrayList;
import java.util.Arrays;

@Route(path = "/cashModule/cashInAmount")
public class CashInAmountActivity extends BaseTitleActivity implements e {
    public static final /* synthetic */ int l = 0;
    public ActivityCashInAmountBinding i;
    public AmountAdapter j;
    public ArrayList<com.huawei.module_cash.bean.a> k;

    public class a implements OnItemClickListener {
        public a() {
        }

        public final void onItemClick(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter, @NonNull View view, int i) {
            CashInAmountActivity cashInAmountActivity = CashInAmountActivity.this;
            AmountAdapter amountAdapter = cashInAmountActivity.j;
            if (amountAdapter.c != i) {
                amountAdapter.c = i;
                amountAdapter.notifyDataSetChanged();
                cashInAmountActivity.i.b.setText("");
            }
        }
    }

    public final void D0() {
    }

    public final void G(String str) {
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.module_cash.CashInAmountActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        CashInAmountActivity.super.G0();
        N0(getString(R$string.cashincashout_cash_in));
        U0();
        this.i.b.addTextChangedListener(new b(this));
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.CashInAmountActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.module_cash.R$id.other_amount;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x002a, code lost:
        r1 = com.huawei.module_cash.R$id.rv_amount_list;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r4 = this;
            android.view.LayoutInflater r0 = r4.getLayoutInflater()
            int r1 = com.huawei.module_cash.R$layout.activity_cash_in_amount
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_cash.R$id.create_qr_code
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r2 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r2
            if (r2 == 0) goto L_0x003e
            int r1 = com.huawei.module_cash.R$id.other_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r2 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r2
            if (r2 == 0) goto L_0x003e
            int r1 = com.huawei.module_cash.R$id.request_amount
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x003e
            int r1 = com.huawei.module_cash.R$id.rv_amount_list
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            if (r3 == 0) goto L_0x003e
            com.huawei.module_cash.databinding.ActivityCashInAmountBinding r1 = new com.huawei.module_cash.databinding.ActivityCashInAmountBinding
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1.<init>(r0, r2, r3)
            r4.i = r1
            return r1
        L_0x003e:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.CashInAmountActivity.K0():androidx.viewbinding.ViewBinding");
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [P2.a, android.content.Context, com.huawei.module_cash.CashInAmountActivity] */
    public final void U0() {
        AmountConfigBean cashInConfig = BasicConfig.getInstance().getCashInConfig();
        if (cashInConfig != null) {
            this.i.b.setCurrency(cashInConfig.getUnit());
            this.k = new ArrayList<>();
            for (int i2 = 1; i2 < cashInConfig.getPriceList().size(); i2++) {
                com.huawei.module_cash.bean.a aVar = new com.huawei.module_cash.bean.a();
                aVar.a = ((AmountConfigBean.Price) cashInConfig.getPriceList().get(i2)).getAmount();
                aVar.b = cashInConfig.getUnit();
                aVar.c = ((AmountConfigBean.Price) cashInConfig.getPriceList().get(i2)).getDiscount();
                this.k.add(aVar);
            }
            this.i.c.setLayoutManager(new GridLayoutManager(this, 3));
            if (this.j == null) {
                this.j = new AmountAdapter(0, this.k);
            }
            this.i.c.setAdapter(this.j);
            this.i.c.addItemDecoration(new SpaceItemDecoration(h.a(this, 30.0f)));
            this.j.setOnItemClickListener(new a());
            return;
        }
        new c(this).b(Arrays.asList(new String[]{"cashInConfig"}));
    }

    public final void V(String str) {
    }

    /* JADX WARNING: type inference failed for: r1v6, types: [android.content.DialogInterface$OnClickListener, java.lang.Object] */
    public void createQrCode(View view) {
        com.huawei.module_cash.bean.a aVar;
        String obj = this.i.b.getText().toString();
        if (TextUtils.isEmpty(obj)) {
            AmountAdapter amountAdapter = this.j;
            int i2 = amountAdapter.c;
            com.huawei.module_cash.bean.a aVar2 = null;
            if (i2 == -1) {
                aVar = null;
            } else {
                aVar = amountAdapter.b.get(i2);
            }
            if (aVar != null) {
                AmountAdapter amountAdapter2 = this.j;
                int i3 = amountAdapter2.c;
                if (i3 != -1) {
                    aVar2 = amountAdapter2.b.get(i3);
                }
                obj = aVar2.a;
            }
        }
        if (!TextUtils.isEmpty(obj) && Double.parseDouble(obj) <= 0.0d) {
            k.b(1, getString(R$string.cashincashout_incorrect_amount_format));
        } else if (!g.a(obj)) {
            k.b(1, getString(R$string.cashincashout_incorrect_amount_format));
        } else {
            AmountConfigBean cashInConfig = BasicConfig.getInstance().getCashInConfig();
            if (cashInConfig != null) {
                String minAmount = cashInConfig.getMinAmount();
                if (!TextUtils.isEmpty(minAmount) && Double.parseDouble(obj) < Double.parseDouble(minAmount)) {
                    new AlertDialog.Builder(this).setMessage(String.format(getString(R$string.cashincashout_failed_to_create_the_qr_code), new Object[]{minAmount})).setCancelable(false).setPositiveButton(getString(R$string.cashincashout_confirm), new Object()).create().show();
                    return;
                }
            }
            n.a.b().getClass();
            n.a.a("/cashModule/cashInQrCode").withString("amount", obj).navigation();
        }
    }

    public final void p(BasicConfigResp.JsonContent jsonContent) {
        AmountConfigBean cashInConfig;
        if (jsonContent != null && (cashInConfig = jsonContent.getCashInConfig()) != null) {
            BasicConfig.getInstance().setCashInConfig(cashInConfig);
            U0();
        }
    }

    public final void v(BaseResp baseResp) {
    }
}
