package com.huawei.module_cash;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

public final class e implements TextWatcher {
    public final /* synthetic */ CashOutAmountActivity a;

    public e(CashOutAmountActivity cashOutAmountActivity) {
        this.a = cashOutAmountActivity;
    }

    public final void afterTextChanged(Editable editable) {
        if (!TextUtils.isEmpty(editable.toString())) {
            AmountAdapter amountAdapter = this.a.k;
            amountAdapter.c = -1;
            amountAdapter.notifyDataSetChanged();
        }
    }

    public final void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }
}
