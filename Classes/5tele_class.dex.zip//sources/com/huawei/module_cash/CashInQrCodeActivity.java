package com.huawei.module_cash;

import E0.c;
import R9.h;
import W2.j;
import W2.r;
import Z6.m;
import Z6.n;
import android.graphics.Bitmap;
import android.os.Handler;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import b7.C0005a;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.AmountConfigBean;
import com.huawei.digitalpayment.customer.httplib.response.GetQrCodeResp;
import com.huawei.module_cash.databinding.ActivityCashInQrcodeBinding;
import java.util.List;

@Route(path = "/cashModule/cashInQrCode")
public class CashInQrCodeActivity extends BaseMvpActivity<m> implements n {
    public static final /* synthetic */ int o = 0;
    @Autowired(name = "amount")
    String amount;
    public ActivityCashInQrcodeBinding j;
    public List<GetQrCodeResp.QrCode> k;
    public String l;
    public Handler m = new Handler();
    public final a n = new a();

    public class a implements Runnable {
        public a() {
        }

        public final void run() {
            CashInQrCodeActivity cashInQrCodeActivity = CashInQrCodeActivity.this;
            try {
                int i = CashInQrCodeActivity.o;
                cashInQrCodeActivity.V0();
                if (!"0".equals(cashInQrCodeActivity.l)) {
                    cashInQrCodeActivity.m.postDelayed(this, Long.parseLong(cashInQrCodeActivity.l) - r.d().getTime());
                }
            } catch (Exception unused) {
            }
        }
    }

    public final void D0() {
        AmountConfigBean cashInConfig = BasicConfig.getInstance().getCashInConfig();
        if (cashInConfig != null) {
            this.j.c.setText(C0005a.b(C0005a.a(this.amount), cashInConfig.getUnitType(), cashInConfig.getUnit()));
        } else {
            this.j.c.setText(C0005a.b(C0005a.a(this.amount), "", ""));
        }
        this.i.b(this.amount);
    }

    public final void G(String str) {
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, com.huawei.module_cash.CashInQrCodeActivity] */
    public final void G0() {
        CashInQrCodeActivity.super.G0();
        N0(getString(R$string.cashincashout_cash_in));
        Customer f = c.f();
        if (f != null) {
            this.j.d.setText(f.getNickName());
            this.j.e.setText(f.getMsisdn());
        }
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [android.app.Activity, com.huawei.module_cash.CashInQrCodeActivity] */
    public final ViewBinding K0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_cash_in_qrcode, (ViewGroup) null, false);
        int i = R$id.amount_qr_code;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i);
        if (imageView != null) {
            i = R$id.amount_qr_code_tips;
            if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                i = R$id.amount_value;
                TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
                if (textView != null) {
                    i = R$id.customer_name;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(inflate, i);
                    if (textView2 != null) {
                        i = R$id.customer_name_label;
                        if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                            i = R$id.customer_phone_number;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(inflate, i);
                            if (textView3 != null) {
                                i = R$id.customer_phone_number_label;
                                if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                    i = R$id.divider_line;
                                    if (ViewBindings.findChildViewById(inflate, i) != null) {
                                        ActivityCashInQrcodeBinding activityCashInQrcodeBinding = new ActivityCashInQrcodeBinding(inflate, imageView, textView, textView2, textView3);
                                        this.j = activityCashInQrcodeBinding;
                                        return activityCashInQrcodeBinding;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.module_cash.CashInQrCodeActivity] */
    public final void V0() {
        boolean z = true;
        while (z) {
            List<GetQrCodeResp.QrCode> list = this.k;
            if (list == null || list.size() <= 0) {
                this.l = "0";
                this.i.b(this.amount);
            } else if (Long.parseLong(this.k.get(0).getExpiredTime()) > r.d().getTime()) {
                Bitmap c = j.c(h.a(this, 213.0f), h.a(this, 213.0f), this.k.get(0).getQrCode());
                this.l = this.k.get(0).getExpiredTime();
                this.j.b.setImageBitmap(c);
                this.k.remove(0);
            } else {
                this.k.remove(0);
            }
            z = false;
        }
    }

    public final void d(String str, List<GetQrCodeResp.QrCode> list) {
        if (list != null) {
            this.k = list;
            this.amount = str;
            V0();
            Handler handler = this.m;
            a aVar = this.n;
            handler.removeCallbacks(aVar);
            this.m.postDelayed(aVar, Long.parseLong(this.l) - r.d().getTime());
        }
    }

    public final void onDestroy() {
        CashInQrCodeActivity.super.onDestroy();
        Handler handler = this.m;
        if (handler != null) {
            handler.removeCallbacks(this.n);
            this.m = null;
        }
    }
}
