package com.huawei.module_cash.deposit.activity;

import I7.e;
import M.g;
import N4.j;
import N4.k;
import V1.h;
import W2.r;
import X6.c;
import X6.d;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.f;
import com.huawei.common.widget.dialog.SetAmountPop;
import com.huawei.digitalpayment.customer.baselib.R;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.httplib.pic.GlideApp;
import com.huawei.digitalpayment.customer.httplib.response.GetQrCodeResp;
import com.huawei.image.glide.Base64Mode;
import com.huawei.module_cash.R$color;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.databinding.ActivityDepositCashAgentBinding;
import com.huawei.module_cash.deposit.viewmodel.DepositCashAgentViewModel;
import java.util.List;

@Route(path = "/cashModule/depositCashAgent")
public class DepositCashAgentActivity extends BaseTitleActivity {
    public static final /* synthetic */ int q = 0;
    public ActivityDepositCashAgentBinding i;
    public SetAmountPop j;
    public List<GetQrCodeResp.QrCode> k;
    public String l;
    public Bitmap m;
    public final a n = new a();
    public Bitmap o;
    public DepositCashAgentViewModel p;

    public class a implements Runnable {
        public a() {
        }

        public final void run() {
            int i = DepositCashAgentActivity.q;
            DepositCashAgentActivity depositCashAgentActivity = DepositCashAgentActivity.this;
            depositCashAgentActivity.U0();
            if (!"0".equals(depositCashAgentActivity.l)) {
                long parseLong = Long.parseLong(depositCashAgentActivity.l) - r.d().getTime();
                h.b();
                A.a.postDelayed(this, parseLong);
            }
        }
    }

    public final void D0() {
        DepositCashAgentViewModel depositCashAgentViewModel = new ViewModelProvider(this).get(DepositCashAgentViewModel.class);
        this.p = depositCashAgentViewModel;
        depositCashAgentViewModel.a.observe(this, new j(this, 1));
        this.p.b.observe(this, new k(this, 1));
        this.p.a();
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.module_cash.deposit.activity.DepositCashAgentActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    @SuppressLint({"SetTextI18n"})
    public final void G0() {
        DepositCashAgentActivity.super.G0();
        N0(getString(R$string.checkout_deposit_cash));
        int i2 = R$color.colorPrimary;
        S0(i2);
        int i3 = R$color.standard_white;
        P0(i3);
        R0(i3);
        f.e(this, ContextCompat.getColor(this, i2), false);
        f.f(this, false);
        this.i.i.setOnClickListener(new e(this, 1));
        this.i.h.setOnClickListener(new c(this, 0));
        Customer f = E0.c.f();
        if (f != null) {
            TextView textView = this.i.g;
            textView.setText(getString(R$string.checkout_phone_number) + "+" + f.getMsisdn());
            TextView textView2 = this.i.f;
            textView2.setText(getString(R$string.checkout_name) + "：" + f.getNickName());
        }
        this.i.e.setText(k3.a.e.b());
        g gVar = new g();
        int i4 = R.mipmap.icon_drawer_head;
        GlideApp.with(this).asBitmap().load(Base64Mode.getConsumerMode(E0.c.f().getAvatar())).apply(gVar.error(i4).placeholder(i4).circleCrop()).into(new d(this));
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.deposit.activity.DepositCashAgentActivity, android.app.Activity] */
    public final ViewBinding K0() {
        ActivityDepositCashAgentBinding inflate = DataBindingUtil.inflate(getLayoutInflater(), R$layout.activity_deposit_cash_agent, (ViewGroup) null, false);
        this.i = inflate;
        return inflate;
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [android.content.Context, com.huawei.module_cash.deposit.activity.DepositCashAgentActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity] */
    public final void U0() {
        boolean z = true;
        while (z) {
            List<GetQrCodeResp.QrCode> list = this.k;
            if (list == null || list.size() <= 0) {
                this.l = "0";
                this.p.a();
            } else if (Long.parseLong(this.k.get(0).getRefreshTime()) > r.d().getTime()) {
                this.o = W2.j.c(R9.h.a(this, 213.0f), R9.h.a(this, 213.0f), this.k.get(0).getQrCode());
                this.l = this.k.get(0).getRefreshTime();
                if (this.m == null) {
                    this.m = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_drawer_head);
                }
                Bitmap a2 = W2.j.a(this.o, W2.j.b(this.m));
                this.o = a2;
                this.i.b.setImageBitmap(a2);
                this.k.remove(0);
            } else {
                this.k.remove(0);
            }
            z = false;
        }
    }

    public final void onBackPressed() {
        SetAmountPop setAmountPop = this.j;
        if (setAmountPop == null || !setAmountPop.isShowing()) {
            DepositCashAgentActivity.super.onBackPressed();
            return;
        }
        SetAmountPop setAmountPop2 = this.j;
        if (setAmountPop2.isShowing()) {
            setAmountPop2.dismiss();
        }
    }

    public final void onDestroy() {
        DepositCashAgentActivity.super.onDestroy();
        A.a.removeCallbacks(this.n);
    }
}
