package com.huawei.module_cash.deposit.viewmodel;

import S2.b;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public class ApplyDepositVoucherViewModel extends ViewModel {
    public final MutableLiveData<b<BaseResp>> a = new MutableLiveData<>();
}
