package com.huawei.module_cash.deposit.repository;

import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.http.b;

public class ApplyDepositVoucherRepository extends b<BaseResp, BaseResp> {
    public final String getApiPath() {
        return "v1/applyDepositVoucher";
    }
}
