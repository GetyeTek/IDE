package com.huawei.module_cash.deposit.viewmodel;

import S2.b;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.response.GetQrCodeResp;

public class DepositCashAgentViewModel extends ViewModel {
    public final MutableLiveData<String> a = new MutableLiveData<>();
    public final MutableLiveData<b<GetQrCodeResp>> b = new MutableLiveData<>();

    public final void a() {
        this.b.setValue(b.c((Object) null));
        com.huawei.http.b bVar = new com.huawei.http.b();
        bVar.addParams("amount", (String) this.a.getValue());
        bVar.addParams("entrance", "51");
        bVar.addParams("notes", "");
        bVar.sendRequest(new Y6.b(this, 0));
    }
}
