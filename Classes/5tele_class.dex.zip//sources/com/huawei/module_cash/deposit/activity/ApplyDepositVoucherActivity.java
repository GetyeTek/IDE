package com.huawei.module_cash.deposit.activity;

import D1.q;
import N4.d;
import S2.b;
import android.content.Intent;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;
import com.huawei.module_cash.R$id;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.databinding.ActivityApplyDepositVoucherBinding;
import com.huawei.module_cash.deposit.viewmodel.ApplyDepositVoucherViewModel;
import java.nio.charset.StandardCharsets;
import w5.a;

@Route(path = "/cashModule/applyDepositVoucher")
public class ApplyDepositVoucherActivity extends BaseTitleActivity {
    public static final /* synthetic */ int k = 0;
    public ActivityApplyDepositVoucherBinding i;
    public ApplyDepositVoucherViewModel j;

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_cash.deposit.activity.ApplyDepositVoucherActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        ApplyDepositVoucherActivity.super.G0();
        N0(getString(R$string.apply_deposit_via_voucher));
        this.i.b.setOnClickListener(new q(this, 2));
        a.a("Apply_deposit_V1");
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.deposit.activity.ApplyDepositVoucherActivity, android.app.Activity] */
    public final ViewBinding K0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_apply_deposit_voucher, (ViewGroup) null, false);
        int i2 = R$id.btn_next;
        LoadingButton findChildViewById = ViewBindings.findChildViewById(inflate, i2);
        if (findChildViewById != null) {
            i2 = R$id.iv_apply_deposit_voucher;
            if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                i2 = R$id.tv_apply_deposit_voucher;
                if (((TextView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                    ActivityApplyDepositVoucherBinding activityApplyDepositVoucherBinding = new ActivityApplyDepositVoucherBinding(inflate, findChildViewById);
                    this.i = activityApplyDepositVoucherBinding;
                    return activityApplyDepositVoucherBinding;
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        ApplyDepositVoucherActivity.super.onActivityResult(i2, i3, intent);
        if (intent != null && i2 == 1000 && i3 == -1) {
            byte[] byteArrayExtra = intent.getByteArrayExtra("pin");
            if (this.j == null) {
                ApplyDepositVoucherViewModel applyDepositVoucherViewModel = new ViewModelProvider(this).get(ApplyDepositVoucherViewModel.class);
                this.j = applyDepositVoucherViewModel;
                applyDepositVoucherViewModel.a.observe(this, new d(this, 1));
            }
            ApplyDepositVoucherViewModel applyDepositVoucherViewModel2 = this.j;
            String g = L3.a.g(new String(byteArrayExtra, StandardCharsets.UTF_8));
            applyDepositVoucherViewModel2.a.setValue(b.c((Object) null));
            com.huawei.http.b bVar = new com.huawei.http.b();
            bVar.addParams("initiatorPin", g);
            bVar.addParams("pinVersion", L3.a.b.getPinKeyVersion());
            bVar.sendRequest(new Y6.a(applyDepositVoucherViewModel2, 0));
        }
    }
}
