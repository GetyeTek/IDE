package com.huawei.module_cash.deposit.repository;

import com.huawei.digitalpayment.customer.httplib.response.GetQrCodeResp;
import com.huawei.http.b;

public class DepositCashRepository extends b<GetQrCodeResp, GetQrCodeResp> {
    public final String getApiPath() {
        return "v1/getQrCodeList";
    }
}
