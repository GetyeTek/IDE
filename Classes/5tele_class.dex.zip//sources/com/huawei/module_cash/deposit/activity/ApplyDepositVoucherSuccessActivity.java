package com.huawei.module_cash.deposit.activity;

import V7.e;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.databinding.ActivityApplyDepositVoucherSuccessBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;

@Route(path = "/cashModule/applyDepositVoucherSuccess")
public class ApplyDepositVoucherSuccessActivity extends DataBindingActivity<ActivityApplyDepositVoucherSuccessBinding, ViewModel> {
    public static final /* synthetic */ int d = 0;

    public final int C0() {
        return R$layout.activity_apply_deposit_voucher_success;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [android.view.View$OnClickListener, java.lang.Object] */
    public final void onCreate(@Nullable Bundle bundle) {
        ApplyDepositVoucherSuccessActivity.super.onCreate(bundle);
        f.e(this, -1, false);
        this.b.a.setOnClickListener(new Object());
        e.a(this, getIntent().getStringExtra("title"), R.layout.common_toolbar);
        this.b.c.setText(getIntent().getStringExtra("content"));
    }
}
