package com.huawei.module_cash.deposit.activity;

import G5.g;
import G5.i;
import X6.b;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.module_cash.R$id;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.R$mipmap;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.databinding.ActivityDepositCashBinding;
import com.huawei.module_checkout.databinding.ItemDepositCashBinding;

@Route(path = "/cashModule/depositCash")
public class DepositCashActivity extends BaseTitleActivity {
    public static final /* synthetic */ int j = 0;
    public ActivityDepositCashBinding i;

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, com.huawei.module_cash.deposit.activity.DepositCashActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        DepositCashActivity.super.G0();
        N0(getString(R$string.designstandard_deposit_cash));
        this.i.b.b.setImageResource(R$mipmap.checkout_ic_agent);
        this.i.b.d.setText(R$string.cash_in_via_agent_scan_qr);
        this.i.b.c.setText("");
        this.i.b.c.setVisibility(8);
        ItemDepositCashBinding itemDepositCashBinding = this.i.b;
        itemDepositCashBinding.a.setOnClickListener(new g(this, 3));
        this.i.c.b.setImageResource(R$mipmap.checkout_ic_atm);
        this.i.c.d.setText(R$string.cashincashout_atm);
        this.i.c.c.setText(R$string.cashincashout_go_to_the_atm_and_enter_the_code_to_cash_out);
        ItemDepositCashBinding itemDepositCashBinding2 = this.i.c;
        itemDepositCashBinding2.a.setOnClickListener(new b(this, 0));
        this.i.d.b.setImageResource(R$mipmap.checkout_ic_bank_account);
        this.i.d.d.setText(R$string.cashincashout_bank_account);
        this.i.d.c.setText(R$string.cashincashout_select_your_bank_account_to_cash_out);
        ItemDepositCashBinding itemDepositCashBinding3 = this.i.d;
        itemDepositCashBinding3.a.setOnClickListener(new b(this, 0));
        this.i.e.b.setImageResource(R$mipmap.checkout_deposit_voucher);
        this.i.e.d.setText(R$string.deposit_via_voucher);
        this.i.e.c.setText("");
        this.i.e.c.setVisibility(8);
        ItemDepositCashBinding itemDepositCashBinding4 = this.i.e;
        itemDepositCashBinding4.a.setOnClickListener(new i(this, 2));
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.module_cash.deposit.activity.DepositCashActivity, android.app.Activity] */
    public final ViewBinding K0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_deposit_cash, (ViewGroup) null, false);
        int i2 = R$id.deposit_cash_agent;
        View findChildViewById = ViewBindings.findChildViewById(inflate, i2);
        if (findChildViewById != null) {
            ItemDepositCashBinding a = ItemDepositCashBinding.a(findChildViewById);
            i2 = R$id.deposit_cash_atm;
            View findChildViewById2 = ViewBindings.findChildViewById(inflate, i2);
            if (findChildViewById2 != null) {
                ItemDepositCashBinding a2 = ItemDepositCashBinding.a(findChildViewById2);
                i2 = R$id.deposit_cash_bank_account;
                View findChildViewById3 = ViewBindings.findChildViewById(inflate, i2);
                if (findChildViewById3 != null) {
                    ItemDepositCashBinding a3 = ItemDepositCashBinding.a(findChildViewById3);
                    i2 = R$id.deposit_voucher;
                    View findChildViewById4 = ViewBindings.findChildViewById(inflate, i2);
                    if (findChildViewById4 != null) {
                        ActivityDepositCashBinding activityDepositCashBinding = new ActivityDepositCashBinding((LinearLayout) inflate, a, a2, a3, ItemDepositCashBinding.a(findChildViewById4));
                        this.i = activityDepositCashBinding;
                        return activityDepositCashBinding;
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }
}
