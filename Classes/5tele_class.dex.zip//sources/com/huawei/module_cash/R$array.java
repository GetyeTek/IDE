package com.huawei.module_cash;

public final class R$array {
    public static final int WheelArrayDefault = 2130903040;
    public static final int WheelArrayWeek = 2130903041;
    public static final int assume_strong_biometrics_models = 2130903042;
    public static final int cashOutAmount = 2130903043;
    public static final int cash_in_introduction = 2130903044;
    public static final int cash_out_agent_introduction = 2130903045;
    public static final int cash_out_atm_introduction = 2130903046;
    public static final int country = 2130903047;
    public static final int crypto_fingerprint_fallback_prefixes = 2130903048;
    public static final int crypto_fingerprint_fallback_vendors = 2130903049;
    public static final int delay_showing_prompt_models = 2130903050;
    public static final int easy_pin = 2130903051;
    public static final int gender = 2130903052;
    public static final int hide_fingerprint_instantly_prefixes = 2130903054;
    public static final int history_time_type = 2130903055;
    public static final int id_type = 2130903056;
    public static final int id_type_new = 2130903057;
    public static final int kyc_type = 2130903061;
    public static final int months = 2130903062;
    public static final int nearby_collection = 2130903065;
    public static final int nearby_filter = 2130903066;
    public static final int nearby_filter_name = 2130903067;
    public static final int nearby_sort = 2130903068;
    public static final int nearby_sort_name = 2130903069;
    public static final int nearby_type = 2130903070;
    public static final int nearby_type_name = 2130903071;
    public static final int second_id_type = 2130903073;
    public static final int second_id_type_value = 2130903074;
    public static final int second_id_type_value_backend = 2130903075;
    public static final int targetShareApp = 2130903078;
    public static final int transfer_introduction = 2130903079;

    private R$array() {
    }
}
