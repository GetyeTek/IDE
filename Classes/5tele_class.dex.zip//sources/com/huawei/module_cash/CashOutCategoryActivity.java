package com.huawei.module_cash;

import W2.a;
import W2.n;
import android.os.Bundle;
import android.view.View;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.module_cash.databinding.ActivityCashCategoryBinding;
import java.util.Map;
import o0.b;

@Route(path = "/cashModule/cashOut")
public class CashOutCategoryActivity extends BaseTitleActivity {
    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.module_cash.CashOutCategoryActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        CashOutCategoryActivity.super.G0();
        N0(getString(R$string.cashincashout_cash_out));
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_cash.CashOutCategoryActivity, android.app.Activity] */
    public final ViewBinding K0() {
        return ActivityCashCategoryBinding.a(getLayoutInflater());
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.module_cash.CashOutCategoryActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity] */
    public void onCategoryClick(View view) {
        if (!a.a(1000, view)) {
            int id = view.getId();
            if (id == R$id.agent_root) {
                if (n.b("").a("IS_RESHOW_CASHOUT_AGENT_INTRODUCTION")) {
                    J0(CashOutNumberActivity.class, false);
                    return;
                }
                n.a.b().getClass();
                n.a.a("/cashModule/introduction").withString("entrance", "CASH_OUT_AGENT").navigation(this);
            } else if (id != R$id.atm_root && id == R$id.bank_root) {
                b.d(this, "/bankModule/bankAccount", (Bundle) null, (Map) null);
            }
        }
    }
}
