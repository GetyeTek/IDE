package com.huawei.module_cash;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class CashInQrCodeActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [android.app.Activity, com.huawei.module_cash.CashInQrCodeActivity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (CashInQrCodeActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.amount;
        } else {
            str = r4.getIntent().getExtras().getString("amount", r4.amount);
        }
        r4.amount = str;
    }
}
