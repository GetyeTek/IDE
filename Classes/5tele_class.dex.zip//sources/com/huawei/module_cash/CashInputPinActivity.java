package com.huawei.module_cash;

import android.view.ViewPropertyAnimator;
import androidx.appcompat.app.AppCompatActivity;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_cash.databinding.ActivityCashInputPinBinding;

@Route(path = "/cashModule/cashInputPin")
public class CashInputPinActivity extends AppCompatActivity {
    public static final /* synthetic */ int d = 0;
    public ActivityCashInputPinBinding a;
    public String b;
    public ViewPropertyAnimator c;

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_cash.CashInputPinActivity, android.app.Activity] */
    public final void finish() {
        CashInputPinActivity.super.finish();
        ViewPropertyAnimator viewPropertyAnimator = this.c;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
        this.a.b.setAlpha(0.0f);
        overridePendingTransition(0, R$anim.from_top_to_bottom);
    }

    /* JADX WARNING: type inference failed for: r12v22, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.EditText] */
    /* JADX WARNING: type inference failed for: r0v17, types: [java.lang.Object, androidx.core.view.OnApplyWindowInsetsListener] */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0059, code lost:
        r1 = com.huawei.module_cash.R$id.virtualKeyboardView;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r12) {
        /*
            r11 = this;
            android.view.Window r0 = r11.getWindow()
            r1 = 8192(0x2000, float:1.14794E-41)
            r0.addFlags(r1)
            com.huawei.module_cash.CashInputPinActivity.super.onCreate(r12)
            android.view.LayoutInflater r12 = r11.getLayoutInflater()
            int r0 = com.huawei.module_cash.R$layout.activity_cash_input_pin
            r1 = 0
            r2 = 0
            android.view.View r12 = r12.inflate(r0, r1, r2)
            int r0 = com.huawei.module_cash.R$id.bg_view
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r12, r0)
            if (r5 == 0) goto L_0x011a
            r0 = r12
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            int r1 = com.huawei.module_cash.R$id.edit_pin
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r12, r1)
            r6 = r3
            com.huawei.module_checkout.view.CheckOutPinEditText r6 = (com.huawei.module_checkout.view.CheckOutPinEditText) r6
            if (r6 == 0) goto L_0x0119
            int r1 = com.huawei.module_cash.R$id.iv_close
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r12, r1)
            r7 = r3
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            if (r7 == 0) goto L_0x0119
            int r1 = com.huawei.module_cash.R$id.tv_amount
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r12, r1)
            r8 = r3
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0119
            int r1 = com.huawei.module_cash.R$id.tv_currency
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r12, r1)
            r9 = r3
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0119
            int r1 = com.huawei.module_cash.R$id.tv_title
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r12, r1)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x0119
            int r1 = com.huawei.module_cash.R$id.virtualKeyboardView
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r12, r1)
            r10 = r3
            com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView r10 = (com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView) r10
            if (r10 == 0) goto L_0x0119
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = new com.huawei.module_cash.databinding.ActivityCashInputPinBinding
            r3 = r12
            r4 = r0
            r3.<init>(r4, r5, r6, r7, r8, r9, r10)
            r11.a = r12
            r11.setContentView(r0)
            com.blankj.utilcode.util.f.e(r11, r2, r2)
            r12 = 1
            com.blankj.utilcode.util.f.f(r11, r12)
            int r12 = com.huawei.module_checkout.R$anim.from_bottom_to_top
            r11.overridePendingTransition(r12, r2)
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            android.view.View r12 = r12.b
            android.view.ViewPropertyAnimator r12 = r12.animate()
            r11.c = r12
            r0 = 1065353216(0x3f800000, float:1.0)
            r12.alpha(r0)
            android.view.ViewPropertyAnimator r12 = r11.c
            r0 = 300(0x12c, double:1.48E-321)
            r12.setDuration(r0)
            android.view.ViewPropertyAnimator r12 = r11.c
            r0 = 200(0xc8, double:9.9E-322)
            r12.setStartDelay(r0)
            android.view.ViewPropertyAnimator r12 = r11.c
            r12.start()
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            com.huawei.module_checkout.view.CheckOutPinEditText r12 = r12.c
            r0 = 6
            r12.setMaxCount(r0)
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            com.huawei.module_checkout.view.CheckOutPinEditText r12 = r12.c
            com.huawei.module_cash.c r0 = new com.huawei.module_cash.c
            r0.<init>(r11)
            r12.setOnCompleteListener(r0)
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            android.widget.ImageView r12 = r12.d
            P7.a r0 = new P7.a
            r1 = 6
            r0.<init>(r11, r1)
            r12.setOnClickListener(r0)
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView r0 = r12.g
            com.huawei.module_checkout.view.CheckOutPinEditText r12 = r12.c
            r0.a(r11, r12)
            android.content.Intent r12 = r11.getIntent()
            java.lang.String r0 = "amount"
            java.lang.String r12 = r12.getStringExtra(r0)
            r11.b = r12
            boolean r12 = android.text.TextUtils.isEmpty(r12)
            if (r12 == 0) goto L_0x00eb
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            android.widget.TextView r12 = r12.e
            java.lang.String r0 = ""
            r12.setText(r0)
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            android.widget.TextView r12 = r12.f
            r12.setText(r0)
            goto L_0x0101
        L_0x00eb:
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            android.widget.TextView r12 = r12.e
            java.lang.String r0 = r11.b
            r12.setText(r0)
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            android.widget.TextView r12 = r12.f
            k3.a r0 = k3.a.e
            java.lang.String r0 = r0.b()
            r12.setText(r0)
        L_0x0101:
            com.huawei.module_cash.databinding.ActivityCashInputPinBinding r12 = r11.a
            androidx.constraintlayout.widget.ConstraintLayout r12 = r12.a
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 35
            if (r0 < r1) goto L_0x0118
            if (r12 == 0) goto L_0x0118
            r12.setFitsSystemWindows(r2)
            com.huawei.module_cash.d r0 = new com.huawei.module_cash.d
            r0.<init>()
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(r12, r0)
        L_0x0118:
            return
        L_0x0119:
            r0 = r1
        L_0x011a:
            android.content.res.Resources r12 = r12.getResources()
            java.lang.String r12 = r12.getResourceName(r0)
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Missing required view with ID: "
            java.lang.String r12 = r1.concat(r12)
            r0.<init>(r12)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.CashInputPinActivity.onCreate(android.os.Bundle):void");
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.TextView] */
    public final void onPause() {
        CashInputPinActivity.super.onPause();
        this.a.c.setText("");
    }
}
