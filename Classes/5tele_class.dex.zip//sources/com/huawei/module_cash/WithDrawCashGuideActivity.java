package com.huawei.module_cash;

import A8.c;
import W2.a;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.module_cash.databinding.ActivityCashCategoryGuideBinding;
import com.huawei.module_checkout.databinding.ItemDepositCashBinding;
import java.util.Map;
import o0.b;

@Route(path = "/cashModule/withdrawcashguide")
public class WithDrawCashGuideActivity extends BaseMvpActivity implements View.OnClickListener {
    public ActivityCashCategoryGuideBinding j;

    public final void D0() {
    }

    public final void G(String str) {
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, android.view.View$OnClickListener, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, com.huawei.module_cash.WithDrawCashGuideActivity] */
    public final void G0() {
        WithDrawCashGuideActivity.super.G0();
        Q0(getResources().getColor(R$color.homeBg));
        N0(getString(R$string.cashincashout_withdrawcash));
        this.j.b.b.setImageResource(R$mipmap.checkout_ic_agent);
        this.j.b.d.setText(R$string.cash_out_via_agent);
        this.j.b.c.setText("");
        this.j.b.c.setVisibility(8);
        this.j.b.a.setOnClickListener(this);
        this.j.c.b.setImageResource(R$mipmap.checkout_ic_atm);
        this.j.c.d.setText(R$string.cash_out_via_atm);
        this.j.c.c.setText("");
        this.j.c.c.setVisibility(8);
        this.j.c.a.setOnClickListener(this);
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.app.Activity, com.huawei.module_cash.WithDrawCashGuideActivity] */
    public final ViewBinding K0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_cash_category_guide, (ViewGroup) null, false);
        int i = R$id.agent_root;
        View findChildViewById = ViewBindings.findChildViewById(inflate, i);
        if (findChildViewById != null) {
            ItemDepositCashBinding a = ItemDepositCashBinding.a(findChildViewById);
            int i2 = R$id.atm_root;
            View findChildViewById2 = ViewBindings.findChildViewById(inflate, i2);
            if (findChildViewById2 != null) {
                ActivityCashCategoryGuideBinding activityCashCategoryGuideBinding = new ActivityCashCategoryGuideBinding((LinearLayout) inflate, a, ItemDepositCashBinding.a(findChildViewById2));
                this.j = activityCashCategoryGuideBinding;
                return activityCashCategoryGuideBinding;
            }
            i = i2;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final c U0() {
        return null;
    }

    public final void V(String str) {
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.app.Activity, com.huawei.module_cash.WithDrawCashGuideActivity] */
    public void onClick(View view) {
        int id = view.getId();
        if (!a.a(1500, view)) {
            if (id == R$id.agent_root) {
                b.d(this, "/cashModule/withdrawcashinputcode", (Bundle) null, (Map) null);
                w5.a.a("Cashout_via_agent_V1");
            }
            if (id == R$id.atm_root) {
                b.d(this, "/cashModule/withdrawcashinatm", (Bundle) null, (Map) null);
                w5.a.a("Cashout_Deposit_via_ATM_V1");
            }
        }
    }
}
