package com.huawei.module_cash;

import V1.h;
import android.content.Intent;
import android.text.TextUtils;
import com.huawei.module_checkout.view.CheckOutPinEditText;

public final /* synthetic */ class c implements CheckOutPinEditText.a {
    public final /* synthetic */ CashInputPinActivity a;

    public /* synthetic */ c(CashInputPinActivity cashInputPinActivity) {
        this.a = cashInputPinActivity;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.module_cash.CashInputPinActivity, android.app.Activity] */
    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.TextView] */
    public final void c(String str) {
        int i = CashInputPinActivity.d;
        ? r0 = this.a;
        r0.a.c.setText("");
        if (!TextUtils.isEmpty(str)) {
            try {
                Intent intent = new Intent();
                intent.putExtra("pin", str.getBytes("UTF-8"));
                r0.setResult(-1, intent);
                r0.finish();
            } catch (Exception e) {
                e.getMessage();
                h.b();
            }
        }
    }
}
