package com.huawei.module_cash;

import R9.h;
import V1.k;
import W2.g;
import Z6.c;
import Z6.e;
import Z6.j;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.AmountConfigBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.digitalpayment.customer.httplib.response.QueryBalanceResp;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;
import com.huawei.module_cash.bean.PayTradeTypeEnum;
import com.huawei.module_cash.databinding.ActivityCashOutAmountBinding;
import com.huawei.module_cash.view.SpaceItemDecoration;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

@Route(path = "/cashModule/cashOutAmount")
public class CashOutAmountActivity extends BaseMvpActivity<j> implements c, e {
    public ActivityCashOutAmountBinding j;
    public AmountAdapter k;
    public ArrayList<com.huawei.module_cash.bean.a> l;
    public PayLoadingDialog m;
    public String n;
    @Autowired(name = "publicName")
    String publicName;
    @Autowired(name = "shortCode")
    String shortCode;

    public class a implements OnItemClickListener {
        public a() {
        }

        public final void onItemClick(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter, @NonNull View view, int i) {
            CashOutAmountActivity cashOutAmountActivity = CashOutAmountActivity.this;
            AmountAdapter amountAdapter = cashOutAmountActivity.k;
            if (amountAdapter.c != i) {
                amountAdapter.c = i;
                amountAdapter.notifyDataSetChanged();
                cashOutAmountActivity.j.e.setText("");
            }
        }
    }

    public final void D0() {
        A8.c cVar = new A8.c(this);
        cVar.a(H3.c.e().B(), new Z6.a(cVar, (P2.a) cVar.a));
        V0();
    }

    public final void G(String str) {
        this.m.dismiss();
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.module_cash.CashOutAmountActivity, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        CashOutAmountActivity.super.G0();
        N0(getString(R$string.cashincashout_cash_out));
        this.m = new PayLoadingDialog();
        this.j.b.setText(this.shortCode);
        this.j.d.setText(this.publicName);
        this.j.e.addTextChangedListener(new e(this));
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [com.huawei.module_cash.CashOutAmountActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x005f, code lost:
        r1 = com.huawei.module_cash.R$id.other_amount;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x006a, code lost:
        r1 = com.huawei.module_cash.R$id.rv_amount_list;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r10 = this;
            android.view.LayoutInflater r0 = r10.getLayoutInflater()
            int r1 = com.huawei.module_cash.R$layout.activity_cash_out_amount
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_cash.R$id.agent_info
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.ConstraintLayout r2 = (androidx.constraintlayout.widget.ConstraintLayout) r2
            if (r2 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.agent_short_code
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.agent_short_code_label
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.balance
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            android.widget.TextView r6 = (android.widget.TextView) r6
            if (r6 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.cash_out_all
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.cash_out_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.organization_name
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            if (r7 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.organization_name_label
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.other_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r8 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r8
            if (r8 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.rv_amount_list
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            androidx.recyclerview.widget.RecyclerView r9 = (androidx.recyclerview.widget.RecyclerView) r9
            if (r9 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.start_line
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x0093
            int r1 = com.huawei.module_cash.R$id.submit
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r2 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r2
            if (r2 == 0) goto L_0x0093
            com.huawei.module_cash.databinding.ActivityCashOutAmountBinding r1 = new com.huawei.module_cash.databinding.ActivityCashOutAmountBinding
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9)
            r10.j = r1
            return r1
        L_0x0093:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.CashOutAmountActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        this.m.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [P2.a, android.content.Context, com.huawei.module_cash.CashOutAmountActivity] */
    public final void V0() {
        AmountConfigBean cashOutConfig = BasicConfig.getInstance().getCashOutConfig();
        if (cashOutConfig != null) {
            InputItemEditText inputItemEditText = this.j.e;
            String unit = cashOutConfig.getUnit();
            inputItemEditText.setCurrency("(" + unit + ")");
            this.l = new ArrayList<>();
            for (int i = 1; i < cashOutConfig.getPriceList().size(); i++) {
                com.huawei.module_cash.bean.a aVar = new com.huawei.module_cash.bean.a();
                aVar.a = ((AmountConfigBean.Price) cashOutConfig.getPriceList().get(i)).getAmount();
                aVar.b = cashOutConfig.getUnit();
                aVar.c = ((AmountConfigBean.Price) cashOutConfig.getPriceList().get(i)).getDiscount();
                this.l.add(aVar);
            }
            this.j.f.setLayoutManager(new GridLayoutManager(this, 3));
            if (this.k == null) {
                this.k = new AmountAdapter(1, this.l);
            }
            this.j.f.setAdapter(this.k);
            this.j.f.addItemDecoration(new SpaceItemDecoration(h.a(this, 30.0f)));
            this.k.setOnItemClickListener(new a());
            return;
        }
        new A8.c(this).b(Arrays.asList(new String[]{"cashOutConfig"}));
    }

    public void cashOutAll(View view) {
        this.j.e.setText(this.n);
    }

    public final void p(BasicConfigResp.JsonContent jsonContent) {
        AmountConfigBean cashOutConfig;
        if (jsonContent != null && (cashOutConfig = jsonContent.getCashOutConfig()) != null) {
            BasicConfig.getInstance().setCashOutConfig(cashOutConfig);
            V0();
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_cash.CashOutAmountActivity] */
    public final void s0(QueryBalanceResp queryBalanceResp) {
        if (queryBalanceResp != null) {
            this.n = queryBalanceResp.getAmount();
            TextView textView = this.j.c;
            String string = getString(R$string.cashincashout_balance);
            String amountDisplay = queryBalanceResp.getAmountDisplay();
            textView.setText(string + amountDisplay);
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [P2.a, android.content.Context, com.huawei.module_cash.CashOutAmountActivity, androidx.appcompat.app.AppCompatActivity] */
    public void submitCashOut(View view) {
        com.huawei.module_cash.bean.a aVar;
        String obj = this.j.e.getText().toString();
        if (TextUtils.isEmpty(obj)) {
            AmountAdapter amountAdapter = this.k;
            int i = amountAdapter.c;
            if (i == -1) {
                aVar = null;
            } else {
                aVar = amountAdapter.b.get(i);
            }
            obj = aVar.a;
        }
        if (!g.a(obj)) {
            k.b(1, getString(R$string.cashincashout_incorrect_amount_format));
            return;
        }
        HashMap a2 = com.google.android.gms.ads.identifier.a.a("amount", obj);
        a2.put("tradeType", PayTradeTypeEnum.NATIVE_APP.getTradeType());
        a2.put("receiverShortCode", this.shortCode);
        a2.put("receiverOperatorCode", this.shortCode);
        new A8.c(this).b(this, TradeTypeEnum.CASH_OUT, a2);
    }
}
