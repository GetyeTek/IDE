package com.huawei.module_cash;

import W2.n;
import android.widget.CompoundButton;

public final class f implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ IntroductionActivity a;

    public f(IntroductionActivity introductionActivity) {
        this.a = introductionActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        IntroductionActivity introductionActivity = this.a;
        if ("TRANSFER".equals(introductionActivity.entrance)) {
            n.b("").h("IS_RESHOW_TRANSFER_INTRODUCTION", z);
        } else if ("CASH_IN".equals(introductionActivity.entrance)) {
            n.b("").h("IS_RESHOW_CASHIN_INTRODUCTION", z);
        } else if ("CASH_OUT_AGENT".equals(introductionActivity.entrance)) {
            n.b("").h("IS_RESHOW_CASHOUT_AGENT_INTRODUCTION", z);
        } else if ("CASH_OUT_ATM".equals(introductionActivity.entrance)) {
            n.b("").h("IS_RESHOW_CASHOUT_ATM_INTRODUCTION", z);
        }
    }
}
