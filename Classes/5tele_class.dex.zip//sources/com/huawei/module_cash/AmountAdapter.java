package com.huawei.module_cash;

import android.annotation.SuppressLint;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.module_cash.bean.a;
import java.util.ArrayList;

public class AmountAdapter extends BaseQuickAdapter<a, BaseViewHolder> {
    public final int a;
    public final ArrayList<a> b;
    public int c = 0;

    public AmountAdapter(int i, @Nullable ArrayList arrayList) {
        super(R$layout.item_amount, arrayList);
        this.b = arrayList;
        this.a = i;
    }

    @SuppressLint({"StringFormatInvalid"})
    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        a aVar = (a) obj;
        int i = R$id.item_amount;
        String str = aVar.a;
        String str2 = aVar.b;
        baseViewHolder.setText(i, str + " " + str2);
        if (this.a == 1 || "0.00".equals(aVar.c)) {
            ((TextView) baseViewHolder.getView(R$id.item_amount_back)).setVisibility(8);
        } else {
            baseViewHolder.setText(R$id.item_amount_back, String.format(J.a().getString(R$string.cashincashout_cash_back), new Object[]{aVar.c}));
        }
        if (baseViewHolder.getAdapterPosition() == this.c) {
            ((TextView) baseViewHolder.getView(i)).setTextColor(-1);
            ((TextView) baseViewHolder.getView(R$id.item_amount_back)).setTextColor(-1);
            baseViewHolder.getView(R$id.item_amount_root).setBackgroundResource(R$drawable.amount_item_select_bg);
            return;
        }
        ((TextView) baseViewHolder.getView(i)).setTextColor(-16755798);
        ((TextView) baseViewHolder.getView(R$id.item_amount_back)).setTextColor(-16755798);
        baseViewHolder.getView(R$id.item_amount_root).setBackgroundResource(R$drawable.amount_item_bg);
    }
}
