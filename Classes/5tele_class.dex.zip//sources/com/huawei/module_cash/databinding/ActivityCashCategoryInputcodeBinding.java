package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityCashCategoryInputcodeBinding implements ViewBinding {
    @NonNull
    public final FrameLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final EditText d;
    @NonNull
    public final EditText e;
    @NonNull
    public final ImageView f;

    public ActivityCashCategoryInputcodeBinding(@NonNull FrameLayout frameLayout, @NonNull LoadingButton loadingButton, @NonNull ImageView imageView, @NonNull EditText editText, @NonNull EditText editText2, @NonNull ImageView imageView2) {
        this.a = frameLayout;
        this.b = loadingButton;
        this.c = imageView;
        this.d = editText;
        this.e = editText2;
        this.f = imageView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
