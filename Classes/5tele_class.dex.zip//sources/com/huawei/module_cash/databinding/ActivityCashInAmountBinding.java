package com.huawei.module_cash.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public final class ActivityCashInAmountBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final InputItemEditText b;
    @NonNull
    public final RecyclerView c;

    public ActivityCashInAmountBinding(@NonNull ConstraintLayout constraintLayout, @NonNull InputItemEditText inputItemEditText, @NonNull RecyclerView recyclerView) {
        this.a = constraintLayout;
        this.b = inputItemEditText;
        this.c = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
