package com.huawei.module_cash.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityApplyDepositVoucherBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final LoadingButton b;

    public ActivityApplyDepositVoucherBinding(@NonNull ConstraintLayout constraintLayout, @NonNull LoadingButton loadingButton) {
        this.a = constraintLayout;
        this.b = loadingButton;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
