package com.huawei.module_cash.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.module_cash.R$id;

public class ActivityApplyDepositVoucherSuccessBindingImpl extends ActivityApplyDepositVoucherSuccessBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.iv_success, 1);
        sparseIntArray.put(R$id.tv_success, 2);
        sparseIntArray.put(R$id.tv_success_tips, 3);
        sparseIntArray.put(R$id.btn_next, 4);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
