package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.module_checkout.databinding.ItemDepositCashBinding;

public final class ActivityDepositCashBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final ItemDepositCashBinding b;
    @NonNull
    public final ItemDepositCashBinding c;
    @NonNull
    public final ItemDepositCashBinding d;
    @NonNull
    public final ItemDepositCashBinding e;

    public ActivityDepositCashBinding(@NonNull LinearLayout linearLayout, @NonNull ItemDepositCashBinding itemDepositCashBinding, @NonNull ItemDepositCashBinding itemDepositCashBinding2, @NonNull ItemDepositCashBinding itemDepositCashBinding3, @NonNull ItemDepositCashBinding itemDepositCashBinding4) {
        this.a = linearLayout;
        this.b = itemDepositCashBinding;
        this.c = itemDepositCashBinding2;
        this.d = itemDepositCashBinding3;
        this.e = itemDepositCashBinding4;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
