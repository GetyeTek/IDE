package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class ActivityDepositCashAgentBinding extends ViewDataBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final RoundImageView b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final RoundTextView h;
    @NonNull
    public final RoundTextView i;

    public ActivityDepositCashAgentBinding(DataBindingComponent dataBindingComponent, View view, RoundConstraintLayout roundConstraintLayout, RoundImageView roundImageView, LinearLayout linearLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4, RoundTextView roundTextView, RoundTextView roundTextView2) {
        super(dataBindingComponent, view, 0);
        this.a = roundConstraintLayout;
        this.b = roundImageView;
        this.c = linearLayout;
        this.d = textView;
        this.e = textView2;
        this.f = textView3;
        this.g = textView4;
        this.h = roundTextView;
        this.i = roundTextView2;
    }
}
