package com.huawei.module_cash.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ItemAmountBinding implements ViewBinding {
    @NonNull
    public final /* bridge */ /* synthetic */ View getRoot() {
        return null;
    }
}
