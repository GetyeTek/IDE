package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.ScrollView;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;
import com.huawei.module_cash.view.IntroductionView;

public final class ActivityIntroductionBinding implements ViewBinding {
    @NonNull
    public final ScrollView a;
    @NonNull
    public final AppCompatCheckBox b;
    @NonNull
    public final IntroductionView c;
    @NonNull
    public final IntroductionView d;
    @NonNull
    public final IntroductionView e;
    @NonNull
    public final LoadingButton f;
    @NonNull
    public final LoadingButton g;
    @NonNull
    public final AppCompatTextView h;

    public ActivityIntroductionBinding(@NonNull ScrollView scrollView, @NonNull AppCompatCheckBox appCompatCheckBox, @NonNull IntroductionView introductionView, @NonNull IntroductionView introductionView2, @NonNull IntroductionView introductionView3, @NonNull LoadingButton loadingButton, @NonNull LoadingButton loadingButton2, @NonNull AppCompatTextView appCompatTextView) {
        this.a = scrollView;
        this.b = appCompatCheckBox;
        this.c = introductionView;
        this.d = introductionView2;
        this.e = introductionView3;
        this.f = loadingButton;
        this.g = loadingButton2;
        this.h = appCompatTextView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
