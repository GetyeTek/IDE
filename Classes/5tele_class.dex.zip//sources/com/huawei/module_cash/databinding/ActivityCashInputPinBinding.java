package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView;
import com.huawei.module_checkout.view.CheckOutPinEditText;

public final class ActivityCashInputPinBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final View b;
    @NonNull
    public final CheckOutPinEditText c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final VirtualKeyboardView g;

    public ActivityCashInputPinBinding(@NonNull ConstraintLayout constraintLayout, @NonNull View view, @NonNull CheckOutPinEditText checkOutPinEditText, @NonNull ImageView imageView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull VirtualKeyboardView virtualKeyboardView) {
        this.a = constraintLayout;
        this.b = view;
        this.c = checkOutPinEditText;
        this.d = imageView;
        this.e = textView;
        this.f = textView2;
        this.g = virtualKeyboardView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
