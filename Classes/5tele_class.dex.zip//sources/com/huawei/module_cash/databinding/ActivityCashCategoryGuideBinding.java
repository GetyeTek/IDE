package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.module_checkout.databinding.ItemDepositCashBinding;

public final class ActivityCashCategoryGuideBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final ItemDepositCashBinding b;
    @NonNull
    public final ItemDepositCashBinding c;

    public ActivityCashCategoryGuideBinding(@NonNull LinearLayout linearLayout, @NonNull ItemDepositCashBinding itemDepositCashBinding, @NonNull ItemDepositCashBinding itemDepositCashBinding2) {
        this.a = linearLayout;
        this.b = itemDepositCashBinding;
        this.c = itemDepositCashBinding2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
