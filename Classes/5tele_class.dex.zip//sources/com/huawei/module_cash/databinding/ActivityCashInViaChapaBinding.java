package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public final class ActivityCashInViaChapaBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final InputItemEditText c;
    @NonNull
    public final EditText d;

    public ActivityCashInViaChapaBinding(@NonNull ConstraintLayout constraintLayout, @NonNull TextView textView, @NonNull InputItemEditText inputItemEditText, @NonNull EditText editText) {
        this.a = constraintLayout;
        this.b = textView;
        this.c = inputItemEditText;
        this.d = editText;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
