package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public abstract class ActivityApplyDepositVoucherSuccessBinding extends ViewDataBinding {
    public static final /* synthetic */ int d = 0;
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;

    public ActivityApplyDepositVoucherSuccessBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = textView;
        this.c = textView2;
    }
}
