package com.huawei.module_cash.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;

public final class ActivityTransferToCashincashoutConfirmBinding implements ViewBinding {
    @NonNull
    public final RoundConstraintLayout a;

    public ActivityTransferToCashincashoutConfirmBinding(@NonNull RoundConstraintLayout roundConstraintLayout) {
        this.a = roundConstraintLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
