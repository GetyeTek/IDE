package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityCashCategoryAtmBinding implements ViewBinding {
    @NonNull
    public final FrameLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final EditText c;
    @NonNull
    public final ImageButton d;
    @NonNull
    public final TextView e;

    public ActivityCashCategoryAtmBinding(@NonNull FrameLayout frameLayout, @NonNull LoadingButton loadingButton, @NonNull EditText editText, @NonNull ImageButton imageButton, @NonNull TextView textView) {
        this.a = frameLayout;
        this.b = loadingButton;
        this.c = editText;
        this.d = imageButton;
        this.e = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
