package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityCashOutNumberBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final EditText b;
    @NonNull
    public final LoadingButton c;

    public ActivityCashOutNumberBinding(@NonNull ConstraintLayout constraintLayout, @NonNull EditText editText, @NonNull LoadingButton loadingButton) {
        this.a = constraintLayout;
        this.b = editText;
        this.c = loadingButton;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
