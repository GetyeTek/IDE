package com.huawei.module_cash.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public final class ActivityCashOutAmountBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final InputItemEditText e;
    @NonNull
    public final RecyclerView f;

    public ActivityCashOutAmountBinding(@NonNull ConstraintLayout constraintLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull InputItemEditText inputItemEditText, @NonNull RecyclerView recyclerView) {
        this.a = constraintLayout;
        this.b = textView;
        this.c = textView2;
        this.d = textView3;
        this.e = inputItemEditText;
        this.f = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
