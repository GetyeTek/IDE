package com.huawei.module_cash.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.module_cash.R$id;

public class ActivityDepositCashAgentBindingImpl extends ActivityDepositCashAgentBinding {
    @Nullable
    public static final SparseIntArray k;
    public long j;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        k = sparseIntArray;
        sparseIntArray.put(R$id.cl_qrcode, 1);
        sparseIntArray.put(R$id.tv_tips, 2);
        sparseIntArray.put(R$id.ll_amount, 3);
        sparseIntArray.put(R$id.tv_amount, 4);
        sparseIntArray.put(R$id.tv_amount_unit, 5);
        sparseIntArray.put(R$id.iv_qrcode, 6);
        sparseIntArray.put(R$id.tv_phone_number, 7);
        sparseIntArray.put(R$id.tv_name, 8);
        sparseIntArray.put(R$id.tv_set_amount, 9);
        sparseIntArray.put(R$id.tv_save_image, 10);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.j = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.j != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.j = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
