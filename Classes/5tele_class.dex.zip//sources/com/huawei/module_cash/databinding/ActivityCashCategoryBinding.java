package com.huawei.module_cash.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.huawei.module_cash.R$id;
import com.huawei.module_cash.R$layout;

public final class ActivityCashCategoryBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;

    public ActivityCashCategoryBinding(@NonNull ConstraintLayout constraintLayout) {
        this.a = constraintLayout;
    }

    @NonNull
    public static ActivityCashCategoryBinding a(@NonNull LayoutInflater layoutInflater) {
        ConstraintLayout inflate = layoutInflater.inflate(R$layout.activity_cash_category, (ViewGroup) null, false);
        int i = R$id.agent_icon;
        if (((ImageView) ViewBindings.findChildViewById(inflate, i)) != null) {
            i = R$id.agent_name;
            if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                i = R$id.agent_root;
                if (ViewBindings.findChildViewById(inflate, i) != null) {
                    i = R$id.atm_icon;
                    if (((ImageView) ViewBindings.findChildViewById(inflate, i)) != null) {
                        i = R$id.atm_name;
                        if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                            i = R$id.atm_root;
                            if (ViewBindings.findChildViewById(inflate, i) != null) {
                                i = R$id.bank_icon;
                                if (((ImageView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                    i = R$id.bank_name;
                                    if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                        i = R$id.bank_root;
                                        if (ViewBindings.findChildViewById(inflate, i) != null) {
                                            return new ActivityCashCategoryBinding(inflate);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
