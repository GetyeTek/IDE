package com.huawei.module_cash.bean;

public final class a {
    public String a;
    public String b;
    public String c;
}
