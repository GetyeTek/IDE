package com.huawei.module_cash;

import A8.c;
import V1.k;
import W2.g;
import Z6.f;
import Z6.h;
import Z6.i;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;
import com.huawei.module_cash.databinding.ActivityCashOutNumberBinding;
import java.util.HashMap;
import java.util.Map;
import n.a;
import o0.b;

@Route(path = "/cashModule/cashOutNumber")
public class CashOutNumberActivity extends BaseMvpActivity<h> implements i {
    public ActivityCashOutNumberBinding j;

    public final void D0() {
    }

    public final void G(String str) {
        this.j.c.a();
    }

    public final void G0() {
        CashOutNumberActivity.super.G0();
        O0(R$string.cashincashout_cash_out);
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.module_cash.CashOutNumberActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x002a, code lost:
        r1 = com.huawei.module_cash.R$id.next;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r5 = this;
            android.view.LayoutInflater r0 = r5.getLayoutInflater()
            int r1 = com.huawei.module_cash.R$layout.activity_cash_out_number
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_cash.R$id.content
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.ConstraintLayout r2 = (androidx.constraintlayout.widget.ConstraintLayout) r2
            if (r2 == 0) goto L_0x0048
            int r1 = com.huawei.module_cash.R$id.enter_number
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.EditText r2 = (android.widget.EditText) r2
            if (r2 == 0) goto L_0x0048
            int r1 = com.huawei.module_cash.R$id.enter_number_label
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x0048
            int r1 = com.huawei.module_cash.R$id.next
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r3 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r3
            if (r3 == 0) goto L_0x0048
            int r1 = com.huawei.module_cash.R$id.scan_number
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            if (r4 == 0) goto L_0x0048
            com.huawei.module_cash.databinding.ActivityCashOutNumberBinding r1 = new com.huawei.module_cash.databinding.ActivityCashOutNumberBinding
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1.<init>(r0, r2, r3)
            r5.j = r1
            return r1
        L_0x0048:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.CashOutNumberActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
        this.j.c.b();
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_cash.CashOutNumberActivity] */
    public final void b(VerifyNumberResp verifyNumberResp) {
        a.b().getClass();
        a.a("/cashModule/cashOutAmount").withString("shortCode", verifyNumberResp.getShortCode()).withString("publicName", verifyNumberResp.getPublicName()).navigation(this);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.module_cash.CashOutNumberActivity] */
    public void gotoAmount(View view) {
        String obj = this.j.b.getText().toString();
        if (TextUtils.isEmpty(obj)) {
            k.b(1, getString(R$string.cashincashout_please_input_short_code));
        } else if (!g.d(obj)) {
            k.b(1, getString(R$string.cashincashout_incorrect_short_code_format));
        } else {
            h hVar = this.i;
            hVar.getClass();
            HashMap hashMap = new HashMap();
            hashMap.put("receiverShortCode", obj);
            hashMap.put("receiverOperatorCode", obj);
            hVar.a(H3.c.e().x(hashMap), new f(hVar, (P2.a) hVar.a));
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_cash.CashOutNumberActivity, android.app.Activity] */
    public void gotoScan(View view) {
        new HashMap().put("isCashOut", Boolean.TRUE);
        b.d(this, "/qrCodeModule/scan", (Bundle) null, (Map) null);
    }
}
