package com.huawei.module_cash;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class IntroductionActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_cash.IntroductionActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (IntroductionActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.entrance;
        } else {
            str = r4.getIntent().getExtras().getString("entrance", r4.entrance);
        }
        r4.entrance = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.msisdn;
        } else {
            str2 = r4.getIntent().getExtras().getString("msisdn", r4.msisdn);
        }
        r4.msisdn = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.customerType;
        } else {
            str3 = r4.getIntent().getExtras().getString("customerType", r4.customerType);
        }
        r4.customerType = str3;
    }
}
