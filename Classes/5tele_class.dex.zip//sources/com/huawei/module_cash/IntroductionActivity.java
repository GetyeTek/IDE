package com.huawei.module_cash;

import W2.a;
import android.view.View;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.module_cash.bean.PayTradeTypeEnum;
import com.huawei.module_cash.databinding.ActivityIntroductionBinding;

@Route(path = "/cashModule/introduction")
public class IntroductionActivity extends BaseTitleActivity {
    @Autowired
    String customerType;
    @Autowired
    String entrance;
    public ActivityIntroductionBinding i;
    @Autowired
    String msisdn;

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.IntroductionActivity, android.content.Context, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void D0() {
        String[] strArr = new String[0];
        if ("TRANSFER".equals(this.entrance)) {
            N0(getString(R$string.cashincashout_transfer));
            strArr = getResources().getStringArray(R$array.transfer_introduction);
        } else if ("CASH_IN".equals(this.entrance)) {
            N0(getString(R$string.cashincashout_cash_in));
            strArr = getResources().getStringArray(R$array.cash_in_introduction);
        } else if ("CASH_OUT_AGENT".equals(this.entrance)) {
            N0(getString(R$string.cashincashout_cash_out));
            strArr = getResources().getStringArray(R$array.cash_out_agent_introduction);
        } else if ("CASH_OUT_ATM".equals(this.entrance)) {
            N0(getString(R$string.cashincashout_cash_out));
            strArr = getResources().getStringArray(R$array.cash_out_atm_introduction);
        }
        if (strArr.length > 0) {
            this.i.h.setText(strArr[0]);
            this.i.c.setImage(strArr[1]);
            this.i.c.setTitle(strArr[2]);
            this.i.c.setContent(strArr[3]);
            this.i.d.setImage(strArr[4]);
            this.i.d.setTitle(strArr[5]);
            this.i.d.setContent(strArr[6]);
            this.i.e.setImage(strArr[7]);
            this.i.e.setTitle(strArr[8]);
            this.i.e.setContent(strArr[9]);
            this.i.g.setText(strArr[10]);
            if (strArr.length >= 12) {
                this.i.f.setVisibility(0);
                this.i.f.setText(strArr[11]);
            }
        }
    }

    public final void G0() {
        IntroductionActivity.super.G0();
        this.i.b.setOnCheckedChangeListener(new f(this));
    }

    /* JADX WARNING: type inference failed for: r12v0, types: [com.huawei.module_cash.IntroductionActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0043, code lost:
        r1 = com.huawei.module_cash.R$id.lb_intro_confirm;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004e, code lost:
        r1 = com.huawei.module_cash.R$id.tv_intro_big_title;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0038, code lost:
        r1 = com.huawei.module_cash.R$id.lb_intro_cancel;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r12 = this;
            android.view.LayoutInflater r0 = r12.getLayoutInflater()
            int r1 = com.huawei.module_cash.R$layout.activity_introduction
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_cash.R$id.checkbox
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            androidx.appcompat.widget.AppCompatCheckBox r5 = (androidx.appcompat.widget.AppCompatCheckBox) r5
            if (r5 == 0) goto L_0x0065
            int r1 = com.huawei.module_cash.R$id.iv_first
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            com.huawei.module_cash.view.IntroductionView r6 = (com.huawei.module_cash.view.IntroductionView) r6
            if (r6 == 0) goto L_0x0065
            int r1 = com.huawei.module_cash.R$id.iv_second
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            com.huawei.module_cash.view.IntroductionView r7 = (com.huawei.module_cash.view.IntroductionView) r7
            if (r7 == 0) goto L_0x0065
            int r1 = com.huawei.module_cash.R$id.iv_third
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            com.huawei.module_cash.view.IntroductionView r8 = (com.huawei.module_cash.view.IntroductionView) r8
            if (r8 == 0) goto L_0x0065
            int r1 = com.huawei.module_cash.R$id.lb_intro_cancel
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r9 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r9
            if (r9 == 0) goto L_0x0065
            int r1 = com.huawei.module_cash.R$id.lb_intro_confirm
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r10 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r10
            if (r10 == 0) goto L_0x0065
            int r1 = com.huawei.module_cash.R$id.tv_intro_big_title
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            androidx.appcompat.widget.AppCompatTextView r11 = (androidx.appcompat.widget.AppCompatTextView) r11
            if (r11 == 0) goto L_0x0065
            com.huawei.module_cash.databinding.ActivityIntroductionBinding r1 = new com.huawei.module_cash.databinding.ActivityIntroductionBinding
            r4 = r0
            android.widget.ScrollView r4 = (android.widget.ScrollView) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11)
            r12.i = r1
            return r1
        L_0x0065:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.IntroductionActivity.K0():androidx.viewbinding.ViewBinding");
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.IntroductionActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity] */
    public void onViewClick(View view) {
        if (!a.a(1000, view)) {
            int id = view.getId();
            if (id == R$id.lb_intro_confirm) {
                if ("TRANSFER".equals(this.entrance)) {
                    n.a.b().getClass();
                    n.a.a("/checkoutModule/transferAmount").withString("msisdn", this.msisdn).withString("tradeType", PayTradeTypeEnum.NATIVE_APP.getTradeType()).withString("customerType", this.customerType).navigation();
                    finish();
                } else if ("CASH_IN".equals(this.entrance)) {
                    J0(CashInAmountActivity.class, false);
                    finish();
                } else {
                    Class<CashOutNumberActivity> cls = CashOutNumberActivity.class;
                    if ("CASH_OUT_AGENT".equals(this.entrance)) {
                        J0(cls, false);
                        finish();
                    } else if ("CASH_OUT_ATM".equals(this.entrance)) {
                        J0(cls, false);
                        finish();
                    }
                }
            } else if (id == R$id.lb_intro_cancel && !"CASH_IN".equals(this.entrance) && !"CASH_OUT_AGENT".equals(this.entrance)) {
                "CASH_OUT_ATM".equals(this.entrance);
            }
        }
    }
}
