package com.huawei.module_cash.view;

import H1.c;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import com.blankj.utilcode.util.A;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.module_cash.R$id;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.R$style;

public class WithDrawCashDataDialog extends BaseDialog {

    public class a implements View.OnClickListener {

        /* renamed from: com.huawei.module_cash.view.WithDrawCashDataDialog$a$a  reason: collision with other inner class name */
        public class C0000a implements Runnable {
            public C0000a() {
            }

            public final void run() {
                a aVar = a.this;
                WithDrawCashDataDialog.this.getDialog().dismiss();
                WithDrawCashDataDialog.this.getClass();
                throw null;
            }
        }

        public a() {
        }

        public final void onClick(View view) {
            A.h(new C0000a(), 300);
        }
    }

    public final void onStart() {
        Window window;
        WithDrawCashDataDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            window.setBackgroundDrawableResource(17170445);
            c.b(window, R$style.BottomAnimation, dialog, false, true);
        }
    }

    public final void onViewCreated(View view, Bundle bundle) {
        WithDrawCashDataDialog.super.onViewCreated(view, bundle);
        ((Button) view.findViewById(R$id.btn_confirm)).setOnClickListener(new a());
    }

    public final int v0() {
        return R$layout.withdrawcashguidedialog;
    }
}
