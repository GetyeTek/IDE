package com.huawei.module_cash.view;

import O9.c;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.huawei.module_cash.R$id;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.R$mipmap;

public class IntroductionView extends RelativeLayout {
    public final TextView a;
    public final TextView b;
    public final ImageView c;

    public IntroductionView(Context context) {
        this(context, (AttributeSet) null);
    }

    public void setContent(String str) {
        this.b.setText(str);
    }

    public void setImage(String str) {
        c.c(this.c, str, R$mipmap.qrcode_default_grid_scan_line);
    }

    public void setTitle(String str) {
        this.a.setText(str);
    }

    public IntroductionView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public IntroductionView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        View inflate = LayoutInflater.from(context).inflate(R$layout.item_introduction_view, this, true);
        this.a = (TextView) inflate.findViewById(R$id.tv_intro_title);
        this.b = (TextView) inflate.findViewById(R$id.tv_intro_content);
        this.c = (ImageView) inflate.findViewById(R$id.iv_intro_pic);
    }
}
