package com.huawei.module_cash.withdrawcash;

import A8.c;
import G7.b;
import V1.h;
import V1.k;
import Z6.o;
import Z6.p;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.google.android.gms.ads.identifier.a;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;
import com.huawei.module_cash.R$id;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Route(path = "/cashModule/withdrawcashinatm")
public class WithDrawCashInAtmActivity extends BaseMvpActivity<p> implements o, View.OnClickListener {
    public ActivityCashCategoryAtmBinding j;
    public byte[] k;
    public LoadingDialog l;

    public final void D0() {
    }

    public final void G(String str) {
        this.l.dismiss();
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v2, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: type inference failed for: r2v9, types: [com.huawei.module_cash.withdrawcash.a, android.text.TextWatcher] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void G0() {
        /*
            r8 = this;
            r0 = 0
            r1 = 1
            com.huawei.module_cash.withdrawcash.WithDrawCashInAtmActivity.super.G0()
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r2 = r8.j
            android.widget.FrameLayout r2 = r2.a
            r8.setContentView(r2)
            android.view.Window r2 = r8.getWindow()
            com.blankj.utilcode.util.f.g(r2)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r2 = r8.j
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r2 = r2.b
            r2.setEnabled(r0)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r2 = r8.j
            android.widget.TextView r2 = r2.e
            k3.a r3 = k3.a.e
            java.lang.String r3 = r3.b()
            r2.setText(r3)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r2 = r8.j
            android.widget.ImageButton r2 = r2.d
            r2.setOnClickListener(r8)
            com.huawei.module_cash.withdrawcash.a r2 = new com.huawei.module_cash.withdrawcash.a
            r2.<init>(r8)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r3 = r8.j
            android.widget.EditText r3 = r3.c
            t4.e r4 = new t4.e
            r4.<init>()
            t4.a r5 = new t4.a
            r5.<init>()
            r6 = 4666723172467343360(0x40c3880000000000, double:10000.0)
            r5.a = r6
            r6 = 2
            android.text.InputFilter[] r6 = new android.text.InputFilter[r6]
            r6[r0] = r4
            r6[r1] = r5
            r3.setFilters(r6)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r0 = r8.j
            android.widget.EditText r0 = r0.c
            com.huawei.module_cash.withdrawcash.b r3 = new com.huawei.module_cash.withdrawcash.b
            r3.<init>(r1)
            r0.addTextChangedListener(r3)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r0 = r8.j
            android.widget.EditText r0 = r0.c
            r0.addTextChangedListener(r2)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r0 = r8.j
            android.widget.EditText r0 = r0.c
            r0.setSingleLine(r1)
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r0 = r8.j
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r0 = r0.b
            r0.setOnClickListener(r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.withdrawcash.WithDrawCashInAtmActivity.G0():void");
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInAtmActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.module_cash.R$id.btn_confirm;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r10 = this;
            android.view.LayoutInflater r0 = r10.getLayoutInflater()
            int r1 = com.huawei.module_cash.R$layout.activity_cash_category_atm
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r2, r3)
            int r1 = com.huawei.module_cash.R$id.bgitem
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0060
            int r1 = com.huawei.module_cash.R$id.btn_confirm
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r3
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r6 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r6
            if (r6 == 0) goto L_0x0060
            int r1 = com.huawei.module_cash.R$id.edit_inputcode
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r3
            android.widget.EditText r7 = (android.widget.EditText) r7
            if (r7 == 0) goto L_0x0060
            int r1 = com.huawei.module_cash.R$id.inuptcodelayout
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundConstraintLayout r3 = (com.huawei.common.widget.round.RoundConstraintLayout) r3
            if (r3 == 0) goto L_0x0060
            int r1 = com.huawei.module_cash.R$id.iv_atmback
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r3
            android.widget.ImageButton r8 = (android.widget.ImageButton) r8
            if (r8 == 0) goto L_0x0060
            int r1 = com.huawei.module_cash.R$id.tool_bar
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r3 == 0) goto L_0x0060
            int r1 = com.huawei.module_cash.R$id.tv_currency
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r3
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0060
            com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding r1 = new com.huawei.module_cash.databinding.ActivityCashCategoryAtmBinding
            r5 = r0
            android.widget.FrameLayout r5 = (android.widget.FrameLayout) r5
            r4 = r1
            r4.<init>(r5, r6, r7, r8, r9)
            r10.j = r1
            return r2
        L_0x0060:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.withdrawcash.WithDrawCashInAtmActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
        if (!"sendSmsCode".equals(str)) {
            LoadingDialog loadingDialog = new LoadingDialog();
            this.l = loadingDialog;
            loadingDialog.show(getSupportFragmentManager(), "");
        }
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        WithDrawCashInAtmActivity.super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null) {
            byte[] byteArrayExtra = intent.getByteArrayExtra("pin");
            this.k = byteArrayExtra;
            if (byteArrayExtra != null) {
                String obj = this.j.c.getText().toString();
                c cVar = new c(this);
                byte[] bArr = this.k;
                HashMap a = a.a("amount", obj);
                a.put("initiatorPin", L3.a.g(new String(bArr, StandardCharsets.UTF_8)));
                a.put("pinVersion", L3.a.b.getPinKeyVersion());
                cVar.a(H3.c.e().D(a), new b(cVar, (P2.a) cVar.a, 1));
            }
        }
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInAtmActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity] */
    public void onClick(View view) {
        int id = view.getId();
        if (!W2.a.a(1500, view)) {
            if (id == R$id.iv_atmback) {
                finish();
            }
            if (id == R$id.btn_confirm) {
                try {
                    String obj = this.j.c.getEditableText().toString();
                    double parseDouble = Double.parseDouble(obj);
                    if (parseDouble >= 50.0d) {
                        if (parseDouble % 50.0d == 0.0d) {
                            if (parseDouble > 10000.0d) {
                                k.b(1, String.format(getResources().getString(R$string.sorry_the_amount_should_be_exceed), new Object[]{"10,000"}) + k3.a.e.b());
                                return;
                            }
                            w5.a.a("Apply_cashout_via_ATM_V1");
                            Bundle bundle = new Bundle(3);
                            bundle.putString("repaymentAmount", obj);
                            o0.b.e(this, "/cashModule/withdrawCashInputPin", bundle, (Map) null, 0, 1111);
                            return;
                        }
                    }
                    k.b(1, String.format(getResources().getString(R$string.sorry_the_amount_must_be_multiple_of), new Object[]{"50"}));
                } catch (Exception e) {
                    e.toString();
                    h.b();
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInAtmActivity, android.app.Activity] */
    public final void s(VerifyNumberResp verifyNumberResp) {
        if (verifyNumberResp.getResponseCode().equals("SYS00000")) {
            o0.b.d((Activity) null, "/cashModule/applyAtmVoucherSuccess", (Bundle) null, (Map) null);
            finish();
        }
    }
}
