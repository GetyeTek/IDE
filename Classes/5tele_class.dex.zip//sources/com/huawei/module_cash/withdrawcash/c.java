package com.huawei.module_cash.withdrawcash;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import java.util.Map;
import o0.b;

public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ int a;

    public /* synthetic */ c(int i) {
        this.a = i;
    }

    public final void onClick(View view) {
        switch (this.a) {
            case 0:
                int i = WithDrawCashInputCodeActivity.l;
                Bundle bundle = new Bundle(1);
                bundle.putString("scanPurpose", "CashOut");
                b.d((Activity) null, "/qrCodeModule/scan", bundle, (Map) null);
                return;
            default:
                b.d((Activity) null, "/profileModule/photoProfile", (Bundle) null, (Map) null);
                return;
        }
    }
}
