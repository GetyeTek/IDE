package com.huawei.module_cash.withdrawcash;

import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import i7.C0013a;
import n.a;

public final class j implements C0013a.b<TransferResp> {
    public final /* synthetic */ WithDrawCashInputMoneyActivity a;

    public j(WithDrawCashInputMoneyActivity withDrawCashInputMoneyActivity) {
        this.a = withDrawCashInputMoneyActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInputMoneyActivity, android.app.Activity] */
    public final void onSuccess(Object obj) {
        ? r0 = this.a;
        a.b().getClass();
        a.a("/basicUiModule/commonSuccess").withSerializable("TransferResp", (TransferResp) obj).withString("shortCode", r0.shortCode).navigation();
        r0.finish();
    }
}
