package com.huawei.module_cash.withdrawcash;

import R1.a;
import V1.k;
import W2.g;
import android.text.TextUtils;
import androidx.fragment.app.FragmentActivity;
import com.huawei.common.exception.BaseException;
import com.huawei.module_cash.bean.PayTradeTypeEnum;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import i7.C0013a;
import java.util.HashMap;

public final class i implements a<Boolean> {
    public final /* synthetic */ WithDrawCashInputMoneyActivity a;

    public i(WithDrawCashInputMoneyActivity withDrawCashInputMoneyActivity) {
        this.a = withDrawCashInputMoneyActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        FragmentActivity fragmentActivity = this.a;
        String obj2 = fragmentActivity.n.getEditableText().toString();
        fragmentActivity.amount = obj2;
        if (TextUtils.isEmpty(obj2)) {
            k.b(1, fragmentActivity.getString(R$string.designstandard_please_input_amount));
        } else if (!g.a(fragmentActivity.amount)) {
            k.b(1, fragmentActivity.getString(R$string.designstandard_incorrect_amount_format));
        } else {
            fragmentActivity.tradeType = PayTradeTypeEnum.NATIVE_APP.getTradeType();
            HashMap hashMap = new HashMap();
            hashMap.put("amount", fragmentActivity.amount);
            hashMap.put("note", "");
            hashMap.put("tradeType", fragmentActivity.tradeType);
            hashMap.put("receiverShortCode", fragmentActivity.shortCode);
            hashMap.put("operatorId", fragmentActivity.operatorId);
            hashMap.put("receiverTillNo", "");
            if (!TextUtils.isEmpty(fragmentActivity.operationNumber)) {
                HashMap hashMap2 = new HashMap();
                hashMap2.put("operationNumber", fragmentActivity.operationNumber);
                hashMap.put("extraPayParams", hashMap2);
            }
            C0013a.C0002a.a.c(fragmentActivity, fragmentActivity.getString(com.huawei.module_cash.R$string.cash_out), PaySceneEnum.CASH_OUT, hashMap, new j(fragmentActivity));
        }
    }
}
