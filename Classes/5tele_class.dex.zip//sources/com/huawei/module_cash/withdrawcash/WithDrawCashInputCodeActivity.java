package com.huawei.module_cash.withdrawcash;

import A8.c;
import V1.k;
import W2.a;
import W2.g;
import Z6.h;
import Z6.i;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;
import com.huawei.module_cash.R$id;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.databinding.ActivityCashCategoryInputcodeBinding;
import java.util.HashMap;
import o0.b;

@Route(path = "/cashModule/withdrawcashinputcode")
public class WithDrawCashInputCodeActivity extends BaseMvpActivity<h> implements i, View.OnClickListener {
    public static final /* synthetic */ int l = 0;
    public ActivityCashCategoryInputcodeBinding j;
    public LoadingDialog k;

    public final void D0() {
    }

    public final void G(String str) {
        this.k.dismiss();
    }

    /* JADX WARNING: type inference failed for: r0v9, types: [com.huawei.module_cash.withdrawcash.d, android.text.TextWatcher] */
    public final void G0() {
        WithDrawCashInputCodeActivity.super.G0();
        setContentView(this.j.a);
        f.g(getWindow());
        N0(getString(R$string.cashincashout_withdrawcash));
        this.j.b.setEnabled(false);
        new BaseDialog();
        new LinearLayoutManager(this);
        ? dVar = new d(this, 0);
        this.j.d.addTextChangedListener(dVar);
        this.j.e.addTextChangedListener(dVar);
        this.j.d.setSingleLine(true);
        this.j.e.setSingleLine(true);
        this.j.f.setOnClickListener(this);
        this.j.b.setOnClickListener(this);
        this.j.c.setOnClickListener(new c(0));
    }

    /* JADX WARNING: type inference failed for: r11v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInputCodeActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.module_cash.R$id.btn_confirm;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r11 = this;
            android.view.LayoutInflater r0 = r11.getLayoutInflater()
            int r1 = com.huawei.module_cash.R$layout.activity_cash_category_inputcode
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r2, r3)
            int r1 = com.huawei.module_cash.R$id.bgitem
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.btn_confirm
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r3
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r6 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r6
            if (r6 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.cashoutscan
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r3
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            if (r7 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.edit_inputcode
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r3
            android.widget.EditText r8 = (android.widget.EditText) r8
            if (r8 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.edit_operatorid
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r3
            android.widget.EditText r9 = (android.widget.EditText) r9
            if (r9 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.inuptcodelayout
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            if (r3 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.iv_agentback
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r3
            android.widget.ImageView r10 = (android.widget.ImageView) r10
            if (r10 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.operatoridlayout
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            if (r3 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.tv_tips
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x0081
            int r1 = com.huawei.module_cash.R$id.tv_titles
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x0081
            com.huawei.module_cash.databinding.ActivityCashCategoryInputcodeBinding r1 = new com.huawei.module_cash.databinding.ActivityCashCategoryInputcodeBinding
            r5 = r0
            android.widget.FrameLayout r5 = (android.widget.FrameLayout) r5
            r4 = r1
            r4.<init>(r5, r6, r7, r8, r9, r10)
            r11.j = r1
            return r2
        L_0x0081:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.withdrawcash.WithDrawCashInputCodeActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
        LoadingDialog loadingDialog = new LoadingDialog();
        this.k = loadingDialog;
        loadingDialog.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInputCodeActivity, android.app.Activity] */
    public final void b(VerifyNumberResp verifyNumberResp) {
        if (verifyNumberResp.getResponseCode().equals("SYS00000")) {
            String obj = this.j.e.getText().toString();
            HashMap hashMap = new HashMap();
            hashMap.put("shortCode", verifyNumberResp.getShortCode());
            hashMap.put("publicName", verifyNumberResp.getPublicName());
            hashMap.put("operatorId", obj);
            b.d(this, "/cashModule/inputmoney", (Bundle) null, hashMap);
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, com.huawei.module_cash.withdrawcash.WithDrawCashInputCodeActivity, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, android.app.Activity] */
    public void onClick(View view) {
        int id = view.getId();
        if (!a.a(1500, view)) {
            if (id == R$id.btn_confirm) {
                String obj = this.j.d.getText().toString();
                String obj2 = this.j.e.getText().toString();
                if (TextUtils.isEmpty(obj)) {
                    k.b(1, getString(R$string.cashincashout_please_input_short_code));
                } else if (!g.d(obj)) {
                    k.b(1, getString(R$string.cashincashout_incorrect_short_code_format));
                } else {
                    h hVar = this.i;
                    hVar.getClass();
                    HashMap hashMap = new HashMap();
                    hashMap.put("receiverShortCode", obj);
                    hashMap.put("operatorId", obj2);
                    hVar.a(H3.c.e().x(hashMap), new Z6.g(hVar, (P2.a) hVar.a, 0));
                }
                w5.a.a("Cashout_via_agent_Next_V1");
            }
            if (id == R$id.iv_agentback) {
                finish();
            }
        }
    }
}
