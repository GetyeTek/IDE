package com.huawei.module_cash.withdrawcash;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import com.huawei.module_checkout.checkout.TradeTypeEnum;

public class WithDrawCashInputMoneyActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInputMoneyActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (WithDrawCashInputMoneyActivity) obj;
        r4.transferType = (TradeTypeEnum) r4.getIntent().getSerializableExtra("transferType");
        if (r4.getIntent().getExtras() == null) {
            str = r4.shortCode;
        } else {
            str = r4.getIntent().getExtras().getString("shortCode", r4.shortCode);
        }
        r4.shortCode = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.publicName;
        } else {
            str2 = r4.getIntent().getExtras().getString("publicName", r4.publicName);
        }
        r4.publicName = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.amount;
        } else {
            str3 = r4.getIntent().getExtras().getString("amount", r4.amount);
        }
        r4.amount = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.operationNumber;
        } else {
            str4 = r4.getIntent().getExtras().getString("operationNumber", r4.operationNumber);
        }
        r4.operationNumber = str4;
        if (r4.getIntent().getExtras() == null) {
            str5 = r4.notes;
        } else {
            str5 = r4.getIntent().getExtras().getString("notes", r4.notes);
        }
        r4.notes = str5;
        if (r4.getIntent().getExtras() == null) {
            str6 = r4.tradeType;
        } else {
            str6 = r4.getIntent().getExtras().getString("tradeType", r4.tradeType);
        }
        r4.tradeType = str6;
        if (r4.getIntent().getExtras() == null) {
            str7 = r4.operatorId;
        } else {
            str7 = r4.getIntent().getExtras().getString("operatorId", r4.operatorId);
        }
        r4.operatorId = str7;
    }
}
