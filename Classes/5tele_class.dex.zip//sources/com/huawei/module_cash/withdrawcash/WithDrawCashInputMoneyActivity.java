package com.huawei.module_cash.withdrawcash;

import D1.q;
import W2.f;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.lifecycle.Observer;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import c2.d;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.google.gson.reflect.TypeToken;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.bean.BalanceInfo;
import com.huawei.module_cash.databinding.ActivityTransferToCashincashoutConfirmBinding;
import com.huawei.module_cash.paymoney.Cashin2MerchantViewModel;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import i7.C0013a;
import java.util.List;
import java.util.Locale;
import o0.b;

@Route(path = "/cashModule/inputmoney")
public class WithDrawCashInputMoneyActivity extends BaseMvvmActivity<Cashin2MerchantViewModel> implements View.OnClickListener {
    public static final /* synthetic */ int o = 0;
    @Autowired
    String amount;
    public CustomKeyBroadPop k;
    public TextView l;
    public TextView m;
    public InputItemEditText n;
    @Autowired
    String notes;
    @Autowired
    String operationNumber;
    @Autowired
    String operatorId = "";
    @Autowired
    String publicName;
    @Autowired
    String shortCode;
    @Autowired
    String tradeType = "";
    @Autowired
    TradeTypeEnum transferType;

    public class a implements Observer<CheckoutResp> {
        public a() {
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInputMoneyActivity, java.lang.Object, android.app.Activity] */
        public final void onChanged(Object obj) {
            ? r0 = WithDrawCashInputMoneyActivity.this;
            r0.getClass();
            Bundle bundle = new Bundle(1);
            bundle.putString("amount", r0.amount);
            bundle.putString("notes", r0.notes);
            bundle.putString("tradeType", r0.tradeType);
            bundle.putString("shortCode", r0.shortCode);
            bundle.putSerializable("CheckoutResp", (CheckoutResp) obj);
            C0013a.C0002a.a.a(r0, "/cashModule/showmoney", bundle, new h(r0));
        }
    }

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r5v4, types: [com.huawei.module_cash.withdrawcash.f, android.text.TextWatcher] */
    public final void G0() {
        List<BalanceInfo> list;
        WithDrawCashInputMoneyActivity.super.G0();
        N0(getString(R$string.cashincashout_cash_out));
        CustomKeyBroadPop customKeyBroadPop = new CustomKeyBroadPop(this, new d(4, d.b(getString(R$string.designstandard_withdraw))));
        this.k = customKeyBroadPop;
        customKeyBroadPop.d = new N4.a(this);
        this.l = (TextView) findViewById(R$id.tv_transfer_to);
        View findViewById = findViewById(com.huawei.module_cash.R$id.tv_withdraw_all);
        TextView textView = (TextView) findViewById(com.huawei.module_cash.R$id.tv_balance);
        this.m = (TextView) findViewById(R$id.tv_org_name);
        InputItemEditText findViewById2 = findViewById(R$id.et_amount);
        this.n = findViewById2;
        findViewById2.requestFocus();
        this.n.setFocusableInTouchMode(true);
        InputItemEditText inputItemEditText = this.n;
        inputItemEditText.setCurrency("(" + k3.a.e.b() + ")");
        this.k.a(this, this.n, true);
        this.n.addTextChangedListener(new f(this));
        String b = b.c(AppService.class).b();
        String str = "";
        if (!TextUtils.isEmpty(b) && (list = (List) f.a(b, new TypeToken().getType())) != null && !list.isEmpty()) {
            for (BalanceInfo balanceInfo : list) {
                if (balanceInfo.getForward().contains("home_balance")) {
                    str = balanceInfo.getAmount();
                    textView.setText(getString(R$string.baselib_balance) + ": " + balanceInfo.getAmountDisplay() + "(" + balanceInfo.getCurrency() + ")");
                }
            }
        }
        findViewById.setOnClickListener(new e(this, str));
        this.l.setText(this.shortCode);
        this.m.setText(this.publicName);
        if (!TextUtils.isEmpty(this.amount)) {
            try {
                double parseDouble = Double.parseDouble(this.amount);
                String format = String.format(Locale.ENGLISH, "%.2f", new Object[]{Double.valueOf(parseDouble)});
                this.n.setText(format);
                this.n.setSelection(format.length());
                this.n.setEnabled(false);
                this.n.setFocusable(false);
                this.n.setFocusableInTouchMode(false);
                findViewById(com.huawei.module_cash.R$id.et_amount_click_view).setOnClickListener(new q(this, 6));
            } catch (Exception unused) {
            }
        }
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_cash.withdrawcash.WithDrawCashInputMoneyActivity, android.app.Activity] */
    public final ViewBinding K0() {
        RoundConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_transfer_to_cashincashout_confirm, (ViewGroup) null, false);
        int i = com.huawei.module_cash.R$id.cl_bottom;
        if (ViewBindings.findChildViewById(inflate, i) != null) {
            i = com.huawei.module_cash.R$id.et_amount;
            if (ViewBindings.findChildViewById(inflate, i) != null) {
                i = com.huawei.module_cash.R$id.et_amount_click_view;
                if (ViewBindings.findChildViewById(inflate, i) != null) {
                    i = com.huawei.module_cash.R$id.iv_head;
                    if (ViewBindings.findChildViewById(inflate, i) != null) {
                        i = com.huawei.module_cash.R$id.line;
                        if (ViewBindings.findChildViewById(inflate, i) != null) {
                            i = com.huawei.module_cash.R$id.tv_amount;
                            if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                i = com.huawei.module_cash.R$id.tv_balance;
                                if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                    i = com.huawei.module_cash.R$id.tv_org_name;
                                    if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                        i = com.huawei.module_cash.R$id.tv_transfer_to;
                                        if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                            i = com.huawei.module_cash.R$id.tv_withdraw_all;
                                            if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                                return new ActivityTransferToCashincashoutConfirmBinding(inflate);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final void U0() {
        WithDrawCashInputMoneyActivity.super.U0();
        this.i.j.observe(this, new a());
    }

    public final void onBackPressed() {
        if (this.k.isShowing()) {
            this.k.c();
        } else {
            WithDrawCashInputMoneyActivity.super.onBackPressed();
        }
    }

    public void onClick(View view) {
        view.getId();
        W2.a.a(1500, view);
    }
}
