package com.huawei.module_cash.withdrawcash;

import android.text.Editable;
import android.text.TextUtils;

public final class a extends O2.a {
    public final /* synthetic */ WithDrawCashInAtmActivity b;

    public a(WithDrawCashInAtmActivity withDrawCashInAtmActivity) {
        super(2);
        this.b = withDrawCashInAtmActivity;
    }

    public final void afterTextChanged(Editable editable) {
        WithDrawCashInAtmActivity withDrawCashInAtmActivity = this.b;
        if (TextUtils.isEmpty(withDrawCashInAtmActivity.j.c.getText().toString())) {
            withDrawCashInAtmActivity.j.b.setEnabled(false);
        } else {
            withDrawCashInAtmActivity.j.b.setEnabled(true);
        }
    }
}
