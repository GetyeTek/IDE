package com.huawei.module_cash.withdrawcash;

import O2.a;
import W2.g;

public final class f extends a {
    public final /* synthetic */ WithDrawCashInputMoneyActivity b;

    public f(WithDrawCashInputMoneyActivity withDrawCashInputMoneyActivity) {
        super(1);
        this.b = withDrawCashInputMoneyActivity;
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        this.b.k.d(g.a(charSequence.toString()));
    }
}
