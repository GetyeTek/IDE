package com.huawei.module_cash.withdrawcash;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.schedule.activity.j;
import com.huawei.module_cash.R$layout;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.databinding.ActivityApplyDepositVoucherSuccessBinding;

@Route(path = "/cashModule/applyAtmVoucherSuccess")
public class ApplyAtmVoucherSuccessActivity extends BaseTitleActivity {
    public static final /* synthetic */ int j = 0;
    public ActivityApplyDepositVoucherSuccessBinding i;

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.module_cash.withdrawcash.ApplyAtmVoucherSuccessActivity, android.content.Context] */
    public final void D0() {
        TextView textView = this.i.b;
        textView.setText(getString(R$string.successful) + "!");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_cash.withdrawcash.ApplyAtmVoucherSuccessActivity, android.content.Context, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        ApplyAtmVoucherSuccessActivity.super.G0();
        N0(getString(R$string.apply_atm_voucher));
        this.i.a.setOnClickListener(new j());
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.module_cash.withdrawcash.ApplyAtmVoucherSuccessActivity, android.app.Activity] */
    public final ViewBinding K0() {
        LayoutInflater layoutInflater = getLayoutInflater();
        int i2 = ActivityApplyDepositVoucherSuccessBinding.d;
        ActivityApplyDepositVoucherSuccessBinding inflateInternal = ViewDataBinding.inflateInternal(layoutInflater, R$layout.activity_apply_deposit_voucher_success, (ViewGroup) null, false, DataBindingUtil.getDefaultComponent());
        this.i = inflateInternal;
        return inflateInternal;
    }
}
