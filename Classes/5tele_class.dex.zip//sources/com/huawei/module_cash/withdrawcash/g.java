package com.huawei.module_cash.withdrawcash;

import com.google.gson.reflect.TypeToken;
import com.huawei.module_cash.bean.BalanceInfo;
import java.util.List;

class g extends TypeToken<List<BalanceInfo>> {
}
