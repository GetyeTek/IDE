package com.huawei.module_cash.withdrawcash;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewPropertyAnimator;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_checkout.requestpin.BaseRequestPinActivity;

@Route(path = "/cashModule/withdrawCashInputPin")
public class WithdrawCashInputPinActivity extends BaseRequestPinActivity {
    public ViewPropertyAnimator g;

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.module_cash.withdrawcash.WithdrawCashInputPinActivity, android.app.Activity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity] */
    public final void D0(String str) {
        if (!TextUtils.isEmpty(str)) {
            try {
                Intent intent = new Intent();
                intent.putExtra("pin", str.getBytes("UTF-8"));
                setResult(-1, intent);
                finish();
            } catch (Exception unused) {
            }
        }
    }

    public final void K() {
        ViewPropertyAnimator viewPropertyAnimator = this.g;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
        this.a.b.setAlpha(0.0f);
        finish();
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_cash.withdrawcash.WithdrawCashInputPinActivity, android.app.Activity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        getIntent().getStringExtra("repaymentAmount");
        ViewPropertyAnimator animate = this.a.b.animate();
        this.g = animate;
        animate.alpha(1.0f);
        this.g.setDuration(300);
        this.g.setStartDelay(200);
        this.g.start();
    }
}
