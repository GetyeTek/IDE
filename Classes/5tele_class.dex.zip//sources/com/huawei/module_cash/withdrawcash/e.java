package com.huawei.module_cash.withdrawcash;

import android.view.View;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public final /* synthetic */ class e implements View.OnClickListener {
    public final /* synthetic */ WithDrawCashInputMoneyActivity a;
    public final /* synthetic */ String b;

    public /* synthetic */ e(WithDrawCashInputMoneyActivity withDrawCashInputMoneyActivity, String str) {
        this.a = withDrawCashInputMoneyActivity;
        this.b = str;
    }

    public final void onClick(View view) {
        WithDrawCashInputMoneyActivity withDrawCashInputMoneyActivity = this.a;
        InputItemEditText inputItemEditText = withDrawCashInputMoneyActivity.n;
        String str = this.b;
        inputItemEditText.setText(str);
        withDrawCashInputMoneyActivity.n.setSelection(str.length());
    }
}
