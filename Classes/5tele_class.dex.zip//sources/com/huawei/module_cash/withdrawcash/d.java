package com.huawei.module_cash.withdrawcash;

import O2.a;
import android.text.Editable;
import android.text.TextUtils;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.login_module.resetpin.ResetPinOtpActivity;

public final class d extends a {
    public final /* synthetic */ int b;
    public final /* synthetic */ BaseMvpActivity c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(BaseMvpActivity baseMvpActivity, int i) {
        super(2);
        this.b = i;
        this.c = baseMvpActivity;
    }

    public void afterTextChanged(Editable editable) {
        switch (this.b) {
            case 0:
                WithDrawCashInputCodeActivity withDrawCashInputCodeActivity = this.c;
                if (TextUtils.isEmpty(withDrawCashInputCodeActivity.j.d.getText().toString())) {
                    withDrawCashInputCodeActivity.j.b.setEnabled(false);
                    return;
                } else {
                    withDrawCashInputCodeActivity.j.b.setEnabled(true);
                    return;
                }
            default:
                d.super.afterTextChanged(editable);
                return;
        }
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        switch (this.b) {
            case 1:
                int i4 = ResetPinOtpActivity.m;
                this.c.V0();
                return;
            default:
                d.super.onTextChanged(charSequence, i, i2, i3);
                return;
        }
    }
}
