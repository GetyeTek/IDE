package com.huawei.module_cash.withdrawcash;

import O2.a;
import android.text.Editable;

public final class b extends a {
    public final void afterTextChanged(Editable editable) {
        if (editable.toString().length() == 2 && editable.toString().startsWith("0") && !editable.toString().equals("0.")) {
            editable.delete(0, 1);
        }
    }
}
