package com.huawei.module_cash;

import android.content.DialogInterface;

public final /* synthetic */ class a implements DialogInterface.OnClickListener {
    public final void onClick(DialogInterface dialogInterface, int i) {
        int i2 = CashInAmountActivity.l;
        dialogInterface.dismiss();
    }
}
