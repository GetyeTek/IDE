package com.huawei.module_cash;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

public final class b implements TextWatcher {
    public final /* synthetic */ CashInAmountActivity a;

    public b(CashInAmountActivity cashInAmountActivity) {
        this.a = cashInAmountActivity;
    }

    public final void afterTextChanged(Editable editable) {
        if (!TextUtils.isEmpty(editable.toString())) {
            AmountAdapter amountAdapter = this.a.j;
            amountAdapter.c = -1;
            amountAdapter.notifyDataSetChanged();
        }
    }

    public final void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }
}
