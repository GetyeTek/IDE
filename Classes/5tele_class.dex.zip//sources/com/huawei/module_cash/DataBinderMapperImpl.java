package com.huawei.module_cash;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;
import com.huawei.module_cash.databinding.ActivityApplyDepositVoucherSuccessBinding;
import com.huawei.module_cash.databinding.ActivityApplyDepositVoucherSuccessBindingImpl;
import com.huawei.module_cash.databinding.ActivityDepositCashAgentBinding;
import com.huawei.module_cash.databinding.ActivityDepositCashAgentBindingImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(2);
            a = hashMap;
            hashMap.put("layout/activity_apply_deposit_voucher_success_0", Integer.valueOf(R$layout.activity_apply_deposit_voucher_success));
            hashMap.put("layout/activity_deposit_cash_agent_0", Integer.valueOf(R$layout.activity_deposit_cash_agent));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(2);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_apply_deposit_voucher_success, 1);
        sparseIntArray.put(R$layout.activity_deposit_cash_agent, 2);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(8);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new RuntimeException("view must have a tag");
            } else if (i2 != 1) {
                if (i2 == 2) {
                    if ("layout/activity_deposit_cash_agent_0".equals(tag)) {
                        Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 11, (ViewDataBinding.IncludedLayouts) null, ActivityDepositCashAgentBindingImpl.k);
                        TextView textView = (TextView) mapBindings[2];
                        ActivityDepositCashAgentBinding activityDepositCashAgentBinding = new ActivityDepositCashAgentBinding(dataBindingComponent, view, (RoundConstraintLayout) mapBindings[1], (RoundImageView) mapBindings[6], (LinearLayout) mapBindings[3], (TextView) mapBindings[4], (TextView) mapBindings[5], (TextView) mapBindings[8], (TextView) mapBindings[7], (RoundTextView) mapBindings[10], (RoundTextView) mapBindings[9]);
                        activityDepositCashAgentBinding.j = -1;
                        ((ConstraintLayout) mapBindings[0]).setTag((Object) null);
                        activityDepositCashAgentBinding.setRootTag(view2);
                        activityDepositCashAgentBinding.invalidateAll();
                        return activityDepositCashAgentBinding;
                    }
                    throw new IllegalArgumentException(l.a(tag, "The tag for activity_deposit_cash_agent is invalid. Received: "));
                }
            } else if ("layout/activity_apply_deposit_voucher_success_0".equals(tag)) {
                Object[] mapBindings2 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 5, (ViewDataBinding.IncludedLayouts) null, ActivityApplyDepositVoucherSuccessBindingImpl.f);
                ImageView imageView = (ImageView) mapBindings2[1];
                ActivityApplyDepositVoucherSuccessBinding activityApplyDepositVoucherSuccessBinding = new ActivityApplyDepositVoucherSuccessBinding(dataBindingComponent, view, (LoadingButton) mapBindings2[4], (TextView) mapBindings2[2], (TextView) mapBindings2[3]);
                activityApplyDepositVoucherSuccessBinding.e = -1;
                ((ConstraintLayout) mapBindings2[0]).setTag((Object) null);
                activityApplyDepositVoucherSuccessBinding.setRootTag(view2);
                activityApplyDepositVoucherSuccessBinding.invalidateAll();
                return activityApplyDepositVoucherSuccessBinding;
            } else {
                throw new IllegalArgumentException(l.a(tag, "The tag for activity_apply_deposit_voucher_success is invalid. Received: "));
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
