package com.huawei.module_cash.chapa.activity;

import D4.g;
import V6.b;
import V6.c;
import V6.e;
import V6.f;
import android.content.Intent;
import android.text.InputFilter;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import c2.d;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.module_cash.R$color;
import com.huawei.module_cash.R$string;
import com.huawei.module_cash.chapa.viewmodel.CashInViaChapaViewModel;
import com.huawei.module_cash.databinding.ActivityCashInViaChapaBinding;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import t4.a;

@Route(path = "/cashModule/cashInViaChapa")
public class CashInViaChapaActivity extends BaseTitleActivity {
    public static final /* synthetic */ int l = 0;
    public ActivityCashInViaChapaBinding i;
    public CashInViaChapaViewModel j;
    public CustomKeyBroadPop k;

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r3v4, types: [V6.f, android.text.TextWatcher] */
    /* JADX WARNING: type inference failed for: r2v12, types: [android.view.View$OnClickListener, java.lang.Object] */
    public final void G0() {
        CashInViaChapaActivity.super.G0();
        CustomKeyBroadPop customKeyBroadPop = new CustomKeyBroadPop(this, new d(4, d.b(getString(R$string.ethiopia_ok))));
        this.k = customKeyBroadPop;
        customKeyBroadPop.d = new c(this);
        customKeyBroadPop.a(this, this.i.c, true);
        this.i.c.addTextChangedListener(new f(this));
        this.i.c.setOnClickListener(new V6.d(this, 0));
        this.i.d.setOnTouchListener(new e(this, 0));
        N0(getString(R$string.cash_in_via_chapa));
        String string = getString(R$string.history);
        TextView textView = this.e;
        if (textView != null) {
            textView.setText(string);
        }
        int i2 = R$color.color_8dc63f;
        TextView textView2 = this.e;
        if (textView2 != null) {
            textView2.setTextColor(ContextCompat.getColor(this, i2));
        }
        ? obj = new Object();
        TextView textView3 = this.e;
        if (textView3 != null) {
            textView3.setOnClickListener(obj);
        }
        InputItemEditText inputItemEditText = this.i.c;
        InputFilter aVar = new a();
        aVar.a = 50000.0d;
        inputItemEditText.setFilters(new InputFilter[]{aVar});
        InputItemEditText inputItemEditText2 = this.i.c;
        inputItemEditText2.setCurrency("(" + k3.a.e.b() + ")");
        this.i.c.requestFocus();
        this.i.c.setFocusableInTouchMode(true);
        this.i.b.setOnClickListener(new b(this, 0));
        if (this.j == null) {
            this.j = new ViewModelProvider(this).get(CashInViaChapaViewModel.class);
        }
        this.j.a.observe(this, new g(this, 1));
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [com.huawei.module_cash.chapa.activity.CashInViaChapaActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0020, code lost:
        r1 = com.huawei.module_cash.R$id.et_amount;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r6 = this;
            android.view.LayoutInflater r0 = r6.getLayoutInflater()
            int r1 = com.huawei.module_cash.R$layout.activity_cash_in_via_chapa
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_cash.R$id.btn_confirm
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0050
            int r1 = com.huawei.module_cash.R$id.cl_amount
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundConstraintLayout r3 = (com.huawei.common.widget.round.RoundConstraintLayout) r3
            if (r3 == 0) goto L_0x0050
            int r1 = com.huawei.module_cash.R$id.et_amount
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r3 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r3
            if (r3 == 0) goto L_0x0050
            int r1 = com.huawei.module_cash.R$id.et_remark
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.EditText r4 = (android.widget.EditText) r4
            if (r4 == 0) goto L_0x0050
            int r1 = com.huawei.module_cash.R$id.line
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r5 == 0) goto L_0x0050
            int r1 = com.huawei.module_cash.R$id.tv_amount
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x0050
            com.huawei.module_cash.databinding.ActivityCashInViaChapaBinding r1 = new com.huawei.module_cash.databinding.ActivityCashInViaChapaBinding
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1.<init>(r0, r2, r3, r4)
            r6.i = r1
            return r1
        L_0x0050:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_cash.chapa.activity.CashInViaChapaActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        CashInViaChapaActivity.super.onActivityResult(i2, i3, intent);
        if (intent != null && i2 == 1001 && i3 == -1) {
            byte[] byteArrayExtra = intent.getByteArrayExtra("pin");
            String format = String.format(Locale.ENGLISH, "%.2f", new Object[]{Double.valueOf(Double.parseDouble(this.i.c.getEditableText().toString()))});
            CashInViaChapaViewModel cashInViaChapaViewModel = this.j;
            String g = L3.a.g(new String(byteArrayExtra, StandardCharsets.UTF_8));
            String obj = this.i.d.getEditableText().toString();
            cashInViaChapaViewModel.a.setValue(S2.b.c((Object) null));
            com.huawei.http.b bVar = new com.huawei.http.b();
            bVar.addParams("initiatorPin", g);
            bVar.addParams("pinVersion", L3.a.b.getPinKeyVersion());
            bVar.addParams("amount", format);
            bVar.addParams("remark", obj);
            bVar.sendRequest(new W6.a(cashInViaChapaViewModel, 0));
        }
    }

    public final void onBackPressed() {
        if (this.k.isShowing()) {
            this.k.c();
        } else {
            CashInViaChapaActivity.super.onBackPressed();
        }
    }
}
