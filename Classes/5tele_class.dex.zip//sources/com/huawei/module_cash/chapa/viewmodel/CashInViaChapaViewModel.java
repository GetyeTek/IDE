package com.huawei.module_cash.chapa.viewmodel;

import S2.b;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.response.ChapaResp;

public class CashInViaChapaViewModel extends ViewModel {
    public final MutableLiveData<b<ChapaResp>> a = new MutableLiveData<>();
}
