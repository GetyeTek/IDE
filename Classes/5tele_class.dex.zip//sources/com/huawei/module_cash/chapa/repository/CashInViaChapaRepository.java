package com.huawei.module_cash.chapa.repository;

import com.huawei.digitalpayment.customer.httplib.response.ChapaResp;
import com.huawei.http.b;

public class CashInViaChapaRepository extends b<ChapaResp, ChapaResp> {
    public final String getApiPath() {
        return "v1/ethiopia/chapa/createOrder";
    }
}
