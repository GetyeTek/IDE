package com.huawei.module_cash;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class CashOutAmountActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_cash.CashOutAmountActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (CashOutAmountActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.shortCode;
        } else {
            str = r4.getIntent().getExtras().getString("shortCode", r4.shortCode);
        }
        r4.shortCode = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.publicName;
        } else {
            str2 = r4.getIntent().getExtras().getString("publicName", r4.publicName);
        }
        r4.publicName = str2;
    }
}
