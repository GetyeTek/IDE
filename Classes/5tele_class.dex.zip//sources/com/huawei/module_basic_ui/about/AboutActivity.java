package com.huawei.module_basic_ui.about;

import D1.o;
import I6.b;
import I6.c;
import W2.j;
import W2.n;
import android.animation.ObjectAnimator;
import android.widget.TextView;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.LoadingButton;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.baselib.utils.upgrade.UpdateBean;
import com.huawei.digitalpayment.customer.httplib.response.VersionVerifyResp;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivityAboutBinding;
import o0.a;

@Route(path = "/basicUiModule/about")
@a("about")
public class AboutActivity extends BaseMvpActivity<b> implements c {
    public static final /* synthetic */ int m = 0;
    public ActivityAboutBinding j;
    public int k;
    public long l;

    public final void D0() {
    }

    public final void G(String str) {
        LoadingButton loadingButton = this.j.b;
        loadingButton.setClickable(true);
        ObjectAnimator objectAnimator = loadingButton.e;
        if (objectAnimator != null) {
            objectAnimator.end();
        }
        loadingButton.b.setText(loadingButton.d);
        loadingButton.c.setVisibility(8);
    }

    public final void G0() {
        AboutActivity.super.G0();
        O0(R$string.designstandard_about);
        this.j.d.setOnClickListener(new G5.a(this, 1));
        this.j.b.setOnClickListener(new o(this, 2));
        this.j.c.setImageBitmap(j.c(500, 500, n.b("").a.getString("AppDownloadIntroduction", "https://app.ethiomobilemoney.et:2121/ammres/customer/downLoad/en.html")));
        TextView textView = this.j.e;
        String a = W2.b.a();
        textView.setText("V" + a);
        String a2 = W2.b.a();
        if (a2.split("\\.").length == 4) {
            a2 = a2.substring(0, a2.lastIndexOf("."));
        }
        TextView textView2 = this.j.e;
        textView2.setText("V" + a2);
        b bVar = this.i;
        bVar.getClass();
        bVar.a(H3.c.e().d0(), new I6.a(bVar, (P2.a) bVar.a, false, false));
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.module_basic_ui.about.AboutActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0017, code lost:
        r1 = com.huawei.module_basic_ui.R$id.iv_code;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r9 = this;
            android.view.LayoutInflater r0 = r9.getLayoutInflater()
            int r1 = com.huawei.module_basic_ui.R$layout.activity_about
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_basic_ui.R$id.btn_check_update
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.huawei.common.widget.LoadingButton r5 = (com.huawei.common.widget.LoadingButton) r5
            if (r5 == 0) goto L_0x0058
            int r1 = com.huawei.module_basic_ui.R$id.iv_code
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            com.huawei.common.widget.round.RoundImageView r6 = (com.huawei.common.widget.round.RoundImageView) r6
            if (r6 == 0) goto L_0x0058
            int r1 = com.huawei.module_basic_ui.R$id.iv_logo
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            if (r7 == 0) goto L_0x0058
            int r1 = com.huawei.module_basic_ui.R$id.tv_name
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0058
            int r1 = com.huawei.module_basic_ui.R$id.tv_term_of_service
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0058
            int r1 = com.huawei.module_basic_ui.R$id.tv_version
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0058
            com.huawei.module_basic_ui.databinding.ActivityAboutBinding r1 = new com.huawei.module_basic_ui.databinding.ActivityAboutBinding
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8)
            r9.j = r1
            return r1
        L_0x0058:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_basic_ui.about.AboutActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        this.j.b.a();
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_basic_ui.about.AboutActivity, android.app.Activity] */
    public final void c0(boolean z, VersionVerifyResp versionVerifyResp) {
        if (versionVerifyResp != null) {
            UpdateBean updateBean = new UpdateBean();
            updateBean.setUpdateMode(versionVerifyResp.getUpdateMode());
            updateBean.setDescription(versionVerifyResp.getDescription());
            updateBean.setDownloadUrl(versionVerifyResp.getDownloadUrl());
            updateBean.setLatestVersion(versionVerifyResp.getLatestVersion());
            h3.a.a(this, updateBean, z);
        }
    }
}
