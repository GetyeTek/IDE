package com.huawei.module_basic_ui;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager.widget.ViewPager;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.viewpager.ViewPagerIndicator;
import com.huawei.module_basic_ui.databinding.ActivityGuideBinding;
import com.huawei.module_basic_ui.databinding.ActivityGuideBindingImpl;
import com.huawei.module_basic_ui.databinding.ActivityResultQrCodeBinding;
import com.huawei.module_basic_ui.databinding.ActivityResultQrCodeBindingImpl;
import com.huawei.module_basic_ui.databinding.ItemLanguageMenuPopBinding;
import com.huawei.module_basic_ui.databinding.ItemLanguageMenuPopBindingImpl;
import com.huawei.module_basic_ui.databinding.LanguagePopLayoutBinding;
import com.huawei.module_basic_ui.databinding.LanguagePopLayoutBindingImpl;
import com.huawei.module_basic_ui.databinding.TipsLayoutBindingImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(5);
            a = hashMap;
            hashMap.put("layout/activity_guide_0", Integer.valueOf(R$layout.activity_guide));
            hashMap.put("layout/activity_result_qr_code_0", Integer.valueOf(R$layout.activity_result_qr_code));
            hashMap.put("layout/item_language_menu_pop_0", Integer.valueOf(R$layout.item_language_menu_pop));
            hashMap.put("layout/language_pop_layout_0", Integer.valueOf(R$layout.language_pop_layout));
            hashMap.put("layout/tips_layout_0", Integer.valueOf(R$layout.tips_layout));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(5);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_guide, 1);
        sparseIntArray.put(R$layout.activity_result_qr_code, 2);
        sparseIntArray.put(R$layout.item_language_menu_pop, 3);
        sparseIntArray.put(R$layout.language_pop_layout, 4);
        sparseIntArray.put(R$layout.tips_layout, 5);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(8);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new RuntimeException("view must have a tag");
            } else if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 3) {
                        if (i2 != 4) {
                            if (i2 == 5) {
                                if ("layout/tips_layout_0".equals(tag)) {
                                    Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 3, (ViewDataBinding.IncludedLayouts) null, TipsLayoutBindingImpl.b);
                                    LinearLayout linearLayout = (LinearLayout) mapBindings[1];
                                    TextView textView = (TextView) mapBindings[2];
                                    ViewDataBinding viewDataBinding = new ViewDataBinding(dataBindingComponent2, view2, 0);
                                    viewDataBinding.a = -1;
                                    ((LinearLayout) mapBindings[0]).setTag((Object) null);
                                    viewDataBinding.setRootTag(view2);
                                    viewDataBinding.invalidateAll();
                                    return viewDataBinding;
                                }
                                throw new IllegalArgumentException(l.a(tag, "The tag for tips_layout is invalid. Received: "));
                            }
                        } else if ("layout/language_pop_layout_0".equals(tag)) {
                            Object[] mapBindings2 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 2, (ViewDataBinding.IncludedLayouts) null, LanguagePopLayoutBindingImpl.c);
                            ViewDataBinding languagePopLayoutBinding = new LanguagePopLayoutBinding(dataBindingComponent2, view2, (RoundRecyclerView) mapBindings2[1]);
                            languagePopLayoutBinding.b = -1;
                            ((RoundConstraintLayout) mapBindings2[0]).setTag((Object) null);
                            languagePopLayoutBinding.setRootTag(view2);
                            languagePopLayoutBinding.invalidateAll();
                            return languagePopLayoutBinding;
                        } else {
                            throw new IllegalArgumentException(l.a(tag, "The tag for language_pop_layout is invalid. Received: "));
                        }
                    } else if ("layout/item_language_menu_pop_0".equals(tag)) {
                        Object[] mapBindings3 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 3, (ViewDataBinding.IncludedLayouts) null, ItemLanguageMenuPopBindingImpl.c);
                        ImageView imageView = (ImageView) mapBindings3[1];
                        ViewDataBinding itemLanguageMenuPopBinding = new ItemLanguageMenuPopBinding(dataBindingComponent2, view2, (TextView) mapBindings3[2]);
                        itemLanguageMenuPopBinding.b = -1;
                        ((ConstraintLayout) mapBindings3[0]).setTag((Object) null);
                        itemLanguageMenuPopBinding.setRootTag(view2);
                        itemLanguageMenuPopBinding.invalidateAll();
                        return itemLanguageMenuPopBinding;
                    } else {
                        throw new IllegalArgumentException(l.a(tag, "The tag for item_language_menu_pop is invalid. Received: "));
                    }
                } else if ("layout/activity_result_qr_code_0".equals(tag)) {
                    Object[] mapBindings4 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 8, (ViewDataBinding.IncludedLayouts) null, ActivityResultQrCodeBindingImpl.f);
                    Guideline guideline = (Guideline) mapBindings4[5];
                    RoundConstraintLayout roundConstraintLayout = (RoundConstraintLayout) mapBindings4[2];
                    TextView textView2 = (TextView) mapBindings4[4];
                    TextView textView3 = (TextView) mapBindings4[1];
                    ActivityResultQrCodeBinding activityResultQrCodeBinding = new ActivityResultQrCodeBinding(dataBindingComponent, view, (ConstraintLayout) mapBindings4[0], (ImageView) mapBindings4[7], (ImageView) mapBindings4[3], (ImageView) mapBindings4[6]);
                    activityResultQrCodeBinding.e = -1;
                    activityResultQrCodeBinding.a.setTag((Object) null);
                    activityResultQrCodeBinding.setRootTag(view2);
                    activityResultQrCodeBinding.invalidateAll();
                    return activityResultQrCodeBinding;
                } else {
                    throw new IllegalArgumentException(l.a(tag, "The tag for activity_result_qr_code is invalid. Received: "));
                }
            } else if ("layout/activity_guide_0".equals(tag)) {
                Object[] mapBindings5 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 4, (ViewDataBinding.IncludedLayouts) null, ActivityGuideBindingImpl.e);
                ActivityGuideBinding activityGuideBinding = new ActivityGuideBinding(dataBindingComponent, view, (ViewPagerIndicator) mapBindings5[3], (ImageView) mapBindings5[2], (ViewPager) mapBindings5[1]);
                activityGuideBinding.d = -1;
                ((ConstraintLayout) mapBindings5[0]).setTag((Object) null);
                activityGuideBinding.setRootTag(view2);
                activityGuideBinding.invalidateAll();
                return activityGuideBinding;
            } else {
                throw new IllegalArgumentException(l.a(tag, "The tag for activity_guide is invalid. Received: "));
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
