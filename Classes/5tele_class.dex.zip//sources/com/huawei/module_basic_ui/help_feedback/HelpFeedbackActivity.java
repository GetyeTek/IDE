package com.huawei.module_basic_ui.help_feedback;

import E0.c;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.google.android.gms.ads.identifier.a;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.MerchantAppIdBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivityHelpFeedbackBinding;
import java.util.HashMap;
import o0.b;

@Route(path = "/basicUiModule/helpAndFeedback")
public class HelpFeedbackActivity extends BaseTitleActivity implements View.OnClickListener {
    public ActivityHelpFeedbackBinding i;

    public final void D0() {
    }

    public final void G0() {
        HelpFeedbackActivity.super.G0();
        O0(R$string.help_feedback);
        this.i.d.setOnClickListener(this);
        this.i.c.setOnClickListener(this);
        this.i.b.setOnClickListener(this);
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.module_basic_ui.help_feedback.HelpFeedbackActivity, android.app.Activity] */
    public final ViewBinding K0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_help_feedback, (ViewGroup) null, false);
        int i2 = R$id.iv_faq;
        if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
            i2 = R$id.iv_logo;
            if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                i2 = R$id.iv_more;
                if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                    i2 = R$id.tv_faq;
                    TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i2);
                    if (textView != null) {
                        i2 = R$id.tv_feedback;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(inflate, i2);
                        if (textView2 != null) {
                            i2 = R$id.tv_help;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(inflate, i2);
                            if (textView3 != null) {
                                ActivityHelpFeedbackBinding activityHelpFeedbackBinding = new ActivityHelpFeedbackBinding(inflate, textView, textView2, textView3);
                                this.i = activityHelpFeedbackBinding;
                                return activityHelpFeedbackBinding;
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [com.huawei.module_basic_ui.help_feedback.HelpFeedbackActivity, android.app.Activity] */
    public void onClick(View view) {
        String str;
        String str2;
        MerchantAppIdBean.FeedbackBean feedback;
        int id = view.getId();
        if (id == R$id.tv_help) {
            BasicConfigResp.StaticPageUrl staticPageUrl = BasicConfig.getInstance().getStaticPageUrl();
            if (staticPageUrl != null) {
                b.d(this, staticPageUrl.getHelpUrl(), (Bundle) null, a.a("from", "login"));
            }
        } else if (id == R$id.tv_faq) {
            BasicConfigResp.StaticPageUrl staticPageUrl2 = BasicConfig.getInstance().getStaticPageUrl();
            if (staticPageUrl2 != null) {
                HashMap hashMap = new HashMap();
                hashMap.put("url", staticPageUrl2.getFAQUrl());
                hashMap.put("from", "login");
                b.d(this, staticPageUrl2.getFAQUrl(), (Bundle) null, hashMap);
            }
        } else if (id != R$id.tv_feedback) {
        } else {
            if (c.g()) {
                MerchantAppIdBean merchantAppIdConfig = BasicConfig.getInstance().getMerchantAppIdConfig();
                if (merchantAppIdConfig != null && (feedback = merchantAppIdConfig.getFeedback()) != null) {
                    String appId = feedback.getAppId();
                    HashMap a = a.a("appId", appId);
                    b.d(this, "merchant://" + appId, (Bundle) null, a);
                    return;
                }
                return;
            }
            MerchantAppIdBean merchantAppIdConfig2 = BasicConfig.getInstance().getMerchantAppIdConfig();
            String str3 = "";
            if (merchantAppIdConfig2 != null) {
                if (merchantAppIdConfig2.getFeedback() == null) {
                    str2 = str3;
                } else {
                    str2 = merchantAppIdConfig2.getFeedback().getH5Url();
                }
                if (merchantAppIdConfig2.getFeedback() != null) {
                    str3 = merchantAppIdConfig2.getFeedback().getAppId();
                }
                str = str3;
                str3 = str2;
            } else {
                str = str3;
            }
            HashMap a2 = com.google.android.gms.measurement.internal.c.a("url", str3, "appId", str);
            a2.put("from", "login");
            b.d(this, str3, (Bundle) null, a2);
        }
    }
}
