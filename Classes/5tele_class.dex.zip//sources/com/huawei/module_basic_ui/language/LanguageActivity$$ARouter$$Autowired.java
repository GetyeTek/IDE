package com.huawei.module_basic_ui.language;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class LanguageActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_basic_ui.language.LanguageActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (LanguageActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.from;
        } else {
            str = r4.getIntent().getExtras().getString("from", r4.from);
        }
        r4.from = str;
    }
}
