package com.huawei.module_basic_ui.language;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;
import com.huawei.module_basic_ui.R$color;
import com.huawei.module_basic_ui.R$id;

public class LanguageDialogFragment extends SelectDialog<LanguageListBean.LanguageBean> {
    public FragmentActivity g;

    public LanguageDialogFragment() {
        throw null;
    }

    public final void onAttach(@NonNull Context context) {
        LanguageDialogFragment.super.onAttach(context);
        this.g = (FragmentActivity) context;
    }

    public final void onDetach() {
        LanguageDialogFragment.super.onDetach();
        this.g.finish();
    }

    public final void x0(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i;
        LanguageListBean.LanguageBean languageBean = (LanguageListBean.LanguageBean) obj;
        LanguageDialogFragment.super.x0(baseViewHolder, languageBean);
        int i2 = R$id.tv_content;
        baseViewHolder.setText(i2, languageBean.getLanguage());
        Context context = baseViewHolder.itemView.getContext();
        if (LanguageUtils.getInstance().getCurrentLang().equals(languageBean.getLanguageCode())) {
            i = R$color.colorPrimary;
        } else {
            i = R$color.colorBlack;
        }
        baseViewHolder.setTextColor(i2, ContextCompat.getColor(context, i));
    }

    public final boolean z0(Object obj) {
        return LanguageUtils.getInstance().getCurrentLang().equals(((LanguageListBean.LanguageBean) obj).getLanguageCode());
    }
}
