package com.huawei.module_basic_ui.language.adapter;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.module_basic_ui.R$color;
import com.huawei.module_basic_ui.R$id;

public class LanguageAdapter extends BaseQuickAdapter<LanguageListBean.LanguageBean, BaseViewHolder> {
    public LanguageAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i;
        LanguageListBean.LanguageBean languageBean = (LanguageListBean.LanguageBean) obj;
        int i2 = R$id.tv_language;
        baseViewHolder.setText(i2, languageBean.getLanguage());
        boolean equals = LanguageUtils.getInstance().getCurrentLang().equals(languageBean.getLanguageCode());
        baseViewHolder.setVisible(R$id.iv_language, equals);
        Application a = J.a();
        if (equals) {
            i = R$color.colorPrimary;
        } else {
            i = R$color.colorBlack;
        }
        baseViewHolder.setTextColor(i2, ContextCompat.getColor(a, i));
    }
}
