package com.huawei.module_basic_ui.language;

import B7.e;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;

public class LanguageViewModel extends BaseViewModel {
    public final e g = new e();
}
