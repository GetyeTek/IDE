package com.huawei.module_basic_ui.language;

import A8.c;
import S1.f;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.k;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.httplib.response.LoginResp;
import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;
import com.huawei.module_basic_ui.R$anim;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import java.util.Map;
import o0.b;

@Route(path = "/basicUiModule/chooseLanguageDialog")
public class LanguageDialogActivity extends AppCompatActivity implements c {
    public static final /* synthetic */ int e = 0;
    public String a;
    public LoadingDialog b;
    public LanguageViewModel c;
    public LanguageListBean.LanguageBean d;

    public class a implements SelectDialog.b<LanguageListBean.LanguageBean> {
        public a() {
        }

        public final void a(Object obj) {
            LanguageListBean.LanguageBean languageBean = (LanguageListBean.LanguageBean) obj;
            int i = LanguageDialogActivity.e;
            P2.a aVar = LanguageDialogActivity.this;
            if (LanguageUtils.getInstance().getCurrentLang().equals(languageBean.getLanguageCode())) {
                aVar.finish();
            } else if ("homepage".equals(aVar.a)) {
                c cVar = new c(aVar);
                cVar.a(H3.c.e().N(com.google.android.gms.ads.identifier.a.a("newLanguage", languageBean.getLanguageCode())), new a(cVar, (P2.a) cVar.a, 0));
                aVar.d = languageBean;
            } else {
                LanguageUtils.getInstance().setLanguage(aVar, languageBean.getLanguageCode());
                aVar.finish();
            }
        }
    }

    public final void G(String str) {
        LoadingDialog loadingDialog = this.b;
        if (loadingDialog != null) {
            loadingDialog.dismiss();
        }
    }

    public final void V(String str) {
        if (this.b == null) {
            this.b = new LoadingDialog();
        }
        this.b.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_basic_ui.language.LanguageDialogActivity, android.app.Activity] */
    public final void finish() {
        LanguageDialogActivity.super.finish();
        int i = R$anim.basic_ui_anim_silent;
        overridePendingTransition(i, i);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, androidx.lifecycle.ViewModelStoreOwner, com.huawei.module_basic_ui.language.LanguageDialogActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        int i = R$anim.basic_ui_anim_silent;
        overridePendingTransition(i, i);
        LanguageDialogActivity.super.onCreate(bundle);
        setContentView(R$layout.layout_transparent);
        this.a = getIntent().getStringExtra("from");
        this.c = new ViewModelProvider(this).get(LanguageViewModel.class);
        new SelectDialog(getString(R$string.baselib_language), LanguageUtils.getInstance().getLanguageConfig(), new a()).show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [R1.a, java.lang.Object] */
    public final void r0(int i, LoginResp loginResp) {
        if (this.d != null) {
            LanguageUtils.getInstance().setLanguage(this, this.d.getLanguageCode());
            if (loginResp != null) {
                f.b.a(this, k.d(loginResp), false);
            }
            I3.c.b();
            Bundle bundle = new Bundle(1);
            bundle.putBoolean("goHome", true);
            b.d(this, "/mainModule/main", bundle, (Map) null);
            overridePendingTransition(0, 0);
        } else {
            finish();
        }
        Q6.b bVar = new Q6.b();
        bVar.a(new Q6.a());
        LanguageViewModel languageViewModel = this.c;
        languageViewModel.c(languageViewModel.g.a(bVar), new Object());
    }

    public final void v(BaseResp baseResp) {
    }
}
