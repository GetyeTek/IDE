package com.huawei.module_basic_ui.language;

import P2.a;
import com.huawei.digitalpayment.customer.httplib.response.LoginResp;

public interface c extends a {
    void r0(int i, LoginResp loginResp);
}
