package com.huawei.module_basic_ui.language;

import R1.a;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;

public final class e implements a {
    public /* synthetic */ void onComplete() {
    }

    public void onError(BaseException baseException) {
    }

    public /* bridge */ /* synthetic */ void onLoading(Object obj) {
        BasicConfigResp basicConfigResp = (BasicConfigResp) obj;
    }

    public /* bridge */ /* synthetic */ void onSuccess(Object obj) {
        BasicConfigResp basicConfigResp = (BasicConfigResp) obj;
    }
}
