package com.huawei.module_basic_ui.language;

import com.huawei.digitalpayment.customer.httplib.response.LoginResp;
import com.huawei.http.b;

public class ChangeLanguageRepository extends b<LoginResp, LoginResp> {
    public final String getApiPath() {
        return "v1/ethiopia/changeLanguage";
    }
}
