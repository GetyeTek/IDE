package com.huawei.module_basic_ui.language;

import L2.b;
import com.huawei.digitalpayment.customer.httplib.response.LoginResp;

public final class a extends b<LoginResp> {
    public final /* synthetic */ int f;
    public final /* synthetic */ b g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(b bVar, P2.a aVar, int i) {
        super(aVar, true);
        this.g = bVar;
        this.f = i;
    }

    public final void b(String str) {
    }

    public final void c(Object obj) {
        ((P2.a) this.g.a).r0(this.f, (LoginResp) obj);
    }
}
