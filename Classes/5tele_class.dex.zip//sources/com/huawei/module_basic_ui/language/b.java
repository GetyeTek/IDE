package com.huawei.module_basic_ui.language;

import A8.c;

public final class b extends c {
}
