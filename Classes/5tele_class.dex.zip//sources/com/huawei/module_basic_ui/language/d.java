package com.huawei.module_basic_ui.language;

import H3.c;
import P2.a;
import android.view.View;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.httplib.response.LoginResp;
import java.util.HashMap;

public final /* synthetic */ class d implements OnItemClickListener {
    public final /* synthetic */ LanguageActivity a;

    public /* synthetic */ d(LanguageActivity languageActivity) {
        this.a = languageActivity;
    }

    public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        int i2 = LanguageActivity.o;
        LanguageActivity languageActivity = this.a;
        if (!LanguageUtils.getInstance().getCurrentLang().equals(languageActivity.l.get(i).getLanguageCode())) {
            LanguageListBean.LanguageBean languageBean = languageActivity.l.get(i);
            if (languageBean == null || "/loginModule/login".equals(languageActivity.from)) {
                languageActivity.V0(i, true, (LoginResp) null);
                return;
            }
            b bVar = languageActivity.i;
            String languageCode = languageBean.getLanguageCode();
            bVar.getClass();
            HashMap hashMap = new HashMap();
            hashMap.put("newLanguage", languageCode);
            bVar.a(c.e().N(hashMap), new a(bVar, (a) bVar.a, i));
        }
    }
}
