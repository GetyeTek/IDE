package com.huawei.module_basic_ui.language;

import A8.c;
import Q6.a;
import S1.f;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.ViewGroup;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import b8.b;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.k;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.httplib.response.LoginResp;
import com.huawei.digitalpayment.customer.viewlib.view.DividerItemDecoration;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.module_basic_ui.R$drawable;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivityLanguageBinding;
import com.huawei.module_basic_ui.language.adapter.LanguageAdapter;
import java.util.List;
import java.util.Map;

@Route(path = "/basicUiModule/chooseLanguage")
public class LanguageActivity extends BaseMvpActivity<b> implements c {
    public static final /* synthetic */ int o = 0;
    @Autowired(name = "from")
    String from;
    public ActivityLanguageBinding j;
    public LanguageAdapter k;
    public List<LanguageListBean.LanguageBean> l;
    public LanguageViewModel m;
    public LoadingDialog n;

    public final void D0() {
    }

    public final void G(String str) {
        this.n.dismiss();
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, com.huawei.module_basic_ui.language.LanguageActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, androidx.lifecycle.ViewModelStoreOwner, androidx.fragment.app.FragmentActivity] */
    public final void G0() {
        LanguageActivity.super.G0();
        O0(R$string.designstandard_language);
        this.m = new ViewModelProvider(this).get(LanguageViewModel.class);
        this.n = new LoadingDialog();
        this.l = LanguageUtils.getInstance().getLanguageConfig();
        this.j.b.setLayoutManager(new LinearLayoutManager(this));
        RecyclerView recyclerView = this.j.b;
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this);
        Drawable drawable = getResources().getDrawable(R$drawable.divider_vertical_drawable);
        if (drawable != null) {
            dividerItemDecoration.a = drawable;
            recyclerView.addItemDecoration(dividerItemDecoration);
            BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_language, this.l);
            this.k = baseQuickAdapter;
            this.j.b.setAdapter(baseQuickAdapter);
            this.k.setOnItemClickListener(new d(this));
            return;
        }
        throw new IllegalArgumentException("Drawable cannot be null.");
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_basic_ui.language.LanguageActivity, android.app.Activity] */
    public final ViewBinding K0() {
        RoundConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_language, (ViewGroup) null, false);
        int i = R$id.rv_recycler_view;
        RecyclerView findChildViewById = ViewBindings.findChildViewById(inflate, i);
        if (findChildViewById != null) {
            ActivityLanguageBinding activityLanguageBinding = new ActivityLanguageBinding(inflate, findChildViewById);
            this.j = activityLanguageBinding;
            return activityLanguageBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
        this.n.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.module_basic_ui.language.LanguageActivity, android.app.Activity] */
    public final void V0(int i, boolean z, LoginResp loginResp) {
        if (!LanguageUtils.getInstance().getCurrentLang().equals(this.l.get(i).getLanguageCode())) {
            LanguageListBean.LanguageBean languageBean = this.l.get(i);
            b.d(LanguageUtils.getInstance().getCurrentLang());
            b.a(LanguageUtils.getInstance().getCurrentLang(), languageBean.getLanguageCode());
            b.b(languageBean.getLanguageCode());
            LanguageUtils.getInstance().setLanguage(this, languageBean.getLanguageCode());
            if (loginResp != null) {
                loginResp.setHasFillQuestion(true);
                f.b.a(this, k.d(loginResp), false);
            }
            Class<AppService> cls = AppService.class;
            o0.b.c(cls).m();
            o0.b.c(cls).i();
            I3.c.b();
            this.k.notifyDataSetChanged();
            if (z) {
                o0.b.d(this, "/loginModule/login", (Bundle) null, (Map) null);
                finish();
            } else {
                Bundle bundle = new Bundle(1);
                bundle.putBoolean("goHome", true);
                o0.b.d(this, "/mainModule/main", bundle, (Map) null);
            }
            overridePendingTransition(0, 0);
            return;
        }
        finish();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [R1.a, java.lang.Object] */
    public final void r0(int i, LoginResp loginResp) {
        V0(i, false, loginResp);
        Q6.b bVar = new Q6.b();
        bVar.a(new a());
        LanguageViewModel languageViewModel = this.m;
        languageViewModel.c(languageViewModel.g.a(bVar), new Object());
    }
}
