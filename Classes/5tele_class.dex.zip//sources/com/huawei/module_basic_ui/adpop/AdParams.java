package com.huawei.module_basic_ui.adpop;

import android.text.TextUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AdParams implements Serializable {
    private static final long serialVersionUID = 1768972802511320702L;
    private String content;
    private String execute;
    private String height;
    private String id;
    private String imgUrl;
    private boolean isToday;
    private String model;
    private String reportTag;
    private int showInterval;
    private int showSeconds;
    private String title;
    private String width;

    public String getContent() {
        return this.content;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getHeight() {
        return this.height;
    }

    public String getId() {
        return this.id;
    }

    public String getImgUrl() {
        return this.imgUrl;
    }

    public String getModel() {
        return this.model;
    }

    public List<String> getReportParams() {
        if (TextUtils.isEmpty(this.reportTag)) {
            return new ArrayList();
        }
        return Arrays.asList(this.reportTag.split("&"));
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public int getShowInterval() {
        return this.showInterval;
    }

    public int getShowSeconds() {
        return this.showSeconds;
    }

    public String getTitle() {
        return this.title;
    }

    public String getWidth() {
        return this.width;
    }

    public boolean isToday() {
        return this.isToday;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setHeight(String str) {
        this.height = str;
    }

    public void setId(String str) {
        this.id = str;
    }

    public void setImgUrl(String str) {
        this.imgUrl = str;
    }

    public void setModel(String str) {
        this.model = str;
    }

    public void setReportTag(String str) {
        this.reportTag = str;
    }

    public void setShowInterval(int i) {
        this.showInterval = i;
    }

    public void setShowSeconds(int i) {
        this.showSeconds = i;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public void setToday(boolean z) {
        this.isToday = z;
    }

    public void setWidth(String str) {
        this.width = str;
    }
}
