package com.huawei.module_basic_ui.adpop;

import J6.c;
import R9.h;
import W2.n;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import java.util.Timer;
import java.util.TimerTask;

public class AdDialog extends BaseDialog {
    public Timer c;
    public AdParams d;

    public class a extends TimerTask {
        public a() {
        }

        public final void run() {
            AdDialog.this.dismiss();
        }
    }

    public class b implements CompoundButton.OnCheckedChangeListener {
        public b() {
        }

        public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            String e = n.b("").e("recent_login_phone_number");
            AdDialog adDialog = AdDialog.this;
            String id = adDialog.d.getId();
            n b = n.b("");
            b.h(e + id, z);
            if (z) {
                adDialog.dismiss();
            }
        }
    }

    public final void dismiss() {
        AdDialog.super.dismiss();
        Timer timer = this.c;
        if (timer != null) {
            timer.cancel();
        }
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        return layoutInflater.inflate(v0(), viewGroup, false);
    }

    public final void onStart() {
        Window window;
        AdDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(17);
            window.setLayout((BaseDialog.w0(window) * 8) / 10, -1);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        int i;
        AdDialog.super.onViewCreated(view, bundle);
        if (this.d == null) {
            dismiss();
            return;
        }
        ImageView imageView = (ImageView) view.findViewById(R$id.iv_advertisement);
        ImageView imageView2 = (ImageView) view.findViewById(R$id.iv_close);
        CheckBox checkBox = (CheckBox) view.findViewById(R$id.cb_ad_check);
        TextView textView = (TextView) view.findViewById(R$id.tv_no_popup);
        LinearLayout linearLayout = (LinearLayout) view.findViewById(R$id.ll_popup_container);
        if (!TextUtils.isEmpty(this.d.getHeight()) && !TextUtils.isEmpty(this.d.getWidth())) {
            int a2 = h.a(getActivity(), (float) Integer.parseInt(this.d.getWidth()));
            int a3 = h.a(getActivity(), (float) Integer.parseInt(this.d.getHeight()));
            if ("1".equals(this.d.getModel())) {
                imageView.setLayoutParams(new LinearLayout.LayoutParams(a2, a3));
            } else {
                ConstraintLayout.LayoutParams layoutParams = imageView.getLayoutParams();
                layoutParams.width = a2;
                layoutParams.height = a3;
                imageView.setLayoutParams(layoutParams);
            }
            imageView.setMaxHeight(0);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        }
        if ("1".equals(this.d.getModel())) {
            imageView.setOnClickListener(new J6.a(this, 0));
        } else {
            ((TextView) view.findViewById(R$id.tv_title)).setText(this.d.getTitle());
            ((TextView) view.findViewById(R$id.tv_content)).setText(this.d.getContent());
            view.findViewById(R$id.lb_confirm).setOnClickListener(new J6.b(this, 0));
        }
        Timer timer = new Timer();
        this.c = timer;
        timer.schedule(new a(), (long) (this.d.getShowSeconds() * 1000));
        if (imageView2 != null) {
            imageView2.setOnClickListener(new c(this, 0));
        }
        if (checkBox != null) {
            checkBox.setOnCheckedChangeListener(new b());
            linearLayout.setOnClickListener(new F3.a(checkBox, 1));
        }
        Context context = getContext();
        if (this.d.isToday()) {
            i = R$string.do_not_popup_today;
        } else {
            i = R$string.do_not_popup_again;
        }
        textView.setText(context.getString(i));
        FragmentActivity activity = getActivity();
        com.bumptech.glide.c.d(activity).e(activity).load(this.d.getImgUrl()).into(imageView);
    }

    public final int v0() {
        if ("1".equals(this.d.getModel())) {
            return R$layout.ad_dialog_pic;
        }
        return R$layout.basic_layout_ad_dialog;
    }
}
