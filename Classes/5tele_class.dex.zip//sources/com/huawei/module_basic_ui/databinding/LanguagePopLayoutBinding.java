package com.huawei.module_basic_ui.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundRecyclerView;

public abstract class LanguagePopLayoutBinding extends ViewDataBinding {
    @NonNull
    public final RoundRecyclerView a;

    public LanguagePopLayoutBinding(DataBindingComponent dataBindingComponent, View view, RoundRecyclerView roundRecyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = roundRecyclerView;
    }
}
