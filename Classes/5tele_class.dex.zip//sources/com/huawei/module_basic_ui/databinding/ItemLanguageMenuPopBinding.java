package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class ItemLanguageMenuPopBinding extends ViewDataBinding {
    @NonNull
    public final TextView a;

    public ItemLanguageMenuPopBinding(DataBindingComponent dataBindingComponent, View view, TextView textView) {
        super(dataBindingComponent, view, 0);
        this.a = textView;
    }
}
