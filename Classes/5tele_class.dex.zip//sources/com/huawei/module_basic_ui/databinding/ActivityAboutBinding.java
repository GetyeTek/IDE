package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundImageView;

public final class ActivityAboutBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final RoundImageView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final TextView e;

    public ActivityAboutBinding(@NonNull ConstraintLayout constraintLayout, @NonNull LoadingButton loadingButton, @NonNull RoundImageView roundImageView, @NonNull ImageView imageView, @NonNull TextView textView) {
        this.a = constraintLayout;
        this.b = loadingButton;
        this.c = roundImageView;
        this.d = imageView;
        this.e = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
