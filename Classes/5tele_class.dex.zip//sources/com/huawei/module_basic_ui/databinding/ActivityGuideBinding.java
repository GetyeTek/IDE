package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager.widget.ViewPager;
import com.huawei.common.widget.viewpager.ViewPagerIndicator;

public abstract class ActivityGuideBinding extends ViewDataBinding {
    @NonNull
    public final ViewPagerIndicator a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final ViewPager c;

    public ActivityGuideBinding(DataBindingComponent dataBindingComponent, View view, ViewPagerIndicator viewPagerIndicator, ImageView imageView, ViewPager viewPager) {
        super(dataBindingComponent, view, 0);
        this.a = viewPagerIndicator;
        this.b = imageView;
        this.c = viewPager;
    }
}
