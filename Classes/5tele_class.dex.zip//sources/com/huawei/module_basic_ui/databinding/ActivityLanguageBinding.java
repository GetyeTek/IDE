package com.huawei.module_basic_ui.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;

public final class ActivityLanguageBinding implements ViewBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final RecyclerView b;

    public ActivityLanguageBinding(@NonNull RoundConstraintLayout roundConstraintLayout, @NonNull RecyclerView recyclerView) {
        this.a = roundConstraintLayout;
        this.b = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
