package com.huawei.module_basic_ui.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class TipsLayoutBinding extends ViewDataBinding {
}
