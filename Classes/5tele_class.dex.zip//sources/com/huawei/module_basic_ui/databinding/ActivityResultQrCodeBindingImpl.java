package com.huawei.module_basic_ui.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.module_basic_ui.R$id;

public class ActivityResultQrCodeBindingImpl extends ActivityResultQrCodeBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.tv_title, 1);
        sparseIntArray.put(R$id.rl_qr_code, 2);
        sparseIntArray.put(R$id.iv_qr_code, 3);
        sparseIntArray.put(R$id.tv_tips, 4);
        sparseIntArray.put(R$id.guideline, 5);
        sparseIntArray.put(R$id.iv_share, 6);
        sparseIntArray.put(R$id.iv_download, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
