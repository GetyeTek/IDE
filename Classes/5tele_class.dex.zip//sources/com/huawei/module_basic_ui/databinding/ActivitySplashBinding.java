package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ActivitySplashBinding implements ViewBinding {
    @NonNull
    public final RelativeLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final ImageView c;

    public ActivitySplashBinding(@NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull ImageView imageView) {
        this.a = relativeLayout;
        this.b = textView;
        this.c = imageView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
