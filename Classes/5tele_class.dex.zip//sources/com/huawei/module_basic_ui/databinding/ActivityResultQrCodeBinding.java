package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class ActivityResultQrCodeBinding extends ViewDataBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final ImageView d;

    public ActivityResultQrCodeBinding(DataBindingComponent dataBindingComponent, View view, ConstraintLayout constraintLayout, ImageView imageView, ImageView imageView2, ImageView imageView3) {
        super(dataBindingComponent, view, 0);
        this.a = constraintLayout;
        this.b = imageView;
        this.c = imageView2;
        this.d = imageView3;
    }
}
