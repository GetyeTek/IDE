package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ActivityMyBalanceBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final TextView e;

    public ActivityMyBalanceBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull ImageView imageView, @NonNull TextView textView3) {
        this.a = linearLayout;
        this.b = textView;
        this.c = textView2;
        this.d = imageView;
        this.e = textView3;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
