package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ActivityAppShareBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;

    public ActivityAppShareBinding(@NonNull LinearLayout linearLayout) {
        this.a = linearLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
