package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public final class ActivitySuccessCommonBinding implements ViewBinding {
    @NonNull
    public final TextView A;
    @NonNull
    public final TextView B;
    @NonNull
    public final TextView C;
    @NonNull
    public final TextView H;
    @NonNull
    public final TextView L;
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final Button b;
    @NonNull
    public final Button c;
    @NonNull
    public final ConstraintLayout d;
    @NonNull
    public final ConstraintLayout e;
    @NonNull
    public final ConstraintLayout f;
    @NonNull
    public final ConstraintLayout g;
    @NonNull
    public final ConstraintLayout h;
    @NonNull
    public final CycleViewPager i;
    @NonNull
    public final View j;
    @NonNull
    public final ImageView k;
    @NonNull
    public final ImageView l;
    @NonNull
    public final ImageView m;
    @NonNull
    public final ImageView n;
    @NonNull
    public final ImageView o;
    @NonNull
    public final LinearLayout p;
    @NonNull
    public final LinearLayout q;
    @NonNull
    public final LinearLayout r;
    @NonNull
    public final HFRecyclerView s;
    @NonNull
    public final View t;
    @NonNull
    public final TextView u;
    @NonNull
    public final TextView v;
    @NonNull
    public final TextView w;
    @NonNull
    public final TextView x;
    @NonNull
    public final TextView y;
    @NonNull
    public final TextView z;

    public ActivitySuccessCommonBinding(@NonNull ConstraintLayout constraintLayout, @NonNull Button button, @NonNull Button button2, @NonNull ConstraintLayout constraintLayout2, @NonNull ConstraintLayout constraintLayout3, @NonNull ConstraintLayout constraintLayout4, @NonNull ConstraintLayout constraintLayout5, @NonNull ConstraintLayout constraintLayout6, @NonNull CycleViewPager cycleViewPager, @NonNull View view, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull ImageView imageView3, @NonNull ImageView imageView4, @NonNull ImageView imageView5, @NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull LinearLayout linearLayout3, @NonNull HFRecyclerView hFRecyclerView, @NonNull View view2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11) {
        this.a = constraintLayout;
        this.b = button;
        this.c = button2;
        this.d = constraintLayout2;
        this.e = constraintLayout3;
        this.f = constraintLayout4;
        this.g = constraintLayout5;
        this.h = constraintLayout6;
        this.i = cycleViewPager;
        this.j = view;
        this.k = imageView;
        this.l = imageView2;
        this.m = imageView3;
        this.n = imageView4;
        this.o = imageView5;
        this.p = linearLayout;
        this.q = linearLayout2;
        this.r = linearLayout3;
        this.s = hFRecyclerView;
        this.t = view2;
        this.u = textView;
        this.v = textView2;
        this.w = textView3;
        this.x = textView4;
        this.y = textView5;
        this.z = textView6;
        this.A = textView7;
        this.B = textView8;
        this.C = textView9;
        this.H = textView10;
        this.L = textView11;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
