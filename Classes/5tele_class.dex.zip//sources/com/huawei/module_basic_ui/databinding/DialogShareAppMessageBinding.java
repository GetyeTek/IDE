package com.huawei.module_basic_ui.databinding;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.customer.viewlib.view.CommonInputView;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class DialogShareAppMessageBinding implements ViewBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final CommonInputView b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final LoadingButton d;
    @NonNull
    public final RoundTextView e;

    public DialogShareAppMessageBinding(@NonNull RoundConstraintLayout roundConstraintLayout, @NonNull CommonInputView commonInputView, @NonNull ImageView imageView, @NonNull LoadingButton loadingButton, @NonNull RoundTextView roundTextView) {
        this.a = roundConstraintLayout;
        this.b = commonInputView;
        this.c = imageView;
        this.d = loadingButton;
        this.e = roundTextView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
