package com.huawei.module_basic_ui.splash.adapter;

import android.view.View;
import android.view.ViewGroup;
import androidx.viewpager.widget.PagerAdapter;
import java.util.ArrayList;

public class ViewPagerAdapter extends PagerAdapter {
    public ArrayList a;

    public ViewPagerAdapter() {
        throw null;
    }

    public final void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((View) this.a.get(i));
    }

    public final int getCount() {
        return this.a.size();
    }

    public final Object instantiateItem(ViewGroup viewGroup, int i) {
        ArrayList arrayList = this.a;
        viewGroup.addView((View) arrayList.get(i));
        return arrayList.get(i);
    }

    public final boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }
}
