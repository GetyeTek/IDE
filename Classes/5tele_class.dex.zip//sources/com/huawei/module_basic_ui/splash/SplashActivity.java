package com.huawei.module_basic_ui.splash;

import B7.e;
import C2.b;
import E0.c;
import G0.o;
import L3.a;
import P6.h;
import P6.j;
import T2.i;
import W2.f;
import W2.n;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.blankj.utilcode.util.A;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.OpenPageImg;
import com.huawei.digitalpayment.customer.httplib.request.BasicConfigRequest;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.databinding.ActivitySplashBinding;
import com.huawei.module_basic_ui.splash.viewmodel.SplashViewModel;
import java.util.HashMap;
import java.util.Map;

public class SplashActivity extends BaseActivity {
    public static final /* synthetic */ int h = 0;
    public ActivitySplashBinding d;
    public SplashViewModel e;
    public h f;
    public boolean g;

    /* JADX WARNING: type inference failed for: r7v0, types: [com.huawei.module_basic_ui.splash.SplashActivity, android.app.Activity] */
    public final ViewBinding C0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_splash, (ViewGroup) null, false);
        int i = R$id.btn_skip;
        TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
        if (textView != null) {
            i = R$id.iv_splash;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i);
            if (imageView != null) {
                RelativeLayout relativeLayout = (RelativeLayout) inflate;
                int i2 = R$id.vp_viewpager;
                if (ViewBindings.findChildViewById(inflate, i2) != null) {
                    this.d = new ActivitySplashBinding(relativeLayout, textView, imageView);
                    return null;
                }
                i = i2;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [R1.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v3, types: [R1.a, java.lang.Object] */
    public final void D0() {
        SplashViewModel splashViewModel = new ViewModelProvider(this).get(SplashViewModel.class);
        this.e = splashViewModel;
        b bVar = splashViewModel.g;
        bVar.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("termsVersion", n.b("").e("TERMS_VERSION"));
        hashMap.put("signKeyVersion", a.a.getSignKeyVersion());
        hashMap.put("pinKeyVersion", a.b.getPinKeyVersion());
        splashViewModel.c(new i(bVar, hashMap, new MutableLiveData((Object) null)).a, new Object());
        SplashViewModel splashViewModel2 = this.e;
        e eVar = splashViewModel2.h;
        eVar.getClass();
        BasicConfigRequest basicConfigRequest = new BasicConfigRequest();
        Q6.b bVar2 = new Q6.b();
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        bVar2.a(new Q6.a());
        basicConfigRequest.setConfigTypes(bVar2.b());
        splashViewModel2.c(new S6.a(eVar, basicConfigRequest, new MutableLiveData((Object) null), bVar2).a, new Object());
        if (TextUtils.equals(BasicConfig.getInstance().getLoginMode(), "1")) {
            c.d();
        }
        if (n.b("").a.getBoolean("is_first_login", true)) {
            startActivity(new Intent(this, GuideActivity.class));
            finish();
            return;
        }
        OpenPageImg openPageImg = (OpenPageImg) f.a(n.b("").e("open_page_img"), OpenPageImg.class);
        if (openPageImg == null || TextUtils.isEmpty(openPageImg.getImgUrl()) || openPageImg.getExpireTime() <= System.currentTimeMillis()) {
            K0();
        } else {
            runOnUiThread(new o(1, this, openPageImg));
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.module_basic_ui.splash.SplashActivity, android.app.Activity] */
    public final void K0() {
        if (!c.g() || !n.b("").a("IS_AUTO_LOGIN_TO_MAIN") || TextUtils.equals(BasicConfig.getInstance().getLoginMode(), "1")) {
            o0.b.d(this, "/mainModule/main", (Bundle) null, (Map) null);
            A.h(new j(this), 50);
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putBoolean("autoLogin", true);
        o0.b.d(this, "/mainModule/main", bundle, (Map) null);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_basic_ui.splash.SplashActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        getWindow().setBackgroundDrawable((Drawable) null);
        SplashActivity.super.onCreate(bundle);
        setContentView(this.d.a);
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.d.b.getLayoutParams();
        layoutParams.topMargin = com.blankj.utilcode.util.f.c();
        this.d.b.setLayoutParams(layoutParams);
        com.blankj.utilcode.util.f.g(getWindow());
        com.blankj.utilcode.util.f.f(this, true);
    }

    public final void onDestroy() {
        SplashActivity.super.onDestroy();
        h hVar = this.f;
        if (hVar != null) {
            hVar.cancel();
            this.g = true;
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.module_basic_ui.splash.SplashActivity, android.app.Activity] */
    public void onViewClick(View view) {
        com.blankj.utilcode.util.f.f(this, false);
    }

    public final void G0() {
    }
}
