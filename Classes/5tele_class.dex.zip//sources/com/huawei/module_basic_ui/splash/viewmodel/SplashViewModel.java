package com.huawei.module_basic_ui.splash.viewmodel;

import B7.e;
import C2.b;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;

public class SplashViewModel extends BaseViewModel {
    public final b g = new b();
    public final e h = new e();
}
