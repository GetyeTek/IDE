package com.huawei.module_basic_ui.splash;

import P6.b;
import P6.c;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.v;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$mipmap;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivityGuideBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.ArrayList;

public class GuideActivity extends DataBindingActivity<ActivityGuideBinding, ViewModel> implements Runnable {
    public static final /* synthetic */ int g = 0;
    public final int[] d = {R$mipmap.guide_post_one, R$mipmap.guide_post_two, R$mipmap.guide_post_third, R$mipmap.guide_post_four};
    public final int[] e = {R$string.login_welcome, R$string.guide_biometric_athentication, R$string.financial_service_for_all, R$string.all_in_one_app};
    public final int[] f = {R$string.space, R$string.guide_biometric_athentication_small, R$string.financial_service_for_all_small, R$string.all_in_one_app_small};

    public class a implements ViewPager.OnPageChangeListener {
        public a() {
        }

        public final void onPageScrollStateChanged(int i) {
        }

        public final void onPageScrolled(int i, float f, int i2) {
        }

        public final void onPageSelected(int i) {
            GuideActivity guideActivity = GuideActivity.this;
            if (i == guideActivity.d.length - 1) {
                guideActivity.b.b.setVisibility(8);
            } else {
                guideActivity.b.b.setVisibility(0);
            }
        }
    }

    public final int C0() {
        return R$layout.activity_guide;
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [android.content.Context, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, java.lang.Runnable, com.huawei.module_basic_ui.splash.GuideActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        int i;
        GuideActivity.super.onCreate(bundle);
        f.e(this, 0, false);
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (true) {
            int[] iArr = this.d;
            if (i2 < iArr.length) {
                View inflate = LayoutInflater.from(this).inflate(R$layout.activity_item_guide_new, (ViewGroup) null);
                ImageView imageView = (ImageView) inflate.findViewById(R$id.iv_post);
                TextView textView = (TextView) inflate.findViewById(R$id.tv_text_big);
                if (i2 == 0) {
                    imageView.getLayoutParams().setMargins(0, v.a(140.0f), 0, 0);
                    ((RelativeLayout.LayoutParams) textView.getLayoutParams()).setMargins(0, v.a(90.0f), 0, 0);
                }
                textView.setText(getString(this.e[i2]));
                textView.setVisibility(0);
                TextView textView2 = (TextView) inflate.findViewById(R$id.tv_text_small);
                int[] iArr2 = this.f;
                textView2.setText(getString(iArr2[i2]));
                if (TextUtils.isEmpty(getString(iArr2[i2]))) {
                    i = 8;
                } else {
                    i = 0;
                }
                textView2.setVisibility(i);
                if (i2 == 3) {
                    TextView textView3 = (TextView) inflate.findViewById(R$id.tv_start);
                    textView3.setText(getString(R$string.designstandard_next).toUpperCase());
                    textView3.setOnClickListener(new P6.a(this, 0));
                    textView3.setVisibility(0);
                }
                imageView.setImageResource(iArr[i2]);
                arrayList.add(inflate);
                i2++;
            } else {
                ViewPager viewPager = this.b.c;
                PagerAdapter pagerAdapter = new PagerAdapter();
                pagerAdapter.a = arrayList;
                viewPager.setAdapter(pagerAdapter);
                ActivityGuideBinding activityGuideBinding = this.b;
                activityGuideBinding.a.a(activityGuideBinding.c);
                this.b.c.addOnPageChangeListener(new a());
                this.b.b.setOnClickListener(new b(this, 0));
                A.h(this, 3000);
                this.b.c.setOnTouchListener(new c(this));
                return;
            }
        }
    }

    public final void onDestroy() {
        A.a.removeCallbacks(this);
        GuideActivity.super.onDestroy();
    }

    public final void run() {
        int[] iArr = this.d;
        int min = Math.min(this.b.c.getCurrentItem() + 1, iArr.length - 1);
        this.b.c.setCurrentItem(min);
        if (min < iArr.length - 1) {
            A.h(this, 3000);
        }
    }
}
