package com.huawei.module_basic_ui.splash;

import com.google.gson.reflect.TypeToken;
import java.util.List;

class a extends TypeToken<List<String>> {
}
