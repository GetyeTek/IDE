package com.huawei.module_basic_ui.splash;

import androidx.appcompat.app.AppCompatActivity;
import com.alibaba.android.arouter.facade.annotation.Route;
import o0.a;

@Route(path = "/basicUiModule/launcher")
@a("launcher")
public class LauncherActivity extends AppCompatActivity {
    public static final /* synthetic */ int a = 0;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: java.lang.Process} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v5, resolved type: java.io.BufferedReader} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v8, resolved type: java.io.DataOutputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v10, resolved type: java.io.BufferedReader} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v15, resolved type: java.io.BufferedReader} */
    /* JADX WARNING: type inference failed for: r5v0 */
    /* JADX WARNING: type inference failed for: r5v1, types: [java.io.OutputStream] */
    /* JADX WARNING: type inference failed for: r8v2, types: [java.io.OutputStream] */
    /* JADX WARNING: type inference failed for: r5v4 */
    /* JADX WARNING: type inference failed for: r5v5 */
    /* JADX WARNING: type inference failed for: r8v11 */
    /* JADX WARNING: type inference failed for: r8v12 */
    /* JADX WARNING: type inference failed for: r8v14 */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x0173, code lost:
        r5.destroy();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:107:0x0178, code lost:
        if (0 == 0) goto L_0x017b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:108:0x017b, code lost:
        r0 = P6.g.a(r16);
        r2 = android.os.Build.TAGS;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:0x0181, code lost:
        if (r0 != false) goto L_0x018c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x0183, code lost:
        if (r2 == null) goto L_0x018c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x0189, code lost:
        if (r2.contains("test-keys") == false) goto L_0x018c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:114:0x0197, code lost:
        if (new java.io.File("/system/app/Superuser.apk").exists() == false) goto L_0x019a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x019a, code lost:
        r2 = new java.io.File("/system/xbin/su");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x01a1, code lost:
        if (r0 != false) goto L_0x01ab;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:118:0x01a7, code lost:
        if (r2.exists() == false) goto L_0x01ab;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:0x01ab, code lost:
        r0 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:0x0106, code lost:
        if (r7 == null) goto L_0x0109;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x01af A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x01b3 A[SYNTHETIC, Splitter:B:124:0x01b3] */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x01be A[SYNTHETIC, Splitter:B:129:0x01be] */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x01c9 A[SYNTHETIC, Splitter:B:134:0x01c9] */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x01d4  */
    /* JADX WARNING: Removed duplicated region for block: B:147:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x00e7 A[SYNTHETIC, Splitter:B:72:0x00e7] */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x00f2 A[SYNTHETIC, Splitter:B:77:0x00f2] */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x00fd A[SYNTHETIC, Splitter:B:82:0x00fd] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean C0() {
        /*
            r16 = this;
            r1 = 1
            java.lang.String r2 = "su"
            java.lang.String r0 = "com.topjohnwu.magisk"
            r3 = 0
            android.content.pm.PackageManager r4 = r16.getPackageManager()     // Catch:{ NameNotFoundException -> 0x000e }
            r4.getApplicationInfo(r0, r3)     // Catch:{ NameNotFoundException -> 0x000e }
            return r1
        L_0x000e:
            java.lang.String r0 = com.blankj.utilcode.util.u.a
            java.lang.String r0 = "echo root"
            java.lang.String[] r0 = new java.lang.String[]{r0}
            java.lang.String r4 = "UTF-8"
            r5 = 0
            r6 = -1
            java.lang.Runtime r7 = java.lang.Runtime.getRuntime()     // Catch:{ Exception -> 0x00de, all -> 0x00d9 }
            java.lang.Process r7 = r7.exec(r2, r5, r5)     // Catch:{ Exception -> 0x00de, all -> 0x00d9 }
            java.io.DataOutputStream r8 = new java.io.DataOutputStream     // Catch:{ Exception -> 0x00d4, all -> 0x00ce }
            java.io.OutputStream r9 = r7.getOutputStream()     // Catch:{ Exception -> 0x00d4, all -> 0x00ce }
            r8.<init>(r9)     // Catch:{ Exception -> 0x00d4, all -> 0x00ce }
            r9 = 0
        L_0x002c:
            java.lang.String r10 = com.blankj.utilcode.util.u.a
            if (r9 >= r1) goto L_0x0050
            r11 = r0[r9]     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            if (r11 != 0) goto L_0x0035
            goto L_0x0042
        L_0x0035:
            byte[] r11 = r11.getBytes()     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r8.write(r11)     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r8.writeBytes(r10)     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r8.flush()     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
        L_0x0042:
            int r9 = r9 + r1
            goto L_0x002c
        L_0x0044:
            r0 = move-exception
            r1 = r0
            r9 = r5
            r10 = r9
        L_0x0048:
            r5 = r8
            goto L_0x01b1
        L_0x004b:
            r0 = move-exception
            r9 = r5
        L_0x004d:
            r10 = r9
            goto L_0x00e2
        L_0x0050:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r0.<init>()     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            java.lang.String r9 = "exit"
            r0.append(r9)     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r0.append(r10)     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r8.writeBytes(r0)     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r8.flush()     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            int r6 = r7.waitFor()     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            java.io.BufferedReader r9 = new java.io.BufferedReader     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            java.io.InputStreamReader r0 = new java.io.InputStreamReader     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            java.io.InputStream r10 = r7.getInputStream()     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r0.<init>(r10, r4)     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            r9.<init>(r0)     // Catch:{ Exception -> 0x004b, all -> 0x0044 }
            java.io.BufferedReader r10 = new java.io.BufferedReader     // Catch:{ Exception -> 0x00cb, all -> 0x00c6 }
            java.io.InputStreamReader r0 = new java.io.InputStreamReader     // Catch:{ Exception -> 0x00cb, all -> 0x00c6 }
            java.io.InputStream r11 = r7.getErrorStream()     // Catch:{ Exception -> 0x00cb, all -> 0x00c6 }
            r0.<init>(r11, r4)     // Catch:{ Exception -> 0x00cb, all -> 0x00c6 }
            r10.<init>(r0)     // Catch:{ Exception -> 0x00cb, all -> 0x00c6 }
            java.lang.String r0 = r9.readLine()     // Catch:{ Exception -> 0x0097 }
            if (r0 == 0) goto L_0x009a
        L_0x008d:
            java.lang.String r0 = r9.readLine()     // Catch:{ Exception -> 0x0097 }
            if (r0 == 0) goto L_0x009a
            goto L_0x008d
        L_0x0094:
            r0 = move-exception
            r1 = r0
            goto L_0x0048
        L_0x0097:
            r0 = move-exception
            goto L_0x00e2
        L_0x009a:
            java.lang.String r0 = r10.readLine()     // Catch:{ Exception -> 0x0097 }
            if (r0 == 0) goto L_0x00a7
        L_0x00a0:
            java.lang.String r0 = r10.readLine()     // Catch:{ Exception -> 0x0097 }
            if (r0 == 0) goto L_0x00a7
            goto L_0x00a0
        L_0x00a7:
            r8.close()     // Catch:{ IOException -> 0x00ab }
            goto L_0x00b0
        L_0x00ab:
            r0 = move-exception
            r4 = r0
            r4.printStackTrace()
        L_0x00b0:
            r9.close()     // Catch:{ IOException -> 0x00b4 }
            goto L_0x00b9
        L_0x00b4:
            r0 = move-exception
            r4 = r0
            r4.printStackTrace()
        L_0x00b9:
            r10.close()     // Catch:{ IOException -> 0x00bd }
            goto L_0x00c2
        L_0x00bd:
            r0 = move-exception
            r4 = r0
            r4.printStackTrace()
        L_0x00c2:
            r7.destroy()
            goto L_0x0109
        L_0x00c6:
            r0 = move-exception
            r1 = r0
            r10 = r5
            goto L_0x0048
        L_0x00cb:
            r0 = move-exception
            r10 = r5
            goto L_0x00e2
        L_0x00ce:
            r0 = move-exception
            r1 = r0
            r9 = r5
        L_0x00d1:
            r10 = r9
            goto L_0x01b1
        L_0x00d4:
            r0 = move-exception
            r8 = r5
        L_0x00d6:
            r9 = r8
            goto L_0x004d
        L_0x00d9:
            r0 = move-exception
            r1 = r0
            r7 = r5
            r9 = r7
            goto L_0x00d1
        L_0x00de:
            r0 = move-exception
            r7 = r5
            r8 = r7
            goto L_0x00d6
        L_0x00e2:
            r0.printStackTrace()     // Catch:{ all -> 0x0094 }
            if (r8 == 0) goto L_0x00f0
            r8.close()     // Catch:{ IOException -> 0x00eb }
            goto L_0x00f0
        L_0x00eb:
            r0 = move-exception
            r4 = r0
            r4.printStackTrace()
        L_0x00f0:
            if (r9 == 0) goto L_0x00fb
            r9.close()     // Catch:{ IOException -> 0x00f6 }
            goto L_0x00fb
        L_0x00f6:
            r0 = move-exception
            r4 = r0
            r4.printStackTrace()
        L_0x00fb:
            if (r10 == 0) goto L_0x0106
            r10.close()     // Catch:{ IOException -> 0x0101 }
            goto L_0x0106
        L_0x0101:
            r0 = move-exception
            r4 = r0
            r4.printStackTrace()
        L_0x0106:
            if (r7 == 0) goto L_0x0109
            goto L_0x00c2
        L_0x0109:
            if (r6 != 0) goto L_0x010d
            r0 = 1
            goto L_0x010e
        L_0x010d:
            r0 = 0
        L_0x010e:
            if (r0 != 0) goto L_0x01b0
            java.lang.String r0 = android.os.Build.TAGS
            java.lang.String r4 = "test-keys"
            if (r0 == 0) goto L_0x011e
            boolean r0 = r0.contains(r4)
            if (r0 == 0) goto L_0x011e
            goto L_0x01a9
        L_0x011e:
            java.lang.String r12 = "/system/sd/xbin/su"
            java.lang.String r13 = "/system/bin/failsafe/su"
            java.lang.String r6 = "/system/app/Superuser.apk"
            java.lang.String r7 = "/sbin/su"
            java.lang.String r8 = "/system/bin/su"
            java.lang.String r9 = "/system/xbin/su"
            java.lang.String r10 = "/data/local/xbin/su"
            java.lang.String r11 = "/data/local/bin/su"
            java.lang.String r14 = "/data/local/su"
            java.lang.String r15 = "/su/bin/su"
            java.lang.String[] r0 = new java.lang.String[]{r6, r7, r8, r9, r10, r11, r12, r13, r14, r15}
            r6 = 0
        L_0x0137:
            r7 = 10
            if (r6 >= r7) goto L_0x014b
            r7 = r0[r6]
            java.io.File r8 = new java.io.File
            r8.<init>(r7)
            boolean r7 = r8.exists()
            if (r7 == 0) goto L_0x0149
            goto L_0x01a9
        L_0x0149:
            int r6 = r6 + r1
            goto L_0x0137
        L_0x014b:
            java.lang.Runtime r0 = java.lang.Runtime.getRuntime()     // Catch:{ all -> 0x0177 }
            java.lang.String r6 = "/system/xbin/which"
            java.lang.String[] r2 = new java.lang.String[]{r6, r2}     // Catch:{ all -> 0x0177 }
            java.lang.Process r5 = r0.exec(r2)     // Catch:{ all -> 0x0177 }
            java.io.BufferedReader r0 = new java.io.BufferedReader     // Catch:{ all -> 0x0177 }
            java.io.InputStreamReader r2 = new java.io.InputStreamReader     // Catch:{ all -> 0x0177 }
            java.io.InputStream r6 = r5.getInputStream()     // Catch:{ all -> 0x0177 }
            java.nio.charset.Charset r7 = java.nio.charset.StandardCharsets.UTF_8     // Catch:{ all -> 0x0177 }
            r2.<init>(r6, r7)     // Catch:{ all -> 0x0177 }
            r0.<init>(r2)     // Catch:{ all -> 0x0177 }
            java.lang.String r0 = r0.readLine()     // Catch:{ all -> 0x0177 }
            if (r0 == 0) goto L_0x0173
            r5.destroy()
            goto L_0x01a9
        L_0x0173:
            r5.destroy()
            goto L_0x017b
        L_0x0177:
            if (r5 == 0) goto L_0x017b
            goto L_0x0173
        L_0x017b:
            boolean r0 = P6.g.a(r16)
            java.lang.String r2 = android.os.Build.TAGS
            if (r0 != 0) goto L_0x018c
            if (r2 == 0) goto L_0x018c
            boolean r2 = r2.contains(r4)
            if (r2 == 0) goto L_0x018c
            goto L_0x01a9
        L_0x018c:
            java.io.File r2 = new java.io.File
            java.lang.String r4 = "/system/app/Superuser.apk"
            r2.<init>(r4)
            boolean r2 = r2.exists()
            if (r2 == 0) goto L_0x019a
            goto L_0x01a9
        L_0x019a:
            java.io.File r2 = new java.io.File
            java.lang.String r4 = "/system/xbin/su"
            r2.<init>(r4)
            if (r0 != 0) goto L_0x01ab
            boolean r0 = r2.exists()
            if (r0 == 0) goto L_0x01ab
        L_0x01a9:
            r0 = 1
            goto L_0x01ac
        L_0x01ab:
            r0 = 0
        L_0x01ac:
            if (r0 == 0) goto L_0x01af
            goto L_0x01b0
        L_0x01af:
            r1 = 0
        L_0x01b0:
            return r1
        L_0x01b1:
            if (r5 == 0) goto L_0x01bc
            r5.close()     // Catch:{ IOException -> 0x01b7 }
            goto L_0x01bc
        L_0x01b7:
            r0 = move-exception
            r2 = r0
            r2.printStackTrace()
        L_0x01bc:
            if (r9 == 0) goto L_0x01c7
            r9.close()     // Catch:{ IOException -> 0x01c2 }
            goto L_0x01c7
        L_0x01c2:
            r0 = move-exception
            r2 = r0
            r2.printStackTrace()
        L_0x01c7:
            if (r10 == 0) goto L_0x01d2
            r10.close()     // Catch:{ IOException -> 0x01cd }
            goto L_0x01d2
        L_0x01cd:
            r0 = move-exception
            r2 = r0
            r2.printStackTrace()
        L_0x01d2:
            if (r7 == 0) goto L_0x01d7
            r7.destroy()
        L_0x01d7:
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_basic_ui.splash.LauncherActivity.C0():boolean");
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.content.Context, com.huawei.module_basic_ui.splash.LauncherActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x00c2, code lost:
        if (r1.contains(r3) != false) goto L_0x00c4;
     */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0074 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0075  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r7) {
        /*
            r6 = this;
            com.huawei.module_basic_ui.splash.LauncherActivity.super.onCreate(r7)
            java.lang.String r7 = r6.getPackageName()
            java.lang.String r0 = "cn.tydic.ethiopay"
            boolean r7 = r7.startsWith(r0)
            if (r7 == 0) goto L_0x006c
            boolean r7 = r6.C0()     // Catch:{ Exception -> 0x003a }
            r0 = 0
            if (r7 == 0) goto L_0x003c
            androidx.appcompat.app.AlertDialog$Builder r7 = new androidx.appcompat.app.AlertDialog$Builder     // Catch:{ Exception -> 0x003a }
            r7.<init>(r6)     // Catch:{ Exception -> 0x003a }
            int r1 = com.huawei.module_basic_ui.R$string.designstandard_the_devices_has_rooted     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog$Builder r7 = r7.setMessage(r1)     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog$Builder r7 = r7.setCancelable(r0)     // Catch:{ Exception -> 0x003a }
            int r0 = com.huawei.module_basic_ui.R$string.designstandard_confirm     // Catch:{ Exception -> 0x003a }
            P6.e r1 = new P6.e     // Catch:{ Exception -> 0x003a }
            r1.<init>(r6)     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog$Builder r7 = r7.setPositiveButton(r0, r1)     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog r7 = r7.create()     // Catch:{ Exception -> 0x003a }
            r7.show()     // Catch:{ Exception -> 0x003a }
            java.lang.Boolean r7 = java.lang.Boolean.TRUE     // Catch:{ Exception -> 0x003a }
            goto L_0x006e
        L_0x003a:
            r7 = move-exception
            goto L_0x0066
        L_0x003c:
            boolean r7 = P6.g.a(r6)     // Catch:{ Exception -> 0x003a }
            if (r7 == 0) goto L_0x006c
            androidx.appcompat.app.AlertDialog$Builder r7 = new androidx.appcompat.app.AlertDialog$Builder     // Catch:{ Exception -> 0x003a }
            r7.<init>(r6)     // Catch:{ Exception -> 0x003a }
            int r1 = com.huawei.module_basic_ui.R$string.designstandard_the_devices_is_running_in_emulator     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog$Builder r7 = r7.setMessage(r1)     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog$Builder r7 = r7.setCancelable(r0)     // Catch:{ Exception -> 0x003a }
            int r0 = com.huawei.module_basic_ui.R$string.designstandard_confirm     // Catch:{ Exception -> 0x003a }
            P6.f r1 = new P6.f     // Catch:{ Exception -> 0x003a }
            r1.<init>(r6)     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog$Builder r7 = r7.setPositiveButton(r0, r1)     // Catch:{ Exception -> 0x003a }
            androidx.appcompat.app.AlertDialog r7 = r7.create()     // Catch:{ Exception -> 0x003a }
            r7.show()     // Catch:{ Exception -> 0x003a }
            java.lang.Boolean r7 = java.lang.Boolean.TRUE     // Catch:{ Exception -> 0x003a }
            goto L_0x006e
        L_0x0066:
            r7.getMessage()
            V1.h.b()
        L_0x006c:
            java.lang.Boolean r7 = java.lang.Boolean.FALSE
        L_0x006e:
            boolean r7 = r7.booleanValue()
            if (r7 == 0) goto L_0x0075
            return
        L_0x0075:
            android.content.Intent r7 = r6.getIntent()
            java.lang.String r0 = "systemExecute"
            java.lang.String r0 = r7.getStringExtra(r0)
            V1.h.b()
            boolean r1 = E0.c.g()
            r2 = 0
            if (r1 == 0) goto L_0x00d8
            boolean r1 = android.text.TextUtils.isEmpty(r0)
            if (r1 != 0) goto L_0x00d8
            java.lang.String r1 = "http"
            boolean r1 = r0.startsWith(r1)
            if (r1 == 0) goto L_0x00c4
            java.lang.String r1 = ""
            com.blankj.utilcode.util.s r1 = com.blankj.utilcode.util.s.a(r1)
            android.content.SharedPreferences r1 = r1.a
            java.lang.String r3 = "openH5UrlWhiteListConfig"
            java.lang.String r1 = r1.getString(r3, r2)
            com.huawei.module_basic_ui.splash.a r3 = new com.huawei.module_basic_ui.splash.a
            r3.<init>()
            java.lang.reflect.Type r3 = r3.getType()
            java.lang.Object r1 = W2.f.a(r1, r3)
            java.util.List r1 = (java.util.List) r1
            android.net.Uri r3 = android.net.Uri.parse(r0)
            java.lang.String r3 = r3.getHost()
            if (r1 == 0) goto L_0x00d8
            boolean r1 = r1.contains(r3)
            if (r1 == 0) goto L_0x00d8
        L_0x00c4:
            android.os.Bundle r7 = new android.os.Bundle
            r1 = 1
            r7.<init>(r1)
            java.lang.String r1 = "execute"
            r7.putString(r1, r0)
            java.lang.String r0 = "/pushModule/notificationFilter"
            o0.b.d(r6, r0, r7, r2)
            r6.finish()
            return
        L_0x00d8:
            java.lang.String r0 = r7.getAction()
            boolean r1 = E0.c.g()
            if (r1 == 0) goto L_0x012d
            java.lang.String r1 = "android.intent.action.VIEW"
            boolean r1 = r1.equals(r0)
            if (r1 == 0) goto L_0x012d
            android.net.Uri r1 = r7.getData()
            if (r1 == 0) goto L_0x012d
            p0.a r7 = o0.b.a
            java.lang.String r7 = r1.getPath()
            boolean r0 = android.text.TextUtils.isEmpty(r7)
            if (r0 == 0) goto L_0x00fd
            goto L_0x0129
        L_0x00fd:
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            java.util.Set r3 = r1.getQueryParameterNames()
            if (r3 == 0) goto L_0x0126
            boolean r4 = r3.isEmpty()
            if (r4 != 0) goto L_0x0126
            java.util.Iterator r3 = r3.iterator()
        L_0x0112:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0126
            java.lang.Object r4 = r3.next()
            java.lang.String r4 = (java.lang.String) r4
            java.lang.String r5 = r1.getQueryParameter(r4)
            r0.put(r4, r5)
            goto L_0x0112
        L_0x0126:
            o0.b.d(r6, r7, r2, r0)
        L_0x0129:
            r6.finish()
            return
        L_0x012d:
            java.lang.String r1 = "appId"
            java.lang.String r1 = r7.getStringExtra(r1)
            java.lang.String r3 = "shortCode"
            java.lang.String r3 = r7.getStringExtra(r3)
            java.lang.String r4 = "receiveCode"
            java.lang.String r4 = r7.getStringExtra(r4)
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 != 0) goto L_0x0166
            boolean r1 = android.text.TextUtils.isEmpty(r3)
            if (r1 != 0) goto L_0x0166
            boolean r1 = android.text.TextUtils.isEmpty(r4)
            if (r1 != 0) goto L_0x0166
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            android.os.Bundle r7 = r7.getExtras()
            r0.putAll(r7)
            java.lang.String r7 = "/checkoutModule/inAppPayEnter"
            o0.b.d(r2, r7, r0, r2)
            r6.finish()
            return
        L_0x0166:
            boolean r7 = r6.isTaskRoot()
            if (r7 != 0) goto L_0x0186
            android.content.Intent r7 = r6.getIntent()
            if (r7 == 0) goto L_0x0186
            java.lang.String r1 = "android.intent.category.LAUNCHER"
            boolean r7 = r7.hasCategory(r1)
            if (r7 == 0) goto L_0x0186
            java.lang.String r7 = "android.intent.action.MAIN"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L_0x0186
            r6.finish()
            return
        L_0x0186:
            android.content.Intent r7 = new android.content.Intent
            java.lang.Class<com.huawei.module_basic_ui.splash.SplashActivity> r0 = com.huawei.module_basic_ui.splash.SplashActivity.class
            r7.<init>(r6, r0)
            r6.startActivity(r7)
            r6.finish()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_basic_ui.splash.LauncherActivity.onCreate(android.os.Bundle):void");
    }
}
