package com.huawei.module_basic_ui.balance;

import E0.c;
import K6.a;
import K6.b;
import V1.h;
import W2.n;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivityMyBalanceBinding;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

@Route(path = "/basicUiModule/balance")
public class MyBalanceActivity extends BaseTitleActivity {
    public static final /* synthetic */ int j = 0;
    public ActivityMyBalanceBinding i;

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [android.content.Context, com.huawei.module_basic_ui.balance.MyBalanceActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        MyBalanceActivity.super.G0();
        N0(getString(R$string.baselib_balance));
        TextView textView = this.i.e;
        String str = "";
        n b = n.b(str);
        String string = b.a.getString(c.e("BALANCE_CACHE"), "0.00");
        if (!TextUtils.isEmpty(string)) {
            try {
                str = new DecimalFormat("#,##0.00", new DecimalFormatSymbols(Locale.US)).format(Double.parseDouble(string));
            } catch (Exception e) {
                e.getMessage();
                h.b();
            }
        }
        textView.setText(str);
        this.i.c.setOnClickListener(new a(this, 0));
        this.i.b.setOnClickListener(new b(this, 0));
        this.i.d.setOnClickListener(new K6.c(this, 0));
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.module_basic_ui.balance.MyBalanceActivity, android.app.Activity] */
    public final ViewBinding K0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_my_balance, (ViewGroup) null, false);
        int i2 = R$id.btn_deposit;
        TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i2);
        if (textView != null) {
            i2 = R$id.btn_withdraw;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(inflate, i2);
            if (textView2 != null) {
                i2 = R$id.imageView2;
                if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                    i2 = R$id.imageView4;
                    if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                        i2 = R$id.iv_history;
                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i2);
                        if (imageView != null) {
                            i2 = R$id.iv_rate_more;
                            if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                                i2 = R$id.iv_wallet;
                                if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                                    i2 = R$id.textView2;
                                    if (((TextView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                                        i2 = R$id.textView3;
                                        if (((TextView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                                            i2 = R$id.textView4;
                                            if (((TextView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                                                i2 = R$id.tv_balance;
                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(inflate, i2);
                                                if (textView3 != null) {
                                                    i2 = R$id.tv_exchange_rate;
                                                    if (((TextView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                                                        ActivityMyBalanceBinding activityMyBalanceBinding = new ActivityMyBalanceBinding((LinearLayout) inflate, textView, textView2, imageView, textView3);
                                                        this.i = activityMyBalanceBinding;
                                                        return activityMyBalanceBinding;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }
}
