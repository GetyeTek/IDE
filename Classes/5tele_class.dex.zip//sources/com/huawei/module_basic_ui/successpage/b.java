package com.huawei.module_basic_ui.successpage;

import D2.a;
import V1.k;
import com.blankj.utilcode.util.e;
import com.huawei.module_basic_ui.R$string;

public final /* synthetic */ class b implements a {
    public final /* synthetic */ CommonSuccessActivity a;

    public /* synthetic */ b(CommonSuccessActivity commonSuccessActivity) {
        this.a = commonSuccessActivity;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.content.Context, java.lang.Object, com.huawei.module_basic_ui.successpage.CommonSuccessActivity] */
    public final void c(boolean z) {
        ? r0 = this.a;
        if (z) {
            U6.b.a(r0.i.p, r0, r0.h, r0.j, r0.shortCode);
            return;
        }
        int i = CommonSuccessActivity.n;
        r0.getClass();
        e.b();
        k.b(1, r0.getString(R$string.designstandard_write_permission_required_to_save_qr_code));
    }
}
