package com.huawei.module_basic_ui.successpage.qrcode;

import N0.G;
import R9.h;
import U6.c;
import V7.e;
import W2.j;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivityResultQrCodeBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;

@Route(path = "/basicUiModule/resultQrCode")
public class ResultQrCodeActivity extends DataBindingActivity<ActivityResultQrCodeBinding, ViewModel> {
    public static final /* synthetic */ int g = 0;
    public TransferResp d;
    public String e;
    public String f;

    public final int C0() {
        return R$layout.activity_result_qr_code;
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, java.lang.Object, com.huawei.module_basic_ui.successpage.qrcode.ResultQrCodeActivity, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        ResultQrCodeActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.qr_code), R.layout.common_toolbar);
        this.d = getIntent().getSerializableExtra("transferResp");
        this.e = getIntent().getStringExtra("transactionTo");
        this.f = getIntent().getStringExtra("shortCode");
        this.b.c.setImageBitmap(j.c(h.a(this, 146.0f), h.a(this, 146.0f), this.d.getTransactionCredentialCode()));
        this.b.d.setOnClickListener(new G(this, 1));
        this.b.b.setOnClickListener(new c(this, 0));
    }
}
