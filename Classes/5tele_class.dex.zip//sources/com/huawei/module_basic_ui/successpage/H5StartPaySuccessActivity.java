package com.huawei.module_basic_ui.successpage;

import Yb.c;
import android.view.View;
import com.alibaba.android.arouter.facade.annotation.Route;

@Route(path = "/basicUiModule/h5StaryPaySuccess")
public class H5StartPaySuccessActivity extends CommonSuccessActivity {
    /* JADX WARNING: type inference failed for: r1v0, types: [android.app.Activity, com.huawei.module_basic_ui.successpage.H5StartPaySuccessActivity] */
    public void onViewClick(View view) {
        c.b().e("notifyH5StartPayCallBack");
        finish();
    }
}
