package com.huawei.module_basic_ui.successpage;

import I4.d;
import J8.a;
import N0.F;
import P6.b;
import S3.i;
import V1.h;
import W2.j;
import W2.n;
import Yb.c;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import androidx.core.content.ContextCompat;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.digitalpayment.customer.httplib.repository.QueryTransDetailsRepository;
import com.huawei.digitalpayment.customer.httplib.request.EventRefreshBalance;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.module_basic_ui.R$color;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$mipmap;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivitySuccessCommonBinding;
import i7.C0013a;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Route(path = "/basicUiModule/commonSuccess")
public class CommonSuccessActivity extends BaseActivity implements Runnable {
    public static final /* synthetic */ int n = 0;
    @Autowired
    String amount = "";
    @Autowired
    String buttonText;
    @Autowired
    String currency = "";
    public final String d = "sp_name_push";
    public final String e = "unreadCountUpdateTime";
    @Autowired
    Map<String, String> extraDisplayItems;
    public String f = "";
    public String g = "";
    public TransferResp h;
    public ActivitySuccessCommonBinding i;
    @Autowired(name = "isAsyncTransaction")
    boolean isAsyncTransaction = false;
    public String j;
    public QueryTransDetailsRepository k;
    public int l;
    public f m;
    @Autowired
    String shortCode = "";
    @Autowired
    boolean updateBalance;

    /* JADX WARNING: type inference failed for: r35v0, types: [com.huawei.module_basic_ui.successpage.CommonSuccessActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0041, code lost:
        r1 = com.huawei.module_basic_ui.R$id.clFeedBack;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004c, code lost:
        r1 = com.huawei.module_basic_ui.R$id.cl_other_info;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0057, code lost:
        r1 = com.huawei.module_basic_ui.R$id.cl_qrcode;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0062, code lost:
        r1 = com.huawei.module_basic_ui.R$id.clTips;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0077, code lost:
        r1 = com.huawei.module_basic_ui.R$id.cycle_view;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x008c, code lost:
        r1 = com.huawei.module_basic_ui.R$id.feedBackLine;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x012c, code lost:
        r1 = com.huawei.module_basic_ui.R$id.rv_other_info;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x0142, code lost:
        r1 = com.huawei.module_basic_ui.R$id.tipsLine;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0036, code lost:
        r1 = com.huawei.module_basic_ui.R$id.cl_download_share_container;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding C0() {
        /*
            r35 = this;
            android.view.LayoutInflater r0 = r35.getLayoutInflater()
            int r1 = com.huawei.module_basic_ui.R$layout.activity_success_common
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_basic_ui.R$id.barrier
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.Barrier r2 = (androidx.constraintlayout.widget.Barrier) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.barrier_tips_lucky
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.Barrier r2 = (androidx.constraintlayout.widget.Barrier) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.btnBillShare
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            android.widget.Button r5 = (android.widget.Button) r5
            if (r5 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.btn_confirm
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            android.widget.Button r6 = (android.widget.Button) r6
            if (r6 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.cl_download_share_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            androidx.constraintlayout.widget.ConstraintLayout r7 = (androidx.constraintlayout.widget.ConstraintLayout) r7
            if (r7 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.clFeedBack
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            androidx.constraintlayout.widget.ConstraintLayout r8 = (androidx.constraintlayout.widget.ConstraintLayout) r8
            if (r8 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.cl_other_info
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            androidx.constraintlayout.widget.ConstraintLayout r9 = (androidx.constraintlayout.widget.ConstraintLayout) r9
            if (r9 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.cl_qrcode
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            androidx.constraintlayout.widget.ConstraintLayout r10 = (androidx.constraintlayout.widget.ConstraintLayout) r10
            if (r10 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.clTips
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            androidx.constraintlayout.widget.ConstraintLayout r11 = (androidx.constraintlayout.widget.ConstraintLayout) r11
            if (r11 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.currencylayout
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.ConstraintLayout r2 = (androidx.constraintlayout.widget.ConstraintLayout) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.cycle_view
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r12 = r2
            com.huawei.common.widget.banner.CycleViewPager r12 = (com.huawei.common.widget.banner.CycleViewPager) r12
            if (r12 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.feedBackImageView
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.feedBackLine
            android.view.View r13 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r13 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.id_view
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.imageView
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.iv_download
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r14 = r2
            android.widget.ImageView r14 = (android.widget.ImageView) r14
            if (r14 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.iv_icon_code
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.iv_lucky_scratch
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r15 = r2
            android.widget.ImageView r15 = (android.widget.ImageView) r15
            if (r15 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.iv_qr_code
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r16 = r2
            android.widget.ImageView r16 = (android.widget.ImageView) r16
            if (r16 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.iv_share
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r17 = r2
            android.widget.ImageView r17 = (android.widget.ImageView) r17
            if (r17 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.iv_status
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r18 = r2
            android.widget.ImageView r18 = (android.widget.ImageView) r18
            if (r18 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.linearLayout
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.ll_content
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r19 = r2
            android.widget.LinearLayout r19 = (android.widget.LinearLayout) r19
            if (r19 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.ll_lucky_scratch_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r20 = r2
            android.widget.LinearLayout r20 = (android.widget.LinearLayout) r20
            if (r20 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.ll_qrcode_bitmap_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r21 = r2
            android.widget.LinearLayout r21 = (android.widget.LinearLayout) r21
            if (r21 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.rl_qr_code
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundConstraintLayout r2 = (com.huawei.common.widget.round.RoundConstraintLayout) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.rl_tips_qrcode_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundLinearLayout r2 = (com.huawei.common.widget.round.RoundLinearLayout) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.rv_other_info
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r22 = r2
            com.huawei.common.widget.recyclerview.HFRecyclerView r22 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r22
            if (r22 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.sl_content
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ScrollView r2 = (android.widget.ScrollView) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tipsLine
            android.view.View r23 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r23 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r24 = r2
            android.widget.TextView r24 = (android.widget.TextView) r24
            if (r24 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_code_tips
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_coupon_pay
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r25 = r2
            android.widget.TextView r25 = (android.widget.TextView) r25
            if (r25 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tvCurrency
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_currency_pre
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r26 = r2
            android.widget.TextView r26 = (android.widget.TextView) r26
            if (r26 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_download
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r27 = r2
            android.widget.TextView r27 = (android.widget.TextView) r27
            if (r27 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tvFeedBack
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r28 = r2
            android.widget.TextView r28 = (android.widget.TextView) r28
            if (r28 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_hint
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r29 = r2
            android.widget.TextView r29 = (android.widget.TextView) r29
            if (r29 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_lucky_scratch_tips
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r30 = r2
            android.widget.TextView r30 = (android.widget.TextView) r30
            if (r30 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_share
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r31 = r2
            android.widget.TextView r31 = (android.widget.TextView) r31
            if (r31 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_subtitle
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r32 = r2
            android.widget.TextView r32 = (android.widget.TextView) r32
            if (r32 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tvTips
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r33 = r2
            android.widget.TextView r33 = (android.widget.TextView) r33
            if (r33 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.tv_title
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r34 = r2
            android.widget.TextView r34 = (android.widget.TextView) r34
            if (r34 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.view1
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.view2
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x0208
            int r1 = com.huawei.module_basic_ui.R$id.view3
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x0208
            com.huawei.module_basic_ui.databinding.ActivitySuccessCommonBinding r1 = new com.huawei.module_basic_ui.databinding.ActivitySuccessCommonBinding
            r3 = r1
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34)
            r2 = r35
            r2.i = r1
            return r1
        L_0x0208:
            r2 = r35
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r3 = "Missing required view with ID: "
            java.lang.String r0 = r3.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_basic_ui.successpage.CommonSuccessActivity.C0():androidx.viewbinding.ViewBinding");
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [android.content.Context, com.huawei.module_basic_ui.successpage.CommonSuccessActivity, android.app.Activity, java.lang.Runnable] */
    public void D0() {
        String str;
        this.j = getIntent().getStringExtra("transactionTo");
        if (!TextUtils.isEmpty(this.buttonText)) {
            this.i.c.setText(this.buttonText);
        }
        if (this.isAsyncTransaction) {
            this.i.c.setVisibility(8);
        }
        n.b("");
        TransferResp transferResp = (TransferResp) n.c(TransferResp.class, "transferResp");
        this.h = transferResp;
        if (transferResp == null) {
            this.h = getIntent().getSerializableExtra("TransferResp");
        }
        if (this.h != null) {
            N0();
            if (!TextUtils.isEmpty(this.h.getActualAmountDisplay())) {
                this.i.u.setText(Html.fromHtml(this.h.getActualAmountDisplay()));
            }
            String discountAmount = this.h.getDiscountAmount();
            if (!TextUtils.isEmpty(discountAmount)) {
                try {
                    float parseFloat = Float.parseFloat(discountAmount);
                    if (parseFloat > 0.0f) {
                        TransferResp transferResp2 = this.h;
                        if (transferResp2 != null) {
                            List displayItems = transferResp2.getDisplayItems();
                            if (displayItems != null) {
                                Iterator it = displayItems.iterator();
                                while (true) {
                                    if (it.hasNext()) {
                                        if (TextUtils.equals(((TransferResp.DisplayItemBean) it.next()).getKey(), "FuelCoupons")) {
                                            str = getString(R$string.designstandard_coupon) + " " + this.h.getOriginalAmountDisplay() + this.h.getUnit();
                                            break;
                                        }
                                    } else {
                                        break;
                                    }
                                }
                                this.i.v.setText(Html.fromHtml(str));
                                this.i.v.setVisibility(0);
                            }
                        }
                        str = getString(R$string.designstandard_coupon) + " -" + parseFloat + this.h.getUnit();
                        this.i.v.setText(Html.fromHtml(str));
                        this.i.v.setVisibility(0);
                    }
                } catch (Exception e2) {
                    e2.getMessage();
                    h.b();
                }
            }
            if (!TextUtils.isEmpty(this.h.getUnit())) {
                if ("Prefix".equals(this.h.getUnitType())) {
                    this.i.w.setVisibility(0);
                    this.i.w.setText(this.h.getUnit());
                } else {
                    this.i.w.setVisibility(0);
                    this.i.w.setText(this.h.getUnit());
                }
                this.i.w.setText(Html.fromHtml("(" + this.h.getUnit() + ")"));
            }
            if (!TextUtils.isEmpty(this.h.getTitle())) {
                this.i.L.setText(Html.fromHtml(this.h.getTitle()));
            }
            if (!TextUtils.isEmpty(this.h.getHint())) {
                this.i.z.setVisibility(0);
                this.i.z.setText(Html.fromHtml(this.h.getHint()));
            }
            O0(this.h.getOrderStatus(), this.h);
            if (!a.i(this.h.getDisplayItems()) || !TextUtils.isEmpty(this.h.getTipsButtonText())) {
                this.i.f.setVisibility(0);
                f fVar = new f(this, R$layout.item_common_success, this.h.getDisplayItems());
                this.m = fVar;
                this.i.s.setAdapter(fVar);
            } else {
                this.i.f.setVisibility(8);
            }
            c.b().h(new EventRefreshBalance());
            if ("Processing".equals(this.h.getOrderStatus())) {
                A.h(this, L0());
                return;
            }
            return;
        }
        if (this.updateBalance) {
            N0();
        }
        if (!TextUtils.isEmpty(this.amount)) {
            this.i.u.setText(W2.c.d(this.amount));
            this.i.w.setVisibility(0);
            this.i.w.setText("(" + this.currency + ")");
        }
        this.i.o.setBackgroundResource(R$mipmap.basic_icon_result_success);
        this.i.L.setText(R$string.designstandard_success);
        this.i.f.setVisibility(8);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_basic_ui.successpage.CommonSuccessActivity, android.app.Activity] */
    public void G0() {
        f.g(getWindow());
        f.f(this, true);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, java.lang.Object, com.huawei.module_basic_ui.successpage.CommonSuccessActivity] */
    public final void K0(boolean z) {
        if (z) {
            this.i.r.setVisibility(8);
            if (this.h.hasTransactionCredentialCode() && z) {
                this.i.g.setVisibility(0);
                P0();
            }
        } else if (this.h.hasTransactionCredentialCode()) {
            this.i.r.setVisibility(0);
            this.i.m.setImageBitmap(j.c(R9.h.a(this, 146.0f), R9.h.a(this, 146.0f), this.h.getTransactionCredentialCode()));
        }
        if (this.h.hasTransactionCredentialCode()) {
            this.i.d.setVisibility(0);
        }
        this.i.g.setOnClickListener(new c(this));
        this.i.k.setOnClickListener(new b(this, 4));
        this.i.x.setOnClickListener(new K6.a(this, 3));
        this.i.n.setOnClickListener(new K6.b(this, 2));
        this.i.B.setOnClickListener(new K6.c(this, 3));
    }

    public final long L0() {
        TransferResp transferResp = this.h;
        if (transferResp == null || transferResp.getPollFreq() == null || this.h.getPollFreq().length <= 0) {
            return 2000;
        }
        return (long) (this.h.getPollFreq()[this.l] * 1000);
    }

    public void M0() {
        TransferResp transferResp = this.h;
        if (transferResp == null || transferResp.getPollFreq() == null || this.h.getPollFreq().length <= 0) {
            if (this.l >= 5) {
                if (this.isAsyncTransaction) {
                    this.i.c.setVisibility(0);
                    this.f = "Failed";
                    this.g = "timeout";
                }
                this.i.o.setBackgroundResource(R$mipmap.ic_payment_time_out);
                this.i.L.setText(R$string.payment_timeout);
                return;
            }
        } else if (this.l >= this.h.getPollFreq().length - 1) {
            if (this.isAsyncTransaction) {
                this.i.c.setVisibility(0);
                this.f = "Failed";
                this.g = "timeout";
            }
            this.i.o.setBackgroundResource(R$mipmap.ic_payment_time_out);
            this.i.L.setText(R$string.payment_timeout);
            return;
        }
        if (this.k == null) {
            this.k = new QueryTransDetailsRepository(this.h.getOrderId());
            if (!TextUtils.isEmpty(this.h.getCouponId())) {
                this.k.addParams("couponId", this.h.getCouponId());
            }
        }
        this.k.sendRequest(new e(this));
        this.l++;
    }

    public final void N0() {
        Class<AppService> cls = AppService.class;
        o0.b.c(cls).m();
        o0.b.c(cls).i();
        n.b(this.d).i(this.e);
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [java.lang.Object, com.huawei.common.widget.banner.CycleViewPager$c] */
    public final void O0(String str, TransferResp transferResp) {
        if ("Success".equals(str)) {
            this.i.o.setBackgroundResource(R$mipmap.basic_icon_result_success);
            this.i.L.setTextColor(ContextCompat.getColor(this, R$color.colorPrimary));
            this.i.s.setVisibility(0);
            this.i.u.setVisibility(0);
            this.i.w.setVisibility(0);
            if (TextUtils.isEmpty(this.h.getBillShareButtonText())) {
                this.i.b.setVisibility(8);
            } else {
                this.i.b.setVisibility(0);
                this.i.b.setText(this.h.getBillShareButtonText());
                this.i.b.setOnClickListener(new F(this, 8));
            }
            if (!TextUtils.isEmpty(this.h.getTipsButtonText())) {
                this.i.h.setVisibility(0);
                this.i.H.setText(this.h.getTipsButtonText());
                this.i.h.setOnClickListener(new D1.a(this, 3));
            }
            if (!TextUtils.isEmpty(this.h.getFeedBackDisplay())) {
                this.i.e.setVisibility(0);
                this.i.y.setText(this.h.getFeedBackDisplay());
                this.i.e.setOnClickListener(new i(this, 3));
            }
            P0();
            if (this.h.isShowLuckyScratchAlone()) {
                this.i.q.setVisibility(0);
                this.i.A.setText(this.h.getLuckyScratchText());
                this.i.l.setOnClickListener(new S3.h(this, 3));
            }
            if (!BasicConfig.getInstance().bannerIsQuerySwitch()) {
                new BannerRepository("", "").sendRequest(new d(this, 2));
            } else {
                List bannerData = this.h.getBannerData();
                if (!a.i(bannerData)) {
                    this.i.i.setVisibility(0);
                    this.i.i.c(bannerData, new Object(), 0);
                }
                K0(!a.i(bannerData));
            }
            if (this.isAsyncTransaction) {
                this.i.c.setVisibility(0);
                this.f = "Success";
            }
        } else if ("Processing".equals(str)) {
            this.i.o.setBackgroundResource(R$mipmap.basic_icon_result_processing);
            this.i.L.setTextColor(ContextCompat.getColor(this, R$color.color_00B578));
            this.i.s.setVisibility(8);
            this.i.u.setVisibility(8);
            this.i.w.setVisibility(8);
        } else if ("Canceled".equals(str)) {
            this.i.o.setBackgroundResource(R$mipmap.basic_icon_result_fail);
            if (transferResp != null && !TextUtils.isEmpty(transferResp.getSubTitle())) {
                this.i.C.setText(transferResp.getSubTitle());
            }
            this.i.L.setTextColor(ContextCompat.getColor(this, R$color.colorBlack));
            this.i.s.setVisibility(8);
            this.i.u.setVisibility(8);
            this.i.w.setVisibility(8);
            if (this.isAsyncTransaction) {
                this.i.c.setVisibility(0);
                this.f = "Canceled";
            }
        }
    }

    public final void P0() {
        if (this.i.g.getVisibility() == 0) {
            this.i.t.setVisibility(0);
        }
        if (this.i.g.getVisibility() == 0 || this.i.h.getVisibility() == 0) {
            this.i.j.setVisibility(0);
        }
    }

    public final void onBackPressed() {
    }

    public final void onDestroy() {
        CommonSuccessActivity.super.onDestroy();
        QueryTransDetailsRepository queryTransDetailsRepository = this.k;
        if (queryTransDetailsRepository != null) {
            queryTransDetailsRepository.cancel();
        }
        A.a.removeCallbacks(this);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_basic_ui.successpage.CommonSuccessActivity, android.app.Activity] */
    public void onViewClick(View view) {
        if (this.isAsyncTransaction) {
            finish();
            boolean equals = TextUtils.equals(this.f, "Success");
            C0013a aVar = C0013a.C0002a.a;
            if (equals) {
                aVar.a.onSuccess(this.h);
            } else {
                aVar.a.a(4, this.g);
            }
        } else {
            o0.b.d(this, "/mainModule/main", (Bundle) null, (Map) null);
            finish();
        }
    }

    public final void run() {
        M0();
    }
}
