package com.huawei.module_basic_ui.successpage;

import android.view.View;
import com.alibaba.android.arouter.facade.annotation.Route;

@Route(path = "/basicUiModule/commonFinishSuccess")
public class CommonFinishSuccessActivity extends CommonSuccessActivity {
    /* JADX WARNING: type inference failed for: r0v0, types: [android.app.Activity, com.huawei.module_basic_ui.successpage.CommonFinishSuccessActivity] */
    public void onViewClick(View view) {
        finish();
    }
}
