package com.huawei.module_basic_ui.successpage;

import W2.r;
import android.text.Html;
import android.text.TextUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_basic_ui.R$id;
import java.util.List;

public final class f extends BaseQuickAdapter<TransferResp.DisplayItemBean, BaseViewHolder> {
    public final /* synthetic */ CommonSuccessActivity a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public f(CommonSuccessActivity commonSuccessActivity, int i, List list) {
        super(i, list);
        this.a = commonSuccessActivity;
    }

    public final void convert(BaseViewHolder baseViewHolder, Object obj) {
        TransferResp.DisplayItemBean displayItemBean = (TransferResp.DisplayItemBean) obj;
        String value = displayItemBean.getValue();
        value.replace("   ", "&nbsp;&nbsp;&nbsp;");
        String obj2 = Html.fromHtml(value.replace("  ", "&nbsp;&nbsp;")).toString();
        if ("TransactionTime".equals(displayItemBean.getKey())) {
            obj2 = r.a(displayItemBean.getValue());
            if (TextUtils.isEmpty(obj2)) {
                obj2 = displayItemBean.getValue();
            }
        }
        boolean equals = "transactionTo".equals(displayItemBean.getKey());
        CommonSuccessActivity commonSuccessActivity = this.a;
        if (equals && !TextUtils.isEmpty(commonSuccessActivity.j)) {
            obj2 = commonSuccessActivity.j;
        }
        if ("AgentID".equals(displayItemBean.getKey())) {
            obj2 = commonSuccessActivity.shortCode;
        }
        baseViewHolder.setText(R$id.tv_label, displayItemBean.getLabel()).setText(R$id.tv_value, obj2);
    }
}
