package com.huawei.module_basic_ui.successpage;

import android.util.Log;
import com.alibaba.android.arouter.facade.model.TypeWrapper;
import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import java.util.Map;

public class CommonSuccessActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    public class a extends TypeWrapper<Map<String, String>> {
    }

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_basic_ui.successpage.CommonSuccessActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (CommonSuccessActivity) obj;
        r4.isAsyncTransaction = r4.getIntent().getBooleanExtra("isAsyncTransaction", r4.isAsyncTransaction);
        if (r4.getIntent().getExtras() == null) {
            str = r4.amount;
        } else {
            str = r4.getIntent().getExtras().getString("amount", r4.amount);
        }
        r4.amount = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.shortCode;
        } else {
            str2 = r4.getIntent().getExtras().getString("shortCode", r4.shortCode);
        }
        r4.shortCode = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.buttonText;
        } else {
            str3 = r4.getIntent().getExtras().getString("buttonText", r4.buttonText);
        }
        r4.buttonText = str3;
        r4.updateBalance = r4.getIntent().getBooleanExtra("updateBalance", r4.updateBalance);
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.currency;
        } else {
            str4 = r4.getIntent().getExtras().getString("currency", r4.currency);
        }
        r4.currency = str4;
        SerializationService serializationService2 = this.serializationService;
        if (serializationService2 != null) {
            r4.extraDisplayItems = (Map) serializationService2.parseObject(r4.getIntent().getStringExtra("extraDisplayItems"), new TypeWrapper().getType());
        } else {
            Log.e("ARouter::", "You want automatic inject the field 'extraDisplayItems' in class 'CommonSuccessActivity' , then you should implement 'SerializationService' to support object auto inject!");
        }
    }
}
