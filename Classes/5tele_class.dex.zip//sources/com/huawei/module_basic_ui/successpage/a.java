package com.huawei.module_basic_ui.successpage;

import U6.b;
import V1.k;
import android.content.Intent;
import android.net.Uri;
import com.blankj.utilcode.util.e;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.module_basic_ui.R$string;

public final /* synthetic */ class a implements D2.a {
    public final /* synthetic */ CommonSuccessActivity a;

    public /* synthetic */ a(CommonSuccessActivity commonSuccessActivity) {
        this.a = commonSuccessActivity;
    }

    public final void c(boolean z) {
        BaseActivity baseActivity = this.a;
        if (z) {
            Uri c = b.c(baseActivity.i.p, baseActivity, baseActivity.h, baseActivity.j, baseActivity.shortCode);
            Intent intent = new Intent("android.intent.action.SEND");
            intent.putExtra("android.intent.extra.STREAM", c);
            intent.setType("image/*");
            try {
                baseActivity.startActivity(Intent.createChooser(intent, baseActivity.getResources().getString(R$string.designstandard_share)));
            } catch (Exception unused) {
                k.b(1, baseActivity.getResources().getString(R$string.designstandard_the_shared_application_component_could_not_be_found));
            }
        } else {
            int i = CommonSuccessActivity.n;
            baseActivity.getClass();
            e.b();
        }
    }
}
