package com.huawei.module_basic_ui.successpage;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import java.util.Map;
import o0.b;

public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ CommonSuccessActivity a;

    public /* synthetic */ c(CommonSuccessActivity commonSuccessActivity) {
        this.a = commonSuccessActivity;
    }

    public final void onClick(View view) {
        int i = CommonSuccessActivity.n;
        CommonSuccessActivity commonSuccessActivity = this.a;
        commonSuccessActivity.getClass();
        Bundle bundle = new Bundle(3);
        bundle.putSerializable("transferResp", commonSuccessActivity.h);
        bundle.putString("transactionTo", commonSuccessActivity.j);
        bundle.putString("shortCode", commonSuccessActivity.shortCode);
        b.d((Activity) null, "/basicUiModule/resultQrCode", bundle, (Map) null);
    }
}
