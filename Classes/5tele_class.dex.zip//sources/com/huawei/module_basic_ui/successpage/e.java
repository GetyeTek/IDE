package com.huawei.module_basic_ui.successpage;

import R1.a;
import V1.k;
import android.text.Html;
import android.text.TextUtils;
import com.blankj.utilcode.util.A;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.CouponRedeemResult;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_basic_ui.R$string;
import java.util.List;

public final class e implements a<TransferResp> {
    public final /* synthetic */ CommonSuccessActivity a;

    public e(CommonSuccessActivity commonSuccessActivity) {
        this.a = commonSuccessActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final void onError(BaseException baseException) {
        CommonSuccessActivity commonSuccessActivity = this.a;
        commonSuccessActivity.O0("Failed", (TransferResp) null);
        k.b(1, baseException.getResponseDesc());
        if (commonSuccessActivity.isAsyncTransaction) {
            commonSuccessActivity.f = "Failed";
            commonSuccessActivity.g = baseException.getResponseDesc();
            commonSuccessActivity.i.c.setVisibility(0);
        }
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.content.Context, com.huawei.module_basic_ui.successpage.CommonSuccessActivity, java.lang.Runnable] */
    public final void onSuccess(Object obj) {
        TransferResp transferResp = (TransferResp) obj;
        ? r0 = this.a;
        r0.h.setReferenceData(transferResp.getReferenceData());
        if (!transferResp.isUseCoupon() || !"FUEL COUPON".equals(transferResp.getCouponType())) {
            r0.O0(transferResp.getOrderStatus(), transferResp);
        } else {
            CouponRedeemResult redeemResult = transferResp.getRedeemResult();
            if (redeemResult == null || !"0".equals(redeemResult.getErrorCode())) {
                r0.O0("Processing", transferResp);
                A.h(r0, r0.L0());
            } else {
                r0.O0("Success", transferResp);
            }
        }
        if (!TextUtils.isEmpty(transferResp.getTitle())) {
            r0.h.setTitle(transferResp.getTitle());
            r0.i.L.setText(Html.fromHtml(transferResp.getTitle()));
        }
        if (r0.m != null) {
            if (!TextUtils.isEmpty(transferResp.getTransId())) {
                TransferResp.DisplayItemBean displayItemBean = new TransferResp.DisplayItemBean();
                displayItemBean.setKey("transId");
                displayItemBean.setLabel(r0.getString(R$string.transaction_number));
                displayItemBean.setValue(transferResp.getTransId());
                if (!r0.h.getDisplayItems().contains(displayItemBean)) {
                    r0.h.getDisplayItems().add(0, displayItemBean);
                }
            }
            if (!TextUtils.isEmpty(transferResp.getServiceNumber())) {
                TransferResp.DisplayItemBean displayItemBean2 = new TransferResp.DisplayItemBean();
                displayItemBean2.setKey("serviceNumber");
                displayItemBean2.setLabel(r0.getString(R$string.service_number));
                displayItemBean2.setValue(transferResp.getServiceNumber());
                if (!r0.h.getDisplayItems().contains(displayItemBean2)) {
                    r0.h.getDisplayItems().add(0, displayItemBean2);
                }
            }
            if (r0.h.getDisplayItems() != null) {
                for (int size = r0.h.getDisplayItems().size() - 1; size >= 0; size--) {
                    if (((TransferResp.DisplayItemBean) r0.h.getDisplayItems().get(size)).getKey().equals("AccountNumber")) {
                        r0.h.getDisplayItems().remove(size);
                    }
                }
            }
            List displayItems = r0.h.getDisplayItems();
            f fVar = r0.m;
            if (fVar != null) {
                fVar.setList(displayItems);
            }
        }
        if ((!transferResp.isUseCoupon() || !"FUEL COUPON".equals(transferResp.getCouponType())) && "Processing".equals(transferResp.getOrderStatus())) {
            A.h(r0, r0.L0());
        }
    }
}
