package com.huawei.module_basic_ui.successpage;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import java.util.Map;
import o0.b;

public final /* synthetic */ class d implements CycleViewPager.c {
    public final void b(CycleViewPager.b bVar, View view) {
        HomeBannerBean homeBannerBean = (HomeBannerBean) bVar;
        int i = CommonSuccessActivity.n;
        if (!TextUtils.isEmpty(homeBannerBean.getExecute())) {
            b.d((Activity) null, homeBannerBean.getExecute(), new Bundle(), (Map) null);
        }
    }
}
