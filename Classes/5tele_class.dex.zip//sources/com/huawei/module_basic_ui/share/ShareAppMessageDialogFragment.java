package com.huawei.module_basic_ui.share;

import H1.c;
import O6.d;
import O6.e;
import O6.f;
import V1.k;
import W2.g;
import W2.h;
import W2.n;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.blankj.utilcode.util.l;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.baselib.utils.exception.PhoneNumberException;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.R$style;
import com.huawei.module_basic_ui.databinding.DialogShareAppMessageBinding;
import com.huawei.module_basic_ui.successpage.CommonSuccessActivity;
import java.util.HashMap;

public class ShareAppMessageDialogFragment extends BaseDialog implements d {
    public AppShareActivity c;
    public DialogShareAppMessageBinding d;

    public class a extends O2.a {
        public final /* synthetic */ ShareAppMessageDialogFragment b;

        public a(ShareAppMessageDialogFragment shareAppMessageDialogFragment) {
            super(2);
            this.b = shareAppMessageDialogFragment;
        }

        public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            DialogShareAppMessageBinding dialogShareAppMessageBinding = this.b.d;
            dialogShareAppMessageBinding.d.setEnabled(g.c(dialogShareAppMessageBinding.b.getText()));
        }
    }

    public class b implements View.OnTouchListener {
        public b() {
        }

        public final boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() != 0) {
                return false;
            }
            l.b(ShareAppMessageDialogFragment.this.d.b);
            return false;
        }
    }

    public final void G(String str) {
        this.d.d.a();
    }

    public final void V(String str) {
        this.d.d.b();
    }

    public final void X() {
        this.c.J0(CommonSuccessActivity.class, true);
    }

    public final void onAttach(@NonNull Context context) {
        ShareAppMessageDialogFragment.super.onAttach(context);
        this.c = (AppShareActivity) context;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0046, code lost:
        r8 = com.huawei.module_basic_ui.R$id.tv_share_sms_content;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x001e, code lost:
        r8 = com.huawei.module_basic_ui.R$id.lb_confirm;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(android.view.LayoutInflater r7, android.view.ViewGroup r8, android.os.Bundle r9) {
        /*
            r6 = this;
            int r8 = com.huawei.module_basic_ui.R$layout.dialog_share_app_message
            r9 = 0
            r0 = 0
            android.view.View r7 = r7.inflate(r8, r0, r9)
            int r8 = com.huawei.module_basic_ui.R$id.edt_share_phone_number
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r2 = r9
            com.huawei.digitalpayment.customer.viewlib.view.CommonInputView r2 = (com.huawei.digitalpayment.customer.viewlib.view.CommonInputView) r2
            if (r2 == 0) goto L_0x0078
            int r8 = com.huawei.module_basic_ui.R$id.img_address_book
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r3 = r9
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0078
            int r8 = com.huawei.module_basic_ui.R$id.lb_confirm
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r9 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r9
            if (r9 == 0) goto L_0x0078
            int r8 = com.huawei.module_basic_ui.R$id.line
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            com.huawei.common.widget.round.RoundTextView r0 = (com.huawei.common.widget.round.RoundTextView) r0
            if (r0 == 0) goto L_0x0078
            int r8 = com.huawei.module_basic_ui.R$id.ll_edit
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            if (r0 == 0) goto L_0x0078
            int r8 = com.huawei.module_basic_ui.R$id.tv_share_limit
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            androidx.appcompat.widget.AppCompatTextView r0 = (androidx.appcompat.widget.AppCompatTextView) r0
            if (r0 == 0) goto L_0x0078
            int r8 = com.huawei.module_basic_ui.R$id.tv_share_sms_content
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r5 = r0
            com.huawei.common.widget.round.RoundTextView r5 = (com.huawei.common.widget.round.RoundTextView) r5
            if (r5 == 0) goto L_0x0078
            com.huawei.module_basic_ui.databinding.DialogShareAppMessageBinding r8 = new com.huawei.module_basic_ui.databinding.DialogShareAppMessageBinding
            r1 = r7
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r0 = r8
            r4 = r9
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r8
            D6.c r7 = new D6.c
            r8 = 2
            r7.<init>(r6, r8)
            r9.setOnClickListener(r7)
            com.huawei.module_basic_ui.databinding.DialogShareAppMessageBinding r7 = r6.d
            android.widget.ImageView r7 = r7.c
            D6.c r8 = new D6.c
            r9 = 2
            r8.<init>(r6, r9)
            r7.setOnClickListener(r8)
            com.huawei.module_basic_ui.databinding.DialogShareAppMessageBinding r7 = r6.d
            com.huawei.common.widget.round.RoundConstraintLayout r7 = r7.a
            return r7
        L_0x0078:
            android.content.res.Resources r7 = r7.getResources()
            java.lang.String r7 = r7.getResourceName(r8)
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            java.lang.String r9 = "Missing required view with ID: "
            java.lang.String r7 = r9.concat(r7)
            r8.<init>(r7)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_basic_ui.share.ShareAppMessageDialogFragment.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onStart() {
        Window window;
        ShareAppMessageDialogFragment.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.getDecorView().setOnTouchListener(new b());
            window.setGravity(80);
            window.setLayout(-1, -2);
            window.setBackgroundDrawableResource(17170445);
            c.b(window, R$style.BottomAnimation, dialog, true, true);
        }
    }

    public void onViewClick(View view) {
        int id = view.getId();
        if (id == R$id.img_address_book) {
            l.b(this.d.b);
            Y2.a.c(requireActivity(), new f(this, 0));
        } else if (id == R$id.lb_confirm) {
            String text = this.d.b.getText();
            try {
                if (!h.d(text)) {
                    if (text.startsWith("09")) {
                        text = text.replaceFirst("09", "9");
                    }
                    String str = "251" + text;
                    if (TextUtils.equals(str, n.b("").e("recent_login_phone_number"))) {
                        k.a(R$string.basic_can_not_share_to_yourself);
                        return;
                    }
                    l.b(this.d.b.getEditText());
                    A8.c cVar = new A8.c(this);
                    HashMap hashMap = new HashMap();
                    hashMap.put("receiverMsisdn", str);
                    cVar.a(H3.c.e().n(hashMap), new O6.b(cVar, (P2.a) cVar.a));
                    return;
                }
                throw new PhoneNumberException("Invalidate Phone");
            } catch (PhoneNumberException unused) {
                k.a(R$string.checkout_invalid_phone_number_please_check);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [com.huawei.module_basic_ui.share.ShareAppMessageDialogFragment$a, android.text.TextWatcher] */
    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        Spanned spanned;
        ShareAppMessageDialogFragment.super.onViewCreated(view, bundle);
        String string = getString(R$string.thank_you_for_sharing_the_telebirr_super_app_with_your_friend);
        this.d.d.setEnabled(false);
        this.d.b.getEditText().setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        this.d.b.getEditText().setInputType(2);
        this.d.b.getEditText().addTextChangedListener(new a(this));
        this.d.b.getEditText().postDelayed(new e(this, 0), 50);
        if (Build.VERSION.SDK_INT >= 24) {
            spanned = Html.fromHtml(string, 0);
        } else {
            spanned = Html.fromHtml(string);
        }
        this.d.e.setText(spanned);
        this.d.b.getEditText().setHint(getString(R$string.designstandard_phone_number));
    }

    public final void v(BaseResp baseResp) {
        BaseMvvmActivity.V0(new BaseException(baseResp.getResponseCode(), baseResp.getResponseDesc()));
    }

    public final int v0() {
        return R$layout.dialog_share_app_message;
    }
}
