package com.huawei.module_basic_ui.share;

import V1.k;
import android.content.Intent;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.RequiresApi;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.module_basic_ui.R$id;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.R$string;
import com.huawei.module_basic_ui.databinding.ActivityAppShareBinding;
import w5.a;

@Route(path = "/basicUiModule/shareApp")
public class AppShareActivity extends BaseTitleActivity {
    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.module_basic_ui.share.AppShareActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void G0() {
        AppShareActivity.super.G0();
        N0(getString(R$string.designstandard_share));
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_basic_ui.share.AppShareActivity, android.app.Activity] */
    public final ViewBinding K0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_app_share, (ViewGroup) null, false);
        int i = R$id.btn_message;
        if (ViewBindings.findChildViewById(inflate, i) != null) {
            i = R$id.btn_social_network;
            if (ViewBindings.findChildViewById(inflate, i) != null) {
                return new ActivityAppShareBinding((LinearLayout) inflate);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_basic_ui.share.AppShareActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    @RequiresApi(api = 24)
    public void onViewClick(View view) {
        int id = view.getId();
        if (id == R$id.btn_message) {
            new ShareAppMessageDialogFragment().show(getSupportFragmentManager(), "");
            a.a("Share_APP_Message_V1");
        } else if (id == R$id.btn_social_network) {
            String valueOf = String.valueOf(Html.fromHtml(BasicConfig.getInstance().getShareAppMSG(), 0));
            Intent intent = new Intent("android.intent.action.SEND");
            intent.putExtra("android.intent.extra.TEXT", valueOf);
            intent.setType("text/plain");
            try {
                startActivity(Intent.createChooser(intent, getResources().getString(R$string.designstandard_share)));
            } catch (Exception unused) {
                k.b(1, getResources().getString(R$string.designstandard_the_shared_application_component_could_not_be_found));
            }
            a.a("Share_APP_Message_Share_V1");
        }
    }
}
