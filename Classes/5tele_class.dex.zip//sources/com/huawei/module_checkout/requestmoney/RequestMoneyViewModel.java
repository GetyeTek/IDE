package com.huawei.module_checkout.requestmoney;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.module_checkout.requestmoney.resp.CreateRequestMoneyResp;

public class RequestMoneyViewModel extends BaseViewModel {
    public final MutableLiveData<c<CreateRequestMoneyResp>> g = new MutableLiveData<>();
}
