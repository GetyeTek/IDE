package com.huawei.module_checkout.requestmoney;

import V7.c;
import com.huawei.common.exception.BaseException;
import com.huawei.module_checkout.requestmoney.resp.CreateRequestMoneyResp;

public final class a implements R1.a<CreateRequestMoneyResp> {
    public final /* synthetic */ RequestMoneyViewModel a;

    public a(RequestMoneyViewModel requestMoneyViewModel) {
        this.a = requestMoneyViewModel;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final void onError(BaseException baseException) {
        this.a.g.setValue(c.a(baseException));
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        this.a.g.setValue(c.e((CreateRequestMoneyResp) obj));
    }
}
