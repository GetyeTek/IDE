package com.huawei.module_checkout.requestmoney;

import V1.k;
import V7.c;
import V7.f;
import W2.g;
import W2.n;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity;
import com.huawei.module_checkout.requestmoney.resp.CreateRequestMoneyResp;
import com.huawei.module_checkout.requestmoney.resp.RequestMoneyResp;
import i7.C0013a;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Route(path = "/checkoutModule/requestMoneyAmount")
public class RequestMoneyAmountActivity extends P2PTransferPayActivity {
    @Autowired(name = "businessType")
    String businessType;
    @Autowired(name = "orderId")
    String orderId;
    public RequestMoneyViewModel s;
    public String t;
    public String u;

    public class a implements Observer<c<CreateRequestMoneyResp>> {
        public a() {
        }

        public final void onChanged(Object obj) {
            CreateRequestMoneyResp.RequestMoneyOrderInfoBean requestMoneyOrderInfo;
            c cVar = (c) obj;
            FragmentActivity fragmentActivity = RequestMoneyAmountActivity.this;
            f.b(fragmentActivity, cVar);
            if (cVar.b()) {
                f.c(cVar);
            } else if (cVar.f()) {
                RequestMoneyResp requestMoneyResp = new RequestMoneyResp();
                requestMoneyResp.setRequestAmount(fragmentActivity.t);
                requestMoneyResp.setRequestNote(fragmentActivity.u);
                requestMoneyResp.setRequestName(E0.c.f().getNickName());
                requestMoneyResp.setRequestMsisdn(n.b("").e("recent_login_phone_number"));
                CreateRequestMoneyResp createRequestMoneyResp = (CreateRequestMoneyResp) cVar.c;
                if (createRequestMoneyResp != null && (requestMoneyOrderInfo = createRequestMoneyResp.getRequestMoneyOrderInfo()) != null) {
                    requestMoneyResp.setRequestMoneyOrderId(requestMoneyOrderInfo.getRequestMoneyOrderId());
                    x7.a.g.b.onSuccess(requestMoneyResp);
                    fragmentActivity.finish();
                }
            }
        }
    }

    public class b implements C0013a.b<TransferResp> {
        public b() {
        }

        public final /* synthetic */ void a(int i, String str) {
        }

        public final /* synthetic */ void b(CheckoutResp checkoutResp) {
        }

        public final void onCancel() {
        }

        public final void onSuccess(Object obj) {
            RequestMoneyAmountActivity.this.b1((TransferResp) obj);
        }
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [android.content.Context, com.huawei.module_checkout.requestmoney.RequestMoneyAmountActivity, com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity] */
    public final void a1() {
        w5.a.a("Request_money_Next_Send_V1");
        String obj = this.o.getEditableText().toString();
        this.t = obj;
        if (TextUtils.isEmpty(obj)) {
            k.b(1, getString(R$string.designstandard_please_input_amount));
        } else if (!g.a(this.t)) {
            k.b(1, getString(R$string.designstandard_incorrect_amount_format));
        } else {
            this.u = this.n.getText().toString().trim();
            if (n.b("").e("recent_login_phone_number").equals(W0())) {
                k.b(1, getString(R$string.designstandard_sorry_you_cannot_send_money_to_your));
            } else if (TextUtils.isEmpty(this.businessType) || !TextUtils.equals(this.businessType, RequestMoneyResp.REQUEST_MONEY)) {
                HashMap hashMap = new HashMap();
                hashMap.put("amount", this.t);
                hashMap.put("orderId", this.orderId);
                hashMap.put("tradeType", Y0());
                if (!TextUtils.isEmpty(X0())) {
                    HashMap hashMap2 = new HashMap();
                    hashMap2.put("operationNumber", X0());
                    hashMap.put("extraPayParams", hashMap2);
                }
                C0013a.C0002a.a.c(this, getString(R$string.checkout_send), PaySceneEnum.REQUEST_MONEY, hashMap, new b());
            } else {
                o0.b.e(this, "/checkoutModule/requestMoneyAmountInputPin", (Bundle) null, (Map) null, 0, 1);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_checkout.requestmoney.RequestMoneyAmountActivity, com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity, android.app.Activity] */
    public final void b1(TransferResp transferResp) {
        Bundle bundle = new Bundle();
        bundle.putString("transactionTo", Z0());
        bundle.putString("buttonText", getString(R$string.baselib_finished));
        bundle.putSerializable("TransferResp", transferResp);
        o0.b.d((Activity) null, "/basicUiModule/commonSuccess", bundle, (Map) null);
        finish();
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        byte[] byteArrayExtra;
        RequestMoneyAmountActivity.super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null && (byteArrayExtra = intent.getByteArrayExtra("pin")) != null) {
            HashMap hashMap = new HashMap();
            hashMap.put("receiverMsisdn", W0());
            hashMap.put("paymentMethod", "App");
            hashMap.put("payeeType", "1000");
            hashMap.put("amount", this.t);
            hashMap.put("note", this.u);
            hashMap.put("initiatorPin", L3.a.g(new String(byteArrayExtra, StandardCharsets.UTF_8)));
            hashMap.put("pinVersion", L3.a.b.getPinKeyVersion());
            RequestMoneyViewModel requestMoneyViewModel = this.s;
            requestMoneyViewModel.g.setValue(c.c());
            com.huawei.http.b bVar = new com.huawei.http.b();
            bVar.addParams(hashMap);
            bVar.sendRequest(new a(requestMoneyViewModel));
        }
    }

    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        RequestMoneyViewModel requestMoneyViewModel = new ViewModelProvider(this).get(RequestMoneyViewModel.class);
        this.s = requestMoneyViewModel;
        requestMoneyViewModel.g.observe(this, new a());
    }
}
