package com.huawei.module_checkout.requestmoney;

import com.huawei.http.b;
import com.huawei.module_checkout.requestmoney.resp.CreateRequestMoneyResp;

public class CreateRequestMoneyRepository extends b<CreateRequestMoneyResp, CreateRequestMoneyResp> {
    public CreateRequestMoneyRepository() {
        throw null;
    }

    public final String getApiPath() {
        return "v1/ethiopia/createRequestMoneyOrder";
    }
}
