package com.huawei.module_checkout.requestmoney.resp;

import com.huawei.digitalpayment.customer.httplib.response.TransferResp;

public class RequestMoneyResp extends TransferResp {
    public static final String REQUEST_MONEY = "Request Money";
    public static final String REQUEST_MONEY_PAY = "Request Money PAY";
    private String requestAmount;
    private String requestMoneyOrderId;
    private String requestMsisdn;
    private String requestName;
    private String requestNote;
    private TransferResp transferResp;

    public String getRequestAmount() {
        return this.requestAmount;
    }

    public String getRequestMoneyOrderId() {
        return this.requestMoneyOrderId;
    }

    public String getRequestMsisdn() {
        return this.requestMsisdn;
    }

    public String getRequestName() {
        return this.requestName;
    }

    public String getRequestNote() {
        return this.requestNote;
    }

    public TransferResp getTransferResp() {
        return this.transferResp;
    }

    public void setRequestAmount(String str) {
        this.requestAmount = str;
    }

    public void setRequestMoneyOrderId(String str) {
        this.requestMoneyOrderId = str;
    }

    public void setRequestMsisdn(String str) {
        this.requestMsisdn = str;
    }

    public void setRequestName(String str) {
        this.requestName = str;
    }

    public void setRequestNote(String str) {
        this.requestNote = str;
    }

    public void setTransferResp(TransferResp transferResp2) {
        this.transferResp = transferResp2;
    }
}
