package com.huawei.module_checkout.requestmoney.resp;

import com.huawei.http.BaseResp;
import java.io.Serializable;

public class CreateRequestMoneyResp extends BaseResp {
    private RequestMoneyOrderInfoBean requestMoneyOrderInfo;

    public static class RequestMoneyOrderInfoBean implements Serializable {
        private String requestMoneyOrderId;

        public String getRequestMoneyOrderId() {
            return this.requestMoneyOrderId;
        }

        public void setRequestMoneyOrderId(String str) {
            this.requestMoneyOrderId = str;
        }
    }

    public RequestMoneyOrderInfoBean getRequestMoneyOrderInfo() {
        return this.requestMoneyOrderInfo;
    }

    public void setRequestMoneyOrderInfo(RequestMoneyOrderInfoBean requestMoneyOrderInfoBean) {
        this.requestMoneyOrderInfo = requestMoneyOrderInfoBean;
    }
}
