package com.huawei.module_checkout.requestmoney;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class RequestMoneyAmountActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_checkout.requestmoney.RequestMoneyAmountActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (RequestMoneyAmountActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.businessType;
        } else {
            str = r4.getIntent().getExtras().getString("businessType", r4.businessType);
        }
        r4.businessType = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.orderId;
        } else {
            str2 = r4.getIntent().getExtras().getString("orderId", r4.orderId);
        }
        r4.orderId = str2;
    }
}
