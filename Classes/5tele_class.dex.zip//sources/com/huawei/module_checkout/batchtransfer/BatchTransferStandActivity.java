package com.huawei.module_checkout.batchtransfer;

import android.content.Intent;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import java.util.List;

@Route(path = "/checkoutModule/batchTransferPayCheckStand")
public class BatchTransferStandActivity extends CheckStandActivity<BatchTransferViewModel> {
    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_checkout.batchtransfer.BatchTransferStandActivity, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void D0() {
        super.D0();
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra("note");
        String stringExtra2 = intent.getStringExtra("receiverItems");
        String stringExtra3 = intent.getStringExtra("batchNo");
        BatchTransferViewModel batchTransferViewModel = (BatchTransferViewModel) this.b;
        batchTransferViewModel.y = stringExtra;
        batchTransferViewModel.x = stringExtra3;
        batchTransferViewModel.z = (List) new Gson().fromJson(String.valueOf(stringExtra2), new TypeToken().getType());
    }
}
