package com.huawei.module_checkout.batchtransfer;

import com.google.gson.reflect.TypeToken;
import com.huawei.digitalpayment.customer.httplib.request.ReceiverItem;
import java.util.List;

class b extends TypeToken<List<ReceiverItem>> {
}
