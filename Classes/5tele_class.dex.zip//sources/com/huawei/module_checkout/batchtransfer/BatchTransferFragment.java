package com.huawei.module_checkout.batchtransfer;

import A8.C;
import V1.k;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutTransparentBinding;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import i7.C0013a;
import java.util.List;

public class BatchTransferFragment extends Fragment {
    public C a;

    public class a implements Observer<CheckoutResp> {
        public final /* synthetic */ String a;
        public final /* synthetic */ String b;

        public a(String str, String str2) {
            this.a = str;
            this.b = str2;
        }

        public final void onChanged(Object obj) {
            CheckoutResp checkoutResp = (CheckoutResp) obj;
            Bundle bundle = new Bundle();
            bundle.putString("note", this.a);
            bundle.putString("batchNo", checkoutResp.getPrepayId());
            bundle.putString("receiverItems", this.b);
            bundle.putSerializable("CheckoutResp", checkoutResp);
            C0013a.C0002a.a.a(BatchTransferFragment.this.getActivity(), "/checkoutModule/batchTransferPayCheckStand", bundle, new a(this));
        }
    }

    public class b implements Observer<BaseException> {
        public final void onChanged(Object obj) {
            BaseException baseException = (BaseException) obj;
            if (baseException != null) {
                k.b(1, baseException.getResponseDesc());
            }
        }
    }

    public class c implements Observer<Boolean> {
        public c() {
        }

        public final void onChanged(Object obj) {
            boolean booleanValue = ((Boolean) obj).booleanValue();
            BatchTransferFragment batchTransferFragment = BatchTransferFragment.this;
            if (booleanValue) {
                DialogManager.d(batchTransferFragment.getChildFragmentManager(), true);
            } else {
                DialogManager.b(batchTransferFragment.getChildFragmentManager());
            }
        }
    }

    /* JADX WARNING: type inference failed for: r7v4, types: [androidx.lifecycle.Observer, java.lang.Object] */
    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        String string = getArguments().getString("note");
        String string2 = getArguments().getString("receiverItems");
        BatchTransferViewModel batchTransferViewModel = new ViewModelProvider(this).get(BatchTransferViewModel.class);
        getLifecycle().addObserver(batchTransferViewModel);
        batchTransferViewModel.y = string;
        batchTransferViewModel.x = "";
        batchTransferViewModel.z = (List) new Gson().fromJson(String.valueOf(string2), new TypeToken().getType());
        batchTransferViewModel.j.observe(getViewLifecycleOwner(), new a(string, string2));
        batchTransferViewModel.d.observe(getViewLifecycleOwner(), new Object());
        batchTransferViewModel.c.observe(getViewLifecycleOwner(), new c());
        batchTransferViewModel.m((FundsSourceInfoDisplay) null);
        return LayoutTransparentBinding.a(layoutInflater).a;
    }
}
