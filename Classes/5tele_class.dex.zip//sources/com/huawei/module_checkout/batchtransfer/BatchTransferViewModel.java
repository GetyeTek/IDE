package com.huawei.module_checkout.batchtransfer;

import V1.h;
import W2.n;
import android.os.Handler;
import android.os.SystemClock;
import android.text.TextUtils;
import androidx.lifecycle.LiveData;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.httplib.request.BatchCheckoutRequest;
import com.huawei.digitalpayment.customer.httplib.request.ReceiverItem;
import com.huawei.digitalpayment.customer.httplib.response.BatchCheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.BatchQueryCheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutPayMethod;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import e7.C0009b;
import e7.C0010c;
import e7.d;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BatchTransferViewModel extends CheckStandViewModel {
    public final d u = new d();
    public Handler v = new Handler();
    public long w;
    public String x;
    public String y;
    public List<ReceiverItem> z;

    public class a extends BaseViewModel.a<BatchCheckoutResp> {
        public a() {
            super(BatchTransferViewModel.this);
        }

        public final void onSuccess(Object obj) {
            String batchNo = ((BatchCheckoutResp) obj).getBatchNo();
            BatchTransferViewModel batchTransferViewModel = BatchTransferViewModel.this;
            batchTransferViewModel.x = batchNo;
            batchTransferViewModel.n();
        }
    }

    public class b extends BaseViewModel.a<BatchQueryCheckoutResp> {
        public b() {
            super(BatchTransferViewModel.this);
        }

        public final void onSuccess(Object obj) {
            String str;
            BatchQueryCheckoutResp batchQueryCheckoutResp = (BatchQueryCheckoutResp) obj;
            batchQueryCheckoutResp.toString();
            h.b();
            String result = batchQueryCheckoutResp.getResult();
            boolean equals = result.equals("Success");
            BatchTransferViewModel batchTransferViewModel = BatchTransferViewModel.this;
            if (equals) {
                BatchTransferViewModel.super.onSuccess(batchQueryCheckoutResp);
                CheckoutResp checkoutResp = new CheckoutResp();
                checkoutResp.setSubTitle(batchQueryCheckoutResp.getSubTitle());
                checkoutResp.setActualAmountDisplay(batchQueryCheckoutResp.getActualAmountDisplay());
                checkoutResp.setUnit(batchQueryCheckoutResp.getUnit());
                checkoutResp.setConfirmDisplayItems(batchQueryCheckoutResp.getConfirmDisplayItems());
                checkoutResp.setOriginalAmountDisplay(batchQueryCheckoutResp.getOriginalAmountDisplay());
                checkoutResp.setFeeAmountDisplay(batchQueryCheckoutResp.getFeeAmountDisplay());
                ArrayList arrayList = new ArrayList();
                for (CheckoutPayMethod checkoutPayMethod : batchQueryCheckoutResp.getPayMethod()) {
                    FundsSourceInfoDisplay fundsSourceInfoDisplay = new FundsSourceInfoDisplay();
                    if (TextUtils.isEmpty(checkoutPayMethod.getIcon())) {
                        str = "icon_wallet";
                    } else {
                        str = checkoutPayMethod.getIcon();
                    }
                    fundsSourceInfoDisplay.setIcon(str);
                    fundsSourceInfoDisplay.setDisplayContent(checkoutPayMethod.getPayMethodDesc());
                    fundsSourceInfoDisplay.setDefault("true".equals(checkoutPayMethod.getSelected()));
                    fundsSourceInfoDisplay.setFundsSourceDisplay(checkoutPayMethod.getPayMethodDisplay());
                    fundsSourceInfoDisplay.setAccountType(checkoutPayMethod.getAccountTypeDisplay());
                    fundsSourceInfoDisplay.setAvailable("true".equals(checkoutPayMethod.getAvailable()));
                    fundsSourceInfoDisplay.setFundsSource(checkoutPayMethod.getFundsSource());
                    arrayList.add(fundsSourceInfoDisplay);
                }
                checkoutResp.setFundsSourceInfoDisplay(arrayList);
                checkoutResp.setPrepayId(batchTransferViewModel.x);
                batchTransferViewModel.j.setValue(checkoutResp);
                batchTransferViewModel.m.setValue(checkoutResp);
            } else if (result.equals("Processing")) {
                long elapsedRealtime = SystemClock.elapsedRealtime();
                long j = elapsedRealtime - batchTransferViewModel.w;
                if (j >= 1500) {
                    batchTransferViewModel.w = elapsedRealtime;
                    batchTransferViewModel.n();
                    return;
                }
                Handler handler = batchTransferViewModel.v;
                if (handler != null) {
                    handler.postDelayed(new androidx.camera.core.impl.utils.futures.b(this, 2), 1500 - j);
                }
            } else {
                BatchTransferViewModel.super.onError(new BaseException(batchQueryCheckoutResp.getErrorTips()));
            }
        }
    }

    public final LiveData<S2.b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        return null;
    }

    public final LiveData<S2.b<TransferResp>> i(String str) {
        return null;
    }

    public final void m(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        BatchCheckoutRequest batchCheckoutRequest = new BatchCheckoutRequest();
        if (!TextUtils.isEmpty(this.y)) {
            batchCheckoutRequest.setNote(this.y);
        }
        batchCheckoutRequest.setInitiatorMsisdn(n.b("").e("recent_login_phone_number"));
        batchCheckoutRequest.setReceiverItems(this.z);
        if (fundsSourceInfoDisplay != null) {
            batchCheckoutRequest.setFundsSource(fundsSourceInfoDisplay.getFundsSource());
            batchCheckoutRequest.setAccountType(fundsSourceInfoDisplay.getAccountType());
        }
        d dVar = this.u;
        dVar.getClass();
        b(new C0009b(dVar, batchCheckoutRequest).a, new a());
    }

    public final void n() {
        HashMap hashMap = new HashMap();
        hashMap.put("initiatorMsisdn", n.b("").e("recent_login_phone_number"));
        hashMap.put("batchNo", this.x);
        d dVar = this.u;
        dVar.getClass();
        b(new C0010c(dVar, hashMap).a, new b());
    }

    public final void onCleared() {
        BatchTransferViewModel.super.onCleared();
        Handler handler = this.v;
        if (handler != null) {
            handler.removeCallbacksAndMessages((Object) null);
            this.v = null;
        }
    }
}
