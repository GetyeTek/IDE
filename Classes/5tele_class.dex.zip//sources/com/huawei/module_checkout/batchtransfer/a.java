package com.huawei.module_checkout.batchtransfer;

import A8.C;
import A8.D;
import com.google.android.gms.measurement.internal.c;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.batchtransfer.BatchTransferFragment;
import i7.C0013a;
import java.util.HashMap;

public final class a implements C0013a.b<TransferResp> {
    public final /* synthetic */ BatchTransferFragment.a a;

    public a(BatchTransferFragment.a aVar) {
        this.a = aVar;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    public final void onSuccess(Object obj) {
        TransferResp transferResp = (TransferResp) obj;
        C c = BatchTransferFragment.this.a;
        if (c != null) {
            HashMap a2 = c.a("resultCode", "0", "batchNo", transferResp.getOrderId());
            D d = (D) c.b;
            d.i(d.d, a2);
        }
    }
}
