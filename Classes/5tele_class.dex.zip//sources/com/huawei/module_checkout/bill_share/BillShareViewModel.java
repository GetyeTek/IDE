package com.huawei.module_checkout.bill_share;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.checkstand.common.CommonCheckoutRepository;

public final class BillShareViewModel extends ViewModel {
    public final MutableLiveData<c<CheckoutResp>> a = new MutableLiveData<>();
    public CommonCheckoutRepository b;

    public final void onCleared() {
        BillShareViewModel.super.onCleared();
        CommonCheckoutRepository commonCheckoutRepository = this.b;
        if (commonCheckoutRepository != null) {
            commonCheckoutRepository.cancel();
        }
    }
}
