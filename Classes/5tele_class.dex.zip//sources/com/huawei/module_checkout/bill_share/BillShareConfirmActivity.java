package com.huawei.module_checkout.bill_share;

import E0.c;
import H9.b;
import V1.h;
import V1.k;
import V7.e;
import android.os.Bundle;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import c6.j;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.v;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.image.glide.Base64Mode;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$mipmap;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.module_checkout.checkstand.adapter.ConfirmDisplayItemAdapter;
import com.huawei.module_checkout.databinding.ActivityBillShareConfirmBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import f7.C0011a;
import i7.C0013a;
import java.util.HashMap;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.f;

@Route(path = "/checkoutModule/billShareConfirm")
public final class BillShareConfirmActivity extends DataBindingActivity<ActivityBillShareConfirmBinding, BillShareViewModel> {
    public static final /* synthetic */ int j = 0;
    public CheckoutResp d;
    public ConfirmDisplayItemAdapter e;
    public String f;
    public String g;
    public String h;
    public String i;

    public static final class a implements Observer, f {
        public final /* synthetic */ C0011a a;

        public a(C0011a aVar) {
            this.a = aVar;
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof Observer) || !(obj instanceof f)) {
                return false;
            }
            return this.a.equals(((f) obj).getFunctionDelegate());
        }

        public final b<?> getFunctionDelegate() {
            return this.a;
        }

        public final int hashCode() {
            return this.a.hashCode();
        }

        public final /* synthetic */ void onChanged(Object obj) {
            this.a.invoke(obj);
        }
    }

    public final int C0() {
        return R$layout.activity_bill_share_confirm;
    }

    public final void E0() {
        HashMap hashMap = new HashMap();
        hashMap.put("recordId", this.f);
        hashMap.put("billShare", this.h);
        C0013a.C0002a.a.b(this, PaySceneEnum.BILL_SHARE, this.d, hashMap, new f7.b(this));
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.module_checkout.bill_share.BillShareConfirmActivity, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(Bundle bundle) {
        String str;
        BillShareConfirmActivity.super.onCreate(bundle);
        com.blankj.utilcode.util.f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getString(R$string.bill_share_payment), R.layout.common_toolbar);
        this.i = getIntent().getStringExtra("msisdn");
        String stringExtra = getIntent().getStringExtra("amount");
        this.f = getIntent().getStringExtra("recordId");
        this.g = getIntent().getStringExtra("publicName");
        this.h = getIntent().getStringExtra("businessType");
        String str2 = this.i;
        if (str2 == null || str2.length() == 0 || stringExtra == null || stringExtra.length() == 0 || (str = this.f) == null || str.length() == 0) {
            h.b();
            finish();
            k.a(R$string.checkout_params_error);
            return;
        }
        Customer f2 = c.f();
        TextView textView = this.b.f;
        String str3 = this.g;
        if (str3 == null) {
            str3 = f2.getNickName();
        }
        textView.setText(str3);
        Base64Mode consumerMode = Base64Mode.getConsumerMode(f2.getAvatar());
        RoundImageView roundImageView = this.b.b;
        int i2 = R$mipmap.icon_big_head;
        y5.b.a(consumerMode, roundImageView, i2, i2);
        this.b.c.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(this, R$color.colorDividerLight), v.a(0.33f)));
        this.b.c.setLayoutManager(new LinearLayoutManager(this, 1, false));
        ConfirmDisplayItemAdapter confirmDisplayItemAdapter = new ConfirmDisplayItemAdapter(EmptyList.INSTANCE);
        this.e = confirmDisplayItemAdapter;
        this.b.c.setAdapter(confirmDisplayItemAdapter);
        this.b.a.setOnClickListener(new j(2, this, stringExtra));
        MutableLiveData<V7.c<CheckoutResp>> mutableLiveData = this.c.a;
        kotlin.jvm.internal.h.d(mutableLiveData, "null cannot be cast to non-null type androidx.lifecycle.LiveData<com.huawei.payment.mvvm.Resource<com.huawei.digitalpayment.customer.httplib.response.CheckoutResp>>");
        mutableLiveData.observe(this, new a(new C0011a(this)));
        this.b.a.performClick();
    }
}
