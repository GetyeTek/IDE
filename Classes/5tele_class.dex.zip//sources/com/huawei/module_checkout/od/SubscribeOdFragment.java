package com.huawei.module_checkout.od;

import A8.H;
import A8.I;
import android.content.Intent;
import android.os.Bundle;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.HashMap;

public class SubscribeOdFragment extends Fragment {
    public H a;

    public class a implements ActivityResultCallback<ActivityResult> {
        public a() {
        }

        public final void onActivityResult(Object obj) {
            H h;
            ActivityResult activityResult = (ActivityResult) obj;
            Intent data = activityResult.getData();
            SubscribeOdFragment subscribeOdFragment = SubscribeOdFragment.this;
            if (!(data == null || activityResult.getResultCode() != -1 || (h = subscribeOdFragment.a) == null)) {
                String stringExtra = data.getStringExtra("resultCode");
                I i = h.a;
                i.getClass();
                HashMap hashMap = new HashMap();
                hashMap.put("resultCode", stringExtra);
                i.i(i.d, hashMap);
            }
            subscribeOdFragment.requireActivity().getSupportFragmentManager().beginTransaction().remove(subscribeOdFragment).commitAllowingStateLoss();
        }
    }

    public final void onCreate(@Nullable Bundle bundle) {
        SubscribeOdFragment.super.onCreate(bundle);
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new a()).launch(new Intent(getContext(), SubscribeConsumerODActivity.class));
    }
}
