package com.huawei.module_checkout.od;

import D4.q;
import D4.r;
import L3.a;
import W2.n;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutInputPinBinding;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputView;
import com.huawei.module_checkout.R$anim;
import com.huawei.module_checkout.R$color;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import w7.b;
import w7.c;
import w7.e;
import w7.f;

public class SubscribeConsumerODActivity extends BaseMvvmActivity<ConsumerODViewModel> implements View.OnClickListener, PinInputView.a {
    public static final /* synthetic */ int n = 0;
    public final String k = "homev5_nocache";
    public final String l = "creditPayBalanceUpdateTime";
    public LayoutInputPinBinding m;

    public final void C(byte[] bArr) {
        String str = new String(bArr, StandardCharsets.UTF_8);
        ConsumerODViewModel consumerODViewModel = this.i;
        b bVar = consumerODViewModel.g;
        bVar.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("initiatorPin", a.g(str));
        hashMap.put("initiatorMsisdn", n.b("").e("recent_login_phone_number"));
        hashMap.put("pinVersion", a.b.getPinKeyVersion());
        hashMap.put("productId", 11040);
        hashMap.put("agreeTermCondition", "Y");
        consumerODViewModel.b(new w7.a(bVar, hashMap).a, new c(consumerODViewModel));
    }

    public final void D0() {
        this.i.h.observe(this, new q(this, 5));
        this.i.i.observe(this, new r(this, 3));
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_checkout.od.SubscribeConsumerODActivity, com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity, android.view.View$OnClickListener, com.huawei.digitalpayment.customer.viewlib.pininput.PinInputView$a, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity] */
    public final void G0() {
        SubscribeConsumerODActivity.super.G0();
        Q0(getResources().getColor(R$color.homeBg));
        getWindow().addFlags(8192);
        this.m.b.setOnClickListener(this);
        this.m.f.setOnClickListener(new e(this));
        this.m.c.setOnInputListener(new f(this));
        this.m.d.setOnInputFinishListener(this);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_checkout.od.SubscribeConsumerODActivity, android.app.Activity] */
    public final ViewBinding K0() {
        LayoutInputPinBinding a = LayoutInputPinBinding.a(getLayoutInflater());
        this.m = a;
        return a;
    }

    public final boolean L0() {
        return false;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_checkout.od.SubscribeConsumerODActivity, android.app.Activity] */
    public final void W0(boolean z) {
        SubscribeConsumerODActivity.super.finish();
        overridePendingTransition(0, R$anim.from_top_to_bottom);
    }

    public void onClick(View view) {
        W0(true);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_checkout.od.SubscribeConsumerODActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity] */
    public final void onCreate(@Nullable Bundle bundle) {
        overridePendingTransition(R$anim.from_bottom_to_top, R$anim.anim_silent);
        SubscribeConsumerODActivity.super.onCreate(bundle);
    }
}
