package com.huawei.module_checkout.od;

import androidx.lifecycle.MutableLiveData;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import w7.b;

public class ConsumerODViewModel extends BaseViewModel {
    public final b g = new b();
    public final MutableLiveData<BaseException> h = new MutableLiveData<>();
    public final MutableLiveData<Object> i = new MutableLiveData<>();
}
