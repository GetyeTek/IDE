package com.huawei.module_checkout;

import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import com.blankj.utilcode.util.l;
import com.huawei.module_checkout.databinding.FragmentCheckOutBinding;
import java.util.List;

public class CheckOutFragment extends DialogFragment {
    public String a;
    public List<String> b;
    public String c;
    public String d;
    public a e;
    public FragmentCheckOutBinding f;
    public String g;
    public String h;
    public String i;
    public int j;

    public interface a {
        void a(String str, String str2);
    }

    public static void w0(TextView textView, String str) {
        if (!TextUtils.isEmpty(str)) {
            textView.setVisibility(0);
            textView.setText(Html.fromHtml(str));
        }
    }

    public final void onActivityCreated(Bundle bundle) {
        CheckOutFragment.super.onActivityCreated(bundle);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(436207616));
        getDialog().getWindow().setLayout(-1, -1);
    }

    public final void onCreate(@Nullable Bundle bundle) {
        CheckOutFragment.super.onCreate(bundle);
        if (getActivity() != null) {
            getActivity().getWindow().addFlags(8192);
        }
        if (getActivity() != null) {
            l.a(getActivity());
        }
    }

    /* JADX WARNING: type inference failed for: r4v16, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.EditText] */
    /* JADX WARNING: type inference failed for: r1v25, types: [java.lang.Object, android.view.View$OnTouchListener] */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x007d, code lost:
        r4 = com.huawei.module_checkout.R$id.virtualKeyboardView;
     */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r20, @androidx.annotation.Nullable android.view.ViewGroup r21, @androidx.annotation.Nullable android.os.Bundle r22) {
        /*
            r19 = this;
            r0 = r19
            int r1 = com.huawei.module_checkout.R$layout.fragment_check_out
            r2 = 0
            r3 = 0
            r4 = r20
            android.view.View r1 = r4.inflate(r1, r2, r3)
            r5 = r1
            androidx.constraintlayout.widget.ConstraintLayout r5 = (androidx.constraintlayout.widget.ConstraintLayout) r5
            int r4 = com.huawei.module_checkout.R$id.edit_pin
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r15 = r6
            com.huawei.module_checkout.view.CheckOutPinEditText r15 = (com.huawei.module_checkout.view.CheckOutPinEditText) r15
            java.lang.String r14 = "Missing required view with ID: "
            if (r15 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.iv_close
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r7 = r6
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            if (r7 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.line
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            if (r6 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.ll_pay_method
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r8 = r6
            android.widget.LinearLayout r8 = (android.widget.LinearLayout) r8
            if (r8 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.tv_amount
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r9 = r6
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.tv_currency
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r10 = r6
            android.widget.TextView r10 = (android.widget.TextView) r10
            if (r10 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.tv_currency_pre
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r11 = r6
            android.widget.TextView r11 = (android.widget.TextView) r11
            if (r11 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.tv_display_item
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r12 = r6
            android.widget.TextView r12 = (android.widget.TextView) r12
            if (r12 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.tv_sub_title
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r13 = r6
            android.widget.TextView r13 = (android.widget.TextView) r13
            if (r13 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r16 = r6
            android.widget.TextView r16 = (android.widget.TextView) r16
            if (r16 == 0) goto L_0x0204
            int r4 = com.huawei.module_checkout.R$id.virtualKeyboardView
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r4)
            r17 = r6
            com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView r17 = (com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView) r17
            if (r17 == 0) goto L_0x0204
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = new com.huawei.module_checkout.databinding.FragmentCheckOutBinding
            r4 = r1
            r6 = r15
            r18 = r14
            r14 = r16
            r3 = r15
            r15 = r17
            r4.<init>(r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15)
            r0.f = r1
            int r1 = r0.j
            r3.setMaxCount(r1)
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            android.widget.TextView r1 = r1.j
            boolean r3 = android.text.TextUtils.isEmpty(r2)
            if (r3 == 0) goto L_0x00af
            int r3 = com.huawei.digitalpayment.customer.baselib.R.string.baselib_enter_pin
            java.lang.String r3 = r0.getString(r3)
            goto L_0x00b0
        L_0x00af:
            r3 = r2
        L_0x00b0:
            w0(r1, r3)
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            android.widget.TextView r1 = r1.i
            java.lang.String r3 = r0.a
            w0(r1, r3)
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            android.widget.TextView r1 = r1.e
            java.lang.String r3 = r0.c
            w0(r1, r3)
            java.util.List<java.lang.String> r1 = r0.b
            boolean r1 = J8.a.i(r1)
            if (r1 != 0) goto L_0x0106
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r3 = 0
        L_0x00d3:
            java.util.List<java.lang.String> r4 = r0.b
            int r4 = r4.size()
            if (r3 >= r4) goto L_0x00fb
            java.util.List<java.lang.String> r4 = r0.b
            java.lang.Object r4 = r4.get(r3)
            java.lang.String r4 = (java.lang.String) r4
            r1.append(r4)
            java.util.List<java.lang.String> r4 = r0.b
            int r4 = r4.size()
            int r4 = r4 + -1
            if (r3 != r4) goto L_0x00f3
            java.lang.String r4 = ""
            goto L_0x00f5
        L_0x00f3:
            java.lang.String r4 = "<br>"
        L_0x00f5:
            r1.append(r4)
            int r3 = r3 + 1
            goto L_0x00d3
        L_0x00fb:
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r3 = r0.f
            android.widget.TextView r3 = r3.h
            java.lang.String r1 = r1.toString()
            w0(r3, r1)
        L_0x0106:
            java.lang.String r1 = "Prefix"
            java.lang.String r3 = r0.i
            boolean r1 = r1.equals(r3)
            if (r1 == 0) goto L_0x011a
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            android.widget.TextView r1 = r1.g
            java.lang.String r3 = r0.h
            w0(r1, r3)
            goto L_0x0123
        L_0x011a:
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            android.widget.TextView r1 = r1.f
            java.lang.String r3 = r0.h
            w0(r1, r3)
        L_0x0123:
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            com.huawei.module_checkout.view.CheckOutPinEditText r1 = r1.b
            a4.a r3 = new a4.a
            r3.<init>(r0)
            r1.setOnCompleteListener(r3)
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            android.widget.ImageView r1 = r1.c
            O1.e r3 = new O1.e
            r4 = 2
            r3.<init>(r0, r4)
            r1.setOnClickListener(r3)
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView r1 = r1.k
            androidx.fragment.app.FragmentActivity r3 = r19.getActivity()
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r4 = r0.f
            com.huawei.module_checkout.view.CheckOutPinEditText r4 = r4.b
            r1.a(r3, r4)
            java.lang.String r1 = "OD"
            java.lang.String r3 = r0.g
            boolean r1 = r1.equals(r3)
            if (r1 == 0) goto L_0x019c
            android.view.LayoutInflater r1 = r19.getLayoutInflater()
            int r3 = com.huawei.digitalpayment.customer.baselib.R.layout.comp_check_out_over_draft
            r4 = 0
            android.view.View r1 = r1.inflate(r3, r2, r4)
            int r2 = com.huawei.digitalpayment.customer.baselib.R.id.iv_wallet
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r2)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0188
            int r2 = com.huawei.digitalpayment.customer.baselib.R.id.tv_balance
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r2)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x0188
            int r2 = com.huawei.digitalpayment.customer.baselib.R.id.tv_balance_amount
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r2)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x0188
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r2 = r0.f
            android.widget.LinearLayout r2 = r2.d
            r2.addView(r1)
            goto L_0x01d0
        L_0x0188:
            android.content.res.Resources r1 = r1.getResources()
            java.lang.String r1 = r1.getResourceName(r2)
            java.lang.NullPointerException r2 = new java.lang.NullPointerException
            r3 = r18
            java.lang.String r1 = r3.concat(r1)
            r2.<init>(r1)
            throw r2
        L_0x019c:
            r3 = r18
            android.view.LayoutInflater r1 = r19.getLayoutInflater()
            int r4 = com.huawei.digitalpayment.customer.baselib.R.layout.comp_check_out_banlace
            r5 = 0
            android.view.View r1 = r1.inflate(r4, r2, r5)
            int r2 = com.huawei.digitalpayment.customer.baselib.R.id.iv_wallet
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r2)
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            if (r4 == 0) goto L_0x01f2
            int r2 = com.huawei.digitalpayment.customer.baselib.R.id.tv_balance
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r2)
            android.widget.TextView r4 = (android.widget.TextView) r4
            if (r4 == 0) goto L_0x01f2
            int r2 = com.huawei.digitalpayment.customer.baselib.R.id.tv_balance_amount
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r1, r2)
            android.widget.TextView r4 = (android.widget.TextView) r4
            if (r4 == 0) goto L_0x01f2
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r2 = r0.f
            android.widget.LinearLayout r2 = r2.d
            r2.addView(r1)
        L_0x01d0:
            c7.a r1 = new c7.a
            r1.<init>()
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r2 = r0.f
            androidx.constraintlayout.widget.ConstraintLayout r2 = r2.a
            r2.setOnTouchListener(r1)
            android.app.Dialog r1 = r19.getDialog()
            if (r1 == 0) goto L_0x01ed
            android.view.Window r1 = r1.getWindow()
            if (r1 == 0) goto L_0x01ed
            r2 = 8192(0x2000, float:1.14794E-41)
            r1.addFlags(r2)
        L_0x01ed:
            com.huawei.module_checkout.databinding.FragmentCheckOutBinding r1 = r0.f
            androidx.constraintlayout.widget.ConstraintLayout r1 = r1.a
            return r1
        L_0x01f2:
            android.content.res.Resources r1 = r1.getResources()
            java.lang.String r1 = r1.getResourceName(r2)
            java.lang.NullPointerException r2 = new java.lang.NullPointerException
            java.lang.String r1 = r3.concat(r1)
            r2.<init>(r1)
            throw r2
        L_0x0204:
            r3 = r14
            android.content.res.Resources r1 = r1.getResources()
            java.lang.String r1 = r1.getResourceName(r4)
            java.lang.NullPointerException r2 = new java.lang.NullPointerException
            java.lang.String r1 = r3.concat(r1)
            r2.<init>(r1)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.CheckOutFragment.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onDismiss(@NonNull DialogInterface dialogInterface) {
        CheckOutFragment.super.onDismiss(dialogInterface);
        if (getActivity() != null) {
            getActivity().getWindow().clearFlags(8192);
        }
    }

    public final void onPause() {
        CheckOutFragment.super.onPause();
        v0();
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.TextView] */
    public final void v0() {
        this.f.b.setText("");
    }
}
