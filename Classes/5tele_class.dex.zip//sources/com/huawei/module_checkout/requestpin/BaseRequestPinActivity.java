package com.huawei.module_checkout.requestpin;

import B7.e;
import B7.f;
import N1.d;
import O1.a;
import V1.h;
import V2.b;
import W2.n;
import android.util.Base64;
import androidx.appcompat.app.AppCompatActivity;
import com.huawei.biometric.dialog.LocalAuthenticationDialog;
import com.huawei.module_checkout.R$anim;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding;
import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;

public abstract class BaseRequestPinActivity extends AppCompatActivity {
    public static final /* synthetic */ int f = 0;
    public ActivityBaseRequestPinBinding a;
    public String b;
    public String c = "";
    public String d;
    public String e;

    public static void C0(BaseRequestPinActivity baseRequestPinActivity, int i, Cipher cipher) {
        baseRequestPinActivity.getClass();
        try {
            String e2 = n.b("").e("recent_login_phone_number");
            n b2 = n.b("Biometric");
            baseRequestPinActivity.D0(new String(cipher.doFinal(Base64.decode(b2.e("FINGERPRINT_PAY_PIN_KEY_" + e2 + "_" + i), 2)), StandardCharsets.UTF_8));
        } catch (Exception e3) {
            e3.getMessage();
            h.b();
        }
    }

    public abstract void D0(String str);

    public final void E0() {
        String e2 = n.b("").e("recent_login_phone_number");
        n b2 = n.b("Biometric");
        if (b2.a.getInt(b.a("key_biometric_pay_id_", e2), 0) == 2) {
            String e3 = n.b("").e("recent_login_phone_number");
            n b3 = n.b("Biometric");
            a aVar = new a(this, d.b("FingerprintPay", b3.e("FINGERPRINT_PAY_IV_KEY_" + e3 + "_2"), true));
            aVar.c = new e(this, 0);
            aVar.a(R$string.checkout_please_verify_your_fingerprint, R$string.designstandard_cancel);
            return;
        }
        String e4 = n.b("").e("recent_login_phone_number");
        n b4 = n.b("Biometric");
        LocalAuthenticationDialog localAuthenticationDialog = new LocalAuthenticationDialog(d.b("FacePay", b4.e("FINGERPRINT_PAY_IV_KEY_" + e4 + "_1"), false));
        localAuthenticationDialog.c = new f(this);
        localAuthenticationDialog.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.app.Activity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity] */
    public final void finish() {
        BaseRequestPinActivity.super.finish();
        overridePendingTransition(0, R$anim.from_top_to_bottom);
    }

    public final void onBackPressed() {
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.content.Context, java.lang.Object, android.app.Activity, androidx.appcompat.app.AppCompatActivity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity, androidx.fragment.app.FragmentActivity] */
    /* JADX WARNING: type inference failed for: r1v5, types: [android.widget.EditText] */
    /* JADX WARNING: type inference failed for: r2v6, types: [java.lang.Object, androidx.core.view.OnApplyWindowInsetsListener] */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x009e, code lost:
        r4 = com.huawei.module_checkout.R$id.virtualKeyboardView;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0030, code lost:
        r4 = com.huawei.module_checkout.R$id.bg_view;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onCreate(@androidx.annotation.Nullable android.os.Bundle r18) {
        /*
            r17 = this;
            r0 = r17
            android.view.Window r1 = r17.getWindow()
            r2 = 8192(0x2000, float:1.14794E-41)
            r1.addFlags(r2)
            com.huawei.module_checkout.requestpin.BaseRequestPinActivity.super.onCreate(r18)
            r1 = 0
            com.blankj.utilcode.util.f.e(r0, r1, r1)
            r2 = 1
            com.blankj.utilcode.util.f.f(r0, r2)
            int r3 = com.huawei.module_checkout.R$anim.from_bottom_to_top
            r0.overridePendingTransition(r3, r1)
            android.view.LayoutInflater r3 = r17.getLayoutInflater()
            int r4 = com.huawei.module_checkout.R$layout.activity_base_request_pin
            r5 = 0
            android.view.View r3 = r3.inflate(r4, r5, r1)
            int r4 = com.huawei.module_checkout.R$id.barrier
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            androidx.constraintlayout.widget.Barrier r5 = (androidx.constraintlayout.widget.Barrier) r5
            if (r5 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.bg_view
            android.view.View r7 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            if (r7 == 0) goto L_0x01d4
            r6 = r3
            androidx.constraintlayout.widget.ConstraintLayout r6 = (androidx.constraintlayout.widget.ConstraintLayout) r6
            int r4 = com.huawei.module_checkout.R$id.edit_pin
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r15 = r5
            com.huawei.module_checkout.view.CheckOutPinEditText r15 = (com.huawei.module_checkout.view.CheckOutPinEditText) r15
            if (r15 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.iv_close
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r9 = r5
            android.widget.ImageView r9 = (android.widget.ImageView) r9
            if (r9 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.rb_channel
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r10 = r5
            android.widget.RadioGroup r10 = (android.widget.RadioGroup) r10
            if (r10 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.rb_channel_reward
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r11 = r5
            android.widget.RadioButton r11 = (android.widget.RadioButton) r11
            if (r11 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.rb_channel_wallet
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r12 = r5
            android.widget.RadioButton r12 = (android.widget.RadioButton) r12
            if (r12 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.tv_amount
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r13 = r5
            android.widget.TextView r13 = (android.widget.TextView) r13
            if (r13 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.tv_currency
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r14 = r5
            android.widget.TextView r14 = (android.widget.TextView) r14
            if (r14 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.tv_pay_by_fingerprint
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r16 = r5
            android.widget.TextView r16 = (android.widget.TextView) r16
            if (r16 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x01d4
            int r4 = com.huawei.module_checkout.R$id.virtualKeyboardView
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            r8 = r5
            com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView r8 = (com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView) r8
            if (r8 == 0) goto L_0x01d4
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r3 = new com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding
            r5 = r3
            r4 = r8
            r8 = r15
            r1 = r15
            r15 = r16
            r16 = r4
            r5.<init>(r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16)
            r0.a = r3
            r4.a(r0, r1)
            android.content.Intent r1 = r17.getIntent()
            java.lang.String r3 = "channels"
            java.lang.String r1 = r1.getStringExtra(r3)
            r0.b = r1
            android.content.Intent r1 = r17.getIntent()
            java.lang.String r3 = "pinAmount"
            java.lang.String r1 = r1.getStringExtra(r3)
            r0.d = r1
            android.content.Intent r1 = r17.getIntent()
            java.lang.String r3 = "pinCurrency"
            java.lang.String r1 = r1.getStringExtra(r3)
            r0.e = r1
            java.lang.String r1 = r0.b
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            r3 = 8
            if (r1 == 0) goto L_0x00f1
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            android.widget.RadioGroup r1 = r1.e
            r1.setVisibility(r3)
            goto L_0x00f5
        L_0x00f1:
            java.lang.String r1 = r0.b
            r0.c = r1
        L_0x00f5:
            java.lang.String r1 = r0.d
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 != 0) goto L_0x0119
            java.lang.String r1 = r0.e
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 == 0) goto L_0x0106
            goto L_0x0119
        L_0x0106:
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            android.widget.TextView r1 = r1.h
            java.lang.String r3 = r0.d
            r1.setText(r3)
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            android.widget.TextView r1 = r1.i
            java.lang.String r3 = r0.e
            r1.setText(r3)
            goto L_0x0127
        L_0x0119:
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            android.widget.TextView r1 = r1.h
            r1.setVisibility(r3)
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            android.widget.TextView r1 = r1.i
            r1.setVisibility(r3)
        L_0x0127:
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            com.huawei.module_checkout.view.CheckOutPinEditText r1 = r1.c
            B7.a r3 = new B7.a
            r3.<init>(r0)
            r1.setOnCompleteListener(r3)
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            android.widget.TextView r1 = r1.j
            B7.b r3 = new B7.b
            r4 = 0
            r3.<init>(r0, r4)
            r1.setOnClickListener(r3)
            java.lang.String r1 = "FingerprintPay"
            boolean r3 = N1.d.a(r1, r2)
            r4 = 2
            if (r3 == 0) goto L_0x014c
            G2.b.c(r4)
        L_0x014c:
            boolean r3 = G2.b.g()
            if (r3 == 0) goto L_0x018c
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r3 = r0.a
            android.widget.TextView r3 = r3.j
            r5 = 0
            r3.setVisibility(r5)
            java.lang.String r3 = ""
            W2.n r3 = W2.n.b(r3)
            java.lang.String r5 = "recent_login_phone_number"
            java.lang.String r3 = r3.e(r5)
            java.lang.String r5 = "Biometric"
            W2.n r5 = W2.n.b(r5)
            java.lang.String r6 = "key_biometric_pay_id_"
            java.lang.String r3 = V2.b.a(r6, r3)
            android.content.SharedPreferences r5 = r5.a
            r6 = 0
            int r3 = r5.getInt(r3, r6)
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r5 = r0.a
            android.widget.TextView r5 = r5.j
            if (r3 != r4) goto L_0x0186
            int r3 = com.huawei.module_checkout.R$string.baselib_fingerprint
        L_0x0181:
            java.lang.String r3 = r0.getString(r3)
            goto L_0x0189
        L_0x0186:
            int r3 = com.huawei.module_checkout.R$string.baselib_use_face_id
            goto L_0x0181
        L_0x0189:
            r5.setText(r3)
        L_0x018c:
            boolean r1 = N1.d.a(r1, r2)
            if (r1 == 0) goto L_0x0195
            G2.b.c(r4)
        L_0x0195:
            boolean r1 = G2.b.g()
            if (r1 == 0) goto L_0x01a4
            boolean r1 = G2.b.h()
            if (r1 == 0) goto L_0x01a4
            r17.E0()
        L_0x01a4:
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            android.widget.ImageView r1 = r1.d
            B7.c r2 = new B7.c
            r3 = 0
            r2.<init>(r0, r3)
            r1.setOnClickListener(r2)
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            androidx.constraintlayout.widget.ConstraintLayout r1 = r1.a
            r0.setContentView(r1)
            com.blankj.utilcode.util.l.a(r17)
            com.huawei.module_checkout.databinding.ActivityBaseRequestPinBinding r1 = r0.a
            androidx.constraintlayout.widget.ConstraintLayout r1 = r1.a
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 35
            if (r2 < r3) goto L_0x01d3
            if (r1 == 0) goto L_0x01d3
            r2 = 0
            r1.setFitsSystemWindows(r2)
            B7.d r2 = new B7.d
            r2.<init>()
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(r1, r2)
        L_0x01d3:
            return
        L_0x01d4:
            android.content.res.Resources r1 = r3.getResources()
            java.lang.String r1 = r1.getResourceName(r4)
            java.lang.NullPointerException r2 = new java.lang.NullPointerException
            java.lang.String r3 = "Missing required view with ID: "
            java.lang.String r1 = r3.concat(r1)
            r2.<init>(r1)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.requestpin.BaseRequestPinActivity.onCreate(android.os.Bundle):void");
    }
}
