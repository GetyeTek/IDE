package com.huawei.module_checkout.inapp.adapter;

import O9.c;
import android.text.Html;
import android.text.TextUtils;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.module_checkout.R$id;

public class PaymentMethodSelectAdapter extends BaseQuickAdapter<FundsSourceInfoDisplay, BaseViewHolder> {
    public FundsSourceInfoDisplay a;

    public PaymentMethodSelectAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        FundsSourceInfoDisplay fundsSourceInfoDisplay = (FundsSourceInfoDisplay) obj;
        baseViewHolder.setText(R$id.tv_title, fundsSourceInfoDisplay.getFundsSourceDisplay());
        String displayContent = fundsSourceInfoDisplay.getDisplayContent();
        if (!TextUtils.isEmpty(displayContent)) {
            baseViewHolder.setText(R$id.tv_subtitle, Html.fromHtml(displayContent));
        } else {
            baseViewHolder.setText(R$id.tv_subtitle, "");
        }
        baseViewHolder.setVisible(R$id.iv_selected, fundsSourceInfoDisplay.equals(this.a));
        c.c((ImageView) baseViewHolder.getView(R$id.iv_icon), fundsSourceInfoDisplay.getIcon(), -1);
        if (!fundsSourceInfoDisplay.isAvailable()) {
            baseViewHolder.itemView.setClickable(false);
            baseViewHolder.itemView.setAlpha(0.4f);
            return;
        }
        baseViewHolder.itemView.setClickable(true);
        baseViewHolder.itemView.setAlpha(1.0f);
    }
}
