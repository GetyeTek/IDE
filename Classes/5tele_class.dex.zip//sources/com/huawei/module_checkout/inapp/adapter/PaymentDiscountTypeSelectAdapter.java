package com.huawei.module_checkout.inapp.adapter;

import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.module_checkout.R$id;

public class PaymentDiscountTypeSelectAdapter extends BaseQuickAdapter<CouponBean, BaseViewHolder> {
    public CouponBean a;

    public PaymentDiscountTypeSelectAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        CouponBean couponBean = (CouponBean) obj;
        baseViewHolder.setText(R$id.tv_title, couponBean.getCouponNameDisplay());
        baseViewHolder.setVisible(R$id.iv_selected, couponBean.equals(this.a));
    }
}
