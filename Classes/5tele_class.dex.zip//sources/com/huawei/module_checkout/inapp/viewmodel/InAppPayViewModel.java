package com.huawei.module_checkout.inapp.viewmodel;

import L3.a;
import android.text.TextUtils;
import android.util.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import java.util.ArrayList;
import t7.b;

public class InAppPayViewModel extends CheckStandViewModel {
    public String u;
    public String v;
    public String w;
    public String x;
    public final b y = new b();

    public final LiveData<S2.b<CheckoutResp>> f(CouponBean couponBean) {
        return m(couponBean, (FundsSourceInfoDisplay) this.k.getValue());
    }

    public final LiveData<S2.b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        return m((CouponBean) this.l.getValue(), fundsSourceInfoDisplay);
    }

    public final LiveData<S2.b<TransferResp>> i(String str) {
        ArrayMap arrayMap = new ArrayMap();
        arrayMap.put("initiatorPin", a.g(str));
        arrayMap.put("pinVersion", a.b.getPinKeyVersion());
        arrayMap.put("prepayId", this.w);
        b bVar = this.y;
        bVar.getClass();
        return new t7.a(bVar, arrayMap).a;
    }

    public final MediatorLiveData m(CouponBean couponBean, FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        ArrayMap arrayMap = new ArrayMap();
        arrayMap.put("appId", this.u);
        arrayMap.put("merchCode", this.v);
        arrayMap.put("prepayId", this.w);
        arrayMap.put("tradeType", "Cross-App");
        if (fundsSourceInfoDisplay != null) {
            arrayMap.put("accountType", fundsSourceInfoDisplay.getAccountType());
            arrayMap.put("fundsSource", fundsSourceInfoDisplay.getFundsSource());
        }
        if (couponBean != null) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(couponBean.getCouponId());
            arrayMap.put("coupons", arrayList);
        }
        if (!TextUtils.isEmpty(this.x)) {
            arrayMap.put("rawRequest", this.x);
        }
        b bVar = this.y;
        bVar.getClass();
        return new C7.a(bVar, arrayMap, 1).a;
    }
}
