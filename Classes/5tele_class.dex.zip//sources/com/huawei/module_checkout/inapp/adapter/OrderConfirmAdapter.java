package com.huawei.module_checkout.inapp.adapter;

import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;

public class OrderConfirmAdapter extends BaseQuickAdapter<CheckoutResp.PayDisplayItem, BaseViewHolder> {
    public OrderConfirmAdapter() {
        super(R$layout.item_order_confirm);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        CheckoutResp.PayDisplayItem payDisplayItem = (CheckoutResp.PayDisplayItem) obj;
        baseViewHolder.setText(R$id.tv_title, payDisplayItem.getTitle());
        baseViewHolder.setText(R$id.tv_content, payDisplayItem.getContent());
    }
}
