package com.huawei.module_checkout.inapp;

import V1.h;
import android.content.Intent;
import android.os.Build;
import android.os.RemoteException;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.databinding.ActivityPaySdkEnterBinding;
import java.lang.ref.WeakReference;
import org.json.JSONException;
import org.json.JSONObject;
import q7.b;
import q7.c;

@Route(path = "/checkoutModule/inAppPayEnter")
public class PaySdkEnterActivity extends BaseActivity implements s7.a {
    public c d;
    public v5.a e;

    public class a implements Runnable {
        public final /* synthetic */ int a;
        public final /* synthetic */ String b;

        public a(int i, String str) {
            this.a = i;
            this.b = str;
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [android.content.Context, com.huawei.module_checkout.inapp.PaySdkEnterActivity, android.app.Activity] */
        public final void run() {
            ? r0 = PaySdkEnterActivity.this;
            v5.a aVar = r0.e;
            String str = this.b;
            int i = this.a;
            if (aVar != null) {
                try {
                    aVar.l(i, str);
                    r0.unbindService(r0.d);
                } catch (RemoteException e) {
                    e.getMessage();
                    h.b();
                }
            }
            String stringExtra = r0.getIntent().getStringExtra("returnApp");
            if (!TextUtils.isEmpty(stringExtra)) {
                try {
                    JSONObject jSONObject = new JSONObject(stringExtra);
                    String string = jSONObject.getString("activity");
                    String string2 = jSONObject.getString("packageName");
                    if (!TextUtils.isEmpty(string) && !TextUtils.isEmpty(string2)) {
                        Intent intent = new Intent(string);
                        intent.addCategory("android.intent.category.DEFAULT");
                        intent.setFlags(268435456);
                        intent.setPackage(string2);
                        intent.putExtra("msg", str);
                        intent.putExtra("code", i);
                        JSONObject jSONObject2 = new JSONObject();
                        if (i == 0) {
                            i = 2;
                        }
                        jSONObject2.put("tradeStatus", i);
                        intent.putExtra("data", jSONObject2.toString());
                        r0.startActivity(intent);
                    }
                } catch (JSONException e2) {
                    e2.getMessage();
                    h.b();
                }
            }
            r0.finish();
        }
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_checkout.inapp.PaySdkEnterActivity, android.app.Activity] */
    public final ViewBinding C0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_pay_sdk_enter, (ViewGroup) null, false);
        if (inflate != null) {
            return new ActivityPaySdkEnterBinding((LinearLayout) inflate);
        }
        throw new NullPointerException("rootView");
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [android.content.Context, com.huawei.module_checkout.inapp.PaySdkEnterActivity, java.lang.Object, android.app.Activity] */
    public final void D0() {
        Intent intent = getIntent();
        b bVar = b.a.a;
        bVar.b = new WeakReference<>(this);
        bVar.a(this, intent.getStringExtra("appId"), intent.getStringExtra("shortCode"), intent.getStringExtra("receiveCode"), intent.getStringExtra("rawRequest"), false);
        String stringExtra = getIntent().getStringExtra("packageName");
        if (!TextUtils.isEmpty(stringExtra)) {
            Intent intent2 = new Intent();
            intent2.setClassName(stringExtra, "com.huawei.ethiopia.pay.sdk.api.core.service.PayService");
            c cVar = new c(this);
            this.d = cVar;
            if (Build.VERSION.SDK_INT >= 34) {
                bindService(intent2, cVar, 513);
            } else {
                bindService(intent2, cVar, 1);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_checkout.inapp.PaySdkEnterActivity, android.app.Activity] */
    public final void G0() {
        f.e(this, -1, false);
        f.f(this, true);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_checkout.inapp.PaySdkEnterActivity, android.app.Activity] */
    public final void h(int i, String str) {
        h.b();
        runOnUiThread(new a(i, str));
    }
}
