package com.huawei.module_checkout.inapp.activity;

import android.content.Intent;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import com.huawei.module_checkout.inapp.viewmodel.InAppPayViewModel;

@Route(path = "/checkoutModule/inAppCheckStand")
public class InAppCheckStandActivity extends CheckStandActivity<InAppPayViewModel> {
    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity, com.huawei.module_checkout.inapp.activity.InAppCheckStandActivity] */
    public final void D0() {
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra("appId");
        String stringExtra2 = intent.getStringExtra("shortCode");
        String stringExtra3 = intent.getStringExtra("orderNo");
        InAppPayViewModel inAppPayViewModel = (InAppPayViewModel) this.b;
        inAppPayViewModel.u = stringExtra;
        inAppPayViewModel.v = stringExtra2;
        inAppPayViewModel.w = stringExtra3;
        super.D0();
    }
}
