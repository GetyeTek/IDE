package com.huawei.module_checkout.inapp;

import V1.h;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.databinding.ActivityPaySdkEnterBinding;
import java.lang.ref.WeakReference;
import q7.b;
import s7.a;

@Route(path = "/checkoutModule/h5CrossAppPayEnter")
public class H5PayEnterActivity extends BaseActivity implements a {
    public String d;

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_checkout.inapp.H5PayEnterActivity, android.app.Activity] */
    public final ViewBinding C0() {
        View inflate = getLayoutInflater().inflate(R$layout.activity_pay_sdk_enter, (ViewGroup) null, false);
        if (inflate != null) {
            return new ActivityPaySdkEnterBinding((LinearLayout) inflate);
        }
        throw new NullPointerException("rootView");
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [com.huawei.module_checkout.inapp.H5PayEnterActivity, java.lang.Object, android.app.Activity] */
    public final void D0() {
        Intent intent = getIntent();
        b bVar = b.a.a;
        bVar.b = new WeakReference<>(this);
        String stringExtra = intent.getStringExtra("appId");
        String stringExtra2 = intent.getStringExtra("shortCode");
        String stringExtra3 = intent.getStringExtra("receiveCode");
        String stringExtra4 = intent.getStringExtra("rawRequest");
        this.d = intent.getStringExtra("callbackUrl");
        bVar.a(this, stringExtra, stringExtra2, stringExtra3, stringExtra4, true);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_checkout.inapp.H5PayEnterActivity, android.app.Activity] */
    public final void G0() {
        f.e(this, -1, false);
        f.f(this, true);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_checkout.inapp.H5PayEnterActivity, android.app.Activity] */
    public final void h(int i, String str) {
        h.b();
        if (!TextUtils.isEmpty(this.d)) {
            A.h(new q7.a(this, i, str), 200);
        }
        finish();
    }
}
