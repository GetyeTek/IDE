package com.huawei.module_checkout.inapp.activity;

import android.content.res.Resources;
import android.os.Bundle;
import androidx.lifecycle.Observer;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.databinding.ActivityInAppPayBinding;
import com.huawei.module_checkout.inapp.adapter.OrderConfirmAdapter;
import com.huawei.module_checkout.inapp.viewmodel.InAppPayViewModel;
import i7.C0013a;
import java.util.ArrayList;
import q7.b;

@Route(path = "/checkoutModule/inAppPay")
public class InAppPayActivity extends BaseMvvmActivity<InAppPayViewModel> {
    public static final /* synthetic */ int r = 0;
    public ActivityInAppPayBinding k;
    public OrderConfirmAdapter l;
    public String m;
    public String n;
    public String o;
    public String p;
    public boolean q;

    public class a implements Observer<CheckoutResp> {
        public a() {
        }

        /* JADX WARNING: type inference failed for: r0v1, types: [android.content.Context, com.huawei.module_checkout.inapp.activity.InAppPayActivity, android.app.Activity] */
        public final void onChanged(Object obj) {
            String str;
            CheckoutResp checkoutResp = (CheckoutResp) obj;
            b bVar = b.a.a;
            bVar.a.clear();
            bVar.a = null;
            ? r0 = InAppPayActivity.this;
            r0.k.d.setText(checkoutResp.getActualAmountDisplay());
            r0.k.e.setText(checkoutResp.getUnit());
            ArrayList arrayList = new ArrayList();
            if (checkoutResp.getPayDisplayItems() == null || checkoutResp.getPayDisplayItems().isEmpty()) {
                arrayList.add(new CheckoutResp.PayDisplayItem(r0.getString(R$string.designstandard_order_amount), checkoutResp.getOriginalAmountDisplayWithUnit()));
                arrayList.add(new CheckoutResp.PayDisplayItem(r0.getString(R$string.designstandard_merchant_name), checkoutResp.getOppositeName()));
                arrayList.add(new CheckoutResp.PayDisplayItem(r0.getString(R$string.designstandard_transaction_time), checkoutResp.getFormatServerTimestamp()));
                arrayList.add(new CheckoutResp.PayDisplayItem(r0.getString(R$string.designstandard_total_fee), checkoutResp.getFeeAmountDisplayWithUnit()));
            } else {
                arrayList.addAll(checkoutResp.getPayDisplayItems());
            }
            r0.l.setNewData(arrayList);
            Bundle bundle = new Bundle();
            bundle.putSerializable("CheckoutResp", checkoutResp);
            bundle.putString("appId", r0.m);
            bundle.putString("shortCode", r0.n);
            if (!r0.q) {
                str = r0.o;
            } else {
                str = checkoutResp.getPrepayId();
            }
            bundle.putString("orderNo", str);
            C0013a.C0002a.a.a(r0, "/checkoutModule/inAppCheckStand", bundle, new r7.b(r0));
        }
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [com.huawei.module_checkout.inapp.activity.InAppPayActivity, com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity, android.app.Activity] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x005c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void D0() {
        /*
            r6 = this;
            android.content.Intent r0 = r6.getIntent()
            java.lang.String r1 = "appId"
            java.lang.String r1 = r0.getStringExtra(r1)
            r6.m = r1
            java.lang.String r1 = "shortCode"
            java.lang.String r1 = r0.getStringExtra(r1)
            r6.n = r1
            java.lang.String r1 = "receiveCode"
            java.lang.String r1 = r0.getStringExtra(r1)
            java.lang.String r2 = "rawRequest"
            java.lang.String r2 = r0.getStringExtra(r2)
            r6.p = r2
            java.lang.String r2 = "isH5Pay"
            r3 = 0
            boolean r0 = r0.getBooleanExtra(r2, r3)
            r6.q = r0
            boolean r0 = android.text.TextUtils.isEmpty(r1)
            r2 = 0
            if (r0 != 0) goto L_0x0040
            java.lang.String r0 = "\\$"
            java.lang.String[] r0 = r1.split(r0)
            int r1 = r0.length
            r3 = 6
            if (r1 != r3) goto L_0x0040
            r1 = 4
            r0 = r0[r1]
            goto L_0x0041
        L_0x0040:
            r0 = r2
        L_0x0041:
            r6.o = r0
            V1.h.b()
            V1.h.b()
            V1.h.b()
            V1.h.b()
            V1.h.b()
            V1.h.b()
            V1.h.b()
            boolean r0 = r6.q
            if (r0 != 0) goto L_0x007d
            java.lang.String r0 = r6.m
            java.lang.String r1 = r6.n
            java.lang.String r3 = r6.o
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x0075
            boolean r0 = android.text.TextUtils.isEmpty(r1)
            if (r0 != 0) goto L_0x0075
            boolean r0 = android.text.TextUtils.isEmpty(r3)
            if (r0 != 0) goto L_0x0075
            goto L_0x007d
        L_0x0075:
            r0 = -2
            q7.b.b(r0)
            r6.finish()
            return
        L_0x007d:
            com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel r0 = r6.i
            com.huawei.module_checkout.inapp.viewmodel.InAppPayViewModel r0 = (com.huawei.module_checkout.inapp.viewmodel.InAppPayViewModel) r0
            java.lang.String r1 = r6.m
            java.lang.String r3 = r6.n
            java.lang.String r4 = r6.o
            java.lang.String r5 = r6.p
            r0.u = r1
            r0.v = r3
            r0.w = r4
            r0.x = r5
            androidx.lifecycle.MediatorLiveData r1 = r0.m(r2, r2)
            u7.a r2 = new u7.a
            r2.<init>(r0)
            r0.b(r1, r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.inapp.activity.InAppPayActivity.D0():void");
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_checkout.inapp.activity.InAppPayActivity, com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, androidx.appcompat.app.AppCompatActivity, android.app.Activity] */
    public final void G0() {
        InAppPayActivity.super.G0();
        N0(getString(R$string.baselib_payment));
        Resources resources = getResources();
        int i = R$color.colorSecondary;
        findViewById(R$id.base_toolbar).setBackgroundColor(resources.getColor(i));
        f.e(this, getResources().getColor(i), false);
        f.f(this, false);
        this.k.b.setOnClickListener(new D6.a(this, 7));
        OrderConfirmAdapter orderConfirmAdapter = new OrderConfirmAdapter();
        this.l = orderConfirmAdapter;
        this.k.c.setAdapter(orderConfirmAdapter);
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.module_checkout.inapp.activity.InAppPayActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0029, code lost:
        r1 = com.huawei.module_checkout.R$id.rv_list;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r9 = this;
            android.view.LayoutInflater r0 = r9.getLayoutInflater()
            int r1 = com.huawei.module_checkout.R$layout.activity_in_app_pay
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_checkout.R$id.confirm
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r5 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r5
            if (r5 == 0) goto L_0x0060
            int r1 = com.huawei.module_checkout.R$id.fl_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.FrameLayout r2 = (android.widget.FrameLayout) r2
            if (r2 == 0) goto L_0x0060
            int r1 = com.huawei.module_checkout.R$id.line
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x0060
            int r1 = com.huawei.module_checkout.R$id.rv_list
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            androidx.recyclerview.widget.RecyclerView r6 = (androidx.recyclerview.widget.RecyclerView) r6
            if (r6 == 0) goto L_0x0060
            int r1 = com.huawei.module_checkout.R$id.transfer_to_merchant
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.fragment.app.FragmentContainerView r2 = (androidx.fragment.app.FragmentContainerView) r2
            if (r2 == 0) goto L_0x0060
            int r1 = com.huawei.module_checkout.R$id.tv_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            if (r7 == 0) goto L_0x0060
            int r1 = com.huawei.module_checkout.R$id.tv_amount_unit
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0060
            com.huawei.module_checkout.databinding.ActivityInAppPayBinding r1 = new com.huawei.module_checkout.databinding.ActivityInAppPayBinding
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8)
            r9.k = r1
            return r1
        L_0x0060:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.inapp.activity.InAppPayActivity.K0():androidx.viewbinding.ViewBinding");
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [androidx.lifecycle.Observer, java.lang.Object] */
    public final void U0() {
        InAppPayActivity.super.U0();
        this.i.j.observe(this, new a());
        this.i.d.observe(this, new Object());
    }

    public final void onBackPressed() {
        InAppPayActivity.super.onBackPressed();
        b.b(-3);
    }
}
