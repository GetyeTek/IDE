package com.huawei.module_checkout.htmlpay.activity;

import V1.k;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.R$string;
import i7.C0013a;
import java.util.ArrayList;

public final /* synthetic */ class b implements Observer {
    public final /* synthetic */ H5PayConfirmActivity a;

    public /* synthetic */ b(H5PayConfirmActivity h5PayConfirmActivity) {
        this.a = h5PayConfirmActivity;
    }

    public final void onChanged(Object obj) {
        S2.b bVar = (S2.b) obj;
        int i = H5PayConfirmActivity.f;
        FragmentActivity fragmentActivity = this.a;
        if (bVar.d()) {
            DialogManager.d(fragmentActivity.getSupportFragmentManager(), true);
        } else {
            DialogManager.b(fragmentActivity.getSupportFragmentManager());
        }
        if (bVar.b()) {
            k.b(1, bVar.b.getMessage());
        }
        Object obj2 = bVar.c;
        if (obj2 != null && bVar.f()) {
            CheckoutResp checkoutResp = (CheckoutResp) obj2;
            ArrayList arrayList = new ArrayList();
            arrayList.add(new DisplayItem(fragmentActivity.getString(R$string.designstandard_order_amount), checkoutResp.getOriginalAmountDisplayWithUnit()));
            arrayList.add(new DisplayItem(fragmentActivity.getString(R$string.designstandard_merchant_name), checkoutResp.getOppositeName()));
            arrayList.add(new DisplayItem(fragmentActivity.getString(R$string.designstandard_transaction_time), checkoutResp.getFormatServerTimestamp()));
            arrayList.add(new DisplayItem(fragmentActivity.getString(R$string.designstandard_total_fee), checkoutResp.getFeeAmountDisplayWithUnit()));
            fragmentActivity.d.setNewData(arrayList);
            Bundle bundle = new Bundle();
            bundle.putString("appId", fragmentActivity.appId);
            bundle.putString("merchCode", fragmentActivity.merchCode);
            bundle.putString("prepayId", checkoutResp.getPrepayId());
            bundle.putString("tradeType", fragmentActivity.tradeType);
            bundle.putSerializable("CheckoutResp", checkoutResp);
            C0013a.C0002a.a.a(fragmentActivity, "/checkoutModule/h5PayCheckStand", bundle, new d(fragmentActivity));
        }
    }
}
