package com.huawei.module_checkout.htmlpay.activity;

import android.app.Activity;
import android.os.Bundle;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.R$string;
import com.huawei.payment.mvvm.DataBindingActivity;
import i7.C0013a;
import java.util.Map;
import o0.b;

public final class f implements C0013a.b<TransferResp> {
    public final /* synthetic */ YijieH5PayConfirmActivityActivity a;

    public f(YijieH5PayConfirmActivityActivity yijieH5PayConfirmActivityActivity) {
        this.a = yijieH5PayConfirmActivityActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final void b(CheckoutResp checkoutResp) {
        YijieH5PayConfirmActivityActivity yijieH5PayConfirmActivityActivity = this.a;
        yijieH5PayConfirmActivityActivity.h = checkoutResp;
        yijieH5PayConfirmActivityActivity.E0(checkoutResp.getOriginalAmountDisplayWithUnit(), checkoutResp.getOppositeName(), checkoutResp.getFormatServerTimestamp(), checkoutResp.getFeeAmountDisplayWithUnit());
    }

    public final void onCancel() {
    }

    public final void onSuccess(Object obj) {
        Bundle bundle = new Bundle();
        int i = R$string.baselib_finished;
        DataBindingActivity dataBindingActivity = this.a;
        bundle.putString("buttonText", dataBindingActivity.getString(i));
        bundle.putSerializable("TransferResp", (TransferResp) obj);
        b.d((Activity) null, "/basicUiModule/commonSuccess", bundle, (Map) null);
        dataBindingActivity.finish();
    }
}
