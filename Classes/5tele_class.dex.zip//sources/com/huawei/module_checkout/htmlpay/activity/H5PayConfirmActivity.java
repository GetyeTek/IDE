package com.huawei.module_checkout.htmlpay.activity;

import N4.n;
import V7.e;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.v;
import com.huawei.common.display.DisplayAdapter;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.databinding.ActivityHtmlpaymentBinding;
import com.huawei.module_checkout.htmlpay.viewmodel.H5PayViewModel;
import com.huawei.module_checkout.htmlpay.viewmodel.H5PayViewModel2;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;

@Route(path = "/checkoutModule/h5PayComfirm")
public class H5PayConfirmActivity extends DataBindingActivity<ActivityHtmlpaymentBinding, H5PayViewModel> {
    public static final /* synthetic */ int f = 0;
    @Autowired(name = "appId")
    String appId;
    public DisplayAdapter d;
    public H5PayViewModel2 e;
    @Autowired(name = "merchCode")
    String merchCode;
    @Autowired(name = "prepayId")
    String prepayId;
    @Autowired(name = "tradeType")
    String tradeType = "PayByQrCode";

    public final int C0() {
        return R$layout.activity_htmlpayment;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.module_checkout.htmlpay.activity.H5PayConfirmActivity, java.lang.Object, androidx.lifecycle.ViewModelStoreOwner, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        H5PayConfirmActivity.super.onCreate(bundle);
        this.b.b.setLayoutManager(new LinearLayoutManager(this));
        DisplayAdapter displayAdapter = new DisplayAdapter();
        this.d = displayAdapter;
        this.b.b.setAdapter(displayAdapter);
        this.b.b.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(this, R$color.colorDividerLight), v.a(0.33f)));
        this.b.a.setOnClickListener(new n(this, 6));
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getString(R$string.designstandard_confirm), R.layout.common_toolbar);
        H5PayViewModel2 h5PayViewModel2 = new ViewModelProvider(this).get(H5PayViewModel2.class);
        this.e = h5PayViewModel2;
        h5PayViewModel2.g.observe(this, new b(this));
        r4.f.b.a(this, new c(this));
    }
}
