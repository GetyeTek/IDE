package com.huawei.module_checkout.htmlpay.activity;

import R1.a;
import android.text.TextUtils;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import i7.C0013a;
import java.util.HashMap;

public final class e implements a<Boolean> {
    public final /* synthetic */ YijieH5PayConfirmActivityActivity a;

    public e(YijieH5PayConfirmActivityActivity yijieH5PayConfirmActivityActivity) {
        this.a = yijieH5PayConfirmActivityActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        YijieH5PayConfirmActivityActivity yijieH5PayConfirmActivityActivity = this.a;
        HashMap a2 = com.google.android.gms.ads.identifier.a.a("tradeType", "NativeApp");
        a2.put("prepayId", yijieH5PayConfirmActivityActivity.g);
        CheckoutResp checkoutResp = yijieH5PayConfirmActivityActivity.h;
        if (checkoutResp != null) {
            a2.put("checkoutResp", checkoutResp);
        }
        if (!TextUtils.isEmpty(yijieH5PayConfirmActivityActivity.f)) {
            HashMap hashMap = new HashMap();
            hashMap.put("operationNumber", yijieH5PayConfirmActivityActivity.f);
            a2.put("extraPayParams", hashMap);
        }
        C0013a.C0002a.a.c(yijieH5PayConfirmActivityActivity, (String) null, PaySceneEnum.H5_CHECKOUT, a2, new f(yijieH5PayConfirmActivityActivity));
    }
}
