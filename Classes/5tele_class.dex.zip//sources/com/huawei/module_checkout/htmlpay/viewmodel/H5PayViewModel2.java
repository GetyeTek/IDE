package com.huawei.module_checkout.htmlpay.viewmodel;

import S2.b;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.htmlpay.repository.H5PayResository2;

public class H5PayViewModel2 extends BaseViewModel {
    public final MutableLiveData<b<CheckoutResp>> g = new MutableLiveData<>();
    public H5PayResository2 h;

    public final void onCleared() {
        H5PayViewModel2.super.onCleared();
        H5PayResository2 h5PayResository2 = this.h;
        if (h5PayResository2 != null) {
            h5PayResository2.cancel();
        }
    }
}
