package com.huawei.module_checkout.htmlpay.activity;

import android.os.Bundle;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import i7.C0013a;
import n.a;

public final class d implements C0013a.b<TransferResp> {
    public final /* synthetic */ H5PayConfirmActivity a;

    public d(H5PayConfirmActivity h5PayConfirmActivity) {
        this.a = h5PayConfirmActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    public final void onSuccess(Object obj) {
        TransferResp transferResp = (TransferResp) obj;
        H5PayConfirmActivity h5PayConfirmActivity = this.a;
        Bundle bundle = new Bundle(1);
        bundle.putSerializable("TransferResp", transferResp);
        a.b().getClass();
        a.a("/basicUiModule/commonSuccess").withString("amount", transferResp.getActualAmountDisplay()).withString("currency", transferResp.getCurrency()).with(bundle).navigation();
        h5PayConfirmActivity.finish();
    }
}
