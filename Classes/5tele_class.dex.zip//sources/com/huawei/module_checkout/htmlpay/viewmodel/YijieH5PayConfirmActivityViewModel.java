package com.huawei.module_checkout.htmlpay.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class YijieH5PayConfirmActivityViewModel extends ViewModel {
    public YijieH5PayConfirmActivityViewModel() {
        new MutableLiveData();
    }
}
