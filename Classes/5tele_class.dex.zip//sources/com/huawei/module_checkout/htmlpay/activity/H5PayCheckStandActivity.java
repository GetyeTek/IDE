package com.huawei.module_checkout.htmlpay.activity;

import android.os.Bundle;
import android.text.TextUtils;
import androidx.navigation.NavController;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.httplib.repository.QueryTransDetailsRepository;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import com.huawei.module_checkout.htmlpay.viewmodel.H5PayViewModel;
import i7.C0013a;
import java.util.Map;
import o0.b;

@Route(path = "/checkoutModule/h5PayCheckStand")
public class H5PayCheckStandActivity extends CheckStandActivity<H5PayViewModel> implements Runnable {
    public boolean g;
    public boolean h;
    public boolean i;
    public int j;
    public QueryTransDetailsRepository k;
    public TransferResp l;
    public String m;

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.module_checkout.htmlpay.activity.H5PayCheckStandActivity, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void D0() {
        super.D0();
        String stringExtra = getIntent().getStringExtra("appId");
        String stringExtra2 = getIntent().getStringExtra("merchCode");
        String stringExtra3 = getIntent().getStringExtra("prepayId");
        String stringExtra4 = getIntent().getStringExtra("tradeType");
        String stringExtra5 = getIntent().getStringExtra("buttonText");
        String stringExtra6 = getIntent().getStringExtra("rawRequest");
        this.m = getIntent().getStringExtra("businessType");
        this.g = getIntent().getBooleanExtra("showPopDialog", false);
        this.h = getIntent().getBooleanExtra("isAsyncTransaction", false);
        this.i = getIntent().getBooleanExtra("useMiniResultFlag", false);
        H5PayViewModel h5PayViewModel = (H5PayViewModel) this.b;
        h5PayViewModel.A = this.m;
        h5PayViewModel.v = stringExtra;
        h5PayViewModel.w = stringExtra2;
        h5PayViewModel.x = stringExtra3;
        h5PayViewModel.y = stringExtra4;
        h5PayViewModel.z = stringExtra6;
        h5PayViewModel.h = stringExtra5;
    }

    public final void E0(NavController navController) {
        if (this.g) {
            Bundle bundle = new Bundle(1);
            bundle.putBoolean("showPopDialog", this.g);
            navController.navigate(R$id.action_emptyFragment_to_inAppPayPinFragment, bundle);
            return;
        }
        navController.navigate(R$id.action_orderConfirmFragment_to_checkStandFragment);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_checkout.htmlpay.activity.H5PayCheckStandActivity, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void G0(TransferResp transferResp) {
        this.l = transferResp;
        if (!this.h) {
            super.G0(transferResp);
        } else if (this.i || "BuyPackage".equals(this.m) || "AirtimeRecharge".equals(this.m) || "CustomerPayBill".equals(this.m)) {
            I0();
        } else {
            Bundle bundle = new Bundle(2);
            bundle.putSerializable("TransferResp", transferResp);
            bundle.putBoolean("isAsyncTransaction", this.h);
            b.d(this, "/basicUiModule/commonSuccess", bundle, (Map) null);
            finish();
        }
    }

    public final void I0() {
        TransferResp transferResp = this.l;
        C0013a aVar = C0013a.C0002a.a;
        if (transferResp == null || transferResp.getPollFreq() == null || this.l.getPollFreq().length <= 0) {
            if (this.j >= 5) {
                finish();
                aVar.a.a(4, "timeout");
                return;
            }
        } else if (this.j >= this.l.getPollFreq().length - 1) {
            finish();
            aVar.a.a(4, "timeout");
            return;
        }
        if (this.k == null) {
            this.k = new QueryTransDetailsRepository(this.l.getOrderId());
            if (!TextUtils.isEmpty(this.l.getCouponId())) {
                this.k.addParams("couponId", this.l.getCouponId());
            }
        }
        this.k.sendRequest(new a(this));
        this.j++;
    }

    public final void run() {
        I0();
    }
}
