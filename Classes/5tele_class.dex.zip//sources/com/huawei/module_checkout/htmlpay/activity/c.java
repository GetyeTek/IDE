package com.huawei.module_checkout.htmlpay.activity;

import R1.a;
import S2.b;
import W2.n;
import android.text.TextUtils;
import com.huawei.common.exception.BaseException;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.htmlpay.repository.H5PayResository2;
import com.huawei.module_checkout.htmlpay.viewmodel.H5PayViewModel2;

public final class c implements a<Boolean> {
    public final /* synthetic */ H5PayConfirmActivity a;

    public c(H5PayConfirmActivity h5PayConfirmActivity) {
        this.a = h5PayConfirmActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    /* JADX WARNING: type inference failed for: r8v2, types: [android.content.Context, com.huawei.module_checkout.htmlpay.activity.H5PayConfirmActivity] */
    public final void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        ? r8 = this.a;
        H5PayViewModel2 h5PayViewModel2 = r8.e;
        String str = r8.appId;
        String str2 = r8.merchCode;
        String str3 = r8.prepayId;
        String str4 = r8.tradeType;
        r8.getString(R$string.pay);
        H5PayResository2 h5PayResository2 = h5PayViewModel2.h;
        if (h5PayResository2 != null) {
            h5PayResository2.cancel();
        }
        h5PayViewModel2.g.setValue(b.c((Object) null));
        if (!TextUtils.isEmpty(n.b("").e("TERMS_VERSION"))) {
            com.huawei.http.b bVar = new com.huawei.http.b();
            bVar.addParams("appId", str);
            bVar.addParams("prepayId", str3);
            bVar.addParams("merchCode", str2);
            bVar.addParams("tradeType", str4);
            if (!TextUtils.isEmpty("")) {
                bVar.addParams("rawRequest", "");
            }
            h5PayViewModel2.h = bVar;
            bVar.sendRequest(new W6.a(h5PayViewModel2, 1));
        }
    }
}
