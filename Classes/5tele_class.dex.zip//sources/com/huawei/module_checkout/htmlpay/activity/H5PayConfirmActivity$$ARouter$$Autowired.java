package com.huawei.module_checkout.htmlpay.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class H5PayConfirmActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_checkout.htmlpay.activity.H5PayConfirmActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (H5PayConfirmActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.appId;
        } else {
            str = r4.getIntent().getExtras().getString("appId", r4.appId);
        }
        r4.appId = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.merchCode;
        } else {
            str2 = r4.getIntent().getExtras().getString("merchCode", r4.merchCode);
        }
        r4.merchCode = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.prepayId;
        } else {
            str3 = r4.getIntent().getExtras().getString("prepayId", r4.prepayId);
        }
        r4.prepayId = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.tradeType;
        } else {
            str4 = r4.getIntent().getExtras().getString("tradeType", r4.tradeType);
        }
        r4.tradeType = str4;
    }
}
