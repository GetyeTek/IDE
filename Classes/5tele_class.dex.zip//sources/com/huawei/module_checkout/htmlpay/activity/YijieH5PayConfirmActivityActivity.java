package com.huawei.module_checkout.htmlpay.activity;

import V7.e;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import c6.p;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.v;
import com.huawei.common.display.DisplayAdapter;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.databinding.ActivityYijieH5PayConfirmBinding;
import com.huawei.module_checkout.htmlpay.viewmodel.YijieH5PayConfirmActivityViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.ArrayList;

@Route(path = "/checkoutModule/yijieH5PayComfirm")
public class YijieH5PayConfirmActivityActivity extends DataBindingActivity<ActivityYijieH5PayConfirmBinding, YijieH5PayConfirmActivityViewModel> {
    public static final /* synthetic */ int j = 0;
    public String d;
    public String e;
    public String f;
    public String g;
    public CheckoutResp h;
    public DisplayAdapter i;

    public final int C0() {
        return R$layout.activity_yijie_h5_pay_confirm;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_checkout.htmlpay.activity.YijieH5PayConfirmActivityActivity] */
    public final void E0(String str, String str2, String str3, String str4) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DisplayItem(getString(R$string.designstandard_order_amount), str));
        arrayList.add(new DisplayItem(getString(R$string.designstandard_merchant_name), str2));
        arrayList.add(new DisplayItem(getString(R$string.designstandard_transaction_time), str3));
        arrayList.add(new DisplayItem(getString(R$string.designstandard_total_fee), str4));
        this.i.setNewData(arrayList);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_checkout.htmlpay.activity.YijieH5PayConfirmActivityActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        YijieH5PayConfirmActivityActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.designstandard_confirm), R.layout.common_toolbar);
        Intent intent = getIntent();
        this.d = intent.getStringExtra("amount");
        this.e = intent.getStringExtra("publicName");
        this.f = intent.getStringExtra("operationNumber");
        this.g = intent.getStringExtra("prePayId");
        intent.getStringExtra("shortCode");
        this.b.b.setLayoutManager(new LinearLayoutManager(this));
        DisplayAdapter displayAdapter = new DisplayAdapter();
        this.i = displayAdapter;
        this.b.b.setAdapter(displayAdapter);
        this.b.b.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(this, R$color.colorDividerLight), v.a(0.33f)));
        E0(this.d, this.e, "", "");
        this.b.a.setOnClickListener(new p(this, 2));
        this.b.a.performClick();
    }
}
