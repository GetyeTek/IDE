package com.huawei.module_checkout.htmlpay.repository;

import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.http.b;

public class H5PayResository2 extends b<CheckoutResp, CheckoutResp> {
    public final String getApiPath() {
        return "v1/h5Checkout";
    }
}
