package com.huawei.module_checkout.htmlpay.viewmodel;

import L3.a;
import S2.b;
import android.text.TextUtils;
import android.util.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import java.util.ArrayList;
import java.util.HashMap;
import o7.c;

public class H5PayViewModel extends CheckStandViewModel {
    public String A = "";
    public final c u = new c();
    public String v;
    public String w;
    public String x;
    public String y;
    public String z;

    public final LiveData<b<CheckoutResp>> f(CouponBean couponBean) {
        return m(couponBean, (FundsSourceInfoDisplay) this.k.getValue());
    }

    public final LiveData<b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        return m((CouponBean) this.l.getValue(), fundsSourceInfoDisplay);
    }

    public final LiveData<b<TransferResp>> i(String str) {
        ArrayMap arrayMap = new ArrayMap();
        arrayMap.put("initiatorPin", a.g(str));
        arrayMap.put("pinVersion", a.b.getPinKeyVersion());
        arrayMap.put("prepayId", this.x);
        if (!TextUtils.isEmpty(this.A)) {
            arrayMap.put("businessType", this.A);
        }
        c cVar = this.u;
        cVar.getClass();
        return new o7.a(cVar, arrayMap).a;
    }

    public final MediatorLiveData m(CouponBean couponBean, FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        HashMap hashMap = new HashMap();
        hashMap.put("appId", this.v);
        hashMap.put("prepayId", this.x);
        hashMap.put("merchCode", this.w);
        hashMap.put("tradeType", this.y);
        if (!TextUtils.isEmpty(this.z)) {
            hashMap.put("rawRequest", this.z);
        }
        if (fundsSourceInfoDisplay != null) {
            hashMap.put("accountType", fundsSourceInfoDisplay.getAccountType());
            hashMap.put("fundsSource", fundsSourceInfoDisplay.getFundsSource());
        }
        if (couponBean != null) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(couponBean.getCouponId());
            hashMap.put("coupons", arrayList);
        }
        c cVar = this.u;
        cVar.getClass();
        return new o7.b(cVar, hashMap).a;
    }
}
