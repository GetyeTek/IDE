package com.huawei.module_checkout.htmlpay.activity;

import com.blankj.utilcode.util.A;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import i7.C0013a;

public final class a implements R1.a<TransferResp> {
    public final /* synthetic */ H5PayCheckStandActivity a;

    public a(H5PayCheckStandActivity h5PayCheckStandActivity) {
        this.a = h5PayCheckStandActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final void onError(BaseException baseException) {
        this.a.finish();
        C0013a.C0002a.a.a.a(5, baseException.getResponseDesc());
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        long j;
        TransferResp transferResp = (TransferResp) obj;
        boolean equals = "Processing".equals(transferResp.getOrderStatus());
        H5PayCheckStandActivity h5PayCheckStandActivity = this.a;
        if (equals) {
            TransferResp transferResp2 = h5PayCheckStandActivity.l;
            if (transferResp2 == null || transferResp2.getPollFreq() == null || transferResp2.getPollFreq().length <= 0) {
                j = 2000;
            } else {
                j = (long) (transferResp2.getPollFreq()[h5PayCheckStandActivity.j] * 1000);
            }
            A.h(h5PayCheckStandActivity, j);
            return;
        }
        boolean equals2 = "Success".equals(transferResp.getOrderStatus());
        C0013a aVar = C0013a.C0002a.a;
        if (equals2) {
            h5PayCheckStandActivity.finish();
            aVar.a.onSuccess(transferResp);
            return;
        }
        h5PayCheckStandActivity.finish();
        aVar.a.a(6, "the order status is abnormal");
    }
}
