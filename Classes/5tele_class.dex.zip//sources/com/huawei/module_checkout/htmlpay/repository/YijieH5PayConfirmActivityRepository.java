package com.huawei.module_checkout.htmlpay.repository;

import com.huawei.http.BaseResp;
import com.huawei.http.b;

public class YijieH5PayConfirmActivityRepository extends b<BaseResp, BaseResp> {
    public final String getApiPath() {
        return "";
    }
}
