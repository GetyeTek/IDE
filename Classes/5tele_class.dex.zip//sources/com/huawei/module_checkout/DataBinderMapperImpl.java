package com.huawei.module_checkout;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.module_checkout.databinding.ActivityBillShareConfirmBinding;
import com.huawei.module_checkout.databinding.ActivityBillShareConfirmBindingImpl;
import com.huawei.module_checkout.databinding.ActivityCheckstandOdComfirmBinding;
import com.huawei.module_checkout.databinding.ActivityCheckstandOdComfirmBindingImpl;
import com.huawei.module_checkout.databinding.ActivityHtmlpaymentBinding;
import com.huawei.module_checkout.databinding.ActivityHtmlpaymentBindingImpl;
import com.huawei.module_checkout.databinding.ActivityYijieH5PayConfirmBinding;
import com.huawei.module_checkout.databinding.ActivityYijieH5PayConfirmBindingImpl;
import com.huawei.module_checkout.databinding.ItemFinanceMarketBannerBindingImpl;
import com.huawei.module_checkout.databinding.ItemOdDisplayGroupBinding;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(6);
            a = hashMap;
            hashMap.put("layout/activity_bill_share_confirm_0", Integer.valueOf(R$layout.activity_bill_share_confirm));
            hashMap.put("layout/activity_checkstand_od_comfirm_0", Integer.valueOf(R$layout.activity_checkstand_od_comfirm));
            hashMap.put("layout/activity_htmlpayment_0", Integer.valueOf(R$layout.activity_htmlpayment));
            hashMap.put("layout/activity_yijie_h5_pay_confirm_0", Integer.valueOf(R$layout.activity_yijie_h5_pay_confirm));
            hashMap.put("layout/item_finance_market_banner_0", Integer.valueOf(R$layout.item_finance_market_banner));
            hashMap.put("layout/item_od_display_group_0", Integer.valueOf(R$layout.item_od_display_group));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(6);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_bill_share_confirm, 1);
        sparseIntArray.put(R$layout.activity_checkstand_od_comfirm, 2);
        sparseIntArray.put(R$layout.activity_htmlpayment, 3);
        sparseIntArray.put(R$layout.activity_yijie_h5_pay_confirm, 4);
        sparseIntArray.put(R$layout.item_finance_market_banner, 5);
        sparseIntArray.put(R$layout.item_od_display_group, 6);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(8);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.kbz.base.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag != null) {
                switch (i2) {
                    case 1:
                        if ("layout/activity_bill_share_confirm_0".equals(tag)) {
                            Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 9, (ViewDataBinding.IncludedLayouts) null, ActivityBillShareConfirmBindingImpl.h);
                            ConstraintLayout constraintLayout = (ConstraintLayout) mapBindings[3];
                            RoundLinearLayout roundLinearLayout = (RoundLinearLayout) mapBindings[7];
                            ActivityBillShareConfirmBinding activityBillShareConfirmBinding = new ActivityBillShareConfirmBinding(dataBindingComponent, view, (LoadingButton) mapBindings[8], (RoundImageView) mapBindings[1], (RecyclerView) mapBindings[6], (TextView) mapBindings[4], (TextView) mapBindings[5], (TextView) mapBindings[2]);
                            activityBillShareConfirmBinding.g = -1;
                            ((ConstraintLayout) mapBindings[0]).setTag((Object) null);
                            activityBillShareConfirmBinding.setRootTag(view2);
                            activityBillShareConfirmBinding.invalidateAll();
                            return activityBillShareConfirmBinding;
                        }
                        throw new IllegalArgumentException(l.a(tag, "The tag for activity_bill_share_confirm is invalid. Received: "));
                    case 2:
                        if ("layout/activity_checkstand_od_comfirm_0".equals(tag)) {
                            Object[] mapBindings2 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 7, (ViewDataBinding.IncludedLayouts) null, ActivityCheckstandOdComfirmBindingImpl.g);
                            RoundLinearLayout roundLinearLayout2 = (RoundLinearLayout) mapBindings2[5];
                            ActivityCheckstandOdComfirmBinding activityCheckstandOdComfirmBinding = new ActivityCheckstandOdComfirmBinding(dataBindingComponent, view, (LoadingButton) mapBindings2[6], (HFRecyclerView) mapBindings2[4], (TextView) mapBindings2[2], (TextView) mapBindings2[1], (TextView) mapBindings2[3]);
                            activityCheckstandOdComfirmBinding.f = -1;
                            ((RoundConstraintLayout) mapBindings2[0]).setTag((Object) null);
                            activityCheckstandOdComfirmBinding.setRootTag(view2);
                            activityCheckstandOdComfirmBinding.invalidateAll();
                            return activityCheckstandOdComfirmBinding;
                        }
                        throw new IllegalArgumentException(l.a(tag, "The tag for activity_checkstand_od_comfirm is invalid. Received: "));
                    case 3:
                        if ("layout/activity_htmlpayment_0".equals(tag)) {
                            Object[] mapBindings3 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 4, (ViewDataBinding.IncludedLayouts) null, ActivityHtmlpaymentBindingImpl.d);
                            RoundLinearLayout roundLinearLayout3 = (RoundLinearLayout) mapBindings3[2];
                            ViewDataBinding activityHtmlpaymentBinding = new ActivityHtmlpaymentBinding(dataBindingComponent2, view2, (LoadingButton) mapBindings3[3], (RoundRecyclerView) mapBindings3[1]);
                            activityHtmlpaymentBinding.c = -1;
                            ((ConstraintLayout) mapBindings3[0]).setTag((Object) null);
                            activityHtmlpaymentBinding.setRootTag(view2);
                            activityHtmlpaymentBinding.invalidateAll();
                            return activityHtmlpaymentBinding;
                        }
                        throw new IllegalArgumentException(l.a(tag, "The tag for activity_htmlpayment is invalid. Received: "));
                    case 4:
                        if ("layout/activity_yijie_h5_pay_confirm_0".equals(tag)) {
                            Object[] mapBindings4 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 4, (ViewDataBinding.IncludedLayouts) null, ActivityYijieH5PayConfirmBindingImpl.d);
                            RoundLinearLayout roundLinearLayout4 = (RoundLinearLayout) mapBindings4[2];
                            ViewDataBinding activityYijieH5PayConfirmBinding = new ActivityYijieH5PayConfirmBinding(dataBindingComponent2, view2, (LoadingButton) mapBindings4[3], (RoundRecyclerView) mapBindings4[1]);
                            activityYijieH5PayConfirmBinding.c = -1;
                            ((ConstraintLayout) mapBindings4[0]).setTag((Object) null);
                            activityYijieH5PayConfirmBinding.setRootTag(view2);
                            activityYijieH5PayConfirmBinding.invalidateAll();
                            return activityYijieH5PayConfirmBinding;
                        }
                        throw new IllegalArgumentException(l.a(tag, "The tag for activity_yijie_h5_pay_confirm is invalid. Received: "));
                    case 5:
                        if ("layout/item_finance_market_banner_0".equals(tag)) {
                            Object[] mapBindings5 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 2, (ViewDataBinding.IncludedLayouts) null, ItemFinanceMarketBannerBindingImpl.b);
                            CycleViewPager cycleViewPager = (CycleViewPager) mapBindings5[1];
                            ViewDataBinding viewDataBinding = new ViewDataBinding(dataBindingComponent2, view2, 0);
                            viewDataBinding.a = -1;
                            ((FrameLayout) mapBindings5[0]).setTag((Object) null);
                            viewDataBinding.setRootTag(view2);
                            viewDataBinding.invalidateAll();
                            return viewDataBinding;
                        }
                        throw new IllegalArgumentException(l.a(tag, "The tag for item_finance_market_banner is invalid. Received: "));
                    case 6:
                        if ("layout/item_od_display_group_0".equals(tag)) {
                            ViewDataBinding itemOdDisplayGroupBinding = new ItemOdDisplayGroupBinding(dataBindingComponent2, view2, (RoundRecyclerView) ViewDataBinding.mapBindings(dataBindingComponent2, view2, 1, (ViewDataBinding.IncludedLayouts) null, (SparseIntArray) null)[0]);
                            itemOdDisplayGroupBinding.b = -1;
                            itemOdDisplayGroupBinding.a.setTag((Object) null);
                            itemOdDisplayGroupBinding.setRootTag(view2);
                            itemOdDisplayGroupBinding.invalidateAll();
                            return itemOdDisplayGroupBinding;
                        }
                        throw new IllegalArgumentException(l.a(tag, "The tag for item_od_display_group is invalid. Received: "));
                }
            } else {
                throw new RuntimeException("view must have a tag");
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
