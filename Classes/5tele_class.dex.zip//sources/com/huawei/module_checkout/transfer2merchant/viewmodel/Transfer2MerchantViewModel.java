package com.huawei.module_checkout.transfer2merchant.viewmodel;

import E7.c;
import L3.a;
import S2.b;
import android.util.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import java.util.HashMap;

public class Transfer2MerchantViewModel extends CheckStandViewModel {
    public final c u = new c();
    public String v;
    public final MutableLiveData<String> w = new MutableLiveData<>();

    public final LiveData<b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        HashMap hashMap = new HashMap();
        hashMap.put("tradeType", this.v);
        hashMap.put("prepayId", this.s);
        if (fundsSourceInfoDisplay != null) {
            hashMap.put("accountType", fundsSourceInfoDisplay.getAccountType());
            hashMap.put("fundsSource", fundsSourceInfoDisplay.getFundsSource());
        }
        c cVar = this.u;
        cVar.getClass();
        return new E7.b(cVar, hashMap).a;
    }

    public final LiveData<b<TransferResp>> i(String str) {
        ArrayMap arrayMap = new ArrayMap();
        arrayMap.put("initiatorPin", a.g(str));
        arrayMap.put("pinVersion", a.b.getPinKeyVersion());
        arrayMap.put("prepayId", this.s);
        c cVar = this.u;
        cVar.getClass();
        return new E7.a(cVar, arrayMap, 0).a;
    }
}
