package com.huawei.module_checkout.transfer2merchant.activity;

import W2.g;
import android.text.Editable;

public final class a extends O2.a {
    public final /* synthetic */ Transfer2MerchantActivity b;

    public a(Transfer2MerchantActivity transfer2MerchantActivity) {
        super(1);
        this.b = transfer2MerchantActivity;
    }

    public final void afterTextChanged(Editable editable) {
        this.b.p.d(g.a(editable.toString()));
    }
}
