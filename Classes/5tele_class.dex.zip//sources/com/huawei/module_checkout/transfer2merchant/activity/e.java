package com.huawei.module_checkout.transfer2merchant.activity;

import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import i7.C0013a;
import n.a;

public final class e implements C0013a.b<TransferResp> {
    public final /* synthetic */ Transfer2MerchantActivity a;

    public e(Transfer2MerchantActivity transfer2MerchantActivity) {
        this.a = transfer2MerchantActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.module_checkout.transfer2merchant.activity.Transfer2MerchantActivity, android.app.Activity] */
    public final void onSuccess(Object obj) {
        ? r0 = this.a;
        a.b().getClass();
        a.a("/basicUiModule/commonSuccess").withSerializable("TransferResp", (TransferResp) obj).navigation();
        r0.finish();
    }
}
