package com.huawei.module_checkout.transfer2merchant.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import com.huawei.module_checkout.checkout.TradeTypeEnum;

public class Transfer2MerchantActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_checkout.transfer2merchant.activity.Transfer2MerchantActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        String str9;
        String str10;
        String str11;
        String str12;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (Transfer2MerchantActivity) obj;
        r4.transferType = (TradeTypeEnum) r4.getIntent().getSerializableExtra("transferType");
        if (r4.getIntent().getExtras() == null) {
            str = r4.shortCode;
        } else {
            str = r4.getIntent().getExtras().getString("shortCode", r4.shortCode);
        }
        r4.shortCode = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.operatorId;
        } else {
            str2 = r4.getIntent().getExtras().getString("operatorId", r4.operatorId);
        }
        r4.operatorId = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.publicName;
        } else {
            str3 = r4.getIntent().getExtras().getString("publicName", r4.publicName);
        }
        r4.publicName = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.operationNumber;
        } else {
            str4 = r4.getIntent().getExtras().getString("operationNumber", r4.operationNumber);
        }
        r4.operationNumber = str4;
        if (r4.getIntent().getExtras() == null) {
            str5 = r4.amount;
        } else {
            str5 = r4.getIntent().getExtras().getString("amount", r4.amount);
        }
        r4.amount = str5;
        if (r4.getIntent().getExtras() == null) {
            str6 = r4.notes;
        } else {
            str6 = r4.getIntent().getExtras().getString("notes", r4.notes);
        }
        r4.notes = str6;
        if (r4.getIntent().getExtras() == null) {
            str7 = r4.tradeType;
        } else {
            str7 = r4.getIntent().getExtras().getString("tradeType", r4.tradeType);
        }
        r4.tradeType = str7;
        if (r4.getIntent().getExtras() == null) {
            str8 = r4.walletName;
        } else {
            str8 = r4.getIntent().getExtras().getString("walletName", r4.walletName);
        }
        r4.walletName = str8;
        if (r4.getIntent().getExtras() == null) {
            str9 = r4.organizationName;
        } else {
            str9 = r4.getIntent().getExtras().getString("OrganizationName", r4.organizationName);
        }
        r4.organizationName = str9;
        if (r4.getIntent().getExtras() == null) {
            str10 = r4.mcc;
        } else {
            str10 = r4.getIntent().getExtras().getString("mcc", r4.mcc);
        }
        r4.mcc = str10;
        if (r4.getIntent().getExtras() == null) {
            str11 = r4.tillId;
        } else {
            str11 = r4.getIntent().getExtras().getString("tillId", r4.tillId);
        }
        r4.tillId = str11;
        if (r4.getIntent().getExtras() == null) {
            str12 = r4.mobileNumber;
        } else {
            str12 = r4.getIntent().getExtras().getString("mobileNumber", r4.mobileNumber);
        }
        r4.mobileNumber = str12;
    }
}
