package com.huawei.module_checkout.transfer2merchant.activity;

import R1.a;
import com.huawei.common.exception.BaseException;

public final class c implements a<String> {
    public final /* synthetic */ Transfer2MerchantActivity a;

    public c(Transfer2MerchantActivity transfer2MerchantActivity) {
        this.a = transfer2MerchantActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        int i = Transfer2MerchantActivity.q;
        this.a.i.w.setValue((String) obj);
    }
}
