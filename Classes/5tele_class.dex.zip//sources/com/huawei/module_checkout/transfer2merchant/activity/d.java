package com.huawei.module_checkout.transfer2merchant.activity;

import R1.a;
import V1.k;
import W2.g;
import android.text.TextUtils;
import androidx.fragment.app.FragmentActivity;
import com.huawei.common.exception.BaseException;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import i7.C0013a;
import java.util.HashMap;

public final class d implements a<Boolean> {
    public final /* synthetic */ Transfer2MerchantActivity a;

    public d(Transfer2MerchantActivity transfer2MerchantActivity) {
        this.a = transfer2MerchantActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        FragmentActivity fragmentActivity = this.a;
        String obj2 = fragmentActivity.o.getEditableText().toString();
        fragmentActivity.amount = obj2;
        if (TextUtils.isEmpty(obj2)) {
            k.b(1, fragmentActivity.getString(R$string.designstandard_please_input_amount));
        } else if (!g.a(fragmentActivity.amount)) {
            k.b(1, fragmentActivity.getString(R$string.designstandard_incorrect_amount_format));
        } else {
            String trim = fragmentActivity.n.getText().toString().trim();
            HashMap a2 = com.google.android.gms.ads.identifier.a.a("tradeType", "NativeApp");
            a2.put("receiverShortCode", fragmentActivity.shortCode);
            if (!TextUtils.isEmpty(fragmentActivity.operatorId)) {
                a2.put("operatorId", fragmentActivity.operatorId);
            }
            a2.put("amount", fragmentActivity.amount);
            a2.put("note", trim);
            if (!TextUtils.isEmpty(fragmentActivity.operationNumber)) {
                HashMap hashMap = new HashMap();
                hashMap.put("operationNumber", fragmentActivity.operationNumber);
                a2.put("extraPayParams", hashMap);
            }
            if (!TextUtils.isEmpty(fragmentActivity.shortCode)) {
                a2.put("externalMerchCode", fragmentActivity.shortCode);
            }
            if (!TextUtils.isEmpty(fragmentActivity.organizationName)) {
                a2.put("externalMerchName", fragmentActivity.organizationName);
            }
            if (!TextUtils.isEmpty(fragmentActivity.mcc)) {
                a2.put("mcc", fragmentActivity.mcc);
            }
            if (!TextUtils.isEmpty(fragmentActivity.tillId)) {
                a2.put("tillId", fragmentActivity.tillId);
            }
            if (!TextUtils.isEmpty(fragmentActivity.mobileNumber)) {
                a2.put("mobileNumber", fragmentActivity.mobileNumber);
            }
            if (!TextUtils.isEmpty(fragmentActivity.walletName) && !fragmentActivity.walletName.equals("TELEBIRR")) {
                a2.put("walletName", fragmentActivity.walletName);
                a2.put("businessType", "ConnectionPayC2B");
            }
            C0013a.C0002a.a.c(fragmentActivity, fragmentActivity.getString(R$string.checkout_pay), PaySceneEnum.PAY_FOR_MERCHANT, a2, new e(fragmentActivity));
        }
    }
}
