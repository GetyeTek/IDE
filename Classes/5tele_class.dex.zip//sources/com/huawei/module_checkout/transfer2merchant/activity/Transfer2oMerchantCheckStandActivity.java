package com.huawei.module_checkout.transfer2merchant.activity;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import com.huawei.module_checkout.transfer2merchant.viewmodel.Transfer2MerchantViewModel;

@Route(path = "/checkoutModule/transferToMerchantCheckStand")
public class Transfer2oMerchantCheckStandActivity extends CheckStandActivity<Transfer2MerchantViewModel> {
    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_checkout.transfer2merchant.activity.Transfer2oMerchantCheckStandActivity, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void D0() {
        super.D0();
        getIntent().getStringExtra("amount");
        String stringExtra = getIntent().getStringExtra("notes");
        String stringExtra2 = getIntent().getStringExtra("tradeType");
        getIntent().getStringExtra("shortCode");
        Transfer2MerchantViewModel transfer2MerchantViewModel = (Transfer2MerchantViewModel) this.b;
        transfer2MerchantViewModel.w.setValue(stringExtra);
        transfer2MerchantViewModel.v = stringExtra2;
    }
}
