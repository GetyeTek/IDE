package com.huawei.module_checkout.transfer2merchant.activity;

import D2.c;
import D6.g;
import V1.h;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.camera.core.m;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.viewbinding.ViewBinding;
import c2.d;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.J;
import com.huawei.common.R;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.ParameterLimitBean;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import com.huawei.module_checkout.p2ptransfer.dialog.AddNoteDialog;
import com.huawei.module_checkout.transfer2merchant.viewmodel.Transfer2MerchantViewModel;
import i7.C0013a;

@Route(path = "/checkoutModule/transferToMerchant")
public class Transfer2MerchantActivity extends BaseMvvmActivity<Transfer2MerchantViewModel> {
    public static final /* synthetic */ int q = 0;
    @Autowired
    String amount;
    public TextView k;
    public TextView l;
    public TextView m;
    @Autowired
    String mcc;
    @Autowired
    String mobileNumber;
    public TextView n;
    @Autowired
    String notes;
    public InputItemEditText o;
    @Autowired
    String operationNumber;
    @Autowired
    String operatorId;
    @Autowired(name = "OrganizationName")
    String organizationName;
    public CustomKeyBroadPop p;
    @Autowired
    String publicName;
    @Autowired
    String shortCode;
    @Autowired
    String tillId;
    @Autowired
    String tradeType = "QrCode";
    @Autowired
    TradeTypeEnum transferType;
    @Autowired
    String walletName;

    public class a implements Observer<String> {
        public a() {
        }

        public final void onChanged(Object obj) {
            int i;
            String str = (String) obj;
            Transfer2MerchantActivity transfer2MerchantActivity = Transfer2MerchantActivity.this;
            transfer2MerchantActivity.n.setText(str);
            TextView textView = transfer2MerchantActivity.n;
            int i2 = 0;
            if (TextUtils.isEmpty(str)) {
                i = 8;
            } else {
                i = 0;
            }
            textView.setVisibility(i);
            TextView textView2 = transfer2MerchantActivity.m;
            if (!TextUtils.isEmpty(str)) {
                i2 = 8;
            }
            textView2.setVisibility(i2);
        }
    }

    public class b implements Observer<CheckoutResp> {
        public b() {
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, com.huawei.module_checkout.transfer2merchant.activity.Transfer2MerchantActivity, android.app.Activity] */
        public final void onChanged(Object obj) {
            ? r0 = Transfer2MerchantActivity.this;
            r0.getClass();
            Bundle bundle = new Bundle(1);
            bundle.putString("amount", r0.amount);
            bundle.putString("notes", r0.notes);
            bundle.putString("tradeType", r0.tradeType);
            bundle.putString("shortCode", r0.shortCode);
            bundle.putSerializable("CheckoutResp", (CheckoutResp) obj);
            C0013a.C0002a.a.a(r0, "/checkoutModule/transferToMerchantCheckStand", bundle, new b(r0));
        }
    }

    public final void D0() {
    }

    public final ViewBinding K0() {
        return null;
    }

    public final void U0() {
        Transfer2MerchantActivity.super.U0();
        this.i.w.observe(this, new a());
        this.i.j.observe(this, new b());
    }

    public final void W0() {
        int i = 50;
        try {
            ParameterLimitBean parameterLimit = BasicConfig.getInstance().getParameterLimit();
            if (parameterLimit != null && !TextUtils.isEmpty(parameterLimit.getNoteLimit())) {
                i = Integer.parseInt(parameterLimit.getNoteLimit());
            }
        } catch (Exception unused) {
            h.b();
        }
        new AddNoteDialog((String) this.i.w.getValue(), new c(this), i).show(getSupportFragmentManager(), "");
    }

    public final void onBackPressed() {
        if (this.p.isShowing()) {
            this.p.c();
        } else {
            Transfer2MerchantActivity.super.onBackPressed();
        }
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [com.huawei.module_checkout.transfer2merchant.activity.a, android.text.TextWatcher] */
    public final void onCreate(@Nullable Bundle bundle) {
        Transfer2MerchantActivity.super.onCreate(bundle);
        setContentView(R$layout.activity_transfer_to_merchant_pay_confirm);
        this.p = new CustomKeyBroadPop(this, new d(4, d.b(J.a().getString(R.string.pay))));
        this.k = (TextView) findViewById(R$id.tv_transfer_to);
        this.l = (TextView) findViewById(R$id.tv_org_name);
        this.m = (TextView) findViewById(R$id.tv_add_notes);
        this.n = (TextView) findViewById(R$id.tv_add_notes_show);
        InputItemEditText findViewById = findViewById(R$id.et_amount);
        this.o = findViewById;
        findViewById.requestFocus();
        this.o.setFocusableInTouchMode(true);
        InputItemEditText inputItemEditText = this.o;
        inputItemEditText.setCurrency("(" + k3.a.e.b() + ")");
        this.m.setOnClickListener(new g(this, 6));
        this.n.setOnClickListener(new O7.a(this, 3));
        this.p.a(this, this.o, true);
        this.p.d = new m(this, 1);
        this.o.addTextChangedListener(new a(this));
        this.k.setText(this.shortCode);
        this.l.setText(this.publicName);
        this.i.w.setValue(this.notes);
        if (!TextUtils.isEmpty(this.amount)) {
            this.o.setText(this.amount);
            this.o.setSelection(this.amount.length());
            this.o.setEnabled(false);
        }
        T0();
        N0(getString(R$string.designstandard_payment));
        int i = R$color.color_F4F4F4;
        Q0(ContextCompat.getColor(this, i));
        S0(i);
        c.a(this, this.o);
    }

    public final void onDestroy() {
        CustomKeyBroadPop customKeyBroadPop = this.p;
        if (customKeyBroadPop != null) {
            customKeyBroadPop.c();
        }
        Transfer2MerchantActivity.super.onDestroy();
    }
}
