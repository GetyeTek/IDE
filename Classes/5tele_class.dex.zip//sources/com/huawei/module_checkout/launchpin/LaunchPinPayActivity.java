package com.huawei.module_checkout.launchpin;

import B7.e;
import N4.l;
import V7.c;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_checkout.checkstand.LaunchPinPayEnum;
import com.huawei.module_checkout.requestpin.BaseRequestPinActivity;
import java.util.HashMap;

@Route(path = "/checkoutModule/launchPinCheckPay")
public class LaunchPinPayActivity extends BaseRequestPinActivity {
    public static final /* synthetic */ int j = 0;
    public HashMap<String, Object> g;
    public LaunchPinPayEnum h;
    public LaunchPinViewModel i;

    public final void D0(String str) {
        LaunchPinViewModel launchPinViewModel = this.i;
        HashMap<String, Object> hashMap = this.g;
        String transferPath = this.h.getTransferPath();
        launchPinViewModel.a.setValue(c.c());
        LaunchPinRepository launchPinRepository = launchPinViewModel.b;
        if (launchPinRepository != null) {
            launchPinRepository.cancel();
        }
        if (launchPinViewModel.b == null) {
            launchPinViewModel.b = new LaunchPinRepository(str, transferPath, hashMap);
        }
        launchPinViewModel.b.sendRequest(new e(launchPinViewModel, 3));
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.module_checkout.launchpin.LaunchPinPayActivity, androidx.lifecycle.LifecycleOwner, androidx.lifecycle.ViewModelStoreOwner, android.app.Activity, androidx.appcompat.app.AppCompatActivity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.g = (HashMap) getIntent().getSerializableExtra("params");
        this.h = (LaunchPinPayEnum) getIntent().getSerializableExtra("launchPinPayEnum");
        LaunchPinViewModel launchPinViewModel = new ViewModelProvider(this).get(LaunchPinViewModel.class);
        this.i = launchPinViewModel;
        launchPinViewModel.a.observe(this, new l(this, 1));
    }
}
