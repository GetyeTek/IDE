package com.huawei.module_checkout.launchpin;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;

public class LaunchPinViewModel extends ViewModel {
    public final MutableLiveData<c<TransferResp>> a = new MutableLiveData<>();
    public LaunchPinRepository b;
}
