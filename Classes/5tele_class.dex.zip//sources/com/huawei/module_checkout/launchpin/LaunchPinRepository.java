package com.huawei.module_checkout.launchpin;

import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.http.b;
import java.util.HashMap;

public class LaunchPinRepository extends b<TransferResp, TransferResp> {
    public final String a;

    public LaunchPinRepository(String str, String str2, HashMap hashMap) {
        this.a = str2;
        AppService c = o0.b.c(AppService.class);
        addParams("pinVersion", c.e());
        addParams("initiatorPin", c.k(str));
        addParams(hashMap);
    }

    public final String getApiPath() {
        return this.a;
    }
}
