package com.huawei.module_checkout.coupon;

import H1.c;
import R9.h;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import c6.m;
import com.google.android.material.tabs.TabLayoutMediator;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.buyairtime.activity.e;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$style;
import java.util.ArrayList;
import java.util.List;

public class CouponDialog extends BaseDialog {
    public List<String> c;
    public ArrayList d;
    public List<CouponBean> e;
    public String f;
    public m g;

    public class a extends FragmentStateAdapter {

        /* renamed from: com.huawei.module_checkout.coupon.CouponDialog$a$a  reason: collision with other inner class name */
        public class C0001a {
            public C0001a() {
            }
        }

        public a(FragmentActivity fragmentActivity) {
            super(fragmentActivity);
        }

        @NonNull
        public final Fragment createFragment(int i) {
            CouponDialog couponDialog = CouponDialog.this;
            if (i == 0) {
                CouponFragment couponFragment = new CouponFragment("AVAILABLE_COUPON", couponDialog.f, couponDialog.d);
                couponFragment.h = new C0001a();
                return couponFragment;
            } else if (i != 1) {
                return null;
            } else {
                return new CouponFragment("UNAVAILABLE_COUPON", couponDialog.f, couponDialog.e);
            }
        }

        public final int getItemCount() {
            return 2;
        }
    }

    public final void onStart() {
        Window window;
        CouponDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, h.a(getActivity(), 600.0f));
            window.setBackgroundDrawableResource(17170445);
            c.b(window, R$style.BottomAnimation, dialog, true, true);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        CouponDialog.super.onViewCreated(view, bundle);
        ViewPager2 findViewById = view.findViewById(R$id.viewPager2);
        findViewById.setAdapter(new a(getActivity()));
        new TabLayoutMediator(view.findViewById(R$id.tabLayout), findViewById, new e(this)).attach();
        view.findViewById(R$id.iv_back).setOnClickListener(new H6.c(this, 4));
    }

    public final int v0() {
        return R$layout.coupon_dialog_layout;
    }
}
