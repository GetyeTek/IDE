package com.huawei.module_checkout.coupon;

import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.blankj.utilcode.util.C;
import com.bumptech.glide.c;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.kbz.dialog.recyclerdialog.BaseRecyclerDialog;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$mipmap;
import com.huawei.module_checkout.R$string;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import n7.a;
import n7.b;

public class SelectCouponDialog extends BaseRecyclerDialog<CouponBean> {
    public List<String> j;

    public SelectCouponDialog() {
        throw null;
    }

    public final void x0(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        float f;
        CouponBean couponBean = (CouponBean) obj;
        baseViewHolder.setText(R$id.tv_coupon_name, couponBean.getCouponName());
        baseViewHolder.setText(R$id.tv_coupon_value, couponBean.getCouponDenomination());
        ImageView imageView = (ImageView) baseViewHolder.getView(R$id.iv_coupon);
        String format = C.b("yyyy/MM/dd").format(new Date(Long.valueOf(couponBean.getValidEndTime()).longValue()));
        String string = getString(R$string.valid_until);
        int i = R$id.tv_valid_until;
        baseViewHolder.setText(i, string + ": " + format);
        baseViewHolder.setText(R$id.tv_value_unit, couponBean.getCouponCurrency());
        c.i(imageView).load(couponBean.getCouponIconUrl()).placeholder(R$mipmap.icon_default_coupon).into(imageView);
        View view = baseViewHolder.getView(R$id.cl_coupon_container);
        String couponId = couponBean.getCouponId();
        List<String> list = this.j;
        boolean z = false;
        if (list != null && !list.isEmpty()) {
            Iterator<String> it = list.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (couponId.equals(it.next())) {
                        z = true;
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        view.setOnClickListener(new a(this, z, couponBean));
        ImageView imageView2 = (ImageView) baseViewHolder.getView(R$id.iv_selected);
        if (z) {
            f = 1.0f;
        } else {
            f = 0.4f;
        }
        view.setAlpha(f);
        if (!z) {
            imageView2.setImageResource(R$mipmap.icon_disable);
            return;
        }
        CouponBean couponBean2 = this.h;
        if (couponBean2 == null) {
            imageView2.setImageResource(R$mipmap.icon_unselected);
        } else if (TextUtils.equals(couponBean2.getCouponId(), couponBean.getCouponId())) {
            imageView2.setImageResource(R$mipmap.icon_selected);
        } else {
            imageView2.setImageResource(R$mipmap.icon_unselected);
        }
    }

    public final int y0() {
        return R$layout.item_select_coupon;
    }

    public final b z0() {
        return new b(this);
    }
}
