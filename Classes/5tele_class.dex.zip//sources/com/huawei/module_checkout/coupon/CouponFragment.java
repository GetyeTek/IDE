package com.huawei.module_checkout.coupon;

import O9.c;
import V1.h;
import W2.r;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.blankj.utilcode.util.C;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$mipmap;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.confirm.PaymentConfirmActivity;
import com.huawei.module_checkout.coupon.CouponDialog;
import com.huawei.module_checkout.databinding.FragmentCouponLayoutBinding;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class CouponFragment extends BaseFragment {
    public final String c;
    public FragmentCouponLayoutBinding d;
    public CouponBean e;
    public List<CouponBean> f;
    public final String g;
    public CouponDialog.a.C0001a h;

    public class a implements OnItemClickListener {
        public final /* synthetic */ b a;

        public a(b bVar) {
            this.a = bVar;
        }

        public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
            b bVar;
            int i2 = 0;
            while (true) {
                bVar = this.a;
                int[] iArr = bVar.b;
                if (i2 >= iArr.length) {
                    break;
                }
                if (i != i2) {
                    iArr[i2] = 0;
                } else if (iArr[i2] == 1) {
                    iArr[i2] = 0;
                } else {
                    iArr[i2] = 1;
                }
                i2++;
            }
            bVar.notifyDataSetChanged();
            int i3 = bVar.b[i];
            CouponFragment couponFragment = CouponFragment.this;
            if (i3 == 0) {
                couponFragment.e = null;
            } else {
                couponFragment.e = couponFragment.f.get(i);
            }
            CouponDialog.a.C0001a aVar = couponFragment.h;
            CouponBean couponBean = couponFragment.e;
            CouponDialog couponDialog = CouponDialog.this;
            if (couponBean == null) {
                couponDialog.f = "-1";
            } else {
                couponDialog.f = couponBean.getCouponId();
            }
            PaymentConfirmActivity paymentConfirmActivity = couponDialog.g.a;
            paymentConfirmActivity.q.dismiss();
            Objects.toString(couponBean);
            h.b();
            ArrayList arrayList = paymentConfirmActivity.p;
            if (couponBean == null) {
                arrayList.clear();
                paymentConfirmActivity.j.e.setText(paymentConfirmActivity.k.getOriginalAmountDisplay());
                paymentConfirmActivity.j.f.setText(R$string.no_coupons);
                return;
            }
            ArrayList arrayList2 = new ArrayList();
            arrayList2.add(couponBean.getCouponId());
            if (arrayList != null && arrayList2.size() > 0) {
                arrayList.clear();
                arrayList.addAll(arrayList2);
            }
            paymentConfirmActivity.X0(paymentConfirmActivity.m, "selectCoupon");
        }
    }

    public static class b extends BaseQuickAdapter<CouponBean, BaseViewHolder> {
        public long a;
        public int[] b;
        public String c;

        public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
            SpannableString spannableString;
            String str;
            CouponBean couponBean = (CouponBean) obj;
            if (!TextUtils.equals("AVAILABLE_COUPON", this.c)) {
                int i = R$id.cb_check_box;
                baseViewHolder.setEnabled(i, false);
                baseViewHolder.setBackgroundResource(i, R$mipmap.icon_pay_method_unable_selector);
            } else if (this.b[baseViewHolder.getAdapterPosition()] == 1) {
                ((CheckBox) baseViewHolder.getView(R$id.cb_check_box)).setChecked(true);
            } else {
                ((CheckBox) baseViewHolder.getView(R$id.cb_check_box)).setChecked(false);
            }
            baseViewHolder.setText(R$id.tv_use_ruler, couponBean.getCouponDesc());
            if ("CUT".equals(couponBean.getCouponType())) {
                baseViewHolder.setText(R$id.tv_amount, couponBean.getDenomination());
            } else {
                baseViewHolder.setText(R$id.tv_amount, couponBean.getDiscountRatio());
            }
            baseViewHolder.setText(R$id.tv_use_hint, couponBean.getCouponHint());
            baseViewHolder.setText(R$id.tv_coupon_name, couponBean.getCouponNameDisplay());
            c.c((ImageView) baseViewHolder.getView(R$id.iv_logo), couponBean.getCouponIconUrl(), -1);
            int i2 = R$id.tv_coupon_use_time;
            long parseLong = Long.parseLong(couponBean.getValidEndTime());
            long time = parseLong - r.d().getTime();
            if (time < this.a) {
                long j = time / 216000000;
                if (j <= 1) {
                    str = J.a().getResources().getString(R$string.will_expire_in_a_hour);
                } else {
                    str = String.format(J.a().getResources().getString(R$string.coupon_expire_date), new Object[]{Long.valueOf(j)});
                }
                spannableString = new SpannableString(str);
                spannableString.setSpan(new ForegroundColorSpan(-65536), 0, str.length(), 33);
            } else {
                String a2 = C.a("yyyy-MM-dd HH:mm:ss", new Date(parseLong));
                spannableString = new SpannableString(String.format(J.a().getResources().getString(R$string.coupon_validity_date), new Object[]{a2}));
            }
            baseViewHolder.setText(i2, spannableString);
        }
    }

    public CouponFragment(String str, String str2, List list) {
        this.c = str;
        this.f = list;
        this.g = str2;
    }

    public final ViewBinding v0(LayoutInflater layoutInflater) {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.fragment_coupon_layout, (ViewGroup) null, false);
        int i = R$id.rv_recycler_coupon;
        RecyclerView findChildViewById = ViewBindings.findChildViewById(inflate, i);
        if (findChildViewById != null) {
            FragmentCouponLayoutBinding fragmentCouponLayoutBinding = new FragmentCouponLayoutBinding(inflate, findChildViewById);
            this.d = fragmentCouponLayoutBinding;
            return fragmentCouponLayoutBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final void w0() {
    }

    public final void x0(View view) {
        if (this.f == null) {
            this.f = new ArrayList();
        }
        this.d.b.setLayoutManager(new LinearLayoutManager(getActivity()));
        List<CouponBean> list = this.f;
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_coupon, list);
        baseQuickAdapter.a = 889032704;
        String str = this.c;
        baseQuickAdapter.c = str;
        if (list != null) {
            baseQuickAdapter.b = new int[list.size()];
            for (int i = 0; i < list.size(); i++) {
                if (TextUtils.equals(this.g, list.get(i).getCouponId())) {
                    baseQuickAdapter.b[i] = 1;
                } else {
                    baseQuickAdapter.b[i] = 0;
                }
            }
        }
        this.d.b.setAdapter(baseQuickAdapter);
        if ("AVAILABLE_COUPON".equals(str)) {
            baseQuickAdapter.setOnItemClickListener(new a(baseQuickAdapter));
        }
    }
}
