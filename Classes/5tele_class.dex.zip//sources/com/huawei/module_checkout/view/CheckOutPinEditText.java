package com.huawei.module_checkout.view;

import R9.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.InputFilter;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatEditText;
import com.huawei.digitalpayment.customer.baselib.R;

public class CheckOutPinEditText extends AppCompatEditText {
    public float a;
    public float b;
    public int c = 0;
    public final int d = ((int) ((5.0f * getContext().getResources().getDisplayMetrics().density) + 0.5f));
    public int e = 6;
    public final int f = -16777216;
    public final int g = -16777216;
    public final int h = -16777216;
    public int i;
    public final int j = ((int) ((getContext().getResources().getDisplayMetrics().density * 0.5f) + 0.5f));
    public final int k = h.a(getContext(), 10.0f);
    public final RectF l = new RectF();
    public final int m = 0;
    public final Paint n;
    public final Paint o;
    public a p;
    public int q;

    public interface a {
        void c(String str);
    }

    /* JADX WARNING: type inference failed for: r3v16, types: [java.lang.Object, android.view.ActionMode$Callback] */
    public CheckOutPinEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setCustomSelectionActionModeCallback(new Object());
        setEnabled(false);
        setLongClickable(false);
        setImeOptions(268435456);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.PinEditText);
        this.e = obtainStyledAttributes.getInt(R.styleable.PinEditText_maxCount, this.e);
        this.f = obtainStyledAttributes.getColor(R.styleable.PinEditText_pwdCircleColor, this.f);
        this.d = obtainStyledAttributes.getDimensionPixelOffset(R.styleable.PinEditText_pwdCircleRadius, this.d);
        this.g = obtainStyledAttributes.getColor(R.styleable.PinEditText_strokeColor, this.g);
        this.h = obtainStyledAttributes.getColor(R.styleable.PinEditText_divideLineColor, this.h);
        this.j = obtainStyledAttributes.getDimensionPixelSize(R.styleable.PinEditText_divideLineWidth, this.j);
        this.m = obtainStyledAttributes.getDimensionPixelOffset(R.styleable.PinEditText_rectAngle, this.m);
        obtainStyledAttributes.recycle();
        this.o = a((int) ((((float) (this.e - 1)) * getContext().getResources().getDisplayMetrics().density) + 0.5f), Paint.Style.FILL, this.f);
        a(this.j * 2, Paint.Style.STROKE, this.g);
        this.n = a(this.j, Paint.Style.FILL_AND_STROKE, this.h);
        setCursorVisible(false);
        setFilters(new InputFilter[]{new InputFilter.LengthFilter(this.e)});
    }

    public static Paint a(int i2, Paint.Style style, int i3) {
        Paint paint = new Paint(1);
        paint.setStrokeWidth((float) i2);
        paint.setStyle(style);
        paint.setColor(i3);
        paint.setAntiAlias(true);
        return paint;
    }

    public String getPasswordString() {
        return getText().toString().trim();
    }

    public final void onDraw(Canvas canvas) {
        int i2;
        int i3 = this.i;
        int i4 = 0;
        int i5 = 0;
        while (true) {
            int i6 = this.e;
            i2 = this.k;
            if (i4 >= i6) {
                break;
            }
            RectF rectF = new RectF();
            int i8 = this.q;
            rectF.top = (float) i8;
            int i9 = this.i;
            rectF.bottom = (float) (i8 + i9);
            if (i4 != 0) {
                i5 = i3 + i2;
                i3 = i9 + i5;
            }
            rectF.left = (float) i5;
            rectF.right = (float) i3;
            canvas.drawRoundRect(rectF, 12.0f, 12.0f, this.n);
            i4++;
        }
        float f2 = this.a;
        for (int i10 = 0; i10 < this.c; i10++) {
            if (i10 != 0) {
                f2 += (float) (this.i + i2);
            }
            canvas.drawCircle(f2, this.b, (float) this.d, this.o);
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.module_checkout.view.CheckOutPinEditText, androidx.appcompat.widget.AppCompatEditText, android.widget.EditText] */
    public final void onSelectionChanged(int i2, int i3) {
        CheckOutPinEditText.super.onSelectionChanged(i2, i3);
        if (i2 == i3) {
            setSelection(getText().length());
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.EditText] */
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        CheckOutPinEditText.super.onSizeChanged(i2, i3, i4, i5);
        int i6 = this.e;
        int i8 = this.k;
        int i9 = ((i2 - (i8 * i6)) - 1) / i6;
        this.i = i9;
        this.q = (i3 - i9) / 2;
        this.a = (float) (((i2 - (i8 * 5)) / i6) / 2);
        this.b = (float) (i3 / 2);
        this.l.set(0.0f, 0.0f, (float) i2, (float) i3);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.view.View, android.widget.EditText] */
    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        a aVar;
        CheckOutPinEditText.super.onTextChanged(charSequence, i2, i3, i4);
        int length = charSequence.toString().length();
        this.c = length;
        if (length == this.e && (aVar = this.p) != null) {
            aVar.c(getPasswordString());
        }
        invalidate();
    }

    public void setMaxCount(int i2) {
        this.e = i2;
    }

    public void setOnCompleteListener(a aVar) {
        this.p = aVar;
    }
}
