package com.huawei.module_checkout.confirm;

import com.huawei.digitalpayment.customer.httplib.response.ODDisplayGroupResp;
import java.io.Serializable;
import java.util.List;

public class OdConfirmDisplay implements Serializable {
    private String amountDisplay;
    private String buttonText;
    private List<ODDisplayGroupResp> odDisplayItems;
    private String reportTag;
    private String title;
    private String unit;

    public String getAmountDisplay() {
        return this.amountDisplay;
    }

    public String getButtonText() {
        return this.buttonText;
    }

    public List<ODDisplayGroupResp> getOdDisplayItems() {
        return this.odDisplayItems;
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public String getTitle() {
        return this.title;
    }

    public String getUnit() {
        return this.unit;
    }

    public void setAmountDisplay(String str) {
        this.amountDisplay = str;
    }

    public void setButtonText(String str) {
        this.buttonText = str;
    }

    public void setOdDisplayItems(List<ODDisplayGroupResp> list) {
        this.odDisplayItems = list;
    }

    public void setReportTag(String str) {
        this.reportTag = str;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public void setUnit(String str) {
        this.unit = str;
    }
}
