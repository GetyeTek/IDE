package com.huawei.module_checkout.confirm;

import A8.c;
import com.huawei.module_checkout.CheckOutFragment;

public final class f extends c {
    public CheckOutFragment c;

    public static class a {
        public String a;
        public String b;
        public String c;
    }
}
