package com.huawei.module_checkout.confirm;

import R1.a;
import com.huawei.common.exception.BaseException;

public final class b implements a<Boolean> {
    public final /* synthetic */ String a;
    public final /* synthetic */ PaymentConfirmActivity b;

    public b(PaymentConfirmActivity paymentConfirmActivity, String str) {
        this.b = paymentConfirmActivity;
        this.a = str;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        PaymentConfirmActivity paymentConfirmActivity = this.b;
        paymentConfirmActivity.X0(this.a, paymentConfirmActivity.from);
    }
}
