package com.huawei.module_checkout.confirm;

import V7.e;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModel;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.httplib.response.ODDisplayGroupResp;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkstand.adapter.OdConfirmGroupAdapter;
import com.huawei.module_checkout.databinding.ActivityCheckstandOdComfirmBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.List;

public class CheckStandODConfirmActivity extends DataBindingActivity<ActivityCheckstandOdComfirmBinding, ViewModel> {
    public static final /* synthetic */ int d = 0;

    public final int C0() {
        return R$layout.activity_checkstand_od_comfirm;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.module_checkout.confirm.CheckStandODConfirmActivity, android.content.Context, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        CheckStandODConfirmActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getString(R$string.confirm_payment), R.layout.common_toolbar);
        OdConfirmDisplay odConfirmDisplay = (OdConfirmDisplay) getIntent().getSerializableExtra("display");
        if (odConfirmDisplay != null) {
            this.b.d.setText(odConfirmDisplay.getTitle());
            this.b.c.setText(odConfirmDisplay.getAmountDisplay());
            this.b.e.setText(odConfirmDisplay.getUnit());
            List<ODDisplayGroupResp> odDisplayItems = odConfirmDisplay.getOdDisplayItems();
            OdConfirmGroupAdapter odConfirmGroupAdapter = new OdConfirmGroupAdapter();
            this.b.b.setAdapter(odConfirmGroupAdapter);
            odConfirmGroupAdapter.setNewData(odDisplayItems);
        }
        this.b.a.setOnClickListener(new a(this, odConfirmDisplay, 0));
    }
}
