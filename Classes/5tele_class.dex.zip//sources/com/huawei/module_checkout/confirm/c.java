package com.huawei.module_checkout.confirm;

import L2.b;
import P2.a;
import android.text.TextUtils;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.CheckOutFragment;
import com.huawei.module_checkout.confirm.f;
import java.util.List;

public final class c extends b<CheckoutResp> {
    public final /* synthetic */ f.a f;
    public final /* synthetic */ PaymentConfirmActivity g;
    public final /* synthetic */ f h;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c(f fVar, a aVar, f.a aVar2, PaymentConfirmActivity paymentConfirmActivity) {
        super(aVar, true);
        this.h = fVar;
        this.f = aVar2;
        this.g = paymentConfirmActivity;
    }

    public final void b(String str) {
        ((a) this.h.a).S((CheckoutResp) null);
    }

    public final void c(Object obj) {
        CheckoutResp checkoutResp = (CheckoutResp) obj;
        f.a aVar = this.f;
        boolean equals = "selectCoupon".equals(aVar.b);
        f fVar = this.h;
        if (equals) {
            ((a) fVar.a).S(checkoutResp);
            return;
        }
        ((a) fVar.a).S(checkoutResp);
        checkoutResp.getBalanceDisplay();
        String actualAmountDisplay = checkoutResp.getActualAmountDisplay();
        String subTitle = checkoutResp.getSubTitle();
        List<String> displayItems = checkoutResp.getDisplayItems();
        String prepayId = checkoutResp.getPrepayId();
        String unit = checkoutResp.getUnit();
        String unitType = checkoutResp.getUnitType();
        String str = aVar.a;
        PaymentConfirmActivity paymentConfirmActivity = this.g;
        V3.a aVar2 = new V3.a(this, aVar, paymentConfirmActivity);
        CheckOutFragment checkOutFragment = new CheckOutFragment();
        TextUtils.isEmpty((CharSequence) null);
        TextUtils.isEmpty((CharSequence) null);
        checkOutFragment.e = aVar2;
        checkOutFragment.c = actualAmountDisplay;
        checkOutFragment.b = displayItems;
        checkOutFragment.d = prepayId;
        checkOutFragment.a = subTitle;
        checkOutFragment.g = str;
        checkOutFragment.h = unit;
        checkOutFragment.i = unitType;
        checkOutFragment.j = 6;
        fVar.c = checkOutFragment;
        checkOutFragment.show(paymentConfirmActivity.getSupportFragmentManager(), "");
    }
}
