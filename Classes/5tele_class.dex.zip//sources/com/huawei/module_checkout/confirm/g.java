package com.huawei.module_checkout.confirm;

import P2.a;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;

public interface g extends a {
    void S(CheckoutResp checkoutResp);
}
