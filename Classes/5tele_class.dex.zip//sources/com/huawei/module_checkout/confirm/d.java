package com.huawei.module_checkout.confirm;

import L2.b;
import P2.a;
import W2.n;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.CheckOutFragment;

public final class d extends b<TransferResp> {
    public final /* synthetic */ PaymentConfirmActivity f;
    public final /* synthetic */ f g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(f fVar, a aVar, PaymentConfirmActivity paymentConfirmActivity) {
        super(aVar, true, "h5PayOrder");
        this.g = fVar;
        this.f = paymentConfirmActivity;
    }

    public final void b(String str) {
        CheckOutFragment checkOutFragment = this.g.c;
        if (checkOutFragment != null) {
            checkOutFragment.v0();
        }
    }

    /* JADX WARNING: type inference failed for: r2v5, types: [com.huawei.module_checkout.confirm.PaymentConfirmActivity, android.app.Activity] */
    public final void c(Object obj) {
        TransferResp transferResp = (TransferResp) obj;
        CheckOutFragment checkOutFragment = this.g.c;
        if (checkOutFragment != null) {
            checkOutFragment.dismiss();
        }
        n.b("");
        n.j(transferResp, "transferResp");
        n.a.b().getClass();
        n.a.a("/basicUiModule/commonSuccess").navigation();
        this.f.finish();
    }
}
