package com.huawei.module_checkout.confirm;

import A8.c;
import G5.i;
import J2.a;
import W2.n;
import X6.b;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.httplib.request.H5CheckoutRequest;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.coupon.CouponDialog;
import com.huawei.module_checkout.databinding.ActivityPaymentBinding;
import java.util.ArrayList;

@a
@Route(path = "/checkoutModule/odPayment")
public class PaymentConfirmActivity extends BaseMvpActivity<f> implements g {
    public static final /* synthetic */ int r = 0;
    @Autowired(name = "checkoutPath")
    String checkoutPath;
    @Autowired(name = "from")
    String from;
    public ActivityPaymentBinding j;
    public CheckoutResp k;
    public PayLoadingDialog l;
    public String m;
    public FundsSourceInfoDisplay n;
    public H5CheckoutRequest o;
    public final ArrayList p = new ArrayList();
    public CouponDialog q;
    @Autowired(name = "rawRequest")
    String rawRequest;
    @Autowired(name = "tradeType")
    String tradeType;
    @Autowired(name = "transferPath")
    String transferPath;

    public final void D0() {
    }

    public final void G(String str) {
        PayLoadingDialog payLoadingDialog = this.l;
        if (payLoadingDialog != null) {
            payLoadingDialog.dismiss();
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, com.huawei.module_checkout.confirm.PaymentConfirmActivity] */
    public final void G0() {
        PaymentConfirmActivity.super.G0();
        N0(getString(R$string.designstandard_confirm));
        n.b("");
        this.k = (CheckoutResp) n.c(CheckoutResp.class, "checkoutresp");
        this.j.b.setOnClickListener(new b(this, 6));
        V0(this.k);
        this.j.d.setOnClickListener(new i(this, 8));
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [com.huawei.module_checkout.confirm.PaymentConfirmActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x002b, code lost:
        r1 = com.huawei.module_checkout.R$id.ll_pay_method_container;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r10 = this;
            android.view.LayoutInflater r0 = r10.getLayoutInflater()
            int r1 = com.huawei.module_checkout.R$layout.activity_payment
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_checkout.R$id.confirm
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r5 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r5
            if (r5 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.iv_arrow_right
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            if (r2 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.iv_logo
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            if (r2 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.ll_pay_method_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            com.huawei.digitalpayment.customer.viewlib.view.MyRadioGroup r6 = (com.huawei.digitalpayment.customer.viewlib.view.MyRadioGroup) r6
            if (r6 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.rl_coupon
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.RelativeLayout r7 = (android.widget.RelativeLayout) r7
            if (r7 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.rv_payment_method
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.recyclerview.widget.RecyclerView r2 = (androidx.recyclerview.widget.RecyclerView) r2
            if (r2 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.tv_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.tv_coupon
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0077
            int r1 = com.huawei.module_checkout.R$id.tv_discount_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0077
            com.huawei.module_checkout.databinding.ActivityPaymentBinding r1 = new com.huawei.module_checkout.databinding.ActivityPaymentBinding
            r4 = r0
            android.widget.LinearLayout r4 = (android.widget.LinearLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9)
            r10.j = r1
            return r1
        L_0x0077:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.confirm.PaymentConfirmActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final void S(CheckoutResp checkoutResp) {
        if (checkoutResp != null) {
            this.k = checkoutResp;
            this.j.c.removeAllViews();
            V0(checkoutResp);
        }
    }

    public final c U0() {
        return new c(this);
    }

    public final void V(String str) {
        if (this.l == null) {
            this.l = new PayLoadingDialog();
        }
        this.l.show(getSupportFragmentManager(), "");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: androidx.appcompat.app.AppCompatActivity} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void V0(com.huawei.digitalpayment.customer.httplib.response.CheckoutResp r18) {
        /*
            r17 = this;
            r1 = r17
            java.util.List r0 = r18.getFundsSourceInfoDisplay()
            if (r0 == 0) goto L_0x0262
            int r2 = r0.size()
            if (r2 > 0) goto L_0x0010
            goto L_0x0262
        L_0x0010:
            java.lang.String r2 = r18.getUnitType()
            java.lang.String r3 = r18.getUnit()
            com.huawei.module_checkout.databinding.ActivityPaymentBinding r4 = r1.j
            android.widget.TextView r4 = r4.e
            java.lang.String r5 = r18.getActualAmountDisplay()
            r4.setText(r5)
            java.util.Iterator r4 = r0.iterator()
        L_0x0027:
            boolean r0 = r4.hasNext()
            r5 = 0
            if (r0 == 0) goto L_0x023e
            java.lang.Object r0 = r4.next()
            r6 = r0
            com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay r6 = (com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay) r6
            android.view.LayoutInflater r0 = r17.getLayoutInflater()
            int r7 = com.huawei.module_checkout.R$layout.item_pay_method
            r8 = 0
            android.view.View r0 = r0.inflate(r7, r8, r5)
            int r7 = com.huawei.module_checkout.R$id.cb_is_checked
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r7)
            android.widget.CheckBox r9 = (android.widget.CheckBox) r9
            java.lang.String r10 = "Missing required view with ID: "
            if (r9 == 0) goto L_0x022c
            int r7 = com.huawei.module_checkout.R$id.iv_logo
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r7)
            android.widget.ImageView r9 = (android.widget.ImageView) r9
            if (r9 == 0) goto L_0x022c
            int r7 = com.huawei.module_checkout.R$id.ll_display_item
            android.view.View r11 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r7)
            r14 = r11
            android.widget.LinearLayout r14 = (android.widget.LinearLayout) r14
            if (r14 == 0) goto L_0x022c
            r12 = r0
            android.widget.RelativeLayout r12 = (android.widget.RelativeLayout) r12
            int r7 = com.huawei.module_checkout.R$id.tv_pay_method_des
            android.view.View r11 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r7)
            r15 = r11
            android.widget.TextView r15 = (android.widget.TextView) r15
            if (r15 == 0) goto L_0x022c
            int r7 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r11 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r7)
            r13 = r11
            android.widget.TextView r13 = (android.widget.TextView) r13
            if (r13 == 0) goto L_0x022c
            com.huawei.module_checkout.databinding.ItemPayMethodBinding r7 = new com.huawei.module_checkout.databinding.ItemPayMethodBinding
            r11 = r7
            r0 = r13
            r13 = r9
            r18 = r15
            r16 = r0
            r11.<init>(r12, r13, r14, r15, r16)
            java.lang.String r11 = r6.getFundsSourceDisplay()
            r0.setText(r11)
            java.lang.String r0 = r6.getDisplayContent()
            boolean r11 = android.text.TextUtils.isEmpty(r0)
            if (r11 == 0) goto L_0x009f
            r11 = 8
            r12 = r18
            r12.setVisibility(r11)
            goto L_0x00a4
        L_0x009f:
            r12 = r18
            r12.setVisibility(r5)
        L_0x00a4:
            int r11 = android.os.Build.VERSION.SDK_INT
            r13 = 24
            if (r11 < r13) goto L_0x00b2
            android.text.Spanned r0 = W2.d.c(r0)
            r12.setText(r0)
            goto L_0x00b9
        L_0x00b2:
            android.text.Spanned r0 = android.text.Html.fromHtml(r0)
            r12.setText(r0)
        L_0x00b9:
            java.lang.String r0 = r6.getIcon()
            android.app.Application r11 = com.blankj.utilcode.util.J.a()
            boolean r12 = android.text.TextUtils.isEmpty(r0)
            if (r12 == 0) goto L_0x00c8
            goto L_0x0112
        L_0x00c8:
            java.util.Locale r12 = java.util.Locale.ENGLISH
            java.lang.String r12 = r0.toLowerCase(r12)
            java.lang.String r13 = "http"
            boolean r12 = r12.startsWith(r13)
            if (r12 == 0) goto L_0x00e6
            com.bumptech.glide.k r11 = com.bumptech.glide.c.h(r11)
            com.bumptech.glide.j r0 = r11.load(r0)
            com.bumptech.glide.j r0 = r0.apply(r8)
            r0.into(r9)
            goto L_0x0112
        L_0x00e6:
            android.content.res.Resources r12 = r11.getResources()
            java.lang.String r13 = "mipmap"
            java.lang.String r14 = r11.getPackageName()
            int r13 = r12.getIdentifier(r0, r13, r14)
            if (r13 > 0) goto L_0x0100
            java.lang.String r13 = "drawable"
            java.lang.String r11 = r11.getPackageName()
            int r13 = r12.getIdentifier(r0, r13, r11)
        L_0x0100:
            r0 = -1
            if (r13 == r0) goto L_0x0112
            android.graphics.drawable.Drawable r0 = r12.getDrawable(r13)     // Catch:{ Exception -> 0x010b }
            r9.setImageDrawable(r0)     // Catch:{ Exception -> 0x010b }
            goto L_0x0112
        L_0x010b:
            r0 = move-exception
            r0.toString()
            V1.h.b()
        L_0x0112:
            android.widget.RelativeLayout r0 = r7.a
            int r9 = r0.getChildCount()
            r11 = 0
        L_0x0119:
            if (r11 >= r9) goto L_0x016c
            android.view.View r12 = r0.getChildAt(r11)
            boolean r13 = r12 instanceof android.widget.RadioButton
            if (r13 == 0) goto L_0x0169
            java.lang.String r13 = r6.getFundsSource()
            r12.setTag(r13)
            int r13 = android.view.View.generateViewId()
            r12.setId(r13)
            android.widget.RadioButton r12 = (android.widget.RadioButton) r12
            boolean r13 = r6.isAvailable()
            if (r13 != 0) goto L_0x0149
            r12.setEnabled(r13)
            android.content.res.Resources r13 = r17.getResources()
            int r14 = com.huawei.module_checkout.R$drawable.check_box_unable_selector
            android.graphics.drawable.Drawable r13 = r13.getDrawable(r14)
            r12.setBackgroundDrawable(r13)
        L_0x0149:
            java.lang.String r13 = r1.m
            boolean r13 = android.text.TextUtils.isEmpty(r13)
            if (r13 == 0) goto L_0x0159
            boolean r13 = r6.isIsDefault()
            r12.setChecked(r13)
            goto L_0x0169
        L_0x0159:
            java.lang.String r13 = r1.m
            java.lang.String r14 = r6.getFundsSource()
            boolean r13 = r13.equals(r14)
            if (r13 == 0) goto L_0x0169
            r13 = 1
            r12.setChecked(r13)
        L_0x0169:
            int r11 = r11 + 1
            goto L_0x0119
        L_0x016c:
            java.lang.String r9 = r6.getOptimalDiscountAmount()
            java.lang.String r11 = "Prefix"
            boolean r11 = r11.equals(r2)
            java.lang.String r12 = "-"
            if (r11 == 0) goto L_0x017f
            java.lang.String r9 = androidx.camera.camera2.internal.P.a(r12, r3, r9)
            goto L_0x0183
        L_0x017f:
            java.lang.String r9 = androidx.camera.camera2.internal.P.a(r12, r9, r3)
        L_0x0183:
            boolean r11 = r6.isIsDefault()
            java.lang.String r12 = r1.m
            boolean r12 = android.text.TextUtils.isEmpty(r12)
            java.util.ArrayList r13 = r1.p
            if (r12 != 0) goto L_0x0195
            com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay r12 = r1.n
            if (r12 != 0) goto L_0x01b5
        L_0x0195:
            if (r11 == 0) goto L_0x01b5
            java.lang.String r11 = r6.getFundsSource()
            r1.m = r11
            com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay r11 = r1.W0(r11)
            r1.n = r11
            if (r13 == 0) goto L_0x01b5
            java.util.List r11 = r6.getOptimalCouponScheme()
            if (r11 == 0) goto L_0x01b5
            r13.clear()
            java.util.List r11 = r6.getOptimalCouponScheme()
            r13.addAll(r11)
        L_0x01b5:
            com.huawei.module_checkout.databinding.ActivityPaymentBinding r11 = r1.j
            android.widget.TextView r11 = r11.f
            boolean r12 = J8.a.i(r13)
            if (r12 == 0) goto L_0x01c5
            int r9 = com.huawei.module_checkout.R$string.no_coupons
            java.lang.String r9 = r1.getString(r9)
        L_0x01c5:
            r11.setText(r9)
            com.huawei.module_checkout.databinding.ActivityPaymentBinding r9 = r1.j
            com.huawei.digitalpayment.customer.viewlib.view.MyRadioGroup r9 = r9.c
            r9.addView(r0)
            java.util.List r0 = r6.getDisplayItems()
            if (r0 == 0) goto L_0x0027
            java.util.Iterator r0 = r0.iterator()
        L_0x01d9:
            boolean r6 = r0.hasNext()
            if (r6 == 0) goto L_0x0027
            java.lang.Object r6 = r0.next()
            com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay$DisplayItemsBean r6 = (com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay.DisplayItemsBean) r6
            android.view.LayoutInflater r9 = r17.getLayoutInflater()
            int r11 = com.huawei.module_checkout.R$layout.item_od_display_item_layout
            android.view.View r9 = r9.inflate(r11, r8, r5)
            r11 = r9
            android.widget.RelativeLayout r11 = (android.widget.RelativeLayout) r11
            int r12 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r13 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r12)
            android.widget.TextView r13 = (android.widget.TextView) r13
            if (r13 == 0) goto L_0x021a
            int r12 = com.huawei.module_checkout.R$id.tv_value
            android.view.View r14 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r12)
            android.widget.TextView r14 = (android.widget.TextView) r14
            if (r14 == 0) goto L_0x021a
            java.lang.String r9 = r6.getValue()
            r14.setText(r9)
            java.lang.String r6 = r6.getLabel()
            r13.setText(r6)
            android.widget.LinearLayout r6 = r7.b
            r6.addView(r11)
            goto L_0x01d9
        L_0x021a:
            android.content.res.Resources r0 = r9.getResources()
            java.lang.String r0 = r0.getResourceName(r12)
            java.lang.NullPointerException r2 = new java.lang.NullPointerException
            java.lang.String r0 = r10.concat(r0)
            r2.<init>(r0)
            throw r2
        L_0x022c:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r7)
            java.lang.NullPointerException r2 = new java.lang.NullPointerException
            java.lang.String r0 = r10.concat(r0)
            r2.<init>(r0)
            throw r2
        L_0x023e:
            android.animation.LayoutTransition r0 = new android.animation.LayoutTransition
            r0.<init>()
            r2 = 400(0x190, double:1.976E-321)
            r0.setDuration(r2)
            r2 = 4
            r0.enableTransitionType(r2)
            r0.setAnimateParentHierarchy(r5)
            com.huawei.module_checkout.databinding.ActivityPaymentBinding r2 = r1.j
            com.huawei.digitalpayment.customer.viewlib.view.MyRadioGroup r2 = r2.c
            r2.setLayoutTransition(r0)
            com.huawei.module_checkout.databinding.ActivityPaymentBinding r0 = r1.j
            com.huawei.digitalpayment.customer.viewlib.view.MyRadioGroup r0 = r0.c
            com.huawei.kbz.chat.contact.d r2 = new com.huawei.kbz.chat.contact.d
            r2.<init>(r1)
            r0.setOnCheckedChangeListener(r2)
        L_0x0262:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.confirm.PaymentConfirmActivity.V0(com.huawei.digitalpayment.customer.httplib.response.CheckoutResp):void");
    }

    public final FundsSourceInfoDisplay W0(String str) {
        for (FundsSourceInfoDisplay fundsSourceInfoDisplay : this.k.getFundsSourceInfoDisplay()) {
            if (str != null && str.equals(fundsSourceInfoDisplay.getFundsSource())) {
                return fundsSourceInfoDisplay;
            }
        }
        return null;
    }

    /* JADX WARNING: type inference failed for: r4v5, types: [com.huawei.module_checkout.confirm.f$a, java.lang.Object] */
    public final void X0(String str, String str2) {
        H5CheckoutRequest h5CheckoutRequest = new H5CheckoutRequest();
        this.o = h5CheckoutRequest;
        h5CheckoutRequest.setPrepayId(this.k.getPrepayId());
        this.o.setFundsSource(str);
        this.o.setRawRequest(this.rawRequest);
        this.o.setAccountType(((FundsSourceInfoDisplay) this.k.getFundsSourceInfoDisplay().get(0)).getAccountType());
        ArrayList arrayList = this.p;
        if (arrayList != null) {
            this.o.setCoupons(arrayList);
        }
        this.o.setTradeType(this.tradeType);
        ? obj = new Object();
        obj.b = str2;
        obj.a = this.m;
        obj.c = this.transferPath;
        f fVar = this.i;
        H5CheckoutRequest h5CheckoutRequest2 = this.o;
        fVar.getClass();
        fVar.a(H3.c.e().e0(h5CheckoutRequest2), new c(fVar, (P2.a) fVar.a, obj, this));
    }
}
