package com.huawei.module_checkout.confirm;

import android.view.View;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import f2.c;
import java.io.Serializable;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;
    public final /* synthetic */ Serializable c;

    public /* synthetic */ a(Object obj, Serializable serializable, int i) {
        this.a = i;
        this.b = obj;
        this.c = serializable;
    }

    public final void onClick(View view) {
        CheckoutResp checkoutResp = this.c;
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = CheckStandODConfirmActivity.d;
                DataBindingActivity dataBindingActivity = (CheckStandODConfirmActivity) obj;
                OdConfirmDisplay odConfirmDisplay = (OdConfirmDisplay) checkoutResp;
                if (odConfirmDisplay != null) {
                    dataBindingActivity.getClass();
                    ReportViewModel reportViewModel = c.b;
                    c.a.a.c("OD_confirm_pay", new String[]{odConfirmDisplay.getReportTag(), odConfirmDisplay.getAmountDisplay()});
                }
                dataBindingActivity.setResult(-1);
                dataBindingActivity.finish();
                return;
            default:
                CheckStandFragment checkStandFragment = (CheckStandFragment) obj;
                checkStandFragment.getClass();
                FundsSourceInfoDisplay z0 = CheckStandFragment.z0("OD_COMBINED", checkoutResp.getFundsSourceInfoDisplay());
                if (z0 != null) {
                    checkStandFragment.e = true;
                    ReportViewModel reportViewModel2 = c.b;
                    c.a.a.c("OD_Confirm_use_od", new String[]{"ok", checkStandFragment.a.h()});
                    CheckStandViewModel checkStandViewModel = checkStandFragment.a;
                    checkStandViewModel.b(checkStandViewModel.g(z0), new m7.a(checkStandViewModel, z0));
                    return;
                }
                return;
        }
    }
}
