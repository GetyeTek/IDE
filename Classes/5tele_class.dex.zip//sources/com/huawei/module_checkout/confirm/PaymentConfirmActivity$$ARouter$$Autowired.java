package com.huawei.module_checkout.confirm;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class PaymentConfirmActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_checkout.confirm.PaymentConfirmActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (PaymentConfirmActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.from;
        } else {
            str = r4.getIntent().getExtras().getString("from", r4.from);
        }
        r4.from = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.tradeType;
        } else {
            str2 = r4.getIntent().getExtras().getString("tradeType", r4.tradeType);
        }
        r4.tradeType = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.checkoutPath;
        } else {
            str3 = r4.getIntent().getExtras().getString("checkoutPath", r4.checkoutPath);
        }
        r4.checkoutPath = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.transferPath;
        } else {
            str4 = r4.getIntent().getExtras().getString("transferPath", r4.transferPath);
        }
        r4.transferPath = str4;
        if (r4.getIntent().getExtras() == null) {
            str5 = r4.rawRequest;
        } else {
            str5 = r4.getIntent().getExtras().getString("rawRequest", r4.rawRequest);
        }
        r4.rawRequest = str5;
    }
}
