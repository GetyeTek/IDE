package com.huawei.module_checkout.p2ptransfer.viewmodel;

import S2.b;
import android.util.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import z7.a;
import z7.c;

public class P2PTransferViewModel extends CheckStandViewModel {
    public String u;
    public final c v = new c();
    public final MutableLiveData<String> w = new MutableLiveData<>();

    public final LiveData<b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        ArrayMap arrayMap = new ArrayMap();
        arrayMap.put("prepayId", this.s);
        arrayMap.put("tradeType", this.u);
        if (fundsSourceInfoDisplay != null) {
            arrayMap.put("accountType", fundsSourceInfoDisplay.getAccountType());
            arrayMap.put("fundsSource", fundsSourceInfoDisplay.getFundsSource());
        }
        c cVar = this.v;
        cVar.getClass();
        return new a(cVar, arrayMap).a;
    }

    public final LiveData<b<TransferResp>> i(String str) {
        ArrayMap arrayMap = new ArrayMap();
        arrayMap.put("initiatorPin", L3.a.g(str));
        arrayMap.put("pinVersion", L3.a.b.getPinKeyVersion());
        arrayMap.put("prepayId", this.s);
        c cVar = this.v;
        cVar.getClass();
        return new z7.b(cVar, arrayMap).a;
    }
}
