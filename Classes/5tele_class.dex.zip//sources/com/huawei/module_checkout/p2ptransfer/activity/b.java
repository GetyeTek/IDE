package com.huawei.module_checkout.p2ptransfer.activity;

import O2.a;
import W2.g;
import android.text.Editable;

public final class b extends a {
    public final /* synthetic */ P2PTransferPayActivity b;

    public b(P2PTransferPayActivity p2PTransferPayActivity) {
        super(1);
        this.b = p2PTransferPayActivity;
    }

    public final void afterTextChanged(Editable editable) {
        this.b.p.d(g.a(editable.toString()));
    }
}
