package com.huawei.module_checkout.p2ptransfer.activity;

import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import i7.C0013a;

public final class c implements C0013a.b<TransferResp> {
    public final /* synthetic */ P2PTransferPayActivity a;

    public c(P2PTransferPayActivity p2PTransferPayActivity) {
        this.a = p2PTransferPayActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    public final void onSuccess(Object obj) {
        this.a.b1((TransferResp) obj);
    }
}
