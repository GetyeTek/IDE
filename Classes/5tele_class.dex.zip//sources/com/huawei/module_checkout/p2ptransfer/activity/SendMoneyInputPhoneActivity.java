package com.huawei.module_checkout.p2ptransfer.activity;

import A7.d;
import W1.b;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.baselib.mvvm.data.Status;
import com.huawei.digitalpayment.customer.httplib.response.RecentTransfersResp;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding;
import com.huawei.module_checkout.p2ptransfer.CustomerType;
import com.huawei.module_checkout.p2ptransfer.adapter.RecentTransferInfoAdapter;
import com.huawei.module_checkout.p2ptransfer.repository.QueryRecentTransferRepository;
import com.huawei.module_checkout.p2ptransfer.viewmodel.SendMoneyInputPhoneViewModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import z7.f;

@Route(path = "/checkoutModule/transferInputPhone")
public class SendMoneyInputPhoneActivity extends BaseMvvmActivity<SendMoneyInputPhoneViewModel> {
    public static final /* synthetic */ int p = 0;
    public ActivitySendMoneyInputPhoneBinding k;
    public ArrayList l;
    public RecentTransferInfoAdapter m;
    public b.b n;
    public String o;

    public class a implements Observer<RecentTransfersResp> {
        public a() {
        }

        public final void onChanged(Object obj) {
            List recentTransfers;
            RecentTransfersResp recentTransfersResp = (RecentTransfersResp) obj;
            SendMoneyInputPhoneActivity sendMoneyInputPhoneActivity = SendMoneyInputPhoneActivity.this;
            sendMoneyInputPhoneActivity.l.clear();
            if (!(recentTransfersResp == null || (recentTransfers = recentTransfersResp.getRecentTransfers()) == null || recentTransfers.size() <= 0)) {
                sendMoneyInputPhoneActivity.k.i.setVisibility(0);
                sendMoneyInputPhoneActivity.k.d.setVisibility(0);
                sendMoneyInputPhoneActivity.l.addAll(recentTransfers);
            }
            sendMoneyInputPhoneActivity.m.notifyDataSetChanged();
            if (sendMoneyInputPhoneActivity.l.isEmpty()) {
                sendMoneyInputPhoneActivity.k.i.setVisibility(8);
                sendMoneyInputPhoneActivity.k.d.setVisibility(8);
                sendMoneyInputPhoneActivity.k.g.setVisibility(0);
                return;
            }
            sendMoneyInputPhoneActivity.k.i.setVisibility(0);
            sendMoneyInputPhoneActivity.k.d.setVisibility(0);
            sendMoneyInputPhoneActivity.k.g.setVisibility(8);
        }
    }

    public class b implements Observer<Status> {
        public b() {
        }

        public final void onChanged(Object obj) {
            Status status = (Status) obj;
            Status status2 = Status.LOADING;
            SendMoneyInputPhoneActivity sendMoneyInputPhoneActivity = SendMoneyInputPhoneActivity.this;
            if (status == status2) {
                sendMoneyInputPhoneActivity.n.a(1);
            } else {
                sendMoneyInputPhoneActivity.n.a(2);
            }
        }
    }

    public class c implements Observer<VerifyNumberResp> {
        public c() {
        }

        public final void onChanged(Object obj) {
            VerifyNumberResp verifyNumberResp = (VerifyNumberResp) obj;
            int i = SendMoneyInputPhoneActivity.p;
            FragmentActivity fragmentActivity = SendMoneyInputPhoneActivity.this;
            fragmentActivity.getClass();
            if (!CustomerType.REGISTERED.getName().equals(verifyNumberResp.getCustomerType())) {
                String string = fragmentActivity.getString(R$string.this_number_is_not_registered);
                String string2 = fragmentActivity.getString(R$string.designstandard_no);
                String string3 = fragmentActivity.getString(R$string.yes);
                c0.b bVar = new c0.b(1, fragmentActivity, verifyNumberResp);
                BaseDialog baseDialog = new BaseDialog();
                baseDialog.g = null;
                baseDialog.h = string;
                baseDialog.i = string2;
                baseDialog.j = string3;
                baseDialog.k = null;
                baseDialog.l = bVar;
                baseDialog.show(fragmentActivity.getSupportFragmentManager(), "tipsDialog");
                return;
            }
            fragmentActivity.W0((String) null, verifyNumberResp);
        }
    }

    public final void D0() {
        SendMoneyInputPhoneViewModel sendMoneyInputPhoneViewModel = this.i;
        sendMoneyInputPhoneViewModel.h.setValue(Status.LOADING);
        new QueryRecentTransferRepository().sendRequest(new d(sendMoneyInputPhoneViewModel, 0));
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v6, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void G0() {
        /*
            r9 = this;
            r0 = 5
            r1 = 1
            r2 = 4
            r3 = 2
            r4 = 0
            com.huawei.module_checkout.p2ptransfer.activity.SendMoneyInputPhoneActivity.super.G0()
            int r5 = com.huawei.module_checkout.R$string.send_money_to_individual
            java.lang.String r5 = r9.getString(r5)
            r9.N0(r5)
            int r5 = com.huawei.module_checkout.R$color.color_F4F4F4
            int r6 = androidx.core.content.ContextCompat.getColor(r9, r5)
            r9.Q0(r6)
            r9.S0(r5)
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            r9.l = r6
            com.huawei.module_checkout.p2ptransfer.adapter.RecentTransferInfoAdapter r6 = new com.huawei.module_checkout.p2ptransfer.adapter.RecentTransferInfoAdapter
            java.util.ArrayList r7 = r9.l
            int r8 = com.huawei.module_checkout.R$layout.item_checkout_recent_transfer_info
            r6.<init>(r8, r7)
            r9.m = r6
            com.huawei.digitalpayment.buyairtime.activity.e r7 = new com.huawei.digitalpayment.buyairtime.activity.e
            r7.<init>(r9)
            r6.setOnItemClickListener(r7)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r6 = r9.k
            com.huawei.common.widget.round.RoundRecyclerView r6 = r6.i
            androidx.recyclerview.widget.LinearLayoutManager r7 = new androidx.recyclerview.widget.LinearLayoutManager
            r7.<init>(r9)
            r6.setLayoutManager(r7)
            com.huawei.common.widget.recyclerview.RecycleViewDivider r6 = new com.huawei.common.widget.recyclerview.RecycleViewDivider
            int r5 = androidx.core.content.ContextCompat.getColor(r9, r5)
            r7 = 1065353216(0x3f800000, float:1.0)
            int r7 = R9.h.a(r9, r7)
            r6.<init>(r5, r7)
            r5 = 1113849856(0x42640000, float:57.0)
            int r5 = R9.h.a(r9, r5)
            r6.c = r5
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.common.widget.round.RoundRecyclerView r5 = r5.i
            r5.addItemDecoration(r6)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.common.widget.round.RoundRecyclerView r5 = r5.i
            com.huawei.module_checkout.p2ptransfer.adapter.RecentTransferInfoAdapter r6 = r9.m
            r5.setAdapter(r6)
            W1.b r5 = W1.b.b()
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r6 = r9.k
            com.huawei.common.widget.round.RoundRecyclerView r6 = r6.i
            W1.b$b r5 = r5.c(r6)
            androidx.camera.core.impl.r r6 = new androidx.camera.core.impl.r
            r6.<init>(r9, r3)
            r5.b = r6
            r9.n = r5
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r5 = r5.b
            D4.m r6 = new D4.m
            r7 = 7
            r6.<init>(r9, r7)
            r5.setOnClickListener(r6)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r5 = r5.b
            r5.setEnabled(r4)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            android.widget.ImageView r5 = r5.d
            D4.n r6 = new D4.n
            r6.<init>(r9, r2)
            r5.setOnClickListener(r6)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.common.widget.input.CommonInputView r5 = r5.h
            java.lang.String r6 = "+251"
            r5.setAreaCode(r6)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.common.widget.input.CommonInputView r5 = r5.h
            r6 = 0
            r5.setError(r6)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.common.widget.input.CommonInputView r5 = r5.h
            android.widget.EditText r5 = r5.getEditText()
            com.huawei.module_checkout.p2ptransfer.activity.f r6 = new com.huawei.module_checkout.p2ptransfer.activity.f
            r6.<init>()
            android.text.InputFilter[] r7 = new android.text.InputFilter[r1]
            r7[r4] = r6
            r5.setFilters(r7)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r5 = r9.k
            com.huawei.common.widget.input.CommonInputView r5 = r5.h
            android.widget.EditText r5 = r5.getEditText()
            r5.setInputType(r3)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r3 = r9.k
            com.huawei.common.widget.input.CommonInputView r3 = r3.h
            android.widget.EditText r3 = r3.getEditText()
            a4.d r5 = new a4.d
            r5.<init>(r9, r1)
            r3.addTextChangedListener(r5)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r1 = r9.k
            com.huawei.common.widget.input.CommonInputView r1 = r1.h
            O1.b r3 = new O1.b
            r3.<init>(r9, r2)
            r5 = 250(0xfa, double:1.235E-321)
            r1.postDelayed(r3, r5)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r1 = r9.k
            android.widget.ImageView r1 = r1.f
            R4.a r2 = new R4.a
            r2.<init>(r9, r0)
            r1.setOnClickListener(r2)
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r1 = r9.k
            android.widget.ImageView r1 = r1.e
            O1.d r2 = new O1.d
            r2.<init>(r9, r0)
            r1.setOnClickListener(r2)
            com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel r0 = r9.i
            com.huawei.module_checkout.p2ptransfer.viewmodel.SendMoneyInputPhoneViewModel r0 = (com.huawei.module_checkout.p2ptransfer.viewmodel.SendMoneyInputPhoneViewModel) r0
            r0.getClass()
            com.huawei.digitalpayment.customer.httplib.repository.BannerRepository r1 = new com.huawei.digitalpayment.customer.httplib.repository.BannerRepository
            java.lang.String r2 = "Application Page"
            java.lang.String r3 = "Send Money"
            r1.<init>(r2, r3)
            r0.l = r1
            A7.e r2 = new A7.e
            r2.<init>(r0, r4)
            r1.sendRequest(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.p2ptransfer.activity.SendMoneyInputPhoneActivity.G0():void");
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [com.huawei.module_checkout.p2ptransfer.activity.SendMoneyInputPhoneActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0062, code lost:
        r1 = com.huawei.module_checkout.R$id.phone_number_input;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x006d, code lost:
        r1 = com.huawei.module_checkout.R$id.rv_recycler_view;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0021, code lost:
        r1 = com.huawei.module_checkout.R$id.cycle_view;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r13 = this;
            android.view.LayoutInflater r0 = r13.getLayoutInflater()
            int r1 = com.huawei.module_checkout.R$layout.activity_send_money_input_phone
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.module_checkout.R$id.btn_next
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r5 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r5
            if (r5 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.cl_bg
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundConstraintLayout r2 = (com.huawei.common.widget.round.RoundConstraintLayout) r2
            if (r2 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.cycle_view
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            com.huawei.common.widget.banner.CycleViewPager r6 = (com.huawei.common.widget.banner.CycleViewPager) r6
            if (r6 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.fl_history
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.FrameLayout r2 = (android.widget.FrameLayout) r2
            if (r2 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.iv_delete
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            if (r7 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.iv_msisdn_scan
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            android.widget.ImageView r8 = (android.widget.ImageView) r8
            if (r8 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.iv_select_contacts
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            android.widget.ImageView r9 = (android.widget.ImageView) r9
            if (r9 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.ll_no_transfer_history
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            android.widget.LinearLayout r10 = (android.widget.LinearLayout) r10
            if (r10 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.phone_number_input
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            com.huawei.common.widget.input.CommonInputView r11 = (com.huawei.common.widget.input.CommonInputView) r11
            if (r11 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.rv_recycler_view
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r12 = r2
            com.huawei.common.widget.round.RoundRecyclerView r12 = (com.huawei.common.widget.round.RoundRecyclerView) r12
            if (r12 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.tv_phone_number
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0098
            int r1 = com.huawei.module_checkout.R$id.tv_recent
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0098
            com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding r1 = new com.huawei.module_checkout.databinding.ActivitySendMoneyInputPhoneBinding
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r13.k = r1
            return r1
        L_0x0098:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.p2ptransfer.activity.SendMoneyInputPhoneActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final void U0() {
        SendMoneyInputPhoneActivity.super.U0();
        this.i.g.observe(this, new a());
        this.i.h.observe(this, new b());
        this.i.j.observe(this, new c());
        this.i.i.observe(this, new e(this));
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_checkout.p2ptransfer.activity.SendMoneyInputPhoneActivity] */
    public final void W0(String str, VerifyNumberResp verifyNumberResp) {
        n.a.b().getClass();
        n.a.a("/checkoutModule/transferAmount").withString("msisdn", this.o).withBoolean("showMsisdn", true).withString("transactionTo", str).withString("publicName", verifyNumberResp.getPublicName()).withString("avatar", verifyNumberResp.getAvatar()).withString("tradeType", "NativeApp").withString("customerType", verifyNumberResp.getCustomerType()).navigation(this);
    }

    public final void X0(String str) {
        this.o = str;
        SendMoneyInputPhoneViewModel sendMoneyInputPhoneViewModel = this.i;
        f fVar = sendMoneyInputPhoneViewModel.k;
        fVar.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("receiverMsisdn", str);
        sendMoneyInputPhoneViewModel.b(new z7.d(fVar, hashMap).a, new A7.b(sendMoneyInputPhoneViewModel));
    }
}
