package com.huawei.module_checkout.p2ptransfer.activity;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import com.huawei.module_checkout.p2ptransfer.viewmodel.P2PTransferViewModel;

@Route(path = "/checkoutModule/p2pCheckStand")
public class P2PTransferCheckStandActivity extends CheckStandActivity<P2PTransferViewModel> {
    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_checkout.p2ptransfer.activity.P2PTransferCheckStandActivity, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void D0() {
        super.D0();
        getIntent().getStringExtra("amount");
        String stringExtra = getIntent().getStringExtra("notes");
        String stringExtra2 = getIntent().getStringExtra("tradeType");
        getIntent().getStringExtra("msisdn");
        P2PTransferViewModel p2PTransferViewModel = (P2PTransferViewModel) this.b;
        p2PTransferViewModel.w.setValue(stringExtra);
        p2PTransferViewModel.u = stringExtra2;
    }
}
