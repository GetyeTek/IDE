package com.huawei.module_checkout.p2ptransfer.repository;

import W2.n;
import com.huawei.digitalpayment.customer.httplib.response.RecentTransfersResp;
import com.huawei.http.b;

public class QueryRecentTransferRepository extends b<RecentTransfersResp, RecentTransfersResp> {
    public static final /* synthetic */ int a = 0;

    public final String getApiKey() {
        return n.b("").e("recent_login_phone_number") + "_v1/ethiopia/queryRecentTransfer";
    }

    public final String getApiPath() {
        return "v1/ethiopia/queryRecentTransfer";
    }

    public final boolean isCache() {
        return true;
    }
}
