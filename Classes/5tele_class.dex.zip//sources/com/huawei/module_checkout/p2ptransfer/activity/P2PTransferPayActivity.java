package com.huawei.module_checkout.p2ptransfer.activity;

import V1.h;
import V1.k;
import W2.g;
import W2.n;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.lifecycle.Observer;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.ParameterLimitBean;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.module_checkout.p2ptransfer.dialog.AddNoteDialog;
import com.huawei.module_checkout.p2ptransfer.viewmodel.P2PTransferViewModel;
import i7.C0013a;
import java.util.HashMap;

@Route(path = "/checkoutModule/transferAmount")
public class P2PTransferPayActivity extends BaseMvvmActivity<P2PTransferViewModel> {
    public static final /* synthetic */ int r = 0;
    @Autowired(name = "amount")
    String amount;
    @Autowired(name = "avatar")
    String avatar;
    @Autowired(name = "chatAvatar")
    String chatAvatar;
    @Autowired(name = "customerType")
    String customerType;
    public TextView k;
    public TextView l;
    public TextView m;
    @Autowired(name = "msisdn")
    String msisdn;
    public TextView n;
    @Autowired(name = "notes")
    String notes;
    public InputItemEditText o;
    @Autowired(name = "operationNumber")
    String operationNumber;
    public CustomKeyBroadPop p;
    @Autowired(name = "publicName")
    String publicName;
    public boolean q;
    @Autowired(name = "showMsisdn")
    boolean showMsisdn;
    @Autowired(name = "title")
    String title;
    @Autowired(name = "tradeType")
    String tradeType = "QrCode";
    @Autowired(name = "transactionTo")
    String transactionTo;

    public class a implements Observer<String> {
        public a() {
        }

        public final void onChanged(Object obj) {
            int i;
            String str = (String) obj;
            P2PTransferPayActivity p2PTransferPayActivity = P2PTransferPayActivity.this;
            p2PTransferPayActivity.n.setText(str);
            TextView textView = p2PTransferPayActivity.n;
            int i2 = 0;
            if (TextUtils.isEmpty(str)) {
                i = 8;
            } else {
                i = 0;
            }
            textView.setVisibility(i);
            TextView textView2 = p2PTransferPayActivity.m;
            if (!TextUtils.isEmpty(str)) {
                i2 = 8;
            }
            textView2.setVisibility(i2);
        }
    }

    public class b implements Observer<CheckoutResp> {
        public b() {
        }

        public final void onChanged(Object obj) {
            CheckoutResp checkoutResp = (CheckoutResp) obj;
            int i = P2PTransferPayActivity.r;
            BaseMvvmActivity baseMvvmActivity = P2PTransferPayActivity.this;
            if (((FundsSourceInfoDisplay) baseMvvmActivity.i.k.getValue()) != null) {
                Bundle bundle = new Bundle(1);
                bundle.putString("amount", baseMvvmActivity.amount);
                bundle.putString("notes", baseMvvmActivity.notes);
                bundle.putString("tradeType", baseMvvmActivity.tradeType);
                bundle.putString("msisdn", baseMvvmActivity.msisdn);
                bundle.putSerializable("CheckoutResp", checkoutResp);
                C0013a.C0002a.a.a(baseMvvmActivity, "/checkoutModule/p2pCheckStand", bundle, new c(baseMvvmActivity));
            } else if (!checkoutResp.isOpenOd()) {
                String string = baseMvvmActivity.getString(R$string.checkout_activate_credit_limit);
                String string2 = baseMvvmActivity.getString(R$string.designstandard_cancel);
                String string3 = baseMvvmActivity.getString(R$string.designstandard_ok);
                com.huawei.common.widget.banner.b bVar = new com.huawei.common.widget.banner.b(baseMvvmActivity, 4);
                BaseDialog baseDialog = new BaseDialog();
                baseDialog.g = null;
                baseDialog.h = string;
                baseDialog.i = string2;
                baseDialog.j = string3;
                baseDialog.k = null;
                baseDialog.l = bVar;
                baseDialog.show(baseMvvmActivity.getSupportFragmentManager(), "tipsDialog");
            } else {
                String string4 = baseMvvmActivity.getString(R$string.checkout_you_dont_have_enough_balance_to_complete_this);
                String string5 = baseMvvmActivity.getString(R$string.designstandard_cancel);
                String string6 = baseMvvmActivity.getString(R$string.designstandard_cash_in);
                a aVar = new a(0);
                BaseDialog baseDialog2 = new BaseDialog();
                baseDialog2.g = null;
                baseDialog2.h = string4;
                baseDialog2.i = string5;
                baseDialog2.j = string6;
                baseDialog2.k = null;
                baseDialog2.l = aVar;
                baseDialog2.show(baseMvvmActivity.getSupportFragmentManager(), "tipsDialog");
            }
        }
    }

    public class c implements R1.a<String> {
        public c() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final /* synthetic */ void onError(BaseException baseException) {
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            int i = P2PTransferPayActivity.r;
            P2PTransferPayActivity.this.i.w.setValue((String) obj);
        }
    }

    public class d implements C0013a.b<TransferResp> {
        public d() {
        }

        public final /* synthetic */ void a(int i, String str) {
        }

        public final /* synthetic */ void b(CheckoutResp checkoutResp) {
        }

        public final void onCancel() {
        }

        public final void onSuccess(Object obj) {
            P2PTransferPayActivity.this.b1((TransferResp) obj);
        }
    }

    public final void D0() {
    }

    public final ViewBinding K0() {
        return null;
    }

    public final void U0() {
        P2PTransferPayActivity.super.U0();
        this.i.w.observe(this, new a());
        this.i.j.observe(this, new b());
    }

    public final String W0() {
        return this.msisdn;
    }

    public final String X0() {
        return this.operationNumber;
    }

    public final String Y0() {
        return this.tradeType;
    }

    public final String Z0() {
        return this.transactionTo;
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [android.content.Context, com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity] */
    public void a1() {
        w5.a.a("Send_money_Next_Send_V1");
        String obj = this.o.getEditableText().toString();
        this.amount = obj;
        if (TextUtils.isEmpty(obj)) {
            k.b(1, getString(R$string.designstandard_please_input_amount));
        } else if (!g.a(this.amount)) {
            k.b(1, getString(R$string.designstandard_incorrect_amount_format));
        } else {
            String trim = this.n.getText().toString().trim();
            if (n.b("").e("recent_login_phone_number").equals(this.msisdn)) {
                k.b(1, getString(R$string.designstandard_sorry_you_cannot_send_money_to_your));
                return;
            }
            HashMap hashMap = new HashMap();
            hashMap.put("amount", this.amount);
            hashMap.put("note", trim);
            hashMap.put("tradeType", this.tradeType);
            hashMap.put("receiverMsisdn", this.msisdn);
            if (!TextUtils.isEmpty(this.operationNumber)) {
                HashMap hashMap2 = new HashMap();
                hashMap2.put("operationNumber", this.operationNumber);
                hashMap.put("extraPayParams", hashMap2);
            }
            C0013a.C0002a.a.c(this, getString(R$string.checkout_send), PaySceneEnum.P2P_TRANSFER, hashMap, new d());
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity, android.app.Activity] */
    public void b1(TransferResp transferResp) {
        x7.a aVar = x7.a.g;
        R1.a<TransferResp> aVar2 = aVar.a;
        if (aVar2 != null) {
            aVar2.onSuccess(transferResp);
            aVar.a = null;
            finish();
            return;
        }
        n.a.b().getClass();
        n.a.a("/basicUiModule/commonSuccess").withString("transactionTo", this.transactionTo).withString("buttonText", getString(R$string.baselib_finished)).withSerializable("TransferResp", transferResp).navigation();
        finish();
    }

    public final void c1() {
        int i = 50;
        try {
            ParameterLimitBean parameterLimit = BasicConfig.getInstance().getParameterLimit();
            if (parameterLimit != null && !TextUtils.isEmpty(parameterLimit.getNoteLimit())) {
                i = Integer.parseInt(parameterLimit.getNoteLimit());
            }
        } catch (Exception unused) {
            h.b();
        }
        new AddNoteDialog((String) this.i.w.getValue(), new c(), i).show(getSupportFragmentManager(), "");
    }

    public final void onBackPressed() {
        if (this.p.isShowing()) {
            this.p.c();
        } else {
            P2PTransferPayActivity.super.onBackPressed();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v1, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: type inference failed for: r2v1, types: [com.huawei.module_checkout.p2ptransfer.activity.b, android.text.TextWatcher] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onCreate(@androidx.annotation.Nullable android.os.Bundle r9) {
        /*
            r8 = this;
            r0 = 5
            r1 = 0
            r2 = 2
            r3 = 1
            com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity.super.onCreate(r9)
            int r9 = com.huawei.module_checkout.R$layout.activity_transfer_to_personal_pay_confirm
            r8.setContentView(r9)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = new com.huawei.common.widget.keyboard.CustomKeyBroadPop
            c2.d r4 = c2.d.a()
            r9.<init>(r8, r4)
            r8.p = r9
            int r9 = com.huawei.module_checkout.R$id.tv_transfer_to
            android.view.View r9 = r8.findViewById(r9)
            android.widget.TextView r9 = (android.widget.TextView) r9
            r8.k = r9
            int r9 = com.huawei.module_checkout.R$id.tv_org_name
            android.view.View r9 = r8.findViewById(r9)
            android.widget.TextView r9 = (android.widget.TextView) r9
            r8.l = r9
            int r9 = com.huawei.module_checkout.R$id.tv_add_notes
            android.view.View r9 = r8.findViewById(r9)
            android.widget.TextView r9 = (android.widget.TextView) r9
            r8.m = r9
            int r9 = com.huawei.module_checkout.R$id.tv_add_notes_show
            android.view.View r9 = r8.findViewById(r9)
            android.widget.TextView r9 = (android.widget.TextView) r9
            r8.n = r9
            int r9 = com.huawei.module_checkout.R$id.et_amount
            android.view.View r9 = r8.findViewById(r9)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r9
            r8.o = r9
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "("
            r4.<init>(r5)
            k3.a r5 = k3.a.e
            java.lang.String r5 = r5.b()
            r4.append(r5)
            java.lang.String r5 = ")"
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            r9.setCurrency(r4)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o
            r9.requestFocus()
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o
            r9.setFocusableInTouchMode(r3)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o
            t4.e r4 = new t4.e
            r4.<init>()
            t4.a r5 = new t4.a
            r5.<init>()
            r6 = 4696837138094751744(0x412e847e00000000, double:999999.0)
            r5.a = r6
            android.text.InputFilter[] r6 = new android.text.InputFilter[r2]
            r6[r1] = r4
            r6[r3] = r5
            r9.setFilters(r6)
            android.widget.TextView r9 = r8.m
            D4.b r4 = new D4.b
            r4.<init>(r8, r0)
            r9.setOnClickListener(r4)
            android.widget.TextView r9 = r8.n
            Z7.a r4 = new Z7.a
            r4.<init>(r8, r2)
            r9.setOnClickListener(r4)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = r8.p
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r4 = r8.o
            r9.a(r8, r4, r3)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = r8.p
            D4.e r4 = new D4.e
            r4.<init>(r8, r2)
            r9.d = r4
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o
            com.huawei.module_checkout.p2ptransfer.activity.b r2 = new com.huawei.module_checkout.p2ptransfer.activity.b
            r2.<init>(r8)
            r9.addTextChangedListener(r2)
            android.widget.TextView r9 = r8.k
            boolean r2 = r8.showMsisdn
            if (r2 == 0) goto L_0x00c2
            java.lang.String r2 = r8.msisdn
            goto L_0x00ec
        L_0x00c2:
            java.lang.String r2 = r8.msisdn
            boolean r4 = android.text.TextUtils.isEmpty(r2)
            if (r4 != 0) goto L_0x00ea
            int r4 = r2.length()
            r5 = 3
            if (r4 >= r5) goto L_0x00d2
            goto L_0x00ea
        L_0x00d2:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r6 = "******"
            r4.<init>(r6)
            int r6 = r2.length()
            int r6 = r6 - r5
            java.lang.String r2 = r2.substring(r6)
            r4.append(r2)
            java.lang.String r2 = r4.toString()
            goto L_0x00ec
        L_0x00ea:
            java.lang.String r2 = ""
        L_0x00ec:
            r9.setText(r2)
            android.widget.TextView r9 = r8.l
            java.lang.String r2 = r8.publicName
            r9.setText(r2)
            com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel r9 = r8.i
            com.huawei.module_checkout.p2ptransfer.viewmodel.P2PTransferViewModel r9 = (com.huawei.module_checkout.p2ptransfer.viewmodel.P2PTransferViewModel) r9
            java.lang.String r2 = r8.notes
            androidx.lifecycle.MutableLiveData<java.lang.String> r9 = r9.w
            r9.setValue(r2)
            java.lang.String r9 = r8.amount
            boolean r9 = android.text.TextUtils.isEmpty(r9)
            if (r9 != 0) goto L_0x014c
            java.lang.String r9 = r8.amount     // Catch:{ Exception -> 0x014b }
            double r4 = java.lang.Double.parseDouble(r9)     // Catch:{ Exception -> 0x014b }
            java.util.Locale r9 = java.util.Locale.ENGLISH     // Catch:{ Exception -> 0x014b }
            java.lang.String r2 = "%.2f"
            java.lang.Double r4 = java.lang.Double.valueOf(r4)     // Catch:{ Exception -> 0x014b }
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x014b }
            r3[r1] = r4     // Catch:{ Exception -> 0x014b }
            java.lang.String r9 = java.lang.String.format(r9, r2, r3)     // Catch:{ Exception -> 0x014b }
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r2 = r8.o     // Catch:{ Exception -> 0x014b }
            r2.setText(r9)     // Catch:{ Exception -> 0x014b }
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r2 = r8.o     // Catch:{ Exception -> 0x014b }
            int r9 = r9.length()     // Catch:{ Exception -> 0x014b }
            r2.setSelection(r9)     // Catch:{ Exception -> 0x014b }
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o     // Catch:{ Exception -> 0x014b }
            r9.setEnabled(r1)     // Catch:{ Exception -> 0x014b }
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o     // Catch:{ Exception -> 0x014b }
            r9.setFocusable(r1)     // Catch:{ Exception -> 0x014b }
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o     // Catch:{ Exception -> 0x014b }
            r9.setFocusableInTouchMode(r1)     // Catch:{ Exception -> 0x014b }
            int r9 = com.huawei.module_checkout.R$id.et_amount_click_view     // Catch:{ Exception -> 0x014b }
            android.view.View r9 = r8.findViewById(r9)     // Catch:{ Exception -> 0x014b }
            V6.b r1 = new V6.b     // Catch:{ Exception -> 0x014b }
            r1.<init>(r8, r0)     // Catch:{ Exception -> 0x014b }
            r9.setOnClickListener(r1)     // Catch:{ Exception -> 0x014b }
            goto L_0x014c
        L_0x014b:
        L_0x014c:
            java.lang.String r9 = r8.avatar
            boolean r9 = android.text.TextUtils.isEmpty(r9)
            if (r9 != 0) goto L_0x0174
            com.huawei.digitalpayment.customer.httplib.pic.GlideRequests r9 = com.huawei.digitalpayment.customer.httplib.pic.GlideApp.with(r8)
            java.lang.String r0 = r8.avatar
            com.huawei.image.glide.Base64Mode r0 = com.huawei.image.glide.Base64Mode.getConsumerMode(r0)
            com.huawei.digitalpayment.customer.httplib.pic.GlideRequest r9 = r9.load(r0)
            int r0 = com.huawei.module_checkout.R$mipmap.icon_send_money_drawer_head
            com.huawei.digitalpayment.customer.httplib.pic.GlideRequest r9 = r9.placeholder(r0)
            int r0 = com.huawei.module_checkout.R$id.iv_head
            android.view.View r0 = r8.findViewById(r0)
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r9.into(r0)
            goto L_0x018a
        L_0x0174:
            com.huawei.image.glide.Base64Mode r9 = new com.huawei.image.glide.Base64Mode
            java.lang.String r0 = r8.chatAvatar
            java.lang.String r1 = "chat-avatar"
            r9.<init>(r0, r1)
            int r0 = com.huawei.module_checkout.R$id.iv_head
            android.view.View r0 = r8.findViewById(r0)
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            int r1 = com.huawei.module_checkout.R$mipmap.icon_send_money_drawer_head
            y5.b.a(r9, r0, r1, r1)
        L_0x018a:
            r8.T0()
            java.lang.String r9 = r8.title
            boolean r9 = android.text.TextUtils.isEmpty(r9)
            if (r9 == 0) goto L_0x019f
            int r9 = com.huawei.module_checkout.R$string.designstandard_send_money
            java.lang.String r9 = r8.getString(r9)
            r8.N0(r9)
            goto L_0x01a4
        L_0x019f:
            java.lang.String r9 = r8.title
            r8.N0(r9)
        L_0x01a4:
            int r9 = com.huawei.module_checkout.R$color.color_F4F4F4
            int r0 = androidx.core.content.ContextCompat.getColor(r8, r9)
            r8.Q0(r0)
            r8.S0(r9)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r9 = r8.o
            D2.c.a(r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity.onCreate(android.os.Bundle):void");
    }

    public final void onDestroy() {
        x7.a.g.a = null;
        this.p.dismiss();
        P2PTransferPayActivity.super.onDestroy();
    }

    public final void onResume() {
        P2PTransferPayActivity.super.onResume();
        w7.d dVar = w7.d.b;
        if (dVar.a && this.q) {
            this.q = false;
            dVar.a = false;
            P2PTransferViewModel p2PTransferViewModel = this.i;
            p2PTransferViewModel.getClass();
            HashMap hashMap = new HashMap();
            hashMap.put("prepayId", p2PTransferViewModel.s);
            hashMap.put("tradeType", p2PTransferViewModel.u);
            z7.c cVar = p2PTransferViewModel.v;
            cVar.getClass();
            p2PTransferViewModel.b(new z7.a(cVar, hashMap).a, new A7.a(p2PTransferViewModel));
        }
    }
}
