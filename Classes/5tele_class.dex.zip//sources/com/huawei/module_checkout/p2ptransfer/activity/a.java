package com.huawei.module_checkout.p2ptransfer.activity;

import V1.h;
import android.view.View;
import com.huawei.digitalpayment.customer.cache.BasicConfig;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ int a;

    public /* synthetic */ a(int i) {
        this.a = i;
    }

    public final void onClick(View view) {
        switch (this.a) {
            case 0:
                int i = P2PTransferPayActivity.r;
                BasicConfig.getInstance().getReferenceDataValueByKey("cashInUrl", "easier://app/pages/wallet/cashIn/cashIn");
                return;
            default:
                h.b();
                return;
        }
    }
}
