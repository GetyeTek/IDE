package com.huawei.module_checkout.p2ptransfer.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.baselib.mvvm.data.Status;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.digitalpayment.customer.httplib.response.RecentTransfersResp;
import com.huawei.digitalpayment.customer.httplib.response.VerifyNumberResp;
import java.util.List;
import z7.f;

public class SendMoneyInputPhoneViewModel extends BaseViewModel {
    public final MutableLiveData<RecentTransfersResp> g = new MutableLiveData<>();
    public final MutableLiveData<Status> h = new MutableLiveData<>();
    public final MutableLiveData<c<List<HomeBannerBean>>> i = new MutableLiveData<>();
    public final MutableLiveData<VerifyNumberResp> j = new MutableLiveData<>();
    public final f k = new f();
    public BannerRepository l;

    public final void onCleared() {
        SendMoneyInputPhoneViewModel.super.onCleared();
        BannerRepository bannerRepository = this.l;
        if (bannerRepository != null) {
            bannerRepository.cancel();
        }
    }
}
