package com.huawei.module_checkout.p2ptransfer.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class P2PTransferPayActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        String str9;
        String str10;
        String str11;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (P2PTransferPayActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.title;
        } else {
            str = r4.getIntent().getExtras().getString("title", r4.title);
        }
        r4.title = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.msisdn;
        } else {
            str2 = r4.getIntent().getExtras().getString("msisdn", r4.msisdn);
        }
        r4.msisdn = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.publicName;
        } else {
            str3 = r4.getIntent().getExtras().getString("publicName", r4.publicName);
        }
        r4.publicName = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.amount;
        } else {
            str4 = r4.getIntent().getExtras().getString("amount", r4.amount);
        }
        r4.amount = str4;
        if (r4.getIntent().getExtras() == null) {
            str5 = r4.notes;
        } else {
            str5 = r4.getIntent().getExtras().getString("notes", r4.notes);
        }
        r4.notes = str5;
        if (r4.getIntent().getExtras() == null) {
            str6 = r4.operationNumber;
        } else {
            str6 = r4.getIntent().getExtras().getString("operationNumber", r4.operationNumber);
        }
        r4.operationNumber = str6;
        r4.showMsisdn = r4.getIntent().getBooleanExtra("showMsisdn", r4.showMsisdn);
        if (r4.getIntent().getExtras() == null) {
            str7 = r4.transactionTo;
        } else {
            str7 = r4.getIntent().getExtras().getString("transactionTo", r4.transactionTo);
        }
        r4.transactionTo = str7;
        if (r4.getIntent().getExtras() == null) {
            str8 = r4.tradeType;
        } else {
            str8 = r4.getIntent().getExtras().getString("tradeType", r4.tradeType);
        }
        r4.tradeType = str8;
        if (r4.getIntent().getExtras() == null) {
            str9 = r4.customerType;
        } else {
            str9 = r4.getIntent().getExtras().getString("customerType", r4.customerType);
        }
        r4.customerType = str9;
        if (r4.getIntent().getExtras() == null) {
            str10 = r4.avatar;
        } else {
            str10 = r4.getIntent().getExtras().getString("avatar", r4.avatar);
        }
        r4.avatar = str10;
        if (r4.getIntent().getExtras() == null) {
            str11 = r4.chatAvatar;
        } else {
            str11 = r4.getIntent().getExtras().getString("chatAvatar", r4.chatAvatar);
        }
        r4.chatAvatar = str11;
    }
}
