package com.huawei.module_checkout.p2ptransfer.adapter;

import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.pic.GlideApp;
import com.huawei.digitalpayment.customer.httplib.response.RecentTransfersResp;
import com.huawei.image.glide.Base64Mode;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$mipmap;

public class RecentTransferInfoAdapter extends BaseQuickAdapter<RecentTransfersResp.RecentTransferInfo, BaseViewHolder> {
    public RecentTransferInfoAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        RecentTransfersResp.RecentTransferInfo recentTransferInfo = (RecentTransfersResp.RecentTransferInfo) obj;
        baseViewHolder.setText(R$id.tv_name, recentTransferInfo.getName());
        ImageView imageView = (ImageView) baseViewHolder.getView(R$id.iv_head);
        GlideApp.with(imageView).load(Base64Mode.getConsumerMode(recentTransferInfo.getAvatar())).placeholder(R$mipmap.icon_send_money_drawer_head).into(imageView);
    }
}
