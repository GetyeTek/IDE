package com.huawei.module_checkout.p2ptransfer.activity;

import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;

public final /* synthetic */ class f implements InputFilter {
    public final CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        int i5 = SendMoneyInputPhoneActivity.p;
        if (charSequence.length() <= 9 || TextUtils.isEmpty(charSequence.toString())) {
            return charSequence;
        }
        return charSequence.toString().substring(charSequence.length() - 9, charSequence.length());
    }
}
