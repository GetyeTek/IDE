package com.huawei.module_checkout.p2ptransfer.dialog;

import H1.c;
import R1.a;
import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import com.huawei.module_checkout.R$style;
import com.huawei.module_checkout.databinding.DialogAddNoteBinding;

public class AddNoteDialog extends DialogFragment {
    public final String a;
    public final a<String> b;
    public DialogAddNoteBinding c;
    public int d;

    public AddNoteDialog(String str, a<String> aVar, int i) {
        this.a = str;
        this.b = aVar;
        this.d = i;
    }

    public final void onAttach(@NonNull Context context) {
        AddNoteDialog.super.onAttach(context);
        FragmentActivity fragmentActivity = (FragmentActivity) context;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0012, code lost:
        r8 = com.huawei.module_checkout.R$id.btn_sure;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0027, code lost:
        r8 = com.huawei.module_checkout.R$id.phone_number_input;
     */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r7, @androidx.annotation.Nullable android.view.ViewGroup r8, @androidx.annotation.Nullable android.os.Bundle r9) {
        /*
            r6 = this;
            int r9 = com.huawei.module_checkout.R$layout.dialog_add_note
            r0 = 0
            android.view.View r7 = r7.inflate(r9, r8, r0)
            int r8 = com.huawei.module_checkout.R$id.btn_cancel
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r2 = r9
            com.huawei.common.widget.round.RoundTextView r2 = (com.huawei.common.widget.round.RoundTextView) r2
            if (r2 == 0) goto L_0x0049
            int r8 = com.huawei.module_checkout.R$id.btn_sure
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r3 = r9
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            if (r3 == 0) goto L_0x0049
            int r8 = com.huawei.module_checkout.R$id.line
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            com.huawei.common.widget.round.RoundTextView r9 = (com.huawei.common.widget.round.RoundTextView) r9
            if (r9 == 0) goto L_0x0049
            int r8 = com.huawei.module_checkout.R$id.phone_number_input
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r4 = r9
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r4 = (com.huawei.digitalpayment.customer.viewlib.view.TypeEditText) r4
            if (r4 == 0) goto L_0x0049
            int r8 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r7, r8)
            r5 = r9
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x0049
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r8 = new com.huawei.module_checkout.databinding.DialogAddNoteBinding
            com.huawei.common.widget.round.RoundConstraintLayout r7 = (com.huawei.common.widget.round.RoundConstraintLayout) r7
            r0 = r8
            r1 = r7
            r0.<init>(r1, r2, r3, r4, r5)
            r6.c = r8
            return r7
        L_0x0049:
            android.content.res.Resources r7 = r7.getResources()
            java.lang.String r7 = r7.getResourceName(r8)
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            java.lang.String r9 = "Missing required view with ID: "
            java.lang.String r7 = r9.concat(r7)
            r8.<init>(r7)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.p2ptransfer.dialog.AddNoteDialog.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onStart() {
        Window window;
        AddNoteDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            window.setBackgroundDrawableResource(17170445);
            c.b(window, R$style.BottomAnimation, dialog, true, true);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onViewCreated(@androidx.annotation.NonNull android.view.View r5, @androidx.annotation.Nullable android.os.Bundle r6) {
        /*
            r4 = this;
            com.huawei.module_checkout.p2ptransfer.dialog.AddNoteDialog.super.onViewCreated(r5, r6)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            android.widget.TextView r5 = r5.e
            int r6 = com.huawei.module_checkout.R$string.checkout_add_notes
            r5.setText(r6)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            r6 = 0
            r5.setError(r6)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r5 = r5.a
            com.huawei.common.widget.round.RoundLinearLayout r5 = r5.d
            r6 = -1
            r5.setBackgroundColor(r6)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r5 = r5.a
            android.widget.EditText r5 = r5.b
            r6 = 1
            r5.setInputType(r6)
            int r5 = r4.d
            if (r5 > 0) goto L_0x0034
            r5 = 50
            r4.d = r5
        L_0x0034:
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r5 = r5.a
            android.widget.EditText r5 = r5.b
            android.text.InputFilter$LengthFilter r0 = new android.text.InputFilter$LengthFilter
            int r1 = r4.d
            r0.<init>(r1)
            t4.h r1 = new t4.h
            r1.<init>()
            r2 = 2
            android.text.InputFilter[] r2 = new android.text.InputFilter[r2]
            r3 = 0
            r2[r3] = r0
            r2[r6] = r1
            r5.setFilters(r2)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r5 = r5.a
            android.widget.EditText r5 = r5.b
            r5.requestFocus()
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r5 = r5.a
            android.widget.EditText r5 = r5.b
            r5.setFocusableInTouchMode(r6)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.common.widget.round.RoundTextView r5 = r5.b
            N0.E r6 = new N0.E
            r0 = 6
            r6.<init>(r4, r0)
            r5.setOnClickListener(r6)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r5 = r5.a
            android.widget.EditText r5 = r5.b
            java.lang.String r6 = r4.a
            r5.setText(r6)
            if (r6 == 0) goto L_0x0098
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r5 = r5.a
            android.widget.EditText r5 = r5.b
            android.text.Editable r6 = r5.getText()
            int r6 = r6.length()
            r5.setSelection(r6)
        L_0x0098:
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.common.widget.round.RoundTextView r5 = r5.c
            N0.F r6 = new N0.F
            r0 = 15
            r6.<init>(r4, r0)
            r5.setOnClickListener(r6)
            com.huawei.module_checkout.databinding.DialogAddNoteBinding r5 = r4.c
            com.huawei.digitalpayment.customer.viewlib.view.TypeEditText r5 = r5.d
            androidx.camera.camera2.internal.D1 r6 = new androidx.camera.camera2.internal.D1
            r0 = 4
            r6.<init>(r4, r0)
            r5.post(r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.p2ptransfer.dialog.AddNoteDialog.onViewCreated(android.view.View, android.os.Bundle):void");
    }
}
