package com.huawei.module_checkout.p2ptransfer.activity;

import V7.c;
import androidx.lifecycle.Observer;
import java.util.List;

public final /* synthetic */ class e implements Observer {
    public final /* synthetic */ SendMoneyInputPhoneActivity a;

    public /* synthetic */ e(SendMoneyInputPhoneActivity sendMoneyInputPhoneActivity) {
        this.a = sendMoneyInputPhoneActivity;
    }

    /* JADX WARNING: type inference failed for: r1v4, types: [java.lang.Object, com.huawei.common.widget.banner.CycleViewPager$c] */
    public final void onChanged(Object obj) {
        List list;
        c cVar = (c) obj;
        int i = SendMoneyInputPhoneActivity.p;
        SendMoneyInputPhoneActivity sendMoneyInputPhoneActivity = this.a;
        sendMoneyInputPhoneActivity.getClass();
        if (cVar.f() && (list = (List) cVar.c) != null && !list.isEmpty()) {
            sendMoneyInputPhoneActivity.k.c.setVisibility(0);
            sendMoneyInputPhoneActivity.k.c.c(list, new Object(), 0);
        }
    }
}
