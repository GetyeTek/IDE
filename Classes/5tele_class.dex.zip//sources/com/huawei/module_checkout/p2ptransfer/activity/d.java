package com.huawei.module_checkout.p2ptransfer.activity;

import R1.a;
import com.huawei.common.exception.BaseException;

public final class d implements a<Boolean> {
    public final /* synthetic */ P2PTransferPayActivity a;

    public d(P2PTransferPayActivity p2PTransferPayActivity) {
        this.a = p2PTransferPayActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        this.a.a1();
    }
}
