package com.huawei.module_checkout.checkstand.common;

import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.http.b;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import java.util.HashMap;

public class CommonCheckoutRepository extends b<CheckoutResp, CheckoutResp> {
    public final PaySceneEnum a;

    public CommonCheckoutRepository(PaySceneEnum paySceneEnum, HashMap hashMap) {
        addParams(hashMap);
        this.a = paySceneEnum;
    }

    public final String getApiPath() {
        return this.a.getCheckoutPath();
    }
}
