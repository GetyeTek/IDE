package com.huawei.module_checkout.checkstand.fragment;

import B7.b;
import B7.c;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.module_checkout.databinding.FragmentPayDiscountBinding;
import com.huawei.module_checkout.inapp.adapter.PaymentDiscountTypeSelectAdapter;
import l7.e;
import l7.f;

public class DiscountTypeFragment extends BaseCheckStandFragment {
    public FragmentPayDiscountBinding c;
    public PaymentDiscountTypeSelectAdapter d;
    public CouponBean e;
    public boolean f;

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0011, code lost:
        r5 = com.huawei.module_checkout.R$id.lb_next;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x001b, code lost:
        r5 = com.huawei.module_checkout.R$id.rv_list;
     */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r4, @androidx.annotation.Nullable android.view.ViewGroup r5, @androidx.annotation.Nullable android.os.Bundle r6) {
        /*
            r3 = this;
            int r6 = com.huawei.module_checkout.R$layout.fragment_pay_discount
            r0 = 0
            android.view.View r4 = r4.inflate(r6, r5, r0)
            int r5 = com.huawei.module_checkout.R$id.iv_back
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x0039
            int r5 = com.huawei.module_checkout.R$id.lb_next
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r0 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r0
            if (r0 == 0) goto L_0x0039
            int r5 = com.huawei.module_checkout.R$id.rv_list
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            androidx.recyclerview.widget.RecyclerView r1 = (androidx.recyclerview.widget.RecyclerView) r1
            if (r1 == 0) goto L_0x0039
            int r5 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0039
            com.huawei.module_checkout.databinding.FragmentPayDiscountBinding r5 = new com.huawei.module_checkout.databinding.FragmentPayDiscountBinding
            com.huawei.common.widget.round.RoundConstraintLayout r4 = (com.huawei.common.widget.round.RoundConstraintLayout) r4
            r5.<init>(r4, r6, r0, r1)
            r3.c = r5
            return r4
        L_0x0039:
            android.content.res.Resources r4 = r4.getResources()
            java.lang.String r4 = r4.getResourceName(r5)
            java.lang.NullPointerException r5 = new java.lang.NullPointerException
            java.lang.String r6 = "Missing required view with ID: "
            java.lang.String r4 = r6.concat(r4)
            r5.<init>(r4)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.checkstand.fragment.DiscountTypeFragment.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.c.b.setOnClickListener(new b(this, 3));
        this.c.c.setOnClickListener(new c(this, 7));
    }

    public final void v0() {
        super.v0();
        this.a.j.observe(getViewLifecycleOwner(), new e(this));
        this.a.o.observe(getViewLifecycleOwner(), new f(this));
    }
}
