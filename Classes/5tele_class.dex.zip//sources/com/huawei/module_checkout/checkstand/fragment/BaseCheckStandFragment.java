package com.huawei.module_checkout.checkstand.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;

public class BaseCheckStandFragment extends Fragment {
    public CheckStandViewModel a;
    public CheckStandActivity b;

    public final void onAttach(@NonNull Context context) {
        BaseCheckStandFragment.super.onAttach(context);
        this.b = (CheckStandActivity) context;
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        BaseCheckStandFragment.super.onViewCreated(view, bundle);
        v0();
    }

    public void v0() {
        this.a = this.b.b;
    }
}
