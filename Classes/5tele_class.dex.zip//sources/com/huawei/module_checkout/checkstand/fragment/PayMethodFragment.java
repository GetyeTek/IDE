package com.huawei.module_checkout.checkstand.fragment;

import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import b4.i;
import c6.o;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.databinding.FragmentInAppPayMethodBinding;
import com.huawei.module_checkout.inapp.adapter.PaymentMethodSelectAdapter;
import l7.g;

public class PayMethodFragment extends BaseCheckStandFragment {
    public FragmentInAppPayMethodBinding c;
    public PaymentMethodSelectAdapter d;
    public boolean e;

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0011, code lost:
        r5 = com.huawei.module_checkout.R$id.lb_next;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x001b, code lost:
        r5 = com.huawei.module_checkout.R$id.rv_list;
     */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r4, @androidx.annotation.Nullable android.view.ViewGroup r5, @androidx.annotation.Nullable android.os.Bundle r6) {
        /*
            r3 = this;
            int r6 = com.huawei.module_checkout.R$layout.fragment_in_app_pay_method
            r0 = 0
            android.view.View r4 = r4.inflate(r6, r5, r0)
            int r5 = com.huawei.module_checkout.R$id.iv_back
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x0039
            int r5 = com.huawei.module_checkout.R$id.lb_next
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r0 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r0
            if (r0 == 0) goto L_0x0039
            int r5 = com.huawei.module_checkout.R$id.rv_list
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            androidx.recyclerview.widget.RecyclerView r1 = (androidx.recyclerview.widget.RecyclerView) r1
            if (r1 == 0) goto L_0x0039
            int r5 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r4, r5)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0039
            com.huawei.module_checkout.databinding.FragmentInAppPayMethodBinding r5 = new com.huawei.module_checkout.databinding.FragmentInAppPayMethodBinding
            com.huawei.common.widget.round.RoundConstraintLayout r4 = (com.huawei.common.widget.round.RoundConstraintLayout) r4
            r5.<init>(r4, r6, r0, r1)
            r3.c = r5
            return r4
        L_0x0039:
            android.content.res.Resources r4 = r4.getResources()
            java.lang.String r4 = r4.getResourceName(r5)
            java.lang.NullPointerException r5 = new java.lang.NullPointerException
            java.lang.String r6 = "Missing required view with ID: "
            java.lang.String r4 = r6.concat(r4)
            r5.<init>(r4)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.checkstand.fragment.PayMethodFragment.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.c.b.setOnClickListener(new i(this, 5));
        this.c.c.setOnClickListener(new o(this, 5));
    }

    public final void v0() {
        super.v0();
        this.a.m.observe(getViewLifecycleOwner(), new g(this));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_in_app_select, ((CheckoutResp) this.a.j.getValue()).getFundsSourceInfoDisplay());
        baseQuickAdapter.a = (FundsSourceInfoDisplay) this.a.k.getValue();
        this.d = baseQuickAdapter;
        this.c.d.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(requireContext(), R$color.colorDividerDark), 1));
        this.c.d.setAdapter(this.d);
    }
}
