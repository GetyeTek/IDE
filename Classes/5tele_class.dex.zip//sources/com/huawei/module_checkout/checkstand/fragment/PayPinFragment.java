package com.huawei.module_checkout.checkstand.fragment;

import D4.b;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.d;
import com.huawei.module_checkout.databinding.FragmentPayPinBinding;
import l7.h;

public class PayPinFragment extends BaseCheckStandFragment {
    public FragmentPayPinBinding c;
    public boolean d;

    public final void onCreate(@Nullable Bundle bundle) {
        requireActivity().getWindow().addFlags(8192);
        PayPinFragment.super.onCreate(bundle);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0040, code lost:
        r10 = com.huawei.module_checkout.R$id.virtualKeyboardView;
     */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r8, @androidx.annotation.Nullable android.view.ViewGroup r9, @androidx.annotation.Nullable android.os.Bundle r10) {
        /*
            r7 = this;
            int r10 = com.huawei.module_checkout.R$layout.fragment_pay_pin
            r0 = 0
            android.view.View r8 = r8.inflate(r10, r9, r0)
            r9 = r8
            androidx.constraintlayout.widget.ConstraintLayout r9 = (androidx.constraintlayout.widget.ConstraintLayout) r9
            int r10 = com.huawei.module_checkout.R$id.edit_pin
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r10)
            r2 = r0
            com.huawei.module_checkout.view.CheckOutPinEditText r2 = (com.huawei.module_checkout.view.CheckOutPinEditText) r2
            if (r2 == 0) goto L_0x0055
            int r10 = com.huawei.module_checkout.R$id.iv_close
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r10)
            r3 = r0
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0055
            int r10 = com.huawei.module_checkout.R$id.tv_amount
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r10)
            r4 = r0
            android.widget.TextView r4 = (android.widget.TextView) r4
            if (r4 == 0) goto L_0x0055
            int r10 = com.huawei.module_checkout.R$id.tv_currency
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r10)
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x0055
            int r10 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r10)
            android.widget.TextView r0 = (android.widget.TextView) r0
            if (r0 == 0) goto L_0x0055
            int r10 = com.huawei.module_checkout.R$id.virtualKeyboardView
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r10)
            r6 = r0
            com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView r6 = (com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView) r6
            if (r6 == 0) goto L_0x0055
            com.huawei.module_checkout.databinding.FragmentPayPinBinding r8 = new com.huawei.module_checkout.databinding.FragmentPayPinBinding
            r0 = r8
            r1 = r9
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.c = r8
            return r9
        L_0x0055:
            android.content.res.Resources r8 = r8.getResources()
            java.lang.String r8 = r8.getResourceName(r10)
            java.lang.NullPointerException r9 = new java.lang.NullPointerException
            java.lang.String r10 = "Missing required view with ID: "
            java.lang.String r8 = r10.concat(r8)
            r9.<init>(r8)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.checkstand.fragment.PayPinFragment.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onDestroy() {
        requireActivity().getWindow().clearFlags(8192);
        PayPinFragment.super.onDestroy();
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.TextView] */
    public final void onPause() {
        PayPinFragment.super.onPause();
        this.c.b.setText("");
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [com.huawei.module_checkout.view.CheckOutPinEditText, android.widget.EditText] */
    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.c.b.setMaxCount(6);
        this.c.b.setOnCompleteListener(new d(this));
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.d = arguments.getBoolean("showPopDialog", false);
        }
        this.c.c.setOnClickListener(new b(this, 6));
        this.c.f.a(requireActivity(), this.c.b);
    }

    public final void v0() {
        super.v0();
        this.a.j.observe(getViewLifecycleOwner(), new h(this));
    }
}
