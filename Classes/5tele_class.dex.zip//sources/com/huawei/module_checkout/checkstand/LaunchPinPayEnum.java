package com.huawei.module_checkout.checkstand;

import java.io.Serializable;

public enum LaunchPinPayEnum implements Serializable {
    FINANCE_REPAYMENT("v1/ethiopia/repayment", "");
    
    private String reportTag;
    private final String transferPath;

    private LaunchPinPayEnum(String str) {
        this(r2, r3, str, "");
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public String getTransferPath() {
        return this.transferPath;
    }

    private LaunchPinPayEnum(String str, String str2) {
        this.transferPath = str;
        this.reportTag = str2;
    }
}
