package com.huawei.module_checkout.checkstand.common;

import S2.b;
import Y4.h;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import java.util.HashMap;
import java.util.Map;
import k7.C0018a;

@Route(path = "/checkoutModule/commonCheckOut")
public class CommonCheckStandActivity extends CheckStandActivity<CommonCheckStandViewModel> {
    public static final /* synthetic */ int k = 0;
    public Map<String, Object> g;
    public CheckoutResp h;
    public CommonCheckStandViewModel i;
    public boolean j;

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.module_checkout.checkstand.common.CommonCheckStandActivity, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.g = (Map) getIntent().getSerializableExtra("params");
        getIntent().getBooleanExtra("isSupportOd", true);
        String stringExtra = getIntent().getStringExtra("buttonText");
        if (TextUtils.isEmpty(stringExtra)) {
            stringExtra = getString(R$string.pay);
        }
        if (this.g == null) {
            this.g = new HashMap();
        }
        this.h = getIntent().getSerializableExtra("checkoutResp");
        CommonCheckStandViewModel commonCheckStandViewModel = (CommonCheckStandViewModel) this.b;
        this.i = commonCheckStandViewModel;
        commonCheckStandViewModel.getClass();
        CommonCheckStandViewModel commonCheckStandViewModel2 = this.i;
        commonCheckStandViewModel2.h = stringExtra;
        HashMap hashMap = new HashMap(this.g);
        commonCheckStandViewModel2.i = hashMap;
        if (hashMap.containsKey("extraPayParams")) {
            commonCheckStandViewModel2.x = (Map) commonCheckStandViewModel2.i.remove("extraPayParams");
        } else {
            HashMap hashMap2 = commonCheckStandViewModel2.i;
            if (hashMap2 == null || !hashMap2.containsKey("thirdParty")) {
                HashMap hashMap3 = commonCheckStandViewModel2.i;
                if (hashMap3 == null || !hashMap3.containsKey("billShare")) {
                    HashMap hashMap4 = commonCheckStandViewModel2.i;
                    if (hashMap4 != null && hashMap4.containsKey("fuelPayment")) {
                        HashMap hashMap5 = new HashMap();
                        commonCheckStandViewModel2.x = hashMap5;
                        hashMap5.put("businessType", commonCheckStandViewModel2.i.get("businessType"));
                    } else if (commonCheckStandViewModel2.i != null && PaySceneEnum.REQUEST_MONEY == commonCheckStandViewModel2.g) {
                        commonCheckStandViewModel2.x = new HashMap();
                        if (!TextUtils.isEmpty((String) commonCheckStandViewModel2.i.get("requestMoneyOrderId"))) {
                            commonCheckStandViewModel2.x.put("requestMoneyOrderId", commonCheckStandViewModel2.i.get("requestMoneyOrderId"));
                        }
                        String str = (String) commonCheckStandViewModel2.i.get("paymentMethod");
                        if (!TextUtils.isEmpty(str) && TextUtils.equals(str, "QRCode")) {
                            commonCheckStandViewModel2.x.put("paymentMethod", "QRCode");
                        }
                    }
                } else {
                    HashMap hashMap6 = new HashMap();
                    commonCheckStandViewModel2.x = hashMap6;
                    hashMap6.put("recordId", commonCheckStandViewModel2.i.get("recordId"));
                }
            } else {
                HashMap hashMap7 = new HashMap();
                commonCheckStandViewModel2.x = hashMap7;
                hashMap7.put("thirdParty", commonCheckStandViewModel2.i.get("thirdParty"));
                commonCheckStandViewModel2.x.put("receiverShortCode", commonCheckStandViewModel2.i.get("receiverShortCode"));
                commonCheckStandViewModel2.x.put("transactionID", commonCheckStandViewModel2.i.get("transactionID"));
            }
        }
        this.i.v.observe(this, new h(this, 2));
        CheckoutResp checkoutResp = this.h;
        if (checkoutResp != null) {
            H0(checkoutResp);
            return;
        }
        this.j = true;
        CommonCheckStandViewModel commonCheckStandViewModel3 = this.i;
        PaySceneEnum paySceneEnum = this.e;
        commonCheckStandViewModel3.v.setValue(b.c((Object) null));
        new CommonCheckoutRepository(paySceneEnum, commonCheckStandViewModel3.i).sendRequest(new C0018a(commonCheckStandViewModel3));
    }
}
