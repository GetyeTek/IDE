package com.huawei.module_checkout.checkstand.common;

import S2.b;
import android.text.TextUtils;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import o7.c;

public class CommonCheckStandViewModel extends CheckStandViewModel {
    public final c u = new c();
    public final MutableLiveData<b<CheckoutResp>> v = new MutableLiveData<>();
    public final MutableLiveData<b<TransferResp>> w = new MutableLiveData<>();
    public Map<String, Object> x;

    public class a implements R1.a<TransferResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            CommonCheckStandViewModel.this.w.setValue(b.a(baseException, (Object) null));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            CommonCheckStandViewModel.this.w.setValue(b.e((TransferResp) obj));
        }
    }

    public final void d(String str) {
        this.x.put("couponId", str);
    }

    public final LiveData<b<CheckoutResp>> f(CouponBean couponBean) {
        return m(couponBean, (FundsSourceInfoDisplay) this.k.getValue());
    }

    public final LiveData<b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        return m((CouponBean) this.l.getValue(), fundsSourceInfoDisplay);
    }

    public final LiveData<b<TransferResp>> i(String str) {
        MutableLiveData<b<TransferResp>> mutableLiveData = this.w;
        mutableLiveData.setValue(b.c((Object) null));
        new CommonPayOrderRepository(this.g, str, this.s, this.x, this.t).sendRequest(new a());
        return mutableLiveData;
    }

    public final MediatorLiveData m(CouponBean couponBean, FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        HashMap hashMap = new HashMap();
        hashMap.put("tradeType", this.i.get("tradeType"));
        hashMap.put("prepayId", this.s);
        if (fundsSourceInfoDisplay != null) {
            hashMap.put("accountType", fundsSourceInfoDisplay.getAccountType());
            hashMap.put("fundsSource", fundsSourceInfoDisplay.getFundsSource());
        }
        hashMap.remove("coupons");
        if (couponBean != null && !TextUtils.isEmpty(couponBean.getCouponId())) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(couponBean.getCouponId());
            hashMap.put("coupons", arrayList);
        }
        if (this.i.containsKey("fuelPayment") && this.i.containsKey("merchCode") && this.i.containsKey("appId")) {
            hashMap.put("merchCode", this.i.get("merchCode"));
            hashMap.put("appId", this.i.get("appId"));
        }
        c cVar = this.u;
        cVar.getClass();
        return new o7.b(cVar, hashMap).a;
    }
}
