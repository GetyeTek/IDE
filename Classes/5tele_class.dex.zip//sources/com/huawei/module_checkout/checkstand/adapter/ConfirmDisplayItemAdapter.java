package com.huawei.module_checkout.checkstand.adapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;
import java.util.List;

public class ConfirmDisplayItemAdapter extends BaseQuickAdapter<FundsSourceInfoDisplay.DisplayItemsBean, BaseViewHolder> {
    public ConfirmDisplayItemAdapter(@Nullable List<FundsSourceInfoDisplay.DisplayItemsBean> list) {
        super(R$layout.item_confirm_display, list);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        FundsSourceInfoDisplay.DisplayItemsBean displayItemsBean = (FundsSourceInfoDisplay.DisplayItemsBean) obj;
        baseViewHolder.setText(R$id.tv_title, displayItemsBean.getLabel());
        baseViewHolder.setText(R$id.tv_content, displayItemsBean.getValue());
    }
}
