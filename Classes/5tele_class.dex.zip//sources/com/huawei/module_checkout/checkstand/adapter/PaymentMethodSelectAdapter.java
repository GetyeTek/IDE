package com.huawei.module_checkout.checkstand.adapter;

import O9.c;
import android.text.Html;
import android.text.TextUtils;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.module_checkout.R$id;
import java.util.ArrayList;
import java.util.List;

public class PaymentMethodSelectAdapter extends BaseQuickAdapter<FundsSourceInfoDisplay, BaseViewHolder> {
    public FundsSourceInfoDisplay a;

    public PaymentMethodSelectAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        FundsSourceInfoDisplay fundsSourceInfoDisplay = (FundsSourceInfoDisplay) obj;
        baseViewHolder.setText(R$id.tv_title, fundsSourceInfoDisplay.getFundsSourceDisplay());
        String displayContent = fundsSourceInfoDisplay.getDisplayContent();
        if (!TextUtils.isEmpty(displayContent)) {
            baseViewHolder.setText(R$id.tv_subtitle, Html.fromHtml(displayContent));
        } else {
            baseViewHolder.setText(R$id.tv_subtitle, "");
        }
        baseViewHolder.setVisible(R$id.iv_selected, fundsSourceInfoDisplay.equals(this.a));
        c.c((ImageView) baseViewHolder.getView(R$id.iv_icon), fundsSourceInfoDisplay.getIcon(), -1);
        if (fundsSourceInfoDisplay.isAvailable() || fundsSourceInfoDisplay.isDefaultAccount()) {
            baseViewHolder.itemView.setClickable(true);
            baseViewHolder.itemView.setAlpha(1.0f);
            return;
        }
        baseViewHolder.itemView.setClickable(false);
        baseViewHolder.itemView.setAlpha(0.4f);
    }

    public final void e(@Nullable List<FundsSourceInfoDisplay> list, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (list != null && !list.isEmpty()) {
            for (FundsSourceInfoDisplay next : list) {
                if (!next.isOdCombinedFundsSource() && (!next.isOd() || z)) {
                    arrayList.add(next);
                }
            }
        }
        PaymentMethodSelectAdapter.super.setNewData(arrayList);
    }

    public final void f(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        this.a = fundsSourceInfoDisplay;
        notifyDataSetChanged();
    }
}
