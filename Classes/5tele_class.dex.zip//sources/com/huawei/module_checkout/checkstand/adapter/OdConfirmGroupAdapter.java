package com.huawei.module_checkout.checkstand.adapter;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.digitalpayment.customer.httplib.response.ODDisplayGroupResp;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.databinding.ItemOdDisplayGroupBinding;

public class OdConfirmGroupAdapter extends BaseQuickAdapter<ODDisplayGroupResp, BaseViewHolder> {
    public OdConfirmGroupAdapter() {
        super(R$layout.item_od_display_group);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        ItemOdDisplayGroupBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        bind.a.setNestedScrollingEnabled(false);
        bind.a.setAdapter(new ConfirmDisplayItemAdapter(((ODDisplayGroupResp) obj).getList()));
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return OdConfirmGroupAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
