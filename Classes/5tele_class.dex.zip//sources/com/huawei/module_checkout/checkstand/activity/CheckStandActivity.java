package com.huawei.module_checkout.checkstand.activity;

import S5.r;
import V1.h;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.FragmentContainerView;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.viewbinding.ViewBindings;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.f;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import com.huawei.module_checkout.databinding.ActivityCheckStandBinding;
import i7.C0013a;
import j7.C0015b;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public abstract class CheckStandActivity<VM extends CheckStandViewModel> extends AppCompatActivity {
    public static final /* synthetic */ int f = 0;
    public NavController a;
    public VM b;
    public ActivityResultLauncher<Intent> c;
    public ActivityCheckStandBinding d;
    public PaySceneEnum e;

    public class a implements Observer<Boolean> {
        public a() {
        }

        public final void onChanged(Object obj) {
            boolean booleanValue = ((Boolean) obj).booleanValue();
            CheckStandActivity checkStandActivity = CheckStandActivity.this;
            if (booleanValue) {
                DialogManager.c(checkStandActivity);
            } else {
                DialogManager.a(checkStandActivity);
            }
        }
    }

    public class b implements ActivityResultCallback<ActivityResult> {
        public b() {
        }

        public final void onActivityResult(Object obj) {
            ActivityResult activityResult = (ActivityResult) obj;
            CheckStandActivity checkStandActivity = CheckStandActivity.this;
            checkStandActivity.a.popBackStack(R$id.emptyFragment, false);
            Intent data = activityResult.getData();
            if (data == null || activityResult.getResultCode() != -1) {
                checkStandActivity.F0((TransferResp) checkStandActivity.b.p.getValue());
                return;
            }
            try {
                CheckStandActivity.C0(checkStandActivity, new String(data.getByteArrayExtra("pin"), "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.getMessage();
                h.b();
            }
        }
    }

    public class c extends AnimatorListenerAdapter {
        public final /* synthetic */ TransferResp a;

        public c(TransferResp transferResp) {
            this.a = transferResp;
        }

        public final void onAnimationEnd(Animator animator) {
            super.onAnimationEnd(animator);
            A.h(new r(this, this.a, 2), 0);
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.module_checkout.checkstand.activity.CheckStandActivity, androidx.fragment.app.FragmentActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void C0(com.huawei.module_checkout.checkstand.activity.CheckStandActivity r3, java.lang.String r4) {
        /*
            java.lang.String r0 = "FingerprintPay"
            r1 = 1
            javax.crypto.Cipher r0 = N1.d.c(r0, r1, r1)
            VM r1 = r3.b
            j7.d r2 = new j7.d
            r2.<init>(r3, r4)
            r1.getClass()
            androidx.biometric.BiometricPrompt$CryptoObject r4 = new androidx.biometric.BiometricPrompt$CryptoObject
            r4.<init>(r0)
            androidx.biometric.BiometricPrompt$PromptInfo$Builder r0 = new androidx.biometric.BiometricPrompt$PromptInfo$Builder
            r0.<init>()
            r1 = 0
            androidx.biometric.BiometricPrompt$PromptInfo$Builder r0 = r0.setConfirmationRequired(r1)
            int r1 = com.huawei.module_checkout.R$string.checkout_please_validate_finger
            java.lang.String r1 = r3.getString(r1)
            androidx.biometric.BiometricPrompt$PromptInfo$Builder r0 = r0.setTitle(r1)
            int r1 = com.huawei.module_checkout.R$string.designstandard_cancel
            java.lang.String r1 = r3.getString(r1)
            androidx.biometric.BiometricPrompt$PromptInfo$Builder r0 = r0.setNegativeButtonText(r1)
            androidx.biometric.BiometricPrompt$PromptInfo r0 = r0.build()
            androidx.biometric.BiometricPrompt r1 = new androidx.biometric.BiometricPrompt
            r1.<init>(r3, r2)
            r1.authenticate(r0, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.checkstand.activity.CheckStandActivity.C0(com.huawei.module_checkout.checkstand.activity.CheckStandActivity, java.lang.String):void");
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [androidx.lifecycle.Observer, java.lang.Object] */
    public void D0() {
        getLifecycle().addObserver(this.b);
        this.b.d.observe(this, new Object());
        this.b.c.observe(this, new a());
        this.b.p.observe(this, new com.huawei.bank.transfer.activity.c(this, 3));
    }

    public void E0(NavController navController) {
        navController.navigate(R$id.action_orderConfirmFragment_to_checkStandFragment);
    }

    public final void F0(TransferResp transferResp) {
        findViewById(R$id.root).animate().alpha(0.0f).setDuration(200).setListener(new c(transferResp)).start();
    }

    public void G0(TransferResp transferResp) {
        finish();
        C0013a.C0002a.a.a.onSuccess(transferResp);
    }

    public final void H0(CheckoutResp checkoutResp) {
        if (checkoutResp != null) {
            this.b.j(checkoutResp);
            this.d.b.animate().alpha(1.0f).setDuration(200).start();
            this.d.b.postDelayed(new C0015b(this), 50);
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_checkout.checkstand.activity.CheckStandActivity, android.app.Activity] */
    public final void finish() {
        CheckStandActivity.super.finish();
        overridePendingTransition(0, 0);
    }

    public final void onBackPressed() {
        NavController navController = this.a;
        if (navController == null) {
            CheckStandActivity.super.onBackPressed();
        } else if (navController.popBackStack()) {
            NavDestination currentDestination = this.a.getCurrentDestination();
            if (currentDestination == null || currentDestination.getId() == R$id.emptyFragment) {
                F0((TransferResp) null);
            }
        } else {
            CheckStandActivity.super.onBackPressed();
        }
    }

    /* JADX WARNING: type inference failed for: r5v5, types: [java.lang.Object, androidx.core.view.OnApplyWindowInsetsListener] */
    public void onCreate(@Nullable Bundle bundle) {
        CheckStandActivity.super.onCreate(bundle);
        overridePendingTransition(0, 0);
        this.c = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new b());
        View inflate = getLayoutInflater().inflate(R$layout.activity_check_stand, (ViewGroup) null, false);
        LinearLayout linearLayout = (LinearLayout) inflate;
        int i = R$id.transfer_to_merchant;
        FragmentContainerView findChildViewById = ViewBindings.findChildViewById(inflate, i);
        if (findChildViewById != null) {
            this.d = new ActivityCheckStandBinding(linearLayout, linearLayout, findChildViewById);
            setContentView(linearLayout);
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.d.c.getLayoutParams();
            layoutParams.topMargin = f.a() + f.c();
            this.d.c.setLayoutParams(layoutParams);
            f.e(this, 0, false);
            f.f(this, false);
            Class cls = getClass();
            while (true) {
                if (cls == null || cls == BaseMvvmActivity.class) {
                    break;
                }
                Type genericSuperclass = cls.getGenericSuperclass();
                if (genericSuperclass instanceof ParameterizedType) {
                    this.b = (CheckStandViewModel) new ViewModelProvider(this).get((Class) ((ParameterizedType) genericSuperclass).getActualTypeArguments()[0]);
                    break;
                }
                cls = cls.getSuperclass();
            }
            D0();
            PaySceneEnum paySceneEnum = (PaySceneEnum) getIntent().getSerializableExtra("paySceneEnum");
            this.e = paySceneEnum;
            this.b.g = paySceneEnum;
            H0(getIntent().getSerializableExtra("CheckoutResp"));
            LinearLayout linearLayout2 = this.d.a;
            if (Build.VERSION.SDK_INT >= 35 && linearLayout2 != null) {
                linearLayout2.setFitsSystemWindows(false);
                ViewCompat.setOnApplyWindowInsetsListener(linearLayout2, new Object());
                return;
            }
            return;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }
}
