package com.huawei.module_checkout.checkstand.viewmodel;

import G2.b;
import N1.d;
import android.text.TextUtils;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.blankj.utilcode.util.J;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.batchtransfer.BatchTransferViewModel;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.module_checkout.confirm.OdConfirmDisplay;
import java.util.HashMap;
import java.util.List;

public abstract class CheckStandViewModel extends BaseViewModel {
    public PaySceneEnum g;
    public String h = J.a().getString(R$string.checkout_send);
    public HashMap i;
    public final MutableLiveData<CheckoutResp> j = new MutableLiveData<>();
    public final MutableLiveData<FundsSourceInfoDisplay> k = new MutableLiveData<>();
    public final MutableLiveData<CouponBean> l = new MutableLiveData<>();
    public final MutableLiveData<CheckoutResp> m = new MutableLiveData<>();
    public final MutableLiveData<OdConfirmDisplay> n = new MutableLiveData<>();
    public final MutableLiveData<CheckoutResp> o = new MutableLiveData<>();
    public final MutableLiveData<TransferResp> p = new MutableLiveData<>();
    public final MutableLiveData<Boolean> q;
    public final MutableLiveData<Boolean> r;
    public String s;
    public String t;

    public class a extends BaseViewModel.a<CheckoutResp> {
        public a() {
            super(CheckStandViewModel.this);
        }

        public final void onSuccess(Object obj) {
            CheckoutResp checkoutResp = (CheckoutResp) obj;
            CheckStandViewModel.super.onSuccess(checkoutResp);
            CheckStandViewModel.this.m.setValue(checkoutResp);
        }
    }

    public CheckStandViewModel() {
        boolean z;
        MutableLiveData<Boolean> mutableLiveData = new MutableLiveData<>(Boolean.TRUE);
        this.q = mutableLiveData;
        MutableLiveData<Boolean> mutableLiveData2 = new MutableLiveData<>(Boolean.FALSE);
        this.r = mutableLiveData2;
        if (d.a("FingerprintPay", true)) {
            b.c(2);
        }
        if (!b.g() || !b.h()) {
            z = false;
        } else {
            z = true;
        }
        mutableLiveData.setValue(Boolean.valueOf(!z));
        if (d.a("FingerprintPay", true)) {
            b.c(2);
        }
        mutableLiveData2.setValue(Boolean.valueOf(b.g()));
    }

    public final void e(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        if (!(this instanceof BatchTransferViewModel)) {
            b(g(fundsSourceInfoDisplay), new a());
        } else {
            ((BatchTransferViewModel) this).m(fundsSourceInfoDisplay);
        }
    }

    public LiveData<S2.b<CheckoutResp>> f(CouponBean couponBean) {
        return null;
    }

    public abstract LiveData<S2.b<CheckoutResp>> g(FundsSourceInfoDisplay fundsSourceInfoDisplay);

    public final String h() {
        PaySceneEnum paySceneEnum = this.g;
        if (paySceneEnum == null) {
            return "";
        }
        return paySceneEnum.getReportTag();
    }

    public abstract LiveData<S2.b<TransferResp>> i(String str);

    public final void j(CheckoutResp checkoutResp) {
        MutableLiveData<CheckoutResp> mutableLiveData = this.j;
        if (mutableLiveData.getValue() != checkoutResp) {
            FundsSourceInfoDisplay paymentMethod = checkoutResp.getPaymentMethod();
            MutableLiveData<FundsSourceInfoDisplay> mutableLiveData2 = this.k;
            if (paymentMethod == null) {
                mutableLiveData2.setValue((Object) null);
            } else if (mutableLiveData2.getValue() == null) {
                k(paymentMethod);
            }
            mutableLiveData.setValue(checkoutResp);
            l();
            this.s = checkoutResp.getPrepayId();
            if (!TextUtils.isEmpty(checkoutResp.getBusinessType())) {
                this.t = checkoutResp.getBusinessType();
            }
        }
    }

    public final void k(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        if (fundsSourceInfoDisplay != null) {
            this.k.setValue(fundsSourceInfoDisplay);
            l();
        }
    }

    public final void l() {
        FundsSourceInfoDisplay fundsSourceInfoDisplay = (FundsSourceInfoDisplay) this.k.getValue();
        MutableLiveData<CouponBean> mutableLiveData = this.l;
        if (fundsSourceInfoDisplay != null) {
            MutableLiveData<CheckoutResp> mutableLiveData2 = this.j;
            if (mutableLiveData2.getValue() != null) {
                List optimalCouponScheme = fundsSourceInfoDisplay.getOptimalCouponScheme();
                if (optimalCouponScheme != null && !optimalCouponScheme.isEmpty()) {
                    String str = (String) optimalCouponScheme.get(0);
                    List<CouponBean> userCoupons = ((CheckoutResp) mutableLiveData2.getValue()).getUserCoupons();
                    if (userCoupons != null && !userCoupons.isEmpty()) {
                        for (CouponBean couponBean : userCoupons) {
                            if (TextUtils.equals(couponBean.getCouponId(), str)) {
                                mutableLiveData.setValue(couponBean);
                                return;
                            }
                        }
                    }
                }
                mutableLiveData.setValue((Object) null);
                return;
            }
        }
        mutableLiveData.setValue((Object) null);
    }

    public void d(String str) {
    }
}
