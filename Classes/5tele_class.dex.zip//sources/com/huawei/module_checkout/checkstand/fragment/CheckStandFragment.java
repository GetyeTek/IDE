package com.huawei.module_checkout.checkstand.fragment;

import D1.q;
import D1.r;
import P7.g;
import V1.h;
import V1.k;
import W2.n;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.camera.core.S;
import androidx.camera.view.w;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.MutableLiveData;
import androidx.navigation.Navigation;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.biometric.dialog.LocalAuthenticationDialog;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.request.BatchPayOrderRequest;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.digitalpayment.customer.httplib.response.ODDisplayGroupResp;
import com.huawei.digitalpayment.schedule.activity.f;
import com.huawei.module_checkout.R$color;
import com.huawei.module_checkout.R$id;
import com.huawei.module_checkout.R$layout;
import com.huawei.module_checkout.R$string;
import com.huawei.module_checkout.batchtransfer.BatchTransferViewModel;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.module_checkout.checkstand.adapter.ConfirmDisplayItemAdapter;
import com.huawei.module_checkout.checkstand.adapter.PaymentMethodSelectAdapter;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import com.huawei.module_checkout.confirm.CheckStandODConfirmActivity;
import com.huawei.module_checkout.confirm.OdConfirmDisplay;
import com.huawei.module_checkout.databinding.FragmentCheckStandBinding;
import e7.C0008a;
import e7.d;
import e7.e;
import f2.c;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import l7.C0019a;
import l7.b;

public class CheckStandFragment extends BaseCheckStandFragment {
    public FragmentCheckStandBinding c;
    public boolean d;
    public boolean e;
    public boolean f;
    public FundsSourceInfoDisplay g;
    public PaymentMethodSelectAdapter h;
    public CouponBean i = new CouponBean();
    public ActivityResultLauncher<Intent> j;
    public boolean k = false;

    public class a implements ActivityResultCallback<ActivityResult> {
        public a() {
        }

        public final void onActivityResult(Object obj) {
            if (((ActivityResult) obj).getResultCode() == -1) {
                CheckStandFragment.this.c.c.postDelayed(new w(this, 3), 200);
            }
        }
    }

    public static void w0(CheckStandFragment checkStandFragment, int i2, Cipher cipher) {
        checkStandFragment.getClass();
        try {
            String e2 = n.b("").e("recent_login_phone_number");
            n b = n.b("Biometric");
            checkStandFragment.C0(new String(cipher.doFinal(Base64.decode(b.e("FINGERPRINT_PAY_PIN_KEY_" + e2 + "_" + i2), 2)), StandardCharsets.UTF_8), true);
        } catch (Exception e3) {
            e3.getMessage();
            h.b();
            Navigation.findNavController((View) null).navigate(R$id.action_checkStandFragment_to_inAppPayPinFragment);
        }
    }

    public static FundsSourceInfoDisplay z0(String str, List list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            FundsSourceInfoDisplay fundsSourceInfoDisplay = (FundsSourceInfoDisplay) it.next();
            if (str.equals(fundsSourceInfoDisplay.getFundsSource())) {
                return fundsSourceInfoDisplay;
            }
        }
        return null;
    }

    public final void A0(OdConfirmDisplay odConfirmDisplay) {
        String str;
        Map map;
        if (PaySceneEnum.BUY_AIRTIME == this.a.g && odConfirmDisplay.getOdDisplayItems() != null && !odConfirmDisplay.getOdDisplayItems().isEmpty() && !"ServiceNumber".equals(odConfirmDisplay.getOdDisplayItems().get(0).getGroupName())) {
            Map map2 = (Map) requireActivity().getIntent().getSerializableExtra("params");
            if (map2 == null || (map = (Map) map2.get("rechargeInfo")) == null) {
                str = "";
            } else {
                str = (String) map.get("rechargedMsisdn");
            }
            ArrayList arrayList = new ArrayList();
            arrayList.add(new FundsSourceInfoDisplay.DisplayItemsBean(requireActivity().getString(R$string.service_number), str));
            ODDisplayGroupResp oDDisplayGroupResp = new ODDisplayGroupResp();
            oDDisplayGroupResp.setGroupName("ServiceNumber");
            oDDisplayGroupResp.setList(arrayList);
            odConfirmDisplay.getOdDisplayItems().add(0, oDDisplayGroupResp);
        }
        Intent intent = new Intent(requireActivity(), CheckStandODConfirmActivity.class);
        intent.putExtra("display", odConfirmDisplay);
        this.j.launch(intent);
    }

    public final void B0(View view) {
        CouponBean couponBean;
        FundsSourceInfoDisplay fundsSourceInfoDisplay = (FundsSourceInfoDisplay) this.a.k.getValue();
        if (fundsSourceInfoDisplay == null) {
            k.b(1, getString(R$string.designstandard_please_choose_pay_method));
            return;
        }
        ReportViewModel reportViewModel = c.b;
        c.a.a.c("click_Cashier_payment_method", new String[]{fundsSourceInfoDisplay.getFundsSource(), this.a.h()});
        CheckoutResp checkoutResp = (CheckoutResp) this.a.j.getValue();
        boolean z = false;
        if (!fundsSourceInfoDisplay.isDefaultAccount() || (fundsSourceInfoDisplay.isIsDefault() && fundsSourceInfoDisplay.isAvailable())) {
            try {
                CheckStandViewModel checkStandViewModel = this.a;
                if (checkStandViewModel.g != null) {
                    w5.a.a(checkStandViewModel.h());
                }
            } catch (Exception e2) {
                e2.getMessage();
                h.b();
            }
            if (fundsSourceInfoDisplay.isOdFundsSource() || fundsSourceInfoDisplay.isOdCombinedFundsSource()) {
                OdConfirmDisplay odConfirmDisplay = new OdConfirmDisplay();
                odConfirmDisplay.setOdDisplayItems(fundsSourceInfoDisplay.getOdDisplayItems());
                odConfirmDisplay.setTitle(checkoutResp.getSubTitle());
                odConfirmDisplay.setAmountDisplay(checkoutResp.getActualAmountDisplay());
                odConfirmDisplay.setUnit(checkoutResp.getUnit());
                odConfirmDisplay.setButtonText(this.a.h);
                odConfirmDisplay.setReportTag(this.a.h());
                A0(odConfirmDisplay);
                return;
            }
            MutableLiveData<CouponBean> mutableLiveData = this.a.l;
            if (!(mutableLiveData == null || (couponBean = (CouponBean) mutableLiveData.getValue()) == null)) {
                z = couponBean.isPopUp();
            }
            if (z) {
                String string = getString(R$string.coupon_refund_tip);
                String string2 = getString(R$string.designstandard_cancel);
                String string3 = getString(R$string.yes);
                b bVar = new b(this, view);
                BaseDialog baseDialog = new BaseDialog();
                baseDialog.g = null;
                baseDialog.h = string;
                baseDialog.i = string2;
                baseDialog.j = string3;
                baseDialog.k = null;
                baseDialog.l = bVar;
                baseDialog.show(getChildFragmentManager(), "tipsDialog");
                return;
            }
            y0(view);
        } else if (checkoutResp.isCashIn()) {
            String string4 = getString(R$string.checkout_you_dont_have_enough_balance_to_complete_this);
            String string5 = getString(R$string.designstandard_cancel);
            String string6 = getString(R$string.designstandard_cash_in);
            f5.c cVar = new f5.c(this, 1);
            BaseDialog baseDialog2 = new BaseDialog();
            baseDialog2.g = null;
            baseDialog2.h = string4;
            baseDialog2.i = string5;
            baseDialog2.j = string6;
            baseDialog2.k = null;
            baseDialog2.l = cVar;
            baseDialog2.show(getChildFragmentManager(), "tipsDialog");
        } else {
            if (checkoutResp.isOpenOd()) {
                FundsSourceInfoDisplay z0 = z0("OD_COMBINED", checkoutResp.getFundsSourceInfoDisplay());
                if (z0 != null) {
                    z = z0.isAvailable();
                }
                if (!z) {
                    k.b(1, getString(R$string.your_balance_is_insufficient_please_choose_other_pay_method));
                    return;
                }
            }
            if (!checkoutResp.isOpenOd()) {
                D0();
                return;
            }
            String string7 = getString(R$string.sorry_your_telebirr_balance_is_insufficient_do_you_want_to_complete_the_transaction_using_telebirr_endekise);
            if (!TextUtils.isEmpty(checkoutResp.getSingleODMsg())) {
                string7 = checkoutResp.getSingleODMsg();
            }
            String string8 = getString(R$string.od_confirmation_no);
            String string9 = getString(R$string.od_confirmation_ok);
            com.huawei.module_checkout.confirm.a aVar = new com.huawei.module_checkout.confirm.a(this, checkoutResp, 1);
            X6.b bVar2 = new X6.b(this, 7);
            BaseDialog baseDialog3 = new BaseDialog();
            baseDialog3.g = null;
            baseDialog3.h = string7;
            baseDialog3.i = string8;
            baseDialog3.j = string9;
            baseDialog3.k = bVar2;
            baseDialog3.l = aVar;
            baseDialog3.show(getChildFragmentManager(), "tipsDialog");
        }
    }

    public final void C0(String str, boolean z) {
        CheckStandViewModel checkStandViewModel = this.a;
        checkStandViewModel.getClass();
        if (checkStandViewModel instanceof BatchTransferViewModel) {
            BatchTransferViewModel batchTransferViewModel = (BatchTransferViewModel) checkStandViewModel;
            BatchPayOrderRequest batchPayOrderRequest = new BatchPayOrderRequest();
            batchPayOrderRequest.setInitiatorMsisdn(n.b("").e("recent_login_phone_number"));
            batchPayOrderRequest.setPinVersion(L3.a.b.getPinKeyVersion());
            batchPayOrderRequest.setReceiverItems(batchTransferViewModel.z);
            batchPayOrderRequest.setInitiatorPin(L3.a.g(str));
            d dVar = batchTransferViewModel.u;
            dVar.getClass();
            batchTransferViewModel.b(new C0008a(0, dVar, batchPayOrderRequest).a, new e(batchTransferViewModel, true));
            return;
        }
        checkStandViewModel.b(checkStandViewModel.i(str), new m7.c(checkStandViewModel, true));
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [com.huawei.module_checkout.checkstand.fragment.CheckStandFragment, androidx.fragment.app.Fragment, com.huawei.module_checkout.checkstand.fragment.BaseCheckStandFragment, android.view.View$OnCreateContextMenuListener] */
    public final void D0() {
        String str = (String) BasicConfig.getInstance().getReferenceData().get("needUpgradeLevel");
        if (TextUtils.isEmpty(str) || !str.equals("true")) {
            CheckoutResp checkoutResp = (CheckoutResp) this.a.j.getValue();
            String string = getString(R$string.checkout_activate_credit_limit);
            if (checkoutResp != null && !TextUtils.isEmpty(checkoutResp.getOpenODMsg())) {
                string = checkoutResp.getOpenODMsg();
            }
            String string2 = getString(R$string.designstandard_cancel);
            String string3 = getString(R$string.designstandard_ok);
            g gVar = new g(this, 9);
            BaseDialog baseDialog = new BaseDialog();
            baseDialog.g = null;
            baseDialog.h = string;
            baseDialog.i = string2;
            baseDialog.j = string3;
            baseDialog.k = null;
            baseDialog.l = gVar;
            baseDialog.show(getChildFragmentManager(), "tipsDialog");
            return;
        }
        E0();
    }

    public final void E0() {
        String string = getString(R$string.update_level_prompt_balance_is_insufficient);
        com.huawei.digitalpayment.schedule.activity.k kVar = new com.huawei.digitalpayment.schedule.activity.k(1);
        String string2 = getString(R$string.go_upgrade_level);
        BaseDialog baseDialog = new BaseDialog();
        baseDialog.c = string;
        baseDialog.f = kVar;
        baseDialog.e = string2;
        baseDialog.show(getChildFragmentManager(), "UpgradeLevelDialog");
    }

    public final void F0(@NonNull CheckoutResp checkoutResp) {
        this.c.l.setText(checkoutResp.getSubTitle());
        this.c.g.setText(checkoutResp.getActualAmountDisplay());
        this.c.h.setText(checkoutResp.getUnit());
        HashMap hashMap = this.a.i;
        if (hashMap == null || !hashMap.containsKey("fuelPayment")) {
            this.c.i.setText(getString(R$string.designstandard_coupon));
        } else {
            this.c.i.setText(getString(R$string.baselib_fuel_coupon));
        }
        List userCoupons = checkoutResp.getUserCoupons();
        List availableCoupons = ((FundsSourceInfoDisplay) checkoutResp.getFundsSourceInfoDisplay().get(0)).getAvailableCoupons();
        if (userCoupons == null || userCoupons.isEmpty() || availableCoupons == null || availableCoupons.isEmpty()) {
            this.c.b.setVisibility(8);
        } else {
            this.c.b.setVisibility(0);
        }
        this.c.k.setText(getString(R$string.designstandard_payment_method));
        List confirmDisplayItems = checkoutResp.getConfirmDisplayItems();
        this.c.f.setAdapter(new ConfirmDisplayItemAdapter(confirmDisplayItems));
        if (confirmDisplayItems.isEmpty()) {
            this.c.f.setVisibility(8);
        } else {
            this.c.f.setVisibility(0);
        }
        if (!this.k) {
            List fundsSourceInfoDisplay = checkoutResp.getFundsSourceInfoDisplay();
            FundsSourceInfoDisplay fundsSourceInfoDisplay2 = (FundsSourceInfoDisplay) this.a.k.getValue();
            if (this.h == null) {
                FundsSourceInfoDisplay defaultAccountDisplay = checkoutResp.getDefaultAccountDisplay();
                BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_in_app_select, (List) null);
                baseQuickAdapter.a = defaultAccountDisplay;
                this.h = baseQuickAdapter;
                this.a.k(checkoutResp.getDefaultAccountDisplay());
                this.c.e.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(requireContext(), R$color.colorDividerDark), 1));
            }
            if (fundsSourceInfoDisplay2 != null) {
                this.h.f(fundsSourceInfoDisplay2);
                FundsSourceInfoDisplay z0 = z0("OD_COMBINED", checkoutResp.getFundsSourceInfoDisplay());
                if (z0 == null || !checkoutResp.isOpenOd() || !z0.isAvailable() || !z0.isDefault()) {
                    this.a.k(fundsSourceInfoDisplay2);
                } else {
                    this.a.k(checkoutResp.getDefaultAccountDisplay());
                    this.h.f(checkoutResp.getDefaultAccountDisplay());
                }
            }
            this.h.e(fundsSourceInfoDisplay, checkoutResp.isNeedShowOd());
            this.h.setOnItemClickListener(new S(3, this, checkoutResp));
            this.c.e.setAdapter(this.h);
        }
    }

    public final void onCreate(@Nullable Bundle bundle) {
        CheckStandFragment.super.onCreate(bundle);
        this.j = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new a());
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0040, code lost:
        r1 = com.huawei.module_checkout.R$id.rv_pay_method;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004b, code lost:
        r1 = com.huawei.module_checkout.R$id.rv_recycler_view;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0020, code lost:
        r1 = com.huawei.module_checkout.R$id.confirm;
     */
    @androidx.annotation.Nullable
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(@androidx.annotation.NonNull android.view.LayoutInflater r18, @androidx.annotation.Nullable android.view.ViewGroup r19, @androidx.annotation.Nullable android.os.Bundle r20) {
        /*
            r17 = this;
            int r0 = com.huawei.module_checkout.R$layout.fragment_check_stand
            r1 = 0
            r2 = r18
            r3 = r19
            android.view.View r0 = r2.inflate(r0, r3, r1)
            int r1 = com.huawei.module_checkout.R$id.cl_discount_type
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r5 = (com.huawei.common.widget.round.RoundConstraintLayout) r5
            if (r5 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.cl_payment_method
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundConstraintLayout r2 = (com.huawei.common.widget.round.RoundConstraintLayout) r2
            if (r2 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.confirm
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r6 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r6
            if (r6 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.iv_close
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            if (r7 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.ll_discount_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            if (r2 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.rv_pay_method
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            androidx.recyclerview.widget.RecyclerView r8 = (androidx.recyclerview.widget.RecyclerView) r8
            if (r8 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.rv_recycler_view
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            com.huawei.common.widget.round.RoundRecyclerView r9 = (com.huawei.common.widget.round.RoundRecyclerView) r9
            if (r9 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.sv_content
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ScrollView r2 = (android.widget.ScrollView) r2
            if (r2 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.tv_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            android.widget.TextView r10 = (android.widget.TextView) r10
            if (r10 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.tv_amount_unit
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            android.widget.TextView r11 = (android.widget.TextView) r11
            if (r11 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.tv_discount_type
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r12 = r2
            android.widget.TextView r12 = (android.widget.TextView) r12
            if (r12 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.tv_discount_type_value
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r13 = r2
            android.widget.TextView r13 = (android.widget.TextView) r13
            if (r13 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.tv_payment_method
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r14 = r2
            android.widget.TextView r14 = (android.widget.TextView) r14
            if (r14 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.tv_title
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r15 = r2
            android.widget.TextView r15 = (android.widget.TextView) r15
            if (r15 == 0) goto L_0x00bc
            int r1 = com.huawei.module_checkout.R$id.tv_verify_method
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r16 = r2
            android.widget.TextView r16 = (android.widget.TextView) r16
            if (r16 == 0) goto L_0x00bc
            com.huawei.module_checkout.databinding.FragmentCheckStandBinding r1 = new com.huawei.module_checkout.databinding.FragmentCheckStandBinding
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r3 = r1
            r4 = r0
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16)
            r2 = r17
            r2.c = r1
            return r0
        L_0x00bc:
            r2 = r17
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r3 = "Missing required view with ID: "
            java.lang.String r0 = r3.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.module_checkout.checkstand.fragment.CheckStandFragment.onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    public final void onResume() {
        CheckStandFragment.super.onResume();
        FundsSourceInfoDisplay fundsSourceInfoDisplay = this.g;
        if (fundsSourceInfoDisplay != null) {
            this.d = true;
            this.a.e(fundsSourceInfoDisplay);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.c.d.setOnClickListener(new com.huawei.digitalpayment.schedule.activity.n(this, 6));
        this.c.i.setOnClickListener(new q(this, 9));
        this.c.j.setOnClickListener(new q(this, 9));
        this.c.c.setOnClickListener(new r(this, 6));
        this.c.m.setOnClickListener(new I7.a(this, 4));
        if (!TextUtils.isEmpty(this.a.h)) {
            this.c.c.setText(this.a.h);
        }
    }

    public final void v0() {
        super.v0();
        this.a.j.observe(getViewLifecycleOwner(), new C0019a(this));
        this.a.q.observe(getViewLifecycleOwner(), new b4.a(this, 4));
        this.a.r.observe(getViewLifecycleOwner(), new b4.b(this, 2));
        this.a.m.observe(getViewLifecycleOwner(), new l7.c(this, 0));
        this.a.n.observe(getViewLifecycleOwner(), new f(this, 1));
        this.a.o.observe(getViewLifecycleOwner(), new com.huawei.digitalpayment.schedule.activity.g(this, 1));
        this.a.l.observe(getViewLifecycleOwner(), new f5.b(this, 1));
    }

    public final void x0(FundsSourceInfoDisplay fundsSourceInfoDisplay) {
        this.d = true;
        this.g = fundsSourceInfoDisplay;
        this.a.e(fundsSourceInfoDisplay);
    }

    public final void y0(View view) {
        if (((Boolean) this.a.q.getValue()).booleanValue()) {
            Navigation.findNavController(view).navigate(R$id.action_checkStandFragment_to_inAppPayPinFragment);
            return;
        }
        String e2 = n.b("").e("recent_login_phone_number");
        n b = n.b("Biometric");
        if (b.a.getInt(V2.b.a("key_biometric_pay_id_", e2), 0) == 2) {
            String e3 = n.b("").e("recent_login_phone_number");
            n b2 = n.b("Biometric");
            O1.a aVar = new O1.a(requireActivity(), N1.d.b("FingerprintPay", b2.e("FINGERPRINT_PAY_IV_KEY_" + e3 + "_2"), true));
            aVar.c = new B6.b(this, 2);
            aVar.a(R$string.checkout_please_verify_your_fingerprint, R$string.designstandard_cancel);
            return;
        }
        String e4 = n.b("").e("recent_login_phone_number");
        n b3 = n.b("Biometric");
        LocalAuthenticationDialog localAuthenticationDialog = new LocalAuthenticationDialog(N1.d.b("FacePay", b3.e("FINGERPRINT_PAY_IV_KEY_" + e4 + "_1"), false));
        localAuthenticationDialog.c = new B6.a(this, 2);
        localAuthenticationDialog.show(getChildFragmentManager(), "");
    }
}
