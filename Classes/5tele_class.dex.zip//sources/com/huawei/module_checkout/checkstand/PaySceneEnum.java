package com.huawei.module_checkout.checkstand;

import com.huawei.module_checkout.requestmoney.resp.RequestMoneyResp;
import java.io.Serializable;

public enum PaySceneEnum implements Serializable {
    CASH_OUT("v1/preCashOut", "v1/cashOut", "Cash Out"),
    TRANSFER_TO_BANK("v1/ethiopia/preTransferToBank", "v1/ethiopia/transferToBank", "Transfer To Bank"),
    TRANSFER_TO_Wallet("v1/ethiopia/preTransferToWallet", "v1/ethiopia/transferToWallet", "Transfer To Wallet"),
    P2P_TRANSFER("v1/preP2PTransfer", "v1/p2pTransfer"),
    P2P_REQUEST_MONEY("v1/ethiopia/preRequestMoneyForChat", "v1/ethiopia/requestMoneyForChat", RequestMoneyResp.REQUEST_MONEY),
    PAY_FOR_MERCHANT("v1/preCustomerBuyGoods", "v1/customerBuyGoods", "Pay For Merchant"),
    BUY_AIRTIME("v1/preRechargeAirtime", "v1/rechargeAirtime", "Airtime"),
    PAY_ET_BILL("v1/ethiopia/prePayEtBill", "v1/ethiopia/payEtBill", "Pay ET Bill"),
    PAY_ET_DEPOSIT("v1/ethiopia/prePayEtDeposit", "v1/ethiopia/payEtDeposit", "Pay ET Deposit"),
    WITHDRAW_TO_BANK_CARD("v1/preWithdrawToBankCard", "v1/withdrawToBankCard", "Withdraw to Bank"),
    UNIQUE_BUY_GOODS("v1/ethiopia/preUniqueBuyGoods", "v1/ethiopia/uniqueBuyGoods", "Unique buy goods"),
    NEW_UNIQUE_BUY_GOODS("v1/ethiopia/preNewCnetBuyGoods", "v1/ethiopia/newCnetBuyGoods", "New CNet buy goods"),
    DEPOSIT_FROM_BANK_CARD("v1/preDepositFromBankCard", "v1/depositFromBankCard", "Deposit form bank"),
    H5_CHECKOUT("v1/h5Checkout", "v1/customerBuyGoods", "H5 Buy Goods"),
    FUEL_PAYMENT("v1/ethiopia/prePayFuel", "v1/ethiopia/payFuel", "Fuel Payment"),
    BILL_SHARE("v1/ethiopia/prePayBillShare", "v1/ethiopia/payBillShare", "Bill share"),
    PAY_TIPS("v1/ethiopia/prePayTips", "v1/ethiopia/payTips", "Pay Tips"),
    REQUEST_MONEY("v1/ethiopia/prePayRequestMoney", "v1/ethiopia/payRequestMoney", RequestMoneyResp.REQUEST_MONEY),
    POCKET_MONEY_P2P("v1/ethiopia/prePayChatP2PPocketMoney", "v1/ethiopia/payChatP2PPocketMoney", "Pocket Money P2P"),
    POCKET_MONEY_GROUP("v1/ethiopia/prePayChatGroupPocketMoney", "v1/ethiopia/payChatGroupPocketMoney", "Pocket Money Group");
    
    private final String checkoutPath;
    private String reportTag;
    private final String transferPath;

    private PaySceneEnum(String str, String str2) {
        this.checkoutPath = str;
        this.transferPath = str2;
    }

    public String getCheckoutPath() {
        return this.checkoutPath;
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public String getTransferParam() {
        return this.transferPath;
    }

    private PaySceneEnum(String str, String str2, String str3) {
        this.checkoutPath = str;
        this.transferPath = str2;
        this.reportTag = str3;
    }
}
