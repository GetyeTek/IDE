package com.huawei.module_checkout.checkstand.common;

import L3.a;
import android.text.TextUtils;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.http.b;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import java.util.Map;

public class CommonPayOrderRepository extends b<TransferResp, TransferResp> {
    public final PaySceneEnum a;

    public CommonPayOrderRepository(PaySceneEnum paySceneEnum, String str, String str2, Map<String, Object> map, String str3) {
        this.a = paySceneEnum;
        addParams("pinVersion", a.b.getPinKeyVersion());
        addParams("initiatorPin", a.g(str));
        addParams("prepayId", str2);
        if (!TextUtils.isEmpty(str3)) {
            addParams("businessType", str3);
        }
        addParams(map);
    }

    public final String getApiPath() {
        return this.a.getTransferParam();
    }
}
