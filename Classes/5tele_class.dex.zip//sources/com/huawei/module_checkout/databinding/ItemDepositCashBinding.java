package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.module_checkout.R$id;

public final class ItemDepositCashBinding implements ViewBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;

    public ItemDepositCashBinding(@NonNull RoundConstraintLayout roundConstraintLayout, @NonNull ImageView imageView, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = roundConstraintLayout;
        this.b = imageView;
        this.c = textView;
        this.d = textView2;
    }

    @NonNull
    public static ItemDepositCashBinding a(@NonNull View view) {
        int i = R$id.iv_arrow_right;
        if (((ImageView) ViewBindings.findChildViewById(view, i)) != null) {
            i = R$id.iv_icon;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i);
            if (imageView != null) {
                i = R$id.tv_content;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R$id.tv_title;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        return new ItemDepositCashBinding((RoundConstraintLayout) view, imageView, textView, textView2);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
