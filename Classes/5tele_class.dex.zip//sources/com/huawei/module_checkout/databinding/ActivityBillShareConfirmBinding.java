package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundImageView;

public abstract class ActivityBillShareConfirmBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final RoundImageView b;
    @NonNull
    public final RecyclerView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public ActivityBillShareConfirmBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, RoundImageView roundImageView, RecyclerView recyclerView, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = roundImageView;
        this.c = recyclerView;
        this.d = textView;
        this.e = textView2;
        this.f = textView3;
    }
}
