package com.huawei.module_checkout.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.module_checkout.R$id;

public class ActivityHtmlpaymentBindingImpl extends ActivityHtmlpaymentBinding {
    @Nullable
    public static final SparseIntArray d;
    public long c;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        d = sparseIntArray;
        sparseIntArray.put(R$id.recycler_view, 1);
        sparseIntArray.put(R$id.ll_button, 2);
        sparseIntArray.put(R$id.btn_confirm, 3);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.c = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.c != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.c = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
