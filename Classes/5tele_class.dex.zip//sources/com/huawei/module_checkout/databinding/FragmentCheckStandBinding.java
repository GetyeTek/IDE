package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class FragmentCheckStandBinding implements ViewBinding {
    @NonNull
    public final RoundLinearLayout a;
    @NonNull
    public final RoundConstraintLayout b;
    @NonNull
    public final LoadingButton c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final RecyclerView e;
    @NonNull
    public final RoundRecyclerView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;
    @NonNull
    public final TextView l;
    @NonNull
    public final TextView m;

    public FragmentCheckStandBinding(@NonNull RoundLinearLayout roundLinearLayout, @NonNull RoundConstraintLayout roundConstraintLayout, @NonNull LoadingButton loadingButton, @NonNull ImageView imageView, @NonNull RecyclerView recyclerView, @NonNull RoundRecyclerView roundRecyclerView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7) {
        this.a = roundLinearLayout;
        this.b = roundConstraintLayout;
        this.c = loadingButton;
        this.d = imageView;
        this.e = recyclerView;
        this.f = roundRecyclerView;
        this.g = textView;
        this.h = textView2;
        this.i = textView3;
        this.j = textView4;
        this.k = textView5;
        this.l = textView6;
        this.m = textView7;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
