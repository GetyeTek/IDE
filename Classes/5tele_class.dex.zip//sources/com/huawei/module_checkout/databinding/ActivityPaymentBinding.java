package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;
import com.huawei.digitalpayment.customer.viewlib.view.MyRadioGroup;

public final class ActivityPaymentBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final MyRadioGroup c;
    @NonNull
    public final RelativeLayout d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public ActivityPaymentBinding(@NonNull LinearLayout linearLayout, @NonNull LoadingButton loadingButton, @NonNull MyRadioGroup myRadioGroup, @NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = linearLayout;
        this.b = loadingButton;
        this.c = myRadioGroup;
        this.d = relativeLayout;
        this.e = textView;
        this.f = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
