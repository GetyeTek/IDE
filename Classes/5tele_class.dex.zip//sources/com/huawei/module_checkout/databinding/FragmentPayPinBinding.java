package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView;
import com.huawei.module_checkout.view.CheckOutPinEditText;

public final class FragmentPayPinBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final CheckOutPinEditText b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final VirtualKeyboardView f;

    public FragmentPayPinBinding(@NonNull ConstraintLayout constraintLayout, @NonNull CheckOutPinEditText checkOutPinEditText, @NonNull ImageView imageView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull VirtualKeyboardView virtualKeyboardView) {
        this.a = constraintLayout;
        this.b = checkOutPinEditText;
        this.c = imageView;
        this.d = textView;
        this.e = textView2;
        this.f = virtualKeyboardView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
