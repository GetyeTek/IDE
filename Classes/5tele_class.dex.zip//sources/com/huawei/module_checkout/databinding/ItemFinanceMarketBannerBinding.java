package com.huawei.module_checkout.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class ItemFinanceMarketBannerBinding extends ViewDataBinding {
}
