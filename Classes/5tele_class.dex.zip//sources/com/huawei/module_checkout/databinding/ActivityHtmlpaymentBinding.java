package com.huawei.module_checkout.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundRecyclerView;

public abstract class ActivityHtmlpaymentBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final RoundRecyclerView b;

    public ActivityHtmlpaymentBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, RoundRecyclerView roundRecyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = roundRecyclerView;
    }
}
