package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityInAppPayBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final RecyclerView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public ActivityInAppPayBinding(@NonNull ConstraintLayout constraintLayout, @NonNull LoadingButton loadingButton, @NonNull RecyclerView recyclerView, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = loadingButton;
        this.c = recyclerView;
        this.d = textView;
        this.e = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
