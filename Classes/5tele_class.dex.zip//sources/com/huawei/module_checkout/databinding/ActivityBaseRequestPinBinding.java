package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView;
import com.huawei.module_checkout.view.CheckOutPinEditText;

public final class ActivityBaseRequestPinBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final View b;
    @NonNull
    public final CheckOutPinEditText c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final RadioGroup e;
    @NonNull
    public final RadioButton f;
    @NonNull
    public final RadioButton g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;

    public ActivityBaseRequestPinBinding(@NonNull ConstraintLayout constraintLayout, @NonNull View view, @NonNull CheckOutPinEditText checkOutPinEditText, @NonNull ImageView imageView, @NonNull RadioGroup radioGroup, @NonNull RadioButton radioButton, @NonNull RadioButton radioButton2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull VirtualKeyboardView virtualKeyboardView) {
        this.a = constraintLayout;
        this.b = view;
        this.c = checkOutPinEditText;
        this.d = imageView;
        this.e = radioGroup;
        this.f = radioButton;
        this.g = radioButton2;
        this.h = textView;
        this.i = textView2;
        this.j = textView3;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
