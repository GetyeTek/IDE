package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ItemPayMethodBinding implements ViewBinding {
    @NonNull
    public final RelativeLayout a;
    @NonNull
    public final LinearLayout b;

    public ItemPayMethodBinding(@NonNull RelativeLayout relativeLayout, @NonNull ImageView imageView, @NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = relativeLayout;
        this.b = linearLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
