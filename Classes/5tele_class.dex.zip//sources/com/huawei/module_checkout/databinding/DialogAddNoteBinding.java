package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.customer.viewlib.view.TypeEditText;

public final class DialogAddNoteBinding implements ViewBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final RoundTextView c;
    @NonNull
    public final TypeEditText d;
    @NonNull
    public final TextView e;

    public DialogAddNoteBinding(@NonNull RoundConstraintLayout roundConstraintLayout, @NonNull RoundTextView roundTextView, @NonNull RoundTextView roundTextView2, @NonNull TypeEditText typeEditText, @NonNull TextView textView) {
        this.a = roundConstraintLayout;
        this.b = roundTextView;
        this.c = roundTextView2;
        this.d = typeEditText;
        this.e = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
