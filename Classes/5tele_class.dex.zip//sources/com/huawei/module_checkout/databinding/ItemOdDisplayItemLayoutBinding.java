package com.huawei.module_checkout.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ItemOdDisplayItemLayoutBinding implements ViewBinding {
    @NonNull
    public final View getRoot() {
        return null;
    }
}
