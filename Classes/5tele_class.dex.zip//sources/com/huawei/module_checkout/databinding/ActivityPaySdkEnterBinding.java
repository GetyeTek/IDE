package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ActivityPaySdkEnterBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;

    public ActivityPaySdkEnterBinding(@NonNull LinearLayout linearLayout) {
        this.a = linearLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
