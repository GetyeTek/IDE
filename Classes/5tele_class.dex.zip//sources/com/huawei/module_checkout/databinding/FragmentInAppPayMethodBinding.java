package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class FragmentInAppPayMethodBinding implements ViewBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final LoadingButton c;
    @NonNull
    public final RecyclerView d;

    public FragmentInAppPayMethodBinding(@NonNull RoundConstraintLayout roundConstraintLayout, @NonNull ImageView imageView, @NonNull LoadingButton loadingButton, @NonNull RecyclerView recyclerView) {
        this.a = roundConstraintLayout;
        this.b = imageView;
        this.c = loadingButton;
        this.d = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
