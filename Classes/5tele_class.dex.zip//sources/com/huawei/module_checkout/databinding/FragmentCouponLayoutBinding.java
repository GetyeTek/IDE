package com.huawei.module_checkout.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;

public final class FragmentCouponLayoutBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final RecyclerView b;

    public FragmentCouponLayoutBinding(@NonNull ConstraintLayout constraintLayout, @NonNull RecyclerView recyclerView) {
        this.a = constraintLayout;
        this.b = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
