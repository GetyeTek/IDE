package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivitySendMoneyInputPhoneBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final CycleViewPager c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final ImageView e;
    @NonNull
    public final ImageView f;
    @NonNull
    public final LinearLayout g;
    @NonNull
    public final CommonInputView h;
    @NonNull
    public final RoundRecyclerView i;

    public ActivitySendMoneyInputPhoneBinding(@NonNull ConstraintLayout constraintLayout, @NonNull LoadingButton loadingButton, @NonNull CycleViewPager cycleViewPager, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull ImageView imageView3, @NonNull LinearLayout linearLayout, @NonNull CommonInputView commonInputView, @NonNull RoundRecyclerView roundRecyclerView) {
        this.a = constraintLayout;
        this.b = loadingButton;
        this.c = cycleViewPager;
        this.d = imageView;
        this.e = imageView2;
        this.f = imageView3;
        this.g = linearLayout;
        this.h = commonInputView;
        this.i = roundRecyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
