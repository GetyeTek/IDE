package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentContainerView;
import androidx.viewbinding.ViewBinding;

public final class ActivityCheckStandBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final LinearLayout b;
    @NonNull
    public final FragmentContainerView c;

    public ActivityCheckStandBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull FragmentContainerView fragmentContainerView) {
        this.a = linearLayout;
        this.b = linearLayout2;
        this.c = fragmentContainerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
