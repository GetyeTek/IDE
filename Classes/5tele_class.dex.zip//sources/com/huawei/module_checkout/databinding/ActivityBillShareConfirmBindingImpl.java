package com.huawei.module_checkout.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.module_checkout.R$id;

public class ActivityBillShareConfirmBindingImpl extends ActivityBillShareConfirmBinding {
    @Nullable
    public static final SparseIntArray h;
    public long g;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        h = sparseIntArray;
        sparseIntArray.put(R$id.ivAvatar, 1);
        sparseIntArray.put(R$id.tvName, 2);
        sparseIntArray.put(R$id.currencylayout, 3);
        sparseIntArray.put(R$id.tvAmount, 4);
        sparseIntArray.put(R$id.tvCurrency, 5);
        sparseIntArray.put(R$id.recycler_view, 6);
        sparseIntArray.put(R$id.ll_button, 7);
        sparseIntArray.put(R$id.btn_confirm, 8);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.g = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.g != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.g = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
