package com.huawei.module_checkout.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.module_checkout.R$id;

public class ActivityCheckstandOdComfirmBindingImpl extends ActivityCheckstandOdComfirmBinding {
    @Nullable
    public static final SparseIntArray g;
    public long f;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.tvTitle, 1);
        sparseIntArray.put(R$id.tvAmount, 2);
        sparseIntArray.put(R$id.tvUnit, 3);
        sparseIntArray.put(R$id.recyclerview, 4);
        sparseIntArray.put(R$id.ll_btn, 5);
        sparseIntArray.put(R$id.btn_next, 6);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.f = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.f != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.f = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
