package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView;
import com.huawei.module_checkout.view.CheckOutPinEditText;

public final class FragmentCheckOutBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final CheckOutPinEditText b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final LinearLayout d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final VirtualKeyboardView k;

    public FragmentCheckOutBinding(@NonNull ConstraintLayout constraintLayout, @NonNull CheckOutPinEditText checkOutPinEditText, @NonNull ImageView imageView, @NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull VirtualKeyboardView virtualKeyboardView) {
        this.a = constraintLayout;
        this.b = checkOutPinEditText;
        this.c = imageView;
        this.d = linearLayout;
        this.e = textView;
        this.f = textView2;
        this.g = textView3;
        this.h = textView4;
        this.i = textView5;
        this.j = textView6;
        this.k = virtualKeyboardView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
