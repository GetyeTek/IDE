package com.huawei.module_checkout.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class ActivityCheckstandOdComfirmBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final HFRecyclerView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public ActivityCheckstandOdComfirmBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, HFRecyclerView hFRecyclerView, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = hFRecyclerView;
        this.c = textView;
        this.d = textView2;
        this.e = textView3;
    }
}
