package com.huawei.module_checkout.startpay.activity;

import android.os.Bundle;
import android.text.TextUtils;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.R$string;
import i7.C0013a;

public final /* synthetic */ class a implements Observer {
    public final /* synthetic */ StartPayEnterActivity a;

    public /* synthetic */ a(StartPayEnterActivity startPayEnterActivity) {
        this.a = startPayEnterActivity;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [android.content.Context, com.huawei.module_checkout.startpay.activity.StartPayEnterActivity, java.lang.Object, android.app.Activity] */
    public final void onChanged(Object obj) {
        CheckoutResp checkoutResp = (CheckoutResp) obj;
        int i = StartPayEnterActivity.q;
        ? r0 = this.a;
        r0.getClass();
        if (checkoutResp != null) {
            Bundle bundle = new Bundle();
            bundle.putString("appId", r0.k);
            bundle.putString("merchCode", r0.l);
            String prepayId = checkoutResp.getPrepayId();
            r0.m = prepayId;
            bundle.putString("prepayId", prepayId);
            bundle.putString("tradeType", r0.tradeType);
            bundle.putString("buttonText", r0.getString(R$string.pay));
            bundle.putString("rawRequest", r0.rawRequest);
            bundle.putBoolean("showPopDialog", r0.showPopDialog);
            if (!TextUtils.isEmpty(r0.h5BusinessType)) {
                r0.businessType = r0.h5BusinessType;
            }
            bundle.putString("businessType", r0.businessType);
            bundle.putBoolean("useMiniResultFlag", r0.p);
            bundle.putBoolean("isAsyncTransaction", r0.o);
            bundle.putSerializable("CheckoutResp", checkoutResp);
            C0013a.C0002a.a.a(r0, "/checkoutModule/h5PayCheckStand", bundle, new c(r0));
        }
    }
}
