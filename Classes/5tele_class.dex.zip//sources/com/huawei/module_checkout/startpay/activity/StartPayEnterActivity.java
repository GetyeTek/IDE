package com.huawei.module_checkout.startpay.activity;

import C7.a;
import C7.b;
import O6.e;
import V1.h;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.A;
import com.google.android.gms.measurement.internal.c;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.httplib.bean.StartPayResp;
import com.huawei.module_checkout.R$anim;
import com.huawei.module_checkout.startpay.viewmodel.StartPayEnterViewModel;
import java.util.HashMap;

@Route(path = "/checkoutModule/startPay")
public class StartPayEnterActivity extends BaseMvvmActivity<StartPayEnterViewModel> {
    public static final /* synthetic */ int q = 0;
    @Autowired(name = "businessType")
    String businessType;
    @Autowired(name = "h5BusinessType")
    String h5BusinessType;
    @Autowired(name = "isJump")
    boolean isJump;
    public String k;
    public String l;
    public String m;
    public StartPayResp n;
    public boolean o;
    public boolean p;
    @Autowired(name = "rawRequest")
    String rawRequest;
    @Autowired(name = "showPopDialog")
    boolean showPopDialog;
    @Autowired(name = "tradeType")
    String tradeType = "InApp";

    public final void D0() {
    }

    public final ViewBinding K0() {
        return null;
    }

    public final void U0() {
        StartPayEnterActivity.super.U0();
        this.i.g.observe(this, new a(this));
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.module_checkout.startpay.activity.StartPayEnterActivity, java.lang.Object, android.app.Activity] */
    public final void W0(int i, String str) {
        HashMap a = c.a("result", "fail", "resultCode", "-1");
        a.put("message", str);
        a.put("errorCode", String.valueOf(i));
        Intent intent = new Intent();
        intent.putExtra("result", a);
        intent.putExtra("businessType", this.businessType);
        intent.putExtra("isJump", this.isJump);
        setResult(i, intent);
        A.h(new e(this, 2), 500);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.module_checkout.startpay.activity.StartPayEnterActivity, android.app.Activity] */
    public final void finish() {
        StartPayEnterActivity.super.finish();
        int i = R$anim.anim_silent;
        overridePendingTransition(i, i);
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [androidx.lifecycle.LifecycleOwner, com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, com.huawei.module_checkout.startpay.activity.StartPayEnterActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        StartPayEnterActivity.super.onCreate(bundle);
        StartPayResp serializableExtra = getIntent().getSerializableExtra("startPayResp");
        this.n = serializableExtra;
        if (serializableExtra != null) {
            try {
                this.rawRequest = serializableExtra.getRawRequest();
                this.showPopDialog = this.n.isShowPopDialog();
                this.o = this.n.isAsyncTransaction();
                this.p = this.n.isUseMiniResultFlag();
                this.businessType = this.n.getBusinessType();
            } catch (Exception unused) {
                h.b();
                W0(3, "params error");
            }
        }
        for (String split : this.rawRequest.split("&")) {
            String[] split2 = split.split("=");
            if ("appid".equalsIgnoreCase(split2[0])) {
                this.k = split2[1];
            }
            if ("merch_code".equalsIgnoreCase(split2[0])) {
                this.l = split2[1];
            }
        }
        h.b();
        h.b();
        h.b();
        if (TextUtils.isEmpty(this.tradeType)) {
            this.tradeType = "InApp";
        }
        StartPayEnterViewModel startPayEnterViewModel = this.i;
        String str = this.tradeType;
        String str2 = this.rawRequest;
        startPayEnterViewModel.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("rawRequest", str2);
        hashMap.put("tradeType", str);
        b bVar = startPayEnterViewModel.i;
        bVar.getClass();
        startPayEnterViewModel.b(new a(bVar, hashMap, 0).a, new D7.a(startPayEnterViewModel));
        this.i.h.observe(this, new b(this, 0));
    }
}
