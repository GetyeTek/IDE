package com.huawei.module_checkout.startpay.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class StartPayEnterActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.module_checkout.startpay.activity.StartPayEnterActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (StartPayEnterActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.rawRequest;
        } else {
            str = r4.getIntent().getExtras().getString("rawRequest", r4.rawRequest);
        }
        r4.rawRequest = str;
        r4.showPopDialog = r4.getIntent().getBooleanExtra("showPopDialog", r4.showPopDialog);
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.tradeType;
        } else {
            str2 = r4.getIntent().getExtras().getString("tradeType", r4.tradeType);
        }
        r4.tradeType = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.businessType;
        } else {
            str3 = r4.getIntent().getExtras().getString("businessType", r4.businessType);
        }
        r4.businessType = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.h5BusinessType;
        } else {
            str4 = r4.getIntent().getExtras().getString("h5BusinessType", r4.h5BusinessType);
        }
        r4.h5BusinessType = str4;
        r4.isJump = r4.getIntent().getBooleanExtra("isJump", r4.isJump);
    }
}
