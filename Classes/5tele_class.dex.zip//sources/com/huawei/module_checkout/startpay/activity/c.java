package com.huawei.module_checkout.startpay.activity;

import android.content.Intent;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import i7.C0013a;
import java.util.HashMap;

public final class c implements C0013a.b<TransferResp> {
    public final /* synthetic */ StartPayEnterActivity a;

    public c(StartPayEnterActivity startPayEnterActivity) {
        this.a = startPayEnterActivity;
    }

    public final void a(int i, String str) {
        this.a.W0(i, str);
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
        this.a.W0(2, "cancel");
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.module_checkout.startpay.activity.StartPayEnterActivity, java.lang.Object, android.app.Activity] */
    public final void onSuccess(Object obj) {
        TransferResp transferResp = (TransferResp) obj;
        ? r0 = this.a;
        r0.getClass();
        HashMap hashMap = new HashMap();
        hashMap.put("result", "success");
        hashMap.put("resultCode", "1");
        hashMap.put("prepayId", r0.m);
        hashMap.put("referenceData", transferResp.getReferenceData());
        Intent intent = new Intent();
        intent.putExtra("result", hashMap);
        intent.putExtra("businessType", r0.businessType);
        intent.putExtra("isJump", r0.isJump);
        intent.putExtra("TransferResp", transferResp);
        r0.setResult(-1, intent);
        r0.finish();
    }
}
