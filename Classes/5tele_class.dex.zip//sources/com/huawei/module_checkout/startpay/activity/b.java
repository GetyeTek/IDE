package com.huawei.module_checkout.startpay.activity;

import V7.c;
import V7.f;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.saving.activity.LockedSavingAccountActivity;
import java.util.List;

public final /* synthetic */ class b implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ AppCompatActivity b;

    public /* synthetic */ b(AppCompatActivity appCompatActivity, int i) {
        this.a = i;
        this.b = appCompatActivity;
    }

    public final void onChanged(Object obj) {
        LockedSavingAccountActivity lockedSavingAccountActivity = this.b;
        switch (this.a) {
            case 0:
                int i = StartPayEnterActivity.q;
                StartPayEnterActivity startPayEnterActivity = (StartPayEnterActivity) lockedSavingAccountActivity;
                startPayEnterActivity.getClass();
                startPayEnterActivity.W0(4, ((BaseException) obj).getMessage());
                return;
            default:
                c cVar = (c) obj;
                int i2 = LockedSavingAccountActivity.j;
                LockedSavingAccountActivity lockedSavingAccountActivity2 = lockedSavingAccountActivity;
                f.b(lockedSavingAccountActivity2, cVar);
                if (cVar.b()) {
                    f.c(cVar);
                    lockedSavingAccountActivity2.f.a(3);
                    return;
                } else if (cVar.f()) {
                    lockedSavingAccountActivity2.d.submitList((List) cVar.c);
                    if (lockedSavingAccountActivity2.d.getItemCount() == 0) {
                        lockedSavingAccountActivity2.f.a(4);
                        return;
                    } else {
                        lockedSavingAccountActivity2.f.a(2);
                        return;
                    }
                } else {
                    return;
                }
        }
    }
}
