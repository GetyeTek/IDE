package com.huawei.module_checkout.startpay.viewmodel;

import C7.b;
import androidx.lifecycle.MutableLiveData;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;

public class StartPayEnterViewModel extends BaseViewModel {
    public final MutableLiveData<CheckoutResp> g = new MutableLiveData<>();
    public final MutableLiveData<BaseException> h = new MutableLiveData<>();
    public final b i = new b();
}
