package M6;

import I3.c;
import android.view.View;
import androidx.fragment.app.FragmentActivity;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.login_module.login.LoginFirstActivity;
import com.huawei.http.b;
import java.util.List;

public final /* synthetic */ class a implements OnItemClickListener {
    public final /* synthetic */ c a;
    public final /* synthetic */ String b;
    public final /* synthetic */ LoginFirstActivity.a c;

    public /* synthetic */ a(c cVar, String str, LoginFirstActivity.a aVar) {
        this.a = cVar;
        this.b = str;
        this.c = aVar;
    }

    public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        c cVar = this.a;
        cVar.dismiss();
        String currentLang = LanguageUtils.getInstance().getCurrentLang();
        List<LanguageListBean.LanguageBean> list = cVar.c;
        if (!currentLang.equals(list.get(i).getLanguageCode())) {
            LanguageListBean.LanguageBean languageBean = list.get(i);
            LoginFirstActivity.a aVar = this.c;
            FragmentActivity fragmentActivity = cVar.a;
            if (languageBean != null && !"/loginModule/login".equals(this.b)) {
                String languageCode = languageBean.getLanguageCode();
                b bVar = new b();
                bVar.addParams("newLanguage", languageCode);
                DialogManager.c(fragmentActivity);
                bVar.sendRequest(new b(cVar, languageBean, aVar));
            } else if (!LanguageUtils.getInstance().getCurrentLang().equals(list.get(i).getLanguageCode())) {
                b8.b.a(LanguageUtils.getInstance().getCurrentLang(), languageBean.getLanguageCode());
                LanguageUtils.getInstance().setLanguage(fragmentActivity, list.get(i).getLanguageCode());
                c.b();
                if (aVar != null) {
                    aVar.onSuccess((Object) null);
                }
            }
        }
    }
}
