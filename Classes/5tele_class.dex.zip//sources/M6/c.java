package M6;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.login_module.login.LoginFirstActivity;
import com.huawei.module_basic_ui.R$color;
import com.huawei.module_basic_ui.R$layout;
import com.huawei.module_basic_ui.databinding.LanguagePopLayoutBinding;
import java.util.List;

public final class c extends PopupWindow {
    public final FragmentActivity a;
    public final int b = (v.a(120.0f) * 5);
    public final List<LanguageListBean.LanguageBean> c;

    public static class a extends BaseQuickAdapter<LanguageListBean.LanguageBean, BaseViewHolder> {
        public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
            DataBindingUtil.bind(baseViewHolder.itemView).a.setText(((LanguageListBean.LanguageBean) obj).getLanguage());
        }
    }

    public c(FragmentActivity fragmentActivity, String str, LoginFirstActivity.a aVar) {
        super(fragmentActivity);
        this.a = a(fragmentActivity);
        LanguagePopLayoutBinding inflate = DataBindingUtil.inflate(LayoutInflater.from(fragmentActivity), R$layout.language_pop_layout, (ViewGroup) null, false);
        setContentView(inflate.getRoot());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(fragmentActivity);
        RoundRecyclerView roundRecyclerView = inflate.a;
        roundRecyclerView.setLayoutManager(linearLayoutManager);
        List<LanguageListBean.LanguageBean> languageConfig = LanguageUtils.getInstance().getLanguageConfig();
        this.c = languageConfig;
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_language_menu_pop, languageConfig);
        baseQuickAdapter.setOnItemClickListener(new a(this, str, aVar));
        roundRecyclerView.setAdapter(baseQuickAdapter);
        roundRecyclerView.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(fragmentActivity, R$color.colorDividerLight), v.a(1.0f)));
    }

    public static FragmentActivity a(Context context) {
        if (context == null) {
            return null;
        }
        if (context instanceof FragmentActivity) {
            return (FragmentActivity) context;
        }
        if (context instanceof ContextWrapper) {
            return a(((ContextWrapper) context).getBaseContext());
        }
        return null;
    }

    public final void b() {
        setHeight(v.a(150.0f));
        setHeight(this.b);
        setBackgroundDrawable(new ColorDrawable(16777215));
        setFocusable(true);
        setOutsideTouchable(true);
        FragmentActivity fragmentActivity = this.a;
        if (fragmentActivity != null) {
            Window window = fragmentActivity.getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.alpha = 0.5f;
            window.addFlags(2);
            window.setAttributes(attributes);
        }
        setInputMethodMode(1);
        setSoftInputMode(16);
    }

    public final void dismiss() {
        super.dismiss();
        FragmentActivity fragmentActivity = this.a;
        if (fragmentActivity != null) {
            Window window = fragmentActivity.getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.alpha = 1.0f;
            window.addFlags(2);
            window.setAttributes(attributes);
        }
    }

    public final void showAsDropDown(View view) {
        b();
        super.showAsDropDown(view);
    }

    public final void showAtLocation(View view, int i, int i2, int i3) {
        b();
        super.showAtLocation(view, i, i2, i3);
    }

    public final void showAsDropDown(View view, int i, int i2, int i3) {
        b();
        super.showAsDropDown(view, i, i2, i3);
    }

    public final void showAsDropDown(View view, int i, int i2) {
        b();
        super.showAsDropDown(view, i, i2);
    }
}
