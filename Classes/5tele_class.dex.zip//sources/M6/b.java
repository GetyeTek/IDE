package M6;

import E0.c;
import R1.a;
import S1.f;
import V1.k;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.httplib.response.LoginResp;
import com.huawei.digitalpayment.customer.login_module.login.LoginFirstActivity;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.module_basic_ui.language.LanguageViewModel;
import java.util.Map;

public final class b implements a<LoginResp> {
    public final /* synthetic */ LanguageListBean.LanguageBean a;
    public final /* synthetic */ LoginFirstActivity.a b;
    public final /* synthetic */ c c;

    public b(c cVar, LanguageListBean.LanguageBean languageBean, LoginFirstActivity.a aVar) {
        this.c = cVar;
        this.a = languageBean;
        this.b = aVar;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final void onError(BaseException baseException) {
        DialogManager.a(this.c.a);
        k.b(1, baseException.getMessage());
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    /* JADX WARNING: type inference failed for: r1v7, types: [R1.a, java.lang.Object] */
    public final void onSuccess(Object obj) {
        LoginResp loginResp = (LoginResp) obj;
        c cVar = this.c;
        DialogManager.a(cVar.a);
        String currentLang = LanguageUtils.getInstance().getCurrentLang();
        LanguageListBean.LanguageBean languageBean = this.a;
        boolean equals = currentLang.equals(languageBean.getLanguageCode());
        FragmentActivity fragmentActivity = cVar.a;
        if (!equals) {
            if (c.g()) {
                b8.b.d(LanguageUtils.getInstance().getCurrentLang());
                b8.b.b(languageBean.getLanguageCode());
            }
            b8.b.a(LanguageUtils.getInstance().getCurrentLang(), languageBean.getLanguageCode());
            LanguageUtils.getInstance().setLanguage(fragmentActivity, languageBean.getLanguageCode());
            if (loginResp != null) {
                loginResp.setHasFillQuestion(true);
                f.b.a(fragmentActivity, com.blankj.utilcode.util.k.d(loginResp), false);
            }
            Class<AppService> cls = AppService.class;
            o0.b.c(cls).m();
            o0.b.c(cls).i();
            I3.c.b();
            Bundle bundle = new Bundle(1);
            bundle.putBoolean("goHome", true);
            o0.b.d(fragmentActivity, "/mainModule/main", bundle, (Map) null);
            fragmentActivity.overridePendingTransition(0, 0);
        }
        Q6.b bVar = new Q6.b();
        bVar.a(new Q6.a());
        LanguageViewModel languageViewModel = new ViewModelProvider(fragmentActivity).get(LanguageViewModel.class);
        languageViewModel.c(languageViewModel.g.a(bVar), new Object());
        LoginFirstActivity.a aVar = this.b;
        if (aVar != null) {
            aVar.onSuccess((Object) null);
        }
    }
}
