package V6;

import android.os.Bundle;
import android.view.View;
import com.huawei.common.widget.dialog.SetAmountPop;
import com.huawei.digitalpayment.customer.login_module.widget.NationalIDSelectDialog;
import com.huawei.kbz.chat.contact.ChatSettingActivity;
import com.huawei.module_cash.chapa.activity.CashInViaChapaActivity;
import com.huawei.requestmoney.R;
import com.huawei.requestmoney.RequestMoneyDetailActivity;
import com.huawei.requestmoney.view.TypeSelectView;
import java.util.Map;
import kotlin.jvm.internal.h;
import o0.b;

public final /* synthetic */ class d implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ d(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                CashInViaChapaActivity cashInViaChapaActivity = (CashInViaChapaActivity) obj;
                cashInViaChapaActivity.k.e(cashInViaChapaActivity);
                return;
            case 1:
                ((SetAmountPop) obj).a.d.setVisibility(8);
                return;
            case 2:
                int i = ChatSettingActivity.c;
                ChatSettingActivity chatSettingActivity = (ChatSettingActivity) obj;
                chatSettingActivity.getClass();
                b.d(chatSettingActivity, "/chat/photo_profile", (Bundle) null, (Map) null);
                return;
            case 3:
                int i2 = RequestMoneyDetailActivity.i;
                RequestMoneyDetailActivity requestMoneyDetailActivity = (RequestMoneyDetailActivity) obj;
                requestMoneyDetailActivity.E0(view, requestMoneyDetailActivity.getResources().getString(R.string.do_you_want_to_cancel_the_request_order));
                return;
            case 4:
                ((NationalIDSelectDialog) obj).getClass();
                throw null;
            default:
                int i3 = TypeSelectView.C0;
                TypeSelectView typeSelectView = (TypeSelectView) obj;
                h.f(typeSelectView, "this$0");
                typeSelectView.e();
                return;
        }
    }
}
