package V6;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.MerchantAppIdBean;
import com.huawei.module_cash.chapa.activity.CashInViaChapaActivity;
import java.util.Map;
import o0.b;

public final /* synthetic */ class a implements View.OnClickListener {
    public final void onClick(View view) {
        MerchantAppIdBean.FeedbackBean feedbackBean;
        int i = CashInViaChapaActivity.l;
        MerchantAppIdBean merchantAppIdConfig = BasicConfig.getInstance().getMerchantAppIdConfig();
        if (merchantAppIdConfig != null) {
            feedbackBean = merchantAppIdConfig.getChapa();
        } else {
            feedbackBean = null;
        }
        if (feedbackBean != null) {
            b.d((Activity) null, feedbackBean.getAppId(), (Bundle) null, (Map) null);
        }
    }
}
