package V6;

import android.view.MotionEvent;
import android.view.View;
import androidx.core.view.DragStartHelper;
import com.blankj.utilcode.util.l;
import com.huawei.common.widget.dialog.SetAmountPop;
import com.huawei.module_cash.chapa.activity.CashInViaChapaActivity;

public final /* synthetic */ class e implements View.OnTouchListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ e(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = CashInViaChapaActivity.l;
                CashInViaChapaActivity cashInViaChapaActivity = (CashInViaChapaActivity) obj;
                cashInViaChapaActivity.getClass();
                if (motionEvent.getAction() == 0) {
                    if (cashInViaChapaActivity.k.isShowing()) {
                        cashInViaChapaActivity.k.c();
                    }
                    l.b(view);
                    cashInViaChapaActivity.i.d.requestFocus();
                    cashInViaChapaActivity.i.d.setFocusableInTouchMode(true);
                }
                return false;
            case 1:
                SetAmountPop setAmountPop = (SetAmountPop) obj;
                setAmountPop.getClass();
                if (motionEvent.getAction() == 0) {
                    l.b(view);
                    setAmountPop.a.b.requestFocus();
                    setAmountPop.a.b.setFocusableInTouchMode(true);
                    setAmountPop.a.d.setVisibility(0);
                }
                return false;
            default:
                return ((DragStartHelper) obj).onTouch(view, motionEvent);
        }
    }
}
