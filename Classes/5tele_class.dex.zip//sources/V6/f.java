package V6;

import O2.a;
import W2.g;
import com.huawei.module_cash.chapa.activity.CashInViaChapaActivity;

public final class f extends a {
    public final /* synthetic */ CashInViaChapaActivity b;

    public f(CashInViaChapaActivity cashInViaChapaActivity) {
        super(1);
        this.b = cashInViaChapaActivity;
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        CashInViaChapaActivity cashInViaChapaActivity = this.b;
        cashInViaChapaActivity.k.d(g.a(charSequence.toString()));
        cashInViaChapaActivity.i.b.setEnabled(g.a(charSequence.toString()));
    }
}
