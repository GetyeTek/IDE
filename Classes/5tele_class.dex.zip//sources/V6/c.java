package V6;

import android.view.KeyEvent;
import c2.e;
import com.huawei.module_cash.chapa.activity.CashInViaChapaActivity;

public final /* synthetic */ class c implements e {
    public final /* synthetic */ KeyEvent.Callback a;

    public /* synthetic */ c(KeyEvent.Callback callback) {
        this.a = callback;
    }

    public void dispatchKeyEvent(KeyEvent keyEvent) {
        int i = CashInViaChapaActivity.l;
        CashInViaChapaActivity cashInViaChapaActivity = (CashInViaChapaActivity) this.a;
        if (66 == keyEvent.getKeyCode()) {
            cashInViaChapaActivity.k.c();
        }
    }
}
