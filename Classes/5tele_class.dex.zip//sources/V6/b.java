package V6;

import W2.g;
import Z7.d;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import com.huawei.common.widget.dialog.AddNoteDialog;
import com.huawei.digitalpayment.customer.login_module.upgrade.UpgradeActivity;
import com.huawei.kbz.chat.contact.ChatSettingActivity;
import com.huawei.module_cash.chapa.activity.CashInViaChapaActivity;
import com.huawei.module_checkout.p2ptransfer.activity.P2PTransferPayActivity;
import com.huawei.requestmoney.view.TypeSelectView;
import g1.j;
import java.util.Locale;
import java.util.Map;
import kotlin.jvm.internal.h;

public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ b(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    /* JADX WARNING: type inference failed for: r2v2, types: [com.huawei.module_cash.chapa.activity.CashInViaChapaActivity, android.app.Activity] */
    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                ? r2 = (CashInViaChapaActivity) obj;
                if (g.a(r2.i.c.getEditableText().toString())) {
                    Bundle bundle = new Bundle(1);
                    bundle.putString("amount", String.format(Locale.ENGLISH, "%.2f", new Object[]{Double.valueOf(Double.parseDouble(r2.i.c.getEditableText().toString()))}));
                    o0.b.e(r2, "/cashModule/cashInputPin", bundle, (Map) null, 0, 1001);
                    return;
                }
                return;
            case 1:
                ((AddNoteDialog) obj).dismiss();
                return;
            case 2:
                ((d) obj).dismiss();
                return;
            case 3:
                UpgradeActivity upgradeActivity = (UpgradeActivity) obj;
                upgradeActivity.k = false;
                upgradeActivity.l = true;
                upgradeActivity.m = false;
                upgradeActivity.X0();
                return;
            case 4:
                int i = ChatSettingActivity.c;
                o0.b.d((ChatSettingActivity) obj, "/chat/my_qrcode", (Bundle) null, (Map) null);
                return;
            case 5:
                P2PTransferPayActivity p2PTransferPayActivity = (P2PTransferPayActivity) obj;
                p2PTransferPayActivity.p.e(p2PTransferPayActivity);
                return;
            case 6:
                ((Dialog) obj).dismiss();
                j.a(w0.g.a, w0.g.e(), "user cancel selection operation.");
                return;
            default:
                int i2 = TypeSelectView.C0;
                TypeSelectView typeSelectView = (TypeSelectView) obj;
                h.f(typeSelectView, "this$0");
                typeSelectView.c();
                return;
        }
    }
}
