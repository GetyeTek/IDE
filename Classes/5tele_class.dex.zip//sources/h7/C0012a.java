package h7;

import L3.a;
import androidx.appcompat.app.AppCompatActivity;
import com.huawei.digitalpayment.customer.httplib.request.TransferRequest;
import com.huawei.module_checkout.CheckOutFragment;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import d7.C0007a;
import d7.c;

/* renamed from: h7.a  reason: case insensitive filesystem */
public final /* synthetic */ class C0012a implements CheckOutFragment.a {
    public final /* synthetic */ b a;
    public final /* synthetic */ AppCompatActivity b;
    public final /* synthetic */ TradeTypeEnum c;

    public /* synthetic */ C0012a(b bVar, AppCompatActivity appCompatActivity, TradeTypeEnum tradeTypeEnum) {
        this.a = bVar;
        this.b = appCompatActivity;
        this.c = tradeTypeEnum;
    }

    public final void a(String str, String str2) {
        b bVar = this.a;
        String g = a.g(str);
        d dVar = bVar.i;
        dVar.getClass();
        c cVar = c.b;
        L2.c.a.getClass();
        dVar.a(((C0007a) cVar.c("https://www.superapp.ethiomobilemoney.et:38443/appgateway/consumer/appserver/consumer/").b(C0007a.class)).b(this.c.getTransferParam(), new TransferRequest(str2, g)), new c(dVar, (P2.a) dVar.a, this.b));
    }
}
