package h7;

import L2.b;
import P2.a;
import android.app.Activity;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.CheckOutFragment;

public final class c extends b<TransferResp> {
    public final /* synthetic */ Activity f;
    public final /* synthetic */ d g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c(d dVar, a aVar, Activity activity) {
        super(aVar, true);
        this.g = dVar;
        this.f = activity;
    }

    public final void b(String str) {
        CheckOutFragment checkOutFragment = this.g.c;
        if (checkOutFragment != null) {
            checkOutFragment.v0();
        }
    }

    public final void c(Object obj) {
        this.g.c.dismiss();
        n.a.b().getClass();
        n.a.a("/basicUiModule/commonSuccess").withObject("transferResp", (TransferResp) obj).navigation();
        this.f.finish();
    }
}
