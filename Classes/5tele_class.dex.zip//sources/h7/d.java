package h7;

import A8.c;
import P2.a;
import androidx.appcompat.app.AppCompatActivity;
import com.huawei.module_checkout.CheckOutFragment;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import d7.C0007a;
import java.util.HashMap;

public final class d<T extends a> extends c {
    public CheckOutFragment c;

    public d() {
        throw null;
    }

    public final void b(AppCompatActivity appCompatActivity, TradeTypeEnum tradeTypeEnum, HashMap hashMap) {
        d7.c cVar = d7.c.b;
        L2.c.a.getClass();
        a(((C0007a) cVar.c("https://www.superapp.ethiomobilemoney.et:38443/appgateway/consumer/appserver/consumer/").b(C0007a.class)).a(tradeTypeEnum.getCheckoutParam(), hashMap), new b(this, (a) this.a, tradeTypeEnum, hashMap, appCompatActivity));
    }
}
