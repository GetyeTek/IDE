package h7;

import P2.a;
import W2.n;
import android.text.TextUtils;
import androidx.appcompat.app.AppCompatActivity;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.ParameterLimitBean;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.module_checkout.CheckOutFragment;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import java.util.HashMap;
import java.util.List;

public final class b extends L2.b<CheckoutResp> {
    public final /* synthetic */ TradeTypeEnum f;
    public final /* synthetic */ HashMap g;
    public final /* synthetic */ AppCompatActivity h;
    public final /* synthetic */ d i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public b(d dVar, a aVar, TradeTypeEnum tradeTypeEnum, HashMap hashMap, AppCompatActivity appCompatActivity) {
        super(aVar, true);
        this.i = dVar;
        this.f = tradeTypeEnum;
        this.g = hashMap;
        this.h = appCompatActivity;
    }

    public final void b(String str) {
        CheckOutFragment checkOutFragment = this.i.c;
        if (checkOutFragment != null) {
            checkOutFragment.v0();
        }
    }

    public final void c(Object obj) {
        CheckoutResp checkoutResp = (CheckoutResp) obj;
        boolean isConfirm = checkoutResp.isConfirm();
        n.b("");
        n.j(checkoutResp, "checkoutresp");
        TradeTypeEnum tradeTypeEnum = this.f;
        if (isConfirm) {
            n.a.b().getClass();
            n.a.a("/checkoutModule/odPayment").withObject("checkOutResp", checkoutResp).withString("transferPath", tradeTypeEnum.getTransferParam()).withString("checkoutPath", tradeTypeEnum.getCheckoutParam()).withString("tradeType", (String) this.g.get("tradeType")).withString("from", d.class.getSimpleName()).navigation();
            return;
        }
        checkoutResp.getBalanceDisplay();
        String actualAmountDisplay = checkoutResp.getActualAmountDisplay();
        String subTitle = checkoutResp.getSubTitle();
        String currency = checkoutResp.getCurrency();
        String unit = checkoutResp.getUnit();
        String unitType = checkoutResp.getUnitType();
        List<String> displayItems = checkoutResp.getDisplayItems();
        String prepayId = checkoutResp.getPrepayId();
        checkoutResp.getBalanceDisplay();
        ParameterLimitBean parameterLimit = BasicConfig.getInstance().getParameterLimit();
        int i2 = 6;
        if (parameterLimit != null) {
            String pinLimit = parameterLimit.getPinLimit();
            if (!TextUtils.isEmpty(pinLimit)) {
                try {
                    i2 = Integer.parseInt(pinLimit);
                } catch (Exception unused) {
                }
            }
        }
        AppCompatActivity appCompatActivity = this.h;
        C0012a aVar = new C0012a(this, appCompatActivity, tradeTypeEnum);
        CheckOutFragment checkOutFragment = new CheckOutFragment();
        TextUtils.isEmpty((CharSequence) null);
        TextUtils.isEmpty(currency);
        checkOutFragment.e = aVar;
        checkOutFragment.c = actualAmountDisplay;
        checkOutFragment.b = displayItems;
        checkOutFragment.d = prepayId;
        checkOutFragment.a = subTitle;
        checkOutFragment.g = null;
        checkOutFragment.h = unit;
        checkOutFragment.i = unitType;
        checkOutFragment.j = i2;
        this.i.c = checkOutFragment;
        checkOutFragment.show(appCompatActivity.getSupportFragmentManager(), tradeTypeEnum.getCheckoutParam());
    }
}
