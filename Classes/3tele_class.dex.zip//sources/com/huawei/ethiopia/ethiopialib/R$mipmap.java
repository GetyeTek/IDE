package com.huawei.ethiopia.ethiopialib;

public final class R$mipmap {
    public static final int base_ic_loading = 2131755048;
    public static final int common_icon_arrow_right = 2131755164;
    public static final int common_icon_back = 2131755165;
    public static final int common_icon_eye_close = 2131755166;
    public static final int common_icon_eye_open = 2131755167;
    public static final int common_icon_hide_key_broad = 2131755168;
    public static final int common_icon_input_clear = 2131755169;
    public static final int common_icon_input_error = 2131755170;
    public static final int common_icon_input_select = 2131755171;
    public static final int common_icon_loading_button_loading = 2131755172;
    public static final int common_keyboard_icon_delete = 2131755173;
    public static final int common_spinner = 2131755176;
    public static final int ethiopia_icon_back = 2131755184;
    public static final int ethiopia_icon_hide_key_broad = 2131755185;
    public static final int ethiopia_keyboard_icon_delete = 2131755186;
    public static final int icon_no_record_yet = 2131755487;
    public static final int icon_no_wifi = 2131755488;
    public static final int icon_system_server_error = 2131755558;

    private R$mipmap() {
    }
}
