package com.huawei.ethiopia.ethiopialib;

public final class R$array {
    public static final int WheelArrayDefault = 2130903040;
    public static final int WheelArrayWeek = 2130903041;

    private R$array() {
    }
}
