package com.huawei.ethiopia.ethiopialib;

public final class R$menu {
    public static final int ucrop_menu = 2131689479;

    private R$menu() {
    }
}
