package com.huawei.ethiopia.ethiopialib;

public final class R$anim {
    public static final int abc_fade_in = 2130771968;
    public static final int abc_fade_out = 2130771969;
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    public static final int abc_popup_enter = 2130771971;
    public static final int abc_popup_exit = 2130771972;
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    public static final int abc_slide_in_bottom = 2130771974;
    public static final int abc_slide_in_top = 2130771975;
    public static final int abc_slide_out_bottom = 2130771976;
    public static final int abc_slide_out_top = 2130771977;
    public static final int abc_tooltip_enter = 2130771978;
    public static final int abc_tooltip_exit = 2130771979;
    public static final int anim_silent = 2130771996;
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130772000;
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130772001;
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130772002;
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130772003;
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130772004;
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130772005;
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130772006;
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130772007;
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130772008;
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130772009;
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130772010;
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130772011;
    public static final int design_bottom_sheet_slide_in = 2130772013;
    public static final int design_bottom_sheet_slide_out = 2130772014;
    public static final int design_snackbar_in = 2130772015;
    public static final int design_snackbar_out = 2130772016;
    public static final int dialog_pop_down = 2130772023;
    public static final int dialog_pop_up = 2130772024;
    public static final int fragment_fast_out_extra_slow_in = 2130772027;
    public static final int from_bottom_to_top = 2130772028;
    public static final int from_top_to_bottom = 2130772029;
    public static final int mtrl_bottom_sheet_slide_in = 2130772046;
    public static final int mtrl_bottom_sheet_slide_out = 2130772047;
    public static final int mtrl_card_lowers_interpolator = 2130772048;
    public static final int nav_default_enter_anim = 2130772049;
    public static final int nav_default_exit_anim = 2130772050;
    public static final int nav_default_pop_enter_anim = 2130772051;
    public static final int nav_default_pop_exit_anim = 2130772052;
    public static final int ucrop_loader_circle_path = 2130772063;
    public static final int ucrop_loader_circle_scale = 2130772064;

    private R$anim() {
    }
}
