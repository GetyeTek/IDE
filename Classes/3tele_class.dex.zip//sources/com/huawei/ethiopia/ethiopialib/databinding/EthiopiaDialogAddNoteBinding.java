package com.huawei.ethiopia.ethiopialib.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundTextView;

public final class EthiopiaDialogAddNoteBinding implements ViewBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final RoundTextView c;
    @NonNull
    public final EditText d;
    @NonNull
    public final TextView e;

    public EthiopiaDialogAddNoteBinding(@NonNull RoundConstraintLayout roundConstraintLayout, @NonNull RoundTextView roundTextView, @NonNull RoundTextView roundTextView2, @NonNull EditText editText, @NonNull TextView textView) {
        this.a = roundConstraintLayout;
        this.b = roundTextView;
        this.c = roundTextView2;
        this.d = editText;
        this.e = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
