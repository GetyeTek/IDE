package com.huawei.digitalpayment.topup.constant;

import java.io.Serializable;

public enum TopUpTradeTypeEnum implements Serializable {
    CUSTOMER_BUY_GOODS("CustomerBuyGoods", "customerBuyGoods"),
    P2P_TRANSFER("P2PTransfer", "p2pTransfer"),
    CASH_OUT("CashOut", "cashOut"),
    WITHDRAW_TO_BANK_CARD("WithdrawToBankCard", "withdrawToBankCard"),
    DEPOSIT_FROM_BANK_CARD("DepositFromBankCard", "depositFromBankCard"),
    AIR_TIME_DATA_PACK("RechargeDataPack", "rechargeDataPack"),
    AIR_TOP_UP("RechargeAirtime", "rechargeAirtime");
    
    private String checkoutParam;
    private String transferParam;

    private TopUpTradeTypeEnum(String str, String str2) {
        this.checkoutParam = str;
        this.transferParam = str2;
    }

    public String getCheckoutParam() {
        return this.checkoutParam;
    }

    public String getTransferParam() {
        return this.transferParam;
    }
}
