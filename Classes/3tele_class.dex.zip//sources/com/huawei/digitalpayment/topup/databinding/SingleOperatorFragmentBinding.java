package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;

public final class SingleOperatorFragmentBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final RecyclerView b;

    public SingleOperatorFragmentBinding(@NonNull LinearLayout linearLayout, @NonNull RecyclerView recyclerView) {
        this.a = linearLayout;
        this.b = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
