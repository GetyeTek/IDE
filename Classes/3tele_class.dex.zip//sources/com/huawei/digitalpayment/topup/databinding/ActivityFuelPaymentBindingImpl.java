package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityFuelPaymentBindingImpl extends ActivityFuelPaymentBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.ll_amount, 1);
        sparseIntArray.put(R$id.tvReceiveNum, 2);
        sparseIntArray.put(R$id.tvCurrency, 3);
        sparseIntArray.put(R$id.recyclerview, 4);
        sparseIntArray.put(R$id.ll_btn, 5);
        sparseIntArray.put(R$id.btnNext, 6);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
