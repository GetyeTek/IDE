package com.huawei.digitalpayment.topup.ui;

import V1.k;
import android.content.Intent;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.blankj.utilcode.util.e;
import com.blankj.utilcode.util.q;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.adapter.DataPackageGroupAdapter;
import com.huawei.digitalpayment.topup.bean.TopUpBean;
import com.huawei.digitalpayment.topup.databinding.SingleOperatorFragmentBinding;
import java.util.ArrayList;

public class DataPackFragment extends BaseFragment implements P2.a {
    public SingleOperatorFragmentBinding c;
    public ArrayList d;
    public DataPackageGroupAdapter e;
    public String f;
    public TopUpBean.OperatorsBean g;
    public PayLoadingDialog h;
    public b i;

    public class a implements q.a {
        public a() {
        }

        public final void a(@NonNull ArrayList arrayList) {
            DataPackFragment dataPackFragment = DataPackFragment.this;
            dataPackFragment.getClass();
            Intent intent = new Intent("android.intent.action.PICK", ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            intent.addCategory("android.intent.category.DEFAULT");
            dataPackFragment.startActivityForResult(intent, 0);
        }

        public final void b(@NonNull ArrayList arrayList) {
            e.b();
            k.b(1, DataPackFragment.this.getString(R$string.designstandard_contact__permission_required_to_get_phone_number));
        }
    }

    public interface b {
        void a(String str);
    }

    public DataPackFragment() {
        throw null;
    }

    public final void G(String str) {
        this.h.dismiss();
    }

    public final void V(String str) {
        PayLoadingDialog payLoadingDialog = new PayLoadingDialog();
        this.h = payLoadingDialog;
        payLoadingDialog.show(getChildFragmentManager(), "dataPack");
    }

    /* JADX WARNING: Removed duplicated region for block: B:32:0x0091 A[Catch:{ all -> 0x0078, all -> 0x00ac, Exception -> 0x00a4 }] */
    @android.annotation.SuppressLint({"Range"})
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onActivityResult(int r9, int r10, android.content.Intent r11) {
        /*
            r8 = this;
            java.lang.String r0 = "_id = "
            if (r9 != 0) goto L_0x00b8
            r9 = -1
            if (r10 != r9) goto L_0x00b8
            if (r11 == 0) goto L_0x00b8
            android.net.Uri r9 = r11.getData()
            if (r9 != 0) goto L_0x0011
            goto L_0x00b8
        L_0x0011:
            android.net.Uri r2 = r11.getData()
            androidx.fragment.app.FragmentActivity r9 = r8.getActivity()     // Catch:{ Exception -> 0x00a4 }
            android.content.ContentResolver r1 = r9.getContentResolver()     // Catch:{ Exception -> 0x00a4 }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            android.database.Cursor r9 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ Exception -> 0x00a4 }
            boolean r10 = r9.moveToFirst()     // Catch:{ all -> 0x0078 }
            java.lang.String r11 = ""
            if (r10 == 0) goto L_0x007e
            java.lang.String r10 = "has_phone_number"
            int r10 = r9.getColumnIndex(r10)     // Catch:{ all -> 0x0078 }
            java.lang.String r10 = r9.getString(r10)     // Catch:{ all -> 0x0078 }
            java.lang.String r1 = "_id"
            int r1 = r9.getColumnIndex(r1)     // Catch:{ all -> 0x0078 }
            java.lang.String r1 = r9.getString(r1)     // Catch:{ all -> 0x0078 }
            java.lang.String r2 = "1"
            boolean r10 = r10.equalsIgnoreCase(r2)     // Catch:{ all -> 0x0078 }
            if (r10 == 0) goto L_0x007e
            androidx.fragment.app.FragmentActivity r10 = r8.getActivity()     // Catch:{ all -> 0x0078 }
            android.content.ContentResolver r2 = r10.getContentResolver()     // Catch:{ all -> 0x0078 }
            android.net.Uri r3 = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI     // Catch:{ all -> 0x0078 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ all -> 0x0078 }
            r10.<init>(r0)     // Catch:{ all -> 0x0078 }
            r10.append(r1)     // Catch:{ all -> 0x0078 }
            java.lang.String r5 = r10.toString()     // Catch:{ all -> 0x0078 }
            r7 = 0
            r4 = 0
            r6 = 0
            android.database.Cursor r10 = r2.query(r3, r4, r5, r6, r7)     // Catch:{ all -> 0x0078 }
            r0 = r11
        L_0x0067:
            boolean r1 = r10.moveToNext()     // Catch:{ all -> 0x0078 }
            if (r1 == 0) goto L_0x007a
            java.lang.String r0 = "data1"
            int r0 = r10.getColumnIndex(r0)     // Catch:{ all -> 0x0078 }
            java.lang.String r0 = r10.getString(r0)     // Catch:{ all -> 0x0078 }
            goto L_0x0067
        L_0x0078:
            r10 = move-exception
            goto L_0x00a6
        L_0x007a:
            r10.close()     // Catch:{ all -> 0x0078 }
            goto L_0x007f
        L_0x007e:
            r0 = r11
        L_0x007f:
            boolean r10 = android.text.TextUtils.isEmpty(r0)     // Catch:{ all -> 0x0078 }
            if (r10 != 0) goto L_0x00a0
            com.huawei.digitalpayment.topup.ui.DataPackFragment$b r10 = r8.i     // Catch:{ all -> 0x0078 }
            if (r10 == 0) goto L_0x00a0
            java.util.regex.Pattern r10 = O4.b.a     // Catch:{ all -> 0x0078 }
            boolean r10 = android.text.TextUtils.isEmpty(r0)     // Catch:{ all -> 0x0078 }
            if (r10 != 0) goto L_0x009b
            java.util.regex.Pattern r10 = O4.b.a     // Catch:{ all -> 0x0078 }
            java.util.regex.Matcher r10 = r10.matcher(r0)     // Catch:{ all -> 0x0078 }
            java.lang.String r11 = r10.replaceAll(r11)     // Catch:{ all -> 0x0078 }
        L_0x009b:
            com.huawei.digitalpayment.topup.ui.DataPackFragment$b r10 = r8.i     // Catch:{ all -> 0x0078 }
            r10.a(r11)     // Catch:{ all -> 0x0078 }
        L_0x00a0:
            r9.close()     // Catch:{ Exception -> 0x00a4 }
            goto L_0x00b8
        L_0x00a4:
            r9 = move-exception
            goto L_0x00b1
        L_0x00a6:
            if (r9 == 0) goto L_0x00b0
            r9.close()     // Catch:{ all -> 0x00ac }
            goto L_0x00b0
        L_0x00ac:
            r9 = move-exception
            r10.addSuppressed(r9)     // Catch:{ Exception -> 0x00a4 }
        L_0x00b0:
            throw r10     // Catch:{ Exception -> 0x00a4 }
        L_0x00b1:
            r9.getMessage()
            V1.h.b()
        L_0x00b8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.topup.ui.DataPackFragment.onActivityResult(int, int, android.content.Intent):void");
    }

    public final void v(BaseResp baseResp) {
        k.b(1, baseResp.getResponseDesc());
    }

    public final ViewBinding v0(LayoutInflater layoutInflater) {
        View inflate = getLayoutInflater().inflate(R$layout.single_operator_fragment, (ViewGroup) null, false);
        int i2 = R$id.rv_data_package_group;
        RecyclerView findChildViewById = ViewBindings.findChildViewById(inflate, i2);
        if (findChildViewById != null) {
            SingleOperatorFragmentBinding singleOperatorFragmentBinding = new SingleOperatorFragmentBinding((LinearLayout) inflate, findChildViewById);
            this.c = singleOperatorFragmentBinding;
            return singleOperatorFragmentBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }

    public final void w0() {
    }

    public final void x0(View view) {
        this.c.b.setLayoutManager(new LinearLayoutManager(getActivity()));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_data_packge_group, this.d);
        this.e = baseQuickAdapter;
        baseQuickAdapter.a = new N4.a(this);
        this.c.b.setAdapter(baseQuickAdapter);
    }

    public final void y0() {
        if (!q.c(new String[]{"android.permission.READ_CONTACTS"})) {
            q e2 = q.e(new String[]{"android.permission.READ_CONTACTS"});
            e2.c = new a();
            e2.f();
            return;
        }
        Intent intent = new Intent("android.intent.action.PICK", ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        intent.addCategory("android.intent.category.DEFAULT");
        startActivityForResult(intent, 0);
    }
}
