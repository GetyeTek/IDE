package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityPayBillBindingImpl extends ActivityPayBillBinding {
    @Nullable
    public static final SparseIntArray q;
    public long p;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        q = sparseIntArray;
        sparseIntArray.put(R$id.scrollView, 1);
        sparseIntArray.put(R$id.cycle_view, 2);
        sparseIntArray.put(R$id.ll_tab, 3);
        sparseIntArray.put(R$id.ll_container, 4);
        sparseIntArray.put(R$id.tl_container, 5);
        sparseIntArray.put(R$id.iv_for_self, 6);
        sparseIntArray.put(R$id.tv_for_self, 7);
        sparseIntArray.put(R$id.iv_for_other, 8);
        sparseIntArray.put(R$id.tv_for_other, 9);
        sparseIntArray.put(R$id.input_mobile_number, 10);
        sparseIntArray.put(R$id.input_by_service_number, 11);
        sparseIntArray.put(R$id.barrier, 12);
        sparseIntArray.put(R$id.input_by_account_number, 13);
        sparseIntArray.put(R$id.ll_deposit_container, 14);
        sparseIntArray.put(R$id.et_amount, 15);
        sparseIntArray.put(R$id.tv_search_result, 16);
        sparseIntArray.put(R$id.recyclerview, 17);
        sparseIntArray.put(R$id.ll_button, 18);
        sparseIntArray.put(R$id.ll_set_schedule_payment, 19);
        sparseIntArray.put(R$id.tv_for_schedule_payment, 20);
        sparseIntArray.put(R$id.btn_next, 21);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.p = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.p != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.p = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
