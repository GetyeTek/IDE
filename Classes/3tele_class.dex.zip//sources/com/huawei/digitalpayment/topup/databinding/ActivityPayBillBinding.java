package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public abstract class ActivityPayBillBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final CycleViewPager b;
    @NonNull
    public final InputItemEditText c;
    @NonNull
    public final CommonInputView d;
    @NonNull
    public final CommonInputView e;
    @NonNull
    public final CommonInputView f;
    @NonNull
    public final ImageView g;
    @NonNull
    public final ImageView h;
    @NonNull
    public final LinearLayout i;
    @NonNull
    public final LinearLayout j;
    @NonNull
    public final RecyclerView k;
    @NonNull
    public final TabLayout l;
    @NonNull
    public final TextView m;
    @NonNull
    public final TextView n;
    @NonNull
    public final TextView o;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ActivityPayBillBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, CycleViewPager cycleViewPager, InputItemEditText inputItemEditText, CommonInputView commonInputView, CommonInputView commonInputView2, CommonInputView commonInputView3, ImageView imageView, ImageView imageView2, LinearLayout linearLayout, LinearLayout linearLayout2, RecyclerView recyclerView, TabLayout tabLayout, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        this.a = loadingButton;
        this.b = cycleViewPager;
        this.c = inputItemEditText;
        this.d = commonInputView;
        this.e = commonInputView2;
        this.f = commonInputView3;
        this.g = imageView;
        this.h = imageView2;
        this.i = linearLayout;
        this.j = linearLayout2;
        this.k = recyclerView;
        this.l = tabLayout;
        this.m = textView;
        this.n = textView2;
        this.o = textView3;
    }
}
