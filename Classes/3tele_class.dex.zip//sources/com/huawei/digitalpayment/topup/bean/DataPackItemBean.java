package com.huawei.digitalpayment.topup.bean;

import java.io.Serializable;

public class DataPackItemBean implements Serializable {
    private boolean checked;
    private String currency;
    private String discountDesc;
    private String finalPrice;
    private String itemDesc;
    private String itemDetailDesc;
    private String itemDetailSubTitle;
    private String itemDetailTitle;
    private String itemId;
    private String offeringId;
    private Integer order;
    private String priceDisplay;
    private String promotionIconURL;

    public String getCurrency() {
        return this.currency;
    }

    public String getDiscountDesc() {
        return this.discountDesc;
    }

    public String getFinalPrice() {
        return this.finalPrice;
    }

    public String getItemDesc() {
        return this.itemDesc;
    }

    public String getItemDetailDesc() {
        return this.itemDetailDesc;
    }

    public String getItemDetailSubTitle() {
        return this.itemDetailSubTitle;
    }

    public String getItemDetailTitle() {
        return this.itemDetailTitle;
    }

    public String getItemId() {
        return this.itemId;
    }

    public String getOfferingId() {
        return this.offeringId;
    }

    public Integer getOrder() {
        return this.order;
    }

    public String getPriceDisplay() {
        return this.priceDisplay;
    }

    public String getPromotionIconURL() {
        return this.promotionIconURL;
    }

    public boolean isChecked() {
        return this.checked;
    }

    public void setChecked(boolean z) {
        this.checked = z;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setDiscountDesc(String str) {
        this.discountDesc = str;
    }

    public void setFinalPrice(String str) {
        this.finalPrice = str;
    }

    public void setItemDesc(String str) {
        this.itemDesc = str;
    }

    public void setItemDetailDesc(String str) {
        this.itemDetailDesc = str;
    }

    public void setItemDetailSubTitle(String str) {
        this.itemDetailSubTitle = str;
    }

    public void setItemDetailTitle(String str) {
        this.itemDetailTitle = str;
    }

    public void setItemId(String str) {
        this.itemId = str;
    }

    public void setOfferingId(String str) {
        this.offeringId = str;
    }

    public void setOrder(Integer num) {
        this.order = num;
    }

    public void setPriceDisplay(String str) {
        this.priceDisplay = str;
    }

    public void setPromotionIconURL(String str) {
        this.promotionIconURL = str;
    }
}
