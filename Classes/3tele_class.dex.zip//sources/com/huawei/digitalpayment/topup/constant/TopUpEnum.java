package com.huawei.digitalpayment.topup.constant;

public enum TopUpEnum {
    AIRTIME("1"),
    DATA_PACK("2");
    
    private final String productType;

    private TopUpEnum(String str) {
        this.productType = str;
    }

    public String getProductType() {
        return this.productType;
    }
}
