package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.module_checkout.databinding.ItemDepositCashBinding;

public abstract class ActivityCreateAutomaticPaymentSelectTypeBinding extends ViewDataBinding {
    @NonNull
    public final ItemDepositCashBinding a;
    @NonNull
    public final ItemDepositCashBinding b;
    @NonNull
    public final ItemDepositCashBinding c;
    @NonNull
    public final ItemDepositCashBinding d;

    public ActivityCreateAutomaticPaymentSelectTypeBinding(DataBindingComponent dataBindingComponent, View view, ItemDepositCashBinding itemDepositCashBinding, ItemDepositCashBinding itemDepositCashBinding2, ItemDepositCashBinding itemDepositCashBinding3, ItemDepositCashBinding itemDepositCashBinding4) {
        super(dataBindingComponent, view, 0);
        this.a = itemDepositCashBinding;
        this.b = itemDepositCashBinding2;
        this.c = itemDepositCashBinding3;
        this.d = itemDepositCashBinding4;
    }
}
