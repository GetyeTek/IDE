package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.digitalpayment.topup.widget.TypeSelectView;

public final class ActivityFuelPaymentAmountBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final Button b;
    @NonNull
    public final InputItemEditText c;
    @NonNull
    public final InputItemEditText d;
    @NonNull
    public final TypeSelectView e;
    @NonNull
    public final RoundConstraintLayout f;
    @NonNull
    public final TextView g;
    @NonNull
    public final TextView h;

    public ActivityFuelPaymentAmountBinding(@NonNull ConstraintLayout constraintLayout, @NonNull Button button, @NonNull InputItemEditText inputItemEditText, @NonNull InputItemEditText inputItemEditText2, @NonNull TypeSelectView typeSelectView, @NonNull RoundConstraintLayout roundConstraintLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = button;
        this.c = inputItemEditText;
        this.d = inputItemEditText2;
        this.e = typeSelectView;
        this.f = roundConstraintLayout;
        this.g = textView;
        this.h = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
