package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityPayForMerchantConfirmBindingImpl extends ActivityPayForMerchantConfirmBinding {
    @Nullable
    public static final SparseIntArray c;
    public long b;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        c = sparseIntArray;
        sparseIntArray.put(R$id.ll_content, 1);
        sparseIntArray.put(R$id.ivIcon, 2);
        sparseIntArray.put(R$id.tvTitle, 3);
        sparseIntArray.put(R$id.tvAmount, 4);
        sparseIntArray.put(R$id.tvAmountUnit, 5);
        sparseIntArray.put(R$id.line, 6);
        sparseIntArray.put(R$id.tvOrderId, 7);
        sparseIntArray.put(R$id.tvOrderIdValue, 8);
        sparseIntArray.put(R$id.tvMerchantName, 9);
        sparseIntArray.put(R$id.tvMerchantNameValue, 10);
        sparseIntArray.put(R$id.ttvAmount, 11);
        sparseIntArray.put(R$id.ttvAmountValue, 12);
        sparseIntArray.put(R$id.btnNext, 13);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.b = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.b != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.b = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
