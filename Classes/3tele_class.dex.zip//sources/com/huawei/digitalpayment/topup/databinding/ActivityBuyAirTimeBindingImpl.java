package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityBuyAirTimeBindingImpl extends ActivityBuyAirTimeBinding {
    @Nullable
    public static final SparseIntArray m;
    public long l;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        m = sparseIntArray;
        sparseIntArray.put(R$id.scrollView, 1);
        sparseIntArray.put(R$id.cycle_view, 2);
        sparseIntArray.put(R$id.ll_tab, 3);
        sparseIntArray.put(R$id.iv_for_self, 4);
        sparseIntArray.put(R$id.tv_for_self, 5);
        sparseIntArray.put(R$id.iv_for_other, 6);
        sparseIntArray.put(R$id.tv_for_other, 7);
        sparseIntArray.put(R$id.self_mobile_number, 8);
        sparseIntArray.put(R$id.input_mobile_number, 9);
        sparseIntArray.put(R$id.tv_title, 10);
        sparseIntArray.put(R$id.recyclerview, 11);
        sparseIntArray.put(R$id.input_set_amount, 12);
        sparseIntArray.put(R$id.ll_btn, 13);
        sparseIntArray.put(R$id.btn_next, 14);
        sparseIntArray.put(R$id.emptyview, 15);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.l = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.l != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.l = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
