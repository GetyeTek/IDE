package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class TopupDialogScheduleDatePickerBindingImpl extends TopupDialogScheduleDatePickerBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.line, 1);
        sparseIntArray.put(R$id.tv_title, 2);
        sparseIntArray.put(R$id.ll_top, 3);
        sparseIntArray.put(R$id.ll_date, 4);
        sparseIntArray.put(R$id.wheelDay, 5);
        sparseIntArray.put(R$id.wheelMonth, 6);
        sparseIntArray.put(R$id.wheelyear, 7);
        sparseIntArray.put(R$id.btn_confirm, 8);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
