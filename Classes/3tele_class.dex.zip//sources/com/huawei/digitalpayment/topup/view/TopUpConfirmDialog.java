package com.huawei.digitalpayment.topup.view;

import A8.c;
import N4.b;
import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.blankj.utilcode.util.v;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$style;
import com.huawei.digitalpayment.topup.bean.DataPackItemBean;
import com.huawei.digitalpayment.topup.bean.TopUpBean;
import com.huawei.digitalpayment.topup.constant.PayTradeTypeEnum;
import com.huawei.digitalpayment.topup.ui.DataPackFragment;
import com.huawei.module_checkout.checkout.TradeTypeEnum;
import java.util.HashMap;

public class TopUpConfirmDialog extends TopUpBaseDialog {
    public String b;
    public String c;
    public String d;
    public String e;
    public b f;

    public class a implements View.OnClickListener {
        public a() {
        }

        public final void onClick(View view) {
            TopUpConfirmDialog topUpConfirmDialog = TopUpConfirmDialog.this;
            b bVar = topUpConfirmDialog.f;
            if (bVar != null) {
                DataPackFragment dataPackFragment = bVar.a;
                dataPackFragment.getClass();
                Object obj = new Object();
                DataPackItemBean dataPackItemBean = bVar.b;
                dataPackItemBean.getItemId();
                TopUpBean.OperatorsBean operatorsBean = dataPackFragment.g;
                if (operatorsBean != null) {
                    operatorsBean.getShortCode();
                }
                HashMap hashMap = new HashMap();
                hashMap.put("rechargeInfo", obj);
                hashMap.put("amount", dataPackItemBean.getFinalPrice());
                hashMap.put("tradeType", PayTradeTypeEnum.NATIVE_APP.getTradeType());
                new c(dataPackFragment).b(dataPackFragment.getActivity(), TradeTypeEnum.AIR_TIME_DATA_PACK, hashMap);
            }
            topUpConfirmDialog.dismiss();
        }
    }

    public final void onStart() {
        Window window;
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, v.a(328.0f));
            window.setBackgroundDrawableResource(17170445);
            H1.c.b(window, R$style.TopUpConfirmBottomAnimation, dialog, true, true);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        String str;
        TopUpConfirmDialog.super.onViewCreated(view, bundle);
        TextView textView = (TextView) view.findViewById(R$id.tv_topup_des);
        textView.setMovementMethod(ScrollingMovementMethod.getInstance());
        TextView textView2 = (TextView) view.findViewById(R$id.tv_topup_title);
        TextView textView3 = (TextView) view.findViewById(R$id.iv_topup_extra);
        TextView textView4 = (TextView) view.findViewById(R$id.tv_topup_confirm_amount);
        StringBuilder sb = new StringBuilder();
        sb.append(this.b);
        O4.a aVar = O4.a.b;
        if (TextUtils.isEmpty(aVar.a)) {
            str = "";
        } else {
            str = aVar.a;
        }
        sb.append(str);
        textView4.setText(sb.toString());
        textView2.setText(this.c);
        textView3.setText(this.d);
        textView.setText(this.e);
        view.findViewById(R$id.btn_top_up_pay).setOnClickListener(new a());
    }

    public final int v0() {
        return R$layout.dialog_topup_confirm_layout;
    }
}
