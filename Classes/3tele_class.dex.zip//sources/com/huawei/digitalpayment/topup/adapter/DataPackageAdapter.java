package com.huawei.digitalpayment.topup.adapter;

import D5.a;
import O9.c;
import android.text.TextUtils;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.bean.DataPackItemBean;

public class DataPackageAdapter extends BaseQuickAdapter<DataPackItemBean, BaseViewHolder> {
    public DataPackageAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        String str;
        DataPackItemBean dataPackItemBean = (DataPackItemBean) obj;
        try {
            int i = R$id.tv_data_package_name;
            StringBuilder sb = new StringBuilder();
            sb.append(a.c(dataPackItemBean.getPriceDisplay()));
            O4.a aVar = O4.a.b;
            if (TextUtils.isEmpty(aVar.a)) {
                str = "";
            } else {
                str = aVar.a;
            }
            sb.append(str);
            baseViewHolder.setText(i, sb.toString());
        } catch (Exception unused) {
        }
        baseViewHolder.setText(R$id.tv_data_package_description, dataPackItemBean.getItemDesc());
        baseViewHolder.setText(R$id.tv_cash_back_price, dataPackItemBean.getDiscountDesc());
        c.c((ImageView) baseViewHolder.getView(R$id.iv_hot_cash_back), dataPackItemBean.getPromotionIconURL(), -1);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(-1, -2);
        if (baseViewHolder.getAdapterPosition() % 2 == 0) {
            layoutParams.setMargins(0, 0, v.a(3.5f), v.a(7.0f));
        } else {
            layoutParams.setMargins(v.a(3.5f), 0, 0, v.a(7.0f));
        }
        baseViewHolder.itemView.setLayoutParams(layoutParams);
    }
}
