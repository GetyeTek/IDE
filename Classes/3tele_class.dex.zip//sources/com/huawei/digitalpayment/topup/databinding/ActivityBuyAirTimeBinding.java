package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.common.widget.input.CommonInputView;

public abstract class ActivityBuyAirTimeBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final CycleViewPager b;
    @NonNull
    public final View c;
    @NonNull
    public final CommonInputView d;
    @NonNull
    public final CommonInputView e;
    @NonNull
    public final ImageView f;
    @NonNull
    public final ImageView g;
    @NonNull
    public final RecyclerView h;
    @NonNull
    public final CommonInputView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;

    public ActivityBuyAirTimeBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, CycleViewPager cycleViewPager, View view2, CommonInputView commonInputView, CommonInputView commonInputView2, ImageView imageView, ImageView imageView2, RecyclerView recyclerView, CommonInputView commonInputView3, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = cycleViewPager;
        this.c = view2;
        this.d = commonInputView;
        this.e = commonInputView2;
        this.f = imageView;
        this.g = imageView2;
        this.h = recyclerView;
        this.i = commonInputView3;
        this.j = textView;
        this.k = textView2;
    }
}
