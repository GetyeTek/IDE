package com.huawei.digitalpayment.topup.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class ItemAutomaticDisplayBinding extends ViewDataBinding {
}
