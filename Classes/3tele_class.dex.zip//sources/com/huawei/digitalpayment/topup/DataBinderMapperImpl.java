package com.huawei.digitalpayment.topup;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(19);
            a = hashMap;
            hashMap.put("layout/activity_automatic_payment_0", Integer.valueOf(R$layout.activity_automatic_payment));
            hashMap.put("layout/activity_automatic_select_page_0", Integer.valueOf(R$layout.activity_automatic_select_page));
            hashMap.put("layout/activity_bill_details_0", Integer.valueOf(R$layout.activity_bill_details));
            hashMap.put("layout/activity_buy_air_time_0", Integer.valueOf(R$layout.activity_buy_air_time));
            hashMap.put("layout/activity_create_automatic_payment_0", Integer.valueOf(R$layout.activity_create_automatic_payment));
            hashMap.put("layout/activity_create_automatic_payment_select_type_0", Integer.valueOf(R$layout.activity_create_automatic_payment_select_type));
            hashMap.put("layout/activity_fuel_payment_0", Integer.valueOf(R$layout.activity_fuel_payment));
            hashMap.put("layout/activity_pay_bill_0", Integer.valueOf(R$layout.activity_pay_bill));
            hashMap.put("layout/activity_pay_cnet_0", Integer.valueOf(R$layout.activity_pay_cnet));
            hashMap.put("layout/activity_pay_for_merchant_0", Integer.valueOf(R$layout.activity_pay_for_merchant));
            hashMap.put("layout/activity_pay_for_merchant_confirm_0", Integer.valueOf(R$layout.activity_pay_for_merchant_confirm));
            hashMap.put("layout/create_automatic_header_layout_0", Integer.valueOf(R$layout.create_automatic_header_layout));
            hashMap.put("layout/item_automatic_display_0", Integer.valueOf(R$layout.item_automatic_display));
            hashMap.put("layout/item_automatic_payment_0", Integer.valueOf(R$layout.item_automatic_payment));
            hashMap.put("layout/item_pay_bill_details_0", Integer.valueOf(R$layout.item_pay_bill_details));
            hashMap.put("layout/item_pay_bill_history_0", Integer.valueOf(R$layout.item_pay_bill_history));
            hashMap.put("layout/topup_dialog_schedule_date_picker_0", Integer.valueOf(R$layout.topup_dialog_schedule_date_picker));
            hashMap.put("layout/topup_item_buy_airtime_amount_list_0", Integer.valueOf(R$layout.topup_item_buy_airtime_amount_list));
            hashMap.put("layout/topup_item_recent_pay_for_merchant_0", Integer.valueOf(R$layout.topup_item_recent_pay_for_merchant));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(19);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_automatic_payment, 1);
        sparseIntArray.put(R$layout.activity_automatic_select_page, 2);
        sparseIntArray.put(R$layout.activity_bill_details, 3);
        sparseIntArray.put(R$layout.activity_buy_air_time, 4);
        sparseIntArray.put(R$layout.activity_create_automatic_payment, 5);
        sparseIntArray.put(R$layout.activity_create_automatic_payment_select_type, 6);
        sparseIntArray.put(R$layout.activity_fuel_payment, 7);
        sparseIntArray.put(R$layout.activity_pay_bill, 8);
        sparseIntArray.put(R$layout.activity_pay_cnet, 9);
        sparseIntArray.put(R$layout.activity_pay_for_merchant, 10);
        sparseIntArray.put(R$layout.activity_pay_for_merchant_confirm, 11);
        sparseIntArray.put(R$layout.create_automatic_header_layout, 12);
        sparseIntArray.put(R$layout.item_automatic_display, 13);
        sparseIntArray.put(R$layout.item_automatic_payment, 14);
        sparseIntArray.put(R$layout.item_pay_bill_details, 15);
        sparseIntArray.put(R$layout.item_pay_bill_history, 16);
        sparseIntArray.put(R$layout.topup_dialog_schedule_date_picker, 17);
        sparseIntArray.put(R$layout.topup_item_buy_airtime_amount_list, 18);
        sparseIntArray.put(R$layout.topup_item_recent_pay_for_merchant, 19);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(8);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    /* JADX WARNING: type inference failed for: r14v2, types: [com.huawei.digitalpayment.topup.databinding.ActivityAutomaticSelectPageBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r0v22, types: [com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r0v31, types: [com.huawei.digitalpayment.topup.databinding.ActivityBuyAirTimeBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r0v64, types: [com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r0v106, types: [com.huawei.digitalpayment.topup.databinding.ActivityPayBillBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r0v144, types: [com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 6 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.databinding.ViewDataBinding getDataBinder(androidx.databinding.DataBindingComponent r31, android.view.View r32, int r33) {
        /*
            r30 = this;
            r1 = r31
            r15 = r32
            android.util.SparseIntArray r0 = a
            r2 = r33
            int r0 = r0.get(r2)
            r14 = 0
            if (r0 <= 0) goto L_0x0031
            java.lang.Object r2 = r32.getTag()
            if (r2 == 0) goto L_0x0815
            r16 = 20
            r18 = 15
            r17 = 10
            r19 = 11
            r11 = 14
            r20 = 8
            r8 = 9
            r7 = 7
            r6 = 6
            r5 = 5
            r3 = 4
            r13 = 3
            r12 = 0
            r9 = -1
            r22 = 1
            r4 = 2
            switch(r0) {
                case 1: goto L_0x07dd;
                case 2: goto L_0x0774;
                case 3: goto L_0x06d8;
                case 4: goto L_0x0631;
                case 5: goto L_0x0575;
                case 6: goto L_0x0505;
                case 7: goto L_0x04ac;
                case 8: goto L_0x03f0;
                case 9: goto L_0x039d;
                case 10: goto L_0x02de;
                case 11: goto L_0x0277;
                case 12: goto L_0x020b;
                case 13: goto L_0x01d4;
                case 14: goto L_0x0195;
                case 15: goto L_0x0152;
                case 16: goto L_0x010f;
                case 17: goto L_0x00b4;
                case 18: goto L_0x006b;
                case 19: goto L_0x0034;
                default: goto L_0x0031;
            }
        L_0x0031:
            r0 = r14
            goto L_0x081d
        L_0x0034:
            java.lang.String r0 = "layout/topup_item_recent_pay_for_merchant_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x005f
            com.huawei.digitalpayment.topup.databinding.TopupItemRecentPayForMerchantBindingImpl r0 = new com.huawei.digitalpayment.topup.databinding.TopupItemRecentPayForMerchantBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.TopupItemRecentPayForMerchantBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r13, r14, r2)
            r3 = r2[r4]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r4 = r2[r22]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0.<init>(r1, r15, r3, r4)
            r0.c = r9
            r1 = r2[r12]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x005f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for topup_item_recent_pay_for_merchant is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x006b:
            java.lang.String r0 = "layout/topup_item_buy_airtime_amount_list_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x00a8
            com.huawei.digitalpayment.topup.databinding.TopupItemBuyAirtimeAmountListBindingImpl r7 = new com.huawei.digitalpayment.topup.databinding.TopupItemBuyAirtimeAmountListBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.TopupItemBuyAirtimeAmountListBindingImpl.f
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r0)
            r2 = r0[r12]
            r3 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r3 = (com.huawei.common.widget.round.RoundConstraintLayout) r3
            r2 = r0[r22]
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            r2 = r0[r13]
            r6 = r2
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r0[r4]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r7
            r1 = r31
            r2 = r32
            r4 = r5
            r5 = r6
            r6 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r9
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r7.a
            r0.setTag(r14)
            r7.setRootTag(r15)
            r7.invalidateAll()
            return r7
        L_0x00a8:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for topup_item_buy_airtime_amount_list is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x00b4:
            java.lang.String r0 = "layout/topup_dialog_schedule_date_picker_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0103
            com.huawei.digitalpayment.topup.databinding.TopupDialogScheduleDatePickerBindingImpl r11 = new com.huawei.digitalpayment.topup.databinding.TopupDialogScheduleDatePickerBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.TopupDialogScheduleDatePickerBindingImpl.f
            java.lang.Object[] r8 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r14, r0)
            r0 = r8[r20]
            r14 = r0
            com.huawei.common.widget.LoadingButton r14 = (com.huawei.common.widget.LoadingButton) r14
            r0 = r8[r22]
            com.huawei.common.widget.round.RoundTextView r0 = (com.huawei.common.widget.round.RoundTextView) r0
            r0 = r8[r3]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = r8[r13]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = r8[r4]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r8[r5]
            r4 = r0
            com.huawei.common.widget.date.WheelPicker r4 = (com.huawei.common.widget.date.WheelPicker) r4
            r0 = r8[r6]
            r5 = r0
            com.huawei.common.widget.date.WheelPicker r5 = (com.huawei.common.widget.date.WheelPicker) r5
            r0 = r8[r7]
            r6 = r0
            com.huawei.common.widget.date.WheelPicker r6 = (com.huawei.common.widget.date.WheelPicker) r6
            r0 = r11
            r1 = r31
            r2 = r32
            r3 = r14
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r11.e = r9
            r0 = r8[r12]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            java.lang.String r1 = "layout/common_dialog_date_picker_0"
            r0.setTag(r1)
            r11.setRootTag(r15)
            r11.invalidateAll()
            return r11
        L_0x0103:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for topup_dialog_schedule_date_picker is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x010f:
            java.lang.String r0 = "layout/item_pay_bill_history_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0146
            com.huawei.digitalpayment.topup.databinding.ItemPayBillHistoryBindingImpl r6 = new com.huawei.digitalpayment.topup.databinding.ItemPayBillHistoryBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.ItemPayBillHistoryBindingImpl.e
            java.lang.Object[] r7 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r0)
            r0 = r7[r22]
            r3 = r0
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = r7[r4]
            r4 = r0
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0 = r7[r13]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r6
            r1 = r31
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r9
            r0 = r7[r12]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0.setTag(r14)
            r6.setRootTag(r15)
            r6.invalidateAll()
            return r6
        L_0x0146:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for item_pay_bill_history is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0152:
            java.lang.String r0 = "layout/item_pay_bill_details_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0189
            com.huawei.digitalpayment.topup.databinding.ItemPayBillDetailsBindingImpl r6 = new com.huawei.digitalpayment.topup.databinding.ItemPayBillDetailsBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.ItemPayBillDetailsBindingImpl.e
            java.lang.Object[] r7 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r0)
            r0 = r7[r4]
            r3 = r0
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0 = r7[r13]
            r4 = r0
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0 = r7[r22]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r6
            r1 = r31
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r9
            r0 = r7[r12]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r14)
            r6.setRootTag(r15)
            r6.invalidateAll()
            return r6
        L_0x0189:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for item_pay_bill_details is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0195:
            java.lang.String r0 = "layout/item_automatic_payment_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x01c8
            com.huawei.digitalpayment.topup.databinding.ItemAutomaticPaymentBindingImpl r0 = new com.huawei.digitalpayment.topup.databinding.ItemAutomaticPaymentBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.ItemAutomaticPaymentBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r5, r14, r2)
            r3 = r2[r3]
            com.huawei.common.widget.round.RoundRecyclerView r3 = (com.huawei.common.widget.round.RoundRecyclerView) r3
            r3 = r2[r22]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r4]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r13]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0.<init>(r1, r15, r12)
            r0.a = r9
            r1 = r2[r12]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x01c8:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for item_automatic_payment is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x01d4:
            java.lang.String r0 = "layout/item_automatic_display_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x01ff
            com.huawei.digitalpayment.topup.databinding.ItemAutomaticDisplayBindingImpl r0 = new com.huawei.digitalpayment.topup.databinding.ItemAutomaticDisplayBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.ItemAutomaticDisplayBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r13, r14, r2)
            r3 = r2[r22]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r4]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0.<init>(r1, r15, r12)
            r0.a = r9
            r1 = r2[r12]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x01ff:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for item_automatic_display is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x020b:
            java.lang.String r0 = "layout/create_automatic_header_layout_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x026b
            com.huawei.digitalpayment.topup.databinding.CreateAutomaticHeaderLayoutBindingImpl r7 = new com.huawei.digitalpayment.topup.databinding.CreateAutomaticHeaderLayoutBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.CreateAutomaticHeaderLayoutBindingImpl.f
            java.lang.Object[] r8 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r5, r14, r0)
            r0 = r8[r4]
            if (r0 == 0) goto L_0x0227
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r4 = r0
            goto L_0x0228
        L_0x0227:
            r4 = r14
        L_0x0228:
            r0 = r8[r3]
            if (r0 == 0) goto L_0x0234
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r5 = r0
            goto L_0x0235
        L_0x0234:
            r5 = r14
        L_0x0235:
            r0 = r8[r13]
            if (r0 == 0) goto L_0x0241
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r6 = r0
            goto L_0x0242
        L_0x0241:
            r6 = r14
        L_0x0242:
            r0 = r8[r22]
            if (r0 == 0) goto L_0x024e
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r11 = r0
            goto L_0x024f
        L_0x024e:
            r11 = r14
        L_0x024f:
            r0 = r7
            r1 = r31
            r2 = r32
            r3 = r4
            r4 = r5
            r5 = r6
            r6 = r11
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r9
            r0 = r8[r12]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r14)
            r7.setRootTag(r15)
            r7.invalidateAll()
            return r7
        L_0x026b:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for create_automatic_header_layout is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0277:
            java.lang.String r0 = "layout/activity_pay_for_merchant_confirm_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x02d2
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantConfirmBindingImpl r0 = new com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantConfirmBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantConfirmBindingImpl.c
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r11, r14, r2)
            r11 = 13
            r11 = r2[r11]
            com.huawei.common.widget.round.RoundTextView r11 = (com.huawei.common.widget.round.RoundTextView) r11
            r4 = r2[r4]
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r4 = r2[r6]
            android.view.View r4 = (android.view.View) r4
            r4 = r2[r22]
            com.huawei.common.widget.round.RoundConstraintLayout r4 = (com.huawei.common.widget.round.RoundConstraintLayout) r4
            r4 = r2[r19]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r4 = 12
            r4 = r2[r4]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r3 = r2[r3]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r5]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r8]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r17]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r7]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r20]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r13]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0.<init>(r1, r15, r11)
            r0.b = r9
            r1 = r2[r12]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x02d2:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_pay_for_merchant_confirm is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x02de:
            java.lang.String r0 = "layout/activity_pay_for_merchant_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0391
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBindingImpl r2 = new com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBindingImpl.q
            r3 = 22
            java.lang.Object[] r23 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r0)
            r0 = r23[r20]
            r3 = r0
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = 4
            r20 = 21
            r20 = r23[r20]
            com.huawei.common.widget.LoadingButton r20 = (com.huawei.common.widget.LoadingButton) r20
            r12 = 2
            r4 = r20
            r20 = r23[r22]
            com.huawei.common.widget.banner.CycleViewPager r20 = (com.huawei.common.widget.banner.CycleViewPager) r20
            r0 = 5
            r5 = r20
            r11 = r23[r11]
            com.huawei.common.widget.input.CommonInputView r11 = (com.huawei.common.widget.input.CommonInputView) r11
            r14 = 6
            r6 = r11
            r11 = r23[r19]
            com.huawei.common.widget.input.CommonInputView r11 = (com.huawei.common.widget.input.CommonInputView) r11
            r7 = r11
            r11 = 12
            r11 = r23[r11]
            com.huawei.common.widget.input.CommonInputView r11 = (com.huawei.common.widget.input.CommonInputView) r11
            r0 = 9
            r8 = r11
            r11 = 13
            r11 = r23[r11]
            com.huawei.common.widget.input.CommonInputView r11 = (com.huawei.common.widget.input.CommonInputView) r11
            r9 = r11
            r21 = 16
            r10 = r23[r21]
            android.widget.ImageView r10 = (android.widget.ImageView) r10
            r11 = r23[r14]
            android.widget.LinearLayout r11 = (android.widget.LinearLayout) r11
            r11 = r23[r16]
            com.huawei.common.widget.round.RoundLinearLayout r11 = (com.huawei.common.widget.round.RoundLinearLayout) r11
            r11 = 18
            r11 = r23[r11]
            android.widget.LinearLayout r11 = (android.widget.LinearLayout) r11
            r13 = r23[r13]
            android.widget.LinearLayout r13 = (android.widget.LinearLayout) r13
            r12 = r23[r12]
            com.huawei.common.widget.round.RoundLinearLayout r12 = (com.huawei.common.widget.round.RoundLinearLayout) r12
            r0 = r23[r0]
            r12 = r0
            androidx.core.widget.NestedScrollView r12 = (androidx.core.widget.NestedScrollView) r12
            r24 = 0
            r0 = 5
            r0 = r23[r0]
            r13 = r0
            com.huawei.common.widget.round.RoundTextView r13 = (com.huawei.common.widget.round.RoundTextView) r13
            r0 = 19
            r0 = r23[r0]
            r14 = r0
            com.huawei.common.widget.round.RoundLinearLayout r14 = (com.huawei.common.widget.round.RoundLinearLayout) r14
            r0 = 0
            r16 = 17
            r16 = r23[r16]
            com.huawei.common.widget.round.RoundRecyclerView r16 = (com.huawei.common.widget.round.RoundRecyclerView) r16
            r15 = r16
            r16 = r23[r17]
            android.view.View r16 = (android.view.View) r16
            r0 = 7
            r0 = r23[r0]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = 4
            r0 = r23[r0]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = r23[r18]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r2
            r1 = r31
            r25 = r2
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17)
            r0 = r25
            r9 = -1
            r0.p = r9
            r1 = r23[r24]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r15 = 0
            r1.setTag(r15)
            r8 = r32
            r0.setRootTag(r8)
            r0.invalidateAll()
            return r0
        L_0x0391:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_pay_for_merchant is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x039d:
            r8 = r15
            r12 = 2
            r24 = 0
            r15 = r14
            r14 = 6
            java.lang.String r0 = "layout/activity_pay_cnet_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x03e4
            com.huawei.digitalpayment.topup.databinding.ActivityPayCnetBindingImpl r6 = new com.huawei.digitalpayment.topup.databinding.ActivityPayCnetBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.ActivityPayCnetBindingImpl.e
            java.lang.Object[] r7 = androidx.databinding.ViewDataBinding.mapBindings(r1, r8, r14, r15, r0)
            r0 = 5
            r0 = r7[r0]
            r3 = r0
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r0 = r7[r12]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = 4
            r0 = r7[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = r7[r13]
            r5 = r0
            com.huawei.common.widget.round.RoundLinearLayout r5 = (com.huawei.common.widget.round.RoundLinearLayout) r5
            r0 = r7[r22]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r6
            r1 = r31
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r9
            r0 = r7[r24]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r15)
            r6.setRootTag(r8)
            r6.invalidateAll()
            return r6
        L_0x03e4:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_pay_cnet is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x03f0:
            r8 = r15
            r0 = 7
            r7 = 9
            r12 = 2
            r21 = 16
            r24 = 0
            r15 = r14
            r14 = 6
            java.lang.String r3 = "layout/activity_pay_bill_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x04a0
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBindingImpl r2 = new com.huawei.digitalpayment.topup.databinding.ActivityPayBillBindingImpl
            android.util.SparseIntArray r3 = com.huawei.digitalpayment.topup.databinding.ActivityPayBillBindingImpl.q
            r4 = 22
            java.lang.Object[] r23 = androidx.databinding.ViewDataBinding.mapBindings(r1, r8, r4, r15, r3)
            r3 = 12
            r3 = r23[r3]
            androidx.constraintlayout.widget.Barrier r3 = (androidx.constraintlayout.widget.Barrier) r3
            r3 = 21
            r3 = r23[r3]
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r4 = r23[r12]
            com.huawei.common.widget.banner.CycleViewPager r4 = (com.huawei.common.widget.banner.CycleViewPager) r4
            r5 = r23[r18]
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r5 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r5
            r6 = 13
            r6 = r23[r6]
            com.huawei.common.widget.input.CommonInputView r6 = (com.huawei.common.widget.input.CommonInputView) r6
            r12 = r23[r19]
            com.huawei.common.widget.input.CommonInputView r12 = (com.huawei.common.widget.input.CommonInputView) r12
            r15 = 9
            r7 = r12
            r12 = r23[r17]
            com.huawei.common.widget.input.CommonInputView r12 = (com.huawei.common.widget.input.CommonInputView) r12
            r8 = r12
            r12 = r23[r20]
            android.widget.ImageView r12 = (android.widget.ImageView) r12
            r9 = r12
            r10 = r23[r14]
            android.widget.ImageView r10 = (android.widget.ImageView) r10
            r12 = 18
            r12 = r23[r12]
            com.huawei.common.widget.round.RoundLinearLayout r12 = (com.huawei.common.widget.round.RoundLinearLayout) r12
            r12 = 4
            r12 = r23[r12]
            android.widget.LinearLayout r12 = (android.widget.LinearLayout) r12
            r11 = r23[r11]
            android.widget.LinearLayout r11 = (android.widget.LinearLayout) r11
            r12 = 19
            r12 = r23[r12]
            android.widget.LinearLayout r12 = (android.widget.LinearLayout) r12
            r14 = 16
            r13 = r23[r13]
            com.huawei.common.widget.round.RoundConstraintLayout r13 = (com.huawei.common.widget.round.RoundConstraintLayout) r13
            r13 = 17
            r13 = r23[r13]
            androidx.recyclerview.widget.RecyclerView r13 = (androidx.recyclerview.widget.RecyclerView) r13
            r17 = r23[r22]
            android.widget.ScrollView r17 = (android.widget.ScrollView) r17
            r17 = 5
            r17 = r23[r17]
            com.google.android.material.tabs.TabLayout r17 = (com.google.android.material.tabs.TabLayout) r17
            r14 = r17
            r15 = r23[r15]
            android.widget.TextView r15 = (android.widget.TextView) r15
            r16 = r23[r16]
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = r23[r0]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = 16
            r0 = r23[r0]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = r2
            r1 = r31
            r26 = r2
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17)
            r0 = r26
            r9 = -1
            r0.p = r9
            r1 = r23[r24]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r8 = 0
            r1.setTag(r8)
            r7 = r32
            r0.setRootTag(r7)
            r0.invalidateAll()
            return r0
        L_0x04a0:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_pay_bill is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x04ac:
            r8 = r14
            r7 = r15
            r0 = 7
            r12 = 2
            r14 = 6
            r24 = 0
            java.lang.String r3 = "layout/activity_fuel_payment_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x04f9
            com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentBindingImpl r11 = new com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentBindingImpl.f
            java.lang.Object[] r15 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r0, r8, r2)
            r0 = r15[r14]
            r3 = r0
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r0 = r15[r22]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = 5
            r0 = r15[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = 4
            r0 = r15[r0]
            r4 = r0
            androidx.recyclerview.widget.RecyclerView r4 = (androidx.recyclerview.widget.RecyclerView) r4
            r0 = r15[r13]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r15[r12]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r11
            r1 = r31
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r11.e = r9
            r0 = r15[r24]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r8)
            r11.setRootTag(r7)
            r11.invalidateAll()
            return r11
        L_0x04f9:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_fuel_payment is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0505:
            r8 = r14
            r7 = r15
            r12 = 2
            r24 = 0
            java.lang.String r0 = "layout/activity_create_automatic_payment_select_type_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0569
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentSelectTypeBindingImpl r11 = new com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentSelectTypeBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentSelectTypeBindingImpl.f
            r2 = 5
            java.lang.Object[] r14 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r2, r8, r0)
            r0 = r14[r12]
            if (r0 == 0) goto L_0x0528
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r3 = r0
        L_0x0526:
            r0 = 4
            goto L_0x052a
        L_0x0528:
            r3 = r8
            goto L_0x0526
        L_0x052a:
            r0 = r14[r0]
            if (r0 == 0) goto L_0x0536
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r4 = r0
            goto L_0x0537
        L_0x0536:
            r4 = r8
        L_0x0537:
            r0 = r14[r13]
            if (r0 == 0) goto L_0x0543
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r5 = r0
            goto L_0x0544
        L_0x0543:
            r5 = r8
        L_0x0544:
            r0 = r14[r22]
            if (r0 == 0) goto L_0x0550
            android.view.View r0 = (android.view.View) r0
            com.huawei.module_checkout.databinding.ItemDepositCashBinding r0 = com.huawei.module_checkout.databinding.ItemDepositCashBinding.a(r0)
            r6 = r0
            goto L_0x0551
        L_0x0550:
            r6 = r8
        L_0x0551:
            r0 = r11
            r1 = r31
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r11.e = r9
            r0 = r14[r24]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r8)
            r11.setRootTag(r7)
            r11.invalidateAll()
            return r11
        L_0x0569:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_create_automatic_payment_select_type is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0575:
            r8 = r14
            r7 = r15
            r0 = 7
            r6 = 16
            r12 = 2
            r14 = 6
            r15 = 9
            r24 = 0
            java.lang.String r3 = "layout/activity_create_automatic_payment_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x0625
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBindingImpl r2 = new com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBindingImpl
            android.util.SparseIntArray r3 = com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBindingImpl.r
            r4 = 21
            java.lang.Object[] r21 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r4, r8, r3)
            r3 = r21[r12]
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r4 = 4
            r4 = r21[r4]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r4 = r21[r13]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r4 = r21[r15]
            com.huawei.common.widget.input.CommonInputView r4 = (com.huawei.common.widget.input.CommonInputView) r4
            r5 = r21[r20]
            android.view.View r5 = (android.view.View) r5
            r12 = r21[r14]
            android.widget.EditText r12 = (android.widget.EditText) r12
            r15 = 16
            r6 = r12
            r0 = r21[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r21[r16]
            com.huawei.common.widget.LoadingButton r0 = (com.huawei.common.widget.LoadingButton) r0
            r7 = r0
            r0 = r21[r17]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r14 = r8
            r8 = r0
            r0 = 13
            r0 = r21[r0]
            com.huawei.common.widget.input.CommonInputView r0 = (com.huawei.common.widget.input.CommonInputView) r0
            r12 = r9
            r9 = r0
            r0 = 12
            r0 = r21[r0]
            r10 = r0
            com.huawei.common.widget.input.CommonInputView r10 = (com.huawei.common.widget.input.CommonInputView) r10
            r0 = r21[r18]
            com.huawei.common.widget.input.CommonInputView r0 = (com.huawei.common.widget.input.CommonInputView) r0
            r11 = r0
            r0 = r21[r19]
            com.huawei.common.widget.input.CommonInputView r0 = (com.huawei.common.widget.input.CommonInputView) r0
            r12 = r0
            r0 = 18
            r0 = r21[r0]
            r13 = r0
            com.huawei.common.widget.input.CommonInputView r13 = (com.huawei.common.widget.input.CommonInputView) r13
            r0 = r21[r22]
            com.huawei.common.widget.input.CommonInputView r0 = (com.huawei.common.widget.input.CommonInputView) r0
            r14 = r0
            r0 = r21[r15]
            r15 = r0
            com.huawei.common.widget.input.CommonInputView r15 = (com.huawei.common.widget.input.CommonInputView) r15
            r0 = 17
            r0 = r21[r0]
            r16 = r0
            com.huawei.common.widget.input.CommonInputView r16 = (com.huawei.common.widget.input.CommonInputView) r16
            r0 = 14
            r0 = r21[r0]
            r17 = r0
            com.huawei.common.widget.input.CommonInputView r17 = (com.huawei.common.widget.input.CommonInputView) r17
            r0 = 19
            r0 = r21[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = 5
            r0 = r21[r0]
            r18 = r0
            androidx.constraintlayout.widget.ConstraintLayout r18 = (androidx.constraintlayout.widget.ConstraintLayout) r18
            r0 = r2
            r1 = r31
            r27 = r2
            r2 = r32
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18)
            r0 = r27
            r10 = -1
            r0.q = r10
            r1 = r21[r24]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r9 = 0
            r1.setTag(r9)
            r8 = r32
            r0.setRootTag(r8)
            r0.invalidateAll()
            return r0
        L_0x0625:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_create_automatic_payment is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0631:
            r10 = r9
            r9 = r14
            r8 = r15
            r0 = 7
            r3 = 16
            r4 = 14
            r12 = 2
            r14 = 6
            r15 = 9
            r24 = 0
            java.lang.String r5 = "layout/activity_buy_air_time_0"
            boolean r5 = r5.equals(r2)
            if (r5 == 0) goto L_0x06cc
            com.huawei.digitalpayment.topup.databinding.ActivityBuyAirTimeBindingImpl r7 = new com.huawei.digitalpayment.topup.databinding.ActivityBuyAirTimeBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.ActivityBuyAirTimeBindingImpl.m
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r8, r3, r9, r2)
            r2 = r16[r4]
            r3 = r2
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r2 = r16[r12]
            r4 = r2
            com.huawei.common.widget.banner.CycleViewPager r4 = (com.huawei.common.widget.banner.CycleViewPager) r4
            r2 = r16[r18]
            r5 = r2
            android.view.View r5 = (android.view.View) r5
            r2 = r16[r15]
            r6 = r2
            com.huawei.common.widget.input.CommonInputView r6 = (com.huawei.common.widget.input.CommonInputView) r6
            r2 = 12
            r2 = r16[r2]
            r12 = r2
            com.huawei.common.widget.input.CommonInputView r12 = (com.huawei.common.widget.input.CommonInputView) r12
            r2 = r16[r14]
            r14 = r2
            android.widget.ImageView r14 = (android.widget.ImageView) r14
            r2 = 4
            r2 = r16[r2]
            r15 = r2
            android.widget.ImageView r15 = (android.widget.ImageView) r15
            r2 = 13
            r2 = r16[r2]
            com.huawei.common.widget.round.RoundLinearLayout r2 = (com.huawei.common.widget.round.RoundLinearLayout) r2
            r2 = r16[r13]
            com.huawei.common.widget.round.RoundConstraintLayout r2 = (com.huawei.common.widget.round.RoundConstraintLayout) r2
            r2 = r16[r19]
            r13 = r2
            androidx.recyclerview.widget.RecyclerView r13 = (androidx.recyclerview.widget.RecyclerView) r13
            r2 = r16[r22]
            android.widget.ScrollView r2 = (android.widget.ScrollView) r2
            r2 = r16[r20]
            r18 = r2
            com.huawei.common.widget.input.CommonInputView r18 = (com.huawei.common.widget.input.CommonInputView) r18
            r0 = r16[r0]
            r19 = r0
            android.widget.TextView r19 = (android.widget.TextView) r19
            r0 = 5
            r0 = r16[r0]
            r20 = r0
            android.widget.TextView r20 = (android.widget.TextView) r20
            r0 = r16[r17]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r7
            r1 = r31
            r2 = r32
            r28 = r7
            r7 = r12
            r8 = r14
            r14 = r9
            r9 = r15
            r11 = r10
            r10 = r13
            r12 = r11
            r11 = r18
            r14 = r12
            r12 = r19
            r13 = r20
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            r0 = r28
            r0.l = r14
            r1 = r16[r24]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r2 = 0
            r1.setTag(r2)
            r1 = r32
            r0.setRootTag(r1)
            r0.invalidateAll()
            return r0
        L_0x06cc:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_buy_air_time is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x06d8:
            r8 = r9
            r10 = r14
            r11 = r15
            r0 = 7
            r4 = 14
            r12 = 2
            r14 = 6
            r15 = 9
            r24 = 0
            java.lang.String r3 = "layout/activity_bill_details_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x0768
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBindingImpl r7 = new com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBindingImpl.m
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r11, r4, r10, r2)
            r2 = 12
            r2 = r16[r2]
            r3 = r2
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r2 = r16[r13]
            androidx.constraintlayout.widget.ConstraintLayout r2 = (androidx.constraintlayout.widget.ConstraintLayout) r2
            r2 = 13
            r2 = r16[r2]
            r4 = r2
            android.view.View r4 = (android.view.View) r4
            r2 = r16[r17]
            r5 = r2
            com.huawei.common.widget.input.CommonInputView r5 = (com.huawei.common.widget.input.CommonInputView) r5
            r2 = r16[r20]
            r6 = r2
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            r2 = 5
            r2 = r16[r2]
            r13 = r2
            android.widget.ImageView r13 = (android.widget.ImageView) r13
            r2 = r16[r19]
            com.huawei.common.widget.round.RoundLinearLayout r2 = (com.huawei.common.widget.round.RoundLinearLayout) r2
            r2 = 4
            r2 = r16[r2]
            r17 = r2
            com.huawei.common.widget.recyclerview.HFRecyclerView r17 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r17
            r2 = r16[r12]
            r12 = r2
            android.widget.ScrollView r12 = (android.widget.ScrollView) r12
            r2 = r16[r22]
            r18 = r2
            android.widget.TextView r18 = (android.widget.TextView) r18
            r2 = r16[r15]
            r15 = r2
            android.widget.TextView r15 = (android.widget.TextView) r15
            r2 = r16[r14]
            r14 = r2
            android.widget.TextView r14 = (android.widget.TextView) r14
            r0 = r16[r0]
            r19 = r0
            android.widget.TextView r19 = (android.widget.TextView) r19
            r0 = r7
            r1 = r31
            r2 = r32
            r29 = r7
            r7 = r13
            r8 = r17
            r9 = r12
            r13 = r10
            r10 = r18
            r11 = r15
            r15 = r32
            r12 = r14
            r14 = r13
            r13 = r19
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            r0 = r29
            r9 = -1
            r0.l = r9
            r1 = r16[r24]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0768:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_bill_details is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0774:
            r8 = r14
            r11 = r15
            r0 = 7
            r12 = 2
            r14 = 6
            r15 = 9
            r24 = 0
            java.lang.String r3 = "layout/activity_automatic_select_page_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x07d1
            com.huawei.digitalpayment.topup.databinding.ActivityAutomaticSelectPageBindingImpl r7 = new com.huawei.digitalpayment.topup.databinding.ActivityAutomaticSelectPageBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.topup.databinding.ActivityAutomaticSelectPageBindingImpl.h
            java.lang.Object[] r15 = androidx.databinding.ViewDataBinding.mapBindings(r1, r11, r15, r8, r2)
            r2 = r15[r12]
            r3 = r2
            android.widget.EditText r3 = (android.widget.EditText) r3
            r2 = r15[r13]
            r4 = r2
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r2 = r15[r20]
            r5 = r2
            com.huawei.common.widget.LoadingButton r5 = (com.huawei.common.widget.LoadingButton) r5
            r2 = 5
            r2 = r15[r2]
            r6 = r2
            android.widget.RadioGroup r6 = (android.widget.RadioGroup) r6
            r0 = r15[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = r15[r14]
            r12 = r0
            androidx.recyclerview.widget.RecyclerView r12 = (androidx.recyclerview.widget.RecyclerView) r12
            r0 = r15[r22]
            androidx.core.widget.NestedScrollView r0 = (androidx.core.widget.NestedScrollView) r0
            r0 = 4
            r0 = r15[r0]
            r13 = r0
            com.huawei.common.widget.round.RoundTextView r13 = (com.huawei.common.widget.round.RoundTextView) r13
            r0 = r7
            r1 = r31
            r2 = r32
            r14 = r7
            r7 = r12
            r12 = r8
            r8 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r14.g = r9
            r0 = r15[r24]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r12)
            r14.setRootTag(r11)
            r14.invalidateAll()
            return r14
        L_0x07d1:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_automatic_select_page is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x07dd:
            r0 = r14
            r11 = r15
            r12 = 2
            r24 = 0
            java.lang.String r3 = "layout/activity_automatic_payment_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x0809
            com.huawei.digitalpayment.topup.databinding.ActivityAutomaticPaymentBindingImpl r2 = new com.huawei.digitalpayment.topup.databinding.ActivityAutomaticPaymentBindingImpl
            android.util.SparseIntArray r3 = com.huawei.digitalpayment.topup.databinding.ActivityAutomaticPaymentBindingImpl.c
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r11, r12, r0, r3)
            r4 = r3[r22]
            com.huawei.common.widget.recyclerview.HFRecyclerView r4 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r4
            r2.<init>(r1, r11, r4)
            r2.b = r9
            r1 = r3[r24]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1.setTag(r0)
            r2.setRootTag(r11)
            r2.invalidateAll()
            return r2
        L_0x0809:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_automatic_payment is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0815:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "view must have a tag"
            r0.<init>(r1)
            throw r0
        L_0x081d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.topup.DataBinderMapperImpl.getDataBinder(androidx.databinding.DataBindingComponent, android.view.View, int):androidx.databinding.ViewDataBinding");
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
