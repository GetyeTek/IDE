package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;

public final class ActivityFuelPaymentVehicleManageBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final Button b;
    @NonNull
    public final ConstraintLayout c;
    @NonNull
    public final RecyclerView d;

    public ActivityFuelPaymentVehicleManageBinding(@NonNull ConstraintLayout constraintLayout, @NonNull Button button, @NonNull ConstraintLayout constraintLayout2, @NonNull RecyclerView recyclerView) {
        this.a = constraintLayout;
        this.b = button;
        this.c = constraintLayout2;
        this.d = recyclerView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
