package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityPayForMerchantBindingImpl extends ActivityPayForMerchantBinding {
    @Nullable
    public static final SparseIntArray q;
    public long p;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        q = sparseIntArray;
        sparseIntArray.put(R$id.cycle_view, 1);
        sparseIntArray.put(R$id.ll_tab, 2);
        sparseIntArray.put(R$id.ll_pay_for_merchant, 3);
        sparseIntArray.put(R$id.tv_pay_for_merchant, 4);
        sparseIntArray.put(R$id.pay_for_merchant_line, 5);
        sparseIntArray.put(R$id.ll_apply_voucher, 6);
        sparseIntArray.put(R$id.tv_apply_voucher, 7);
        sparseIntArray.put(R$id.apply_voucher_line, 8);
        sparseIntArray.put(R$id.nestedSl, 9);
        sparseIntArray.put(R$id.top, 10);
        sparseIntArray.put(R$id.input_merchant_id, 11);
        sparseIntArray.put(R$id.input_operator_id, 12);
        sparseIntArray.put(R$id.input_set_amount, 13);
        sparseIntArray.put(R$id.inputAddnote, 14);
        sparseIntArray.put(R$id.tvRecent, 15);
        sparseIntArray.put(R$id.ivDelete, 16);
        sparseIntArray.put(R$id.recentRv, 17);
        sparseIntArray.put(R$id.llNoRecord, 18);
        sparseIntArray.put(R$id.payForMerchantRL, 19);
        sparseIntArray.put(R$id.ll_btn, 20);
        sparseIntArray.put(R$id.btn_next, 21);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.p = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.p != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.p = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
