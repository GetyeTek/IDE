package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class OffinceCommonTypeSelectBinding implements ViewBinding {
    @NonNull
    public final View getRoot() {
        return null;
    }
}
