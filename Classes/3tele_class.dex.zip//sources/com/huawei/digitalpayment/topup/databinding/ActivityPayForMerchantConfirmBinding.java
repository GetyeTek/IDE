package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundTextView;

public abstract class ActivityPayForMerchantConfirmBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;

    public ActivityPayForMerchantConfirmBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
    }
}
