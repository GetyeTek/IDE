package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.topup.widget.PlateInputView;
import com.huawei.digitalpayment.topup.widget.TypeSelectView;

public final class ActivityNewOrEditVehicleBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final Button b;
    @NonNull
    public final PlateInputView c;
    @NonNull
    public final TypeSelectView d;
    @NonNull
    public final LinearLayout e;
    @NonNull
    public final LinearLayout f;
    @NonNull
    public final TextView g;

    public ActivityNewOrEditVehicleBinding(@NonNull LinearLayout linearLayout, @NonNull Button button, @NonNull PlateInputView plateInputView, @NonNull TypeSelectView typeSelectView, @NonNull LinearLayout linearLayout2, @NonNull LinearLayout linearLayout3, @NonNull TextView textView) {
        this.a = linearLayout;
        this.b = button;
        this.c = plateInputView;
        this.d = typeSelectView;
        this.e = linearLayout2;
        this.f = linearLayout3;
        this.g = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
