package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.date.WheelPicker;

public abstract class TopupDialogScheduleDatePickerBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final WheelPicker b;
    @NonNull
    public final WheelPicker c;
    @NonNull
    public final WheelPicker d;

    public TopupDialogScheduleDatePickerBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, WheelPicker wheelPicker, WheelPicker wheelPicker2, WheelPicker wheelPicker3) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = wheelPicker;
        this.c = wheelPicker2;
        this.d = wheelPicker3;
    }
}
