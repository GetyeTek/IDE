package com.huawei.digitalpayment.topup.widget;

import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.digitalpayment.topup.R$id;
import kotlin.jvm.internal.h;

public final class PlateInputView extends CommonInputView {
    public View A;
    public View B;
    public TextView C;
    public TextView H;
    public TextView L;
    public TextView M;
    public View y;
    public View z;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public PlateInputView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
        h.f(context, "context");
    }

    public final String c() {
        if (!TextUtils.isEmpty(this.L.getText())) {
            if (TextUtils.isEmpty(this.H.getText().toString()) || TextUtils.isEmpty(getEditText().getText())) {
                return "";
            }
            CharSequence text = this.H.getText();
            CharSequence text2 = this.L.getText();
            Editable text3 = getEditText().getText();
            return text + "-" + text2 + "-" + text3;
        } else if (TextUtils.isEmpty(this.H.getText().toString()) || TextUtils.isEmpty(getEditText().getText())) {
            return "";
        } else {
            CharSequence text4 = this.H.getText();
            Editable text5 = getEditText().getText();
            return text4 + "-" + text5;
        }
    }

    public final View getClInput() {
        return this.A;
    }

    public final TextView getEtInput() {
        return this.M;
    }

    public final View getLlCarCode() {
        return this.y;
    }

    public final View getLlRegion() {
        return this.z;
    }

    public final View getLlWoreda() {
        return this.B;
    }

    public final TextView getTvCarCode() {
        return this.H;
    }

    public final TextView getTvRegion() {
        return this.L;
    }

    public final TextView getTvWoreda() {
        return this.C;
    }

    public final void setClInput(View view) {
        h.f(view, "<set-?>");
        this.A = view;
    }

    public final void setEtInput(TextView textView) {
        h.f(textView, "<set-?>");
        this.M = textView;
    }

    public final void setLlCarCode(View view) {
        h.f(view, "<set-?>");
        this.y = view;
    }

    public final void setLlRegion(View view) {
        h.f(view, "<set-?>");
        this.z = view;
    }

    public final void setLlWoreda(View view) {
        h.f(view, "<set-?>");
        this.B = view;
    }

    public final void setTvCarCode(TextView textView) {
        h.f(textView, "<set-?>");
        this.H = textView;
    }

    public final void setTvRegion(TextView textView) {
        h.f(textView, "<set-?>");
        this.L = textView;
    }

    public final void setTvWoreda(TextView textView) {
        h.f(textView, "<set-?>");
        this.C = textView;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.view.View, com.huawei.digitalpayment.topup.widget.PlateInputView] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PlateInputView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        h.f(context, "context");
        View findViewById = findViewById(R$id.llCarCode);
        h.e(findViewById, "findViewById(...)");
        this.y = findViewById;
        View findViewById2 = findViewById(R$id.llRegion);
        h.e(findViewById2, "findViewById(...)");
        this.z = findViewById2;
        View findViewById3 = findViewById(R$id.cl_input);
        h.e(findViewById3, "findViewById(...)");
        this.A = findViewById3;
        View findViewById4 = findViewById(R$id.llWoreda);
        h.e(findViewById4, "findViewById(...)");
        this.B = findViewById4;
        View findViewById5 = findViewById(R$id.tvWoreda);
        h.e(findViewById5, "findViewById(...)");
        this.C = (TextView) findViewById5;
        View findViewById6 = findViewById(R$id.tvCarCode);
        h.e(findViewById6, "findViewById(...)");
        this.H = (TextView) findViewById6;
        View findViewById7 = findViewById(R$id.tvRegion);
        h.e(findViewById7, "findViewById(...)");
        this.L = (TextView) findViewById7;
        View findViewById8 = findViewById(R$id.et_input);
        h.e(findViewById8, "findViewById(...)");
        this.M = (TextView) findViewById8;
    }
}
