package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class ActivityPayForMerchantBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final CycleViewPager c;
    @NonNull
    public final CommonInputView d;
    @NonNull
    public final CommonInputView e;
    @NonNull
    public final CommonInputView f;
    @NonNull
    public final CommonInputView g;
    @NonNull
    public final ImageView h;
    @NonNull
    public final LinearLayout i;
    @NonNull
    public final NestedScrollView j;
    @NonNull
    public final RoundTextView k;
    @NonNull
    public final RoundLinearLayout l;
    @NonNull
    public final RoundRecyclerView m;
    @NonNull
    public final TextView n;
    @NonNull
    public final TextView o;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ActivityPayForMerchantBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, LoadingButton loadingButton, CycleViewPager cycleViewPager, CommonInputView commonInputView, CommonInputView commonInputView2, CommonInputView commonInputView3, CommonInputView commonInputView4, ImageView imageView, LinearLayout linearLayout, NestedScrollView nestedScrollView, RoundTextView roundTextView2, RoundLinearLayout roundLinearLayout, RoundRecyclerView roundRecyclerView, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        this.a = roundTextView;
        this.b = loadingButton;
        this.c = cycleViewPager;
        this.d = commonInputView;
        this.e = commonInputView2;
        this.f = commonInputView3;
        this.g = commonInputView4;
        this.h = imageView;
        this.i = linearLayout;
        this.j = nestedScrollView;
        this.k = roundTextView2;
        this.l = roundLinearLayout;
        this.m = roundRecyclerView;
        this.n = textView;
        this.o = textView2;
    }
}
