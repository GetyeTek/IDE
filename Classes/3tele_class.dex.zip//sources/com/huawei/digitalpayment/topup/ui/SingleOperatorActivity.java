package com.huawei.digitalpayment.topup.ui;

import G5.g;
import N4.d;
import N4.e;
import O9.c;
import android.animation.LayoutTransition;
import android.text.TextUtils;
import android.view.View;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import com.google.android.material.appbar.AppBarLayout;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.bean.PackageTabsBean;
import com.huawei.digitalpayment.topup.bean.TopUpBean;
import com.huawei.digitalpayment.topup.databinding.ActivitySingleOperatorBinding;
import com.huawei.digitalpayment.topup.viewmodel.TopUpViewModel;
import java.util.ArrayList;

public class SingleOperatorActivity extends BaseTitleActivity implements AppBarLayout.OnOffsetChangedListener {
    public static final /* synthetic */ int o = 0;
    public ActivitySingleOperatorBinding i;
    public final ArrayList j = new ArrayList();
    public final ArrayList k = new ArrayList();
    public TopUpViewModel l;
    public TopUpBean.OperatorsBean m;
    public DataPackFragment n;

    /* JADX WARNING: type inference failed for: r3v0, types: [androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.digitalpayment.topup.ui.SingleOperatorActivity, androidx.lifecycle.ViewModelStoreOwner, android.app.Activity, androidx.appcompat.app.AppCompatActivity] */
    public final void D0() {
        PackageTabsBean packageTabsBean;
        TopUpViewModel topUpViewModel = new ViewModelProvider(this).get(TopUpViewModel.class);
        this.l = topUpViewModel;
        if (topUpViewModel.d == null) {
            topUpViewModel.d = new MutableLiveData<>();
        }
        topUpViewModel.d.observe(this, new d(this, 0));
        TopUpViewModel topUpViewModel2 = this.l;
        if (topUpViewModel2.e == null) {
            topUpViewModel2.e = new MutableLiveData<>();
        }
        topUpViewModel2.e.observe(this, new e(this, 0));
        if (getIntent() != null) {
            TopUpBean.OperatorsBean operatorsBean = (TopUpBean.OperatorsBean) getIntent().getSerializableExtra("operatorsBean");
            this.m = operatorsBean;
            if (operatorsBean != null) {
                TopUpViewModel topUpViewModel3 = this.l;
                topUpViewModel3.d.setValue(operatorsBean.getPackageTabs());
                if (!(this.m.getPackageTabs() == null || (packageTabsBean = this.m.getPackageTabs().get(0)) == null)) {
                    this.l.a(packageTabsBean.getPackageGroups());
                }
                this.i.e.c.setVisibility(0);
                c.c(this.i.e.e, this.m.getTitleLogoUrl(), -1);
            }
            String stringExtra = getIntent().getStringExtra("phoneNumber");
            if (!TextUtils.isEmpty(stringExtra)) {
                this.i.e.b.setText(stringExtra);
            }
        }
    }

    @RequiresApi(api = 21)
    public final void G0() {
        super.G0();
        U0();
        this.i.b.addOnOffsetChangedListener(this);
        this.i.e.d.setOnClickListener(new g(this, 1));
        this.i.e.b.addTextChangedListener(new N4.g(this));
    }

    /* JADX WARNING: type inference failed for: r17v0, types: [com.huawei.digitalpayment.topup.ui.SingleOperatorActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x008e, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.tip_phone_number;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00c8, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.toolbar;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0031, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.include_toolbar_close;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r17 = this;
            android.view.LayoutInflater r0 = r17.getLayoutInflater()
            int r1 = com.huawei.digitalpayment.topup.R$layout.activity_single_operator
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.digitalpayment.topup.R$id.app_bar
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.google.android.material.appbar.AppBarLayout r5 = (com.google.android.material.appbar.AppBarLayout) r5
            java.lang.String r2 = "Missing required view with ID: "
            if (r5 == 0) goto L_0x00df
            r6 = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout r6 = (androidx.coordinatorlayout.widget.CoordinatorLayout) r6
            int r1 = com.huawei.digitalpayment.topup.R$id.ctlCollapsingLayout
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.google.android.material.appbar.CollapsingToolbarLayout r3 = (com.google.android.material.appbar.CollapsingToolbarLayout) r3
            if (r3 == 0) goto L_0x00df
            int r1 = com.huawei.digitalpayment.topup.R$id.fl_data_package_group
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r3
            android.widget.FrameLayout r7 = (android.widget.FrameLayout) r7
            if (r7 == 0) goto L_0x00df
            int r1 = com.huawei.digitalpayment.topup.R$id.include_toolbar_close
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r3 == 0) goto L_0x00df
            r1 = r3
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            int r1 = com.huawei.digitalpayment.topup.R$id.imageView
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r1)
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            if (r4 == 0) goto L_0x0106
            int r4 = com.huawei.digitalpayment.topup.R$id.tv_base_title
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0102
            int r3 = com.huawei.digitalpayment.topup.R$id.include_toolbar_open
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            if (r8 == 0) goto L_0x00fe
            int r3 = com.huawei.digitalpayment.topup.R$id.cl_open_toolbar
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r3)
            androidx.constraintlayout.widget.ConstraintLayout r9 = (androidx.constraintlayout.widget.ConstraintLayout) r9
            if (r9 == 0) goto L_0x00e9
            int r3 = com.huawei.digitalpayment.topup.R$id.edit_phone_number
            android.view.View r9 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r3)
            r12 = r9
            android.widget.EditText r12 = (android.widget.EditText) r12
            if (r12 == 0) goto L_0x00e9
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x00e6
            r13 = r8
            androidx.constraintlayout.widget.ConstraintLayout r13 = (androidx.constraintlayout.widget.ConstraintLayout) r13
            int r1 = com.huawei.digitalpayment.topup.R$id.iv_get_contact
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r1)
            r14 = r3
            android.widget.ImageView r14 = (android.widget.ImageView) r14
            if (r14 == 0) goto L_0x00e6
            int r1 = com.huawei.digitalpayment.topup.R$id.iv_promotion_image
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r1)
            r15 = r3
            android.widget.ImageView r15 = (android.widget.ImageView) r15
            if (r15 == 0) goto L_0x00e6
            int r1 = com.huawei.digitalpayment.topup.R$id.tip_phone_number
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r1)
            r16 = r3
            com.google.android.material.textfield.TextInputLayout r16 = (com.google.android.material.textfield.TextInputLayout) r16
            if (r16 == 0) goto L_0x00e6
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r8, r4)
            android.widget.TextView r1 = (android.widget.TextView) r1
            if (r1 == 0) goto L_0x00e2
            com.huawei.digitalpayment.topup.databinding.ToolbarDataOpenBinding r8 = new com.huawei.digitalpayment.topup.databinding.ToolbarDataOpenBinding
            r10 = r8
            r11 = r13
            r10.<init>(r11, r12, r13, r14, r15, r16)
            int r1 = com.huawei.digitalpayment.topup.R$id.nv_scroll_view
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.core.widget.NestedScrollView r3 = (androidx.core.widget.NestedScrollView) r3
            if (r3 == 0) goto L_0x00df
            int r1 = com.huawei.digitalpayment.topup.R$id.rg_data_package
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r3
            android.widget.RadioGroup r9 = (android.widget.RadioGroup) r9
            if (r9 == 0) goto L_0x00df
            int r1 = com.huawei.digitalpayment.topup.R$id.sv_content
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.LinearLayout r3 = (android.widget.LinearLayout) r3
            if (r3 == 0) goto L_0x00df
            int r1 = com.huawei.digitalpayment.topup.R$id.toolbar
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r3
            androidx.appcompat.widget.Toolbar r10 = (androidx.appcompat.widget.Toolbar) r10
            if (r10 == 0) goto L_0x00df
            com.huawei.digitalpayment.topup.databinding.ActivitySingleOperatorBinding r0 = new com.huawei.digitalpayment.topup.databinding.ActivitySingleOperatorBinding
            r3 = r0
            r4 = r6
            r3.<init>(r4, r5, r6, r7, r8, r9, r10)
            r5 = r17
            r5.i = r0
            return r0
        L_0x00df:
            r5 = r17
            goto L_0x011a
        L_0x00e2:
            r5 = r17
            r1 = r4
            goto L_0x00ec
        L_0x00e6:
            r5 = r17
            goto L_0x00ec
        L_0x00e9:
            r5 = r17
            r1 = r3
        L_0x00ec:
            android.content.res.Resources r0 = r8.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x00fe:
            r5 = r17
            r1 = r3
            goto L_0x011a
        L_0x0102:
            r5 = r17
            r1 = r4
            goto L_0x0108
        L_0x0106:
            r5 = r17
        L_0x0108:
            android.content.res.Resources r0 = r3.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x011a:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.topup.ui.SingleOperatorActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final boolean L0() {
        return false;
    }

    /* JADX WARNING: type inference failed for: r0v8, types: [com.huawei.digitalpayment.topup.ui.DataPackFragment, com.huawei.digitalpayment.customer.baselib.base.BaseFragment] */
    public final void U0() {
        DataPackFragment dataPackFragment = this.n;
        ArrayList arrayList = this.k;
        if (dataPackFragment == null) {
            ? baseFragment = new BaseFragment();
            if (arrayList != null) {
                baseFragment.d = arrayList;
            }
            this.n = baseFragment;
            baseFragment.g = this.m;
            baseFragment.i = new N4.c(this);
            getSupportFragmentManager().beginTransaction().replace(R$id.fl_data_package_group, this.n).commitNow();
        } else {
            dataPackFragment.d = arrayList;
            dataPackFragment.e.notifyDataSetChanged();
            this.n.g = this.m;
        }
        if (arrayList == null || arrayList.size() <= 0) {
            this.i.d.setVisibility(8);
        } else {
            this.i.d.setVisibility(0);
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.digitalpayment.topup.ui.SingleOperatorActivity, android.app.Activity] */
    public void onBackClick(View view) {
        finish();
    }

    public final void onOffsetChanged(AppBarLayout appBarLayout, int i2) {
        int i5;
        float abs = ((float) Math.abs(i2)) / ((float) appBarLayout.getTotalScrollRange());
        Toolbar toolbar = this.i.g;
        int i6 = (abs > 0.0f ? 1 : (abs == 0.0f ? 0 : -1));
        if (i6 == 0) {
            i5 = 8;
        } else {
            i5 = 0;
        }
        toolbar.setVisibility(i5);
        this.i.g.setAlpha(abs);
        this.i.e.e.setAlpha(1.0f - abs);
        if (i6 == 0) {
            LayoutTransition layoutTransition = new LayoutTransition();
            layoutTransition.setDuration(400);
            layoutTransition.enableTransitionType(4);
            layoutTransition.setAnimateParentHierarchy(false);
            this.i.c.setLayoutTransition(layoutTransition);
            return;
        }
        this.i.c.setLayoutTransition((LayoutTransition) null);
    }
}
