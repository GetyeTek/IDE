package com.huawei.digitalpayment.topup.adapter;

import D5.a;
import O4.e;
import O9.c;
import V1.h;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.bean.DataPackItemBean;
import com.huawei.ethiopia.component.service.AppService;
import o0.b;

public class BuyPackageAdapter extends BaseQuickAdapter<DataPackItemBean, BaseViewHolder> {
    public BuyPackageAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        GradientDrawable gradientDrawable;
        DataPackItemBean dataPackItemBean = (DataPackItemBean) obj;
        try {
            String l = b.c(AppService.class).l();
            String c = a.c(dataPackItemBean.getPriceDisplay());
            SpannableString spannableString = new SpannableString(c + l);
            spannableString.setSpan(new RelativeSizeSpan(0.6f), c.length(), (l + c).length(), 33);
            baseViewHolder.setText(R$id.tv_data_package_name, spannableString);
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
        baseViewHolder.setText(R$id.tv_data_package_description, dataPackItemBean.getItemDesc());
        baseViewHolder.setText(R$id.tv_cash_back_price, dataPackItemBean.getDiscountDesc());
        ConstraintLayout view = baseViewHolder.getView(R$id.ll_top_up_data_item);
        if (dataPackItemBean.isChecked()) {
            gradientDrawable = (GradientDrawable) e.a(view.getContext(), "shape_top_up_item_selected_bg");
            baseViewHolder.setTextColor(R$id.tv_data_package_name, ContextCompat.getColor(getContext(), R$color.colorPrimary));
        } else {
            gradientDrawable = (GradientDrawable) e.a(view.getContext(), "shape_top_up_item_unselected_bg");
            baseViewHolder.setTextColor(R$id.tv_data_package_name, ContextCompat.getColor(getContext(), R$color.black));
        }
        view.setBackground(gradientDrawable);
        c.c((ImageView) baseViewHolder.getView(R$id.iv_hot_cash_back), dataPackItemBean.getPromotionIconURL(), -1);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(-1, -2);
        if (baseViewHolder.getAdapterPosition() % 2 == 0) {
            layoutParams.setMargins(0, 0, v.a(3.5f), v.a(7.0f));
        } else {
            layoutParams.setMargins(v.a(3.5f), 0, 0, v.a(7.0f));
        }
        baseViewHolder.itemView.setLayoutParams(layoutParams);
    }
}
