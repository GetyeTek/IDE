package com.huawei.digitalpayment.topup.adapter;

import O9.c;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.bean.TopUpBean;

public class OperatorAdapter extends BaseQuickAdapter<TopUpBean.OperatorsBean, BaseViewHolder> {
    public OperatorAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        c.c((ImageView) baseViewHolder.getView(R$id.iv_operator_logo), ((TopUpBean.OperatorsBean) obj).getBrandLogoUrl(), -1);
    }
}
