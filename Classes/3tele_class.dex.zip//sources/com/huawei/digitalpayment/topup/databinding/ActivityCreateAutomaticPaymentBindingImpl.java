package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityCreateAutomaticPaymentBindingImpl extends ActivityCreateAutomaticPaymentBinding {
    @Nullable
    public static final SparseIntArray r;
    public long q;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        r = sparseIntArray;
        sparseIntArray.put(R$id.inputReminderName, 1);
        sparseIntArray.put(R$id.billLayout, 2);
        sparseIntArray.put(R$id.billTitleStar, 3);
        sparseIntArray.put(R$id.billTitle, 4);
        sparseIntArray.put(R$id.selectBiller, 5);
        sparseIntArray.put(R$id.billerName, 6);
        sparseIntArray.put(R$id.billerSelectIv, 7);
        sparseIntArray.put(R$id.billerLine, 8);
        sparseIntArray.put(R$id.billerInputView, 9);
        sparseIntArray.put(R$id.commonInputLayout, 10);
        sparseIntArray.put(R$id.inputReceiverMobileNumber, 11);
        sparseIntArray.put(R$id.input_buyPackage, 12);
        sparseIntArray.put(R$id.inputAmount, 13);
        sparseIntArray.put(R$id.inputStartingPaymentDate, 14);
        sparseIntArray.put(R$id.inputEndPaymentDate, 15);
        sparseIntArray.put(R$id.inputSelectPaymentFrequency, 16);
        sparseIntArray.put(R$id.inputSendReminderInAdvance, 17);
        sparseIntArray.put(R$id.inputRemarks, 18);
        sparseIntArray.put(R$id.ll_btn, 19);
        sparseIntArray.put(R$id.btn_next, 20);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.q = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.q != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.q = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
