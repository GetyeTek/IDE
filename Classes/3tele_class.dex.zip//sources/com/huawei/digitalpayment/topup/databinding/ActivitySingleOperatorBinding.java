package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import com.google.android.material.appbar.AppBarLayout;

public final class ActivitySingleOperatorBinding implements ViewBinding {
    @NonNull
    public final CoordinatorLayout a;
    @NonNull
    public final AppBarLayout b;
    @NonNull
    public final CoordinatorLayout c;
    @NonNull
    public final FrameLayout d;
    @NonNull
    public final ToolbarDataOpenBinding e;
    @NonNull
    public final RadioGroup f;
    @NonNull
    public final Toolbar g;

    public ActivitySingleOperatorBinding(@NonNull CoordinatorLayout coordinatorLayout, @NonNull AppBarLayout appBarLayout, @NonNull CoordinatorLayout coordinatorLayout2, @NonNull FrameLayout frameLayout, @NonNull ToolbarDataOpenBinding toolbarDataOpenBinding, @NonNull RadioGroup radioGroup, @NonNull Toolbar toolbar) {
        this.a = coordinatorLayout;
        this.b = appBarLayout;
        this.c = coordinatorLayout2;
        this.d = frameLayout;
        this.e = toolbarDataOpenBinding;
        this.f = radioGroup;
        this.g = toolbar;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
