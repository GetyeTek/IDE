package com.huawei.digitalpayment.topup.bean;

import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import java.io.Serializable;

public class TopUpResp extends BaseResp implements Serializable {
    private TopUpBean topUpPageData;

    public TopUpBean getTopUpPageData() {
        return this.topUpPageData;
    }

    public void setTopUpPageData(TopUpBean topUpBean) {
        this.topUpPageData = topUpBean;
    }
}
