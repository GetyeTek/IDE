package com.huawei.digitalpayment.topup.bean;

import java.io.Serializable;
import java.util.List;

public class TopUpBean implements Serializable {
    private String currency;
    private List<OperatorsBean> operators;
    private String promotionBgColor;
    private String promotionBgImgUrl;

    public static class OperatorsBean implements Serializable {
        private String backgroundColor;
        private String brandLogoUrl;
        private List<String> numberSegment;
        private String operatorName;
        private List<PackageTabsBean> packageTabs;
        private List<TopUpPricesBean> prices;
        private String promotionImage;
        private String shortCode;
        private String titleLogoUrl;

        public String getBackgroundColor() {
            return this.backgroundColor;
        }

        public String getBrandLogoUrl() {
            return this.brandLogoUrl;
        }

        public List<String> getNumberSegment() {
            return this.numberSegment;
        }

        public String getOperatorName() {
            return this.operatorName;
        }

        public List<PackageTabsBean> getPackageTabs() {
            return this.packageTabs;
        }

        public List<TopUpPricesBean> getPrices() {
            return this.prices;
        }

        public String getPromotionImage() {
            return this.promotionImage;
        }

        public String getShortCode() {
            return this.shortCode;
        }

        public String getTitleLogoUrl() {
            return this.titleLogoUrl;
        }

        public void setBackgroundColor(String str) {
            this.backgroundColor = str;
        }

        public void setBrandLogoUrl(String str) {
            this.brandLogoUrl = str;
        }

        public void setNumberSegment(List<String> list) {
            this.numberSegment = list;
        }

        public void setOperatorName(String str) {
            this.operatorName = str;
        }

        public void setPackageTabs(List<PackageTabsBean> list) {
            this.packageTabs = list;
        }

        public void setPrices(List<TopUpPricesBean> list) {
            this.prices = list;
        }

        public void setPromotionImage(String str) {
            this.promotionImage = str;
        }

        public void setShortCode(String str) {
            this.shortCode = str;
        }

        public void setTitleLogoUrl(String str) {
            this.titleLogoUrl = str;
        }
    }

    public String getCurrency() {
        return this.currency;
    }

    public List<OperatorsBean> getOperators() {
        return this.operators;
    }

    public String getPromotionBgColor() {
        return this.promotionBgColor;
    }

    public String getPromotionBgImgUrl() {
        return this.promotionBgImgUrl;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setOperators(List<OperatorsBean> list) {
        this.operators = list;
    }

    public void setPromotionBgColor(String str) {
        this.promotionBgColor = str;
    }

    public void setPromotionBgImgUrl(String str) {
        this.promotionBgImgUrl = str;
    }
}
