package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundTextView;

public abstract class ActivityAutomaticSelectPageBinding extends ViewDataBinding {
    @NonNull
    public final EditText a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final LoadingButton c;
    @NonNull
    public final RadioGroup d;
    @NonNull
    public final RecyclerView e;
    @NonNull
    public final RoundTextView f;

    public ActivityAutomaticSelectPageBinding(DataBindingComponent dataBindingComponent, View view, EditText editText, ImageView imageView, LoadingButton loadingButton, RadioGroup radioGroup, RecyclerView recyclerView, RoundTextView roundTextView) {
        super(dataBindingComponent, view, 0);
        this.a = editText;
        this.b = imageView;
        this.c = loadingButton;
        this.d = radioGroup;
        this.e = recyclerView;
        this.f = roundTextView;
    }
}
