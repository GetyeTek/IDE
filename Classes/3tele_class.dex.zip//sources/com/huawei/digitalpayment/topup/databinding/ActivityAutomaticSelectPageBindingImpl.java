package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityAutomaticSelectPageBindingImpl extends ActivityAutomaticSelectPageBinding {
    @Nullable
    public static final SparseIntArray h;
    public long g;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        h = sparseIntArray;
        sparseIntArray.put(R$id.sl_content, 1);
        sparseIntArray.put(R$id.et_search, 2);
        sparseIntArray.put(R$id.iv_search_delete, 3);
        sparseIntArray.put(R$id.tv_search, 4);
        sparseIntArray.put(R$id.rg_data_package, 5);
        sparseIntArray.put(R$id.rv_package, 6);
        sparseIntArray.put(R$id.rl_submit_container, 7);
        sparseIntArray.put(R$id.lb_next, 8);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.g = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.g != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.g = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
