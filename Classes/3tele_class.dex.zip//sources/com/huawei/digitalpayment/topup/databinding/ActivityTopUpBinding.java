package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.google.android.material.appbar.AppBarLayout;

public final class ActivityTopUpBinding implements ViewBinding {
    @NonNull
    public final CoordinatorLayout a;
    @NonNull
    public final AppBarLayout b;
    @NonNull
    public final ConstraintLayout c;
    @NonNull
    public final CoordinatorLayout d;
    @NonNull
    public final EditText e;
    @NonNull
    public final FrameLayout f;
    @NonNull
    public final ToolbarTopupOpenBinding g;
    @NonNull
    public final ImageView h;
    @NonNull
    public final LinearLayout i;
    @NonNull
    public final NestedScrollView j;
    @NonNull
    public final RadioGroup k;
    @NonNull
    public final RecyclerView l;
    @NonNull
    public final RecyclerView m;
    @NonNull
    public final FrameLayout n;
    @NonNull
    public final Toolbar o;
    @NonNull
    public final TextView p;

    public ActivityTopUpBinding(@NonNull CoordinatorLayout coordinatorLayout, @NonNull AppBarLayout appBarLayout, @NonNull ConstraintLayout constraintLayout, @NonNull CoordinatorLayout coordinatorLayout2, @NonNull EditText editText, @NonNull FrameLayout frameLayout, @NonNull ToolbarTopupOpenBinding toolbarTopupOpenBinding, @NonNull ImageView imageView, @NonNull LinearLayout linearLayout, @NonNull NestedScrollView nestedScrollView, @NonNull RadioGroup radioGroup, @NonNull RecyclerView recyclerView, @NonNull RecyclerView recyclerView2, @NonNull FrameLayout frameLayout2, @NonNull Toolbar toolbar, @NonNull TextView textView) {
        this.a = coordinatorLayout;
        this.b = appBarLayout;
        this.c = constraintLayout;
        this.d = coordinatorLayout2;
        this.e = editText;
        this.f = frameLayout;
        this.g = toolbarTopupOpenBinding;
        this.h = imageView;
        this.i = linearLayout;
        this.j = nestedScrollView;
        this.k = radioGroup;
        this.l = recyclerView;
        this.m = recyclerView2;
        this.n = frameLayout2;
        this.o = toolbar;
        this.p = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
