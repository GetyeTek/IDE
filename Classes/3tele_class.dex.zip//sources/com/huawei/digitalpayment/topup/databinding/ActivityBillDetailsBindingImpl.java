package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ActivityBillDetailsBindingImpl extends ActivityBillDetailsBinding {
    @Nullable
    public static final SparseIntArray m;
    public long l;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        m = sparseIntArray;
        sparseIntArray.put(R$id.tv_customer_name, 1);
        sparseIntArray.put(R$id.scrollView, 2);
        sparseIntArray.put(R$id.constraintLayout, 3);
        sparseIntArray.put(R$id.recyclerview, 4);
        sparseIntArray.put(R$id.iv_for_total, 5);
        sparseIntArray.put(R$id.tv_for_self, 6);
        sparseIntArray.put(R$id.tv_total_bill_amount, 7);
        sparseIntArray.put(R$id.iv_for_other, 8);
        sparseIntArray.put(R$id.tv_for_other, 9);
        sparseIntArray.put(R$id.input_amount, 10);
        sparseIntArray.put(R$id.ll_btn, 11);
        sparseIntArray.put(R$id.btn_next, 12);
        sparseIntArray.put(R$id.emptyview, 13);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.l = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.l != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.l = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
