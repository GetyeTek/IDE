package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;

public abstract class TopupItemBuyAirtimeAmountListBinding extends ViewDataBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;

    public TopupItemBuyAirtimeAmountListBinding(DataBindingComponent dataBindingComponent, View view, RoundConstraintLayout roundConstraintLayout, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = roundConstraintLayout;
        this.b = textView;
        this.c = textView2;
        this.d = textView3;
    }
}
