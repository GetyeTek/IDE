package com.huawei.digitalpayment.topup.bean;

import android.text.TextUtils;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import java.io.Serializable;

public class TopUpPricesBean implements MultiItemEntity, Serializable {
    public static final int DISCOUNT = 2;
    public static final int NO_DISCOUNT = 1;
    private String discountDesc;
    private String finalPrice;
    private String itemId;
    private String mode;
    private String operatorShortCode;
    private String order;
    private String priceDisplay;
    private String priceId;

    public String getDiscountDesc() {
        return this.discountDesc;
    }

    public String getFinalPrice() {
        return this.finalPrice;
    }

    public String getItemId() {
        return this.itemId;
    }

    public int getItemType() {
        if (TextUtils.isEmpty(this.discountDesc)) {
            return 1;
        }
        return 2;
    }

    public String getMode() {
        return this.mode;
    }

    public String getOperatorShortCode() {
        return this.operatorShortCode;
    }

    public String getOrder() {
        return this.order;
    }

    public String getPriceDisplay() {
        return this.priceDisplay;
    }

    public String getPriceId() {
        return this.priceId;
    }

    public void setDiscountDesc(String str) {
        this.discountDesc = str;
    }

    public void setFinalPrice(String str) {
        this.finalPrice = str;
    }

    public void setItemId(String str) {
        this.itemId = str;
    }

    public void setMode(String str) {
        this.mode = str;
    }

    public void setOperatorShortCode(String str) {
        this.operatorShortCode = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setPriceDisplay(String str) {
        this.priceDisplay = str;
    }

    public void setPriceId(String str) {
        this.priceId = str;
    }
}
