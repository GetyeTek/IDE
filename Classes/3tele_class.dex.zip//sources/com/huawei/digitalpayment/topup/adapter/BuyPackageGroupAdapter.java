package com.huawei.digitalpayment.topup.adapter;

import I4.c;
import J4.a;
import J4.b;
import V1.h;
import android.widget.CheckBox;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.bean.DataPackGroupsBean;
import com.huawei.digitalpayment.topup.bean.DataPackItemBean;
import java.util.Collections;
import java.util.List;

public class BuyPackageGroupAdapter extends BaseQuickAdapter<DataPackGroupsBean, BaseViewHolder> {
    public static final /* synthetic */ int c = 0;
    public DataPackItemBean a;
    public c b;

    public BuyPackageGroupAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        DataPackGroupsBean dataPackGroupsBean = (DataPackGroupsBean) obj;
        baseViewHolder.setText(R$id.tv_group_name, dataPackGroupsBean.getGroupName());
        RecyclerView view = baseViewHolder.getView(R$id.rv_data_package);
        CheckBox checkBox = (CheckBox) baseViewHolder.getView(R$id.cb_check);
        view.setLayoutManager(new GridLayoutManager(baseViewHolder.itemView.getContext(), 2));
        List<DataPackItemBean> dataPackList = dataPackGroupsBean.getDataPackList();
        try {
            Collections.sort(dataPackList, new a(0));
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
        checkBox.setOnCheckedChangeListener(new b(view));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_data_buy_package, dataPackList);
        baseQuickAdapter.setOnItemClickListener(new J4.c(this, dataPackGroupsBean));
        view.setAdapter(baseQuickAdapter);
    }
}
