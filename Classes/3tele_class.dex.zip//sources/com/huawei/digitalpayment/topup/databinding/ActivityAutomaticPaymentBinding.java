package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class ActivityAutomaticPaymentBinding extends ViewDataBinding {
    @NonNull
    public final HFRecyclerView a;

    public ActivityAutomaticPaymentBinding(DataBindingComponent dataBindingComponent, View view, HFRecyclerView hFRecyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = hFRecyclerView;
    }
}
