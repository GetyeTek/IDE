package com.huawei.digitalpayment.topup.ui;

import M4.c;
import M4.d;
import N4.h;
import N4.i;
import N4.j;
import N4.k;
import N4.l;
import N4.m;
import N4.q;
import W2.n;
import android.animation.LayoutTransition;
import android.content.Intent;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.View;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.google.android.material.appbar.AppBarLayout;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.adapter.OperatorAdapter;
import com.huawei.digitalpayment.topup.adapter.TopUpAdapter;
import com.huawei.digitalpayment.topup.bean.PackageTabsBean;
import com.huawei.digitalpayment.topup.bean.TopUpBean;
import com.huawei.digitalpayment.topup.bean.TopUpPricesBean;
import com.huawei.digitalpayment.topup.databinding.ActivityTopUpBinding;
import com.huawei.digitalpayment.topup.view.PayLoadingDialog;
import com.huawei.digitalpayment.topup.viewmodel.TopUpViewModel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import w9.b;

@Route(path = "/topUpModule/topUp")
public class TopUpActivity extends BaseTitleActivity implements P2.a, AppBarLayout.OnOffsetChangedListener {
    public static final /* synthetic */ int u = 0;
    public ActivityTopUpBinding i;
    public List<TopUpBean.OperatorsBean> j = new ArrayList();
    public final ArrayList k = new ArrayList();
    public final ArrayList l = new ArrayList();
    public final ArrayList m = new ArrayList();
    public TopUpBean n;
    public OperatorAdapter o;
    public TopUpAdapter p;
    public TopUpViewModel q;
    public DataPackFragment r;
    public TopUpBean.OperatorsBean s;
    public PayLoadingDialog t;

    public class a implements OnItemClickListener {
        public a() {
        }

        /* JADX WARNING: type inference failed for: r2v1, types: [android.content.Context, com.huawei.digitalpayment.topup.ui.TopUpActivity] */
        public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
            ? r2 = TopUpActivity.this;
            Intent intent = new Intent(r2, SingleOperatorActivity.class);
            intent.putExtra("operatorsBean", r2.j.get(i));
            String obj = r2.i.e.getEditableText().toString();
            if (!TextUtils.isEmpty(obj)) {
                intent.putExtra("phoneNumber", obj);
            }
            r2.startActivity(intent);
        }
    }

    public final void D0() {
        TopUpViewModel topUpViewModel = new ViewModelProvider(this).get(TopUpViewModel.class);
        this.q = topUpViewModel;
        if (topUpViewModel.a == null) {
            topUpViewModel.a = new MutableLiveData<>();
        }
        topUpViewModel.a.observe(this, new h(this, 0));
        TopUpViewModel topUpViewModel2 = this.q;
        if (topUpViewModel2.b == null) {
            topUpViewModel2.b = new MutableLiveData<>();
        }
        topUpViewModel2.b.observe(this, new i(this));
        TopUpViewModel topUpViewModel3 = this.q;
        if (topUpViewModel3.c == null) {
            topUpViewModel3.c = new MutableLiveData<>();
        }
        topUpViewModel3.c.observe(this, new j(this, 0));
        TopUpViewModel topUpViewModel4 = this.q;
        if (topUpViewModel4.d == null) {
            topUpViewModel4.d = new MutableLiveData<>();
        }
        topUpViewModel4.d.observe(this, new k(this, 0));
        TopUpViewModel topUpViewModel5 = this.q;
        if (topUpViewModel5.e == null) {
            topUpViewModel5.e = new MutableLiveData<>();
        }
        topUpViewModel5.e.observe(this, new l(this, 0));
        TopUpViewModel topUpViewModel6 = this.q;
        n.b("");
        TopUpBean topUpBean = (TopUpBean) n.d("TopUpBean");
        if (topUpBean != null) {
            c.b = true;
            topUpViewModel6.a.setValue(topUpBean);
        } else {
            c.b = false;
        }
        d dVar = d.b;
        L2.c.a.getClass();
        io.reactivex.rxjava3.internal.operators.observable.n e = ((M4.a) dVar.c("https://www.superapp.ethiomobilemoney.et:38443/appgateway/consumer/appserver/consumer/").b(M4.a.class)).c().g(b.a()).e(b.a());
        C9.b.h(16, "initialCapacity");
        new io.reactivex.rxjava3.internal.operators.observable.b(e).a(new M4.b(this, topUpViewModel6));
        this.i.e.setText(n.b("").e("recent_login_phone_number"));
    }

    public final void G(String str) {
        this.t.dismiss();
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.topup.ui.TopUpActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, com.google.android.material.appbar.AppBarLayout$OnOffsetChangedListener] */
    @RequiresApi(api = 21)
    public final void G0() {
        super.G0();
        N0(getString(R$string.topup_top_up));
        U0();
        V0();
        this.i.e.addTextChangedListener(new q(this));
        this.i.h.setOnClickListener(new N4.n(this, 0));
        this.i.b.addOnOffsetChangedListener(this);
    }

    public final boolean H0() {
        return false;
    }

    /* JADX WARNING: type inference failed for: r21v0, types: [com.huawei.digitalpayment.topup.ui.TopUpActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0051, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.include_toolbar_close;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00c1, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.nv_scroll_view;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00df, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.rv_operators;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00eb, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.rv_top_up;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0103, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.toolbar;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0023, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.cl_air_time_container;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r21 = this;
            android.view.LayoutInflater r0 = r21.getLayoutInflater()
            int r1 = com.huawei.digitalpayment.topup.R$layout.activity_top_up
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.digitalpayment.topup.R$id.app_bar
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            com.google.android.material.appbar.AppBarLayout r5 = (com.google.android.material.appbar.AppBarLayout) r5
            java.lang.String r2 = "Missing required view with ID: "
            if (r5 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.choose_amount
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.cl_air_time_container
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r3
            androidx.constraintlayout.widget.ConstraintLayout r6 = (androidx.constraintlayout.widget.ConstraintLayout) r6
            if (r6 == 0) goto L_0x0135
            r7 = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout r7 = (androidx.coordinatorlayout.widget.CoordinatorLayout) r7
            int r1 = com.huawei.digitalpayment.topup.R$id.ctlCollapsingLayout
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.google.android.material.appbar.CollapsingToolbarLayout r3 = (com.google.android.material.appbar.CollapsingToolbarLayout) r3
            if (r3 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.edit_phone_number
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r3
            android.widget.EditText r8 = (android.widget.EditText) r8
            if (r8 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.fl_data_package_group
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r3
            android.widget.FrameLayout r9 = (android.widget.FrameLayout) r9
            if (r9 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.include_toolbar_close
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r3 == 0) goto L_0x0135
            r1 = r3
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            int r1 = com.huawei.digitalpayment.topup.R$id.imageView
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r1)
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            if (r4 == 0) goto L_0x015c
            int r4 = com.huawei.digitalpayment.topup.R$id.tv_base_title
            android.view.View r10 = androidx.viewbinding.ViewBindings.findChildViewById(r3, r4)
            android.widget.TextView r10 = (android.widget.TextView) r10
            if (r10 == 0) goto L_0x0158
            int r3 = com.huawei.digitalpayment.topup.R$id.include_toolbar_open
            android.view.View r10 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            if (r10 == 0) goto L_0x0138
            int r3 = com.huawei.digitalpayment.topup.R$id.cl_open_toolbar
            android.view.View r11 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r3)
            androidx.constraintlayout.widget.ConstraintLayout r11 = (androidx.constraintlayout.widget.ConstraintLayout) r11
            if (r11 == 0) goto L_0x0143
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0140
            int r1 = com.huawei.digitalpayment.topup.R$id.iv_promotion_image
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0140
            android.view.View r12 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r4)
            android.widget.TextView r12 = (android.widget.TextView) r12
            if (r12 == 0) goto L_0x013c
            com.huawei.digitalpayment.topup.databinding.ToolbarTopupOpenBinding r12 = new com.huawei.digitalpayment.topup.databinding.ToolbarTopupOpenBinding
            androidx.constraintlayout.widget.ConstraintLayout r10 = (androidx.constraintlayout.widget.ConstraintLayout) r10
            r12.<init>(r10, r11, r3)
            int r3 = com.huawei.digitalpayment.topup.R$id.iv_get_contact
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r3)
            r11 = r4
            android.widget.ImageView r11 = (android.widget.ImageView) r11
            if (r11 == 0) goto L_0x0138
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.ll_bg_container
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r13 = r3
            android.widget.LinearLayout r13 = (android.widget.LinearLayout) r13
            if (r13 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.nv_scroll_view
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r14 = r3
            androidx.core.widget.NestedScrollView r14 = (androidx.core.widget.NestedScrollView) r14
            if (r14 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.phone_number_line
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r3 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.rg_data_package
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r15 = r3
            android.widget.RadioGroup r15 = (android.widget.RadioGroup) r15
            if (r15 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.rv_operators
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r16 = r3
            androidx.recyclerview.widget.RecyclerView r16 = (androidx.recyclerview.widget.RecyclerView) r16
            if (r16 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.rv_top_up
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r17 = r3
            androidx.recyclerview.widget.RecyclerView r17 = (androidx.recyclerview.widget.RecyclerView) r17
            if (r17 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.sv_content
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r18 = r3
            android.widget.FrameLayout r18 = (android.widget.FrameLayout) r18
            if (r18 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.toolbar
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r19 = r3
            androidx.appcompat.widget.Toolbar r19 = (androidx.appcompat.widget.Toolbar) r19
            if (r19 == 0) goto L_0x0135
            int r1 = com.huawei.digitalpayment.topup.R$id.tv_operator
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r20 = r3
            android.widget.TextView r20 = (android.widget.TextView) r20
            if (r20 == 0) goto L_0x0135
            com.huawei.digitalpayment.topup.databinding.ActivityTopUpBinding r0 = new com.huawei.digitalpayment.topup.databinding.ActivityTopUpBinding
            r3 = r0
            r4 = r7
            r10 = r12
            r12 = r13
            r13 = r14
            r14 = r15
            r15 = r16
            r16 = r17
            r17 = r18
            r18 = r19
            r19 = r20
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19)
            r5 = r21
            r5.i = r0
            return r0
        L_0x0135:
            r5 = r21
            goto L_0x0170
        L_0x0138:
            r5 = r21
            r1 = r3
            goto L_0x0170
        L_0x013c:
            r5 = r21
            r1 = r4
            goto L_0x0146
        L_0x0140:
            r5 = r21
            goto L_0x0146
        L_0x0143:
            r5 = r21
            r1 = r3
        L_0x0146:
            android.content.res.Resources r0 = r10.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x0158:
            r5 = r21
            r1 = r4
            goto L_0x015e
        L_0x015c:
            r5 = r21
        L_0x015e:
            android.content.res.Resources r0 = r3.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x0170:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.topup.ui.TopUpActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final boolean L0() {
        return false;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.topup.ui.TopUpActivity] */
    public final void U0() {
        List<TopUpBean.OperatorsBean> list = this.j;
        if (list == null || list.size() <= 0) {
            this.i.l.setVisibility(8);
            this.i.f.setVisibility(0);
        } else {
            this.i.l.setVisibility(0);
            this.i.f.setVisibility(8);
        }
        this.i.l.setLayoutManager(new GridLayoutManager(this, 2));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_operators, this.j);
        this.o = baseQuickAdapter;
        baseQuickAdapter.setOnItemClickListener(new a());
        this.i.l.setAdapter(this.o);
    }

    public final void V(String str) {
        PayLoadingDialog payLoadingDialog = new PayLoadingDialog();
        this.t = payLoadingDialog;
        payLoadingDialog.show(getSupportFragmentManager(), "topUp");
    }

    /* JADX WARNING: type inference failed for: r0v8, types: [com.huawei.digitalpayment.topup.ui.DataPackFragment, com.huawei.digitalpayment.customer.baselib.base.BaseFragment] */
    public final void V0() {
        DataPackFragment dataPackFragment = this.r;
        ArrayList arrayList = this.m;
        if (dataPackFragment == null) {
            ? baseFragment = new BaseFragment();
            if (arrayList != null) {
                baseFragment.d = arrayList;
            }
            this.r = baseFragment;
            baseFragment.g = this.s;
            baseFragment.i = new m(this);
            getSupportFragmentManager().beginTransaction().replace(R$id.fl_data_package_group, this.r).commitNow();
        } else {
            dataPackFragment.d = arrayList;
            dataPackFragment.e.notifyDataSetChanged();
            this.r.g = this.s;
        }
        if (arrayList == null || arrayList.size() <= 0) {
            this.i.f.setVisibility(8);
        } else {
            this.i.f.setVisibility(0);
        }
    }

    /* JADX WARNING: type inference failed for: r2v4, types: [java.lang.Object, java.util.Comparator] */
    public final void W0(String str) {
        TopUpBean.OperatorsBean operatorsBean;
        PackageTabsBean packageTabsBean;
        TopUpBean topUpBean = this.n;
        if (topUpBean != null) {
            String promotionBgImgUrl = topUpBean.getPromotionBgImgUrl();
            String promotionBgColor = this.n.getPromotionBgColor();
            if (!TextUtils.isEmpty(promotionBgImgUrl)) {
                this.i.g.c.setVisibility(0);
                this.i.g.b.setVisibility(0);
                O9.c.c(this.i.g.c, promotionBgImgUrl, -1);
            }
            if (!TextUtils.isEmpty(promotionBgColor)) {
                this.i.i.setBackgroundColor(Color.parseColor(promotionBgColor));
                this.i.o.setBackgroundColor(Color.parseColor(promotionBgColor));
                this.i.n.setBackgroundColor(Color.parseColor(promotionBgColor));
                this.i.j.setBackgroundColor(Color.parseColor(promotionBgColor));
            }
            List<TopUpBean.OperatorsBean> operators = this.n.getOperators();
            if (operators != null && operators.size() > 0) {
                if (operators.size() == 1) {
                    operatorsBean = operators.get(0);
                } else {
                    operatorsBean = O4.b.b(str, this.n);
                }
                if (operatorsBean == null || !O4.b.a(str, operatorsBean)) {
                    this.s = null;
                    this.q.b.setValue(operators);
                    if (TextUtils.isEmpty(str)) {
                        this.i.p.setText(R$string.topup_empty_phone_number);
                    } else {
                        this.i.p.setText(R$string.topup_illegal_investment);
                    }
                    this.i.p.setTextColor(getResources().getColor(R$color.colorError));
                    TopUpAdapter topUpAdapter = this.p;
                    if (topUpAdapter != null) {
                        topUpAdapter.b = false;
                        topUpAdapter.notifyDataSetChanged();
                        return;
                    }
                    return;
                }
                this.i.p.setText(operatorsBean.getOperatorName());
                this.i.p.setTextColor(getResources().getColor(R$color.black));
                TopUpBean.OperatorsBean operatorsBean2 = this.s;
                if (operatorsBean2 == null || !TextUtils.equals(operatorsBean2.getOperatorName(), operatorsBean.getOperatorName())) {
                    this.s = operatorsBean;
                    if (this.q != null) {
                        List<TopUpPricesBean> prices = operatorsBean.getPrices();
                        if (prices == null || prices.size() <= 0) {
                            this.i.c.setVisibility(8);
                        } else {
                            this.i.c.setVisibility(0);
                            TopUpViewModel topUpViewModel = this.q;
                            topUpViewModel.getClass();
                            try {
                                Collections.sort(prices, new Object());
                            } catch (Exception unused) {
                            }
                            topUpViewModel.c.setValue(prices);
                        }
                        TopUpViewModel topUpViewModel2 = this.q;
                        topUpViewModel2.d.setValue(operatorsBean.getPackageTabs());
                        if (operatorsBean.getPackageTabs() != null && (packageTabsBean = operatorsBean.getPackageTabs().get(0)) != null) {
                            this.q.a(packageTabsBean.getPackageGroups());
                        }
                    }
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.digitalpayment.topup.ui.TopUpActivity, android.app.Activity] */
    public void onBackClick(View view) {
        finish();
    }

    public final void onOffsetChanged(AppBarLayout appBarLayout, int i2) {
        int i5;
        float abs = ((float) Math.abs(i2)) / ((float) appBarLayout.getTotalScrollRange());
        Toolbar toolbar = this.i.o;
        int i6 = (abs > 0.0f ? 1 : (abs == 0.0f ? 0 : -1));
        if (i6 == 0) {
            i5 = 8;
        } else {
            i5 = 0;
        }
        toolbar.setVisibility(i5);
        this.i.o.setAlpha(abs);
        this.i.g.c.setAlpha(1.0f - abs);
        if (i6 == 0) {
            LayoutTransition layoutTransition = new LayoutTransition();
            layoutTransition.setDuration(400);
            layoutTransition.enableTransitionType(4);
            layoutTransition.setAnimateParentHierarchy(false);
            this.i.d.setLayoutTransition(layoutTransition);
            return;
        }
        this.i.d.setLayoutTransition((LayoutTransition) null);
    }

    public final void v(BaseResp baseResp) {
        V1.k.b(1, baseResp.getResponseDesc());
    }
}
