package com.huawei.digitalpayment.topup.bean;

import java.io.Serializable;

public class TabIconBean implements Serializable {
    private String tabIconNormal;
    private String tabIconNormalBg;
    private String tabIconSelected;
    private String tabIconSelectorBg;

    public String getTabIconNormal() {
        return this.tabIconNormal;
    }

    public String getTabIconNormalBg() {
        return this.tabIconNormalBg;
    }

    public String getTabIconSelected() {
        return this.tabIconSelected;
    }

    public String getTabIconSelectorBg() {
        return this.tabIconSelectorBg;
    }

    public void setTabIconNormal(String str) {
        this.tabIconNormal = str;
    }

    public void setTabIconNormalBg(String str) {
        this.tabIconNormalBg = str;
    }

    public void setTabIconSelected(String str) {
        this.tabIconSelected = str;
    }

    public void setTabIconSelectorBg(String str) {
        this.tabIconSelectorBg = str;
    }
}
