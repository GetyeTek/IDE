package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;

public final class ActivityFuelPaymentQrCodeBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final Button b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public ActivityFuelPaymentQrCodeBinding(@NonNull ConstraintLayout constraintLayout, @NonNull Button button, @NonNull ImageView imageView, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = button;
        this.c = imageView;
        this.d = textView;
        this.e = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
