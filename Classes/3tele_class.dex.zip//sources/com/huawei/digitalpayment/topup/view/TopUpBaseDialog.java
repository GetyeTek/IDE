package com.huawei.digitalpayment.topup.view;

import V1.h;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.FragmentManager;
import com.huawei.digitalpayment.topup.R$style;

public abstract class TopUpBaseDialog extends AppCompatDialogFragment {
    public boolean a;

    public final void dismiss() {
        try {
            TopUpBaseDialog.super.dismissAllowingStateLoss();
            this.a = false;
        } catch (Exception unused) {
        }
    }

    public final void onCreate(Bundle bundle) {
        TopUpBaseDialog.super.onCreate(bundle);
        setStyle(0, R$style.TopUpBaseDialogFragment);
    }

    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (v0() != 0) {
            return layoutInflater.inflate(v0(), viewGroup, false);
        }
        throw new NullPointerException("please set legitimate Id");
    }

    public void onStart() {
        Window window;
        TopUpBaseDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(17);
            window.setLayout(-2, -2);
            window.setBackgroundDrawableResource(17170445);
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelable(false);
        }
    }

    public final void show(FragmentManager fragmentManager, String str) {
        try {
            if (!this.a) {
                TopUpBaseDialog.super.show(fragmentManager, str);
                this.a = true;
            }
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
    }

    public abstract int v0();
}
