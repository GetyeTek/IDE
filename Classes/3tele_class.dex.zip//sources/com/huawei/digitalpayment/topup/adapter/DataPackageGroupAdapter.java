package com.huawei.digitalpayment.topup.adapter;

import J4.e;
import N4.a;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.bean.DataPackGroupsBean;
import com.huawei.digitalpayment.topup.bean.DataPackItemBean;
import java.util.Collections;
import java.util.List;

public class DataPackageGroupAdapter extends BaseQuickAdapter<DataPackGroupsBean, BaseViewHolder> {
    public static final /* synthetic */ int b = 0;
    public a a;

    public DataPackageGroupAdapter() {
        throw null;
    }

    /* JADX WARNING: type inference failed for: r1v3, types: [java.lang.Object, java.util.Comparator] */
    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        DataPackGroupsBean dataPackGroupsBean = (DataPackGroupsBean) obj;
        baseViewHolder.setText(R$id.tv_group_name, dataPackGroupsBean.getGroupName());
        RecyclerView view = baseViewHolder.getView(R$id.rv_data_package);
        view.setLayoutManager(new GridLayoutManager(baseViewHolder.itemView.getContext(), 2));
        List<DataPackItemBean> dataPackList = dataPackGroupsBean.getDataPackList();
        try {
            Collections.sort(dataPackList, new Object());
        } catch (Exception unused) {
        }
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_data_package, dataPackList);
        baseQuickAdapter.setOnItemClickListener(new e(this, dataPackGroupsBean));
        view.setAdapter(baseQuickAdapter);
    }
}
