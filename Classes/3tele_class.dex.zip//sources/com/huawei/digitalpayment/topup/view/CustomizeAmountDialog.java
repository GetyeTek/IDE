package com.huawei.digitalpayment.topup.view;

import H1.c;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.blankj.utilcode.util.v;
import com.huawei.digitalpayment.customer.viewlib.view.DigitalVirtualKeyboardView;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$style;

public class CustomizeAmountDialog extends TopUpBaseDialog {

    public class a implements View.OnClickListener {
        public a() {
        }

        public final void onClick(View view) {
            CustomizeAmountDialog.this.dismiss();
        }
    }

    public final void onStart() {
        Window window;
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, v.a(357.0f));
            window.setBackgroundDrawableResource(17170443);
            c.b(window, R$style.TopUpConfirmBottomAnimation, dialog, false, false);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        CustomizeAmountDialog.super.onViewCreated(view, bundle);
        EditText editText = (EditText) view.findViewById(R$id.et_amount);
        D2.c.a(getActivity(), editText);
        view.findViewById(R$id.iv_amount_close).setOnClickListener(new a());
        editText.requestFocus();
        DigitalVirtualKeyboardView digitalVirtualKeyboardView = (DigitalVirtualKeyboardView) view.findViewById(R$id.digitalVirtualKeyboardView);
    }

    public final int v0() {
        return R$layout.dialog_topup_amount_layout;
    }
}
