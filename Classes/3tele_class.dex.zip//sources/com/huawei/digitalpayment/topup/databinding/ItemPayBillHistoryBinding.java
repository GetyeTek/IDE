package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundTextView;

public abstract class ItemPayBillHistoryBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;

    public ItemPayBillHistoryBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = textView;
        this.c = textView2;
    }
}
