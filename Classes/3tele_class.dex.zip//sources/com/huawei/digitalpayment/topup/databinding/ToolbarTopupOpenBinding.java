package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;

public final class ToolbarTopupOpenBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final ConstraintLayout b;
    @NonNull
    public final ImageView c;

    public ToolbarTopupOpenBinding(@NonNull ConstraintLayout constraintLayout, @NonNull ConstraintLayout constraintLayout2, @NonNull ImageView imageView) {
        this.a = constraintLayout;
        this.b = constraintLayout2;
        this.c = imageView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
