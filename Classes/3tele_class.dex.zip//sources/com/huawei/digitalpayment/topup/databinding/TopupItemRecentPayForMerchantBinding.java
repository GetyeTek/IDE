package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class TopupItemRecentPayForMerchantBinding extends ViewDataBinding {
    @NonNull
    public final TextView a;
    @NonNull
    public final TextView b;

    public TopupItemRecentPayForMerchantBinding(DataBindingComponent dataBindingComponent, View view, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = textView;
        this.b = textView2;
    }
}
