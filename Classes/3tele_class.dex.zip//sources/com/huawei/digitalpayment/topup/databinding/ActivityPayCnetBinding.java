package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundLinearLayout;

public abstract class ActivityPayCnetBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final RoundLinearLayout c;

    public ActivityPayCnetBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, ImageView imageView, RoundLinearLayout roundLinearLayout) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = imageView;
        this.c = roundLinearLayout;
    }
}
