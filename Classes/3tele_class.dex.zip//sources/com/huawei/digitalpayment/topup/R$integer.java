package com.huawei.digitalpayment.topup;

public final class R$integer {
    public static final int abc_config_activityDefaultDur = 2131427328;
    public static final int abc_config_activityShortDur = 2131427329;
    public static final int app_bar_elevation_anim_duration = 2131427330;
    public static final int bottom_sheet_slide_duration = 2131427331;
    public static final int cancel_button_image_alpha = 2131427332;
    public static final int config_navAnimTime = 2131427333;
    public static final int config_tooltipAnimTime = 2131427334;
    public static final int design_snackbar_text_max_lines = 2131427335;
    public static final int design_tab_indicator_anim_duration_ms = 2131427336;
    public static final int google_play_services_version = 2131427337;
    public static final int hide_password_duration = 2131427338;
    public static final int m3_btn_anim_delay_ms = 2131427340;
    public static final int m3_btn_anim_duration_ms = 2131427341;
    public static final int m3_card_anim_delay_ms = 2131427342;
    public static final int m3_card_anim_duration_ms = 2131427343;
    public static final int m3_chip_anim_duration = 2131427344;
    public static final int m3_sys_motion_path = 2131427361;
    public static final int material_motion_duration_long_1 = 2131427368;
    public static final int material_motion_duration_long_2 = 2131427369;
    public static final int material_motion_duration_medium_1 = 2131427370;
    public static final int material_motion_duration_medium_2 = 2131427371;
    public static final int material_motion_duration_short_1 = 2131427372;
    public static final int material_motion_duration_short_2 = 2131427373;
    public static final int material_motion_path = 2131427374;
    public static final int mtrl_badge_max_character_count = 2131427375;
    public static final int mtrl_btn_anim_delay_ms = 2131427376;
    public static final int mtrl_btn_anim_duration_ms = 2131427377;
    public static final int mtrl_calendar_header_orientation = 2131427378;
    public static final int mtrl_calendar_selection_text_lines = 2131427379;
    public static final int mtrl_calendar_year_selector_span = 2131427380;
    public static final int mtrl_card_anim_delay_ms = 2131427381;
    public static final int mtrl_card_anim_duration_ms = 2131427382;
    public static final int mtrl_chip_anim_duration = 2131427383;
    public static final int mtrl_tab_indicator_anim_duration_ms = 2131427392;
    public static final int mtrl_view_gone = 2131427393;
    public static final int mtrl_view_invisible = 2131427394;
    public static final int mtrl_view_visible = 2131427395;
    public static final int show_password_duration = 2131427396;
    public static final int status_bar_notification_info_maxnum = 2131427397;
    public static final int ucrop_progress_loading_anim_time = 2131427398;

    private R$integer() {
    }
}
