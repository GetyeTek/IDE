package com.huawei.digitalpayment.topup.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.topup.R$id;

public class ItemAutomaticPaymentBindingImpl extends ItemAutomaticPaymentBinding {
    @Nullable
    public static final SparseIntArray b;
    public long a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        b = sparseIntArray;
        sparseIntArray.put(R$id.ivDelete, 1);
        sparseIntArray.put(R$id.tvAutomaticPaymentName, 2);
        sparseIntArray.put(R$id.tvFrequency, 3);
        sparseIntArray.put(R$id.displayRecycler, 4);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.a = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.a != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.a = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
