package com.huawei.digitalpayment.topup.view;

import com.huawei.digitalpayment.topup.R$layout;

public class PayLoadingDialog extends TopUpBaseDialog {
    public final int v0() {
        return R$layout.layout_top_up_loading_circle;
    }
}
