package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class DialogTopupConfirmLayoutBinding implements ViewBinding {
    @NonNull
    public final /* bridge */ /* synthetic */ View getRoot() {
        return null;
    }
}
