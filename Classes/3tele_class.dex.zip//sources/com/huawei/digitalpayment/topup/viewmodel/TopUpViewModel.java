package com.huawei.digitalpayment.topup.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.topup.bean.DataPackGroupsBean;
import com.huawei.digitalpayment.topup.bean.PackageTabsBean;
import com.huawei.digitalpayment.topup.bean.TopUpBean;
import com.huawei.digitalpayment.topup.bean.TopUpPricesBean;
import java.util.Collections;
import java.util.List;

public class TopUpViewModel extends ViewModel {
    public MutableLiveData<TopUpBean> a;
    public MutableLiveData<List<TopUpBean.OperatorsBean>> b;
    public MutableLiveData<List<TopUpPricesBean>> c;
    public MutableLiveData<List<PackageTabsBean>> d;
    public MutableLiveData<List<DataPackGroupsBean>> e;

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, java.util.Comparator] */
    public final void a(List<DataPackGroupsBean> list) {
        try {
            Collections.sort(list, new Object());
        } catch (Exception unused) {
        }
        this.e.setValue(list);
    }
}
