package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.google.android.material.textfield.TextInputLayout;

public final class ToolbarDataOpenBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final EditText b;
    @NonNull
    public final ConstraintLayout c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final ImageView e;
    @NonNull
    public final TextInputLayout f;

    public ToolbarDataOpenBinding(@NonNull ConstraintLayout constraintLayout, @NonNull EditText editText, @NonNull ConstraintLayout constraintLayout2, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull TextInputLayout textInputLayout) {
        this.a = constraintLayout;
        this.b = editText;
        this.c = constraintLayout2;
        this.d = imageView;
        this.e = imageView2;
        this.f = textInputLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
