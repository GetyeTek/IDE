package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class ItemPayBillDetailsBinding extends ViewDataBinding {
    @NonNull
    public final TextView a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;

    public ItemPayBillDetailsBinding(DataBindingComponent dataBindingComponent, View view, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = textView;
        this.b = textView2;
        this.c = textView3;
    }
}
