package com.huawei.digitalpayment.topup.bean;

import com.google.gson.JsonObject;
import java.io.Serializable;
import java.util.List;

public class PackageTabsBean implements Serializable {
    private JsonObject extJson;
    private String operatorShortCode;
    private Integer order;
    private List<DataPackGroupsBean> packageGroups;
    private String tabIcon;
    private String tabId;
    private String tabName;

    public JsonObject getExtJson() {
        return this.extJson;
    }

    public Integer getOrder() {
        return this.order;
    }

    public List<DataPackGroupsBean> getPackageGroups() {
        return this.packageGroups;
    }

    public String getTabIcon() {
        return this.tabIcon;
    }

    public String getTabName() {
        return this.tabName;
    }

    public void setExtJson(JsonObject jsonObject) {
        this.extJson = jsonObject;
    }

    public void setOrder(Integer num) {
        this.order = num;
    }

    public void setPackageGroups(List<DataPackGroupsBean> list) {
        this.packageGroups = list;
    }

    public void setTabIcon(String str) {
        this.tabIcon = str;
    }

    public void setTabName(String str) {
        this.tabName = str;
    }
}
