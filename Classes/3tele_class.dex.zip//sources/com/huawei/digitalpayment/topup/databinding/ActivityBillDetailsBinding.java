package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class ActivityBillDetailsBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final View b;
    @NonNull
    public final CommonInputView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final ImageView e;
    @NonNull
    public final HFRecyclerView f;
    @NonNull
    public final ScrollView g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;

    public ActivityBillDetailsBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, View view2, CommonInputView commonInputView, ImageView imageView, ImageView imageView2, HFRecyclerView hFRecyclerView, ScrollView scrollView, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = view2;
        this.c = commonInputView;
        this.d = imageView;
        this.e = imageView2;
        this.f = hFRecyclerView;
        this.g = scrollView;
        this.h = textView;
        this.i = textView2;
        this.j = textView3;
        this.k = textView4;
    }
}
