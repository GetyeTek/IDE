package com.huawei.digitalpayment.topup.adapter;

import B6.b;
import J4.f;
import J4.g;
import J4.h;
import J4.i;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.VehicleBean;
import com.huawei.digitalpayment.fuel.activity.FuelPaymentVehicleManageActivity;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$string;

public class VehicleManageAdapter extends BaseQuickAdapter<VehicleBean, BaseViewHolder> {
    public FuelPaymentVehicleManageActivity a;
    public b b;

    /* JADX WARNING: type inference failed for: r1v3, types: [android.content.Context, com.huawei.digitalpayment.fuel.activity.FuelPaymentVehicleManageActivity] */
    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        String str;
        VehicleBean vehicleBean = (VehicleBean) obj;
        baseViewHolder.setText(R$id.tv_vehicle_plate_number, vehicleBean.getPlateNumber().replace("-", ""));
        boolean equals = "1".equals(vehicleBean.getFuelType());
        ? r1 = this.a;
        if (equals) {
            str = r1.getString(R$string.benzene);
        } else {
            str = r1.getString(R$string.diesel);
        }
        baseViewHolder.setText(R$id.tv_fuel_type, str);
        int itemPosition = getItemPosition(vehicleBean);
        baseViewHolder.getView(R$id.iv_arrow_right).setOnClickListener(new f(this, vehicleBean));
        baseViewHolder.getView(R$id.iv_edit).setOnClickListener(new g(this, vehicleBean, itemPosition));
        baseViewHolder.getView(R$id.iv_delete).setOnClickListener(new h(this, vehicleBean, itemPosition));
        baseViewHolder.getView(R$id.cl_container).setOnClickListener(new i(this, vehicleBean, 0));
    }
}
