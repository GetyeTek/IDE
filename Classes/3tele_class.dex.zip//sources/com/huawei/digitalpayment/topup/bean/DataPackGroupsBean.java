package com.huawei.digitalpayment.topup.bean;

import J8.a;
import java.io.Serializable;
import java.util.List;
import java.util.Locale;

public class DataPackGroupsBean implements Serializable {
    private List<DataPackItemBean> dataPackList;
    private String groupId;
    private String groupName;
    private Integer order;
    private String tabId;

    public boolean contain(String str) {
        if (a.i(this.dataPackList)) {
            return false;
        }
        for (DataPackItemBean itemDesc : this.dataPackList) {
            String itemDesc2 = itemDesc.getItemDesc();
            Locale locale = Locale.ROOT;
            if (itemDesc2.toLowerCase(locale).contains(str.toLowerCase(locale))) {
                return true;
            }
        }
        return false;
    }

    public List<DataPackItemBean> getDataPackList() {
        return this.dataPackList;
    }

    public String getGroupId() {
        return this.groupId;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public Integer getOrder() {
        return this.order;
    }

    public String getTabId() {
        return this.tabId;
    }

    public void setDataPackList(List<DataPackItemBean> list) {
        this.dataPackList = list;
    }

    public void setGroupId(String str) {
        this.groupId = str;
    }

    public void setGroupName(String str) {
        this.groupName = str;
    }

    public void setOrder(Integer num) {
        this.order = num;
    }

    public void setTabId(String str) {
        this.tabId = str;
    }
}
