package com.huawei.digitalpayment.topup.adapter;

import D5.a;
import android.content.res.Resources;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.VerifySecurityQuestionResp;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$drawable;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.bean.TopUpPricesBean;

public class TopUpAdapter extends BaseMultiItemQuickAdapter<TopUpPricesBean, BaseViewHolder> {
    public String a;
    public boolean b;

    public TopUpAdapter() {
        throw null;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        TopUpPricesBean topUpPricesBean = (TopUpPricesBean) obj;
        if (TextUtils.equals(topUpPricesBean.getMode(), VerifySecurityQuestionResp.CODE_SUCCESS)) {
            if (!TextUtils.isEmpty(topUpPricesBean.getDiscountDesc())) {
                int i = R$id.tv_final_price;
                baseViewHolder.setText(i, J.a().getString(R$string.topup_cash_back) + topUpPricesBean.getDiscountDesc());
            }
            baseViewHolder.setText(R$id.tv_currency, this.a);
            try {
                baseViewHolder.setText(R$id.tv_charge_amount, a.c(topUpPricesBean.getPriceDisplay()));
            } catch (Exception unused) {
            }
        } else {
            baseViewHolder.setText(R$id.tv_charge_amount, topUpPricesBean.getPriceDisplay());
        }
        if (!this.b) {
            baseViewHolder.itemView.setEnabled(false);
            int i2 = R$id.tv_charge_amount;
            Resources resources = J.a().getResources();
            int i5 = R$color.colorTextLevel3;
            baseViewHolder.setTextColor(i2, resources.getColor(i5));
            baseViewHolder.setTextColor(R$id.tv_currency, J.a().getResources().getColor(i5));
            baseViewHolder.itemView.setBackground(J.a().getResources().getDrawable(R$drawable.shape_top_up_item_bg_unable));
            return;
        }
        int i6 = R$id.tv_charge_amount;
        Resources resources2 = J.a().getResources();
        int i7 = R$color.colorPrimary;
        baseViewHolder.setTextColor(i6, resources2.getColor(i7));
        baseViewHolder.setTextColor(R$id.tv_currency, J.a().getResources().getColor(i7));
        baseViewHolder.itemView.setEnabled(true);
        baseViewHolder.itemView.setBackground(J.a().getResources().getDrawable(R$drawable.shape_top_up_item_bg));
    }
}
