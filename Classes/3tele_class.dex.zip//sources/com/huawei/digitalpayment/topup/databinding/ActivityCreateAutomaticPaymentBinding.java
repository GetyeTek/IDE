package com.huawei.digitalpayment.topup.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.input.CommonInputView;

public abstract class ActivityCreateAutomaticPaymentBinding extends ViewDataBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final CommonInputView b;
    @NonNull
    public final View c;
    @NonNull
    public final EditText d;
    @NonNull
    public final LoadingButton e;
    @NonNull
    public final LinearLayout f;
    @NonNull
    public final CommonInputView g;
    @NonNull
    public final CommonInputView h;
    @NonNull
    public final CommonInputView i;
    @NonNull
    public final CommonInputView j;
    @NonNull
    public final CommonInputView k;
    @NonNull
    public final CommonInputView l;
    @NonNull
    public final CommonInputView m;
    @NonNull
    public final CommonInputView n;
    @NonNull
    public final CommonInputView o;
    @NonNull
    public final ConstraintLayout p;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ActivityCreateAutomaticPaymentBinding(DataBindingComponent dataBindingComponent, View view, ConstraintLayout constraintLayout, CommonInputView commonInputView, View view2, EditText editText, LoadingButton loadingButton, LinearLayout linearLayout, CommonInputView commonInputView2, CommonInputView commonInputView3, CommonInputView commonInputView4, CommonInputView commonInputView5, CommonInputView commonInputView6, CommonInputView commonInputView7, CommonInputView commonInputView8, CommonInputView commonInputView9, CommonInputView commonInputView10, ConstraintLayout constraintLayout2) {
        super(dataBindingComponent, view, 0);
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view3 = view;
        this.a = constraintLayout;
        this.b = commonInputView;
        this.c = view2;
        this.d = editText;
        this.e = loadingButton;
        this.f = linearLayout;
        this.g = commonInputView2;
        this.h = commonInputView3;
        this.i = commonInputView4;
        this.j = commonInputView5;
        this.k = commonInputView6;
        this.l = commonInputView7;
        this.m = commonInputView8;
        this.n = commonInputView9;
        this.o = commonInputView10;
        this.p = constraintLayout2;
    }
}
