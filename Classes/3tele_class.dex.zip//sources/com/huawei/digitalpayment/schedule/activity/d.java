package com.huawei.digitalpayment.schedule.activity;

import android.widget.RadioGroup;

public final /* synthetic */ class d implements RadioGroup.OnCheckedChangeListener {
    public final /* synthetic */ AutomaticBuyPackageSelectPageActivity a;

    public /* synthetic */ d(AutomaticBuyPackageSelectPageActivity automaticBuyPackageSelectPageActivity) {
        this.a = automaticBuyPackageSelectPageActivity;
    }

    public final void onCheckedChanged(RadioGroup radioGroup, int i) {
        int i2 = AutomaticBuyPackageSelectPageActivity.l;
        this.a.E0();
    }
}
