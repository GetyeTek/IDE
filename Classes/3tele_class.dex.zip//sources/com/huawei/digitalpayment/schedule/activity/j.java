package com.huawei.digitalpayment.schedule.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum;
import com.huawei.module_cash.withdrawcash.ApplyAtmVoucherSuccessActivity;
import java.util.Map;
import o0.b;

public final /* synthetic */ class j implements View.OnClickListener {
    public final /* synthetic */ int a = 1;

    public /* synthetic */ j() {
    }

    public final void onClick(View view) {
        switch (this.a) {
            case 0:
                int i = AutomaticPaymentActivity.g;
                AutomaticPaymentActivity.E0(CreateAutomaticEnum.PAY_BILL);
                return;
            default:
                int i2 = ApplyAtmVoucherSuccessActivity.j;
                b.d((Activity) null, "/mainV5Module/main", (Bundle) null, (Map) null);
                return;
        }
    }

    public /* synthetic */ j(AutomaticPaymentActivity automaticPaymentActivity) {
    }
}
