package com.huawei.digitalpayment.schedule.resp;

import com.huawei.http.BaseResp;
import java.util.List;

public class AutomaticPaymentListResp extends BaseResp {
    private List<AutomaticPaymentResp> reminderScheduleInfoDetails;

    public List<AutomaticPaymentResp> getReminderScheduleInfoDetails() {
        return this.reminderScheduleInfoDetails;
    }

    public void setReminderScheduleInfoDetails(List<AutomaticPaymentResp> list) {
        this.reminderScheduleInfoDetails = list;
    }
}
