package com.huawei.digitalpayment.schedule.activity;

import I4.g;
import android.view.View;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.l;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.digitalpayment.schedule.dialog.SelectBillerDialog;
import com.huawei.digitalpayment.schedule.repository.QueryBillerConfigRepository;
import com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel;
import com.huawei.digitalpayment.topup.R$string;

public final class p implements View.OnClickListener {
    public final /* synthetic */ CreateAutomaticPaymentActivity a;

    public p(CreateAutomaticPaymentActivity createAutomaticPaymentActivity) {
        this.a = createAutomaticPaymentActivity;
    }

    public final void onClick(View view) {
        FragmentActivity fragmentActivity = this.a;
        if (fragmentActivity.l == null) {
            if (fragmentActivity.m == null) {
                LoadingDialog loadingDialog = new LoadingDialog();
                fragmentActivity.m = loadingDialog;
                loadingDialog.show(fragmentActivity.getSupportFragmentManager(), "loadingDialog");
            }
            CreateAutomaticPaymentViewModel createAutomaticPaymentViewModel = fragmentActivity.c;
            createAutomaticPaymentViewModel.getClass();
            new QueryBillerConfigRepository().sendRequest(new g(createAutomaticPaymentViewModel, 0));
            return;
        }
        l.a(fragmentActivity);
        SelectBillerDialog selectBillerDialog = fragmentActivity.o;
        if (selectBillerDialog != null) {
            selectBillerDialog.dismiss();
        }
        SelectBillerDialog selectBillerDialog2 = new SelectBillerDialog(fragmentActivity.n, fragmentActivity.getString(R$string.select_biller), fragmentActivity.l, new s(fragmentActivity));
        fragmentActivity.o = selectBillerDialog2;
        selectBillerDialog2.show(fragmentActivity.getSupportFragmentManager(), "billerDialog");
    }
}
