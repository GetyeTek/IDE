package com.huawei.digitalpayment.schedule.adapter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.digitalpayment.schedule.resp.AutomaticPaymentResp;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;

public class AutomaticPaymentAdapter extends BaseQuickAdapter<AutomaticPaymentResp, BaseViewHolder> {
    public AutomaticPaymentAdapter() {
        super(R$layout.item_automatic_payment);
        addChildClickViewIds(new int[]{R$id.ivDelete});
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        AutomaticPaymentResp automaticPaymentResp = (AutomaticPaymentResp) obj;
        baseViewHolder.setText(R$id.tvAutomaticPaymentName, automaticPaymentResp.getScheduleName());
        baseViewHolder.setText(R$id.tvFrequency, automaticPaymentResp.getFrequencyDesc());
        baseViewHolder.getView(R$id.displayRecycler).setAdapter(new BaseQuickAdapter(R$layout.item_automatic_display, automaticPaymentResp.getDisplayItems()));
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return AutomaticPaymentAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
