package com.huawei.digitalpayment.schedule.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.schedule.repository.AutomaticBuyPackageSelectPageRepository;
import com.huawei.digitalpayment.schedule.resp.TopUpPageDataResp;
import com.huawei.digitalpayment.topup.bean.DataPackGroupsBean;
import com.huawei.digitalpayment.topup.bean.PackageTabsBean;
import java.util.List;

public class AutomaticBuyPackageSelectPageViewModel extends ViewModel {
    public final MutableLiveData<c<TopUpPageDataResp>> a = new MutableLiveData<>();
    public final MutableLiveData<List<PackageTabsBean>> b = new MutableLiveData<>();
    public final MutableLiveData<List<DataPackGroupsBean>> c = new MutableLiveData<>();
    public AutomaticBuyPackageSelectPageRepository d;

    public final void onCleared() {
        AutomaticBuyPackageSelectPageViewModel.super.onCleared();
        AutomaticBuyPackageSelectPageRepository automaticBuyPackageSelectPageRepository = this.d;
        if (automaticBuyPackageSelectPageRepository != null) {
            automaticBuyPackageSelectPageRepository.cancel();
        }
    }
}
