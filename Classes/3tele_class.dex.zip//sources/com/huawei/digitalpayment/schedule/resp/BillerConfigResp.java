package com.huawei.digitalpayment.schedule.resp;

import com.huawei.http.BaseResp;
import java.util.List;

public class BillerConfigResp extends BaseResp {
    private List<BillerItem> billerItems;

    public List<BillerItem> getBillerItems() {
        return this.billerItems;
    }

    public void setBillerItems(List<BillerItem> list) {
        this.billerItems = list;
    }
}
