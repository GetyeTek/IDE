package com.huawei.digitalpayment.schedule.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.blankj.utilcode.util.C;
import com.huawei.digitalpayment.schedule.dialog.ScheduleDatePickerDialog;
import java.util.Calendar;
import java.util.HashMap;
import o6.b;

public final /* synthetic */ class m implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;
    public final /* synthetic */ Object c;

    public /* synthetic */ m(int i, Object obj, Object obj2) {
        this.a = i;
        this.b = obj;
        this.c = obj2;
    }

    public final void onClick(View view) {
        Object obj = this.c;
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                int i = CreateAutomaticPaymentActivity.r;
                CreateAutomaticPaymentActivity createAutomaticPaymentActivity = (CreateAutomaticPaymentActivity) obj2;
                ScheduleDatePickerDialog scheduleDatePickerDialog = (ScheduleDatePickerDialog) obj;
                scheduleDatePickerDialog.dismiss();
                Calendar instance = Calendar.getInstance();
                instance.set(1, scheduleDatePickerDialog.g);
                instance.set(2, scheduleDatePickerDialog.h - 1);
                instance.set(5, scheduleDatePickerDialog.i);
                createAutomaticPaymentActivity.i = instance;
                createAutomaticPaymentActivity.b.i.getEditText().setText(C.a("dd-MM-yyyy", instance.getTime()));
                return;
            default:
                b bVar = (b) obj2;
                bVar.getClass();
                HashMap hashMap = new HashMap(1);
                hashMap.put("ConversationId", (String) obj);
                o0.b.d((Activity) null, "/chat/official_account", (Bundle) null, hashMap);
                bVar.i.v0();
                return;
        }
    }
}
