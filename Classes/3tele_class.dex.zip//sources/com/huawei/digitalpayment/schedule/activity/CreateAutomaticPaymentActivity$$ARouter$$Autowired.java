package com.huawei.digitalpayment.schedule.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class CreateAutomaticPaymentActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        this.serializationService = e.c(SerializationService.class);
        ? r42 = (CreateAutomaticPaymentActivity) obj;
        if (r42.getIntent().getExtras() == null) {
            str = r42.billerCode;
        } else {
            str = r42.getIntent().getExtras().getString("billerCode", r42.billerCode);
        }
        r42.billerCode = str;
        if (r42.getIntent().getExtras() == null) {
            str2 = r42.billerName;
        } else {
            str2 = r42.getIntent().getExtras().getString("billerName", r42.billerName);
        }
        r42.billerName = str2;
        if (r42.getIntent().getExtras() == null) {
            str3 = r42.referenceName;
        } else {
            str3 = r42.getIntent().getExtras().getString("referenceName", r42.referenceName);
        }
        r42.referenceName = str3;
        if (r42.getIntent().getExtras() == null) {
            str4 = r42.paymentType;
        } else {
            str4 = r42.getIntent().getExtras().getString("paymentType", r42.paymentType);
        }
        r42.paymentType = str4;
    }
}
