package com.huawei.digitalpayment.schedule.activity;

import V7.c;
import V7.f;
import android.app.Activity;
import android.os.Bundle;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.CouponBean;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.ethiopia.finance.R;
import com.huawei.ethiopia.finance.resp.SavingProductInfo;
import com.huawei.ethiopia.finance.resp.TransactionInfo;
import com.huawei.ethiopia.finance.saving.activity.SavingProductDetailActivity;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;
import com.huawei.module_checkout.checkstand.viewmodel.CheckStandViewModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import o0.b;

public final /* synthetic */ class g implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ g(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        double d;
        switch (this.a) {
            case 0:
                c cVar = (c) obj;
                int i = AutomaticPaymentActivity.g;
                FragmentActivity fragmentActivity = (AutomaticPaymentActivity) this.b;
                f.b(fragmentActivity, cVar);
                if (cVar.b()) {
                    f.c(cVar);
                    return;
                } else if (cVar.f()) {
                    Bundle bundle = new Bundle();
                    bundle.putString("title", fragmentActivity.getString(R$string.successful));
                    bundle.putString("content", fragmentActivity.getString(R$string.action_done_successfully));
                    b.d((Activity) null, "/cashModule/applyDepositVoucherSuccess", bundle, (Map) null);
                    fragmentActivity.finish();
                    return;
                } else {
                    return;
                }
            case 1:
                CheckoutResp checkoutResp = (CheckoutResp) obj;
                CheckStandFragment checkStandFragment = (CheckStandFragment) this.b;
                if (checkStandFragment.f) {
                    checkStandFragment.f = false;
                    CheckStandViewModel checkStandViewModel = checkStandFragment.a;
                    CouponBean couponBean = checkStandFragment.i;
                    if (couponBean != null) {
                        checkStandViewModel.l.setValue(couponBean);
                    } else {
                        checkStandViewModel.getClass();
                    }
                }
                checkStandFragment.k = true;
                checkStandFragment.F0(checkoutResp);
                checkStandFragment.k = false;
                return;
            default:
                SavingProductDetailActivity savingProductDetailActivity = (SavingProductDetailActivity) this.b;
                c cVar2 = (c) obj;
                int i2 = SavingProductDetailActivity.l;
                if (cVar2.d()) {
                    savingProductDetailActivity.j.a(1);
                    return;
                } else if (cVar2.b()) {
                    f.c(cVar2);
                    savingProductDetailActivity.j.a(3);
                    return;
                } else if (cVar2.f()) {
                    SavingProductInfo savingProductInfo = (SavingProductInfo) cVar2.c;
                    savingProductDetailActivity.h = savingProductInfo;
                    List<TransactionInfo> transactionList = savingProductInfo.getTransactionList();
                    ArrayList arrayList = new ArrayList();
                    if (transactionList != null && !transactionList.isEmpty()) {
                        for (TransactionInfo transactionInfo : transactionList) {
                            try {
                                d = Double.parseDouble(transactionInfo.getTransactionAmount().replaceAll(",", ""));
                            } catch (Exception unused) {
                                d = 0.0d;
                            }
                            if (d > 0.0d) {
                                arrayList.add(transactionInfo);
                            }
                        }
                    }
                    if (!arrayList.isEmpty()) {
                        synchronized (savingProductDetailActivity) {
                            if (savingProductDetailActivity.i == null) {
                                ViewDataBinding inflate = DataBindingUtil.inflate(savingProductDetailActivity.getLayoutInflater(), R.layout.finance_item_saving_product_transaction_title, savingProductDetailActivity.b.d, false);
                                savingProductDetailActivity.i = inflate;
                                savingProductDetailActivity.b.d.a(-1, inflate.getRoot());
                            }
                        }
                    }
                    savingProductDetailActivity.g.submitList(arrayList);
                    savingProductDetailActivity.E0(savingProductInfo);
                    if (savingProductDetailActivity.g.getItemCount() == 0) {
                        savingProductDetailActivity.j.a(4);
                        return;
                    } else {
                        savingProductDetailActivity.j.a(2);
                        return;
                    }
                } else {
                    return;
                }
        }
    }
}
