package com.huawei.digitalpayment.schedule.activity;

import I4.f;
import L3.a;
import V1.k;
import V7.c;
import W2.h;
import W2.n;
import android.content.Intent;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.C;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum;
import com.huawei.digitalpayment.schedule.dialog.SelectBillerDialog;
import com.huawei.digitalpayment.schedule.dialog.SelectPaymentFrequencyDialog;
import com.huawei.digitalpayment.schedule.resp.BillerItem;
import com.huawei.digitalpayment.schedule.resp.PaymentFrequencyInfo;
import com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.bean.DataPackItemBean;
import com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding;
import com.huawei.http.b;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

@Route(path = "/topUpModule/createAutomaticPayment")
public class CreateAutomaticPaymentActivity extends DataBindingActivity<ActivityCreateAutomaticPaymentBinding, CreateAutomaticPaymentViewModel> {
    public static final /* synthetic */ int r = 0;
    @Autowired
    String billerCode;
    @Autowired
    String billerName;
    public SelectPaymentFrequencyDialog d;
    public SelectPaymentFrequencyDialog e;
    public PaymentFrequencyInfo f;
    public PaymentFrequencyInfo g;
    public Calendar h;
    public Calendar i;
    public Calendar j;
    public CreateAutomaticEnum k;
    public List<BillerItem> l;
    public LoadingDialog m;
    public BillerItem n;
    public SelectBillerDialog o;
    public final String p = "ETPostpaidBill";
    @Autowired
    String paymentType;
    public DataPackItemBean q;
    @Autowired
    String referenceName;

    /* JADX WARNING: type inference failed for: r6v0, types: [android.content.Context, com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity] */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x00b9 A[SYNTHETIC, Splitter:B:19:0x00b9] */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x00db A[Catch:{ Exception -> 0x007d }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x011e A[Catch:{ Exception -> 0x007d }] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void E0(com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity r6, com.huawei.digitalpayment.schedule.resp.BillerItem r7) {
        /*
            r0 = 1
            r1 = 0
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r2 = r2.d     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r7.getBillerName()     // Catch:{ Exception -> 0x007d }
            r2.setText(r3)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.TextView r2 = r2.getTvTitle()     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r7.getReferenceName()     // Catch:{ Exception -> 0x007d }
            r2.setText(r3)     // Catch:{ Exception -> 0x007d }
            java.lang.String r2 = "om"
            com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils r3 = com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils.getInstance()     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r3.getCurrentLang()     // Catch:{ Exception -> 0x007d }
            boolean r2 = android.text.TextUtils.equals(r2, r3)     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = " "
            if (r2 != 0) goto L_0x0080
            java.lang.String r2 = "am"
            com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils r4 = com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils.getInstance()     // Catch:{ Exception -> 0x007d }
            java.lang.String r4 = r4.getCurrentLang()     // Catch:{ Exception -> 0x007d }
            boolean r2 = android.text.TextUtils.equals(r2, r4)     // Catch:{ Exception -> 0x007d }
            if (r2 != 0) goto L_0x0080
            java.lang.String r2 = "ti"
            com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils r4 = com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils.getInstance()     // Catch:{ Exception -> 0x007d }
            java.lang.String r4 = r4.getCurrentLang()     // Catch:{ Exception -> 0x007d }
            boolean r2 = android.text.TextUtils.equals(r2, r4)     // Catch:{ Exception -> 0x007d }
            if (r2 == 0) goto L_0x0053
            goto L_0x0080
        L_0x0053:
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r2 = r2.getEditText()     // Catch:{ Exception -> 0x007d }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x007d }
            r4.<init>()     // Catch:{ Exception -> 0x007d }
            int r5 = com.huawei.digitalpayment.topup.R$string.enter     // Catch:{ Exception -> 0x007d }
            java.lang.String r5 = r6.getString(r5)     // Catch:{ Exception -> 0x007d }
            r4.append(r5)     // Catch:{ Exception -> 0x007d }
            r4.append(r3)     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r7.getReferenceName()     // Catch:{ Exception -> 0x007d }
            r4.append(r3)     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r4.toString()     // Catch:{ Exception -> 0x007d }
            r2.setHint(r3)     // Catch:{ Exception -> 0x007d }
            goto L_0x00af
        L_0x007d:
            r6 = move-exception
            goto L_0x0171
        L_0x0080:
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r2 = r2.getEditText()     // Catch:{ Exception -> 0x007d }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x007d }
            r4.<init>()     // Catch:{ Exception -> 0x007d }
            java.lang.String r5 = r7.getReferenceName()     // Catch:{ Exception -> 0x007d }
            r4.append(r5)     // Catch:{ Exception -> 0x007d }
            r4.append(r3)     // Catch:{ Exception -> 0x007d }
            int r3 = com.huawei.digitalpayment.topup.R$string.enter     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r6.getString(r3)     // Catch:{ Exception -> 0x007d }
            java.util.Locale r5 = java.util.Locale.ENGLISH     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r3.toLowerCase(r5)     // Catch:{ Exception -> 0x007d }
            r4.append(r3)     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r4.toString()     // Catch:{ Exception -> 0x007d }
            r2.setHint(r3)     // Catch:{ Exception -> 0x007d }
        L_0x00af:
            com.huawei.digitalpayment.schedule.resp.BillerItem r2 = r6.n     // Catch:{ Exception -> 0x007d }
            boolean r2 = r7.equals(r2)     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = ""
            if (r2 != 0) goto L_0x00c6
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r2 = r2.getEditText()     // Catch:{ Exception -> 0x007d }
            r2.setText(r3)     // Catch:{ Exception -> 0x007d }
        L_0x00c6:
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            r2.setAreaCode(r3)     // Catch:{ Exception -> 0x007d }
            java.lang.String r2 = r6.p     // Catch:{ Exception -> 0x007d }
            java.lang.String r3 = r7.getBillerCode()     // Catch:{ Exception -> 0x007d }
            boolean r2 = r2.equals(r3)     // Catch:{ Exception -> 0x007d }
            if (r2 == 0) goto L_0x011e
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.ImageView r2 = r2.getIvIcon()     // Catch:{ Exception -> 0x007d }
            r2.setVisibility(r1)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r2 = r2.getEditText()     // Catch:{ Exception -> 0x007d }
            android.text.InputFilter$LengthFilter r3 = new android.text.InputFilter$LengthFilter     // Catch:{ Exception -> 0x007d }
            r4 = 18
            r3.<init>(r4)     // Catch:{ Exception -> 0x007d }
            android.text.InputFilter[] r0 = new android.text.InputFilter[r0]     // Catch:{ Exception -> 0x007d }
            r0[r1] = r3     // Catch:{ Exception -> 0x007d }
            r2.setFilters(r0)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r0 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r0 = r0.b     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r0 = r0.getEditText()     // Catch:{ Exception -> 0x007d }
            r2 = 2
            r0.setInputType(r2)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r0 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r0 = r0.b     // Catch:{ Exception -> 0x007d }
            I7.e r2 = new I7.e     // Catch:{ Exception -> 0x007d }
            r3 = 4
            r2.<init>(r6, r3)     // Catch:{ Exception -> 0x007d }
            r0.setOnIconListener(r2)     // Catch:{ Exception -> 0x007d }
            goto L_0x0153
        L_0x011e:
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.ImageView r2 = r2.getIvIcon()     // Catch:{ Exception -> 0x007d }
            r3 = 8
            r2.setVisibility(r3)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r2 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r2     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r2 = r2.b     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r2 = r2.getEditText()     // Catch:{ Exception -> 0x007d }
            r2.setInputType(r0)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r0 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r0 = r0.b     // Catch:{ Exception -> 0x007d }
            android.widget.EditText r0 = r0.getEditText()     // Catch:{ Exception -> 0x007d }
            android.text.InputFilter[] r2 = new android.text.InputFilter[r1]     // Catch:{ Exception -> 0x007d }
            r0.setFilters(r2)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r0 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r0 = r0.b     // Catch:{ Exception -> 0x007d }
            r2 = 0
            r0.setOnIconListener(r2)     // Catch:{ Exception -> 0x007d }
        L_0x0153:
            r6.n = r7     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r7 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7     // Catch:{ Exception -> 0x007d }
            android.view.View r7 = r7.c     // Catch:{ Exception -> 0x007d }
            r7.setVisibility(r1)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r7 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7     // Catch:{ Exception -> 0x007d }
            com.huawei.common.widget.input.CommonInputView r7 = r7.b     // Catch:{ Exception -> 0x007d }
            r7.setVisibility(r1)     // Catch:{ Exception -> 0x007d }
            androidx.databinding.ViewDataBinding r6 = r6.b     // Catch:{ Exception -> 0x007d }
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r6 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r6     // Catch:{ Exception -> 0x007d }
            android.widget.LinearLayout r6 = r6.f     // Catch:{ Exception -> 0x007d }
            r6.setVisibility(r1)     // Catch:{ Exception -> 0x007d }
            goto L_0x0177
        L_0x0171:
            r6.getMessage()
            V1.h.b()
        L_0x0177:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity.E0(com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity, com.huawei.digitalpayment.schedule.resp.BillerItem):void");
    }

    public static boolean F0(CommonInputView commonInputView) {
        if (!TextUtils.isEmpty(commonInputView.getText())) {
            return true;
        }
        k.b(1, commonInputView.getEditText().getHint());
        return false;
    }

    public final int C0() {
        return R$layout.activity_create_automatic_payment;
    }

    public final void onActivityResult(int i2, int i5, @Nullable Intent intent) {
        String str;
        CreateAutomaticPaymentActivity.super.onActivityResult(i2, i5, intent);
        if (intent != null && i2 == 1001 && i5 == -1) {
            String str2 = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            HashMap hashMap = new HashMap();
            hashMap.put("pinVersion", a.b.getPinKeyVersion());
            hashMap.put("initiatorPin", a.g(str2));
            hashMap.put("scheduleName", this.b.l.getText());
            hashMap.put("initiatorMsisdn", n.b("").e("recent_login_phone_number"));
            hashMap.put("amount", this.b.g.getText());
            hashMap.put("firstPaymentReminderDate", C.a("yyyyMMdd", this.h.getTime()));
            Calendar calendar = this.i;
            if (calendar != null) {
                hashMap.put("issuePaymentReminderUntil", C.a("yyyyMMdd", calendar.getTime()));
            } else {
                hashMap.put("issuePaymentReminderUntil", "20991231");
            }
            hashMap.put("frequency", this.f.getKey());
            if (!"2".equals(this.f.getKey())) {
                hashMap.put("preWarningPeriod", this.g.getKey());
            }
            if (!TextUtils.isEmpty(this.b.k.getText())) {
                hashMap.put("freeText", this.b.k.getText());
            }
            CreateAutomaticEnum createAutomaticEnum = this.k;
            if (createAutomaticEnum == CreateAutomaticEnum.SEND_MONEY) {
                hashMap.put("receiverMsisdn", "251" + h.c(this.b.j.getText()));
            } else {
                String str3 = "RechargedMSISDN";
                if (createAutomaticEnum == CreateAutomaticEnum.PAY_BILL) {
                    hashMap.put("billerCode", this.n.getBillerCode());
                    HashMap hashMap2 = new HashMap();
                    String billerCode2 = this.n.getBillerCode();
                    String str4 = this.p;
                    if (!str4.equals(billerCode2)) {
                        str3 = "BillReferenceNumber";
                    }
                    hashMap2.put("key", str3);
                    if (str4.equals(this.n.getBillerCode())) {
                        str = h.b(this.b.b.getText());
                    } else {
                        str = this.b.b.getText();
                    }
                    hashMap2.put("value", str);
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(hashMap2);
                    hashMap.put("extraParameter", arrayList);
                } else {
                    HashMap a = com.google.android.gms.ads.identifier.a.a("key", str3);
                    a.put("value", "251" + h.c(this.b.j.getText()));
                    ArrayList arrayList2 = new ArrayList();
                    arrayList2.add(a);
                    hashMap.put("extraParameter", arrayList2);
                    if (this.k == CreateAutomaticEnum.BUY_PACKAGE && this.q != null) {
                        HashMap a2 = com.google.android.gms.ads.identifier.a.a("key", "OfferingId");
                        a2.put("value", this.q.getOfferingId());
                        arrayList2.add(a2);
                        hashMap.put("receiverMsisdn", "251" + h.c(this.b.j.getText()));
                        hashMap.put("itemId", this.q.getItemId());
                    }
                }
            }
            hashMap.put("transactionType", this.k.getTransactionType());
            CreateAutomaticPaymentViewModel createAutomaticPaymentViewModel = this.c;
            createAutomaticPaymentViewModel.a.setValue(c.c());
            b bVar = new b();
            bVar.addParams(hashMap);
            bVar.sendRequest(new f(createAutomaticPaymentViewModel, 0));
        }
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.content.Context, com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity, androidx.lifecycle.LifecycleOwner, java.lang.Object, android.app.Activity, com.huawei.payment.mvvm.DataBindingActivity, android.view.View$OnCreateContextMenuListener, androidx.fragment.app.FragmentActivity] */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0076, code lost:
        if (android.text.TextUtils.equals(r3, r4.getTransactionType()) != false) goto L_0x005d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r7) {
        /*
            r6 = this;
            r0 = 4
            r1 = 1
            r2 = 0
            android.view.Window r3 = r6.getWindow()
            r4 = 16
            r3.setSoftInputMode(r4)
            com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity.super.onCreate(r7)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            android.view.View r7 = r7.getRoot()
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r7 = (android.view.ViewGroup.MarginLayoutParams) r7
            int r3 = com.blankj.utilcode.util.f.c()
            int r3 = -r3
            r7.topMargin = r3
            int r7 = com.huawei.digitalpayment.topup.R$color.color_F4F4F4
            int r7 = androidx.core.content.ContextCompat.getColor(r6, r7)
            com.blankj.utilcode.util.f.e(r6, r7, r2)
            int r7 = com.huawei.digitalpayment.topup.R$string.create_schedule_payment
            java.lang.String r7 = r6.getString(r7)
            int r3 = com.huawei.payment.mvvm.R.layout.common_toolbar
            V7.e.a(r6, r7, r3)
            android.content.Intent r7 = r6.getIntent()
            java.lang.String r3 = "createAutomaticEnum"
            java.io.Serializable r7 = r7.getSerializableExtra(r3)
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r7 = (com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum) r7
            if (r7 == 0) goto L_0x0047
            goto L_0x0079
        L_0x0047:
            android.content.Intent r3 = r6.getIntent()
            java.lang.String r4 = "transactionType"
            java.lang.String r3 = r3.getStringExtra(r4)
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r4 = com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum.PAY_BILL
            java.lang.String r5 = r4.getTransactionType()
            boolean r5 = android.text.TextUtils.equals(r3, r5)
            if (r5 == 0) goto L_0x005f
        L_0x005d:
            r7 = r4
            goto L_0x0079
        L_0x005f:
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r4 = com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum.SEND_MONEY
            java.lang.String r5 = r4.getTransactionType()
            boolean r5 = android.text.TextUtils.equals(r3, r5)
            if (r5 == 0) goto L_0x006c
            goto L_0x005d
        L_0x006c:
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r4 = com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum.BUY_AIRTIME
            java.lang.String r5 = r4.getTransactionType()
            boolean r3 = android.text.TextUtils.equals(r3, r5)
            if (r3 == 0) goto L_0x0079
            goto L_0x005d
        L_0x0079:
            r6.k = r7
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.l
            android.widget.EditText r7 = r7.getEditText()
            r3 = 33
            r7.setInputType(r3)
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r7 = com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum.PAY_BILL
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r3 = r6.k
            if (r7 == r3) goto L_0x00b6
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.j
            android.widget.EditText r3 = r3.getEditText()
            android.text.InputFilter$LengthFilter r4 = new android.text.InputFilter$LengthFilter
            r5 = 10
            r4.<init>(r5)
            android.text.InputFilter[] r5 = new android.text.InputFilter[r1]
            r5[r2] = r4
            r3.setFilters(r5)
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.j
            X6.b r4 = new X6.b
            r4.<init>(r6, r0)
            r3.setOnIconListener(r4)
        L_0x00b6:
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.g
            android.widget.EditText r3 = r3.getEditText()
            r4 = 8194(0x2002, float:1.1482E-41)
            r3.setInputType(r4)
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.g
            android.widget.EditText r3 = r3.getEditText()
            t4.a r4 = new t4.a
            r4.<init>()
            android.text.InputFilter[] r5 = new android.text.InputFilter[r1]
            r5[r2] = r4
            r3.setFilters(r5)
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.g
            int r4 = com.huawei.digitalpayment.topup.R$id.tv_unit
            android.view.View r3 = r3.findViewById(r4)
            android.widget.TextView r3 = (android.widget.TextView) r3
            k3.a r4 = k3.C0033a.e
            java.lang.String r4 = r4.b()
            r3.setText(r4)
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.o
            android.widget.EditText r3 = r3.getEditText()
            P7.g r4 = new P7.g
            r4.<init>(r6, r0)
            r3.setOnClickListener(r4)
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.i
            android.widget.EditText r3 = r3.getEditText()
            D1.o r4 = new D1.o
            r5 = 6
            r4.<init>(r6, r5)
            r3.setOnClickListener(r4)
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.m
            android.widget.EditText r3 = r3.getEditText()
            com.huawei.digitalpayment.schedule.activity.n r4 = new com.huawei.digitalpayment.schedule.activity.n
            r4.<init>(r6, r2)
            r3.setOnClickListener(r4)
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.n
            android.widget.EditText r3 = r3.getEditText()
            D1.q r4 = new D1.q
            r4.<init>(r6, r0)
            r3.setOnClickListener(r4)
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.k
            android.widget.EditText r0 = r0.getEditText()
            android.text.InputFilter$LengthFilter r3 = new android.text.InputFilter$LengthFilter
            r4 = 50
            r3.<init>(r4)
            android.text.InputFilter[] r4 = new android.text.InputFilter[r1]
            r4[r2] = r3
            r0.setFilters(r4)
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.k
            android.widget.EditText r0 = r0.getEditText()
            r3 = 131105(0x20021, float:1.83717E-40)
            r0.setInputType(r3)
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.k
            int r3 = com.huawei.digitalpayment.topup.R$id.tv_current_input_size
            android.view.View r0 = r0.findViewById(r3)
            android.widget.TextView r0 = (android.widget.TextView) r0
            androidx.databinding.ViewDataBinding r3 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r3
            com.huawei.common.widget.input.CommonInputView r3 = r3.k
            android.widget.EditText r3 = r3.getEditText()
            com.huawei.digitalpayment.schedule.activity.q r4 = new com.huawei.digitalpayment.schedule.activity.q
            r4.<init>(r0)
            r3.addTextChangedListener(r4)
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r0 = r6.k
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r3 = com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum.BUY_AIRTIME
            if (r0 != r3) goto L_0x01a7
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.j
            android.widget.TextView r0 = r0.getTvTitle()
            int r3 = com.huawei.digitalpayment.topup.R$string.mobile_number
            r0.setText(r3)
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.j
            android.widget.EditText r0 = r0.getEditText()
            int r3 = com.huawei.digitalpayment.topup.R$string.enter_mobile_number
            r0.setHint(r3)
        L_0x01a7:
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r0
            com.huawei.common.widget.LoadingButton r0 = r0.e
            D1.r r3 = new D1.r
            r4 = 3
            r3.<init>(r6, r4)
            r0.setOnClickListener(r3)
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r0 = r6.k
            r3 = 8
            if (r0 != r7) goto L_0x0259
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel r7 = (com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel) r7
            androidx.lifecycle.MutableLiveData<java.util.List<com.huawei.digitalpayment.schedule.resp.BillerItem>> r7 = r7.b
            com.huawei.digitalpayment.schedule.activity.o r0 = new com.huawei.digitalpayment.schedule.activity.o
            r0.<init>(r6)
            r7.observe(r6, r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.j
            r7.setVisibility(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            androidx.constraintlayout.widget.ConstraintLayout r7 = r7.a
            r7.setVisibility(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            android.view.View r7 = r7.c
            r7.setVisibility(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.b
            r7.setVisibility(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            android.widget.EditText r7 = r7.d
            r0 = 0
            r7.setMovementMethod(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            android.widget.EditText r7 = r7.d
            r7.setKeyListener(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            android.widget.EditText r7 = r7.getEditText()
            java.lang.String r0 = "1"
            r7.setText(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            r7.setVisibility(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            android.widget.LinearLayout r7 = r7.f
            r7.setVisibility(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            androidx.constraintlayout.widget.ConstraintLayout r7 = r7.p
            com.huawei.digitalpayment.schedule.activity.p r0 = new com.huawei.digitalpayment.schedule.activity.p
            r0.<init>(r6)
            r7.setOnClickListener(r0)
            com.huawei.common.widget.dialog.LoadingDialog r7 = r6.m
            if (r7 != 0) goto L_0x0244
            com.huawei.common.widget.dialog.LoadingDialog r7 = new com.huawei.common.widget.dialog.LoadingDialog
            r7.<init>()
            r6.m = r7
            androidx.fragment.app.FragmentManager r0 = r6.getSupportFragmentManager()
            java.lang.String r3 = "loadingDialog"
            r7.show(r0, r3)
        L_0x0244:
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel r7 = (com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel) r7
            r7.getClass()
            com.huawei.digitalpayment.schedule.repository.QueryBillerConfigRepository r0 = new com.huawei.digitalpayment.schedule.repository.QueryBillerConfigRepository
            r0.<init>()
            I4.g r3 = new I4.g
            r3.<init>(r7, r2)
            r0.sendRequest(r3)
            goto L_0x02b7
        L_0x0259:
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            androidx.constraintlayout.widget.ConstraintLayout r7 = r7.a
            r7.setVisibility(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            android.widget.LinearLayout r7 = r7.f
            r7.setVisibility(r2)
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r7 = r6.k
            com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum r0 = com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum.BUY_PACKAGE
            if (r7 != r0) goto L_0x02b7
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.h
            r7.setVisibility(r2)
            android.content.Intent r7 = r6.getIntent()
            java.lang.String r0 = "buyPackage"
            java.io.Serializable r7 = r7.getSerializableExtra(r0)
            com.huawei.digitalpayment.topup.bean.DataPackItemBean r7 = (com.huawei.digitalpayment.topup.bean.DataPackItemBean) r7
            r6.q = r7
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.h
            android.widget.EditText r7 = r7.getEditText()
            com.huawei.digitalpayment.topup.bean.DataPackItemBean r0 = r6.q
            java.lang.String r0 = r0.getItemDesc()
            r7.setText(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            android.widget.EditText r7 = r7.getEditText()
            r7.setInputType(r2)
            r7.setFocusable(r2)
            r7.setFocusableInTouchMode(r2)
            com.huawei.digitalpayment.topup.bean.DataPackItemBean r0 = r6.q
            java.lang.String r0 = r0.getFinalPrice()
            r7.setText(r0)
        L_0x02b7:
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel r7 = (com.huawei.digitalpayment.schedule.viewmodel.CreateAutomaticPaymentViewModel) r7
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.http.BaseResp>> r7 = r7.a
            N4.e r0 = new N4.e
            r0.<init>(r6, r1)
            r7.observe(r6, r0)
            java.util.Calendar r7 = java.util.Calendar.getInstance()
            r0 = 5
            r7.add(r0, r1)
            r6.j = r7
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentActivity.onCreate(android.os.Bundle):void");
    }
}
