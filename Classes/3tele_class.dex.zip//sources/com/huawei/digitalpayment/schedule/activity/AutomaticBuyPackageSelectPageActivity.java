package com.huawei.digitalpayment.schedule.activity;

import P6.a;
import P6.b;
import S3.i;
import V1.h;
import V7.c;
import V7.e;
import android.os.Bundle;
import android.widget.RadioButton;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum;
import com.huawei.digitalpayment.schedule.repository.AutomaticBuyPackageSelectPageRepository;
import com.huawei.digitalpayment.schedule.viewmodel.AutomaticBuyPackageSelectPageViewModel;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.adapter.BuyPackageGroupAdapter;
import com.huawei.digitalpayment.topup.bean.DataPackGroupsBean;
import com.huawei.digitalpayment.topup.bean.DataPackItemBean;
import com.huawei.digitalpayment.topup.bean.PackageTabsBean;
import com.huawei.digitalpayment.topup.bean.TopUpBean;
import com.huawei.digitalpayment.topup.databinding.ActivityAutomaticSelectPageBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Route(path = "/topUpModule/automaticBuyPackageSelectPage")
public class AutomaticBuyPackageSelectPageActivity extends DataBindingActivity<ActivityAutomaticSelectPageBinding, AutomaticBuyPackageSelectPageViewModel> {
    public static final /* synthetic */ int l = 0;
    public final ArrayList d = new ArrayList();
    public final ArrayList e = new ArrayList();
    public List<TopUpBean.OperatorsBean> f;
    public TopUpBean g;
    public TopUpBean.OperatorsBean h;
    public BuyPackageGroupAdapter i;
    public CreateAutomaticEnum j;
    public DataPackItemBean k;

    public final int C0() {
        return R$layout.activity_automatic_select_page;
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [java.lang.Object, java.util.Comparator] */
    public final void E0() {
        PackageTabsBean packageTabsBean;
        RadioButton radioButton = (RadioButton) findViewById(this.b.d.getCheckedRadioButtonId());
        if (radioButton != null && (packageTabsBean = (PackageTabsBean) radioButton.getTag()) != null) {
            AutomaticBuyPackageSelectPageViewModel automaticBuyPackageSelectPageViewModel = this.c;
            List<DataPackGroupsBean> packageGroups = packageTabsBean.getPackageGroups();
            automaticBuyPackageSelectPageViewModel.getClass();
            try {
                Collections.sort(packageGroups, new Object());
            } catch (Exception e2) {
                e2.getMessage();
                h.b();
            }
            automaticBuyPackageSelectPageViewModel.c.setValue(packageGroups);
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.digitalpayment.schedule.activity.AutomaticBuyPackageSelectPageActivity, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        AutomaticBuyPackageSelectPageActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.color_f8f8f8), false);
        e.a(this, getString(R$string.select_package), R.layout.common_toolbar);
        this.j = (CreateAutomaticEnum) getIntent().getSerializableExtra("createAutomaticEnum");
        AutomaticBuyPackageSelectPageViewModel automaticBuyPackageSelectPageViewModel = this.c;
        automaticBuyPackageSelectPageViewModel.a.setValue(c.c());
        if (automaticBuyPackageSelectPageViewModel.d == null) {
            automaticBuyPackageSelectPageViewModel.d = new AutomaticBuyPackageSelectPageRepository();
        }
        automaticBuyPackageSelectPageViewModel.d.sendRequest(new I4.c(automaticBuyPackageSelectPageViewModel, 0));
        this.c.a.observe(this, new a(this, 0));
        this.c.b.observe(this, new b(this, 0));
        this.c.c.observe(this, new c(this, 0));
        this.b.c.setOnClickListener(new i(this, 2));
        this.b.f.setOnClickListener(new a(this, 2));
        this.b.a.addTextChangedListener(new e(this, 0));
        this.b.b.setOnClickListener(new b(this, 3));
    }
}
