package com.huawei.digitalpayment.schedule.activity;

import I4.g;
import N0.H;
import O4.d;
import O4.e;
import T6.a;
import V7.c;
import V7.f;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import androidx.lifecycle.Observer;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.k;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.topup.bean.PackageTabsBean;
import com.huawei.digitalpayment.topup.bean.TabIconBean;
import com.huawei.ethiopia.finance.repayment.activity.FinanceRepaymentActivity;
import com.huawei.ethiopia.finance.repayment.resp.ContractResp;
import com.huawei.ethiopia.finance.resp.ActiveState;
import com.huawei.ethiopia.finance.saving.activity.SavingFragment;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingAccountRepository;
import com.huawei.ethiopia.finance.saving.viewmodel.SavingViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import f4.C0021b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final /* synthetic */ class b implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ b(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        ContractResp contractResp;
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                List list = (List) obj;
                DataBindingActivity dataBindingActivity = (AutomaticBuyPackageSelectPageActivity) obj2;
                if (list == null) {
                    int i = AutomaticBuyPackageSelectPageActivity.l;
                    return;
                }
                ArrayList arrayList = dataBindingActivity.d;
                arrayList.clear();
                arrayList.addAll(list);
                if (arrayList != null && arrayList.size() > 0) {
                    dataBindingActivity.b.d.removeAllViews();
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        PackageTabsBean packageTabsBean = (PackageTabsBean) it.next();
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                        layoutParams.rightMargin = 42;
                        RadioButton radioButton = new RadioButton(dataBindingActivity);
                        try {
                            TabIconBean tabIconBean = (TabIconBean) k.a(packageTabsBean.getTabIcon(), TabIconBean.class);
                            e.c(dataBindingActivity, radioButton, tabIconBean, false);
                            radioButton.setOnCheckedChangeListener(new d(dataBindingActivity, radioButton, tabIconBean));
                        } catch (Exception unused) {
                        }
                        radioButton.setButtonDrawable((Drawable) null);
                        radioButton.setId(View.generateViewId());
                        radioButton.setEnabled(true);
                        radioButton.setSingleLine();
                        radioButton.setEllipsize(TextUtils.TruncateAt.END);
                        radioButton.setText(packageTabsBean.getTabName());
                        radioButton.setCompoundDrawablePadding(6);
                        radioButton.setPadding(36, 18, 36, 18);
                        radioButton.setLayoutParams(layoutParams);
                        radioButton.setTag(packageTabsBean);
                        dataBindingActivity.b.d.addView(radioButton);
                    }
                    if (dataBindingActivity.b.d.getChildCount() > 0) {
                        dataBindingActivity.b.d.check(dataBindingActivity.b.d.getChildAt(0).getId());
                    }
                }
                dataBindingActivity.b.d.setOnCheckedChangeListener(new d(dataBindingActivity));
                return;
            case 1:
                Boolean bool = (Boolean) obj;
                C0021b bVar = (C0021b) obj2;
                int i2 = bVar.f;
                BaseMvpActivity baseMvpActivity = bVar.a;
                if (i2 == -1 || !bool.booleanValue()) {
                    DialogManager.b(baseMvpActivity.getSupportFragmentManager());
                    return;
                } else {
                    DialogManager.d(baseMvpActivity.getSupportFragmentManager(), true);
                    return;
                }
            case 2:
                c cVar = (c) obj;
                int i5 = FinanceRepaymentActivity.e;
                FinanceRepaymentActivity financeRepaymentActivity = (FinanceRepaymentActivity) obj2;
                f.b(financeRepaymentActivity, cVar);
                if (!cVar.d()) {
                    if (cVar.b()) {
                        f.c(cVar);
                        return;
                    } else if (cVar.f() && (contractResp = (ContractResp) cVar.c) != null) {
                        long currentTimeMillis = System.currentTimeMillis();
                        long j = a.a;
                        long j2 = currentTimeMillis - j;
                        if (j <= 0 || j2 >= 1000) {
                            a.a = currentTimeMillis;
                            c6.b bVar2 = new c6.b(financeRepaymentActivity, contractResp);
                            BaseDialog baseDialog = new BaseDialog();
                            baseDialog.c = contractResp;
                            baseDialog.d = bVar2;
                            baseDialog.show(financeRepaymentActivity.getSupportFragmentManager(), "");
                            return;
                        }
                        return;
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            default:
                c cVar2 = (c) obj;
                SavingFragment savingFragment = (SavingFragment) obj2;
                if (cVar2.d()) {
                    savingFragment.g.a(1);
                    return;
                } else if (cVar2.b()) {
                    savingFragment.g.a(3);
                    return;
                } else if (cVar2.f()) {
                    ActiveState activeState = (ActiveState) cVar2.c;
                    savingFragment.i = activeState.isActive();
                    boolean depositIsActive = activeState.depositIsActive();
                    activeState.recurringIsActive();
                    if (!savingFragment.i || !depositIsActive) {
                        DialogManager.b(savingFragment.getChildFragmentManager());
                        savingFragment.b.e.setVisibility(8);
                        savingFragment.b.a.setVisibility(8);
                        savingFragment.b.c.getRoot().setVisibility(0);
                        savingFragment.g.a(2);
                        return;
                    }
                    savingFragment.b.e.setVisibility(0);
                    savingFragment.b.a.setVisibility(0);
                    savingFragment.b.c.getRoot().setVisibility(8);
                    SavingViewModel savingViewModel = savingFragment.c;
                    String str = savingFragment.e;
                    savingViewModel.b.setValue(c.c());
                    QuerySavingAccountRepository querySavingAccountRepository = new QuerySavingAccountRepository(str, false, true);
                    savingViewModel.e = querySavingAccountRepository;
                    querySavingAccountRepository.sendRequest(new g(savingViewModel, 5));
                    A.h(new H(savingFragment, 4), 500);
                    return;
                } else {
                    return;
                }
        }
    }
}
