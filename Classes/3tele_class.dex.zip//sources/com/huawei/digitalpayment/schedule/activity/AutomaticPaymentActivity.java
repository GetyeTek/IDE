package com.huawei.digitalpayment.schedule.activity;

import A8.C;
import I4.d;
import I4.e;
import V7.c;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.digitalpayment.schedule.adapter.AutomaticPaymentAdapter;
import com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum;
import com.huawei.digitalpayment.schedule.repository.CancelAutomaticPaymentRepository;
import com.huawei.digitalpayment.schedule.repository.QueryScheduleRepository;
import com.huawei.digitalpayment.schedule.resp.AutomaticPaymentResp;
import com.huawei.digitalpayment.schedule.viewmodel.AutomaticPaymentViewModel;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$mipmap;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityAutomaticPaymentBinding;
import com.huawei.digitalpayment.topup.databinding.CreateAutomaticHeaderLayoutBinding;
import com.huawei.module_checkout.databinding.ItemDepositCashBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import o0.b;
import w5.a;

@Route(path = "/topUpModule/ScheduledPayment")
public class AutomaticPaymentActivity extends DataBindingActivity<ActivityAutomaticPaymentBinding, AutomaticPaymentViewModel> {
    public static final /* synthetic */ int g = 0;
    public AutomaticPaymentAdapter d;
    public AutomaticPaymentResp e;
    public boolean f = true;

    public static void E0(CreateAutomaticEnum createAutomaticEnum) {
        a.a(createAutomaticEnum.getSendReportTag());
        Bundle bundle = new Bundle(1);
        bundle.putSerializable("createAutomaticEnum", createAutomaticEnum);
        if (createAutomaticEnum == CreateAutomaticEnum.BUY_PACKAGE) {
            b.d((Activity) null, "/topUpModule/automaticBuyPackageSelectPage", bundle, (Map) null);
        } else {
            b.d((Activity) null, "/topUpModule/createAutomaticPayment", bundle, (Map) null);
        }
    }

    public final int C0() {
        return R$layout.activity_automatic_payment;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        AutomaticPaymentActivity.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 100000 && i2 == -1) {
            byte[] byteArrayExtra = intent.getByteArrayExtra("pin");
            AutomaticPaymentViewModel automaticPaymentViewModel = this.c;
            String str = new String(byteArrayExtra, StandardCharsets.UTF_8);
            AutomaticPaymentResp automaticPaymentResp = this.e;
            automaticPaymentViewModel.b.setValue(c.c());
            new CancelAutomaticPaymentRepository(str, automaticPaymentResp).sendRequest(new e(automaticPaymentViewModel, 0));
        }
    }

    /* JADX WARNING: type inference failed for: r2v5, types: [android.view.View$OnClickListener, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v9, types: [android.view.View$OnClickListener, java.lang.Object] */
    public final void onCreate(@Nullable Bundle bundle) {
        AutomaticPaymentActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.color_F4F4F4), false);
        V7.e.a(this, getString(R$string.schedule_payment), R.layout.common_toolbar);
        this.b.a.setLayoutManager(new LinearLayoutManager(this));
        AutomaticPaymentAdapter automaticPaymentAdapter = new AutomaticPaymentAdapter();
        this.d = automaticPaymentAdapter;
        automaticPaymentAdapter.setOnItemChildClickListener(new androidx.camera.view.e(this));
        this.b.a.setAdapter(this.d);
        CreateAutomaticHeaderLayoutBinding inflate = DataBindingUtil.inflate(getLayoutInflater(), R$layout.create_automatic_header_layout, this.b.a, false);
        inflate.d.c.setVisibility(8);
        ItemDepositCashBinding itemDepositCashBinding = inflate.d;
        itemDepositCashBinding.b.setImageResource(R$mipmap.home_v5_icon_send_money);
        itemDepositCashBinding.d.setText(R$string.designstandard_send_money);
        itemDepositCashBinding.a.setOnClickListener(new Object());
        ItemDepositCashBinding itemDepositCashBinding2 = inflate.a;
        itemDepositCashBinding2.c.setVisibility(8);
        itemDepositCashBinding2.b.setImageResource(R$mipmap.topup_icon_buy_airtime);
        itemDepositCashBinding2.d.setText(R$string.buy_airtime);
        itemDepositCashBinding2.a.setOnClickListener(new Object());
        ItemDepositCashBinding itemDepositCashBinding3 = inflate.c;
        itemDepositCashBinding3.c.setVisibility(8);
        itemDepositCashBinding3.b.setImageResource(R$mipmap.topup_icon_paybill);
        itemDepositCashBinding3.d.setText(R$string.pay_bill);
        itemDepositCashBinding3.a.setOnClickListener(new j(this));
        ItemDepositCashBinding itemDepositCashBinding4 = inflate.b;
        itemDepositCashBinding4.c.setVisibility(8);
        itemDepositCashBinding4.b.setImageResource(R$mipmap.topup_icon_buy_package);
        itemDepositCashBinding4.d.setText(R$string.buy_package);
        k kVar = new k(this);
        RoundConstraintLayout roundConstraintLayout = itemDepositCashBinding4.a;
        roundConstraintLayout.setOnClickListener(kVar);
        roundConstraintLayout.setVisibility(8);
        this.b.a.a(-1, inflate.getRoot());
        this.c.a.observe(this, new f(this, 0));
        this.c.b.observe(this, new g(this, 0));
    }

    public final void onResume() {
        AutomaticPaymentActivity.super.onResume();
        if (this.f) {
            AutomaticPaymentViewModel automaticPaymentViewModel = this.c;
            automaticPaymentViewModel.a.setValue(c.c());
            QueryScheduleRepository queryScheduleRepository = new QueryScheduleRepository();
            automaticPaymentViewModel.c = queryScheduleRepository;
            queryScheduleRepository.sendRequest(new d(automaticPaymentViewModel, 0));
            this.f = false;
            return;
        }
        AutomaticPaymentViewModel automaticPaymentViewModel2 = this.c;
        QueryScheduleRepository queryScheduleRepository2 = automaticPaymentViewModel2.c;
        if (queryScheduleRepository2 != null) {
            queryScheduleRepository2.cancel();
        }
        QueryScheduleRepository queryScheduleRepository3 = new QueryScheduleRepository();
        automaticPaymentViewModel2.c = queryScheduleRepository3;
        queryScheduleRepository3.sendRequest(new C(automaticPaymentViewModel2, 1));
    }
}
