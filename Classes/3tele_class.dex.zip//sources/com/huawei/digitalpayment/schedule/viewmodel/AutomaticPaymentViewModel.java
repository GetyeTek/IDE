package com.huawei.digitalpayment.schedule.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.schedule.repository.QueryScheduleRepository;
import com.huawei.digitalpayment.schedule.resp.AutomaticPaymentListResp;
import com.huawei.http.BaseResp;

public class AutomaticPaymentViewModel extends ViewModel {
    public final MutableLiveData<c<AutomaticPaymentListResp>> a = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> b = new MutableLiveData<>();
    public QueryScheduleRepository c;
}
