package com.huawei.digitalpayment.schedule.dialog;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;
import com.huawei.digitalpayment.schedule.activity.s;
import com.huawei.digitalpayment.schedule.resp.BillerItem;
import com.huawei.digitalpayment.topup.R$id;
import java.util.List;

public class SelectBillerDialog extends SelectDialog<BillerItem> {
    public final BillerItem g;

    public SelectBillerDialog(BillerItem billerItem, String str, List list, s sVar) {
        super(str, list, sVar);
        this.g = billerItem;
    }

    public final void x0(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        BillerItem billerItem = (BillerItem) obj;
        super.x0(baseViewHolder, billerItem);
        baseViewHolder.setText(R$id.tv_content, billerItem.getBillerName());
    }

    public final boolean z0(Object obj) {
        BillerItem billerItem = (BillerItem) obj;
        BillerItem billerItem2 = this.g;
        if (billerItem2 == null) {
            return false;
        }
        return TextUtils.equals(billerItem.getBillerCode(), billerItem2.getBillerCode());
    }
}
