package com.huawei.digitalpayment.schedule.activity;

import V7.c;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.schedule.resp.AutomaticPaymentListResp;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;
import com.huawei.module_checkout.confirm.OdConfirmDisplay;

public final /* synthetic */ class f implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ f(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                c cVar = (c) obj;
                int i = AutomaticPaymentActivity.g;
                AutomaticPaymentActivity automaticPaymentActivity = (AutomaticPaymentActivity) obj2;
                automaticPaymentActivity.getClass();
                V7.f.b(automaticPaymentActivity, cVar);
                if (cVar.b()) {
                    V7.f.c(cVar);
                    return;
                } else if (cVar.f()) {
                    automaticPaymentActivity.d.setNewData(((AutomaticPaymentListResp) cVar.c).getReminderScheduleInfoDetails());
                    return;
                } else {
                    return;
                }
            default:
                OdConfirmDisplay odConfirmDisplay = (OdConfirmDisplay) obj;
                CheckStandFragment checkStandFragment = (CheckStandFragment) obj2;
                if (checkStandFragment.e) {
                    checkStandFragment.e = false;
                    odConfirmDisplay.setButtonText(checkStandFragment.a.h);
                    checkStandFragment.A0(odConfirmDisplay);
                    return;
                }
                return;
        }
    }
}
