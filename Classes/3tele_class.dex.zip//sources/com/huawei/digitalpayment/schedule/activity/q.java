package com.huawei.digitalpayment.schedule.activity;

import O2.a;
import android.text.Editable;
import android.widget.TextView;

public final class q extends a {
    public final /* synthetic */ TextView b;

    public q(TextView textView) {
        super(1);
        this.b = textView;
    }

    public final void afterTextChanged(Editable editable) {
        this.b.setText(editable.length() + "/50");
    }
}
