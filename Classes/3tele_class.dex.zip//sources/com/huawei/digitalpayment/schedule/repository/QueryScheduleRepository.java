package com.huawei.digitalpayment.schedule.repository;

import W2.n;
import com.huawei.digitalpayment.schedule.resp.AutomaticPaymentListResp;
import com.huawei.http.b;

public class QueryScheduleRepository extends b<AutomaticPaymentListResp, AutomaticPaymentListResp> {
    public QueryScheduleRepository() {
        addParams("initiatorMsisdn", n.b("").e("recent_login_phone_number"));
    }

    public final String getApiKey() {
        return n.b("").e("recent_login_phone_number") + "_v1/ethiopia/querySchedule";
    }

    public final String getApiPath() {
        return "v1/ethiopia/querySchedule";
    }

    public final boolean isCache() {
        return true;
    }
}
