package com.huawei.digitalpayment.schedule.activity;

import R1.a;
import V1.k;
import W2.h;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.utils.exception.PhoneNumberException;
import com.huawei.digitalpayment.topup.R$string;

public final class r implements a<String> {
    public final /* synthetic */ CreateAutomaticPaymentActivity a;

    public r(CreateAutomaticPaymentActivity createAutomaticPaymentActivity) {
        this.a = createAutomaticPaymentActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        String str = (String) obj;
        CreateAutomaticPaymentActivity createAutomaticPaymentActivity = this.a;
        try {
            String a2 = h.a(str, (Integer) null);
            int i = CreateAutomaticPaymentActivity.r;
            createAutomaticPaymentActivity.b.j.getEditText().setText(a2);
            createAutomaticPaymentActivity.b.j.getEditText().setSelection(createAutomaticPaymentActivity.b.j.getEditText().getText().length());
        } catch (PhoneNumberException unused) {
            k.a(R$string.checkout_invalid_phone_number_please_check);
        }
    }
}
