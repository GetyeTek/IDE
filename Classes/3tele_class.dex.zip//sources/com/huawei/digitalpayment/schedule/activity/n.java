package com.huawei.digitalpayment.schedule.activity;

import D1.q;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import androidx.camera.video.internal.audio.d;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.l;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.digitalpayment.schedule.dialog.SelectPaymentFrequencyDialog;
import com.huawei.digitalpayment.schedule.resp.PaymentFrequencyInfo;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.ethiopia.finance.od.activity.FinanceAgreementActivity;
import com.huawei.kbz.chat.chat_room.ChatActivity;
import com.huawei.kbz.chat.contact.SelectContactActivity;
import com.huawei.module_checkout.checkstand.activity.CheckStandActivity;
import com.huawei.module_checkout.checkstand.fragment.CheckStandFragment;
import com.huawei.requestmoney.BlackOrFavorListActivity;
import com.huawei.requestmoney.R;
import f2.c;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import o0.b;
import p5.g;
import w5.a;

public final /* synthetic */ class n implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ n(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onClick(View view) {
        String str;
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = CreateAutomaticPaymentActivity.r;
                FragmentActivity fragmentActivity = (CreateAutomaticPaymentActivity) obj;
                l.a(fragmentActivity);
                ArrayList arrayList = new ArrayList();
                arrayList.add(new PaymentFrequencyInfo("2", fragmentActivity.getString(R$string.daily)));
                arrayList.add(new PaymentFrequencyInfo("3", fragmentActivity.getString(R$string.weekly)));
                arrayList.add(new PaymentFrequencyInfo(PaymentFrequencyInfo.MONTHLY, fragmentActivity.getString(R$string.monthly)));
                SelectPaymentFrequencyDialog selectPaymentFrequencyDialog = fragmentActivity.d;
                if (selectPaymentFrequencyDialog != null) {
                    selectPaymentFrequencyDialog.dismiss();
                }
                SelectPaymentFrequencyDialog selectPaymentFrequencyDialog2 = new SelectPaymentFrequencyDialog(fragmentActivity.f, fragmentActivity.getString(R$string.select_payment_frequency), arrayList, new d(fragmentActivity));
                fragmentActivity.d = selectPaymentFrequencyDialog2;
                selectPaymentFrequencyDialog2.show(fragmentActivity.getSupportFragmentManager(), "");
                return;
            case 1:
                int i2 = ChatActivity.f;
                ((ChatActivity) obj).finish();
                return;
            case 2:
                int i5 = SelectContactActivity.n;
                ((SelectContactActivity) obj).finish();
                return;
            case 3:
                BlackOrFavorListActivity blackOrFavorListActivity = (BlackOrFavorListActivity) obj;
                if (!blackOrFavorListActivity.f) {
                    String string = blackOrFavorListActivity.getString(R.string.block_all_users_tips);
                    String string2 = blackOrFavorListActivity.getString(R.string.no);
                    String string3 = blackOrFavorListActivity.getString(R.string.yes);
                    q qVar = new q(blackOrFavorListActivity, 7);
                    BaseDialog baseDialog = new BaseDialog();
                    baseDialog.g = null;
                    baseDialog.h = string;
                    baseDialog.i = string2;
                    baseDialog.j = string3;
                    baseDialog.k = null;
                    baseDialog.l = qVar;
                    baseDialog.show(blackOrFavorListActivity.getSupportFragmentManager(), "");
                    return;
                }
                HashMap hashMap = new HashMap();
                hashMap.put("relateType", blackOrFavorListActivity.d);
                hashMap.put("blockAll", Boolean.FALSE);
                blackOrFavorListActivity.c.f(hashMap);
                return;
            case 4:
                int i6 = FinanceAgreementActivity.g;
                FinanceAgreementActivity financeAgreementActivity = (FinanceAgreementActivity) obj;
                ReportViewModel reportViewModel = c.b;
                c cVar = c.a.a;
                String str2 = financeAgreementActivity.f;
                String str3 = financeAgreementActivity.d;
                if (TextUtils.isEmpty(str2)) {
                    str = "form checkout";
                } else {
                    str = "self registration";
                }
                cVar.c("Finance_Confirm_activation_T-C", new String[]{str2, str3, str});
                if ("finance_saving".equals(financeAgreementActivity.d)) {
                    Bundle bundle = new Bundle();
                    bundle.putString("bankCode", financeAgreementActivity.f);
                    bundle.putString("fundsLenderId", financeAgreementActivity.e);
                    b.d((Activity) null, "/finance/activeSaving", bundle, (Map) null);
                    financeAgreementActivity.finish();
                    return;
                }
                if (!"finance_saving".equals(financeAgreementActivity.d) && "finance_overdraft".equals(financeAgreementActivity.d)) {
                    String c = g.c(financeAgreementActivity.f);
                    a.a("OD_" + c + "_agreement_v1");
                }
                b.e(financeAgreementActivity, "/loginModule/openBiometricIdentifyPin", (Bundle) null, (Map) null, 0, 100);
                return;
            case 5:
                CheckStandActivity checkStandActivity = ((j7.d) obj).b;
                checkStandActivity.F0((TransferResp) checkStandActivity.b.p.getValue());
                return;
            case 6:
                ((CheckStandFragment) obj).b.onBackPressed();
                return;
            default:
                o6.b bVar = (o6.b) obj;
                bVar.f.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(bVar.b)));
                bVar.i.v0();
                return;
        }
    }
}
