package com.huawei.digitalpayment.schedule.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.schedule.resp.BillerItem;
import com.huawei.http.BaseResp;
import java.util.List;

public class CreateAutomaticPaymentViewModel extends ViewModel {
    public final MutableLiveData<c<BaseResp>> a = new MutableLiveData<>();
    public final MutableLiveData<List<BillerItem>> b = new MutableLiveData<>();
}
