package com.huawei.digitalpayment.schedule.resp;

import com.huawei.digitalpayment.topup.bean.TopUpBean;
import com.huawei.http.BaseResp;

public class TopUpPageDataResp extends BaseResp {
    private TopUpBean topUpPageData;

    public TopUpBean getTopUpPageData() {
        return this.topUpPageData;
    }

    public void setTopUpPageData(TopUpBean topUpBean) {
        this.topUpPageData = topUpBean;
    }
}
