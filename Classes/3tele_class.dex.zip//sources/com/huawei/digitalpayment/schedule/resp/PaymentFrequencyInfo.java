package com.huawei.digitalpayment.schedule.resp;

import java.io.Serializable;

public class PaymentFrequencyInfo implements Serializable {
    public static final String DAILY = "2";
    public static final String MONTHLY = "5";
    public static final String WEEKLY = "3";
    private String key;
    private String value;

    public PaymentFrequencyInfo(String str, String str2) {
        this.key = str;
        this.value = str2;
    }

    public String getKey() {
        return this.key;
    }

    public String getValue() {
        return this.value;
    }

    public void setKey(String str) {
        this.key = str;
    }

    public void setValue(String str) {
        this.value = str;
    }
}
