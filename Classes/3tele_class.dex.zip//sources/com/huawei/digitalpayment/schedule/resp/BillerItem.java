package com.huawei.digitalpayment.schedule.resp;

import java.io.Serializable;

public class BillerItem implements Serializable {
    private String billerCode;
    private String billerName;
    private String referenceName;

    public String getBillerCode() {
        return this.billerCode;
    }

    public String getBillerName() {
        return this.billerName;
    }

    public String getReferenceName() {
        return this.referenceName;
    }

    public void setBillerCode(String str) {
        this.billerCode = str;
    }

    public void setBillerName(String str) {
        this.billerName = str;
    }

    public void setReferenceName(String str) {
        this.referenceName = str;
    }
}
