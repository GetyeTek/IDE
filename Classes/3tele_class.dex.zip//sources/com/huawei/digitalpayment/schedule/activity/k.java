package com.huawei.digitalpayment.schedule.activity;

import C3.g;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum;
import f2.c;
import java.util.Map;
import o0.b;

public final /* synthetic */ class k implements View.OnClickListener {
    public final /* synthetic */ int a;

    public /* synthetic */ k(int i) {
        this.a = i;
    }

    public final void onClick(View view) {
        switch (this.a) {
            case 0:
                int i = AutomaticPaymentActivity.g;
                AutomaticPaymentActivity.E0(CreateAutomaticEnum.BUY_PACKAGE);
                return;
            case 1:
                b.d((Activity) null, "/loginModule/upgradeLevel", (Bundle) null, (Map) null);
                return;
            default:
                String[] strArr = new String[0];
                if (!g.d()) {
                    ReportViewModel reportViewModel = c.b;
                    c.a.a.c("click_Lv1HomePg_search", strArr);
                }
                b.d((Activity) null, "/mainModule/search?reportTag=Homepage_Search_Enter_V1", (Bundle) null, (Map) null);
                return;
        }
    }

    public /* synthetic */ k(AutomaticPaymentActivity automaticPaymentActivity) {
        this.a = 0;
    }
}
