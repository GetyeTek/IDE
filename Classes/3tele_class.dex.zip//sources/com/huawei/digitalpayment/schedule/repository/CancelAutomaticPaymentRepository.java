package com.huawei.digitalpayment.schedule.repository;

import L3.a;
import W2.n;
import com.huawei.digitalpayment.schedule.resp.AutomaticPaymentListResp;
import com.huawei.digitalpayment.schedule.resp.AutomaticPaymentResp;
import com.huawei.http.BaseResp;
import com.huawei.http.b;

public class CancelAutomaticPaymentRepository extends b<BaseResp, BaseResp> {
    public final AutomaticPaymentResp a;

    public CancelAutomaticPaymentRepository(String str, AutomaticPaymentResp automaticPaymentResp) {
        this.a = automaticPaymentResp;
        addParams("reminderScheduleId", automaticPaymentResp.getReminderScheduleId());
        addParams("initiatorMsisdn", n.b("").e("recent_login_phone_number"));
        addParams("initiatorPin", a.g(str));
        addParams("pinVersion", a.b.getPinKeyVersion());
    }

    public final String getApiPath() {
        return "v1/ethiopia/cancelSchedule";
    }

    public final void saveToLocal(Object obj) {
        AutomaticPaymentListResp automaticPaymentListResp;
        BaseResp baseResp = (BaseResp) obj;
        QueryScheduleRepository queryScheduleRepository = new QueryScheduleRepository();
        AutomaticPaymentResp automaticPaymentResp = this.a;
        if (!(automaticPaymentResp == null || (automaticPaymentListResp = (AutomaticPaymentListResp) queryScheduleRepository.loadFromLocal()) == null)) {
            automaticPaymentListResp.getReminderScheduleInfoDetails().remove(automaticPaymentResp);
            queryScheduleRepository.saveToLocal(automaticPaymentListResp);
        }
        CancelAutomaticPaymentRepository.super.saveToLocal(baseResp);
    }
}
