package com.huawei.digitalpayment.schedule.repository;

import com.huawei.digitalpayment.schedule.resp.BillerConfigResp;
import com.huawei.http.b;

public class QueryBillerConfigRepository extends b<BillerConfigResp, BillerConfigResp> {
    public final String getApiPath() {
        return "v1/ethiopia/queryBillerConfig";
    }
}
