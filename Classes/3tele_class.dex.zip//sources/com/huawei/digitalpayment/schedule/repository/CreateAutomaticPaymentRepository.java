package com.huawei.digitalpayment.schedule.repository;

import com.huawei.http.BaseResp;
import com.huawei.http.b;

public class CreateAutomaticPaymentRepository extends b<BaseResp, BaseResp> {
    public CreateAutomaticPaymentRepository() {
        throw null;
    }

    public final String getApiPath() {
        return "v1/ethiopia/createSchedule";
    }
}
