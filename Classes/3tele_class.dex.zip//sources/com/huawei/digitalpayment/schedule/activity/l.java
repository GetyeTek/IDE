package com.huawei.digitalpayment.schedule.activity;

import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;
import com.huawei.digitalpayment.schedule.resp.PaymentFrequencyInfo;

public final /* synthetic */ class l implements SelectDialog.b {
    public final /* synthetic */ CreateAutomaticPaymentActivity a;

    public /* synthetic */ l(CreateAutomaticPaymentActivity createAutomaticPaymentActivity) {
        this.a = createAutomaticPaymentActivity;
    }

    public final void a(Object obj) {
        PaymentFrequencyInfo paymentFrequencyInfo = (PaymentFrequencyInfo) obj;
        CreateAutomaticPaymentActivity createAutomaticPaymentActivity = this.a;
        createAutomaticPaymentActivity.e.dismiss();
        createAutomaticPaymentActivity.g = paymentFrequencyInfo;
        createAutomaticPaymentActivity.b.n.getEditText().setText(paymentFrequencyInfo.getValue());
    }
}
