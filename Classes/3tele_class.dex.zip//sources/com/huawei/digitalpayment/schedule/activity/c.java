package com.huawei.digitalpayment.schedule.activity;

import J8.a;
import V7.f;
import android.text.TextUtils;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.fuel.activity.FuelPaymentActivity;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.adapter.BuyPackageGroupAdapter;
import com.huawei.ethiopia.finance.market.LoanProductsMarketActivity;
import com.huawei.ethiopia.finance.resp.FinanceLoanResp;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.ethiopia.finance.saving.activity.SavingFragment;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingActivatableProductRepository;
import com.huawei.ethiopia.finance.saving.viewmodel.SavingViewModel;
import com.huawei.kbz.chat.contact.b;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.payment.mvvm.DataBindingActivity;
import f4.C0021b;
import i7.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public final /* synthetic */ class c implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        FinanceProductInfo financeProductInfo;
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                List list = (List) obj;
                DataBindingActivity dataBindingActivity = (AutomaticBuyPackageSelectPageActivity) obj2;
                ArrayList arrayList = dataBindingActivity.e;
                arrayList.clear();
                if (!a.i(list)) {
                    arrayList.addAll(list);
                }
                BuyPackageGroupAdapter buyPackageGroupAdapter = dataBindingActivity.i;
                if (buyPackageGroupAdapter == null) {
                    dataBindingActivity.b.e.setLayoutManager(new LinearLayoutManager(dataBindingActivity));
                    BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_buy_packge_group, arrayList);
                    dataBindingActivity.i = baseQuickAdapter;
                    baseQuickAdapter.b = new I4.c(dataBindingActivity, 2);
                    dataBindingActivity.b.e.setAdapter(baseQuickAdapter);
                    return;
                }
                buyPackageGroupAdapter.setList(arrayList);
                return;
            case 1:
                V7.c cVar = (V7.c) obj;
                int i = LoanProductsMarketActivity.v;
                LoanProductsMarketActivity loanProductsMarketActivity = (LoanProductsMarketActivity) obj2;
                if (cVar.d()) {
                    loanProductsMarketActivity.g.a(1);
                    return;
                } else if (cVar.b()) {
                    f.c(cVar);
                    loanProductsMarketActivity.g.a(3);
                    return;
                } else if (cVar.f()) {
                    loanProductsMarketActivity.g.a(2);
                    loanProductsMarketActivity.h = (FinanceLoanResp) cVar.c;
                    ArrayList arrayList2 = loanProductsMarketActivity.e;
                    arrayList2.clear();
                    arrayList2.addAll(loanProductsMarketActivity.h.getProductList());
                    loanProductsMarketActivity.J0(loanProductsMarketActivity.F0());
                    return;
                } else {
                    return;
                }
            case 2:
                C0021b bVar = (C0021b) obj2;
                bVar.getClass();
                if (((Boolean) obj).booleanValue()) {
                    int i2 = bVar.f;
                    if (i2 == 2) {
                        bVar.c();
                    } else if (i2 == 3) {
                        bVar.a();
                    } else if (i2 == 4) {
                        bVar.b();
                    }
                    bVar.f = -1;
                    return;
                }
                return;
            case 3:
                V7.c cVar2 = (V7.c) obj;
                SavingFragment savingFragment = (SavingFragment) obj2;
                if (cVar2.d()) {
                    savingFragment.g.a(1);
                    return;
                } else if (cVar2.b()) {
                    savingFragment.g.a(3);
                    return;
                } else {
                    List list2 = (List) cVar2.c;
                    if (list2 == null || list2.size() <= 0 || (financeProductInfo = (FinanceProductInfo) list2.get(0)) == null || (!TextUtils.isEmpty(financeProductInfo.getProductRateValue()) && !TextUtils.equals("0%", financeProductInfo.getProductRateValue()))) {
                        SavingViewModel savingViewModel = savingFragment.c;
                        String str = savingFragment.e;
                        savingViewModel.a.setValue(V7.c.c());
                        new QuerySavingActivatableProductRepository(true, str).sendRequest(new b(savingViewModel, 2));
                    }
                    if (cVar2.f()) {
                        savingFragment.g.a(2);
                        if (!list2.isEmpty() || !savingFragment.i) {
                            savingFragment.a.submitList(list2);
                            return;
                        }
                        savingFragment.b.e.setVisibility(8);
                        savingFragment.b.a.setVisibility(8);
                        savingFragment.b.c.getRoot().setVisibility(8);
                        savingFragment.g.a(4);
                        return;
                    }
                    return;
                }
            default:
                V7.c cVar3 = (V7.c) obj;
                int i5 = FuelPaymentActivity.e;
                FuelPaymentActivity fuelPaymentActivity = (FuelPaymentActivity) obj2;
                f.b(fuelPaymentActivity, cVar3);
                if (cVar3.b()) {
                    f.c(cVar3);
                    return;
                } else if (cVar3.f()) {
                    HashMap hashMap = new HashMap();
                    hashMap.put("businessType", fuelPaymentActivity.d.getFuelPaymentQrCode());
                    hashMap.put("fuelPayment", "fuelPayment");
                    hashMap.put("tradeType", "QrCode");
                    a.a.a.b(fuelPaymentActivity, PaySceneEnum.FUEL_PAYMENT, (CheckoutResp) cVar3.c, hashMap, new x4.a(fuelPaymentActivity));
                    return;
                } else {
                    return;
                }
        }
    }
}
