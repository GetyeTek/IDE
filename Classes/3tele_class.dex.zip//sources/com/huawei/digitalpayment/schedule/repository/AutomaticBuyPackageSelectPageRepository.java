package com.huawei.digitalpayment.schedule.repository;

import com.huawei.digitalpayment.schedule.resp.TopUpPageDataResp;
import com.huawei.http.b;

public class AutomaticBuyPackageSelectPageRepository extends b<TopUpPageDataResp, TopUpPageDataResp> {
    public final String getApiPath() {
        return "v1/ethiopia/getPackageData";
    }
}
