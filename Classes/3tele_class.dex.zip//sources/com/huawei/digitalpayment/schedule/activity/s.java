package com.huawei.digitalpayment.schedule.activity;

import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;
import com.huawei.digitalpayment.schedule.resp.BillerItem;

public final class s implements SelectDialog.b<BillerItem> {
    public final /* synthetic */ CreateAutomaticPaymentActivity a;

    public s(CreateAutomaticPaymentActivity createAutomaticPaymentActivity) {
        this.a = createAutomaticPaymentActivity;
    }

    public final void a(Object obj) {
        CreateAutomaticPaymentActivity createAutomaticPaymentActivity = this.a;
        createAutomaticPaymentActivity.o.dismiss();
        CreateAutomaticPaymentActivity.E0(createAutomaticPaymentActivity, (BillerItem) obj);
    }
}
