package com.huawei.digitalpayment.schedule.activity;

import O2.a;
import android.text.Editable;
import android.text.TextUtils;
import com.huawei.ethiopia.finance.repayment.activity.FinanceRepaymentActivity;
import com.huawei.payment.mvvm.DataBindingActivity;

public final class e extends a {
    public final /* synthetic */ int b;
    public final /* synthetic */ DataBindingActivity c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e(DataBindingActivity dataBindingActivity, int i) {
        super(1);
        this.b = i;
        this.c = dataBindingActivity;
    }

    public final void afterTextChanged(Editable editable) {
        FinanceRepaymentActivity financeRepaymentActivity = this.c;
        switch (this.b) {
            case 0:
                AutomaticBuyPackageSelectPageActivity automaticBuyPackageSelectPageActivity = (AutomaticBuyPackageSelectPageActivity) financeRepaymentActivity;
                if (TextUtils.isEmpty(editable)) {
                    int i = AutomaticBuyPackageSelectPageActivity.l;
                    automaticBuyPackageSelectPageActivity.b.b.setVisibility(8);
                    automaticBuyPackageSelectPageActivity.b.d.setVisibility(0);
                    automaticBuyPackageSelectPageActivity.E0();
                    return;
                }
                int i2 = AutomaticBuyPackageSelectPageActivity.l;
                automaticBuyPackageSelectPageActivity.b.b.setVisibility(0);
                automaticBuyPackageSelectPageActivity.b.d.setVisibility(8);
                return;
            default:
                FinanceRepaymentActivity financeRepaymentActivity2 = financeRepaymentActivity;
                if (TextUtils.equals(editable.toString(), "01")) {
                    int i5 = FinanceRepaymentActivity.e;
                    financeRepaymentActivity2.b.b.setAreaCode("+251");
                    financeRepaymentActivity2.d.setText("");
                } else {
                    int i6 = FinanceRepaymentActivity.e;
                    financeRepaymentActivity2.b.b.setAreaCode("");
                    financeRepaymentActivity2.d.setText("");
                }
                financeRepaymentActivity2.b.d.setEnabled(financeRepaymentActivity2.E0());
                return;
        }
    }
}
