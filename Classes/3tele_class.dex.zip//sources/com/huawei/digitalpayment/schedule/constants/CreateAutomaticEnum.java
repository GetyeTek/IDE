package com.huawei.digitalpayment.schedule.constants;

import java.io.Serializable;

public enum CreateAutomaticEnum implements Serializable {
    SEND_MONEY("P2PTransfer", "Schedule_Send_money_V1", "Schedule_Send_money_Submit_V1"),
    BUY_AIRTIME("AirtimeRecharge", "Schedule_Buy Airtime_V1", "Schedule_Buy Airtime_Submit_V1"),
    PAY_BILL("CustomerPayBill", "Schedule Pay_Bill_V1", "Schedule_Pay_Bill_Submit_V1"),
    BUY_PACKAGE("BuyPackage", "Schedule Buy_Package_V1", "Schedule_Buy_Package_Submit_V1");
    
    private final String sendReportTag;
    private final String submitReportTag;
    private final String transactionType;

    private CreateAutomaticEnum(String str, String str2, String str3) {
        this.transactionType = str;
        this.sendReportTag = str2;
        this.submitReportTag = str3;
    }

    public String getSendReportTag() {
        return this.sendReportTag;
    }

    public String getSubmitReportTag() {
        return this.submitReportTag;
    }

    public String getTransactionType() {
        return this.transactionType;
    }
}
