package com.huawei.digitalpayment.schedule.activity;

import V7.e;
import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModel;
import b4.i;
import c6.n;
import c6.o;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$mipmap;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityCreateAutomaticPaymentSelectTypeBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.Map;
import o0.b;
import w5.a;

@Route(path = "/topUpModule/createAutomaticPaymentSelectType")
public class CreateAutomaticPaymentSelectTypeActivity extends DataBindingActivity<ActivityCreateAutomaticPaymentSelectTypeBinding, ViewModel> {
    public static final /* synthetic */ int d = 0;

    public final int C0() {
        return R$layout.activity_create_automatic_payment_select_type;
    }

    public final void E0(CreateAutomaticEnum createAutomaticEnum) {
        a.a(createAutomaticEnum.getSendReportTag());
        Bundle bundle = new Bundle(1);
        bundle.putSerializable("createAutomaticEnum", createAutomaticEnum);
        b.d((Activity) null, "/topUpModule/createAutomaticPayment", bundle, (Map) null);
        finish();
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.schedule.activity.CreateAutomaticPaymentSelectTypeActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        CreateAutomaticPaymentSelectTypeActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.color_F4F4F4), false);
        e.a(this, getString(R$string.create_schedule_payment), R.layout.common_toolbar);
        this.b.d.c.setVisibility(8);
        this.b.d.b.setImageResource(R$mipmap.home_v5_icon_send_money);
        this.b.d.d.setText(R$string.designstandard_send_money);
        this.b.d.a.setOnClickListener(new n(this, 4));
        this.b.a.c.setVisibility(8);
        this.b.a.b.setImageResource(R$mipmap.topup_icon_transfer_to_customer);
        this.b.a.d.setText(R$string.buy_airtime);
        this.b.a.a.setOnClickListener(new N4.n(this, 5));
        this.b.c.c.setVisibility(8);
        this.b.c.b.setImageResource(R$mipmap.topup_icon_paybill);
        this.b.c.d.setText(R$string.pay_bill);
        this.b.c.a.setOnClickListener(new i(this, 4));
        this.b.b.c.setVisibility(8);
        this.b.b.b.setImageResource(R$mipmap.topup_icon_buy_package);
        this.b.b.d.setText(R$string.buy_package);
        this.b.b.a.setOnClickListener(new o(this, 1));
    }
}
