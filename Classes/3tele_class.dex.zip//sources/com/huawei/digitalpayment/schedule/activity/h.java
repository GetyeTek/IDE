package com.huawei.digitalpayment.schedule.activity;

import android.view.View;
import com.huawei.digitalpayment.schedule.constants.CreateAutomaticEnum;

public final /* synthetic */ class h implements View.OnClickListener {
    public final void onClick(View view) {
        int i = AutomaticPaymentActivity.g;
        AutomaticPaymentActivity.E0(CreateAutomaticEnum.SEND_MONEY);
    }
}
