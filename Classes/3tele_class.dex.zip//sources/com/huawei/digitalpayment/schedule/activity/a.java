package com.huawei.digitalpayment.schedule.activity;

import V1.h;
import V7.c;
import V7.f;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.homev6.transactionhistory.TransactionSpendGraphFragment;
import com.huawei.digitalpayment.customer.httplib.response.TransactionDailyStatGraphResp;
import com.huawei.digitalpayment.schedule.resp.TopUpPageDataResp;
import com.huawei.digitalpayment.schedule.viewmodel.AutomaticBuyPackageSelectPageViewModel;
import com.huawei.digitalpayment.topup.bean.DataPackGroupsBean;
import com.huawei.digitalpayment.topup.bean.PackageTabsBean;
import com.huawei.digitalpayment.topup.bean.TopUpBean;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final /* synthetic */ class a implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    /* JADX WARNING: type inference failed for: r1v3, types: [java.lang.Object, java.util.Comparator] */
    /* JADX WARNING: type inference failed for: r3v1, types: [java.lang.Object, java.util.Comparator] */
    public final void onChanged(Object obj) {
        PackageTabsBean packageTabsBean;
        int i = 0;
        Object obj2 = this.b;
        c cVar = (c) obj;
        switch (this.a) {
            case 0:
                int i2 = AutomaticBuyPackageSelectPageActivity.l;
                AutomaticBuyPackageSelectPageActivity automaticBuyPackageSelectPageActivity = (AutomaticBuyPackageSelectPageActivity) obj2;
                f.b(automaticBuyPackageSelectPageActivity, cVar);
                if (cVar.b()) {
                    f.c(cVar);
                }
                if (cVar.f()) {
                    TopUpPageDataResp topUpPageDataResp = (TopUpPageDataResp) cVar.c;
                    if (!(topUpPageDataResp == null || topUpPageDataResp.getTopUpPageData() == null)) {
                        TopUpBean topUpPageData = topUpPageDataResp.getTopUpPageData();
                        automaticBuyPackageSelectPageActivity.g = topUpPageData;
                        automaticBuyPackageSelectPageActivity.f = topUpPageData.getOperators();
                    }
                    if (automaticBuyPackageSelectPageActivity.g != null) {
                        if (!J8.a.i(automaticBuyPackageSelectPageActivity.f)) {
                            automaticBuyPackageSelectPageActivity.h = automaticBuyPackageSelectPageActivity.f.get(0);
                        }
                        TopUpBean.OperatorsBean operatorsBean = automaticBuyPackageSelectPageActivity.h;
                        if (operatorsBean != null) {
                            AutomaticBuyPackageSelectPageViewModel automaticBuyPackageSelectPageViewModel = automaticBuyPackageSelectPageActivity.c;
                            List<PackageTabsBean> packageTabs = operatorsBean.getPackageTabs();
                            automaticBuyPackageSelectPageViewModel.getClass();
                            try {
                                Collections.sort(packageTabs, new Object());
                            } catch (Exception e) {
                                e.getMessage();
                                h.b();
                            }
                            automaticBuyPackageSelectPageViewModel.b.setValue(packageTabs);
                            if (automaticBuyPackageSelectPageActivity.h.getPackageTabs() != null && (packageTabsBean = automaticBuyPackageSelectPageActivity.h.getPackageTabs().get(0)) != null) {
                                AutomaticBuyPackageSelectPageViewModel automaticBuyPackageSelectPageViewModel2 = automaticBuyPackageSelectPageActivity.c;
                                List<DataPackGroupsBean> packageGroups = packageTabsBean.getPackageGroups();
                                automaticBuyPackageSelectPageViewModel2.getClass();
                                try {
                                    Collections.sort(packageGroups, new Object());
                                } catch (Exception e2) {
                                    e2.getMessage();
                                    h.b();
                                }
                                automaticBuyPackageSelectPageViewModel2.c.setValue(packageGroups);
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            default:
                TransactionSpendGraphFragment transactionSpendGraphFragment = (TransactionSpendGraphFragment) obj2;
                transactionSpendGraphFragment.getClass();
                if (cVar.b()) {
                    f.c(cVar);
                    return;
                } else if (cVar.f()) {
                    TransactionDailyStatGraphResp transactionDailyStatGraphResp = (TransactionDailyStatGraphResp) cVar.c;
                    if (transactionDailyStatGraphResp.getTransactionDailyList() != null) {
                        transactionSpendGraphFragment.n = transactionDailyStatGraphResp.getTransactionDailyList();
                        transactionSpendGraphFragment.t = transactionDailyStatGraphResp;
                        ArrayList<TransactionDailyStatGraphResp.DailyStatGraph> transactionDailyList = transactionDailyStatGraphResp.getTransactionDailyList();
                        ArrayList arrayList = transactionSpendGraphFragment.j;
                        arrayList.clear();
                        ArrayList arrayList2 = transactionSpendGraphFragment.k;
                        arrayList2.clear();
                        if (transactionDailyList != null && transactionDailyList.size() > 0) {
                            float parseFloat = Float.parseFloat(transactionDailyList.get(0).getCreditAmount());
                            float parseFloat2 = Float.parseFloat(transactionDailyList.get(0).getCreditAmount());
                            float parseFloat3 = Float.parseFloat(transactionDailyList.get(0).getDebitAmount());
                            float parseFloat4 = Float.parseFloat(transactionDailyList.get(0).getDebitAmount());
                            Iterator<TransactionDailyStatGraphResp.DailyStatGraph> it = transactionDailyList.iterator();
                            while (it.hasNext()) {
                                TransactionDailyStatGraphResp.DailyStatGraph next = it.next();
                                if (parseFloat2 > Float.parseFloat(next.getCreditAmount())) {
                                    parseFloat2 = Float.parseFloat(next.getCreditAmount());
                                }
                                if (parseFloat4 > Float.parseFloat(next.getDebitAmount())) {
                                    parseFloat4 = Float.parseFloat(next.getDebitAmount());
                                }
                                if (parseFloat < Float.parseFloat(next.getCreditAmount())) {
                                    parseFloat = Float.parseFloat(next.getCreditAmount());
                                }
                                if (parseFloat3 < Float.parseFloat(next.getDebitAmount())) {
                                    parseFloat3 = Float.parseFloat(next.getDebitAmount());
                                }
                            }
                            float f = (float) 6;
                            transactionSpendGraphFragment.l = Math.round((parseFloat / f) + 0.5f);
                            transactionSpendGraphFragment.m = Math.round((parseFloat3 / f) + 0.5f);
                            arrayList2.add(0);
                            arrayList.add(0);
                            while (i < 6) {
                                i++;
                                arrayList.add(Integer.valueOf(transactionSpendGraphFragment.l * i));
                                arrayList2.add(Integer.valueOf(transactionSpendGraphFragment.m * i));
                            }
                        }
                        transactionSpendGraphFragment.B0();
                        transactionSpendGraphFragment.C0();
                        return;
                    }
                    return;
                } else {
                    return;
                }
        }
    }
}
