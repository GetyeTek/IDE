package com.huawei.digitalpayment.schedule.resp;

import com.blankj.utilcode.util.J;
import com.google.gson.annotations.SerializedName;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.http.BaseResp;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class AutomaticPaymentResp extends BaseResp {
    private String amount;
    private String currency;
    private List<AutomaticDisplayItem> displayItems;
    private List<Map<String, String>> extraParameter;
    private String firstPaymentReminderDate;
    private String freeText;
    private String frequency;
    private String initiatorIdentifier;
    private String initiatorIdentifierType;
    private String issuePaymentReminderUntil;
    private String needConfirmation;
    private String preWarningPeriod;
    @SerializedName(alternate = {"receiverShortCode"}, value = "receiverMsisdn")
    private String receiverMsisdn;
    private String reminderScheduleId;
    private String scheduleName;
    private String sendPreWarning;
    private String transactionType;

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.reminderScheduleId, ((AutomaticPaymentResp) obj).reminderScheduleId);
    }

    public String getAmount() {
        return this.amount;
    }

    public String getCurrency() {
        return this.currency;
    }

    public List<AutomaticDisplayItem> getDisplayItems() {
        return this.displayItems;
    }

    public List<Map<String, String>> getExtraParameter() {
        return this.extraParameter;
    }

    public String getFirstPaymentReminderDate() {
        return this.firstPaymentReminderDate;
    }

    public String getFreeText() {
        return this.freeText;
    }

    public String getFrequency() {
        return this.frequency;
    }

    public String getFrequencyDesc() {
        if ("2".equals(this.frequency)) {
            return J.a().getString(R$string.daily);
        }
        if ("3".equals(this.frequency)) {
            return J.a().getString(R$string.weekly);
        }
        if (PaymentFrequencyInfo.MONTHLY.equals(this.frequency)) {
            return J.a().getString(R$string.monthly);
        }
        return this.frequency;
    }

    public String getInitiatorIdentifier() {
        return this.initiatorIdentifier;
    }

    public String getInitiatorIdentifierType() {
        return this.initiatorIdentifierType;
    }

    public String getIssuePaymentReminderUntil() {
        return this.issuePaymentReminderUntil;
    }

    public String getNeedConfirmation() {
        return this.needConfirmation;
    }

    public String getPreWarningPeriod() {
        return this.preWarningPeriod;
    }

    public String getReceiverMsisdn() {
        return this.receiverMsisdn;
    }

    public String getReminderScheduleId() {
        return this.reminderScheduleId;
    }

    public String getScheduleName() {
        return this.scheduleName;
    }

    public String getSendPreWarning() {
        return this.sendPreWarning;
    }

    public String getTransactionType() {
        return this.transactionType;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.reminderScheduleId});
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setDisplayItems(List<AutomaticDisplayItem> list) {
        this.displayItems = list;
    }

    public void setExtraParameter(List<Map<String, String>> list) {
        this.extraParameter = list;
    }

    public void setFirstPaymentReminderDate(String str) {
        this.firstPaymentReminderDate = str;
    }

    public void setFreeText(String str) {
        this.freeText = str;
    }

    public void setFrequency(String str) {
        this.frequency = str;
    }

    public void setInitiatorIdentifier(String str) {
        this.initiatorIdentifier = str;
    }

    public void setInitiatorIdentifierType(String str) {
        this.initiatorIdentifierType = str;
    }

    public void setIssuePaymentReminderUntil(String str) {
        this.issuePaymentReminderUntil = str;
    }

    public void setNeedConfirmation(String str) {
        this.needConfirmation = str;
    }

    public void setPreWarningPeriod(String str) {
        this.preWarningPeriod = str;
    }

    public void setReceiverMsisdn(String str) {
        this.receiverMsisdn = str;
    }

    public void setReminderScheduleId(String str) {
        this.reminderScheduleId = str;
    }

    public void setScheduleName(String str) {
        this.scheduleName = str;
    }

    public void setSendPreWarning(String str) {
        this.sendPreWarning = str;
    }

    public void setTransactionType(String str) {
        this.transactionType = str;
    }
}
