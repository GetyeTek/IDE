package com.huawei.digitalpayment.schedule.dialog;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;
import com.huawei.digitalpayment.schedule.resp.PaymentFrequencyInfo;
import com.huawei.digitalpayment.topup.R$id;
import java.util.ArrayList;

public class SelectPaymentFrequencyDialog extends SelectDialog<PaymentFrequencyInfo> {
    public final PaymentFrequencyInfo g;

    public SelectPaymentFrequencyDialog(PaymentFrequencyInfo paymentFrequencyInfo, String str, ArrayList arrayList, SelectDialog.b bVar) {
        super(str, arrayList, bVar);
        this.g = paymentFrequencyInfo;
    }

    public final void x0(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        PaymentFrequencyInfo paymentFrequencyInfo = (PaymentFrequencyInfo) obj;
        super.x0(baseViewHolder, paymentFrequencyInfo);
        baseViewHolder.setText(R$id.tv_content, paymentFrequencyInfo.getValue());
    }

    public final boolean z0(Object obj) {
        PaymentFrequencyInfo paymentFrequencyInfo = (PaymentFrequencyInfo) obj;
        PaymentFrequencyInfo paymentFrequencyInfo2 = this.g;
        if (paymentFrequencyInfo2 == null) {
            return false;
        }
        return TextUtils.equals(paymentFrequencyInfo.getKey(), paymentFrequencyInfo2.getKey());
    }
}
