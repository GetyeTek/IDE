package com.huawei.digitalpayment.schedule.activity;

import android.text.TextUtils;
import androidx.lifecycle.Observer;
import com.huawei.common.widget.dialog.LoadingDialog;
import com.huawei.digitalpayment.schedule.resp.BillerItem;
import java.util.Iterator;
import java.util.List;

public final class o implements Observer<List<BillerItem>> {
    public final /* synthetic */ CreateAutomaticPaymentActivity a;

    public o(CreateAutomaticPaymentActivity createAutomaticPaymentActivity) {
        this.a = createAutomaticPaymentActivity;
    }

    public final void onChanged(Object obj) {
        List<BillerItem> list = (List) obj;
        CreateAutomaticPaymentActivity createAutomaticPaymentActivity = this.a;
        LoadingDialog loadingDialog = createAutomaticPaymentActivity.m;
        if (loadingDialog != null && loadingDialog.a) {
            loadingDialog.dismiss();
        }
        createAutomaticPaymentActivity.l = list;
        if (!TextUtils.isEmpty(createAutomaticPaymentActivity.billerCode)) {
            Iterator<BillerItem> it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                BillerItem next = it.next();
                if (next.getBillerCode().equals(createAutomaticPaymentActivity.billerCode)) {
                    createAutomaticPaymentActivity.n = next;
                    break;
                }
            }
            BillerItem billerItem = createAutomaticPaymentActivity.n;
            if (billerItem != null) {
                CreateAutomaticPaymentActivity.E0(createAutomaticPaymentActivity, billerItem);
            }
        }
    }
}
