package com.huawei.digitalpayment.schedule.resp;

import java.io.Serializable;

public class AutomaticDisplayItem implements Serializable {
    private String key;
    private String label;
    private String value;

    public String getKey() {
        return this.key;
    }

    public String getLabel() {
        return this.label;
    }

    public String getValue() {
        return this.value;
    }

    public void setKey(String str) {
        this.key = str;
    }

    public void setLabel(String str) {
        this.label = str;
    }

    public void setValue(String str) {
        this.value = str;
    }
}
