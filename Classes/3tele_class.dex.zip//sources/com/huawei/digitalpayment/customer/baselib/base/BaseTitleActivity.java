package com.huawei.digitalpayment.customer.baselib.base;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import androidx.annotation.ColorRes;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.viewbinding.ViewBinding;
import com.blankj.utilcode.util.f;
import com.google.android.material.appbar.AppBarLayout;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.R$drawable;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.databinding.ActivityBaseTitleBinding;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutTransparentBinding;
import com.huawei.digitalpayment.customer.homev6.transactionhistory.TransactionHistoryActivity;
import com.huawei.module_cash.chapa.activity.CashInViaChapaActivity;
import com.huawei.module_checkout.startpay.activity.StartPayEnterActivity;

public abstract class BaseTitleActivity extends BaseActivity {
    public TextView d;
    public TextView e;
    public ViewBinding f;
    public AppBarLayout g;
    public Toolbar h;

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity] */
    public final ViewBinding C0() {
        if (M0()) {
            LayoutTransparentBinding a = LayoutTransparentBinding.a(getLayoutInflater());
            this.f = a;
            return a;
        }
        ActivityBaseTitleBinding a2 = ActivityBaseTitleBinding.a(getLayoutInflater());
        this.f = a2;
        return a2;
    }

    public void G0() {
        if (!M0() && (this.f instanceof ActivityBaseTitleBinding)) {
            ViewBinding K0 = K0();
            if (K0 != null) {
                this.f.b.addView(K0.getRoot());
            }
            if (L0()) {
                T0();
            } else {
                AppBarLayout findViewById = findViewById(R$id.app_bar_layout);
                this.g = findViewById;
                findViewById.setVisibility(8);
            }
        }
        Q0(getResources().getColor(R$color.colorPageBackgroundDark));
    }

    public abstract ViewBinding K0();

    public boolean L0() {
        return !(this instanceof TransactionHistoryActivity);
    }

    public boolean M0() {
        return this instanceof StartPayEnterActivity;
    }

    public final void N0(String str) {
        TextView textView = this.d;
        if (textView != null) {
            textView.setText(str);
        }
    }

    public final void O0(@StringRes int i) {
        TextView textView = this.d;
        if (textView != null) {
            textView.setText(i);
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity] */
    public final void P0(@ColorRes int i) {
        TextView textView = this.d;
        if (textView != null) {
            textView.setTextColor(ContextCompat.getColor(this, i));
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity] */
    public final void Q0(int i) {
        f.e(this, i, false);
        f.f(this, true);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, androidx.appcompat.app.AppCompatActivity] */
    public final void R0(@ColorRes int i) {
        Drawable drawable = ContextCompat.getDrawable(this, R$drawable.abc_ic_ab_back_material);
        if (drawable != null) {
            drawable.setColorFilter(ContextCompat.getColor(this, i), PorterDuff.Mode.SRC_ATOP);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setHomeAsUpIndicator(drawable);
            }
        }
        this.d.setTextColor(getResources().getColor(i));
    }

    public final void S0(@ColorRes int i) {
        AppBarLayout appBarLayout = this.g;
        if (appBarLayout != null) {
            appBarLayout.setBackground((Drawable) null);
        }
        Toolbar toolbar = this.h;
        if (toolbar != null) {
            toolbar.setBackgroundColor(getResources().getColor(i));
        }
    }

    public final void T0() {
        AppBarLayout findViewById = findViewById(R$id.app_bar_layout);
        this.g = findViewById;
        int i = 0;
        findViewById.setVisibility(0);
        this.d = (TextView) findViewById(R$id.tv_base_title);
        Toolbar findViewById2 = findViewById(R$id.base_toolbar);
        this.h = findViewById2;
        findViewById2.setTitle("");
        TextView textView = (TextView) findViewById(R$id.tv_navigation);
        this.e = textView;
        if (!(this instanceof CashInViaChapaActivity)) {
            i = 8;
        }
        textView.setVisibility(i);
        setSupportActionBar(this.h);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        R0(R$color.colorBlack);
    }
}
