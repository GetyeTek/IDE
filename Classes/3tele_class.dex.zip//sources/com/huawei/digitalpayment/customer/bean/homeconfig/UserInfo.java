package com.huawei.digitalpayment.customer.bean.homeconfig;

import java.io.Serializable;

public class UserInfo implements Serializable {
    public static final String TAG = "UserInfo";
    private static final long serialVersionUID = 1;
    private String MSISDN;
    private String customerLevel;
    private String databaseAccessKey;
    private String dateofBirth;
    private String fullName;
    private String gender;
    private String idNo;
    private String idType;
    private String level;
    private String nationality;
    private String openIMToken;
    private String permanentAddress;
    private String profilePhoto;
    private String receiptQRCode;
    private String state;
    private String token;
    private String town;
    private String township;

    public String getCustomerLevel() {
        return this.customerLevel;
    }

    public String getDatabaseAccessKey() {
        return this.databaseAccessKey;
    }

    public String getDateofBirth() {
        return this.dateofBirth;
    }

    public String getFullName() {
        return this.fullName;
    }

    public String getGender() {
        return this.gender;
    }

    public String getIdNo() {
        return this.idNo;
    }

    public String getIdType() {
        return this.idType;
    }

    public String getLevel() {
        return this.level;
    }

    public String getMSISDN() {
        return this.MSISDN;
    }

    public String getNationality() {
        return this.nationality;
    }

    public String getOpenIMToken() {
        return this.openIMToken;
    }

    public String getPermanentAddress() {
        return this.permanentAddress;
    }

    public String getProfilePhoto() {
        return this.profilePhoto;
    }

    public String getReceiptQRCode() {
        return this.receiptQRCode;
    }

    public String getState() {
        return this.state;
    }

    public String getToken() {
        return this.token;
    }

    public String getTown() {
        return this.town;
    }

    public String getTownship() {
        return this.township;
    }

    public void setCustomerLevel(String str) {
        this.customerLevel = str;
    }

    public void setDatabaseAccessKey(String str) {
        this.databaseAccessKey = str;
    }

    public void setDateofBirth(String str) {
        this.dateofBirth = str;
    }

    public void setFullName(String str) {
        this.fullName = str;
    }

    public void setGender(String str) {
        this.gender = str;
    }

    public void setIdNo(String str) {
        this.idNo = str;
    }

    public void setIdType(String str) {
        this.idType = str;
    }

    public void setLevel(String str) {
        this.level = str;
    }

    public void setMSISDN(String str) {
        this.MSISDN = str;
    }

    public void setNationality(String str) {
        this.nationality = str;
    }

    public void setOpenIMToken(String str) {
        this.openIMToken = str;
    }

    public void setPermanentAddress(String str) {
        this.permanentAddress = str;
    }

    public void setProfilePhoto(String str) {
        this.profilePhoto = str;
    }

    public void setReceiptQRCode(String str) {
        this.receiptQRCode = str;
    }

    public void setState(String str) {
        this.state = str;
    }

    public void setToken(String str) {
        this.token = str;
    }

    public void setTown(String str) {
        this.town = str;
    }

    public void setTownship(String str) {
        this.township = str;
    }
}
