package com.huawei.digitalpayment.customer.baselib.sms;

import V1.h;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.Task;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsAutoFill implements LifecycleObserver {
    public static final Pattern c = Pattern.compile("\\d{6}");
    public final a a;
    public final IntentFilter b = new IntentFilter("com.google.android.gms.auth.api.phone.SMS_RETRIEVED");

    public class a extends BroadcastReceiver {
        public final /* synthetic */ R1.a a;

        public a(R1.a aVar) {
            this.a = aVar;
        }

        public final void onReceive(Context context, Intent intent) {
            Bundle extras;
            String str;
            try {
                intent.getAction();
                h.b();
                if ("com.google.android.gms.auth.api.phone.SMS_RETRIEVED".equals(intent.getAction()) && (extras = intent.getExtras()) != null) {
                    Status status = (Status) extras.get("com.google.android.gms.auth.api.phone.EXTRA_STATUS");
                    status.getStatusCode();
                    h.b();
                    if (status.getStatusCode() == 0) {
                        h.b();
                        SmsAutoFill smsAutoFill = SmsAutoFill.this;
                        Pattern pattern = SmsAutoFill.c;
                        smsAutoFill.getClass();
                        Matcher matcher = SmsAutoFill.c.matcher((String) extras.get("com.google.android.gms.auth.api.phone.EXTRA_SMS_MESSAGE"));
                        if (matcher.find()) {
                            str = matcher.group(0);
                        } else {
                            str = "";
                        }
                        if (!TextUtils.isEmpty(str)) {
                            this.a.onSuccess(str);
                        }
                    }
                }
            } catch (Exception e) {
                e.getMessage();
                h.b();
            }
        }
    }

    public SmsAutoFill(R1.a<String> aVar) {
        this.a = new a(aVar);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.google.android.gms.tasks.OnSuccessListener, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v1, types: [com.google.android.gms.tasks.OnFailureListener, java.lang.Object] */
    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    public void onCreate(LifecycleOwner lifecycleOwner) {
        Objects.toString(lifecycleOwner);
        h.b();
        FragmentActivity fragmentActivity = (FragmentActivity) lifecycleOwner;
        Task startSmsRetriever = SmsRetriever.getClient(fragmentActivity).startSmsRetriever();
        startSmsRetriever.addOnSuccessListener(new Object());
        startSmsRetriever.addOnFailureListener(new Object());
        int i = Build.VERSION.SDK_INT;
        IntentFilter intentFilter = this.b;
        a aVar = this.a;
        if (i >= 34) {
            fragmentActivity.registerReceiver(aVar, intentFilter, "com.google.android.gms.auth.api.phone.permission.SEND", (Handler) null, 4);
        } else {
            fragmentActivity.registerReceiver(aVar, intentFilter, "com.google.android.gms.auth.api.phone.permission.SEND", (Handler) null);
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy(LifecycleOwner lifecycleOwner) {
        h.b();
        ((FragmentActivity) lifecycleOwner).unregisterReceiver(this.a);
    }
}
