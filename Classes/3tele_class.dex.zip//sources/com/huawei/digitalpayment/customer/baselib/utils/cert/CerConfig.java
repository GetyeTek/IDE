package com.huawei.digitalpayment.customer.baselib.utils.cert;

public class CerConfig {
    private String k;
    private String str;

    public String getK() {
        return this.k;
    }

    public String getStr() {
        return this.str;
    }

    public void setK(String str2) {
        this.k = str2;
    }

    public void setStr(String str2) {
        this.str = str2;
    }
}
