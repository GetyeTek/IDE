package com.huawei.digitalpayment.customer.baselib.base;

import F2.d;
import R9.e;
import V1.a;
import V1.h;
import W1.b;
import Yb.j;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.topup.ui.SingleOperatorActivity;

public abstract class BaseActivity extends AppCompatActivity {
    public static final /* synthetic */ int c = 0;
    public b.b a;
    public GestureDetector b = null;

    public abstract ViewBinding C0();

    public abstract void D0();

    public final void E0(View view) {
        if (this.a == null) {
            b.b c2 = b.b().c(view);
            c2.b = new F2.b(this, 0);
            this.a = c2;
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, java.lang.Object, androidx.appcompat.app.AppCompatActivity] */
    public void F0() {
        if (this.a == null) {
            b b2 = b.b();
            b2.getClass();
            b.b bVar = new b.b(b2.a, this, (ViewGroup) findViewById(16908290));
            bVar.b = new F2.b(this, 0);
            this.a = bVar;
        }
    }

    public abstract void G0();

    public boolean H0() {
        return !(this instanceof SingleOperatorActivity);
    }

    public void I0() {
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity] */
    public final void J0(Class<?> cls, boolean z) {
        startActivity(new Intent(this, cls));
        if (z) {
            finish();
        }
    }

    public final Resources getResources() {
        Resources resources = BaseActivity.super.getResources();
        if (resources.getConfiguration().fontScale != 1.0f) {
            Configuration configuration = new Configuration();
            configuration.setToDefaults();
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        }
        return resources;
    }

    public final void onConfigurationChanged(@NonNull Configuration configuration) {
        BaseActivity.super.onConfigurationChanged(configuration);
        if (configuration.fontScale != 1.0f) {
            getResources();
        }
    }

    /* JADX WARNING: type inference failed for: r0v6, types: [java.lang.Object, androidx.core.view.OnApplyWindowInsetsListener] */
    @SuppressLint({"SourceLockedOrientationActivity"})
    public void onCreate(@Nullable Bundle bundle) {
        getWindow().setSoftInputMode(32);
        BaseActivity.super.onCreate(bundle);
        setRequestedOrientation(1);
        if (C0() != null) {
            View root = C0().getRoot();
            root.setFitsSystemWindows(H0());
            setContentView(root);
            if (Build.VERSION.SDK_INT >= 35 && !root.getFitsSystemWindows()) {
                root.setFitsSystemWindows(false);
                ViewCompat.setOnApplyWindowInsetsListener(root, new Object());
            }
        }
        G0();
        D0();
        this.b = new GestureDetector(this, new d(this));
    }

    @j
    public void onEvent(String str) {
    }

    public final boolean onSupportNavigateUp() {
        onBackPressed();
        return BaseActivity.super.onSupportNavigateUp();
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        return this.b.onTouchEvent(motionEvent);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.digitalpayment.customer.baselib.base.BaseActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity] */
    public final void setRequestedOrientation(int i) {
        if (Build.VERSION.SDK_INT != 26 || !a.a(this)) {
            BaseActivity.super.setRequestedOrientation(i);
        } else {
            h.b();
        }
    }

    public final void startActivityForResult(Intent intent, int i, @Nullable Bundle bundle) {
        boolean z;
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - e.a >= 500) {
            z = true;
        } else {
            z = false;
        }
        e.a = currentTimeMillis;
        if (z) {
            BaseActivity.super.startActivityForResult(intent, i, bundle);
        }
    }
}
