package com.huawei.digitalpayment.customer.bean.sp;

import java.io.Serializable;

public class SPCacheModel<T> implements Serializable {
    private long currentTime;
    private int saveTime;
    private T value;

    public SPCacheModel() {
    }

    public long getCurrentTime() {
        return this.currentTime;
    }

    public int getSaveTime() {
        return this.saveTime;
    }

    public T getValue() {
        return this.value;
    }

    public void setCurrentTime(long j) {
        this.currentTime = j;
    }

    public void setSaveTime(int i) {
        this.saveTime = i;
    }

    public void setValue(T t) {
        this.value = t;
    }

    public SPCacheModel(int i, T t, long j) {
        this.saveTime = i;
        this.value = t;
        this.currentTime = j;
    }
}
