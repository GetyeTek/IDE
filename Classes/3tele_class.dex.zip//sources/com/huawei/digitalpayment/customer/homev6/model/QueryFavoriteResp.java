package com.huawei.digitalpayment.customer.homev6.model;

import com.huawei.http.BaseResp;
import java.util.List;
import java.util.Map;

public class QueryFavoriteResp extends BaseResp {
    private List<HomeFunction> favoriteFunctions;
    private Map<String, HomeFunction> functionDefine;
    private Map<String, HomeFunction> recommendedFunctions;

    public List<HomeFunction> getFavoriteFunctions() {
        return this.favoriteFunctions;
    }

    public Map<String, HomeFunction> getFunctionDefine() {
        return this.functionDefine;
    }

    public Map<String, HomeFunction> getRecommendedFunctions() {
        return this.recommendedFunctions;
    }

    public void setFavoriteFunctions(List<HomeFunction> list) {
        this.favoriteFunctions = list;
    }

    public void setFunctionDefine(Map<String, HomeFunction> map) {
        this.functionDefine = map;
    }

    public void setRecommendedFunctions(Map<String, HomeFunction> map) {
        this.recommendedFunctions = map;
    }
}
