package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import com.huawei.digitalpayment.customer.httplib.response.FundsSourceInfoDisplay;
import com.huawei.module_checkout.R;
import com.huawei.module_checkout.confirm.PaymentConfirmActivity;

public class MyRadioGroup extends LinearLayout {
    public int a;
    public boolean b;
    public b c;
    public final a d;
    public final c e;

    public class a implements CompoundButton.OnCheckedChangeListener {
        public a() {
        }

        public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            MyRadioGroup myRadioGroup = MyRadioGroup.this;
            if (!myRadioGroup.b) {
                myRadioGroup.b = true;
                int i = myRadioGroup.a;
                if (i != -1) {
                    myRadioGroup.c(i, false);
                }
                myRadioGroup.b = false;
                myRadioGroup.setCheckedId(compoundButton.getId());
            }
        }
    }

    public interface b {
    }

    public class c implements ViewGroup.OnHierarchyChangeListener {
        public ViewGroup.OnHierarchyChangeListener a;

        public c() {
        }

        public final void onChildViewAdded(View view, View view2) {
            MyRadioGroup myRadioGroup = MyRadioGroup.this;
            if (view == myRadioGroup && (view2 instanceof RadioButton)) {
                if (view2.getId() == -1) {
                    view2.setId(view2.hashCode());
                }
                ((RadioButton) view2).setOnCheckedChangeListener(myRadioGroup.d);
            } else if (view == myRadioGroup && (view2 instanceof ViewGroup)) {
                myRadioGroup.getClass();
                RadioButton b2 = MyRadioGroup.b((ViewGroup) view2);
                if (b2.getId() == -1) {
                    b2.setId(b2.hashCode());
                }
                b2.setOnCheckedChangeListener(myRadioGroup.d);
            }
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.a;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public final void onChildViewRemoved(View view, View view2) {
            MyRadioGroup myRadioGroup = MyRadioGroup.this;
            if (view == myRadioGroup && (view2 instanceof RadioButton)) {
                ((RadioButton) view2).setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener) null);
            } else if (view == myRadioGroup && (view2 instanceof ViewGroup)) {
                myRadioGroup.getClass();
                MyRadioGroup.b((ViewGroup) view2).setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener) null);
            }
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.a;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    public static class d extends LinearLayout.LayoutParams {
        public final void setBaseAttributes(TypedArray typedArray, int i, int i2) {
            if (typedArray.hasValue(i)) {
                this.width = typedArray.getLayoutDimension(i, "layout_width");
            } else {
                this.width = -2;
            }
            if (typedArray.hasValue(i2)) {
                this.height = typedArray.getLayoutDimension(i2, "layout_height");
            } else {
                this.height = -2;
            }
        }
    }

    public MyRadioGroup(Context context) {
        super(context);
        this.a = -1;
        this.b = false;
        setOrientation(1);
        this.d = new a();
        c cVar = new c();
        this.e = cVar;
        super.setOnHierarchyChangeListener(cVar);
    }

    public static RadioButton b(ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        RadioButton radioButton = null;
        for (int i = 0; i < childCount; i++) {
            if (viewGroup.getChildAt(i) instanceof RadioButton) {
                radioButton = (RadioButton) viewGroup.getChildAt(i);
            } else if (viewGroup.getChildAt(i) instanceof ViewGroup) {
                b((ViewGroup) viewGroup.getChildAt(i));
            }
        }
        return radioButton;
    }

    /* access modifiers changed from: private */
    public void setCheckedId(int i) {
        this.a = i;
        com.huawei.kbz.chat.contact.d dVar = this.c;
        if (dVar != null) {
            com.huawei.kbz.chat.contact.d dVar2 = dVar;
            dVar2.getClass();
            int i2 = PaymentConfirmActivity.r;
            PaymentConfirmActivity paymentConfirmActivity = dVar2.a;
            View findViewById = paymentConfirmActivity.findViewById(i);
            if (findViewById != null) {
                String str = (String) findViewById.getTag();
                str.getClass();
                if (str.equals("WALLET")) {
                    paymentConfirmActivity.m = "WALLET";
                    paymentConfirmActivity.j.b.setText(paymentConfirmActivity.getString(R.string.designstandard_pay));
                    paymentConfirmActivity.n = paymentConfirmActivity.W0(paymentConfirmActivity.m);
                } else if (str.equals("OD")) {
                    paymentConfirmActivity.m = "OD";
                    LoadingButton loadingButton = paymentConfirmActivity.j.b;
                    int i5 = R.string.designstandard_enable_and_pay;
                    loadingButton.setText(paymentConfirmActivity.getString(i5));
                    FundsSourceInfoDisplay W0 = paymentConfirmActivity.W0(paymentConfirmActivity.m);
                    paymentConfirmActivity.n = W0;
                    if (W0.isSignOD()) {
                        paymentConfirmActivity.j.b.setText(paymentConfirmActivity.getString(R.string.designstandard_pay));
                    } else {
                        paymentConfirmActivity.j.b.setText(paymentConfirmActivity.getString(i5));
                    }
                }
            }
        }
    }

    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof RadioButton) {
            RadioButton radioButton = (RadioButton) view;
            if (radioButton.isChecked()) {
                this.b = true;
                int i2 = this.a;
                if (i2 != -1) {
                    c(i2, false);
                }
                this.b = false;
                setCheckedId(radioButton.getId());
            }
        } else if (view instanceof ViewGroup) {
            RadioButton b2 = b((ViewGroup) view);
            if (b2 != null) {
                if (b2.isChecked()) {
                    this.b = true;
                    int i5 = this.a;
                    if (i5 != -1) {
                        c(i5, false);
                    }
                    this.b = false;
                    setCheckedId(b2.getId());
                }
            } else {
                return;
            }
        }
        super.addView(view, i, layoutParams);
    }

    public final void c(int i, boolean z) {
        View findViewById = findViewById(i);
        if (findViewById instanceof RadioButton) {
            ((RadioButton) findViewById).setChecked(z);
        }
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof d;
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    public final void onFinishInflate() {
        super.onFinishInflate();
        int i = this.a;
        if (i != -1) {
            this.b = true;
            c(i, true);
            this.b = false;
            setCheckedId(this.a);
        }
    }

    public void setOnCheckedChangeListener(b bVar) {
        this.c = bVar;
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.e.a = onHierarchyChangeListener;
    }

    public final LinearLayout.LayoutParams generateDefaultLayoutParams() {
        return new LinearLayout.LayoutParams(-2, -2);
    }

    /* renamed from: generateLayoutParams  reason: collision with other method in class */
    public final LinearLayout.LayoutParams m0generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    public MyRadioGroup(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = -1;
        this.b = false;
        this.d = new a();
        c cVar = new c();
        this.e = cVar;
        super.setOnHierarchyChangeListener(cVar);
    }
}
