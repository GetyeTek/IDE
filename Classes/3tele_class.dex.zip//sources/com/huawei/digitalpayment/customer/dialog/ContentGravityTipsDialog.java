package com.huawei.digitalpayment.customer.dialog;

import D6.a;
import H6.i;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.common.R;
import com.huawei.common.widget.dialog.BaseDialog;

public class ContentGravityTipsDialog extends BaseDialog {
    public TextView c;
    public TextView d;
    public TextView e;
    public TextView f;
    public String g;
    public String h;
    public String i;
    public int j;

    public final void onStart() {
        Window window;
        ContentGravityTipsDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setLayout((BaseDialog.w0(window) * 8) / 10, -2);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        ContentGravityTipsDialog.super.onViewCreated(view, bundle);
        this.c = (TextView) view.findViewById(R.id.tv_left_button);
        this.d = (TextView) view.findViewById(R.id.tv_right_button);
        this.f = (TextView) view.findViewById(R.id.tv_tips_content);
        this.e = (TextView) view.findViewById(R.id.tv_tips_title);
        this.c.setFocusable(false);
        this.c.setOnClickListener(new a(this, 4));
        this.d.setFocusable(false);
        this.d.setOnClickListener(new i(this, 6));
        String str = this.g;
        if (!TextUtils.isEmpty(str)) {
            this.e.setVisibility(0);
            this.e.setText(str);
            this.f.setTextColor(Color.parseColor("#999999"));
        } else {
            this.e.setVisibility(8);
            this.f.setTextColor(getResources().getColor(17170444));
        }
        int i2 = this.j;
        if (i2 != 0) {
            this.f.setGravity(i2);
        }
        String str2 = this.h;
        if (!TextUtils.isEmpty(str2)) {
            this.f.setText(str2);
        }
        if (!TextUtils.isEmpty((CharSequence) null)) {
            this.c.setVisibility(0);
            this.c.setText((CharSequence) null);
        } else {
            this.c.setVisibility(8);
        }
        String str3 = this.i;
        if (!TextUtils.isEmpty(str3)) {
            this.d.setText(str3);
        }
    }

    public final int v0() {
        return R.layout.dialog_common_tips;
    }
}
