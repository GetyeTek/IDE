package com.huawei.digitalpayment.customer.baselib.mvp;

import A8.c;
import P2.a;
import V1.k;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public abstract class BaseMvpActivity<P extends c> extends BaseTitleActivity implements a {
    public P i;

    public void G0() {
        super.G0();
        this.i = U0();
    }

    public abstract P U0();

    public void onDestroy() {
        BaseMvpActivity.super.onDestroy();
        P p = this.i;
        if (p != null) {
            p.a = null;
            y9.a aVar = (y9.a) p.b;
            if (aVar != null) {
                aVar.dispose();
            }
        }
    }

    public void v(BaseResp baseResp) {
        if ("app.the_app_version_is_not_supported".equals(baseResp.getResponseCode())) {
            Yb.c.b().h(baseResp);
        } else {
            k.b(1, baseResp.getResponseDesc());
        }
    }
}
