package com.huawei.digitalpayment.customer.homev6.pop;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.digitalpayment.customer.homev6.R$color;
import com.huawei.digitalpayment.customer.homev6.R$layout;
import com.huawei.digitalpayment.customer.homev6.R$mipmap;
import com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemMenuPopBinding;
import com.huawei.digitalpayment.customer.homev6.databinding.Homev6MenuPopLayoutBinding;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import java.util.List;
import y5.b;

public final class e extends PopupWindow {
    public final FragmentActivity a;
    public final int b;

    public static class a extends BaseQuickAdapter<HomeFunction, BaseViewHolder> {
        public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
            HomeFunction homeFunction = (HomeFunction) obj;
            Homev6ItemMenuPopBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
            bind.b.setText(homeFunction.getFuncName());
            b.c(bind.a, homeFunction.getIcon(), R$mipmap.homev5_ic_function_default);
        }
    }

    public e(Activity activity, List list) {
        super(activity);
        this.b = list.size() * v.a(60.0f);
        this.a = a(activity);
        Homev6MenuPopLayoutBinding inflate = DataBindingUtil.inflate(LayoutInflater.from(activity), R$layout.homev6_menu_pop_layout, (ViewGroup) null, false);
        setContentView(inflate.getRoot());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(activity);
        RoundRecyclerView roundRecyclerView = inflate.a;
        roundRecyclerView.setLayoutManager(linearLayoutManager);
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.homev6_item_menu_pop, list);
        baseQuickAdapter.setOnItemClickListener(new d(this, baseQuickAdapter));
        roundRecyclerView.setAdapter(baseQuickAdapter);
        roundRecyclerView.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(activity, R$color.colorDividerLight), v.a(1.0f)));
    }

    public static FragmentActivity a(Context context) {
        if (context == null) {
            return null;
        }
        if (context instanceof FragmentActivity) {
            return (FragmentActivity) context;
        }
        if (context instanceof ContextWrapper) {
            return a(((ContextWrapper) context).getBaseContext());
        }
        return null;
    }

    public final void b() {
        setHeight(v.a(150.0f));
        setHeight(this.b);
        setBackgroundDrawable(new ColorDrawable(16777215));
        setFocusable(true);
        setOutsideTouchable(true);
        FragmentActivity fragmentActivity = this.a;
        if (fragmentActivity != null) {
            Window window = fragmentActivity.getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.alpha = 0.5f;
            window.addFlags(2);
            window.setAttributes(attributes);
        }
        setInputMethodMode(1);
        setSoftInputMode(16);
    }

    public final void dismiss() {
        super.dismiss();
        FragmentActivity fragmentActivity = this.a;
        if (fragmentActivity != null) {
            Window window = fragmentActivity.getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.alpha = 1.0f;
            window.addFlags(2);
            window.setAttributes(attributes);
        }
    }

    public final void showAsDropDown(View view) {
        b();
        super.showAsDropDown(view);
    }

    public final void showAtLocation(View view, int i, int i2, int i5) {
        b();
        super.showAtLocation(view, i, i2, i5);
    }
}
