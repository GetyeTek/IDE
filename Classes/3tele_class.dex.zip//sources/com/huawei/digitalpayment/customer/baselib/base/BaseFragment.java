package com.huawei.digitalpayment.customer.baselib.base;

import J2.a;
import Yb.c;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewbinding.ViewBinding;

public abstract class BaseFragment extends Fragment {
    public final boolean a = true;
    public boolean b = true;

    public void onCreate(@Nullable Bundle bundle) {
        BaseFragment.super.onCreate(bundle);
        if (getClass().isAnnotationPresent(a.class)) {
            c.b().j(this);
        }
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        return v0(layoutInflater).getRoot();
    }

    public void onDestroy() {
        BaseFragment.super.onDestroy();
        if (getClass().isAnnotationPresent(a.class)) {
            c.b().m(this);
        }
    }

    public void onResume() {
        BaseFragment.super.onResume();
        if (this.b && this.a) {
            this.b = false;
        }
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        BaseFragment.super.onViewCreated(view, bundle);
        x0(view);
        w0();
    }

    public abstract ViewBinding v0(LayoutInflater layoutInflater);

    public abstract void w0();

    public abstract void x0(View view);
}
