package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class DialogSelectBinding implements ViewBinding {
    @NonNull
    public final /* bridge */ /* synthetic */ View getRoot() {
        return null;
    }
}
