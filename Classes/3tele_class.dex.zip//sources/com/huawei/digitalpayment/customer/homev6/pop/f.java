package com.huawei.digitalpayment.customer.homev6.pop;

import android.view.View;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;

public final class f implements OnItemClickListener {
    public final /* synthetic */ TransactionTypeGroup a;
    public final /* synthetic */ TransactionTypeAdapter b;

    public f(TransactionTypeAdapter transactionTypeAdapter, TransactionTypeGroup transactionTypeGroup) {
        this.b = transactionTypeAdapter;
        this.a = transactionTypeGroup;
    }

    public final void onItemClick(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter, @NonNull View view, int i) {
        TransactionTypeGroup transactionTypeGroup = this.a;
        for (TransactionTypeBean check : transactionTypeGroup.getList()) {
            check.setCheck(false);
        }
        transactionTypeGroup.getList().get(i).setCheck(!transactionTypeGroup.getList().get(i).isCheck);
        this.b.notifyDataSetChanged();
    }
}
