package com.huawei.digitalpayment.customer.baselib.utils.language;

import java.util.List;

public class LanguageListBean {
    private List<LanguageBean> languageBeanList;

    public static class LanguageBean {
        private String countryIcon;
        private boolean isChecked;
        private String language;
        private String languageCode;

        public LanguageBean() {
        }

        public String getCountryIcon() {
            return this.countryIcon;
        }

        public String getLanguage() {
            return this.language;
        }

        public String getLanguageCode() {
            return this.languageCode;
        }

        public boolean isChecked() {
            return this.isChecked;
        }

        public void setChecked(boolean z) {
            this.isChecked = z;
        }

        public void setCountryIcon(String str) {
            this.countryIcon = str;
        }

        public void setLanguage(String str) {
            this.language = str;
        }

        public void setLanguageCode(String str) {
            this.languageCode = str;
        }

        public String toString() {
            return "LanguageBean{language='" + this.language + "', languageCode='" + this.languageCode + "', isChecked=" + this.isChecked + '}';
        }

        public LanguageBean(String str, boolean z) {
            this.language = str;
            this.isChecked = z;
        }

        public LanguageBean(String str, String str2, boolean z) {
            this.language = str;
            this.languageCode = str2;
            this.isChecked = z;
        }
    }

    public List<LanguageBean> getLanguageBeanList() {
        return this.languageBeanList;
    }

    public void setLanguageBeanList(List<LanguageBean> list) {
        this.languageBeanList = list;
    }
}
