package com.huawei.digitalpayment.customer.bean.homeconfig;

import java.io.Serializable;
import java.util.Map;

public class HomeFunctionDefine implements Serializable {
    private String clickNewDisappear;
    private String editEnable;
    private String editable;
    private String execute;
    private String execute2;
    private String funcId;
    private String funcName;
    private String groupId;
    private String guestGoPage;
    private boolean hideDivideLine;
    private String hotIcon;
    private String icon;
    private String iconSelected;
    private String introduce;
    private String iosHotIcon;
    private String iosIcon;
    private String iosIconSelected;
    private boolean ishidden = false;
    private int itemType;
    private String logo;
    private String marker;
    private String markerEndTime;
    private String markerStartTime;
    private String markerText;
    private String miniAppId;
    private String name;
    private String order = "";
    private Map<String, String> param;
    private String parentType;
    private String rating;
    private long recentUseTime;
    private String reportTag;
    private String showNewMarker;
    private String startTime;
    private String startTimeUTC = "";
    private String stopTime;
    private String stopTimeUTC = "";
    private String supportGroups;
    private String type;

    public String getClickNewDisappear() {
        return this.clickNewDisappear;
    }

    public String getEditEnable() {
        return this.editEnable;
    }

    public String getEditable() {
        return this.editable;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getExecute2() {
        return this.execute2;
    }

    public String getFuncId() {
        return this.funcId;
    }

    public String getFuncName() {
        return this.funcName;
    }

    public String getGroupId() {
        return this.groupId;
    }

    public String getGuestGoPage() {
        return this.guestGoPage;
    }

    public String getHotIcon() {
        return this.hotIcon;
    }

    public String getIcon() {
        return this.icon;
    }

    public String getIconSelected() {
        return this.iconSelected;
    }

    public String getIntroduce() {
        return this.introduce;
    }

    public String getIosHotIcon() {
        return this.iosHotIcon;
    }

    public String getIosIcon() {
        return this.iosIcon;
    }

    public String getIosIconSelected() {
        return this.iosIconSelected;
    }

    public int getItemType() {
        return this.itemType;
    }

    public String getLogo() {
        return this.logo;
    }

    public String getMarker() {
        return this.marker;
    }

    public String getMarkerEndTime() {
        return this.markerEndTime;
    }

    public String getMarkerStartTime() {
        return this.markerStartTime;
    }

    public String getMarkerText() {
        return this.markerText;
    }

    public String getMiniAppId() {
        return this.miniAppId;
    }

    public String getName() {
        return this.name;
    }

    public String getOrder() {
        String str = this.order;
        if (str == null) {
            return "9999";
        }
        return str;
    }

    public Map<String, String> getParam() {
        return this.param;
    }

    public String getParentType() {
        return this.parentType;
    }

    public String getRating() {
        return this.rating;
    }

    public long getRecentUseTime() {
        return this.recentUseTime;
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public String getShowNewMarker() {
        return this.showNewMarker;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public String getStartTimeUTC() {
        return this.startTimeUTC;
    }

    public String getStopTime() {
        return this.stopTime;
    }

    public String getStopTimeUTC() {
        return this.stopTimeUTC;
    }

    public String getSupportGroups() {
        return this.supportGroups;
    }

    public String getType() {
        return this.type;
    }

    public boolean isHideDivideLine() {
        return this.hideDivideLine;
    }

    public boolean isIshidden() {
        return this.ishidden;
    }

    public void setClickNewDisappear(String str) {
        this.clickNewDisappear = str;
    }

    public void setEditEnable(String str) {
        this.editEnable = str;
    }

    public void setEditable(String str) {
        this.editable = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setExecute2(String str) {
        this.execute2 = str;
    }

    public void setFuncId(String str) {
        this.funcId = str;
    }

    public void setFuncName(String str) {
        this.funcName = str;
    }

    public void setGroupId(String str) {
        this.groupId = str;
    }

    public void setGuestGoPage(String str) {
        this.guestGoPage = str;
    }

    public void setHideDivideLine(boolean z) {
        this.hideDivideLine = z;
    }

    public void setHotIcon(String str) {
        this.hotIcon = str;
    }

    public void setIcon(String str) {
        this.icon = str;
    }

    public void setIconSelected(String str) {
        this.iconSelected = str;
    }

    public void setIntroduce(String str) {
        this.introduce = str;
    }

    public void setIosHotIcon(String str) {
        this.iosHotIcon = str;
    }

    public void setIosIcon(String str) {
        this.iosIcon = str;
    }

    public void setIosIconSelected(String str) {
        this.iosIconSelected = str;
    }

    public void setIshidden(boolean z) {
        this.ishidden = z;
    }

    public void setItemType(int i) {
        this.itemType = i;
    }

    public void setLogo(String str) {
        this.logo = str;
    }

    public void setMarker(String str) {
        this.marker = str;
    }

    public void setMarkerEndTime(String str) {
        this.markerEndTime = str;
    }

    public void setMarkerStartTime(String str) {
        this.markerStartTime = str;
    }

    public void setMarkerText(String str) {
        this.markerText = str;
    }

    public void setMiniAppId(String str) {
        this.miniAppId = str;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setParam(Map<String, String> map) {
        this.param = map;
    }

    public void setParentType(String str) {
        this.parentType = str;
    }

    public void setRating(String str) {
        this.rating = str;
    }

    public void setRecentUseTime(long j) {
        this.recentUseTime = j;
    }

    public void setReportTag(String str) {
        this.reportTag = str;
    }

    public void setShowNewMarker(String str) {
        this.showNewMarker = str;
    }

    public void setStartTime(String str) {
        this.startTime = str;
    }

    public void setStartTimeUTC(String str) {
        this.startTimeUTC = str;
    }

    public void setStopTime(String str) {
        this.stopTime = str;
    }

    public void setStopTimeUTC(String str) {
        this.stopTimeUTC = str;
    }

    public void setSupportGroups(String str) {
        this.supportGroups = str;
    }

    public void setType(String str) {
        this.type = str;
    }
}
