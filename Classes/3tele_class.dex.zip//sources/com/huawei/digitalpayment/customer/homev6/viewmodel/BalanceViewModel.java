package com.huawei.digitalpayment.customer.homev6.viewmodel;

import C3.g;
import W2.n;
import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.blankj.utilcode.util.s;
import com.google.gson.JsonElement;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.homev6.model.HomeBalance;
import com.huawei.digitalpayment.customer.homev6.repository.BalanceRepository;
import com.huawei.digitalpayment.customer.homev6.repository.CreditPayBalanceRepository;
import java.util.List;

public class BalanceViewModel extends ViewModel {
    public final BalanceRepository a = new BalanceRepository();
    public final MutableLiveData<List<HomeBalance>> b = new MutableLiveData<>();
    public final MutableLiveData<HomeBalance> c = new MutableLiveData<>();
    public final MutableLiveData<BaseException> d = new MutableLiveData<>();
    public CreditPayBalanceRepository e;

    public class a implements R1.a<JsonElement> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            BalanceViewModel.this.c.setValue(BalanceViewModel.d());
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            JsonElement jsonElement = (JsonElement) obj;
            BalanceViewModel.this.c.setValue(BalanceViewModel.d());
        }
    }

    @NonNull
    public static HomeBalance d() {
        HomeBalance homeBalance = new HomeBalance();
        s a2 = s.a("homev5_cache");
        homeBalance.setAmountDisplay(a2.a.getString(g.a("creditPayBalance"), "--"));
        return homeBalance;
    }

    public final void a(HomeBalance homeBalance, boolean z) {
        if (homeBalance != null) {
            this.a.getClass();
            s a2 = s.a("homev5_nocache");
            a2.a.edit().putBoolean("hide_balance_" + homeBalance.getBalanceId(), z).apply();
            MutableLiveData<List<HomeBalance>> mutableLiveData = this.b;
            mutableLiveData.setValue((List) mutableLiveData.getValue());
            MutableLiveData<HomeBalance> mutableLiveData2 = this.c;
            mutableLiveData2.setValue((HomeBalance) mutableLiveData2.getValue());
        }
    }

    public final boolean b(HomeBalance homeBalance) {
        this.a.getClass();
        s a2 = s.a("homev5_nocache");
        return a2.a.getBoolean("hide_balance_" + homeBalance.getBalanceId(), true);
    }

    public final void c(boolean z) {
        this.c.setValue(d());
        if (z) {
            n.b("homev5_cache").i(g.a("creditPayBalance"));
            n.b("homev5_cache").i(g.a("creditPayBalanceUpdateTime"));
        }
        CreditPayBalanceRepository creditPayBalanceRepository = this.e;
        if (creditPayBalanceRepository != null) {
            creditPayBalanceRepository.cancel();
        }
        CreditPayBalanceRepository creditPayBalanceRepository2 = new CreditPayBalanceRepository();
        this.e = creditPayBalanceRepository2;
        creditPayBalanceRepository2.sendRequest(new a());
    }

    public final void onCleared() {
        BalanceViewModel.super.onCleared();
        CreditPayBalanceRepository creditPayBalanceRepository = this.e;
        if (creditPayBalanceRepository != null) {
            creditPayBalanceRepository.cancel();
        }
    }
}
