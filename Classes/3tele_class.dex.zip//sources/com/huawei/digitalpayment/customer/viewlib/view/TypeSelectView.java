package com.huawei.digitalpayment.customer.viewlib.view;

import D6.a;
import H6.c;
import H6.d;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.huawei.astp.macle.ui.w;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$mipmap;
import kotlin.jvm.internal.h;

public final class TypeSelectView extends CommonInputView {
    public static final /* synthetic */ int M = 0;
    public ImageView A;
    public ImageView B;
    public DisplayItem C;
    public DisplayItem H;
    public DisplayItem L;
    public TextView y;
    public TextView z;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public TypeSelectView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
        h.f(context, "context");
    }

    public final void c() {
        DisplayItem displayItem = this.C;
        String str = null;
        if (displayItem != null) {
            this.L = displayItem;
            EditText editText = getEditText();
            DisplayItem displayItem2 = this.L;
            if (displayItem2 != null) {
                str = displayItem2.getTitle();
            }
            editText.setText(str);
            this.A.setImageResource(R$mipmap.standard_checkbox_selected);
            this.B.setImageResource(R$mipmap.standard_checkbox_unselected);
            return;
        }
        h.m("leftItem");
        throw null;
    }

    public final void d() {
        DisplayItem displayItem = this.H;
        String str = null;
        if (displayItem != null) {
            this.L = displayItem;
            EditText editText = getEditText();
            DisplayItem displayItem2 = this.L;
            if (displayItem2 != null) {
                str = displayItem2.getTitle();
            }
            editText.setText(str);
            this.B.setImageResource(R$mipmap.standard_checkbox_selected);
            this.A.setImageResource(R$mipmap.standard_checkbox_unselected);
            return;
        }
        h.m("rightItem");
        throw null;
    }

    public final void e(DisplayItem displayItem, DisplayItem displayItem2) {
        this.y.setText(displayItem.getContent());
        this.z.setText(displayItem2.getContent());
        this.C = displayItem;
        this.H = displayItem2;
    }

    public final ImageView getIvLeft() {
        return this.A;
    }

    public final ImageView getIvRight() {
        return this.B;
    }

    public final DisplayItem getSelectItem() {
        return this.L;
    }

    public final TextView getTvLeft() {
        return this.y;
    }

    public final TextView getTvRight() {
        return this.z;
    }

    public final void setIvLeft(ImageView imageView) {
        h.f(imageView, "<set-?>");
        this.A = imageView;
    }

    public final void setIvRight(ImageView imageView) {
        h.f(imageView, "<set-?>");
        this.B = imageView;
    }

    public final void setTvLeft(TextView textView) {
        h.f(textView, "<set-?>");
        this.y = textView;
    }

    public final void setTvRight(TextView textView) {
        h.f(textView, "<set-?>");
        this.z = textView;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.view.View, java.lang.Object, com.huawei.digitalpayment.customer.viewlib.view.TypeSelectView] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TypeSelectView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        h.f(context, "context");
        View findViewById = findViewById(R$id.tvLeft);
        h.e(findViewById, "findViewById(...)");
        this.y = (TextView) findViewById;
        View findViewById2 = findViewById(R$id.tvRight);
        h.e(findViewById2, "findViewById(...)");
        this.z = (TextView) findViewById2;
        View findViewById3 = findViewById(R$id.ivLeft);
        h.e(findViewById3, "findViewById(...)");
        this.A = (ImageView) findViewById3;
        View findViewById4 = findViewById(R$id.ivRight);
        h.e(findViewById4, "findViewById(...)");
        this.B = (ImageView) findViewById4;
        this.y.setOnClickListener(new c(this, 5));
        this.A.setOnClickListener(new d(this, 2));
        this.z.setOnClickListener(new w(this, 4));
        this.B.setOnClickListener(new a(this, 8));
    }
}
