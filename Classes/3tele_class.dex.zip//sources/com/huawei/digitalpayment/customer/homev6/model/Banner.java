package com.huawei.digitalpayment.customer.homev6.model;

import java.io.Serializable;

public class Banner implements Serializable {
    private String content;
    private String delayTime;
    private String execute;
    private String imageUrl;
    private String order;
    private String reportTag;
    private String startTime;
    private String stopTime;

    public String getContent() {
        return this.content;
    }

    public String getDelayTime() {
        return this.delayTime;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public String getOrder() {
        return this.order;
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public String getStopTime() {
        return this.stopTime;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public void setDelayTime(String str) {
        this.delayTime = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setImageUrl(String str) {
        this.imageUrl = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setReportTag(String str) {
        this.reportTag = str;
    }

    public void setStartTime(String str) {
        this.startTime = str;
    }

    public void setStopTime(String str) {
        this.stopTime = str;
    }
}
