package com.huawei.digitalpayment.customer.bean.homeconfig;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomeConfig5 implements Serializable {
    private List<HomeDynamicMenu> dynamicMenu;
    private Map<String, HomeFunctionDefine> functionDefine;
    private List<HomeLifeFunction> lifeFunction;
    private List<MyGroupBean> myFunction;
    private List<HomeNavigation> navigation;
    private ArrayList<String> otherBankTransferShow;
    private List<HomePinFunctionBean> pinFunction;
    private List<HomePinFunctionBean> topFunction;

    public List<HomeDynamicMenu> getDynamicMenu() {
        return this.dynamicMenu;
    }

    public Map<String, HomeFunctionDefine> getFunctionDefine() {
        return this.functionDefine;
    }

    public List<HomeLifeFunction> getLifeFunction() {
        return this.lifeFunction;
    }

    public List<MyGroupBean> getMyFunction() {
        return this.myFunction;
    }

    public List<HomeNavigation> getNavigation() {
        return this.navigation;
    }

    public ArrayList<String> getOtherBankTransferShow() {
        return this.otherBankTransferShow;
    }

    public List<HomePinFunctionBean> getPinFunction() {
        return this.pinFunction;
    }

    public List<HomePinFunctionBean> getTopFunction() {
        return this.topFunction;
    }

    public void setDynamicMenu(List<HomeDynamicMenu> list) {
        this.dynamicMenu = list;
    }

    public void setFunctionDefine(Map<String, HomeFunctionDefine> map) {
        this.functionDefine = map;
    }

    public void setLifeFunction(List<HomeLifeFunction> list) {
        this.lifeFunction = list;
    }

    public void setMyFunction(List<MyGroupBean> list) {
        this.myFunction = list;
    }

    public void setNavigation(List<HomeNavigation> list) {
        this.navigation = list;
    }

    public void setOtherBankTransferShow(ArrayList<String> arrayList) {
        this.otherBankTransferShow = arrayList;
    }

    public void setPinFunction(List<HomePinFunctionBean> list) {
        this.pinFunction = list;
    }

    public void setTopFunction(List<HomePinFunctionBean> list) {
        this.topFunction = list;
    }
}
