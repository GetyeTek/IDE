package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

public class DividerItemDecoration extends RecyclerView.ItemDecoration {
    public static final int[] c = {16843284};
    public Drawable a;
    public final Rect b = new Rect();

    public DividerItemDecoration(FragmentActivity fragmentActivity) {
        TypedArray obtainStyledAttributes = fragmentActivity.obtainStyledAttributes(c);
        Drawable drawable = obtainStyledAttributes.getDrawable(0);
        this.a = drawable;
        if (drawable == null) {
            Log.w("DividerItem", "DividerItemDecoration. Please set that attribute all call setDrawable()");
        }
        obtainStyledAttributes.recycle();
    }

    public final void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        Drawable drawable = this.a;
        if (drawable == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(0, 0, drawable.getIntrinsicWidth(), 0);
        }
    }

    public final void onDraw(Canvas canvas, RecyclerView recyclerView, RecyclerView.State state) {
        int i;
        int i2;
        if (recyclerView.getLayoutManager() != null && this.a != null) {
            canvas.save();
            if (recyclerView.getClipToPadding()) {
                i = recyclerView.getPaddingTop();
                i2 = recyclerView.getHeight() - recyclerView.getPaddingBottom();
                canvas.clipRect(recyclerView.getPaddingLeft(), i, recyclerView.getWidth() - recyclerView.getPaddingRight(), i2);
            } else {
                i2 = recyclerView.getHeight();
                i = 0;
            }
            int childCount = recyclerView.getChildCount();
            for (int i5 = 0; i5 < childCount; i5++) {
                View childAt = recyclerView.getChildAt(i5);
                RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                Rect rect = this.b;
                layoutManager.getDecoratedBoundsWithMargins(childAt, rect);
                int round = Math.round(childAt.getTranslationX()) + rect.right;
                this.a.setBounds(round - this.a.getIntrinsicWidth(), i, round, i2);
                this.a.draw(canvas);
            }
            canvas.restore();
        }
    }
}
