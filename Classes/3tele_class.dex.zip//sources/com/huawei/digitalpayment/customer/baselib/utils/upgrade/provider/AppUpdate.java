package com.huawei.digitalpayment.customer.baselib.utils.upgrade.provider;

import android.os.Parcel;
import android.os.Parcelable;

public class AppUpdate implements Parcelable {
    private int forceUpdate;
    private String newVersionCode;
    private int updateCancelText;
    private String updateInfo;
    private int updateResourceId;
    private int updateTitle;

    public static class a {
        public String a;
        public String b;
        public int c;
        public int d;
        public int e;
        public int f;
    }

    public /* synthetic */ AppUpdate(a aVar, int i) {
        this(aVar);
    }

    public int describeContents() {
        return 0;
    }

    public int getForceUpdate() {
        return this.forceUpdate;
    }

    public String getNewVersionCode() {
        return this.newVersionCode;
    }

    public int getUpdateCancelText() {
        return this.updateCancelText;
    }

    public String getUpdateInfo() {
        return this.updateInfo;
    }

    public int getUpdateResourceId() {
        return this.updateResourceId;
    }

    public int getUpdateTitle() {
        return this.updateTitle;
    }

    public void writeToParcel(Parcel parcel, int i) {
    }

    private AppUpdate(a aVar) {
        this.forceUpdate = aVar.c;
        this.updateInfo = aVar.b;
        this.newVersionCode = aVar.a;
        this.updateResourceId = aVar.e;
        this.updateTitle = aVar.d;
        this.updateCancelText = aVar.f;
    }
}
