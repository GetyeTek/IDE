package com.huawei.digitalpayment.customer.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;

public class UpgradeDialog extends BaseDialog {
    public String c;
    public LoadingButton d;
    public String e;
    public View.OnClickListener f;

    public class a implements View.OnClickListener {
        public a() {
        }

        public final void onClick(View view) {
            UpgradeDialog.this.dismiss();
        }
    }

    public class b implements View.OnClickListener {
        public b() {
        }

        public final void onClick(View view) {
            UpgradeDialog upgradeDialog = UpgradeDialog.this;
            View.OnClickListener onClickListener = upgradeDialog.f;
            if (onClickListener != null) {
                onClickListener.onClick(view);
            }
            upgradeDialog.dismiss();
        }
    }

    public final void onStart() {
        Window window;
        UpgradeDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setLayout((BaseDialog.w0(window) * 8) / 10, -2);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        UpgradeDialog.super.onViewCreated(view, bundle);
        ((TextView) view.findViewById(R$id.tv_content)).setText(this.c);
        ((ImageView) view.findViewById(R$id.iv_close)).setOnClickListener(new a());
        LoadingButton findViewById = view.findViewById(R$id.lb_confirm);
        this.d = findViewById;
        findViewById.setText(this.e);
        this.d.setOnClickListener(new b());
    }

    public final int v0() {
        return R$layout.layout_upgrade_dialog;
    }
}
