package com.huawei.digitalpayment.customer.baselib.mvvm.data;

public enum Status {
    NONE,
    SUCCESS,
    ERROR,
    LOADING
}
