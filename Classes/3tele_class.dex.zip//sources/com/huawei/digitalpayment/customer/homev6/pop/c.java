package com.huawei.digitalpayment.customer.homev6.pop;

import H7.a;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import com.huawei.digitalpayment.customer.homev6.R$id;
import com.huawei.digitalpayment.customer.homev6.common.TransactionTypeEnum;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class c extends PopupWindow implements View.OnClickListener {
    public View a;
    public TransactionTypeFilterEvent b;
    public TransactionTypeAdapter c;
    public Map<String, Map<String, String>> d;

    public static String b(List list) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            TransactionTypeBean transactionTypeBean = (TransactionTypeBean) it.next();
            if (transactionTypeBean.isCheck) {
                return transactionTypeBean.getType();
            }
        }
        return "";
    }

    public final void a(TransactionTypeEnum transactionTypeEnum, ArrayList arrayList) {
        String str;
        String tradeType = transactionTypeEnum.getTradeType();
        Map<String, Map<String, String>> map = this.d;
        if (map.containsKey(tradeType)) {
            boolean equals = transactionTypeEnum.getTradeType().equals(TransactionTypeEnum.TRANSACTION_TYPE.getTradeType());
            TransactionTypeFilterEvent transactionTypeFilterEvent = this.b;
            if (equals) {
                str = transactionTypeFilterEvent.getTransactionType();
            } else if (transactionTypeEnum.getTradeType().equals(TransactionTypeEnum.ACCOUNT_TYPE.getTradeType())) {
                str = transactionTypeFilterEvent.getAccountType();
            } else if (transactionTypeEnum.getTradeType().equals(TransactionTypeEnum.ROLE_TYPE.getTradeType())) {
                str = transactionTypeFilterEvent.getOppositeParty();
            } else {
                str = "";
            }
            String[] d2 = a.d(map.get(transactionTypeEnum.getTradeType()));
            TransactionTypeGroup transactionTypeGroup = new TransactionTypeGroup();
            transactionTypeGroup.setGroupName(transactionTypeEnum.getName());
            transactionTypeGroup.setGroupId(transactionTypeEnum.getTradeType());
            transactionTypeGroup.setShow(true);
            ArrayList arrayList2 = new ArrayList();
            for (String str2 : d2) {
                TransactionTypeBean transactionTypeBean = new TransactionTypeBean(str2, str2);
                if (str.equals(str2)) {
                    transactionTypeBean.setCheck(true);
                } else {
                    transactionTypeBean.setCheck(false);
                }
                arrayList2.add(transactionTypeBean);
            }
            transactionTypeGroup.setList(arrayList2);
            arrayList.add(transactionTypeGroup);
        }
    }

    public final void dismiss() {
        super.dismiss();
        View view = this.a;
        if (view != null && view.getParent() != null) {
            ((ViewGroup) this.a.getParent()).removeView(this.a);
        }
    }

    public final void onClick(View view) {
        int id = view.getId();
        if (id == R$id.ll_content) {
            dismiss();
        } else if (id == R$id.btn_ok && !W2.a.a(1500, view)) {
            Iterator it = this.c.a.iterator();
            while (true) {
                boolean hasNext = it.hasNext();
                TransactionTypeFilterEvent transactionTypeFilterEvent = this.b;
                if (hasNext) {
                    TransactionTypeGroup transactionTypeGroup = (TransactionTypeGroup) it.next();
                    if (transactionTypeGroup.getGroupId().equals(TransactionTypeEnum.TRANSACTION_TYPE.getTradeType())) {
                        transactionTypeFilterEvent.setTransactionType(b(transactionTypeGroup.getList()));
                    }
                    if (transactionTypeGroup.getGroupId().equals(TransactionTypeEnum.ACCOUNT_TYPE.getTradeType())) {
                        transactionTypeFilterEvent.setAccountType(b(transactionTypeGroup.getList()));
                    }
                    if (transactionTypeGroup.getGroupId().equals(TransactionTypeEnum.ROLE_TYPE.getTradeType())) {
                        transactionTypeFilterEvent.setOppositeParty(b(transactionTypeGroup.getList()));
                    }
                } else {
                    Yb.c.b().e(transactionTypeFilterEvent);
                    dismiss();
                    return;
                }
            }
        }
    }
}
