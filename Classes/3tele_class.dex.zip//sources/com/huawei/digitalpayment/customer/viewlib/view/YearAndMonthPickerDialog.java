package com.huawei.digitalpayment.customer.viewlib.view;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.date.WheelPicker;
import com.huawei.common.widget.dialog.BottomDialog;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import q1.z;
import t4.l;
import t4.m;

public class YearAndMonthPickerDialog extends BottomDialog<ViewDataBinding> {
    public final Calendar d;
    public final Calendar e;
    public int f;
    public int g;
    public final String h;
    public final String i;
    public LoadingButton j;
    public WheelPicker k;
    public WheelPicker l;
    public z m;

    public YearAndMonthPickerDialog() {
        this((Calendar) null);
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        return layoutInflater.inflate(R$layout.common_dialog_date_year_month_picker, viewGroup, false);
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        YearAndMonthPickerDialog.super.onViewCreated(view, bundle);
        this.j = view.findViewById(R$id.btn_confirm);
        TextView textView = (TextView) view.findViewById(R$id.tv_title);
        this.k = view.findViewById(R$id.wheelyear);
        this.l = view.findViewById(R$id.wheelMonth);
        WheelPicker wheelPicker = this.k;
        if (wheelPicker != null) {
            wheelPicker.setTypeface((Typeface) null);
        }
        WheelPicker wheelPicker2 = this.l;
        if (wheelPicker2 != null) {
            wheelPicker2.setTypeface((Typeface) null);
        }
        WheelPicker wheelPicker3 = this.k;
        if (wheelPicker3 != null) {
            wheelPicker3.setSelectedTypeface((Typeface) null);
        }
        WheelPicker wheelPicker4 = this.l;
        if (wheelPicker4 != null) {
            wheelPicker4.setSelectedTypeface((Typeface) null);
        }
        LoadingButton loadingButton = this.j;
        if (loadingButton != null) {
            loadingButton.setOnClickListener(this.m);
        }
        ArrayList arrayList = new ArrayList();
        int i2 = this.d.get(1);
        int i5 = 0;
        for (int i6 = i2; i6 <= this.e.get(1); i6++) {
            if (i6 == this.f) {
                i5 = i6 - i2;
            }
            arrayList.add(String.format(Locale.ENGLISH, this.h, new Object[]{Integer.valueOf(i6)}));
        }
        WheelPicker wheelPicker5 = this.k;
        if (wheelPicker5 != null) {
            wheelPicker5.setData(arrayList);
            this.k.f(i5, false);
            this.k.setOnItemSelectedListener(new l(this, i2));
        }
        y0();
        x0();
    }

    public final int v0() {
        return R$layout.common_dialog_date_year_month_picker;
    }

    public final void x0() {
        Calendar calendar = this.d;
        int i2 = calendar.get(1);
        int i5 = calendar.get(2) + 1;
        if (this.f == i2 && this.g == i5) {
            calendar.get(5);
        }
        Calendar calendar2 = this.e;
        int i6 = calendar2.get(1);
        int i7 = calendar2.get(2) + 1;
        if (this.f == i6 && this.g == i7) {
            calendar2.get(5);
        } else {
            Calendar instance = Calendar.getInstance();
            instance.set(1, this.f);
            instance.set(2, this.g - 1);
            instance.set(5, 1);
            instance.roll(5, -1);
            instance.get(5);
        }
        new ArrayList();
    }

    public final void y0() {
        int i2;
        int i5;
        String str = this.i;
        Calendar calendar = this.d;
        if (this.f == calendar.get(1)) {
            i2 = calendar.get(2) + 1;
        } else {
            i2 = 1;
        }
        Calendar calendar2 = this.e;
        if (this.f == calendar2.get(1)) {
            i5 = calendar2.get(2) + 1;
        } else {
            i5 = 12;
        }
        ArrayList arrayList = new ArrayList();
        for (int i6 = i2; i6 <= i5; i6++) {
            arrayList.add(String.format(Locale.ENGLISH, str, new Object[]{Integer.valueOf(i6)}));
        }
        int i7 = this.g;
        Locale locale = Locale.ENGLISH;
        if (!arrayList.contains(String.format(locale, str, new Object[]{Integer.valueOf(i7)}))) {
            if (this.g < i2) {
                this.g = i2;
            } else {
                this.g = i5;
            }
        }
        int indexOf = arrayList.indexOf(String.format(locale, str, new Object[]{Integer.valueOf(this.g)}));
        WheelPicker wheelPicker = this.l;
        if (wheelPicker != null) {
            wheelPicker.setData(arrayList);
            this.l.f(indexOf, false);
            this.g = indexOf + i2;
            this.l.setOnItemSelectedListener(new m(this, i2));
        }
    }

    public YearAndMonthPickerDialog(Calendar calendar) {
        this.h = "%d";
        this.i = "%d";
        if (calendar == null) {
            calendar = Calendar.getInstance();
            calendar.setTimeInMillis(System.currentTimeMillis());
        }
        int i2 = calendar.get(1);
        Calendar instance = Calendar.getInstance();
        instance.set(1, i2 - 1000);
        calendar = calendar.compareTo(instance) < 0 ? instance : calendar;
        Calendar instance2 = Calendar.getInstance();
        instance2.set(1, i2 + 1000);
        calendar = calendar.compareTo(instance2) > 0 ? instance2 : calendar;
        this.d = instance;
        this.e = instance2;
        this.f = calendar.get(1);
        this.g = calendar.get(2) + 1;
    }
}
