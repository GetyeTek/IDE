package com.huawei.digitalpayment.customer.homev6.pop;

import java.io.Serializable;
import java.util.Calendar;

public class RecordFilterEvent implements Serializable {
    private Calendar endCalendar;
    private Calendar fromCalendar;

    public RecordFilterEvent(Calendar calendar, Calendar calendar2) {
        this.fromCalendar = calendar;
        this.endCalendar = calendar2;
    }

    public void clear() {
        this.fromCalendar = null;
        this.endCalendar = null;
    }

    public Calendar getEndCalendar() {
        return this.endCalendar;
    }

    public Calendar getFromCalendar() {
        return this.fromCalendar;
    }

    public void setEndCalendar(Calendar calendar) {
        this.endCalendar = calendar;
    }

    public void setFromCalendar(Calendar calendar) {
        this.fromCalendar = calendar;
    }
}
