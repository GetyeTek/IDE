package com.huawei.digitalpayment.customer.baselib.utils.upgrade;

import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public class UpdateBean extends BaseResp {
    private String description;
    private String downloadUrl;
    private long laterTime = 0;
    private String latestVersion;
    private String updateMode;

    public String getDescription() {
        return this.description;
    }

    public String getDownloadUrl() {
        return this.downloadUrl;
    }

    public long getLaterTime() {
        return this.laterTime;
    }

    public String getLatestVersion() {
        return this.latestVersion;
    }

    public String getUpdateMode() {
        return this.updateMode;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public void setDownloadUrl(String str) {
        this.downloadUrl = str;
    }

    public void setLaterTime(long j) {
        this.laterTime = j;
    }

    public void setLatestVersion(String str) {
        this.latestVersion = str;
    }

    public void setUpdateMode(String str) {
        this.updateMode = str;
    }
}
