package com.huawei.digitalpayment.customer.homev6.pop;

import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
    public int a;

    public final void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        int i = this.a;
        rect.left = i;
        rect.right = i;
        rect.bottom = i;
        rect.top = i;
    }
}
