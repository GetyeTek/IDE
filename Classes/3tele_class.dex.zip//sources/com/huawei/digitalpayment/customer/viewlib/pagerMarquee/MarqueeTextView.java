package com.huawei.digitalpayment.customer.viewlib.pagerMarquee;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;
import android.widget.Scroller;
import androidx.appcompat.widget.AppCompatTextView;
import com.huawei.digitalpayment.customer.baselib.R$styleable;

public class MarqueeTextView extends AppCompatTextView {
    public Scroller a;
    public int b;
    public int c = 0;
    public boolean d = true;
    public boolean e = true;
    public int f;
    public int g;

    public class a implements Runnable {
        public final /* synthetic */ int a;
        public final /* synthetic */ int b;

        public a(int i, int i2) {
            this.a = i;
            this.b = i2;
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [android.view.View, com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView] */
        public final void run() {
            ? r0 = MarqueeTextView.this;
            r0.a.startScroll(r0.c, 0, this.a, 0, this.b);
            r0.invalidate();
            r0.d = false;
        }
    }

    public MarqueeTextView(Context context) {
        super(context, (AttributeSet) null);
        a(context, (AttributeSet) null);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView] */
    public final void a(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.MarqueeTextView);
        this.b = obtainStyledAttributes.getInt(R$styleable.MarqueeTextView_scroll_interval, 10000);
        this.f = obtainStyledAttributes.getInt(R$styleable.MarqueeTextView_scroll_mode, 100);
        this.g = obtainStyledAttributes.getInt(R$styleable.MarqueeTextView_scroll_first_delay, 1000);
        obtainStyledAttributes.recycle();
        setEllipsize((TextUtils.TruncateAt) null);
        setSingleLine();
    }

    /* JADX WARNING: type inference failed for: r11v0, types: [androidx.appcompat.widget.AppCompatTextView, android.widget.TextView, android.view.View, com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView] */
    public final void b() {
        if (this.d) {
            setHorizontallyScrolling(true);
            if (this.a == null) {
                Scroller scroller = new Scroller(getContext(), new LinearInterpolator());
                this.a = scroller;
                setScroller(scroller);
            }
            TextPaint paint = getPaint();
            Rect rect = new Rect();
            String charSequence = getText().toString();
            paint.getTextBounds(charSequence, 0, charSequence.length(), rect);
            int width = rect.width();
            int i = width - this.c;
            int intValue = Double.valueOf((((double) (this.b * i)) * 1.0d) / ((double) width)).intValue();
            if (this.e) {
                new Handler(Looper.getMainLooper()).postDelayed(new a(i, intValue), (long) this.g);
                return;
            }
            this.a.startScroll(this.c, 0, i, 0, intValue);
            invalidate();
            this.d = false;
        }
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [android.widget.TextView, android.view.View, com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView] */
    public final void computeScroll() {
        MarqueeTextView.super.computeScroll();
        Scroller scroller = this.a;
        if (scroller == null || !scroller.isFinished() || this.d) {
            return;
        }
        if (this.f == 101) {
            Scroller scroller2 = this.a;
            if (scroller2 != null) {
                this.d = true;
                scroller2.startScroll(0, 0, 0, 0, 0);
                return;
            }
            return;
        }
        this.d = true;
        this.c = getWidth() * -1;
        this.e = false;
        b();
    }

    public int getRndDuration() {
        return this.b;
    }

    public int getScrollFirstDelay() {
        return this.g;
    }

    public int getmScrollMode() {
        return this.f;
    }

    public void setRndDuration(int i) {
        this.b = i;
    }

    public void setScrollFirstDelay(int i) {
        this.g = i;
    }

    public void setmScrollMode(int i) {
        this.f = i;
    }

    public MarqueeTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        a(context, attributeSet);
    }

    public MarqueeTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a(context, attributeSet);
    }
}
