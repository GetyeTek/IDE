package com.huawei.digitalpayment.customer.homev6.pop;

import java.io.Serializable;

public class TransactionTypeBean implements Serializable {
    boolean isCheck;
    String type;
    String typeName;

    public TransactionTypeBean() {
    }

    public String getType() {
        return this.type;
    }

    public String getTypeName() {
        return this.typeName;
    }

    public boolean isCheck() {
        return this.isCheck;
    }

    public void setCheck(boolean z) {
        this.isCheck = z;
    }

    public void setType(String str) {
        this.type = str;
    }

    public void setTypeName(String str) {
        this.typeName = str;
    }

    public TransactionTypeBean(String str, String str2) {
        this.type = str;
        this.typeName = str2;
    }
}
