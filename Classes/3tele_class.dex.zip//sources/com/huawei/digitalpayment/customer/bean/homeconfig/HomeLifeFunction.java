package com.huawei.digitalpayment.customer.bean.homeconfig;

import androidx.annotation.NonNull;
import java.io.Serializable;
import java.util.List;

public class HomeLifeFunction implements Serializable {
    private String clickDisappear;
    private String groupId;
    private String groupName;
    private String groupOrder;
    private boolean isExpand;
    private List<HomeFunctionDefine> list;
    private String marker;
    private String markerEndTime;
    private String markerStartTime;
    private String markerText;
    private String menuName;
    private String menuType;
    private String order;
    private String startTime;
    private String startTimeUTC = "";
    private String stopTime;
    private String stopTimeUTC = "";

    public static class LifeFuncItemBean implements Serializable, Cloneable, Comparable<LifeFuncItemBean> {
        private String execute;
        private String execute2;
        private String funcId;
        private String groupId;
        private boolean ishidden = false;
        private int itemType;
        private String logo;
        private String miniAppId;
        private String name;
        private String order;
        private String parentType;
        private String startTime;
        private String startTimeUTC = "";
        private String stopTime;
        private String stopTimeUTC = "";
        private String type;

        @NonNull
        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }

        public String getExecute() {
            return this.execute;
        }

        public String getExecute2() {
            return this.execute2;
        }

        public String getFuncId() {
            return this.funcId;
        }

        public String getGroupId() {
            return this.groupId;
        }

        public int getItemType() {
            return this.itemType;
        }

        public String getLogo() {
            return this.logo;
        }

        public String getMiniAppId() {
            return this.miniAppId;
        }

        public String getName() {
            return this.name;
        }

        public String getOrder() {
            return this.order;
        }

        public String getParentType() {
            return this.parentType;
        }

        public String getStartTime() {
            return this.startTime;
        }

        public String getStartTimeUTC() {
            return this.startTimeUTC;
        }

        public String getStopTime() {
            return this.stopTime;
        }

        public String getStopTimeUTC() {
            return this.stopTimeUTC;
        }

        public String getType() {
            return this.type;
        }

        public boolean isIshidden() {
            return this.ishidden;
        }

        public void setExecute(String str) {
            this.execute = str;
        }

        public void setExecute2(String str) {
            this.execute2 = str;
        }

        public void setFuncId(String str) {
            this.funcId = str;
        }

        public void setGroupId(String str) {
            this.groupId = str;
        }

        public void setIshidden(boolean z) {
            this.ishidden = z;
        }

        public void setItemType(int i) {
            this.itemType = i;
        }

        public void setLogo(String str) {
            this.logo = str;
        }

        public void setMiniAppId(String str) {
            this.miniAppId = str;
        }

        public void setName(String str) {
            this.name = str;
        }

        public void setOrder(String str) {
            this.order = str;
        }

        public void setParentType(String str) {
            this.parentType = str;
        }

        public void setStartTime(String str) {
            this.startTime = str;
        }

        public void setStartTimeUTC(String str) {
            this.startTimeUTC = str;
        }

        public void setStopTime(String str) {
            this.stopTime = str;
        }

        public void setStopTimeUTC(String str) {
            this.stopTimeUTC = str;
        }

        public void setType(String str) {
            this.type = str;
        }

        public int compareTo(LifeFuncItemBean lifeFuncItemBean) {
            String str = this.order;
            if (str == null) {
                return 1;
            }
            return str.compareTo(lifeFuncItemBean.getOrder());
        }
    }

    public String getClickDisappear() {
        return this.clickDisappear;
    }

    public String getGroupId() {
        return this.groupId;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public String getGroupOrder() {
        return this.groupOrder;
    }

    public List<HomeFunctionDefine> getList() {
        return this.list;
    }

    public String getMarker() {
        return this.marker;
    }

    public String getMarkerEndTime() {
        return this.markerEndTime;
    }

    public String getMarkerStartTime() {
        return this.markerStartTime;
    }

    public String getMarkerText() {
        return this.markerText;
    }

    public String getMenuName() {
        return this.menuName;
    }

    public String getMenuType() {
        return this.menuType;
    }

    public String getOrder() {
        return this.order;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public String getStartTimeUTC() {
        return this.startTimeUTC;
    }

    public String getStopTime() {
        return this.stopTime;
    }

    public String getStopTimeUTC() {
        return this.stopTimeUTC;
    }

    public boolean isExpand() {
        return this.isExpand;
    }

    public void setClickDisappear(String str) {
        this.clickDisappear = str;
    }

    public void setExpand(boolean z) {
        this.isExpand = z;
    }

    public void setGroupId(String str) {
        this.groupId = str;
    }

    public void setGroupName(String str) {
        this.groupName = str;
    }

    public void setGroupOrder(String str) {
        this.groupOrder = str;
    }

    public void setList(List<HomeFunctionDefine> list2) {
        this.list = list2;
    }

    public void setMarker(String str) {
        this.marker = str;
    }

    public void setMarkerEndTime(String str) {
        this.markerEndTime = str;
    }

    public void setMarkerStartTime(String str) {
        this.markerStartTime = str;
    }

    public void setMarkerText(String str) {
        this.markerText = str;
    }

    public void setMenuName(String str) {
        this.menuName = str;
    }

    public void setMenuType(String str) {
        this.menuType = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setStartTime(String str) {
        this.startTime = str;
    }

    public void setStartTimeUTC(String str) {
        this.startTimeUTC = str;
    }

    public void setStopTime(String str) {
        this.stopTime = str;
    }

    public void setStopTimeUTC(String str) {
        this.stopTimeUTC = str;
    }
}
