package com.huawei.digitalpayment.customer.homev6.base;

import V1.a;
import V1.h;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseHomeActivity extends AppCompatActivity {
    public BaseHomeActivity a;

    public void onCreate(@Nullable Bundle bundle) {
        BaseHomeActivity.super.onCreate(bundle);
        this.a = this;
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.digitalpayment.customer.homev6.base.BaseHomeActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity] */
    public final void setRequestedOrientation(int i) {
        if (Build.VERSION.SDK_INT != 26 || !a.a(this)) {
            BaseHomeActivity.super.setRequestedOrientation(i);
        } else {
            h.b();
        }
    }
}
