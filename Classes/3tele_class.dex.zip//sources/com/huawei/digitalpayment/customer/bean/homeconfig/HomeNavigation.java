package com.huawei.digitalpayment.customer.bean.homeconfig;

import java.io.Serializable;

public class HomeNavigation implements Serializable {
    private String funcId;
    private String order;
    private String startTime;
    private String startTimeUTC = "";
    private String stopTime;
    private String stopTimeUTC = "";

    public String getFuncId() {
        return this.funcId;
    }

    public String getOrder() {
        return this.order;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public String getStartTimeUTC() {
        return this.startTimeUTC;
    }

    public String getStopTime() {
        return this.stopTime;
    }

    public String getStopTimeUTC() {
        return this.stopTimeUTC;
    }

    public void setFuncId(String str) {
        this.funcId = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setStartTime(String str) {
        this.startTime = str;
    }

    public void setStartTimeUTC(String str) {
        this.startTimeUTC = str;
    }

    public void setStopTime(String str) {
        this.stopTime = str;
    }

    public void setStopTimeUTC(String str) {
        this.stopTimeUTC = str;
    }
}
