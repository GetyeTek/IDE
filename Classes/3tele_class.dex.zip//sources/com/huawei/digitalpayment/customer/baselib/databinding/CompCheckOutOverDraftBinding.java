package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class CompCheckOutOverDraftBinding implements ViewBinding {
    @NonNull
    public final View getRoot() {
        return null;
    }
}
