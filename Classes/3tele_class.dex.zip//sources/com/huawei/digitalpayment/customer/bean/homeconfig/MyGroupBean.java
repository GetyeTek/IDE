package com.huawei.digitalpayment.customer.bean.homeconfig;

import java.io.Serializable;
import java.util.List;

public class MyGroupBean implements Serializable {
    private String groupId;
    private String groupName;
    private String groupOrder;
    private List<HomePinFunctionBean> list;

    public String getGroupId() {
        return this.groupId;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public String getGroupOrder() {
        return this.groupOrder;
    }

    public List<HomePinFunctionBean> getList() {
        return this.list;
    }

    public void setGroupId(String str) {
        this.groupId = str;
    }

    public void setGroupName(String str) {
        this.groupName = str;
    }

    public void setGroupOrder(String str) {
        this.groupOrder = str;
    }

    public void setList(List<HomePinFunctionBean> list2) {
        this.list = list2;
    }

    public String toString() {
        return "MyGroupBean{, groupId='" + this.groupId + "', groupName='" + this.groupName + "', groupOrder='" + this.groupOrder + "', list=" + this.list + '}';
    }
}
