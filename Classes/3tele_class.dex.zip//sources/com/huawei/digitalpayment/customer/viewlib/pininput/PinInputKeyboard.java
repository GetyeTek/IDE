package com.huawei.digitalpayment.customer.viewlib.pininput;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBindings;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.R$string;

public class PinInputKeyboard extends ConstraintLayout implements View.OnClickListener {
    public a a;

    public interface a {
        void a(char c);

        void onDelete();
    }

    public PinInputKeyboard(@NonNull Context context) {
        super(context);
        a();
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.view.View$OnClickListener, android.view.View, com.huawei.digitalpayment.customer.viewlib.pininput.PinInputKeyboard, android.view.ViewGroup] */
    public final void a() {
        ConstraintLayout inflate = LayoutInflater.from(getContext()).inflate(R$layout.pin_input_keyboard, this, false);
        addView(inflate);
        int i = R$id.tv_input_0;
        if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
            i = R$id.tv_input_1;
            if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                i = R$id.tv_input_2;
                if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                    i = R$id.tv_input_3;
                    if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                        i = R$id.tv_input_4;
                        if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                            i = R$id.tv_input_5;
                            if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                i = R$id.tv_input_6;
                                if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                    i = R$id.tv_input_7;
                                    if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                        i = R$id.tv_input_8;
                                        if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                            i = R$id.tv_input_9;
                                            if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                                i = R$id.tv_input_back;
                                                if (((LinearLayout) ViewBindings.findChildViewById(inflate, i)) != null) {
                                                    i = R$id.tv_input_forget;
                                                    if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                                                        ConstraintLayout constraintLayout = inflate;
                                                        int childCount = constraintLayout.getChildCount();
                                                        for (int i2 = 0; i2 < childCount; i2++) {
                                                            constraintLayout.getChildAt(i2).setOnClickListener(this);
                                                        }
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.view.View, com.huawei.digitalpayment.customer.viewlib.pininput.PinInputKeyboard] */
    public final void onClick(View view) {
        a aVar;
        if (view instanceof LinearLayout) {
            a aVar2 = this.a;
            if (aVar2 != null) {
                aVar2.onDelete();
                return;
            }
            return;
        }
        CharSequence text = ((TextView) view).getText();
        if (!TextUtils.equals(getResources().getString(R$string.baselib_forget_pin), text) && (aVar = this.a) != null) {
            aVar.a(text.charAt(0));
        }
    }

    public void setOnInputListener(a aVar) {
        this.a = aVar;
    }

    public PinInputKeyboard(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        a();
    }

    public PinInputKeyboard(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a();
    }
}
