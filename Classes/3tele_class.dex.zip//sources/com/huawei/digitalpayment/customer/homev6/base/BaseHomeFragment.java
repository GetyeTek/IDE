package com.huawei.digitalpayment.customer.homev6.base;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

public class BaseHomeFragment extends Fragment {
    public FragmentActivity a;

    public final void onAttach(@NonNull Context context) {
        BaseHomeFragment.super.onAttach(context);
        this.a = (FragmentActivity) context;
    }
}
