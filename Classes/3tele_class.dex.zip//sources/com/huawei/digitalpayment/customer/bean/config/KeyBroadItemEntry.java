package com.huawei.digitalpayment.customer.bean.config;

import android.graphics.Color;
import android.text.TextUtils;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.google.gson.annotations.SerializedName;
import com.huawei.digitalpayment.customer.baselib.R$string;
import java.io.Serializable;

public class KeyBroadItemEntry implements MultiItemEntity, Serializable {
    @SerializedName("bgColor")
    private String bgColor = "#FFFFFF";
    @SerializedName("heightWeight")
    private int heightWeight = 1;
    @SerializedName("keyCode")
    private int keyCode = -1;
    @SerializedName("textColor")
    private String textColor = "#000000";
    @SerializedName("type")
    private int type;
    @SerializedName("value")
    private String value;
    @SerializedName("widthWeight")
    private int widthWeight = 1;

    public int getBgColor() {
        return Color.parseColor(this.bgColor);
    }

    public int getHeightWeight() {
        return this.heightWeight;
    }

    public int getItemType() {
        return this.type;
    }

    public int getKeyCode() {
        return this.keyCode;
    }

    public int getTextColor() {
        return Color.parseColor(this.textColor);
    }

    public int getType() {
        return this.type;
    }

    public String getValue() {
        if (TextUtils.equals("OK", this.value)) {
            return J.a().getString(R$string.designstandard_ok);
        }
        if (TextUtils.equals("Pay", this.value)) {
            return J.a().getString(R$string.designstandard_pay);
        }
        return this.value;
    }

    public int getWidthWeight() {
        return this.widthWeight;
    }

    public void setBgColor(String str) {
        this.bgColor = str;
    }

    public void setHeightWeight(int i) {
        this.heightWeight = i;
    }

    public void setKeyCode(int i) {
        this.keyCode = i;
    }

    public void setTextColor(String str) {
        this.textColor = str;
    }

    public void setType(int i) {
        this.type = i;
    }

    public void setValue(String str) {
        this.value = str;
    }

    public void setWidthWeight(int i) {
        this.widthWeight = i;
    }
}
