package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundLinearLayout;

public final class BaseNormalTextlinerBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final LinearLayout b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final RoundLinearLayout e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;

    public BaseNormalTextlinerBinding(@NonNull ConstraintLayout constraintLayout, @NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull RoundLinearLayout roundLinearLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = linearLayout;
        this.c = imageView;
        this.d = imageView2;
        this.e = roundLinearLayout;
        this.f = textView;
        this.g = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
