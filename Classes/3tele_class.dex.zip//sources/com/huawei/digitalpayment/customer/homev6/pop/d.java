package com.huawei.digitalpayment.customer.homev6.pop;

import C3.e;
import android.view.View;
import androidx.camera.core.p;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.cubeim.client.api.ConvCallback;
import com.huawei.cubeim.client.api.Conversation;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import com.huawei.digitalpayment.customer.homev6.pop.e;
import g1.i;
import kotlin.jvm.internal.h;

public final /* synthetic */ class d implements OnItemClickListener, ConvCallback {
    public final /* synthetic */ Object a;
    public final /* synthetic */ Object b;

    public /* synthetic */ d(Object obj, Object obj2) {
        this.a = obj;
        this.b = obj2;
    }

    public void callback(Exception exc, Conversation conversation) {
        i iVar = (i) this.b;
        h.f(iVar, "$callback");
        conversation.loadImage((String) this.a, new p(iVar));
    }

    public void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        ((e) this.a).dismiss();
        e.b((HomeFunction) ((e.a) this.b).getData().get(i));
    }
}
