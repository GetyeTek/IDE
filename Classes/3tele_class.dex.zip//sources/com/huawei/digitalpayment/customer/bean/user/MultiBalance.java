package com.huawei.digitalpayment.customer.bean.user;

import java.io.Serializable;

public class MultiBalance implements Serializable {
    String accountType;
    String accountTypeAlias;
    String accountTypeNameDisplay;
    String amount;
    String amountDisplay;
    String balanceId;
    String currency;
    String forward;
    String order;
    String unit;
    String unitType;

    public String getAccountType() {
        return this.accountType;
    }

    public String getAccountTypeAlias() {
        return this.accountTypeAlias;
    }

    public String getAccountTypeNameDisplay() {
        return this.accountTypeNameDisplay;
    }

    public String getAmount() {
        return this.amount;
    }

    public String getAmountDisplay() {
        return this.amountDisplay;
    }

    public String getBalanceId() {
        return this.balanceId;
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getForward() {
        return this.forward;
    }

    public String getOrder() {
        return this.order;
    }

    public String getUnit() {
        return this.unit;
    }

    public String getUnitType() {
        return this.unitType;
    }

    public void setAccountType(String str) {
        this.accountType = str;
    }

    public void setAccountTypeAlias(String str) {
        this.accountTypeAlias = str;
    }

    public void setAccountTypeNameDisplay(String str) {
        this.accountTypeNameDisplay = str;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setAmountDisplay(String str) {
        this.amountDisplay = str;
    }

    public void setBalanceId(String str) {
        this.balanceId = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setForward(String str) {
        this.forward = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setUnit(String str) {
        this.unit = str;
    }

    public void setUnitType(String str) {
        this.unitType = str;
    }
}
