package com.huawei.digitalpayment.customer.baselib.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class CommonDialogDateYearMonthPickerBinding extends ViewDataBinding {
}
