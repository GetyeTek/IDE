package com.huawei.digitalpayment.customer.bean.homeconfig;

import android.text.TextUtils;
import com.huawei.common.widget.banner.CycleViewPager;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class HomeDynamicMenu implements Serializable {
    private String backgroundImageUrl;
    private String backgroundRatio;
    private String execute;
    private String imageUrl;
    private List<DynamicItemBean> list;
    private String menuName;
    private String menuType;
    private String order;
    private String startTime;
    private String startTimeUTC = "";
    private String stopTime;
    private String stopTimeUTC = "";
    private String titleImageUrl;

    public static class DynamicItemBean implements CycleViewPager.b, Serializable {
        private String bulletin;
        private String content;
        private String delayTime;
        private String editEnable;
        private String execute;
        private String execute2;
        private String funcId = "";
        private String guestGoPage;
        private String imageUrl;
        private String imgUrl;
        private boolean isNeedHide = false;
        private String name;
        private String order;
        private Map<String, String> param;
        private String reportTag;
        private String showSeconds;
        private String startTime;
        private String startTimeUTC = "";
        private String stopTime;
        private String stopTimeUTC = "";
        private String time;
        private String title;
        private String url;

        public String getBulletin() {
            return this.bulletin;
        }

        public String getContent() {
            if (TextUtils.isEmpty(this.content)) {
                this.content = getBulletin();
            }
            return this.content;
        }

        public String getDelayTime() {
            if (TextUtils.isEmpty(this.delayTime)) {
                this.delayTime = getShowSeconds();
            }
            return this.delayTime;
        }

        public String getEditEnable() {
            return this.editEnable;
        }

        public String getExecute() {
            return this.execute;
        }

        public String getExecute2() {
            return this.execute2;
        }

        public String getFuncId() {
            return this.funcId;
        }

        public String getGuestGoPage() {
            return this.guestGoPage;
        }

        public String getImageUrl() {
            if (TextUtils.isEmpty(this.imageUrl)) {
                this.imageUrl = getImgUrl();
            }
            return this.imageUrl;
        }

        public String getImgUrl() {
            return this.imgUrl;
        }

        public String getName() {
            return this.name;
        }

        public String getOrder() {
            return this.order;
        }

        public Map<String, String> getParam() {
            return this.param;
        }

        public String getReportTag() {
            return this.reportTag;
        }

        public String getShowSeconds() {
            return this.showSeconds;
        }

        public String getStartTime() {
            return this.startTime;
        }

        public String getStartTimeUTC() {
            return this.startTimeUTC;
        }

        public String getStopTime() {
            return this.stopTime;
        }

        public String getStopTimeUTC() {
            return this.stopTimeUTC;
        }

        public String getTime() {
            return this.time;
        }

        public String getTitle() {
            return this.title;
        }

        public String getUrl() {
            return this.url;
        }

        public boolean isNeedHide() {
            return this.isNeedHide;
        }

        public void setBulletin(String str) {
            this.bulletin = str;
        }

        public void setContent(String str) {
            this.content = str;
        }

        public void setDelayTime(String str) {
            this.delayTime = str;
        }

        public void setEditEnable(String str) {
            this.editEnable = str;
        }

        public void setExecute(String str) {
            this.execute = str;
        }

        public void setExecute2(String str) {
            this.execute2 = str;
        }

        public void setFuncId(String str) {
            this.funcId = str;
        }

        public void setGuestGoPage(String str) {
            this.guestGoPage = str;
        }

        public void setImageUrl(String str) {
            this.imageUrl = str;
        }

        public void setImgUrl(String str) {
            this.imgUrl = str;
        }

        public void setName(String str) {
            this.name = str;
        }

        public void setNeedHide(boolean z) {
            this.isNeedHide = z;
        }

        public void setOrder(String str) {
            this.order = str;
        }

        public void setParam(Map<String, String> map) {
            this.param = map;
        }

        public void setReportTag(String str) {
            this.reportTag = str;
        }

        public void setShowSeconds(String str) {
            this.showSeconds = str;
        }

        public void setStartTime(String str) {
            this.startTime = str;
        }

        public void setStartTimeUTC(String str) {
            this.startTimeUTC = str;
        }

        public void setStopTime(String str) {
            this.stopTime = str;
        }

        public void setStopTimeUTC(String str) {
            this.stopTimeUTC = str;
        }

        public void setTime(String str) {
            this.time = str;
        }

        public void setTitle(String str) {
            this.title = str;
        }

        public void setUrl(String str) {
            this.url = str;
        }
    }

    public String getBackgroundImageUrl() {
        return this.backgroundImageUrl;
    }

    public String getBackgroundRatio() {
        return this.backgroundRatio;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public List<DynamicItemBean> getList() {
        return this.list;
    }

    public String getMenuName() {
        return this.menuName;
    }

    public String getMenuType() {
        return this.menuType;
    }

    public String getOrder() {
        return this.order;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public String getStartTimeUTC() {
        return this.startTimeUTC;
    }

    public String getStopTime() {
        return this.stopTime;
    }

    public String getStopTimeUTC() {
        return this.stopTimeUTC;
    }

    public String getTitleImageUrl() {
        return this.titleImageUrl;
    }

    public void setBackgroundImageUrl(String str) {
        this.backgroundImageUrl = str;
    }

    public void setBackgroundRatio(String str) {
        this.backgroundRatio = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setImageUrl(String str) {
        this.imageUrl = str;
    }

    public void setList(List<DynamicItemBean> list2) {
        this.list = list2;
    }

    public void setMenuName(String str) {
        this.menuName = str;
    }

    public void setMenuType(String str) {
        this.menuType = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setStartTime(String str) {
        this.startTime = str;
    }

    public void setStartTimeUTC(String str) {
        this.startTimeUTC = str;
    }

    public void setStopTime(String str) {
        this.stopTime = str;
    }

    public void setStopTimeUTC(String str) {
        this.stopTimeUTC = str;
    }

    public void setTitleImageUrl(String str) {
        this.titleImageUrl = str;
    }
}
