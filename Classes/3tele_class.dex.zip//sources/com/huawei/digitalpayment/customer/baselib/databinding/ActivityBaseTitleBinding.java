package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;

public final class ActivityBaseTitleBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final FrameLayout b;

    public ActivityBaseTitleBinding(@NonNull LinearLayout linearLayout, @NonNull FrameLayout frameLayout) {
        this.a = linearLayout;
        this.b = frameLayout;
    }

    @NonNull
    public static ActivityBaseTitleBinding a(@NonNull LayoutInflater layoutInflater) {
        View inflate = layoutInflater.inflate(R$layout.activity_base_title, (ViewGroup) null, false);
        int i = R$id.base_container;
        FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(inflate, i);
        if (frameLayout != null) {
            return new ActivityBaseTitleBinding((LinearLayout) inflate, frameLayout);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
