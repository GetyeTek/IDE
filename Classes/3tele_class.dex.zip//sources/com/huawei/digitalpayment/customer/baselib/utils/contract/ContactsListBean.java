package com.huawei.digitalpayment.customer.baselib.utils.contract;

import java.io.Serializable;
import java.util.List;

public class ContactsListBean implements Serializable {
    private List<ContactsBean> list;

    public List<ContactsBean> getList() {
        return this.list;
    }

    public void setList(List<ContactsBean> list2) {
        this.list = list2;
    }
}
