package com.huawei.digitalpayment.customer.baselib.utils.exception;

public class PhoneNumberException extends RuntimeException {
    public PhoneNumberException() {
    }

    public PhoneNumberException(String str) {
        super(str);
    }
}
