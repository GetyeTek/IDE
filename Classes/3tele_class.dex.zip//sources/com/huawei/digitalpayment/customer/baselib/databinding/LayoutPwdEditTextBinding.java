package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundLinearLayout;

public final class LayoutPwdEditTextBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final EditText b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final RoundLinearLayout d;

    public LayoutPwdEditTextBinding(@NonNull ConstraintLayout constraintLayout, @NonNull EditText editText, @NonNull ImageView imageView, @NonNull RoundLinearLayout roundLinearLayout) {
        this.a = constraintLayout;
        this.b = editText;
        this.c = imageView;
        this.d = roundLinearLayout;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
