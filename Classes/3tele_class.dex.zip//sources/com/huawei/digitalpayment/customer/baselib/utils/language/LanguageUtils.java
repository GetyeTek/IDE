package com.huawei.digitalpayment.customer.baselib.utils.language;

import E2.a;
import V1.h;
import W2.n;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import com.blankj.utilcode.util.J;
import com.huawei.digitalpayment.customer.baselib.R$string;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageListBean;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class LanguageUtils {
    private static LanguageUtils mInstance = new LanguageUtils();
    private String languageCode;
    private final List<LanguageListBean.LanguageBean> languageConfig = new ArrayList();

    private LanguageUtils() {
    }

    public static LanguageUtils getInstance() {
        return mInstance;
    }

    private void init() {
        String string = J.a().getString(R$string.baselib_baseenglish);
        String string2 = J.a().getString(R$string.baselib_baseamharic);
        String string3 = J.a().getString(R$string.afaan_oromoo);
        String string4 = J.a().getString(R$string.baselib_basetigirigina);
        String string5 = J.a().getString(R$string.baselib_basesomali);
        LanguageListBean.LanguageBean languageBean = new LanguageListBean.LanguageBean();
        LanguageListBean.LanguageBean languageBean2 = new LanguageListBean.LanguageBean();
        LanguageListBean.LanguageBean languageBean3 = new LanguageListBean.LanguageBean();
        LanguageListBean.LanguageBean languageBean4 = new LanguageListBean.LanguageBean();
        LanguageListBean.LanguageBean languageBean5 = new LanguageListBean.LanguageBean();
        languageBean.setLanguage(string);
        languageBean2.setLanguage(string4);
        languageBean3.setLanguage(string5);
        languageBean4.setLanguage(string3);
        languageBean5.setLanguage(string2);
        languageBean.setLanguageCode(LanguageConstants.EN);
        languageBean2.setLanguageCode(LanguageConstants.TI);
        languageBean3.setLanguageCode(LanguageConstants.SO);
        languageBean4.setLanguageCode(LanguageConstants.OM);
        languageBean5.setLanguageCode(LanguageConstants.AM);
        this.languageConfig.clear();
        this.languageConfig.add(languageBean);
        this.languageConfig.add(languageBean5);
        this.languageConfig.add(languageBean4);
        this.languageConfig.add(languageBean2);
        this.languageConfig.add(languageBean3);
    }

    public String getCountry() {
        return a.a().a.getResources().getConfiguration().locale.getCountry();
    }

    public String getCurrentLang() {
        if (TextUtils.isEmpty(this.languageCode)) {
            this.languageCode = n.b("").a.getString(LanguageConstants.LANGUAGE_CODE, LanguageConstants.EN);
        }
        h.b();
        return this.languageCode;
    }

    public String getCurrentShowLang() {
        n b = n.b("");
        return b.a.getString(LanguageConstants.LANGUAGE, J.a().getString(R$string.baselib_english));
    }

    public List<LanguageListBean.LanguageBean> getLanguageConfig() {
        init();
        return this.languageConfig;
    }

    public Locale getLanguageLocale(String str) {
        if (TextUtils.isEmpty(str)) {
            return Locale.ENGLISH;
        }
        return new Locale(str.split("_")[0], "");
    }

    public String getType() {
        return a.a().a.getResources().getConfiguration().locale.getLanguage();
    }

    public void setLanguage(Context context, String str) {
        Resources resources = context.getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        configuration.setLocale(getLanguageLocale(str));
        if (Build.VERSION.SDK_INT > 24) {
            context.getApplicationContext().createConfigurationContext(configuration).createConfigurationContext(configuration);
        }
        resources.updateConfiguration(configuration, displayMetrics);
        this.languageCode = str;
        n.b("").g(LanguageConstants.LANGUAGE_CODE, str, false);
        getInstance().updateCurLanguage();
    }

    public void updateCurLanguage() {
        init();
        String string = J.a().getString(R$string.baselib_english);
        Iterator<LanguageListBean.LanguageBean> it = this.languageConfig.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            LanguageListBean.LanguageBean next = it.next();
            if (TextUtils.equals(getCurrentLang(), next.getLanguageCode())) {
                string = next.getLanguage();
                break;
            }
        }
        n.b("").g(LanguageConstants.LANGUAGE, string, false);
    }
}
