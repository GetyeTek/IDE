package com.huawei.digitalpayment.customer.homev6.pop;

import android.annotation.SuppressLint;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.homev6.R$color;
import com.huawei.digitalpayment.customer.homev6.R$id;
import com.huawei.digitalpayment.customer.homev6.R$mipmap;

public class TransactionTypeChildAdapter extends BaseQuickAdapter<TransactionTypeBean, BaseViewHolder> {
    @SuppressLint({"ResourceAsColor", "ResourceType"})
    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        TransactionTypeBean transactionTypeBean = (TransactionTypeBean) obj;
        int i = R$id.tvFunctionName;
        baseViewHolder.setText(i, transactionTypeBean.getTypeName());
        if (transactionTypeBean.isCheck) {
            baseViewHolder.setBackgroundResource(i, R$mipmap.icon_type_select);
            baseViewHolder.setTextColor(i, ContextCompat.getColor(getContext(), R$color.type_select_color));
            return;
        }
        baseViewHolder.setBackgroundResource(i, R$mipmap.icon_type_unselect);
        baseViewHolder.setTextColor(i, ContextCompat.getColor(getContext(), R$color.type_unselect_color));
    }
}
