package com.huawei.digitalpayment.customer.baselib;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.date.WheelPicker;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseActivityAbstractPinBinding;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseActivityAbstractPinBindingImpl;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseDialogScheduleDatePickerBinding;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseDialogScheduleDatePickerBindingImpl;
import com.huawei.digitalpayment.customer.baselib.databinding.CommonDialogDateYearMonthPickerBindingImpl;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputKeyboard;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(3);
            a = hashMap;
            hashMap.put("layout/base_activity_abstract_pin_0", Integer.valueOf(R$layout.base_activity_abstract_pin));
            hashMap.put("layout/base_dialog_schedule_date_picker_0", Integer.valueOf(R$layout.base_dialog_schedule_date_picker));
            hashMap.put("layout/common_dialog_date_year_month_picker_0", Integer.valueOf(R$layout.common_dialog_date_year_month_picker));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(3);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.base_activity_abstract_pin, 1);
        sparseIntArray.put(R$layout.base_dialog_schedule_date_picker, 2);
        sparseIntArray.put(R$layout.common_dialog_date_year_month_picker, 3);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(6);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new RuntimeException("view must have a tag");
            } else if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 == 3) {
                        if ("layout/common_dialog_date_year_month_picker_0".equals(tag)) {
                            Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 7, (ViewDataBinding.IncludedLayouts) null, CommonDialogDateYearMonthPickerBindingImpl.b);
                            LoadingButton loadingButton = (LoadingButton) mapBindings[6];
                            RoundTextView roundTextView = (RoundTextView) mapBindings[1];
                            LinearLayout linearLayout = (LinearLayout) mapBindings[3];
                            TextView textView = (TextView) mapBindings[2];
                            WheelPicker wheelPicker = (WheelPicker) mapBindings[5];
                            WheelPicker wheelPicker2 = (WheelPicker) mapBindings[4];
                            ViewDataBinding viewDataBinding = new ViewDataBinding(dataBindingComponent2, view2, 0);
                            viewDataBinding.a = -1;
                            ((RoundConstraintLayout) mapBindings[0]).setTag((Object) null);
                            viewDataBinding.setRootTag(view2);
                            viewDataBinding.invalidateAll();
                            return viewDataBinding;
                        }
                        throw new IllegalArgumentException(l.a(tag, "The tag for common_dialog_date_year_month_picker is invalid. Received: "));
                    }
                } else if ("layout/base_dialog_schedule_date_picker_0".equals(tag)) {
                    Object[] mapBindings2 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 9, (ViewDataBinding.IncludedLayouts) null, BaseDialogScheduleDatePickerBindingImpl.f);
                    RoundTextView roundTextView2 = (RoundTextView) mapBindings2[1];
                    LinearLayout linearLayout2 = (LinearLayout) mapBindings2[4];
                    LinearLayout linearLayout3 = (LinearLayout) mapBindings2[3];
                    TextView textView2 = (TextView) mapBindings2[2];
                    BaseDialogScheduleDatePickerBinding baseDialogScheduleDatePickerBinding = new BaseDialogScheduleDatePickerBinding(dataBindingComponent, view, (LoadingButton) mapBindings2[8], (WheelPicker) mapBindings2[5], (WheelPicker) mapBindings2[6], (WheelPicker) mapBindings2[7]);
                    baseDialogScheduleDatePickerBinding.e = -1;
                    ((RoundConstraintLayout) mapBindings2[0]).setTag("layout/common_dialog_date_picker_0");
                    baseDialogScheduleDatePickerBinding.setRootTag(view2);
                    baseDialogScheduleDatePickerBinding.invalidateAll();
                    return baseDialogScheduleDatePickerBinding;
                } else {
                    throw new IllegalArgumentException(l.a(tag, "The tag for base_dialog_schedule_date_picker is invalid. Received: "));
                }
            } else if ("layout/base_activity_abstract_pin_0".equals(tag)) {
                Object[] mapBindings3 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 7, (ViewDataBinding.IncludedLayouts) null, BaseActivityAbstractPinBindingImpl.g);
                TextView textView3 = (TextView) mapBindings3[3];
                BaseActivityAbstractPinBinding baseActivityAbstractPinBinding = new BaseActivityAbstractPinBinding(dataBindingComponent, view, (ImageView) mapBindings3[2], (PinInputKeyboard) mapBindings3[1], (PinInputView) mapBindings3[4], (TextView) mapBindings3[6], (TextView) mapBindings3[5]);
                baseActivityAbstractPinBinding.f = -1;
                ((ConstraintLayout) mapBindings3[0]).setTag((Object) null);
                baseActivityAbstractPinBinding.setRootTag(view2);
                baseActivityAbstractPinBinding.invalidateAll();
                return baseActivityAbstractPinBinding;
            } else {
                throw new IllegalArgumentException(l.a(tag, "The tag for base_activity_abstract_pin is invalid. Received: "));
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
