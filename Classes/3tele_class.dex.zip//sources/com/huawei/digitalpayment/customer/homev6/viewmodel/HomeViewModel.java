package com.huawei.digitalpayment.customer.homev6.viewmodel;

import B7.e;
import V7.c;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import com.blankj.utilcode.util.J;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.homev6.model.FunctionGroup;
import com.huawei.digitalpayment.customer.homev6.model.GroupReceivePocketMoneyResp;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import com.huawei.digitalpayment.customer.homev6.model.UserBean;
import com.huawei.digitalpayment.customer.homev6.repository.HomeBasicConfigRepository;
import com.huawei.digitalpayment.customer.homev6.repository.PocketMoneyRepository;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import u3.C0067a;
import u3.b;

public class HomeViewModel extends BaseViewModel {
    public static HomeViewModel v;
    public final MutableLiveData<List<HomeFunction>> g = new MutableLiveData<>();
    public final MutableLiveData<List<HomeFunction>> h = new MutableLiveData<>();
    public final MutableLiveData<List<FunctionGroup>> i = new MutableLiveData<>();
    public final MutableLiveData<List<FunctionGroup>> j = new MutableLiveData<>();
    public final MutableLiveData<List<FunctionGroup>> k = new MutableLiveData<>(new ArrayList());
    public final MutableLiveData<List<FunctionGroup>> l = new MutableLiveData<>(new ArrayList());
    public final MutableLiveData<BaseException> m = new MutableLiveData<>(new BaseException(""));
    public final MutableLiveData<UserBean> n = new MutableLiveData<>();
    public final MutableLiveData<Map<String, HomeFunction>> o = new MutableLiveData<>();
    public final MutableLiveData<c<GroupReceivePocketMoneyResp>> p = new MutableLiveData<>();
    public final b q = new b();
    public HomeBasicConfigRepository r;
    public final e s = new e();
    public PocketMoneyRepository t;
    public GroupReceivePocketMoneyResp u;

    public static synchronized HomeViewModel e() {
        HomeViewModel homeViewModel;
        synchronized (HomeViewModel.class) {
            try {
                if (v == null) {
                    v = new ViewModelProvider.AndroidViewModelFactory(J.a()).create(HomeViewModel.class);
                }
                homeViewModel = v;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        return homeViewModel;
    }

    public static boolean f(GroupReceivePocketMoneyResp groupReceivePocketMoneyResp, List list) {
        if (list == null || list.isEmpty()) {
            return false;
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Iterator<HomeFunction> it2 = ((FunctionGroup) it.next()).getList().iterator();
            while (true) {
                if (it2.hasNext()) {
                    HomeFunction next = it2.next();
                    if (groupReceivePocketMoneyResp.getFunctionId().equals(next.getFuncId())) {
                        int waiteReceiveNum = groupReceivePocketMoneyResp.getWaiteReceiveNum();
                        String num = Integer.toString(waiteReceiveNum);
                        if (waiteReceiveNum >= 99) {
                            num = "99+";
                        }
                        if (waiteReceiveNum <= 0) {
                            num = "";
                        }
                        next.setMarker(num);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static void h(GroupReceivePocketMoneyResp groupReceivePocketMoneyResp, List list, List list2, List list3) {
        if (groupReceivePocketMoneyResp != null && !TextUtils.isEmpty(groupReceivePocketMoneyResp.getFunctionId())) {
            if (f(groupReceivePocketMoneyResp, list)) {
                groupReceivePocketMoneyResp.setFragmentFlag(0);
            } else if (f(groupReceivePocketMoneyResp, list2)) {
                groupReceivePocketMoneyResp.setFragmentFlag(1);
            } else if (f(groupReceivePocketMoneyResp, list3)) {
                groupReceivePocketMoneyResp.setFragmentFlag(2);
            } else {
                groupReceivePocketMoneyResp.setFragmentFlag(-1);
            }
        }
    }

    public final void d(ArrayList arrayList, List list) {
        if (list != null && !list.isEmpty()) {
            b bVar = this.q;
            List unmodifiableList = Collections.unmodifiableList(bVar.a);
            List unmodifiableList2 = Collections.unmodifiableList(bVar.b);
            List unmodifiableList3 = Collections.unmodifiableList(bVar.c);
            Iterator it = list.iterator();
            while (it.hasNext()) {
                FunctionGroup functionGroup = (FunctionGroup) it.next();
                if ("banner".equals(functionGroup.getMenuType()) && unmodifiableList != null && !unmodifiableList.isEmpty()) {
                    functionGroup.setList(unmodifiableList);
                }
                if ("appsBanner".equals(functionGroup.getGroupId()) && unmodifiableList2 != null && !unmodifiableList2.isEmpty()) {
                    functionGroup.setList(unmodifiableList2);
                }
                if ("lifeBanner".equals(functionGroup.getGroupId()) && unmodifiableList3 != null && !unmodifiableList3.isEmpty()) {
                    functionGroup.setList(unmodifiableList3);
                }
                arrayList.add(functionGroup);
            }
        }
    }

    public final void g(String str) {
        D3.c cVar = new D3.c(this, str);
        b bVar = this.q;
        bVar.getClass();
        BannerRepository bannerRepository = new BannerRepository("Navigation Page", str);
        bannerRepository.a = false;
        bannerRepository.sendRequest(new C0067a(bVar, str, cVar));
    }

    public final void onCleared() {
        super.onCleared();
        HomeBasicConfigRepository homeBasicConfigRepository = this.r;
        if (homeBasicConfigRepository != null) {
            homeBasicConfigRepository.cancel();
        }
        PocketMoneyRepository pocketMoneyRepository = this.t;
        if (pocketMoneyRepository != null) {
            pocketMoneyRepository.cancel();
        }
    }
}
