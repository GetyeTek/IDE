package com.huawei.digitalpayment.customer.viewlib.view;

import W2.k;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.blankj.utilcode.util.t;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$mipmap;
import com.huawei.digitalpayment.customer.baselib.R$raw;
import com.huawei.digitalpayment.customer.bean.config.KeyBroadItemEntry;
import java.util.List;

public class DigitalVirtualKeyboardView extends RelativeLayout {
    public static List<KeyBroadItemEntry> a;

    public static class KeyBroadAdapter extends BaseMultiItemQuickAdapter<KeyBroadItemEntry, BaseViewHolder> {
        public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
            KeyBroadItemEntry keyBroadItemEntry = (KeyBroadItemEntry) obj;
            int itemType = keyBroadItemEntry.getItemType();
            if (itemType == 0) {
                baseViewHolder.setText(R$id.tv_degit_content, keyBroadItemEntry.getValue());
                DigitalVirtualKeyboardView.a((t.b() - 40) / 4, baseViewHolder.itemView);
            } else if (itemType == 1) {
                baseViewHolder.setImageResource(R$id.iv_del_content, R$mipmap.icon_delete_digital);
                DigitalVirtualKeyboardView.a((t.b() - 40) / 4, baseViewHolder.itemView);
            } else if (itemType == 2) {
                int i = R$id.tv_ok_content;
                baseViewHolder.setText(i, (CharSequence) null);
                t.b();
                TextView textView = (TextView) baseViewHolder.getView(i);
                throw null;
            } else if (itemType == 3) {
                baseViewHolder.setText(R$id.tv_zero_content, keyBroadItemEntry.getValue());
                View view = baseViewHolder.itemView;
                int b = (t.b() - 40) / 2;
                int b2 = (int) ((((double) (t.b() - 40)) * 0.56d) / 4.0d);
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                if (layoutParams.height != b2 || layoutParams.width != b) {
                    layoutParams.width = b;
                    layoutParams.height = b2;
                    view.setLayoutParams(layoutParams);
                }
            } else if (itemType == 4) {
                baseViewHolder.setVisible(R$id.tv_content, false);
            }
        }
    }

    public class a extends TypeToken<List<KeyBroadItemEntry>> {
    }

    public static void a(int i, View view) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (i >= 0 && layoutParams.width != i) {
            layoutParams.width = i;
            layoutParams.height = (int) (((double) i) * 0.56d);
        }
        view.setLayoutParams(layoutParams);
    }

    public static List<KeyBroadItemEntry> getKeyBroadConfig() {
        if (a == null) {
            a = (List) new Gson().fromJson(k.b(R$raw.digital_keyboard_config), new a().getType());
        }
        return a;
    }

    public void setFinishEnable(boolean z) {
        throw null;
    }
}
