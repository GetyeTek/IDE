package com.huawei.digitalpayment.customer.baselib.mvp;

import A8.c;
import P2.a;
import V1.k;
import android.view.View;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public abstract class BaseMvpFragment<P extends c> extends BaseFragment implements a {
    public P c;

    public final void onDestroyView() {
        BaseMvpFragment.super.onDestroyView();
        P p = this.c;
        if (p != null) {
            p.a = null;
            y9.a aVar = (y9.a) p.b;
            if (aVar != null) {
                aVar.dispose();
            }
        }
    }

    public void v(BaseResp baseResp) {
        if ("app.the_app_version_is_not_supported".equals(baseResp.getResponseCode())) {
            Yb.c.b().e(baseResp);
        } else {
            k.b(1, baseResp.getResponseDesc());
        }
    }

    public void x0(View view) {
        this.c = y0();
    }

    public abstract P y0();
}
