package com.huawei.digitalpayment.customer.baselib.sms;

import V1.h;
import V2.c;
import a5.l;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RequestSms implements LifecycleObserver {
    public static final Pattern f = Pattern.compile("\\d{6}");
    public c a;
    public final IntentFilter b;
    public FragmentActivity c;
    public ActivityResultLauncher<Intent> d;
    public final l e;

    public class a implements ActivityResultCallback<ActivityResult> {
        public a() {
        }

        public final void onActivityResult(Object obj) {
            String str;
            ActivityResult activityResult = (ActivityResult) obj;
            if (activityResult.getResultCode() == -1 && activityResult.getData() != null) {
                String stringExtra = activityResult.getData().getStringExtra("com.google.android.gms.auth.api.phone.EXTRA_SMS_MESSAGE");
                Pattern pattern = RequestSms.f;
                RequestSms requestSms = RequestSms.this;
                Matcher matcher = RequestSms.f.matcher(stringExtra);
                if (matcher.find()) {
                    str = matcher.group(0);
                } else {
                    str = "";
                }
                h.b();
                h.b();
                if (!TextUtils.isEmpty(str)) {
                    l lVar = requestSms.e;
                    if (lVar != null) {
                        lVar.onSuccess(str);
                    }
                    h.b();
                    c cVar = requestSms.a;
                    if (cVar != null) {
                        requestSms.c.unregisterReceiver(cVar);
                        requestSms.a = null;
                    }
                }
            }
        }
    }

    public RequestSms() {
        throw null;
    }

    public RequestSms(l lVar) {
        this.e = lVar;
        this.b = new IntentFilter("com.google.android.gms.auth.api.phone.SMS_RETRIEVED");
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    public void onCreate(LifecycleOwner lifecycleOwner) {
        Objects.toString(lifecycleOwner);
        h.b();
        FragmentActivity fragmentActivity = (FragmentActivity) lifecycleOwner;
        this.c = fragmentActivity;
        this.d = fragmentActivity.registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new a());
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy(LifecycleOwner lifecycleOwner) {
        h.b();
        h.b();
        c cVar = this.a;
        if (cVar != null) {
            this.c.unregisterReceiver(cVar);
            this.a = null;
        }
    }
}
