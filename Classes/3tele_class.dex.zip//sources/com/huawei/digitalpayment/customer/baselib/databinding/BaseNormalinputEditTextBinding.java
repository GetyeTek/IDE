package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundLinearLayout;

public final class BaseNormalinputEditTextBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final EditText b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final RoundLinearLayout d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public BaseNormalinputEditTextBinding(@NonNull ConstraintLayout constraintLayout, @NonNull EditText editText, @NonNull ImageView imageView, @NonNull RoundLinearLayout roundLinearLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = editText;
        this.c = imageView;
        this.d = roundLinearLayout;
        this.e = textView;
        this.f = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
