package com.huawei.digitalpayment.customer.homev6.model;

public interface a {
    String getOrder();

    String getStartTime();

    String getStartTimeUTC();

    String getStopTime();

    String getStopTimeUTC();
}
