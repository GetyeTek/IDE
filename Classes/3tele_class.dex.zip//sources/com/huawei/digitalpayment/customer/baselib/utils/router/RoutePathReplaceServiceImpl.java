package com.huawei.digitalpayment.customer.baselib.utils.router;

import V1.h;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.ArrayMap;
import androidx.sqlite.db.b;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.facade.service.PathReplaceService;
import java.util.ArrayList;
import java.util.HashMap;

@Route(path = "/customer/RoutePathReplaceServiceImpl")
public class RoutePathReplaceServiceImpl implements PathReplaceService {
    public static final ArrayList a;
    public static final ArrayMap b;
    public static final HashMap c = new HashMap();

    static {
        ArrayList arrayList = new ArrayList();
        a = arrayList;
        ArrayMap arrayMap = new ArrayMap();
        b = arrayMap;
        b.b(arrayList, "/consumer/homepage/wallet", "/consumer/homepage/life", "/consumer/homepage/chat", "/consumer/homepage/my");
        arrayMap.put("/customer/change_language", "/basicUiModule/chooseLanguage");
        arrayMap.put("/customer/change_pin", "/loginModule/changePin");
        arrayMap.put("/customer/financialService", "/finance/finance");
        arrayMap.put("/customer/financialServiceCBE", "/finance/financeCBE");
        arrayMap.put("/customer/biometric_authentication", "/loginModule/biometricSwitch");
        arrayMap.put("/customer/scan_and_pay", "/qrCodeModule/scan");
        arrayMap.put("/customer/my_qr", "/qrCodeModule/receive");
        arrayMap.put("/consumer/buyGoodsAmount", "/checkoutModule/transferToMerchant");
        arrayMap.put("/checkoutModule/odPayment", "/checkoutModule/odPayment");
        arrayMap.put("/customer/about", "/basicUiModule/about");
        arrayMap.put("/customer/home_balance", "/mainModule/mainBalance");
        arrayMap.put("/customer/home_reward_balance", "/mainModule/mainRewardBalance");
        arrayMap.put("/customer/home_usd_balance", "/mainModule/mainUsdBalance");
        arrayMap.put("/consumer/transferAmount", "/checkoutModule/transferAmount");
        arrayMap.put("/consumer/historyDetails", "/historyModule/historyDetails");
        arrayMap.put("/consumer/webCheckout", "/checkoutModule/h5PayComfirm");
        arrayMap.put("/consumer/billShare", "/checkoutModule/billShareConfirm");
        arrayMap.put("/customer/send_money", "/checkoutModule/transferInputPhone");
        arrayMap.put("/customer/share_app", "/basicUiModule/shareApp");
        arrayMap.put("/customer/despoist", "/cashModule/depositCash");
        arrayMap.put("/customer/withdraw", "/cashModule/withdrawcashguide");
        arrayMap.put("/customer/transfer_to_bank", "/bankModule/transferToBank");
        arrayMap.put("/mainModule/main", "/mainV5Module/main");
        arrayMap.put("/consumer/cNet", "/topUpModule/cNet");
        arrayMap.put("/customer/cashIn/agent", "/cashModule/depositCashAgent");
        arrayMap.put("/customer/deposit/voucher", "/cashModule/applyDepositVoucher");
        arrayMap.put("/customer/cashOut/agent", "/cashModule/withdrawcashinputcode");
        arrayMap.put("/customer/cashOut/atm", "/cashModule/withdrawcashinatm");
        arrayMap.put("/loginModule/forgotPin", "/loginModule/resetpinnophone");
        arrayMap.put("/consumer/myVisaPan", "/mainModule/myVisaPan");
        arrayMap.put("/consumer/customerInfo", "/chat/user_info");
        arrayMap.put("/consumer/fuelPayment", "/topUpModule/fuelPaymentVehicle");
        arrayMap.put("/consumer/requestMoney", "/requestMoneyModule/requestMoney");
        arrayMap.put("/consumer/requestMoneyConfirm", "/requestMoneyModule/requestMoneyConfirm");
        arrayMap.put("/loginModule/answerQAPage", "/loginModule/verifyEncryptedProblem");
        arrayMap.put("/loginModule/createQAPage", "/loginModule/setEncryptedProblem");
        arrayMap.put("/loginModule/resetPin", "/loginModule/resetPinCommit");
        arrayMap.put("/customer/financeRepayment", "/finance/repayment");
        arrayMap.put("/customer/upgradeLevel", "/loginModule/upgradeLevel");
        arrayMap.put("/customer/verifyPaymentResult", "/qrCodeModule/verifyPaymentResult");
        arrayMap.put("/customer/verifyPayment", "/qrCodeModule/verifyPayment");
    }

    public static Uri B(Uri uri) {
        try {
            String path = uri.getPath();
            if (!path.startsWith("/customer/cash_out")) {
                return uri;
            }
            HashMap hashMap = c;
            for (String str : hashMap.keySet()) {
                if (TextUtils.equals(str, path)) {
                    return Uri.parse(uri.toString().replace(str, (CharSequence) hashMap.get(str)));
                }
            }
            return uri;
        } catch (Exception unused) {
            return uri;
        }
    }

    public final String forString(String str) {
        ArrayMap arrayMap = b;
        if (!arrayMap.containsKey(str)) {
            return str;
        }
        String str2 = (String) arrayMap.get(str);
        h.b();
        return str2;
    }

    public final Uri forUri(Uri uri) {
        String path = uri.getPath();
        ArrayMap arrayMap = b;
        if (arrayMap.containsKey(path)) {
            h.b();
            String host = uri.getHost();
            String scheme = uri.getScheme();
            return Uri.parse(scheme + "://" + host + ((String) arrayMap.get(path)));
        }
        try {
            if (a.contains(uri.getPath())) {
                uri = Uri.parse("native://app/mainModule/main?navigation=" + uri.toString());
            }
            return B(uri);
        } catch (Exception unused) {
            return uri;
        }
    }

    public final void init(Context context) {
    }
}
