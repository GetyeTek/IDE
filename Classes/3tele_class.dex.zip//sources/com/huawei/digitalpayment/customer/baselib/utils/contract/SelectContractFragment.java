package com.huawei.digitalpayment.customer.baselib.utils.contract;

import R1.a;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.R$string;
import org.json.JSONObject;

public class SelectContractFragment extends Fragment {
    public a<JSONObject> a;

    /* JADX WARNING: Removed duplicated region for block: B:38:0x00bf A[SYNTHETIC, Splitter:B:38:0x00bf] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onActivityResult(int r11, int r12, @androidx.annotation.Nullable android.content.Intent r13) {
        /*
            r10 = this;
            java.lang.String r0 = ""
            java.lang.String r1 = "_id = "
            com.huawei.digitalpayment.customer.baselib.utils.contract.SelectContractFragment.super.onActivityResult(r11, r12, r13)
            r2 = 101(0x65, float:1.42E-43)
            if (r11 != r2) goto L_0x00e5
            r11 = -1
            if (r12 != r11) goto L_0x00e5
            if (r13 == 0) goto L_0x00e5
            org.json.JSONObject r11 = new org.json.JSONObject
            r11.<init>()
            android.net.Uri r3 = r13.getData()
            androidx.fragment.app.FragmentActivity r12 = r10.requireActivity()
            android.content.ContentResolver r12 = r12.getContentResolver()
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r2 = r12
            android.database.Cursor r13 = r2.query(r3, r4, r5, r6, r7)     // Catch:{ Exception -> 0x00c8 }
            boolean r2 = r13.moveToFirst()     // Catch:{ all -> 0x0057 }
            if (r2 == 0) goto L_0x00b5
            java.lang.String r2 = "contact_id"
            int r2 = r13.getColumnIndex(r2)     // Catch:{ all -> 0x0057 }
            long r2 = r13.getLong(r2)     // Catch:{ all -> 0x0057 }
            android.net.Uri r4 = android.provider.ContactsContract.Contacts.CONTENT_URI     // Catch:{ all -> 0x0057 }
            android.net.Uri r2 = android.content.ContentUris.withAppendedId(r4, r2)     // Catch:{ all -> 0x0057 }
            android.app.Application r3 = com.blankj.utilcode.util.J.a()     // Catch:{ all -> 0x0057 }
            android.content.ContentResolver r3 = r3.getContentResolver()     // Catch:{ all -> 0x0057 }
            java.io.InputStream r2 = android.provider.ContactsContract.Contacts.openContactPhotoInputStream(r3, r2)     // Catch:{ all -> 0x0057 }
            android.graphics.Bitmap r2 = android.graphics.BitmapFactory.decodeStream(r2)     // Catch:{ all -> 0x0057 }
            if (r2 == 0) goto L_0x005c
            java.lang.String r2 = Y2.a.a(r2)     // Catch:{ all -> 0x0057 }
            goto L_0x005d
        L_0x0057:
            r12 = move-exception
            r2 = r0
            r3 = r2
            goto L_0x00bd
        L_0x005c:
            r2 = r0
        L_0x005d:
            java.lang.String r3 = "display_name"
            int r3 = r13.getColumnIndex(r3)     // Catch:{ all -> 0x00b2 }
            java.lang.String r3 = r13.getString(r3)     // Catch:{ all -> 0x00b2 }
            java.lang.String r4 = "has_phone_number"
            int r4 = r13.getColumnIndex(r4)     // Catch:{ all -> 0x00ac }
            java.lang.String r4 = r13.getString(r4)     // Catch:{ all -> 0x00ac }
            java.lang.String r5 = "_id"
            int r5 = r13.getColumnIndex(r5)     // Catch:{ all -> 0x00ac }
            java.lang.String r5 = r13.getString(r5)     // Catch:{ all -> 0x00ac }
            java.lang.String r6 = "1"
            boolean r4 = r4.equalsIgnoreCase(r6)     // Catch:{ all -> 0x00ac }
            if (r4 == 0) goto L_0x00b7
            android.net.Uri r6 = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI     // Catch:{ all -> 0x00ac }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00ac }
            r4.<init>(r1)     // Catch:{ all -> 0x00ac }
            r4.append(r5)     // Catch:{ all -> 0x00ac }
            java.lang.String r7 = r4.toString()     // Catch:{ all -> 0x00ac }
            r9 = 0
            r1 = 0
            r8 = 0
            r4 = r12
            r5 = r6
            r6 = r1
            android.database.Cursor r12 = r4.query(r5, r6, r7, r8, r9)     // Catch:{ all -> 0x00ac }
        L_0x009b:
            boolean r1 = r12.moveToNext()     // Catch:{ all -> 0x00ac }
            if (r1 == 0) goto L_0x00ae
            java.lang.String r1 = "data1"
            int r1 = r12.getColumnIndex(r1)     // Catch:{ all -> 0x00ac }
            java.lang.String r0 = r12.getString(r1)     // Catch:{ all -> 0x00ac }
            goto L_0x009b
        L_0x00ac:
            r12 = move-exception
            goto L_0x00bd
        L_0x00ae:
            r12.close()     // Catch:{ all -> 0x00ac }
            goto L_0x00b7
        L_0x00b2:
            r12 = move-exception
            r3 = r0
            goto L_0x00bd
        L_0x00b5:
            r2 = r0
            r3 = r2
        L_0x00b7:
            r13.close()     // Catch:{ Exception -> 0x00bb }
            goto L_0x00d1
        L_0x00bb:
            r12 = move-exception
            goto L_0x00cb
        L_0x00bd:
            if (r13 == 0) goto L_0x00c7
            r13.close()     // Catch:{ all -> 0x00c3 }
            goto L_0x00c7
        L_0x00c3:
            r13 = move-exception
            r12.addSuppressed(r13)     // Catch:{ Exception -> 0x00bb }
        L_0x00c7:
            throw r12     // Catch:{ Exception -> 0x00bb }
        L_0x00c8:
            r12 = move-exception
            r2 = r0
            r3 = r2
        L_0x00cb:
            r12.getMessage()
            V1.h.b()
        L_0x00d1:
            java.lang.String r12 = "phoneNumber"
            r11.put(r12, r0)     // Catch:{ JSONException -> 0x00e0 }
            java.lang.String r12 = "avatar"
            r11.put(r12, r2)     // Catch:{ JSONException -> 0x00e0 }
            java.lang.String r12 = "name"
            r11.put(r12, r3)     // Catch:{ JSONException -> 0x00e0 }
        L_0x00e0:
            R1.a<org.json.JSONObject> r12 = r10.a
            r12.onSuccess(r11)
        L_0x00e5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.baselib.utils.contract.SelectContractFragment.onActivityResult(int, int, android.content.Intent):void");
    }

    public final void onCreate(@Nullable Bundle bundle) {
        SelectContractFragment.super.onCreate(bundle);
        setRetainInstance(true);
    }

    public final void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        SelectContractFragment.super.onRequestPermissionsResult(i, strArr, iArr);
        if (i != 100) {
            return;
        }
        if (iArr[0] == 0) {
            Intent intent = new Intent("android.intent.action.PICK", ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            intent.addCategory("android.intent.category.DEFAULT");
            startActivityForResult(intent, 101);
            return;
        }
        this.a.onError(new BaseException("6", getString(R$string.designstandard_in_order_to_ensure_the_normal_use_of)));
    }

    public final void v0(a<JSONObject> aVar) {
        this.a = aVar;
        if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(requireContext(), "android.permission.READ_CONTACTS") != 0) {
            requestPermissions(new String[]{"android.permission.READ_CONTACTS"}, 100);
            return;
        }
        Intent intent = new Intent("android.intent.action.PICK", ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        intent.addCategory("android.intent.category.DEFAULT");
        startActivityForResult(intent, 101);
    }
}
