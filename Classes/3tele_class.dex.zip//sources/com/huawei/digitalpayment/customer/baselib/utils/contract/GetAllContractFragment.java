package com.huawei.digitalpayment.customer.baselib.utils.contract;

import R1.a;
import V1.h;
import Y2.c;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.blankj.utilcode.util.A;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.R$string;

public class GetAllContractFragment extends Fragment {
    public a<String> a;

    public final void onCreate(@Nullable Bundle bundle) {
        GetAllContractFragment.super.onCreate(bundle);
        setRetainInstance(true);
    }

    public final void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        GetAllContractFragment.super.onRequestPermissionsResult(i, strArr, iArr);
        if (i != 100) {
            return;
        }
        if (iArr[0] == 0) {
            h.b();
            A.d(new c(this));
            return;
        }
        this.a.onError(new BaseException(getString(R$string.common_permission_deny)));
    }
}
