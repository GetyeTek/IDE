package com.huawei.digitalpayment.customer.viewlib.location;

import R1.b;
import android.app.Application;
import android.location.LocationManager;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.q;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.R$string;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import r4.C0062a;
import r4.c;
import r4.d;
import r4.e;
import r4.h;

public class CheckLocationPermissionFragment extends Fragment {
    public boolean a;

    public final void onCreate(@Nullable Bundle bundle) {
        CheckLocationPermissionFragment.super.onCreate(bundle);
        if (BasicConfig.getInstance().isReportLocationInForce()) {
            v0();
            return;
        }
        DialogManager.d(getChildFragmentManager(), false);
        new h().a(requireContext(), new d(this, false));
    }

    public final void onResume() {
        CheckLocationPermissionFragment.super.onResume();
        if (this.a) {
            this.a = false;
            v0();
        }
    }

    public final void v0() {
        Application a2 = J.a();
        if (ContextCompat.checkSelfPermission(a2, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(a2, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            LocationManager locationManager = (LocationManager) J.a().getSystemService("location");
            if (locationManager == null || !locationManager.isLocationEnabled()) {
                x0(new c(this));
                return;
            }
            DialogManager.d(getChildFragmentManager(), false);
            new h().a(requireContext(), new d(this, true));
            return;
        }
        q e = q.e(new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"});
        e.c = new C0062a(this);
        e.f();
    }

    public final void w0() {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.getSupportFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.view.View$OnClickListener, r4.e] */
    public final void x0(b bVar) {
        String string = getString(R$string.turn_on_location_service_tip);
        String string2 = getString(R$string.app_allow);
        String string3 = getString(R$string.cancel);
        ? eVar = new e(this);
        BaseDialog baseDialog = new BaseDialog();
        baseDialog.g = null;
        baseDialog.h = string;
        baseDialog.i = string3;
        baseDialog.j = string2;
        baseDialog.k = eVar;
        baseDialog.l = bVar;
        baseDialog.show(requireActivity().getSupportFragmentManager(), "turn_on_location");
    }
}
