package com.huawei.digitalpayment.customer.viewlib.pininput.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.google.gson.JsonObject;
import com.huawei.common.exception.BaseException;
import com.huawei.http.b;

public class IdentifyPinViewModel extends ViewModel {
    public final MutableLiveData<c<JsonObject>> a = new MutableLiveData<>();

    public class a implements R1.a<JsonObject> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            IdentifyPinViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            IdentifyPinViewModel.this.a.setValue(c.e((JsonObject) obj));
        }
    }

    public final void a(String str) {
        this.a.setValue(c.c());
        b bVar = new b();
        bVar.addParams("initiatorPin", L3.a.g(str));
        bVar.addParams("pinVersion", L3.a.b.getPinKeyVersion());
        bVar.sendRequest(new a());
    }
}
