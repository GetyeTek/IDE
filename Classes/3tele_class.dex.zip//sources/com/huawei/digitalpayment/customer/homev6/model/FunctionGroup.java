package com.huawei.digitalpayment.customer.homev6.model;

import H9.a;
import L2.c;
import java.io.Serializable;
import java.util.List;

public class FunctionGroup implements Serializable, a {
    private String groupIcon;
    private String groupId;
    private String groupName;
    private List<HomeFunction> list;
    private String marker;
    private String menuType;
    private String minAndroidVersion;
    private String order;
    private String reportTag;
    private boolean show;
    private String startTime;
    private String startTimeUTC;
    private String stopTime;
    private String stopTimeUTC;

    public String getGroupIcon() {
        return this.groupIcon;
    }

    public String getGroupId() {
        return this.groupId;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public List<HomeFunction> getList() {
        return this.list;
    }

    public String getMarker() {
        c.a.getClass();
        return a.b(this.marker);
    }

    public String getMenuType() {
        return this.menuType;
    }

    public String getMinAndroidVersion() {
        return this.minAndroidVersion;
    }

    public String getOrder() {
        return this.order;
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public String getStartTimeUTC() {
        return this.startTimeUTC;
    }

    public String getStopTime() {
        return this.stopTime;
    }

    public String getStopTimeUTC() {
        return this.stopTimeUTC;
    }

    public boolean isShow() {
        return this.show;
    }

    public void setGroupIcon(String str) {
        this.groupIcon = str;
    }

    public void setGroupId(String str) {
        this.groupId = str;
    }

    public void setGroupName(String str) {
        this.groupName = str;
    }

    public void setList(List<HomeFunction> list2) {
        this.list = list2;
    }

    public void setMarker(String str) {
        this.marker = str;
    }

    public void setMenuType(String str) {
        this.menuType = str;
    }

    public void setMinAndroidVersion(String str) {
        this.minAndroidVersion = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setReportTag(String str) {
        this.reportTag = str;
    }

    public void setShow(boolean z) {
        this.show = z;
    }

    public void setStartTime(String str) {
        this.startTime = str;
    }

    public void setStartTimeUTC(String str) {
        this.startTimeUTC = str;
    }

    public void setStopTime(String str) {
        this.stopTime = str;
    }

    public void setStopTimeUTC(String str) {
        this.stopTimeUTC = str;
    }
}
