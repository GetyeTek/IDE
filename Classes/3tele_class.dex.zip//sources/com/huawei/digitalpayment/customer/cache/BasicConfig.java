package com.huawei.digitalpayment.customer.cache;

import E0.c;
import V1.h;
import W2.f;
import W2.n;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.camera.camera2.internal.O;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.k;
import com.google.gson.JsonElement;
import com.huawei.digitalpayment.customer.baselib.R$string;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.httplib.bean.AmountConfigBean;
import com.huawei.digitalpayment.customer.httplib.bean.CreditPayConfigBean;
import com.huawei.digitalpayment.customer.httplib.bean.EasierDownloadConfigBean;
import com.huawei.digitalpayment.customer.httplib.bean.HomeFuncList;
import com.huawei.digitalpayment.customer.httplib.bean.MerchantAppIdBean;
import com.huawei.digitalpayment.customer.httplib.bean.ParameterLimitBean;
import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.digitalpayment.customer.httplib.response.ChatBizConfigResp;
import com.huawei.digitalpayment.customer.httplib.response.ConfigVerifyResp;
import com.huawei.digitalpayment.customer.httplib.response.PocketMoneyBizConfigResp;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class BasicConfig implements Serializable {
    private static final int MAX_COUNT = 6;
    private static final String TAG = "BasicConfig";
    private static BasicConfig instance = new BasicConfig();
    private AmountConfigBean cashInConfig;
    private AmountConfigBean cashOutConfig;
    private ChatBizConfigResp chatBizConfig;
    private ConfigVerifyResp configVerifyResp;
    private String editTextInputLimit;
    private HomeFuncList functionConfigOld;
    private boolean isShowTerms;
    private List<BasicConfigResp.SettingsConfig> loginPageSettingsConfig;
    private MerchantAppIdBean mandateInfo;
    private MerchantAppIdBean merchantAppIdConfig;
    private String needCaptcha;
    private ParameterLimitBean parameterLimit;
    private PocketMoneyBizConfigResp pocketMoneyBizConfigResp;
    private Map<String, String> referenceData;
    private BasicConfigResp.StaticPageUrl staticPageUrl;

    private BasicConfig() {
    }

    public static BasicConfig getInstance() {
        return instance;
    }

    private String getSPKey(String str) {
        return O.a(str, "_", LanguageUtils.getInstance().getCurrentLang());
    }

    private boolean isY(@NonNull String str) {
        return "Y".equals(getReferenceDataValueByKey(str));
    }

    public boolean bannerIsQuerySwitch() {
        Map<String, String> map = this.referenceData;
        if (map == null || map.size() == 0) {
            return false;
        }
        return TextUtils.equals("true", this.referenceData.get("bannerIsQuerySwitch"));
    }

    public void clearOpenImg() {
        n.b("").i(getSPKey("open_page_img"));
    }

    public AmountConfigBean getCashInConfig() {
        return this.cashInConfig;
    }

    public AmountConfigBean getCashOutConfig() {
        return this.cashOutConfig;
    }

    public ChatBizConfigResp getChatBizConfig() {
        if (this.chatBizConfig == null) {
            String e = n.b("").e("chat_biz_config");
            if (TextUtils.isEmpty(e)) {
                this.chatBizConfig = (ChatBizConfigResp) f.a(e, ChatBizConfigResp.class);
            }
        }
        return this.chatBizConfig;
    }

    public ConfigVerifyResp getConfigVerifyResp() {
        return this.configVerifyResp;
    }

    public String getLoginMode() {
        Map<String, String> referenceData2 = getReferenceData();
        if (referenceData2 == null) {
            return "1";
        }
        referenceData2.toString();
        h.b();
        String str = referenceData2.get("loginMode");
        if (TextUtils.isEmpty(str)) {
            return "1";
        }
        return str;
    }

    public MerchantAppIdBean getMerchantAppIdConfig() {
        MerchantAppIdBean merchantAppIdBean = (MerchantAppIdBean) f.a(n.b("").e(getSPKey("MERCHANT_APP_ID_INFO")), MerchantAppIdBean.class);
        this.merchantAppIdConfig = merchantAppIdBean;
        return merchantAppIdBean;
    }

    public String getNeedCaptcha() {
        return this.needCaptcha;
    }

    public ParameterLimitBean getParameterLimit() {
        return this.parameterLimit;
    }

    public PocketMoneyBizConfigResp getPocketMoneyBizConfig() {
        if (this.pocketMoneyBizConfigResp == null) {
            String e = n.b("").e("pocket_money_config");
            if (TextUtils.isEmpty(e)) {
                this.pocketMoneyBizConfigResp = (PocketMoneyBizConfigResp) f.a(e, PocketMoneyBizConfigResp.class);
            }
        }
        return this.pocketMoneyBizConfigResp;
    }

    public Map<String, String> getReferenceData() {
        Map<String, String> map = this.referenceData;
        if (map == null || map.size() == 0) {
            this.referenceData = (Map) f.a(n.b("").e("referenceData"), Map.class);
        }
        return this.referenceData;
    }

    public String getReferenceDataValueByKey(@NonNull String str) {
        return getReferenceDataValueByKey(str, (String) null);
    }

    public String getShareAppMSG() {
        String str;
        try {
            str = c.f().getNickName();
        } catch (Exception unused) {
            str = "";
        }
        String string = n.b("").a.getString("share_app_msg", "");
        try {
            string = String.format(string, new Object[]{str});
        } catch (Exception unused2) {
        }
        if (!TextUtils.isEmpty(string)) {
            return string;
        }
        return J.a().getString(R$string.app_share_link, new Object[]{str});
    }

    public BasicConfigResp.StaticPageUrl getStaticPageUrl() {
        String e = n.b("").e(getSPKey("STATIC_PAGE_URL"));
        if (!TextUtils.isEmpty(e)) {
            this.staticPageUrl = (BasicConfigResp.StaticPageUrl) f.a(e, BasicConfigResp.StaticPageUrl.class);
        }
        return this.staticPageUrl;
    }

    public boolean isReportLocationAfterLogin() {
        return isY("reportLocationAfterLogin");
    }

    public boolean isReportLocationInForce() {
        return isY("reportLocationInForce");
    }

    public boolean isReportLocationInRealTime() {
        return isY("reportLocationInRealTime");
    }

    public void saveChatBizConfig(ChatBizConfigResp chatBizConfigResp) {
        this.chatBizConfig = chatBizConfigResp;
        n.b("").g("chat_biz_config", k.d(chatBizConfigResp), false);
    }

    public void saveConfigVerifyResp(ConfigVerifyResp configVerifyResp2) {
        this.configVerifyResp = configVerifyResp2;
    }

    public void saveEnableBiometricPayTimes(Integer num) {
        if (num == null) {
            n.b("").i("ENABLE_BIOMETRIC_PAY_TIMES");
        } else {
            n.b("").f(num.intValue(), "ENABLE_BIOMETRIC_PAY_TIMES");
        }
    }

    public void savePocketMoneyBizConfig(PocketMoneyBizConfigResp pocketMoneyBizConfigResp2) {
        this.pocketMoneyBizConfigResp = pocketMoneyBizConfigResp2;
        n.b("").g("pocket_money_config", k.d(pocketMoneyBizConfigResp2), false);
    }

    public void saveReferenceData(Map<String, String> map) {
        if (map != null) {
            this.referenceData = map;
            n.b("").g("referenceData", k.d(map), false);
        }
    }

    public void setCashInConfig(AmountConfigBean amountConfigBean) {
        this.cashInConfig = amountConfigBean;
    }

    public void setCashOutConfig(AmountConfigBean amountConfigBean) {
        this.cashOutConfig = amountConfigBean;
    }

    public void setCreditPayConfig(CreditPayConfigBean creditPayConfigBean) {
        if (creditPayConfigBean != null && !TextUtils.isEmpty(creditPayConfigBean.getUrl())) {
            n.b("").g("openOdUrl", creditPayConfigBean.getUrl(), false);
        }
    }

    public void setEasierDownloadConfigBean(EasierDownloadConfigBean easierDownloadConfigBean) {
        if (easierDownloadConfigBean != null && !TextUtils.isEmpty(easierDownloadConfigBean.getUrl())) {
            n.b("").g("easierDownloadUrl", easierDownloadConfigBean.getUrl(), false);
        }
        if (easierDownloadConfigBean != null && !TextUtils.isEmpty(easierDownloadConfigBean.getUrlDev())) {
            n.b("").g("easierDownloadDevUrl", easierDownloadConfigBean.getUrlDev(), false);
        }
        if (easierDownloadConfigBean != null) {
            n.b("").g("easierDownloadVersion", easierDownloadConfigBean.getVersion(), false);
        }
    }

    public void setEditTextInputLimit(String str) {
        this.editTextInputLimit = str;
    }

    public void setFunctionConfigOld(HomeFuncList homeFuncList) {
        if (homeFuncList != null) {
            n.b("").g(getSPKey("HOME_FUNCTION_LIST"), k.d(homeFuncList), false);
        }
        this.functionConfigOld = homeFuncList;
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Object, java.util.Comparator] */
    public void setLoginPageSettingConfig(List<BasicConfigResp.SettingsConfig> list) {
        try {
            Collections.sort(this.loginPageSettingsConfig, new Object());
        } catch (Exception unused) {
        }
        LanguageUtils.getInstance().getCurrentLang();
        if (list != null) {
            if (c.g()) {
                n.b("").g(getSPKey("LOGIN_SETTING_MENU"), k.d(list), false);
            } else {
                n.b("").g(getSPKey("UN_LOGIN_SETTING_MENU"), k.d(list), false);
            }
        }
        this.loginPageSettingsConfig = list;
    }

    public void setMerchantAppIdConfig(MerchantAppIdBean merchantAppIdBean) {
        if (merchantAppIdBean != null) {
            n.b("").g(getSPKey("MERCHANT_APP_ID_INFO"), k.d(merchantAppIdBean), false);
        }
        this.merchantAppIdConfig = merchantAppIdBean;
    }

    public void setNeedCaptcha(String str) {
        this.needCaptcha = str;
    }

    public void setOpenH5UrlWhiteList(JsonElement jsonElement) {
        Objects.toString(jsonElement);
        h.b();
        if (jsonElement != null) {
            n.b("").g("openH5UrlWhiteListConfig", k.d(jsonElement), false);
        }
    }

    public void setOpenUrlWhiteList(JsonElement jsonElement) {
        Objects.toString(jsonElement);
        h.b();
        if (jsonElement != null) {
            n.b("").g("openUrlWhiteListConfig", k.d(jsonElement), false);
        }
    }

    public void setParameterLimit(ParameterLimitBean parameterLimitBean) {
        this.parameterLimit = parameterLimitBean;
    }

    public void setShareAppMSG(String str) {
        if (!TextUtils.isEmpty(str)) {
            n.b("").g("share_app_msg", str, false);
        }
    }

    public void setStaticPageUrl(BasicConfigResp.StaticPageUrl staticPageUrl2) {
        this.staticPageUrl = staticPageUrl2;
        if (staticPageUrl2 != null) {
            n.b("").g(getSPKey("STATIC_PAGE_URL"), k.d(staticPageUrl2), false);
        }
    }

    public String getReferenceDataValueByKey(@NonNull String str, String str2) {
        Map<String, String> map = this.referenceData;
        if (map == null) {
            return str2;
        }
        String str3 = map.get(str);
        return !TextUtils.isEmpty(str3) ? str3 : str2;
    }
}
