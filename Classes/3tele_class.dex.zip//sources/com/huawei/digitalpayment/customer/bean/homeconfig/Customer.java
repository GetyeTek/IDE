package com.huawei.digitalpayment.customer.bean.homeconfig;

import java.io.Serializable;

public class Customer implements Serializable {
    private Address address;
    private String avatar;
    private String birthday;
    private String customerLevel;
    private String execute;
    private String firstName;
    private String gender;
    private String idName;
    private String idNumber;
    private String idType;
    private String identityId;
    private String msisdn;
    private String nickName;
    private String qrCode;

    public static class Address implements Serializable {
        private String city;
        private String district;
        private String nationality;
        private String permanentAddress;
        private String province;

        public String getCity() {
            return this.city;
        }

        public String getDistrict() {
            return this.district;
        }

        public String getNationality() {
            return this.nationality;
        }

        public String getPermanentAddress() {
            return this.permanentAddress;
        }

        public String getProvince() {
            return this.province;
        }

        public void setCity(String str) {
            this.city = str;
        }

        public void setDistrict(String str) {
            this.district = str;
        }

        public void setNationality(String str) {
            this.nationality = str;
        }

        public void setPermanentAddress(String str) {
            this.permanentAddress = str;
        }

        public void setProvince(String str) {
            this.province = str;
        }
    }

    public static String getToken() {
        return "";
    }

    public Address getAddress() {
        return this.address;
    }

    public String getAvatar() {
        return this.avatar;
    }

    public String getBirthday() {
        return this.birthday;
    }

    public String getCustomerLevel() {
        return this.customerLevel;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getGender() {
        return this.gender;
    }

    public String getIdName() {
        return this.idName;
    }

    public String getIdNumber() {
        return this.idNumber;
    }

    public String getIdType() {
        return this.idType;
    }

    public String getIdentityId() {
        return this.identityId;
    }

    public String getMsisdn() {
        String str = this.msisdn;
        if (str == null) {
            return "";
        }
        return str;
    }

    public String getNickName() {
        String str = this.nickName;
        if (str == null) {
            return "";
        }
        return str;
    }

    public String getQrCode() {
        return this.qrCode;
    }

    public void setAddress(Address address2) {
        this.address = address2;
    }

    public void setAvatar(String str) {
        this.avatar = str;
    }

    public void setBirthday(String str) {
        this.birthday = str;
    }

    public void setCustomerLevel(String str) {
        this.customerLevel = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setFirstName(String str) {
        this.firstName = str;
    }

    public void setGender(String str) {
        this.gender = str;
    }

    public void setIdName(String str) {
        this.idName = str;
    }

    public void setIdNumber(String str) {
        this.idNumber = str;
    }

    public void setIdType(String str) {
        this.idType = str;
    }

    public void setIdentityId(String str) {
        this.identityId = str;
    }

    public void setMsisdn(String str) {
        this.msisdn = str;
    }

    public void setNickName(String str) {
        this.nickName = str;
    }

    public void setQrCode(String str) {
        this.qrCode = str;
    }
}
