package com.huawei.digitalpayment.customer.baselib.session;

import U2.a;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.customer.cache.BasicConfig;

public class SessionManagerView extends FrameLayout {
    public SessionManagerView(Context context) {
        super(context);
    }

    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0 && TextUtils.equals(BasicConfig.getInstance().getLoginMode(), "1")) {
            a.b.a();
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public SessionManagerView(Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }
}
