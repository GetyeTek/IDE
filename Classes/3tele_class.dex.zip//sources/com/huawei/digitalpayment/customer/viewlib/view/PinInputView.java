package com.huawei.digitalpayment.customer.viewlib.view;

import D4.p;
import W1.e;
import android.content.Context;
import android.text.method.HideReturnsTransformationMethod;
import android.util.AttributeSet;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.customer.baselib.R$mipmap;

public class PinInputView extends CommonInputView {
    public boolean i = true;
    public final e j = new e();

    public PinInputView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        c();
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Object, android.view.ActionMode$Callback] */
    /* JADX WARNING: type inference failed for: r1v3, types: [java.lang.Object, android.view.ActionMode$Callback] */
    public final void c() {
        EditText editText = getEditText();
        editText.setInputType(2);
        editText.setCustomSelectionActionModeCallback(new Object());
        d();
        setOnIconListener(new p(this, 6));
        editText.setCustomSelectionActionModeCallback(new Object());
        editText.setLongClickable(false);
    }

    public final void d() {
        EditText editText = getEditText();
        if (this.i) {
            editText.setTransformationMethod(this.j);
        } else {
            editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        }
        editText.setSelection(editText.getText().length());
        ImageView ivIcon = getIvIcon();
        if (this.i) {
            ivIcon.setImageResource(R$mipmap.common_pin_eye_close);
        } else {
            ivIcon.setImageResource(R$mipmap.common_pin_eye_open);
        }
    }

    public PinInputView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        c();
    }
}
