package com.huawei.digitalpayment.customer.bean.homeconfig;

import com.google.gson.annotations.SerializedName;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class MenuConfig extends BaseResp {
    @SerializedName("jsonContent")
    private List<UseRewardBalance> useRewardBalances;

    public static class UseRewardBalance implements Serializable {
        @SerializedName("execute")
        private String execute;
        @SerializedName("funcId")
        private String funcId;
        @SerializedName("funcName")
        private String funcName;
        @SerializedName("icon")
        private String icon;
        @SerializedName("order")
        private String order;
        @SerializedName("reportTag")
        private String reportTag;

        public String getExecute() {
            return this.execute;
        }

        public String getFuncId() {
            return this.funcId;
        }

        public String getFuncName() {
            return this.funcName;
        }

        public String getIcon() {
            return this.icon;
        }

        public String getOrder() {
            return this.order;
        }

        public String getReportTag() {
            return this.reportTag;
        }

        public void setExecute(String str) {
            this.execute = str;
        }

        public void setFuncId(String str) {
            this.funcId = str;
        }

        public void setFuncName(String str) {
            this.funcName = str;
        }

        public void setIcon(String str) {
            this.icon = str;
        }

        public void setOrder(String str) {
            this.order = str;
        }

        public void setReportTag(String str) {
            this.reportTag = str;
        }
    }

    public List<UseRewardBalance> getUseRewardBalances() {
        return this.useRewardBalances;
    }

    public void setUseRewardBalances(List<UseRewardBalance> list) {
        this.useRewardBalances = list;
    }
}
