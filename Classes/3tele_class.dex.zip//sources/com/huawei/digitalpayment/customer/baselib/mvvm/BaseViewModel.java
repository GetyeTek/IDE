package com.huawei.digitalpayment.customer.baselib.mvvm;

import V1.h;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

public class BaseViewModel extends ViewModel implements LifecycleObserver {
    public final MutableLiveData<Boolean> a;
    public final MutableLiveData<BaseException> b;
    public final LiveData<Boolean> c;
    public final LiveData<BaseException> d;
    public y9.a e;
    public final ArrayList f = new ArrayList();

    public class a<T> implements R1.a<T> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public void onError(BaseException baseException) {
            BaseViewModel baseViewModel = BaseViewModel.this;
            baseViewModel.a.setValue(Boolean.FALSE);
            baseViewModel.b.setValue(baseException);
        }

        public final void onLoading(T t) {
            BaseViewModel.this.a.setValue(Boolean.TRUE);
        }

        public void onSuccess(T t) {
            BaseViewModel.this.a.setValue(Boolean.FALSE);
            Objects.toString(t);
            h.b();
        }
    }

    public static class b<T> implements Observer<S2.b<T>> {
        public final ArrayList a;
        public R1.a<T> b;
        public LiveData<S2.b<T>> c;

        public b(ArrayList arrayList, LiveData liveData, R1.a aVar) {
            this.a = arrayList;
            this.c = liveData;
            this.b = aVar;
        }

        public final void onChanged(Object obj) {
            S2.b bVar = (S2.b) obj;
            boolean d = bVar.d();
            T t = bVar.c;
            if (d) {
                this.b.onLoading(t);
                return;
            }
            boolean b2 = bVar.b();
            ArrayList arrayList = this.a;
            if (b2) {
                this.b.onError(bVar.b);
                LiveData<S2.b<T>> liveData = this.c;
                if (liveData != null) {
                    liveData.removeObserver(this);
                    this.b = null;
                    this.c = null;
                }
                arrayList.remove(this);
            } else if (bVar.f()) {
                this.b.onSuccess(t);
                LiveData<S2.b<T>> liveData2 = this.c;
                if (liveData2 != null) {
                    liveData2.removeObserver(this);
                    this.b = null;
                    this.c = null;
                }
                arrayList.remove(this);
            }
        }
    }

    public BaseViewModel() {
        MutableLiveData<Boolean> mutableLiveData = new MutableLiveData<>(Boolean.FALSE);
        this.a = mutableLiveData;
        MutableLiveData<BaseException> mutableLiveData2 = new MutableLiveData<>();
        this.b = mutableLiveData2;
        this.c = Transformations.distinctUntilChanged(mutableLiveData);
        this.d = Transformations.distinctUntilChanged(mutableLiveData2);
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [y9.a, java.lang.Object] */
    @Deprecated
    public final void a(L2.a aVar) {
        if (this.e == null) {
            this.e = new Object();
        }
        this.e.b(aVar);
    }

    public final <T> void b(LiveData<S2.b<T>> liveData, R1.a<T> aVar) {
        ArrayList arrayList = this.f;
        b bVar = new b(arrayList, liveData, aVar);
        if (!arrayList.contains(bVar)) {
            arrayList.add(bVar);
        }
        liveData.observeForever(bVar);
    }

    public final void c(MediatorLiveData mediatorLiveData, R1.a aVar) {
        mediatorLiveData.observeForever(new b(this.f, mediatorLiveData, aVar));
    }

    public void onCleared() {
        BaseViewModel.super.onCleared();
        y9.a aVar = this.e;
        if (aVar != null) {
            aVar.dispose();
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    public void onCreate(LifecycleOwner lifecycleOwner) {
        Objects.toString(lifecycleOwner);
        h.b();
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy(LifecycleOwner lifecycleOwner) {
        Objects.toString(lifecycleOwner);
        h.b();
        ArrayList arrayList = this.f;
        if (!arrayList.isEmpty()) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                b bVar = (b) it.next();
                LiveData<S2.b<T>> liveData = bVar.c;
                if (liveData != null) {
                    liveData.removeObserver(bVar);
                    bVar.b = null;
                    bVar.c = null;
                }
            }
            arrayList.clear();
        }
    }
}
