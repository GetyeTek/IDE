package com.huawei.digitalpayment.customer.homev6;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(41);
            a = hashMap;
            hashMap.put("layout/activity_my_usd_balance_0", Integer.valueOf(R$layout.activity_my_usd_balance));
            hashMap.put("layout/activity_transaction_history_0", Integer.valueOf(R$layout.activity_transaction_history));
            hashMap.put("layout/activity_transaction_history_list_0", Integer.valueOf(R$layout.activity_transaction_history_list));
            hashMap.put("layout/fragment_transaction_report_0", Integer.valueOf(R$layout.fragment_transaction_report));
            hashMap.put("layout/fragment_transaction_send_graph_0", Integer.valueOf(R$layout.fragment_transaction_send_graph));
            hashMap.put("layout/home_edit_function_activity_0", Integer.valueOf(R$layout.home_edit_function_activity));
            hashMap.put("layout/homev5_activity_home_0", Integer.valueOf(R$layout.homev5_activity_home));
            hashMap.put("layout/homev5_fragment_home_0", Integer.valueOf(R$layout.homev5_fragment_home));
            hashMap.put("layout/homev5_fragment_life_0", Integer.valueOf(R$layout.homev5_fragment_life));
            hashMap.put("layout/homev5_fragment_my_0", Integer.valueOf(R$layout.homev5_fragment_my));
            hashMap.put("layout/homev5_item_edit_favorite_function_0", Integer.valueOf(R$layout.homev5_item_edit_favorite_function));
            hashMap.put("layout/homev5_item_home_edit_function_0", Integer.valueOf(R$layout.homev5_item_home_edit_function));
            hashMap.put("layout/homev5_item_home_favorite_function_0", Integer.valueOf(R$layout.homev5_item_home_favorite_function));
            hashMap.put("layout/homev5_item_home_function_0", Integer.valueOf(R$layout.homev5_item_home_function));
            hashMap.put("layout/homev5_item_home_head_function_0", Integer.valueOf(R$layout.homev5_item_home_head_function));
            hashMap.put("layout/homev5_item_home_life_function_0", Integer.valueOf(R$layout.homev5_item_home_life_function));
            hashMap.put("layout/homev5_item_home_pin_group_function_0", Integer.valueOf(R$layout.homev5_item_home_pin_group_function));
            hashMap.put("layout/homev5_item_life_banner_0", Integer.valueOf(R$layout.homev5_item_life_banner));
            hashMap.put("layout/homev5_item_life_function_0", Integer.valueOf(R$layout.homev5_item_life_function));
            hashMap.put("layout/homev5_item_my_function_0", Integer.valueOf(R$layout.homev5_item_my_function));
            hashMap.put("layout/homev5_item_my_function_item_0", Integer.valueOf(R$layout.homev5_item_my_function_item));
            hashMap.put("layout/homev5_life_group_function_0", Integer.valueOf(R$layout.homev5_life_group_function));
            hashMap.put("layout/homev5_my_login_out_0", Integer.valueOf(R$layout.homev5_my_login_out));
            hashMap.put("layout/homev6_activity_search_0", Integer.valueOf(R$layout.homev6_activity_search));
            hashMap.put("layout/homev6_apps_group_function_0", Integer.valueOf(R$layout.homev6_apps_group_function));
            hashMap.put("layout/homev6_fragment_apps_0", Integer.valueOf(R$layout.homev6_fragment_apps));
            hashMap.put("layout/homev6_home_footer_0", Integer.valueOf(R$layout.homev6_home_footer));
            hashMap.put("layout/homev6_home_header_0", Integer.valueOf(R$layout.homev6_home_header));
            hashMap.put("layout/homev6_home_popular_services_0", Integer.valueOf(R$layout.homev6_home_popular_services));
            hashMap.put("layout/homev6_home_title_bar_0", Integer.valueOf(R$layout.homev6_home_title_bar));
            hashMap.put("layout/homev6_item_apps_function_0", Integer.valueOf(R$layout.homev6_item_apps_function));
            hashMap.put("layout/homev6_item_banner_0", Integer.valueOf(R$layout.homev6_item_banner));
            hashMap.put("layout/homev6_item_home_popular_service_function_0", Integer.valueOf(R$layout.homev6_item_home_popular_service_function));
            hashMap.put("layout/homev6_item_menu_pop_0", Integer.valueOf(R$layout.homev6_item_menu_pop));
            hashMap.put("layout/homev6_item_pay_function_0", Integer.valueOf(R$layout.homev6_item_pay_function));
            hashMap.put("layout/homev6_life_group_function_0", Integer.valueOf(R$layout.homev6_life_group_function));
            hashMap.put("layout/homev6_menu_pop_layout_0", Integer.valueOf(R$layout.homev6_menu_pop_layout));
            hashMap.put("layout/transaction_filter_type_0", Integer.valueOf(R$layout.transaction_filter_type));
            hashMap.put("layout/transaction_item_records_0", Integer.valueOf(R$layout.transaction_item_records));
            hashMap.put("layout/transaction_type_child_0", Integer.valueOf(R$layout.transaction_type_child));
            hashMap.put("layout/transaction_type_group_0", Integer.valueOf(R$layout.transaction_type_group));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(41);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_my_usd_balance, 1);
        sparseIntArray.put(R$layout.activity_transaction_history, 2);
        sparseIntArray.put(R$layout.activity_transaction_history_list, 3);
        sparseIntArray.put(R$layout.fragment_transaction_report, 4);
        sparseIntArray.put(R$layout.fragment_transaction_send_graph, 5);
        sparseIntArray.put(R$layout.home_edit_function_activity, 6);
        sparseIntArray.put(R$layout.homev5_activity_home, 7);
        sparseIntArray.put(R$layout.homev5_fragment_home, 8);
        sparseIntArray.put(R$layout.homev5_fragment_life, 9);
        sparseIntArray.put(R$layout.homev5_fragment_my, 10);
        sparseIntArray.put(R$layout.homev5_item_edit_favorite_function, 11);
        sparseIntArray.put(R$layout.homev5_item_home_edit_function, 12);
        sparseIntArray.put(R$layout.homev5_item_home_favorite_function, 13);
        sparseIntArray.put(R$layout.homev5_item_home_function, 14);
        sparseIntArray.put(R$layout.homev5_item_home_head_function, 15);
        sparseIntArray.put(R$layout.homev5_item_home_life_function, 16);
        sparseIntArray.put(R$layout.homev5_item_home_pin_group_function, 17);
        sparseIntArray.put(R$layout.homev5_item_life_banner, 18);
        sparseIntArray.put(R$layout.homev5_item_life_function, 19);
        sparseIntArray.put(R$layout.homev5_item_my_function, 20);
        sparseIntArray.put(R$layout.homev5_item_my_function_item, 21);
        sparseIntArray.put(R$layout.homev5_life_group_function, 22);
        sparseIntArray.put(R$layout.homev5_my_login_out, 23);
        sparseIntArray.put(R$layout.homev6_activity_search, 24);
        sparseIntArray.put(R$layout.homev6_apps_group_function, 25);
        sparseIntArray.put(R$layout.homev6_fragment_apps, 26);
        sparseIntArray.put(R$layout.homev6_home_footer, 27);
        sparseIntArray.put(R$layout.homev6_home_header, 28);
        sparseIntArray.put(R$layout.homev6_home_popular_services, 29);
        sparseIntArray.put(R$layout.homev6_home_title_bar, 30);
        sparseIntArray.put(R$layout.homev6_item_apps_function, 31);
        sparseIntArray.put(R$layout.homev6_item_banner, 32);
        sparseIntArray.put(R$layout.homev6_item_home_popular_service_function, 33);
        sparseIntArray.put(R$layout.homev6_item_menu_pop, 34);
        sparseIntArray.put(R$layout.homev6_item_pay_function, 35);
        sparseIntArray.put(R$layout.homev6_life_group_function, 36);
        sparseIntArray.put(R$layout.homev6_menu_pop_layout, 37);
        sparseIntArray.put(R$layout.transaction_filter_type, 38);
        sparseIntArray.put(R$layout.transaction_item_records, 39);
        sparseIntArray.put(R$layout.transaction_type_child, 40);
        sparseIntArray.put(R$layout.transaction_type_group, 41);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(10);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.login_module.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_basic_ui.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    /* JADX WARNING: type inference failed for: r2v10, types: [com.huawei.digitalpayment.customer.homev6.databinding.FragmentTransactionReportBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r7v21, types: [androidx.databinding.ViewDataBinding, com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFavoriteFunctionBindingImpl] */
    /* JADX WARNING: type inference failed for: r7v23, types: [com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFunctionBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r9v17, types: [com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemMyFunctionItemBindingImpl, androidx.databinding.ViewDataBinding, com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemMyFunctionItemBinding] */
    /* JADX WARNING: type inference failed for: r0v393, types: [com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: Code restructure failed: missing block: B:235:0x0c64, code lost:
        r1 = com.huawei.digitalpayment.customer.homev6.R$id.creditTv;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:237:0x0c70, code lost:
        r1 = com.huawei.digitalpayment.customer.homev6.R$id.dateFilter;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:241:0x0c88, code lost:
        r1 = com.huawei.digitalpayment.customer.homev6.R$id.debitTV;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:281:0x0e68, code lost:
        r6 = com.huawei.digitalpayment.customer.homev6.R$id.closedRTV;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 5 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.databinding.ViewDataBinding getDataBinder(androidx.databinding.DataBindingComponent r36, android.view.View r37, int r38) {
        /*
            r35 = this;
            r1 = r36
            r15 = r37
            android.util.SparseIntArray r0 = a
            r2 = r38
            int r0 = r0.get(r2)
            r14 = 0
            if (r0 <= 0) goto L_0x0028
            java.lang.Object r2 = r37.getTag()
            if (r2 == 0) goto L_0x0f5c
            r20 = 12
            r8 = 13
            r16 = 10
            r5 = 8
            r4 = 5
            r9 = 4
            r7 = 3
            r6 = 2
            r3 = 0
            r12 = 1
            r10 = -1
            switch(r0) {
                case 1: goto L_0x0ef4;
                case 2: goto L_0x0e2c;
                case 3: goto L_0x0ded;
                case 4: goto L_0x0d21;
                case 5: goto L_0x0c25;
                case 6: goto L_0x0b8e;
                case 7: goto L_0x0b2c;
                case 8: goto L_0x0a8d;
                case 9: goto L_0x0a3c;
                case 10: goto L_0x09ae;
                case 11: goto L_0x095e;
                case 12: goto L_0x0906;
                case 13: goto L_0x08a8;
                case 14: goto L_0x084a;
                case 15: goto L_0x080a;
                case 16: goto L_0x07c2;
                case 17: goto L_0x078b;
                case 18: goto L_0x0750;
                case 19: goto L_0x0708;
                case 20: goto L_0x06d1;
                case 21: goto L_0x0663;
                case 22: goto L_0x0612;
                case 23: goto L_0x05e0;
                case 24: goto L_0x055d;
                case 25: goto L_0x052a;
                case 26: goto L_0x04da;
                case 27: goto L_0x04a8;
                case 28: goto L_0x038f;
                case 29: goto L_0x0340;
                case 30: goto L_0x0308;
                case 31: goto L_0x02c8;
                case 32: goto L_0x0290;
                case 33: goto L_0x024b;
                case 34: goto L_0x0213;
                case 35: goto L_0x01d3;
                case 36: goto L_0x0178;
                case 37: goto L_0x0144;
                case 38: goto L_0x0102;
                case 39: goto L_0x00b0;
                case 40: goto L_0x007b;
                case 41: goto L_0x002b;
                default: goto L_0x0028;
            }
        L_0x0028:
            r11 = r14
            goto L_0x0f64
        L_0x002b:
            java.lang.String r0 = "layout/transaction_type_group_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x006f
            com.huawei.digitalpayment.customer.homev6.databinding.TransactionTypeGroupBindingImpl r8 = new com.huawei.digitalpayment.customer.homev6.databinding.TransactionTypeGroupBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.TransactionTypeGroupBindingImpl.g
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r14, r0)
            r2 = r0[r9]
            r4 = r2
            androidx.recyclerview.widget.RecyclerView r4 = (androidx.recyclerview.widget.RecyclerView) r4
            r2 = r0[r7]
            r5 = r2
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r2 = r0[r3]
            r7 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r7 = (com.huawei.common.widget.round.RoundConstraintLayout) r7
            r2 = r0[r12]
            r9 = r2
            androidx.constraintlayout.widget.ConstraintLayout r9 = (androidx.constraintlayout.widget.ConstraintLayout) r9
            r0 = r0[r6]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r8
            r1 = r36
            r2 = r37
            r3 = r4
            r4 = r5
            r5 = r7
            r6 = r9
            r7 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r8.f = r10
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r8.c
            r0.setTag(r14)
            r8.setRootTag(r15)
            r8.invalidateAll()
            return r8
        L_0x006f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for transaction_type_group is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x007b:
            java.lang.String r0 = "layout/transaction_type_child_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x00a4
            com.huawei.digitalpayment.customer.homev6.databinding.TransactionTypeChildBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.TransactionTypeChildBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.TransactionTypeChildBindingImpl.c
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r6, r14, r2)
            r3 = r2[r3]
            com.huawei.common.widget.round.RoundLinearLayout r3 = (com.huawei.common.widget.round.RoundLinearLayout) r3
            r2 = r2[r12]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0.<init>(r1, r15, r3)
            r0.b = r10
            com.huawei.common.widget.round.RoundLinearLayout r1 = r0.a
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x00a4:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for transaction_type_child is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x00b0:
            java.lang.String r0 = "layout/transaction_item_records_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x00f6
            com.huawei.digitalpayment.customer.homev6.databinding.TransactionItemRecordsBindingImpl r8 = new com.huawei.digitalpayment.customer.homev6.databinding.TransactionItemRecordsBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.TransactionItemRecordsBindingImpl.f
            r2 = 6
            java.lang.Object[] r13 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r2, r14, r0)
            r0 = r13[r9]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r13[r6]
            r6 = r0
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            r0 = r13[r4]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r13[r12]
            r9 = r0
            android.widget.TextView r9 = (android.widget.TextView) r9
            r0 = r13[r7]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = r8
            r1 = r36
            r2 = r37
            r12 = 0
            r3 = r5
            r4 = r6
            r5 = r9
            r6 = r7
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r8.e = r10
            r0 = r13[r12]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r14)
            r8.setRootTag(r15)
            r8.invalidateAll()
            return r8
        L_0x00f6:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for transaction_item_records is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0102:
            r8 = 0
            java.lang.String r0 = "layout/transaction_filter_type_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0138
            com.huawei.digitalpayment.customer.homev6.databinding.TransactionFilterTypeBindingImpl r9 = new com.huawei.digitalpayment.customer.homev6.databinding.TransactionFilterTypeBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.TransactionFilterTypeBindingImpl.f
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r14, r0)
            r2 = r0[r6]
            r3 = r2
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r2 = r0[r12]
            r4 = r2
            androidx.recyclerview.widget.RecyclerView r4 = (androidx.recyclerview.widget.RecyclerView) r4
            r0 = r0[r8]
            r5 = r0
            android.widget.LinearLayout r5 = (android.widget.LinearLayout) r5
            r0 = r9
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5)
            r9.e = r10
            android.widget.LinearLayout r0 = r9.c
            r0.setTag(r14)
            r9.setRootTag(r15)
            r9.invalidateAll()
            return r9
        L_0x0138:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for transaction_filter_type is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0144:
            r8 = 0
            java.lang.String r0 = "layout/homev6_menu_pop_layout_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x016c
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6MenuPopLayoutBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6MenuPopLayoutBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6MenuPopLayoutBindingImpl.c
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r6, r14, r2)
            r3 = r2[r12]
            com.huawei.common.widget.round.RoundRecyclerView r3 = (com.huawei.common.widget.round.RoundRecyclerView) r3
            r0.<init>(r1, r15, r3)
            r0.b = r10
            r1 = r2[r8]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x016c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_menu_pop_layout is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0178:
            r8 = 0
            java.lang.String r0 = "layout/homev6_life_group_function_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x01c7
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6LifeGroupFunctionBindingImpl r13 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6LifeGroupFunctionBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6LifeGroupFunctionBindingImpl.i
            r3 = 7
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r0)
            r2 = 6
            r2 = r0[r2]
            r3 = r2
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r2 = r0[r4]
            r4 = r2
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r2 = r0[r6]
            r5 = r2
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r2 = r0[r8]
            r6 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r6 = (com.huawei.common.widget.round.RoundConstraintLayout) r6
            r2 = r0[r12]
            r8 = r2
            androidx.constraintlayout.widget.ConstraintLayout r8 = (androidx.constraintlayout.widget.ConstraintLayout) r8
            r2 = r0[r9]
            r9 = r2
            com.huawei.common.widget.round.RoundTextView r9 = (com.huawei.common.widget.round.RoundTextView) r9
            r0 = r0[r7]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r13
            r1 = r36
            r2 = r37
            r7 = r8
            r8 = r9
            r9 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r13.h = r10
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r13.d
            r0.setTag(r14)
            r13.setRootTag(r15)
            r13.invalidateAll()
            return r13
        L_0x01c7:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_life_group_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x01d3:
            r8 = 0
            java.lang.String r0 = "layout/homev6_item_pay_function_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0207
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemPayFunctionBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemPayFunctionBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemPayFunctionBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r14, r2)
            r3 = r2[r12]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r9]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r6]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r3 = r2[r7]
            android.view.View r3 = (android.view.View) r3
            r0.<init>(r1, r15, r8)
            r0.a = r10
            r1 = r2[r8]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0207:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_item_pay_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0213:
            r8 = 0
            java.lang.String r0 = "layout/homev6_item_menu_pop_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x023f
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemMenuPopBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemMenuPopBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemMenuPopBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r14, r2)
            r3 = r2[r12]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r4 = r2[r6]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0.<init>(r1, r15, r3, r4)
            r0.c = r10
            r1 = r2[r8]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x023f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_item_menu_pop is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x024b:
            r8 = 0
            java.lang.String r0 = "layout/homev6_item_home_popular_service_function_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0284
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemHomePopularServiceFunctionBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemHomePopularServiceFunctionBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemHomePopularServiceFunctionBindingImpl.b
            r3 = 6
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r2)
            r3 = r2[r6]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r12]
            com.huawei.common.widget.round.RoundConstraintLayout r3 = (com.huawei.common.widget.round.RoundConstraintLayout) r3
            r3 = r2[r9]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r4]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r3 = r2[r7]
            android.view.View r3 = (android.view.View) r3
            r0.<init>(r1, r15, r8)
            r0.a = r10
            r1 = r2[r8]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0284:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_item_home_popular_service_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0290:
            r8 = 0
            java.lang.String r0 = "layout/homev6_item_banner_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x02bc
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemBannerBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemBannerBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemBannerBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r14, r2)
            r3 = r2[r6]
            com.huawei.common.widget.banner.CycleViewPager r3 = (com.huawei.common.widget.banner.CycleViewPager) r3
            r4 = r2[r12]
            android.view.View r4 = (android.view.View) r4
            r0.<init>(r1, r15, r3, r4)
            r0.c = r10
            r1 = r2[r8]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x02bc:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_item_banner is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x02c8:
            r8 = 0
            java.lang.String r0 = "layout/homev6_item_apps_function_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x02fc
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemAppsFunctionBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemAppsFunctionBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6ItemAppsFunctionBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r14, r2)
            r3 = r2[r12]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r9]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r6]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r3 = r2[r7]
            android.view.View r3 = (android.view.View) r3
            r0.<init>(r1, r15, r8)
            r0.a = r10
            r1 = r2[r8]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x02fc:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_item_apps_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0308:
            r8 = 0
            java.lang.String r0 = "layout/homev6_home_title_bar_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0334
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r14, r2)
            r3 = r2[r6]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r4 = r2[r12]
            androidx.appcompat.widget.AppCompatTextView r4 = (androidx.appcompat.widget.AppCompatTextView) r4
            r0.<init>(r1, r15, r3, r4)
            r0.c = r10
            r1 = r2[r8]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0334:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_home_title_bar is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0340:
            r8 = 0
            java.lang.String r0 = "layout/homev6_home_popular_services_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0383
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomePopularServicesBindingImpl r13 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomePopularServicesBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomePopularServicesBindingImpl.g
            r2 = 6
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r2, r14, r0)
            r0 = r16[r4]
            r3 = r0
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r0 = r16[r9]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = r16[r6]
            r5 = r0
            com.huawei.common.widget.round.RoundTextView r5 = (com.huawei.common.widget.round.RoundTextView) r5
            r0 = r16[r12]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r16[r7]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = r13
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r13.f = r10
            r0 = r16[r8]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0.setTag(r14)
            r13.setRootTag(r15)
            r13.invalidateAll()
            return r13
        L_0x0383:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_home_popular_services is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x038f:
            r3 = 7
            java.lang.String r0 = "layout/homev6_home_header_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x049c
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBindingImpl r2 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBindingImpl.C
            r3 = 33
            java.lang.Object[] r30 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r0)
            r0 = r30[r6]
            android.view.View r0 = (android.view.View) r0
            r0 = 27
            r0 = r30[r0]
            androidx.constraintlayout.widget.Guideline r0 = (androidx.constraintlayout.widget.Guideline) r0
            r0 = r30[r12]
            r3 = r0
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r0 = 7
            r4 = r30[r4]
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r5 = r30[r5]
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r5 = 22
            r5 = r30[r5]
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r6 = 30
            r6 = r30[r6]
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            r12 = 29
            r12 = r30[r12]
            android.widget.ImageView r12 = (android.widget.ImageView) r12
            r0 = 3
            r7 = r12
            r8 = r30[r8]
            android.widget.ImageView r8 = (android.widget.ImageView) r8
            r12 = 25
            r12 = r30[r12]
            android.widget.ImageView r12 = (android.widget.ImageView) r12
            r14 = 4
            r9 = r12
            r12 = 17
            r12 = r30[r12]
            android.widget.ImageView r12 = (android.widget.ImageView) r12
            r11 = 6
            r10 = r12
            r12 = 26
            r12 = r30[r12]
            com.huawei.common.widget.round.RoundImageView r12 = (com.huawei.common.widget.round.RoundImageView) r12
            r13 = 6
            r11 = r12
            r12 = r30[r13]
            android.widget.LinearLayout r12 = (android.widget.LinearLayout) r12
            r13 = 9
            r0 = r30[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r1 = 9
            r13 = r0
            r0 = r30[r14]
            r14 = r0
            android.widget.TextView r14 = (android.widget.TextView) r14
            r0 = 0
            r1 = r30[r1]
            android.widget.TextView r1 = (android.widget.TextView) r1
            r15 = r1
            r1 = r30[r16]
            android.widget.TextView r1 = (android.widget.TextView) r1
            r1 = 20
            r1 = r30[r1]
            r16 = r1
            android.widget.TextView r16 = (android.widget.TextView) r16
            r1 = 21
            r1 = r30[r1]
            r17 = r1
            android.widget.TextView r17 = (android.widget.TextView) r17
            r1 = 7
            r1 = r30[r1]
            r18 = r1
            com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView r18 = (com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView) r18
            r1 = 11
            r1 = r30[r1]
            r19 = r1
            android.widget.TextView r19 = (android.widget.TextView) r19
            r1 = r30[r20]
            r20 = r1
            android.widget.TextView r20 = (android.widget.TextView) r20
            r1 = 14
            r1 = r30[r1]
            r21 = r1
            android.widget.TextView r21 = (android.widget.TextView) r21
            r1 = 15
            r1 = r30[r1]
            r22 = r1
            android.widget.TextView r22 = (android.widget.TextView) r22
            r1 = 31
            r1 = r30[r1]
            r23 = r1
            com.huawei.common.widget.round.RoundTextView r23 = (com.huawei.common.widget.round.RoundTextView) r23
            r1 = 23
            r1 = r30[r1]
            r24 = r1
            android.widget.TextView r24 = (android.widget.TextView) r24
            r1 = 24
            r1 = r30[r1]
            r25 = r1
            android.widget.TextView r25 = (android.widget.TextView) r25
            r1 = 28
            r1 = r30[r1]
            r26 = r1
            com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView r26 = (com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView) r26
            r1 = 16
            r1 = r30[r1]
            r27 = r1
            android.widget.TextView r27 = (android.widget.TextView) r27
            r1 = 18
            r1 = r30[r1]
            r28 = r1
            android.widget.TextView r28 = (android.widget.TextView) r28
            r1 = 19
            r1 = r30[r1]
            r29 = r1
            android.widget.TextView r29 = (android.widget.TextView) r29
            r1 = 32
            r1 = r30[r1]
            android.view.View r1 = (android.view.View) r1
            r1 = r0
            r0 = r2
            r1 = r36
            r31 = r2
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29)
            r0 = r31
            r10 = -1
            r0.B = r10
            r15 = 0
            r1 = r30[r15]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r9 = 0
            r1.setTag(r9)
            r8 = r37
            r0.setRootTag(r8)
            r0.invalidateAll()
            return r0
        L_0x049c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_home_header is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x04a8:
            r9 = r14
            r8 = r15
            r15 = 0
            java.lang.String r0 = "layout/homev6_home_footer_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x04ce
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeFooterBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeFooterBindingImpl
            r7 = r36
            java.lang.Object[] r1 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r12, r9, r9)
            r0.<init>(r7, r8, r15)
            r0.a = r10
            r1 = r1[r15]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r9)
            r0.setRootTag(r8)
            r0.invalidateAll()
            return r0
        L_0x04ce:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_home_footer is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x04da:
            r7 = r1
            r9 = r14
            r8 = r15
            r0 = 3
            r14 = 4
            r15 = 0
            java.lang.String r1 = "layout/homev6_fragment_apps_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x051e
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6FragmentAppsBindingImpl r13 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6FragmentAppsBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6FragmentAppsBindingImpl.e
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6FragmentAppsBindingImpl.f
            java.lang.Object[] r14 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r14, r1, r2)
            r0 = r14[r0]
            r3 = r0
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r0 = r14[r12]
            r4 = r0
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding r4 = (com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding) r4
            r0 = r14[r6]
            r5 = r0
            android.view.View r5 = (android.view.View) r5
            r0 = r13
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5)
            r13.d = r10
            r0 = r14[r15]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r9)
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding r0 = r13.b
            r13.setContainedBinding(r0)
            r13.setRootTag(r8)
            r13.invalidateAll()
            return r13
        L_0x051e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_fragment_apps is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x052a:
            r7 = r1
            r9 = r14
            r8 = r15
            r15 = 0
            java.lang.String r0 = "layout/homev6_apps_group_function_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0551
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6AppsGroupFunctionBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6AppsGroupFunctionBindingImpl
            java.lang.Object[] r1 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r12, r9, r9)
            r1 = r1[r15]
            androidx.recyclerview.widget.RecyclerView r1 = (androidx.recyclerview.widget.RecyclerView) r1
            r0.<init>(r7, r8, r1)
            r0.b = r10
            androidx.recyclerview.widget.RecyclerView r1 = r0.a
            r1.setTag(r9)
            r0.setRootTag(r8)
            r0.invalidateAll()
            return r0
        L_0x0551:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_apps_group_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x055d:
            r7 = r1
            r9 = r14
            r8 = r15
            r0 = 3
            r1 = 9
            r3 = 11
            r10 = 7
            r13 = 6
            r14 = 4
            r15 = 0
            java.lang.String r11 = "layout/homev6_activity_search_0"
            boolean r11 = r11.equals(r2)
            if (r11 == 0) goto L_0x05d4
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6ActivitySearchBindingImpl r11 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev6ActivitySearchBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev6ActivitySearchBindingImpl.j
            java.lang.Object[] r17 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r3, r9, r2)
            r2 = r17[r13]
            r3 = r2
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r0 = r17[r0]
            r13 = r0
            android.widget.EditText r13 = (android.widget.EditText) r13
            r0 = r17[r10]
            r10 = r0
            com.huawei.digitalpayment.customer.homev6.widget.tag.TagFlowLayout r10 = (com.huawei.digitalpayment.customer.homev6.widget.tag.TagFlowLayout) r10
            r0 = r17[r4]
            r18 = r0
            android.widget.TextView r18 = (android.widget.TextView) r18
            r0 = r17[r14]
            r14 = r0
            android.widget.ImageView r14 = (android.widget.ImageView) r14
            r0 = r17[r5]
            r19 = r0
            androidx.recyclerview.widget.RecyclerView r19 = (androidx.recyclerview.widget.RecyclerView) r19
            r0 = r17[r16]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r17[r1]
            r16 = r0
            androidx.constraintlayout.widget.ConstraintLayout r16 = (androidx.constraintlayout.widget.ConstraintLayout) r16
            r0 = r17[r12]
            r12 = r0
            android.widget.ImageView r12 = (android.widget.ImageView) r12
            r0 = r17[r6]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r11
            r1 = r36
            r2 = r37
            r4 = r13
            r5 = r10
            r6 = r18
            r7 = r14
            r13 = r8
            r8 = r19
            r14 = r9
            r9 = r16
            r14 = -1
            r10 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
            r11.i = r14
            r0 = 0
            r0 = r17[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r1 = 0
            r0.setTag(r1)
            r11.setRootTag(r13)
            r11.invalidateAll()
            return r11
        L_0x05d4:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev6_activity_search is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x05e0:
            r7 = r1
            r13 = r15
            r14 = r10
            java.lang.String r0 = "layout/homev5_my_login_out_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0606
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5MyLoginOutBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5MyLoginOutBindingImpl
            r1 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r7, r13, r12, r1, r1)
            r3 = 0
            r0.<init>(r7, r13, r3)
            r0.b = r14
            r2 = r2[r3]
            com.huawei.common.widget.round.RoundTextView r2 = (com.huawei.common.widget.round.RoundTextView) r2
            r2.setTag(r1)
            r0.setRootTag(r13)
            r0.invalidateAll()
            return r0
        L_0x0606:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_my_login_out is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0612:
            r7 = r1
            r13 = r15
            r0 = 3
            r33 = r10
            r11 = r14
            r14 = r33
            java.lang.String r1 = "layout/homev5_life_group_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0657
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5LifeGroupFunctionBindingImpl r8 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5LifeGroupFunctionBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5LifeGroupFunctionBindingImpl.f
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r7, r13, r4, r11, r1)
            r1 = r10[r9]
            r3 = r1
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r0 = r10[r0]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = r10[r6]
            r5 = r0
            com.huawei.common.widget.round.RoundTextView r5 = (com.huawei.common.widget.round.RoundTextView) r5
            r0 = r10[r12]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r8
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r8.e = r14
            r0 = 0
            r0 = r10[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0.setTag(r11)
            r8.setRootTag(r13)
            r8.invalidateAll()
            return r8
        L_0x0657:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_life_group_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0663:
            r7 = r1
            r8 = r15
            r0 = 3
            r13 = 6
            r33 = r10
            r11 = r14
            r14 = r33
            r10 = 7
            java.lang.String r1 = "layout/homev5_item_my_function_item_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x06c5
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemMyFunctionItemBindingImpl r3 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemMyFunctionItemBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemMyFunctionItemBindingImpl.i
            java.lang.Object[] r1 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r5, r11, r1)
            r2 = r1[r9]
            r5 = r2
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r2 = r1[r12]
            r9 = r2
            android.widget.ImageView r9 = (android.widget.ImageView) r9
            r2 = r1[r10]
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            r0 = r1[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0 = 0
            r0 = r1[r0]
            r10 = r0
            android.widget.RelativeLayout r10 = (android.widget.RelativeLayout) r10
            r0 = r1[r13]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r1[r4]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r1[r6]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = r3
            r1 = r36
            r2 = r37
            r7 = r3
            r3 = r5
            r4 = r9
            r5 = r10
            r6 = r12
            r9 = r7
            r7 = r13
            r10 = r8
            r8 = r16
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r9.h = r14
            android.widget.RelativeLayout r0 = r9.c
            r0.setTag(r11)
            r9.setRootTag(r10)
            r9.invalidateAll()
            return r9
        L_0x06c5:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_my_function_item is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x06d1:
            r7 = r1
            r33 = r10
            r11 = r14
            r10 = r15
            r14 = r33
            java.lang.String r0 = "layout/homev5_item_my_function_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x06fc
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemMyFunctionBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemMyFunctionBindingImpl
            java.lang.Object[] r1 = androidx.databinding.ViewDataBinding.mapBindings(r7, r10, r12, r11, r11)
            r2 = 0
            r1 = r1[r2]
            com.huawei.common.widget.round.RoundRecyclerView r1 = (com.huawei.common.widget.round.RoundRecyclerView) r1
            r0.<init>(r7, r10, r1)
            r0.c = r14
            com.huawei.common.widget.round.RoundRecyclerView r1 = r0.a
            r1.setTag(r11)
            r0.setRootTag(r10)
            r0.invalidateAll()
            return r0
        L_0x06fc:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_my_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0708:
            r7 = r1
            r0 = 3
            r33 = r10
            r11 = r14
            r10 = r15
            r14 = r33
            java.lang.String r1 = "layout/homev5_item_life_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0744
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemLifeFunctionBindingImpl r1 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemLifeFunctionBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemLifeFunctionBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r7, r10, r4, r11, r2)
            r3 = r2[r12]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r9]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r6]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = r2[r0]
            android.view.View r0 = (android.view.View) r0
            r0 = 0
            r1.<init>(r7, r10, r0)
            r1.a = r14
            r0 = r2[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r1.setRootTag(r10)
            r1.invalidateAll()
            return r1
        L_0x0744:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_life_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0750:
            r7 = r1
            r33 = r10
            r11 = r14
            r10 = r15
            r14 = r33
            java.lang.String r0 = "layout/homev5_item_life_banner_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x077f
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemLifeBannerBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemLifeBannerBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemLifeBannerBindingImpl.c
            java.lang.Object[] r1 = androidx.databinding.ViewDataBinding.mapBindings(r7, r10, r6, r11, r1)
            r2 = r1[r12]
            com.huawei.common.widget.banner.CycleViewPager r2 = (com.huawei.common.widget.banner.CycleViewPager) r2
            r0.<init>(r7, r10, r2)
            r0.b = r14
            r2 = 0
            r1 = r1[r2]
            android.widget.FrameLayout r1 = (android.widget.FrameLayout) r1
            r1.setTag(r11)
            r0.setRootTag(r10)
            r0.invalidateAll()
            return r0
        L_0x077f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_life_banner is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x078b:
            r7 = r1
            r33 = r10
            r11 = r14
            r10 = r15
            r14 = r33
            java.lang.String r0 = "layout/homev5_item_home_pin_group_function_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x07b6
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomePinGroupFunctionBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomePinGroupFunctionBindingImpl
            java.lang.Object[] r1 = androidx.databinding.ViewDataBinding.mapBindings(r7, r10, r12, r11, r11)
            r2 = 0
            r1 = r1[r2]
            com.huawei.common.widget.round.RoundRecyclerView r1 = (com.huawei.common.widget.round.RoundRecyclerView) r1
            r0.<init>(r7, r10, r1)
            r0.b = r14
            com.huawei.common.widget.round.RoundRecyclerView r1 = r0.a
            r1.setTag(r11)
            r0.setRootTag(r10)
            r0.invalidateAll()
            return r0
        L_0x07b6:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_home_pin_group_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x07c2:
            r7 = r1
            r0 = 3
            r33 = r10
            r11 = r14
            r10 = r15
            r14 = r33
            java.lang.String r1 = "layout/homev5_item_home_life_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x07fe
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeLifeFunctionBindingImpl r1 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeLifeFunctionBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeLifeFunctionBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r7, r10, r4, r11, r2)
            r3 = r2[r12]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r9]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r6]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = r2[r0]
            android.view.View r0 = (android.view.View) r0
            r0 = 0
            r1.<init>(r7, r10, r0)
            r1.a = r14
            r0 = r2[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r1.setRootTag(r10)
            r1.invalidateAll()
            return r1
        L_0x07fe:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_home_life_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x080a:
            r7 = r1
            r0 = 3
            r33 = r10
            r11 = r14
            r10 = r15
            r14 = r33
            java.lang.String r1 = "layout/homev5_item_home_head_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x083e
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeHeadFunctionBindingImpl r1 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeHeadFunctionBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeHeadFunctionBindingImpl.b
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r7, r10, r0, r11, r2)
            r2 = r0[r12]
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            r2 = r0[r6]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = 0
            r1.<init>(r7, r10, r2)
            r1.a = r14
            r0 = r0[r2]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r1.setRootTag(r10)
            r1.invalidateAll()
            return r1
        L_0x083e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_home_head_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x084a:
            r7 = r1
            r8 = r15
            r0 = 3
            r13 = 6
            r33 = r10
            r11 = r14
            r14 = r33
            r10 = 7
            java.lang.String r1 = "layout/homev5_item_home_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x089c
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFunctionBindingImpl r5 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFunctionBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFunctionBindingImpl.g
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r10, r11, r1)
            r1 = r10[r6]
            r3 = r1
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r1 = r10[r12]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1 = r10[r4]
            r4 = r1
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0 = r10[r0]
            r6 = r0
            com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView r6 = (com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView) r6
            r0 = r10[r13]
            r12 = r0
            com.huawei.common.widget.round.RoundTextView r12 = (com.huawei.common.widget.round.RoundTextView) r12
            r0 = r10[r9]
            android.view.View r0 = (android.view.View) r0
            r0 = r5
            r1 = r36
            r2 = r37
            r7 = r5
            r5 = r6
            r6 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.f = r14
            r0 = 0
            r0 = r10[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r7.setRootTag(r8)
            r7.invalidateAll()
            return r7
        L_0x089c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_home_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x08a8:
            r7 = r1
            r8 = r15
            r0 = 3
            r13 = 6
            r33 = r10
            r11 = r14
            r14 = r33
            r10 = 7
            java.lang.String r1 = "layout/homev5_item_home_favorite_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x08fa
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFavoriteFunctionBindingImpl r5 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFavoriteFunctionBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeFavoriteFunctionBindingImpl.g
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r10, r11, r1)
            r1 = r10[r6]
            r3 = r1
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r1 = r10[r12]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1 = r10[r4]
            r4 = r1
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0 = r10[r0]
            r6 = r0
            com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView r6 = (com.huawei.digitalpayment.customer.homev6.widget.MarqueeTextView) r6
            r0 = r10[r13]
            r12 = r0
            com.huawei.common.widget.round.RoundTextView r12 = (com.huawei.common.widget.round.RoundTextView) r12
            r0 = r10[r9]
            android.view.View r0 = (android.view.View) r0
            r0 = r5
            r1 = r36
            r2 = r37
            r7 = r5
            r5 = r6
            r6 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.f = r14
            r0 = 0
            r0 = r10[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r7.setRootTag(r8)
            r7.invalidateAll()
            return r7
        L_0x08fa:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_home_favorite_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0906:
            r7 = r1
            r8 = r15
            r0 = 3
            r13 = 6
            r33 = r10
            r11 = r14
            r14 = r33
            java.lang.String r1 = "layout/homev5_item_home_edit_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0952
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeEditFunctionBindingImpl r10 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeEditFunctionBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemHomeEditFunctionBindingImpl.f
            java.lang.Object[] r1 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r13, r11, r1)
            r2 = r1[r4]
            r3 = r2
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r0 = r1[r0]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = r1[r9]
            com.huawei.payment.NestedScrollableHost r0 = (com.huawei.payment.NestedScrollableHost) r0
            r0 = 0
            r0 = r1[r0]
            r5 = r0
            com.huawei.common.widget.round.RoundConstraintLayout r5 = (com.huawei.common.widget.round.RoundConstraintLayout) r5
            r0 = r1[r6]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r1[r12]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r10
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r10.e = r14
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r10.c
            r0.setTag(r11)
            r10.setRootTag(r8)
            r10.invalidateAll()
            return r10
        L_0x0952:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_home_edit_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x095e:
            r7 = r1
            r8 = r15
            r0 = 3
            r33 = r10
            r11 = r14
            r14 = r33
            java.lang.String r1 = "layout/homev5_item_edit_favorite_function_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x09a2
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemEditFavoriteFunctionBindingImpl r10 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemEditFavoriteFunctionBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ItemEditFavoriteFunctionBindingImpl.f
            java.lang.Object[] r13 = androidx.databinding.ViewDataBinding.mapBindings(r7, r8, r4, r11, r1)
            r1 = r13[r12]
            r3 = r1
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r1 = r13[r6]
            r4 = r1
            com.huawei.common.widget.round.RoundImageView r4 = (com.huawei.common.widget.round.RoundImageView) r4
            r1 = r13[r9]
            r5 = r1
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r13[r0]
            android.view.View r0 = (android.view.View) r0
            r0 = r10
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5)
            r10.e = r14
            r0 = 0
            r0 = r13[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0.setTag(r11)
            r10.setRootTag(r8)
            r10.invalidateAll()
            return r10
        L_0x09a2:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_item_edit_favorite_function is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x09ae:
            r7 = r1
            r11 = r14
            r14 = r15
            r0 = 3
            r1 = 9
            r3 = 11
            r10 = 7
            r13 = 6
            java.lang.String r15 = "layout/homev5_fragment_my_0"
            boolean r15 = r15.equals(r2)
            if (r15 == 0) goto L_0x0a30
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentMyBindingImpl r15 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentMyBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentMyBindingImpl.k
            android.util.SparseIntArray r11 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentMyBindingImpl.l
            java.lang.Object[] r17 = androidx.databinding.ViewDataBinding.mapBindings(r7, r14, r8, r2, r11)
            r0 = r17[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = r17[r1]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r17[r10]
            r8 = r0
            com.huawei.common.widget.round.RoundTextView r8 = (com.huawei.common.widget.round.RoundTextView) r8
            r0 = r17[r4]
            r4 = r0
            com.huawei.common.widget.round.RoundImageView r4 = (com.huawei.common.widget.round.RoundImageView) r4
            r0 = r17[r9]
            com.huawei.common.widget.round.RoundImageView r0 = (com.huawei.common.widget.round.RoundImageView) r0
            r0 = r17[r3]
            r9 = r0
            com.huawei.common.widget.round.RoundImageView r9 = (com.huawei.common.widget.round.RoundImageView) r9
            r0 = r17[r20]
            r10 = r0
            androidx.appcompat.widget.LinearLayoutCompat r10 = (androidx.appcompat.widget.LinearLayoutCompat) r10
            r0 = r17[r12]
            r11 = r0
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding r11 = (com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding) r11
            r0 = r17[r13]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r17[r5]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r17[r16]
            r16 = r0
            android.view.View r16 = (android.view.View) r16
            r0 = r17[r6]
            r18 = r0
            android.view.View r18 = (android.view.View) r18
            r0 = r15
            r1 = r36
            r2 = r37
            r3 = r8
            r5 = r9
            r6 = r10
            r7 = r11
            r8 = r12
            r9 = r13
            r10 = r16
            r13 = 0
            r11 = r18
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            r0 = -1
            r15.j = r0
            r0 = 0
            r0 = r17[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r13)
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding r0 = r15.e
            r15.setContainedBinding(r0)
            r15.setRootTag(r14)
            r15.invalidateAll()
            return r15
        L_0x0a30:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_fragment_my is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0a3c:
            r7 = r1
            r13 = r14
            r14 = r15
            r0 = 3
            java.lang.String r1 = "layout/homev5_fragment_life_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0a81
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentLifeBindingImpl r8 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentLifeBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentLifeBindingImpl.e
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentLifeBindingImpl.f
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r7, r14, r9, r1, r2)
            r0 = r9[r0]
            r3 = r0
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r0 = r9[r12]
            r4 = r0
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding r4 = (com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding) r4
            r0 = r9[r6]
            r5 = r0
            android.view.View r5 = (android.view.View) r5
            r0 = r8
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5)
            r0 = -1
            r8.d = r0
            r0 = 0
            r0 = r9[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r13)
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeTitleBarBinding r0 = r8.b
            r8.setContainedBinding(r0)
            r8.setRootTag(r14)
            r8.invalidateAll()
            return r8
        L_0x0a81:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_fragment_life is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0a8d:
            r7 = r1
            r11 = r14
            r14 = r15
            r0 = 3
            r1 = 9
            r10 = 7
            r13 = 6
            java.lang.String r3 = "layout/homev5_fragment_home_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x0b20
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentHomeBindingImpl r15 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentHomeBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r2 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentHomeBindingImpl.h
            android.util.SparseIntArray r3 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5FragmentHomeBindingImpl.i
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r7, r14, r1, r2, r3)
            r1 = r16[r9]
            r3 = r1
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeFooterBinding r3 = (com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeFooterBinding) r3
            r0 = r16[r0]
            r8 = r0
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBinding r8 = (com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBinding) r8
            r0 = r16[r10]
            r9 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r9 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r9
            r0 = r16[r13]
            r10 = r0
            com.scwang.smart.refresh.layout.SmartRefreshLayout r10 = (com.scwang.smart.refresh.layout.SmartRefreshLayout) r10
            r0 = r16[r5]
            r13 = r0
            com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView r13 = (com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView) r13
            r0 = r16[r4]
            r17 = r0
            android.view.View r17 = (android.view.View) r17
            r0 = r15
            r1 = r36
            r2 = r37
            r4 = r8
            r5 = r9
            r18 = 2
            r6 = r10
            r7 = r13
            r8 = r17
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r0 = -1
            r15.g = r0
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeFooterBinding r0 = r15.a
            r15.setContainedBinding(r0)
            com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBinding r0 = r15.b
            r15.setContainedBinding(r0)
            r0 = 0
            r0 = r16[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r0 = r16[r12]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r11)
            r0 = r16[r18]
            if (r0 == 0) goto L_0x0b19
            android.view.View r0 = (android.view.View) r0
            r1 = r0
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.viewStatusBar
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x0b05
            goto L_0x0b19
        L_0x0b05:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x0b19:
            r15.setRootTag(r14)
            r15.invalidateAll()
            return r15
        L_0x0b20:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_fragment_home is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0b2c:
            r7 = r1
            r11 = r14
            r14 = r15
            r0 = 3
            r10 = 7
            r13 = 6
            r18 = 2
            java.lang.String r1 = "layout/homev5_activity_home_0"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0b82
            com.huawei.digitalpayment.customer.homev6.databinding.Homev5ActivityHomeBindingImpl r15 = new com.huawei.digitalpayment.customer.homev6.databinding.Homev5ActivityHomeBindingImpl
            android.util.SparseIntArray r1 = com.huawei.digitalpayment.customer.homev6.databinding.Homev5ActivityHomeBindingImpl.h
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r7, r14, r10, r11, r1)
            r1 = r10[r13]
            r3 = r1
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r1 = r10[r9]
            r5 = r1
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r0 = r10[r0]
            r6 = r0
            android.view.View r6 = (android.view.View) r6
            r0 = r10[r4]
            r8 = r0
            android.widget.LinearLayout r8 = (android.widget.LinearLayout) r8
            r0 = r10[r18]
            r9 = r0
            android.widget.LinearLayout r9 = (android.widget.LinearLayout) r9
            r0 = r10[r12]
            r12 = r0
            androidx.viewpager2.widget.ViewPager2 r12 = (androidx.viewpager2.widget.ViewPager2) r12
            r0 = r15
            r1 = r36
            r2 = r37
            r4 = r5
            r5 = r6
            r6 = r8
            r7 = r9
            r8 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r0 = -1
            r15.g = r0
            r0 = 0
            r0 = r10[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r15.setRootTag(r14)
            r15.invalidateAll()
            return r15
        L_0x0b82:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for homev5_activity_home is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0b8e:
            r7 = r1
            r14 = r15
            java.lang.String r0 = "layout/home_edit_function_activity_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0c19
            com.huawei.digitalpayment.customer.homev6.databinding.HomeEditFunctionActivityBindingImpl r9 = new com.huawei.digitalpayment.customer.homev6.databinding.HomeEditFunctionActivityBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.HomeEditFunctionActivityBindingImpl.h
            r1 = 16
            r10 = 0
            java.lang.Object[] r11 = androidx.databinding.ViewDataBinding.mapBindings(r7, r14, r1, r10, r0)
            r0 = 1
            r0 = r11[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0 = 13
            r0 = r11[r0]
            r3 = r0
            android.widget.EditText r3 = (android.widget.EditText) r3
            r0 = 6
            r0 = r11[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = 14
            r0 = r11[r0]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = 2
            r0 = r11[r0]
            r5 = r0
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r0 = 5
            r0 = r11[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = 8
            r0 = r11[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = 10
            r0 = r11[r0]
            r6 = r0
            androidx.recyclerview.widget.RecyclerView r6 = (androidx.recyclerview.widget.RecyclerView) r6
            r0 = 15
            r0 = r11[r0]
            r8 = r0
            androidx.recyclerview.widget.RecyclerView r8 = (androidx.recyclerview.widget.RecyclerView) r8
            r0 = 12
            r0 = r11[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = 3
            r0 = r11[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 7
            r0 = r11[r0]
            com.huawei.common.widget.round.RoundTextView r0 = (com.huawei.common.widget.round.RoundTextView) r0
            r0 = 9
            r0 = r11[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 11
            r0 = r11[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 4
            r0 = r11[r0]
            r12 = r0
            com.huawei.common.widget.round.RoundTextView r12 = (com.huawei.common.widget.round.RoundTextView) r12
            r0 = r9
            r1 = r36
            r2 = r37
            r7 = r8
            r8 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r0 = -1
            r9.g = r0
            r0 = 0
            r0 = r11[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r10)
            r9.setRootTag(r14)
            r9.invalidateAll()
            return r9
        L_0x0c19:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for home_edit_function_activity is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0c25:
            r7 = r1
            r14 = r15
            java.lang.String r0 = "layout/fragment_transaction_send_graph_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0d15
            com.huawei.digitalpayment.customer.homev6.databinding.FragmentTransactionSendGraphBindingImpl r8 = new com.huawei.digitalpayment.customer.homev6.databinding.FragmentTransactionSendGraphBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.FragmentTransactionSendGraphBindingImpl.h
            r1 = 8
            r9 = 0
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r7, r14, r1, r9, r0)
            r0 = 6
            r0 = r10[r0]
            r3 = r0
            com.huawei.digitalpayment.customer.homev6.transactionhistory.chartview.BarViewMine r3 = (com.huawei.digitalpayment.customer.homev6.transactionhistory.chartview.BarViewMine) r3
            r0 = 5
            r0 = r10[r0]
            r4 = r0
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r0 = 4
            r0 = r10[r0]
            r5 = r0
            com.huawei.common.widget.round.RoundTextView r5 = (com.huawei.common.widget.round.RoundTextView) r5
            r0 = 3
            r0 = r10[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 2
            r0 = r10[r0]
            if (r0 == 0) goto L_0x0cea
            android.view.View r0 = (android.view.View) r0
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.chartview
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r17 = r2
            com.huawei.digitalpayment.customer.homev6.transactionhistory.chartview.MineChartView r17 = (com.huawei.digitalpayment.customer.homev6.transactionhistory.chartview.MineChartView) r17
            if (r17 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.creditTv
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r18 = r2
            com.huawei.common.widget.round.RoundTextView r18 = (com.huawei.common.widget.round.RoundTextView) r18
            if (r18 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.dateFilter
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r19 = r2
            com.huawei.common.widget.round.RoundLinearLayout r19 = (com.huawei.common.widget.round.RoundLinearLayout) r19
            if (r19 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.dateTV
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r20 = r2
            android.widget.TextView r20 = (android.widget.TextView) r20
            if (r20 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.debitTV
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r21 = r2
            com.huawei.common.widget.round.RoundTextView r21 = (com.huawei.common.widget.round.RoundTextView) r21
            if (r21 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.monthlyConsumption
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.mountUnit
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r22 = r2
            android.widget.TextView r22 = (android.widget.TextView) r22
            if (r22 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.totalAmount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r23 = r2
            android.widget.TextView r23 = (android.widget.TextView) r23
            if (r23 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.totalAmountTv
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x0cd6
            int r1 = com.huawei.digitalpayment.customer.homev6.R$id.transactionTop
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundConstraintLayout r2 = (com.huawei.common.widget.round.RoundConstraintLayout) r2
            if (r2 == 0) goto L_0x0cd6
            com.huawei.digitalpayment.customer.homev6.databinding.FragmentMonthlyConsumptionBinding r1 = new com.huawei.digitalpayment.customer.homev6.databinding.FragmentMonthlyConsumptionBinding
            r16 = r0
            android.widget.FrameLayout r16 = (android.widget.FrameLayout) r16
            r15 = r1
            r15.<init>(r16, r17, r18, r19, r20, r21, r22, r23)
            r6 = r1
            goto L_0x0ceb
        L_0x0cd6:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x0cea:
            r6 = r9
        L_0x0ceb:
            r0 = 7
            r0 = r10[r0]
            r11 = r0
            androidx.recyclerview.widget.RecyclerView r11 = (androidx.recyclerview.widget.RecyclerView) r11
            r0 = r8
            r1 = r36
            r2 = r37
            r7 = r11
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r0 = -1
            r8.g = r0
            r0 = 0
            r0 = r10[r0]
            androidx.core.widget.NestedScrollView r0 = (androidx.core.widget.NestedScrollView) r0
            r0.setTag(r9)
            r0 = 1
            r0 = r10[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r9)
            r8.setRootTag(r14)
            r8.invalidateAll()
            return r8
        L_0x0d15:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for fragment_transaction_send_graph is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0d21:
            r7 = r1
            r14 = r15
            java.lang.String r0 = "layout/fragment_transaction_report_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0de1
            com.huawei.digitalpayment.customer.homev6.databinding.FragmentTransactionReportBindingImpl r2 = new com.huawei.digitalpayment.customer.homev6.databinding.FragmentTransactionReportBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.FragmentTransactionReportBindingImpl.r
            r1 = 22
            r15 = 0
            java.lang.Object[] r18 = androidx.databinding.ViewDataBinding.mapBindings(r7, r14, r1, r15, r0)
            r0 = 12
            r0 = r18[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0 = 14
            r0 = r18[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = 8
            r0 = r18[r0]
            r3 = r0
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0 = 2
            r0 = r18[r0]
            r4 = r0
            com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView r4 = (com.huawei.digitalpayment.customer.viewlib.pagerMarquee.MarqueeTextView) r4
            r0 = 21
            r0 = r18[r0]
            r5 = r0
            androidx.recyclerview.widget.RecyclerView r5 = (androidx.recyclerview.widget.RecyclerView) r5
            r0 = 7
            r0 = r18[r0]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = 3
            r0 = r18[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r1 = r7
            r7 = r0
            r0 = 4
            r0 = r18[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = 10
            r0 = r18[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 1
            r0 = r18[r0]
            r8 = r0
            com.huawei.common.widget.round.RoundConstraintLayout r8 = (com.huawei.common.widget.round.RoundConstraintLayout) r8
            r0 = 5
            r0 = r18[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = 6
            r0 = r18[r0]
            r9 = r0
            android.widget.LinearLayout r9 = (android.widget.LinearLayout) r9
            r0 = 9
            r0 = r18[r0]
            r10 = r0
            android.widget.LinearLayout r10 = (android.widget.LinearLayout) r10
            r0 = 11
            r0 = r18[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 13
            r0 = r18[r0]
            r11 = r0
            android.widget.TextView r11 = (android.widget.TextView) r11
            r0 = 15
            r0 = r18[r0]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = 17
            r0 = r18[r0]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = 19
            r0 = r18[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r14 = r0
            r0 = 16
            r0 = r18[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r15 = r0
            r0 = 18
            r0 = r18[r0]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = 20
            r0 = r18[r0]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = r2
            r1 = r36
            r32 = r2
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17)
            r0 = -1
            r2 = r32
            r2.q = r0
            r0 = 0
            r0 = r18[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r1 = 0
            r0.setTag(r1)
            r7 = r37
            r2.setRootTag(r7)
            r2.invalidateAll()
            return r2
        L_0x0de1:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for fragment_transaction_report is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0ded:
            r11 = r14
            r7 = r15
            r0 = 3
            r18 = 2
            java.lang.String r3 = "layout/activity_transaction_history_list_0"
            boolean r3 = r3.equals(r2)
            if (r3 == 0) goto L_0x0e20
            com.huawei.digitalpayment.customer.homev6.databinding.ActivityTransactionHistoryListBindingImpl r2 = new com.huawei.digitalpayment.customer.homev6.databinding.ActivityTransactionHistoryListBindingImpl
            android.util.SparseIntArray r3 = com.huawei.digitalpayment.customer.homev6.databinding.ActivityTransactionHistoryListBindingImpl.e
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r0, r11, r3)
            r3 = r0[r18]
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r4 = r0[r12]
            com.scwang.smart.refresh.layout.SmartRefreshLayout r4 = (com.scwang.smart.refresh.layout.SmartRefreshLayout) r4
            r2.<init>(r1, r7, r3, r4)
            r3 = -1
            r2.d = r3
            r1 = 0
            r0 = r0[r1]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r11)
            r2.setRootTag(r7)
            r2.invalidateAll()
            return r2
        L_0x0e20:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_transaction_history_list is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0e2c:
            r7 = r15
            java.lang.String r0 = "layout/activity_transaction_history_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0ee8
            com.huawei.digitalpayment.customer.homev6.databinding.ActivityTransactionHistoryBindingImpl r0 = new com.huawei.digitalpayment.customer.homev6.databinding.ActivityTransactionHistoryBindingImpl
            android.util.SparseIntArray r2 = com.huawei.digitalpayment.customer.homev6.databinding.ActivityTransactionHistoryBindingImpl.e
            r3 = 5
            r4 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r3, r4, r2)
            r3 = 4
            r3 = r2[r3]
            android.widget.LinearLayout r3 = (android.widget.LinearLayout) r3
            r3 = 1
            r3 = r2[r3]
            android.widget.LinearLayout r3 = (android.widget.LinearLayout) r3
            r5 = 2
            r5 = r2[r5]
            if (r5 == 0) goto L_0x0ec7
            android.view.View r5 = (android.view.View) r5
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.activeRTV
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            r11 = r8
            com.huawei.common.widget.round.RoundTextView r11 = (com.huawei.common.widget.round.RoundTextView) r11
            if (r11 == 0) goto L_0x0eb3
            r10 = r5
            com.google.android.material.appbar.AppBarLayout r10 = (com.google.android.material.appbar.AppBarLayout) r10
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.base_toolbar
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            androidx.appcompat.widget.Toolbar r8 = (androidx.appcompat.widget.Toolbar) r8
            if (r8 == 0) goto L_0x0eb3
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.closedRTV
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            r12 = r8
            com.huawei.common.widget.round.RoundTextView r12 = (com.huawei.common.widget.round.RoundTextView) r12
            if (r12 == 0) goto L_0x0eb3
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.iv_back
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            r13 = r8
            android.widget.ImageView r13 = (android.widget.ImageView) r13
            if (r13 == 0) goto L_0x0eb3
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.ll_active
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            r14 = r8
            android.widget.LinearLayout r14 = (android.widget.LinearLayout) r14
            if (r14 == 0) goto L_0x0eb3
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.ll_closed
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            r15 = r8
            android.widget.LinearLayout r15 = (android.widget.LinearLayout) r15
            if (r15 == 0) goto L_0x0eb3
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.tv_active
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            r16 = r8
            android.widget.TextView r16 = (android.widget.TextView) r16
            if (r16 == 0) goto L_0x0eb3
            int r6 = com.huawei.digitalpayment.customer.homev6.R$id.tv_closed
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r5, r6)
            r17 = r8
            android.widget.TextView r17 = (android.widget.TextView) r17
            if (r17 == 0) goto L_0x0eb3
            com.huawei.digitalpayment.customer.homev6.databinding.TransactionTitleBarBinding r5 = new com.huawei.digitalpayment.customer.homev6.databinding.TransactionTitleBarBinding
            r9 = r5
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17)
            goto L_0x0ec8
        L_0x0eb3:
            android.content.res.Resources r0 = r5.getResources()
            java.lang.String r0 = r0.getResourceName(r6)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x0ec7:
            r5 = r4
        L_0x0ec8:
            r6 = 3
            r6 = r2[r6]
            android.view.View r6 = (android.view.View) r6
            r0.<init>(r1, r7, r3, r5)
            r5 = -1
            r0.d = r5
            r1 = 0
            r1 = r2[r1]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r4)
            android.widget.LinearLayout r1 = r0.a
            r1.setTag(r4)
            r0.setRootTag(r7)
            r0.invalidateAll()
            return r0
        L_0x0ee8:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_transaction_history is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0ef4:
            r7 = r15
            java.lang.String r0 = "layout/activity_my_usd_balance_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0f50
            com.huawei.digitalpayment.customer.homev6.databinding.ActivityMyUsdBalanceBindingImpl r8 = new com.huawei.digitalpayment.customer.homev6.databinding.ActivityMyUsdBalanceBindingImpl
            android.util.SparseIntArray r0 = com.huawei.digitalpayment.customer.homev6.databinding.ActivityMyUsdBalanceBindingImpl.f
            r2 = 9
            r9 = 0
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r2, r9, r0)
            r0 = 8
            r0 = r10[r0]
            r3 = r0
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r0 = 1
            r0 = r10[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = 2
            r0 = r10[r0]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = 4
            r0 = r10[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = 6
            r0 = r10[r0]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = 5
            r0 = r10[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 3
            r0 = r10[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 7
            r0 = r10[r0]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r8
            r1 = r36
            r2 = r37
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r0 = -1
            r8.e = r0
            r0 = 0
            r0 = r10[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r9)
            r8.setRootTag(r7)
            r8.invalidateAll()
            return r8
        L_0x0f50:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_my_usd_balance is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0f5c:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "view must have a tag"
            r0.<init>(r1)
            throw r0
        L_0x0f64:
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.homev6.DataBinderMapperImpl.getDataBinder(androidx.databinding.DataBindingComponent, android.view.View, int):androidx.databinding.ViewDataBinding");
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
