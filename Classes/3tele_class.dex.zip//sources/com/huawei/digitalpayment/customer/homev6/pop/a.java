package com.huawei.digitalpayment.customer.homev6.pop;

import android.view.View;
import com.blankj.utilcode.util.C;
import com.huawei.digitalpayment.customer.baselib.dialog.ScheduleDatePickerDialog;
import java.util.Calendar;

public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ b a;
    public final /* synthetic */ ScheduleDatePickerDialog b;

    public /* synthetic */ a(b bVar, ScheduleDatePickerDialog scheduleDatePickerDialog) {
        this.a = bVar;
        this.b = scheduleDatePickerDialog;
    }

    public final void onClick(View view) {
        b bVar = this.a;
        bVar.getClass();
        ScheduleDatePickerDialog scheduleDatePickerDialog = this.b;
        scheduleDatePickerDialog.dismiss();
        Calendar x0 = scheduleDatePickerDialog.x0();
        RecordFilterEvent recordFilterEvent = bVar.d;
        recordFilterEvent.setFromCalendar(x0);
        if (recordFilterEvent.getFromCalendar() != null) {
            bVar.b.c.setText(C.a("yyyy-MM-dd", recordFilterEvent.getFromCalendar().getTime()));
        }
    }
}
