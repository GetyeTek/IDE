package com.huawei.digitalpayment.customer.viewlib;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.huawei.digitalpayment.customer.baselib.R$drawable;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutEnterPinFragmentBinding;
import com.huawei.digitalpayment.customer.viewlib.view.EnterPinView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import p4.c;

public class EnterPinFragment extends BaseFragment implements c.a, EnterPinView.a {
    public LayoutEnterPinFragmentBinding c;
    public ArrayList<Map<String, String>> d;
    public boolean e;
    public b f;

    public class a implements View.OnTouchListener {
        public final boolean onTouch(View view, MotionEvent motionEvent) {
            return true;
        }
    }

    public interface b {
        void a(String str);
    }

    public final void F(String str) {
        if ("BACK_COMMAND".equals(str)) {
            EnterPinView enterPinView = this.c.d;
            int i = enterPinView.e;
            if (i != -1) {
                enterPinView.f = false;
                enterPinView.b.get(i).setBackgroundResource(R$drawable.enter_pin_view_bg);
                String str2 = enterPinView.d;
                enterPinView.d = str2.substring(0, str2.length() - 1);
                enterPinView.e--;
                return;
            }
            return;
        }
        EnterPinView enterPinView2 = this.c.d;
        if (!enterPinView2.f) {
            int i2 = enterPinView2.e + 1;
            enterPinView2.e = i2;
            enterPinView2.b.get(i2).setBackgroundResource(R$drawable.enter_pin_view_bg_black);
            String a2 = androidx.camera.camera2.internal.c.a(new StringBuilder(), enterPinView2.d, str);
            enterPinView2.d = a2;
            if (enterPinView2.e == enterPinView2.a - 1) {
                EnterPinFragment enterPinFragment = (EnterPinFragment) enterPinView2.g;
                b bVar = enterPinFragment.f;
                if (bVar != null) {
                    bVar.a(a2);
                    enterPinFragment.c.d.a();
                }
                enterPinView2.f = true;
            }
        }
    }

    public final void K() {
        this.c.d.a();
    }

    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        if (getActivity() != null) {
            getActivity().getWindow().addFlags(8192);
        }
    }

    public final void onDestroy() {
        super.onDestroy();
        if (getActivity() != null) {
            getActivity().getWindow().clearFlags(8192);
        }
    }

    public final void onStop() {
        EnterPinFragment.super.onStop();
        this.c.d.a();
    }

    /* JADX WARNING: type inference failed for: r0v9, types: [java.lang.Object, android.view.View$OnTouchListener] */
    public final ViewBinding v0(LayoutInflater layoutInflater) {
        ConstraintLayout inflate = layoutInflater.inflate(R$layout.layout_enter_pin_fragment, (ViewGroup) null, false);
        int i = R$id.enter_close;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i);
        if (imageView != null) {
            i = R$id.enter_keyboard;
            GridView gridView = (GridView) ViewBindings.findChildViewById(inflate, i);
            if (gridView != null) {
                i = R$id.enter_pin;
                EnterPinView enterPinView = (EnterPinView) ViewBindings.findChildViewById(inflate, i);
                if (enterPinView != null) {
                    i = R$id.enter_title;
                    if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                        i = R$id.forget_pin;
                        TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
                        if (textView != null) {
                            ConstraintLayout constraintLayout = inflate;
                            this.c = new LayoutEnterPinFragmentBinding(constraintLayout, imageView, gridView, enterPinView, textView);
                            constraintLayout.setOnTouchListener(new Object());
                            return this.c;
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    public final void w0() {
        c cVar;
        this.d = new ArrayList<>();
        for (int i = 1; i < 13; i++) {
            HashMap hashMap = new HashMap();
            if (i < 10) {
                hashMap.put("name", String.valueOf(i));
            } else if (i == 10) {
                hashMap.put("name", "");
            } else if (i == 11) {
                hashMap.put("name", String.valueOf(0));
            } else {
                hashMap.put("name", "back");
            }
            this.d.add(hashMap);
        }
        if (this.e) {
            Context context = getContext();
            ArrayList<Map<String, String>> arrayList = this.d;
            B1.c.b(arrayList);
            cVar = new c(context, arrayList);
        } else {
            cVar = new c(getContext(), this.d);
        }
        cVar.c = this;
        this.c.c.setAdapter(cVar);
        this.c.d.setEnterFinishListener(this);
        this.c.b.setOnClickListener(new P6.a(this, 4));
        this.c.e.setOnClickListener(new P6.b(this, 6));
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, android.view.View$OnTouchListener] */
    public final void x0(View view) {
        view.setOnTouchListener(new Object());
    }
}
