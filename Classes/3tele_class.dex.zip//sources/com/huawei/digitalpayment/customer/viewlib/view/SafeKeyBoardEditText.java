package com.huawei.digitalpayment.customer.viewlib.view;

import V1.h;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.PopupWindow;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.camera.core.impl.r;
import com.blankj.utilcode.util.l;
import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import t4.k;

public class SafeKeyBoardEditText extends AppCompatEditText implements View.OnClickListener, View.OnKeyListener {
    public static final /* synthetic */ int h = 0;
    public Window a;
    public View b;
    public View c;
    public final Activity d;
    public PopupWindow e;
    public int f;
    public VirtualKeyboardView g;

    public SafeKeyBoardEditText(Context context) {
        this(context, (AttributeSet) null);
    }

    public static Activity a(Context context) {
        if (context == null) {
            return null;
        }
        if (context instanceof Activity) {
            return (Activity) context;
        }
        if (context instanceof ContextWrapper) {
            return a(((ContextWrapper) context).getBaseContext());
        }
        return null;
    }

    public void b() {
        PopupWindow popupWindow = this.e;
        if (popupWindow != null && popupWindow.isShowing()) {
            this.e.dismiss();
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.view.View, com.huawei.digitalpayment.customer.viewlib.view.SafeKeyBoardEditText] */
    public final void c() {
        if (this.c != null && this.b != null) {
            int[] iArr = new int[2];
            getLocationOnScreen(iArr);
            Rect rect = new Rect();
            this.c.getWindowVisibleDisplayFrame(rect);
            int measuredHeight = (getMeasuredHeight() + iArr[1]) - (rect.bottom - this.g.getHeight());
            this.f = measuredHeight;
            if (measuredHeight > 0) {
                this.b.scrollBy(0, measuredHeight);
            }
        }
    }

    public void d() {
        PopupWindow popupWindow;
        if (this.c != null && (popupWindow = this.e) != null && !popupWindow.isShowing()) {
            l.a(this.d);
            this.e.showAtLocation(this.c, 80, 0, 0);
            c();
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.view.View, com.huawei.digitalpayment.customer.viewlib.view.SafeKeyBoardEditText, android.widget.EditText] */
    public void onAttachedToWindow() {
        SafeKeyBoardEditText.super.onAttachedToWindow();
        Window window = a(getContext()).getWindow();
        this.a = window;
        this.c = window.getDecorView();
        this.b = this.a.findViewById(16908290);
    }

    public final void onClick(View view) {
        d();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.digitalpayment.customer.viewlib.view.SafeKeyBoardEditText, android.widget.EditText] */
    public void onDetachedFromWindow() {
        SafeKeyBoardEditText.super.onDetachedFromWindow();
        b();
        this.e = null;
        this.g = null;
        this.c = null;
        this.b = null;
        this.a = null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.digitalpayment.customer.viewlib.view.SafeKeyBoardEditText, android.widget.EditText] */
    public void onFocusChanged(boolean z, int i, Rect rect) {
        SafeKeyBoardEditText.super.onFocusChanged(z, i, rect);
        if (z) {
            d();
        } else {
            b();
        }
    }

    public final boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (i != 4 || keyEvent.getAction() != 1) {
            return false;
        }
        if (this.e.isShowing()) {
            b();
        } else {
            Activity activity = this.d;
            if (activity != null) {
                activity.onBackPressed();
            }
        }
        return true;
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [com.huawei.digitalpayment.customer.viewlib.view.VirtualKeyboardView$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v5, types: [t4.j, java.lang.Object, java.lang.reflect.InvocationHandler] */
    public SafeKeyBoardEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f = 0;
        this.d = a(context);
        setShowSoftInputOnFocus(false);
        setOnClickListener(this);
        setOnKeyListener(this);
        VirtualKeyboardView virtualKeyboardView = new VirtualKeyboardView(context);
        this.g = virtualKeyboardView;
        virtualKeyboardView.setEditText(this);
        this.g.setOnVirtualKeyboardFinish(new Object());
        this.g.post(new r(this, 3));
        PopupWindow popupWindow = new PopupWindow(this.g, -1, -2, false);
        this.e = popupWindow;
        ? obj = new Object();
        try {
            Field declaredField = PopupWindow.class.getDeclaredField("mWindowManager");
            declaredField.setAccessible(true);
            Object obj2 = declaredField.get(popupWindow);
            obj.a = obj2;
            if (obj2 != null) {
                declaredField.set(popupWindow, Proxy.newProxyInstance(Handler.class.getClassLoader(), new Class[]{WindowManager.class}, obj));
            }
        } catch (IllegalAccessException e2) {
            e2.getMessage();
            h.b();
        } catch (NoSuchFieldException e3) {
            e3.getMessage();
            h.b();
        }
        this.e.setOnDismissListener(new k(this));
        this.e.setBackgroundDrawable(new ColorDrawable(0));
        setLongClickable(false);
        setImeOptions(268435456);
    }
}
