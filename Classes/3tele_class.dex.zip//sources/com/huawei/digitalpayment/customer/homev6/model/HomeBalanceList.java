package com.huawei.digitalpayment.customer.homev6.model;

import java.util.List;

public class HomeBalanceList extends BaseModel {
    List<HomeBalance> balances;

    public List<HomeBalance> getBalances() {
        return this.balances;
    }

    public void setBalances(List<HomeBalance> list) {
        this.balances = list;
    }
}
