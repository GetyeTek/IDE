package com.huawei.digitalpayment.customer.baselib.utils.contract;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.k;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.R$string;
import org.json.JSONArray;
import org.json.JSONObject;

public class SelectMultiplePhonesFragment extends Fragment {

    public class a extends A.b<JSONArray> {
        public final /* synthetic */ Intent d;

        public a(Intent intent) {
            this.d = intent;
        }

        public final Object a() throws Throwable {
            Parcelable[] parcelableArrayExtra = this.d.getParcelableArrayExtra("com.android.contacts.extra.PHONE_URIS");
            JSONArray jSONArray = new JSONArray();
            if (parcelableArrayExtra != null && parcelableArrayExtra.length > 0) {
                ContentResolver contentResolver = SelectMultiplePhonesFragment.this.requireActivity().getContentResolver();
                for (Parcelable parcelable : parcelableArrayExtra) {
                    ContactsBean contactsBean = new ContactsBean();
                    Cursor query = contentResolver.query((Uri) parcelable, new String[]{"contact_id", "data1", "display_name"}, (String) null, (String[]) null, (String) null);
                    if (query != null) {
                        while (query.moveToNext()) {
                            int i = query.getInt(0);
                            String string = query.getString(1);
                            String string2 = query.getString(2);
                            contactsBean.setId(i);
                            contactsBean.setName(string2);
                            contactsBean.addMobile(string);
                        }
                        query.close();
                    }
                    jSONArray.put(new JSONObject(k.d(contactsBean)));
                }
            }
            return jSONArray;
        }

        public final void f(Object obj) {
            JSONArray jSONArray = (JSONArray) obj;
            SelectMultiplePhonesFragment.this.getClass();
        }
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        SelectMultiplePhonesFragment.super.onActivityResult(i, i2, intent);
        if (i == 101 && i2 == -1 && intent != null) {
            A.d(new a(intent));
        }
    }

    public final void onCreate(@Nullable Bundle bundle) {
        SelectMultiplePhonesFragment.super.onCreate(bundle);
        setRetainInstance(true);
    }

    public final void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        SelectMultiplePhonesFragment.super.onRequestPermissionsResult(i, strArr, iArr);
        if (i != 100) {
            return;
        }
        if (iArr[0] == 0) {
            Intent intent = new Intent("com.android.contacts.action.GET_MULTIPLE_PHONES");
            intent.addCategory("android.intent.category.DEFAULT");
            intent.setType("vnd.android.cursor.dir/phone_v2");
            startActivityForResult(intent, 101);
            return;
        }
        new BaseException("6", getString(R$string.designstandard_in_order_to_ensure_the_normal_use_of));
        throw null;
    }
}
