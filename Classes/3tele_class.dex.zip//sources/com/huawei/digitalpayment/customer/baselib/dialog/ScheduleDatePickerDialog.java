package com.huawei.digitalpayment.customer.baselib.dialog;

import I2.a;
import I2.b;
import I2.c;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.blankj.utilcode.util.C;
import com.huawei.common.widget.dialog.BottomDialog;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseDialogScheduleDatePickerBinding;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class ScheduleDatePickerDialog extends BottomDialog<BaseDialogScheduleDatePickerBinding> {
    public final Calendar d;
    public final Calendar e;
    public final Calendar f;
    public int g;
    public int h;
    public int i;
    public final String j;
    public final String k;
    public final String l;
    public View.OnClickListener m;

    public ScheduleDatePickerDialog() {
        this((Calendar) null, (Calendar) null, (Calendar) null);
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        ScheduleDatePickerDialog.super.onViewCreated(view, bundle);
        this.c.a.setOnClickListener(this.m);
        ArrayList arrayList = new ArrayList();
        int i2 = this.d.get(1);
        int i5 = 0;
        for (int i6 = i2; i6 <= this.e.get(1); i6++) {
            if (i6 == this.f.get(1)) {
                i5 = i6 - i2;
            }
            arrayList.add(String.format(Locale.ENGLISH, this.j, new Object[]{Integer.valueOf(i6)}));
        }
        this.c.d.setData(arrayList);
        this.c.d.f(i5, false);
        this.c.d.setOnItemSelectedListener(new c(this, i2));
        z0();
        y0();
    }

    public final int v0() {
        return R$layout.base_dialog_schedule_date_picker;
    }

    public final Calendar x0() {
        Calendar instance = Calendar.getInstance();
        instance.set(1, this.g);
        instance.set(2, this.h - 1);
        instance.set(5, this.i);
        return instance;
    }

    public final void y0() {
        int i2;
        int i5;
        String str;
        Calendar calendar = this.d;
        int i6 = calendar.get(1);
        int i7 = calendar.get(2) + 1;
        if (this.g == i6 && this.h == i7) {
            i2 = calendar.get(5);
        } else {
            i2 = 1;
        }
        Calendar calendar2 = this.e;
        int i8 = calendar2.get(1);
        int i9 = calendar2.get(2) + 1;
        int i10 = this.g;
        if (i10 == i8 && this.h == i9) {
            i5 = calendar2.get(5);
        } else {
            int i11 = this.h;
            if (i11 != 1) {
                if (i11 == 2) {
                    C.a aVar = C.a;
                    if ((i10 % 4 != 0 || i10 % 100 == 0) && i10 % 400 != 0) {
                        i5 = 28;
                    } else {
                        i5 = 29;
                    }
                } else if (!(i11 == 3 || i11 == 5 || i11 == 10 || i11 == 12 || i11 == 7 || i11 == 8)) {
                    i5 = 30;
                }
            }
            i5 = 31;
        }
        ArrayList arrayList = new ArrayList();
        int i12 = i2;
        while (true) {
            str = this.l;
            if (i12 > i5) {
                break;
            }
            arrayList.add(String.format(Locale.ENGLISH, str, new Object[]{Integer.valueOf(i12)}));
            i12++;
        }
        Locale locale = Locale.ENGLISH;
        if (!arrayList.contains(String.format(locale, str, new Object[]{Integer.valueOf(this.i)}))) {
            if (this.i < i2) {
                this.i = i2;
            } else {
                this.i = i5;
            }
        }
        int indexOf = arrayList.indexOf(String.format(locale, str, new Object[]{Integer.valueOf(this.i)}));
        this.c.b.setData(arrayList);
        this.c.b.f(indexOf, false);
        this.c.b.setOnItemSelectedListener(new b(this, i2));
    }

    public final void z0() {
        int i2;
        int i5;
        String str;
        Calendar calendar = this.d;
        if (this.g == calendar.get(1)) {
            i2 = calendar.get(2) + 1;
        } else {
            i2 = 1;
        }
        Calendar calendar2 = this.e;
        if (this.g == calendar2.get(1)) {
            i5 = calendar2.get(2) + 1;
        } else {
            i5 = 12;
        }
        ArrayList arrayList = new ArrayList();
        int i6 = i2;
        while (true) {
            str = this.k;
            if (i6 > i5) {
                break;
            }
            arrayList.add(String.format(Locale.ENGLISH, str, new Object[]{Integer.valueOf(i6)}));
            i6++;
        }
        Locale locale = Locale.ENGLISH;
        if (!arrayList.contains(String.format(locale, str, new Object[]{Integer.valueOf(this.h)}))) {
            if (this.h < i2) {
                this.h = i2;
            } else {
                this.h = i5;
            }
        }
        int indexOf = arrayList.indexOf(String.format(locale, str, new Object[]{Integer.valueOf(this.h)}));
        this.c.c.setData(arrayList);
        this.c.c.f(indexOf, false);
        this.h = indexOf + i2;
        this.c.c.setOnItemSelectedListener(new a(this, i2));
    }

    public ScheduleDatePickerDialog(Calendar calendar, Calendar calendar2, Calendar calendar3) {
        this.j = "%d";
        this.k = "%d";
        this.l = "%d";
        if (calendar3 == null) {
            calendar3 = Calendar.getInstance();
            calendar3.setTimeInMillis(System.currentTimeMillis());
        }
        int i2 = calendar3.get(1);
        if (calendar == null) {
            calendar = Calendar.getInstance();
            calendar.set(1, i2 - 1000);
        }
        calendar3 = calendar3.compareTo(calendar) < 0 ? calendar : calendar3;
        if (calendar2 == null) {
            calendar2 = Calendar.getInstance();
            calendar2.set(1, i2 + 1000);
        }
        calendar3 = calendar3.compareTo(calendar2) > 0 ? calendar2 : calendar3;
        this.d = calendar;
        this.e = calendar2;
        this.f = calendar3;
        this.g = calendar3.get(1);
        this.h = calendar3.get(2) + 1;
        this.i = calendar3.get(5);
    }
}
