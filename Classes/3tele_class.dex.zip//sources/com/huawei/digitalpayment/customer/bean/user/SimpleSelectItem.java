package com.huawei.digitalpayment.customer.bean.user;

import java.io.Serializable;

public class SimpleSelectItem implements Serializable {
    private String key;
    private String title;

    public SimpleSelectItem(String str, String str2) {
        this.key = str;
        this.title = str2;
    }

    public String getKey() {
        return this.key;
    }

    public String getTitle() {
        return this.title;
    }

    public void setKey(String str) {
        this.key = str;
    }

    public void setTitle(String str) {
        this.title = str;
    }
}
