package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatCheckBox;
import d2.a;

public class RoundCheckBox extends AppCompatCheckBox {
    public final a a;

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox, android.view.View] */
    public RoundCheckBox(Context context) {
        super(context);
        this.a = new a(this, (AttributeSet) null);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.widget.CheckBox, com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox] */
    public final void draw(Canvas canvas) {
        this.a.getClass();
        a.a(canvas);
        RoundCheckBox.super.draw(canvas);
        this.a.b(canvas);
    }

    public a getBaseFilletView() {
        return this.a;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.widget.CheckBox, com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox] */
    public final void onSizeChanged(int i, int i2, int i5, int i6) {
        RoundCheckBox.super.onSizeChanged(i, i2, i5, i6);
        this.a.c(i, i2);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox, android.view.View] */
    public RoundCheckBox(Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = new a(this, attributeSet);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.digitalpayment.customer.viewlib.view.RoundCheckBox, android.view.View] */
    public RoundCheckBox(Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = new a(this, attributeSet);
    }
}
