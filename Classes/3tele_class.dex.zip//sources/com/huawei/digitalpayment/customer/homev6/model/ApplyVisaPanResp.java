package com.huawei.digitalpayment.customer.homev6.model;

import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public class ApplyVisaPanResp extends BaseResp {
    private String subTitle;
    private String visaBackgroundUrl;
    private String visaPAN;

    public String getSubTitle() {
        return this.subTitle;
    }

    public String getVisaBackgroundUrl() {
        return this.visaBackgroundUrl;
    }

    public String getVisaPAN() {
        return this.visaPAN;
    }

    public void setSubTitle(String str) {
        this.subTitle = str;
    }

    public void setVisaBackgroundUrl(String str) {
        this.visaBackgroundUrl = str;
    }

    public void setVisaPAN(String str) {
        this.visaPAN = str;
    }
}
