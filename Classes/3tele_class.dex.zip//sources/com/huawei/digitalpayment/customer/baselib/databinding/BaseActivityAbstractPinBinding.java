package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputKeyboard;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputView;

public abstract class BaseActivityAbstractPinBinding extends ViewDataBinding {
    @NonNull
    public final ImageView a;
    @NonNull
    public final PinInputKeyboard b;
    @NonNull
    public final PinInputView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public BaseActivityAbstractPinBinding(DataBindingComponent dataBindingComponent, View view, ImageView imageView, PinInputKeyboard pinInputKeyboard, PinInputView pinInputView, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = imageView;
        this.b = pinInputKeyboard;
        this.c = pinInputView;
        this.d = textView;
        this.e = textView2;
    }
}
