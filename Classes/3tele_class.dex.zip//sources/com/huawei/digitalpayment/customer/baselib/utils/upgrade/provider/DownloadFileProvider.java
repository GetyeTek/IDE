package com.huawei.digitalpayment.customer.baselib.utils.upgrade.provider;

import androidx.core.content.FileProvider;

public class DownloadFileProvider extends FileProvider {
}
