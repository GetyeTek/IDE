package com.huawei.digitalpayment.customer.viewlib.view;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;

public class PayLoadingDialog extends BaseDialog {
    public ImageView c;
    public ObjectAnimator d;

    public final void dismiss() {
        PayLoadingDialog.super.dismiss();
        ObjectAnimator objectAnimator = this.d;
        if (objectAnimator != null && objectAnimator.isRunning()) {
            this.d.pause();
        }
    }

    public final void onDestroy() {
        PayLoadingDialog.super.onDestroy();
        ObjectAnimator objectAnimator = this.d;
        if (objectAnimator != null) {
            objectAnimator.end();
            this.d = null;
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        PayLoadingDialog.super.onViewCreated(view, bundle);
        this.c = (ImageView) view.findViewById(R$id.iv_loading);
    }

    public final void show(FragmentManager fragmentManager, String str) {
        PayLoadingDialog.super.show(fragmentManager, str);
        if (this.a) {
            if (this.d == null) {
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.c, "rotation", new float[]{0.0f, 360.0f});
                this.d = ofFloat;
                ofFloat.setDuration(3000);
                this.d.setInterpolator(new LinearInterpolator());
                this.d.setRepeatCount(-1);
                this.d.setRepeatMode(1);
            }
            this.d.start();
        }
    }

    public final int v0() {
        return R$layout.layout_loading;
    }
}
