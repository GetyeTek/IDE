package com.huawei.digitalpayment.customer.baselib.utils.language;

import C0.e;
import V1.h;
import Yb.c;
import Yb.j;
import android.app.Activity;
import android.app.Application;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.f;
import com.huawei.album.ui.AlbumActivity;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.digitalpayment.customer.baselib.session.SessionManagerView;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.payment.lib.image.crop.CropActivity;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.Objects;

public class GlobalActivityLifecycleCallback implements Application.ActivityLifecycleCallbacks {
    private static final String DEFAULT_LANGUAGE_CODE = "unknown";
    private final String MODE_1 = "1";

    public class a implements OnApplyWindowInsetsListener {
        @NonNull
        public final WindowInsetsCompat onApplyWindowInsets(@NonNull View view, @NonNull WindowInsetsCompat windowInsetsCompat) {
            view.setPadding(view.getPaddingLeft(), windowInsetsCompat.getInsets(WindowInsetsCompat.Type.statusBars()).top, view.getPaddingRight(), windowInsetsCompat.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom);
            return windowInsetsCompat;
        }
    }

    private void initLanguage(Activity activity) {
        P1.a annotation = activity.getClass().getAnnotation(P1.a.class);
        if ((activity instanceof BaseActivity) || (activity instanceof DataBindingActivity) || annotation != null) {
            String currentLang = LanguageUtils.getInstance().getCurrentLang();
            LanguageUtils.getInstance().setLanguage(activity, currentLang);
            LanguageUtils.getInstance().setLanguage(J.a(), currentLang);
        }
    }

    private void resetFont(@NonNull Resources resources) {
        if (resources.getConfiguration().fontScale != 1.0f) {
            Configuration configuration = new Configuration();
            configuration.setToDefaults();
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, androidx.core.view.OnApplyWindowInsetsListener] */
    public void fixStatusView(View view) {
        if (Build.VERSION.SDK_INT >= 35 && view != null) {
            view.setFitsSystemWindows(false);
            ViewCompat.setOnApplyWindowInsetsListener(view, new Object());
        }
    }

    public String getLoginMode() {
        String loginMode = BasicConfig.getInstance().getLoginMode();
        if (TextUtils.isEmpty(loginMode)) {
            return "1";
        }
        return loginMode;
    }

    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle bundle) {
        Objects.toString(activity);
        h.b();
        resetFont(activity.getResources());
        resetFont(Resources.getSystem());
        if ((activity instanceof BaseActivity) || (activity instanceof DataBindingActivity) || activity.getClass().getSuperclass().getName().contains("BaseActivity")) {
            n.a.b().getClass();
            n.a.c(activity);
        }
        if ((activity instanceof CropActivity) && Build.VERSION.SDK_INT >= 35) {
            f.e(activity, e.a(activity, R$color.colorWhite), true);
            fixStatusView(activity.findViewById(16908290));
        }
        if ((activity instanceof AlbumActivity) && Build.VERSION.SDK_INT >= 35) {
            f.e(activity, e.a(activity, R$color.album_primary), true);
            fixStatusView(activity.findViewById(16908290));
        }
        initLanguage(activity);
    }

    public void onActivityDestroyed(@NonNull Activity activity) {
        Objects.toString(activity);
        h.b();
    }

    public void onActivityPaused(@NonNull Activity activity) {
        Objects.toString(activity);
        h.b();
    }

    public void onActivityResumed(@NonNull Activity activity) {
        Objects.toString(activity);
        h.b();
        if (TextUtils.equals(BasicConfig.getInstance().getLoginMode(), "1")) {
            U2.a aVar = U2.a.b;
            aVar.a();
            if (aVar.a == null) {
                aVar.a = new SessionManagerView(activity.getApplicationContext());
            }
            ViewGroup viewGroup = (ViewGroup) aVar.a.getParent();
            if (viewGroup != null) {
                viewGroup.removeView(aVar.a);
            }
            ((ViewGroup) activity.findViewById(16908290)).addView(aVar.a, new ViewGroup.LayoutParams(-1, -1));
        }
    }

    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle bundle) {
    }

    public void onActivityStarted(@NonNull Activity activity) {
        boolean containsKey;
        Objects.toString(activity);
        h.b();
        if (activity instanceof BaseActivity) {
            c b = c.b();
            synchronized (b) {
                containsKey = b.b.containsKey(this);
            }
            if (!containsKey) {
                c.b().j(activity);
            }
        }
    }

    public void onActivityStopped(@NonNull Activity activity) {
        c.b().m(activity);
        Objects.toString(activity);
        h.b();
    }

    @j
    public void onEvent(String str) {
    }
}
