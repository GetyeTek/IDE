package com.huawei.digitalpayment.customer.designstandard;

public final class R$mipmap {
    public static final int bg_pic_splash = 2131755068;
    public static final int drawer_menu_bg = 2131755183;
    public static final int ic_launcher = 2131755346;
    public static final int ic_launcher_round = 2131755347;
    public static final int icon_add_contact = 2131755370;
    public static final int icon_logo = 2131755467;
    public static final int icon_tips = 2131755559;
    public static final int splash_bottom = 2131755763;
    public static final int splash_bottom_left = 2131755764;
    public static final int splash_bottom_right = 2131755765;
    public static final int splash_logo = 2131755766;
    public static final int splash_text = 2131755767;
    public static final int standard_checkbox_disable = 2131755768;
    public static final int standard_checkbox_selected = 2131755769;
    public static final int standard_checkbox_unselected = 2131755770;
    public static final int standard_ic_call = 2131755771;
    public static final int standard_ic_placeholder = 2131755772;
    public static final int standard_ic_tips = 2131755773;
    public static final int standard_icon_black_arrow_left = 2131755774;
    public static final int standard_icon_black_back = 2131755775;
    public static final int standard_icon_black_close = 2131755776;
    public static final int standard_icon_black_extend = 2131755777;
    public static final int standard_icon_eyes_close = 2131755778;
    public static final int standard_icon_eyes_open = 2131755779;
    public static final int standard_icon_grey_arrow_right = 2131755780;
    public static final int standard_icon_grey_extend = 2131755781;
    public static final int standard_icon_result_fail = 2131755782;
    public static final int standard_icon_result_success = 2131755783;
    public static final int standard_icon_result_wait = 2131755784;
    public static final int standard_icon_result_warning = 2131755785;
    public static final int standard_icon_warning = 2131755786;
    public static final int standard_radio_disable = 2131755787;
    public static final int standard_radio_selected = 2131755788;
    public static final int standard_radio_unselected = 2131755789;
    public static final int standard_switch_disable = 2131755790;
    public static final int standard_switch_enable = 2131755791;

    private R$mipmap() {
    }
}
