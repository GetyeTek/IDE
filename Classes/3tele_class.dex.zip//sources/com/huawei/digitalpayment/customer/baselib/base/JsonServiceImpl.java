package com.huawei.digitalpayment.customer.baselib.base;

import android.content.Context;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.facade.service.SerializationService;
import com.google.gson.Gson;
import java.lang.reflect.Type;

@Route(path = "/service/json")
public class JsonServiceImpl implements SerializationService {
    public Gson a;

    public final void init(Context context) {
        this.a = new Gson();
    }

    public final <T> T json2Object(String str, Class<T> cls) {
        if (this.a == null) {
            this.a = new Gson();
        }
        return this.a.fromJson(str, cls);
    }

    public final String object2Json(Object obj) {
        if (this.a == null) {
            this.a = new Gson();
        }
        return this.a.toJson(obj);
    }

    public final <T> T parseObject(String str, Type type) {
        if (this.a == null) {
            this.a = new Gson();
        }
        return this.a.fromJson(str, type);
    }
}
