package com.huawei.digitalpayment.customer.baselib.mvvm;

import V1.k;
import Yb.c;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public abstract class BaseMvvmActivity<VM extends BaseViewModel> extends BaseTitleActivity {
    public static final /* synthetic */ int j = 0;
    public VM i;

    public class a implements Observer<Boolean> {
        public a() {
        }

        public final void onChanged(Object obj) {
            boolean booleanValue = ((Boolean) obj).booleanValue();
            BaseMvvmActivity baseMvvmActivity = BaseMvvmActivity.this;
            if (booleanValue) {
                DialogManager.c(baseMvvmActivity);
            } else {
                DialogManager.a(baseMvvmActivity);
            }
        }
    }

    public static void V0(BaseException baseException) {
        if ("app.the_app_version_is_not_supported".equals(baseException.getResponseCode())) {
            c.b().e(new BaseResp(baseException.getResponseCode(), baseException.getResponseDesc()));
        } else {
            k.b(1, baseException.getResponseDesc());
        }
    }

    public void G0() {
        super.G0();
        Class cls = getClass();
        while (true) {
            if (cls == null || cls == BaseMvvmActivity.class) {
                break;
            }
            Type genericSuperclass = cls.getGenericSuperclass();
            if (genericSuperclass instanceof ParameterizedType) {
                Class<BaseViewModel> cls2 = (Class) ((ParameterizedType) genericSuperclass).getActualTypeArguments()[0];
                if (cls2 != BaseViewModel.class) {
                    this.i = (BaseViewModel) new ViewModelProvider(this).get(cls2);
                } else {
                    throw new RuntimeException("The VM should use a BaseViewModel subclass");
                }
            } else {
                cls = cls.getSuperclass();
            }
        }
        U0();
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [androidx.lifecycle.Observer, java.lang.Object] */
    public void U0() {
        if (this.i != null) {
            getLifecycle().addObserver(this.i);
            this.i.d.observe(this, new Object());
            this.i.c.observe(this, new a());
        }
    }
}
