package com.huawei.digitalpayment.customer.homev6.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class HomeConfig implements Serializable {
    private static final long serialVersionUID = -690589599034231428L;
    private List<FunctionGroup> appsFunction;
    private List<FunctionGroup> dynamicMenu;
    private List<HomeFunction> favoriteFunctions;
    private Map<String, HomeFunction> functionDefine;
    private List<Banner> lifeBanner;
    private List<FunctionGroup> lifeFunction;
    private List<FunctionGroup> myFunction;
    private List<HomeFunction> navigation;
    private List<HomeFunction> topFunction;

    public List<FunctionGroup> getAppsFunction() {
        return this.appsFunction;
    }

    public List<FunctionGroup> getDynamicMenu() {
        return this.dynamicMenu;
    }

    public List<HomeFunction> getFavoriteFunctions() {
        return this.favoriteFunctions;
    }

    public Map<String, HomeFunction> getFunctionDefine() {
        return this.functionDefine;
    }

    public List<Banner> getLifeBanner() {
        return this.lifeBanner;
    }

    public List<FunctionGroup> getLifeFunction() {
        return this.lifeFunction;
    }

    public List<FunctionGroup> getMyFunction() {
        return this.myFunction;
    }

    public List<HomeFunction> getNavigation() {
        return this.navigation;
    }

    public List<HomeFunction> getTopFunction() {
        return this.topFunction;
    }

    public void setAppsFunction(List<FunctionGroup> list) {
        this.appsFunction = list;
    }

    public void setDynamicMenu(List<FunctionGroup> list) {
        this.dynamicMenu = list;
    }

    public void setFavoriteFunctions(List<HomeFunction> list) {
        this.favoriteFunctions = list;
    }

    public void setFunctionDefine(Map<String, HomeFunction> map) {
        this.functionDefine = map;
    }

    public void setLifeBanner(List<Banner> list) {
        this.lifeBanner = list;
    }

    public void setLifeFunction(List<FunctionGroup> list) {
        this.lifeFunction = list;
    }

    public void setMyFunction(List<FunctionGroup> list) {
        this.myFunction = list;
    }

    public void setNavigation(List<HomeFunction> list) {
        this.navigation = list;
    }

    public void setTopFunction(List<HomeFunction> list) {
        this.topFunction = list;
    }
}
