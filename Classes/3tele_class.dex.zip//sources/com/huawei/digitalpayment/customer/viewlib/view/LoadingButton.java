package com.huawei.digitalpayment.customer.viewlib.view;

import R9.h;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.huawei.digitalpayment.customer.baselib.R$mipmap;
import com.huawei.digitalpayment.customer.baselib.R$styleable;

public class LoadingButton extends LinearLayout {
    public final TextView a;
    public final ImageView b;
    public String c;
    public ObjectAnimator d;

    public LoadingButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setGravity(17);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.LoadingButton);
        this.c = obtainStyledAttributes.getString(R$styleable.LoadingButton_lb_text);
        int color = obtainStyledAttributes.getColor(R$styleable.LoadingButton_lb_text_color, -1);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(R$styleable.LoadingButton_lb_text_size, 16);
        TextView textView = new TextView(context);
        this.a = textView;
        textView.setTextColor(color);
        this.a.setTextSize(0, (float) dimensionPixelSize);
        this.a.setAllCaps(false);
        this.a.setText(this.c);
        this.a.setGravity(17);
        obtainStyledAttributes.getDimensionPixelSize(R$styleable.LoadingButton_icon_height, h.a(context, 14.0f));
        obtainStyledAttributes.getDimensionPixelSize(R$styleable.LoadingButton_icon_with, h.a(context, 14.0f));
        int resourceId = obtainStyledAttributes.getResourceId(R$styleable.LoadingButton_icon_drawable, R$mipmap.base_ic_loading);
        ImageView imageView = new ImageView(context);
        this.b = imageView;
        imageView.setImageResource(resourceId);
        this.b.setVisibility(8);
        addView(this.b);
        addView(this.a);
        ((LinearLayout.LayoutParams) this.a.getLayoutParams()).leftMargin = 10;
        obtainStyledAttributes.recycle();
    }

    public final void a() {
        setClickable(true);
        this.a.setAlpha(1.0f);
        ObjectAnimator objectAnimator = this.d;
        if (objectAnimator != null) {
            objectAnimator.end();
        }
        this.a.setText(this.c);
        this.a.setVisibility(0);
        this.b.setVisibility(8);
    }

    public final void b() {
        ImageView imageView = this.b;
        ObjectAnimator objectAnimator = this.d;
        if (objectAnimator == null || !objectAnimator.isRunning()) {
            setClickable(false);
            imageView.setVisibility(0);
            this.a.setAlpha(0.6f);
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(imageView, "rotation", new float[]{0.0f, 360.0f});
            this.d = ofFloat;
            ofFloat.setDuration(3000);
            this.d.setInterpolator(new LinearInterpolator());
            this.d.setRepeatCount(-1);
            this.d.setRepeatMode(1);
            this.d.start();
        }
    }

    public TextView getmTextView() {
        return this.a;
    }

    public void setText(String str) {
        TextView textView = this.a;
        if (textView != null) {
            this.c = str;
            textView.setText(str);
        }
    }
}
