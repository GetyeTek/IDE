package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.AppCompatImageView;

public class RatioImageView extends AppCompatImageView {
    public RatioImageView(Context context) {
        super(context);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.widget.ImageView, android.view.View, com.huawei.digitalpayment.customer.viewlib.view.RatioImageView] */
    public final void onMeasure(int i, int i2) {
        Drawable drawable = getDrawable();
        if (drawable != null) {
            int size = View.MeasureSpec.getSize(i);
            setMeasuredDimension(size, (int) Math.ceil((double) ((((float) size) * ((float) drawable.getIntrinsicHeight())) / ((float) drawable.getIntrinsicWidth()))));
            return;
        }
        RatioImageView.super.onMeasure(i, i2);
    }

    public RatioImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
