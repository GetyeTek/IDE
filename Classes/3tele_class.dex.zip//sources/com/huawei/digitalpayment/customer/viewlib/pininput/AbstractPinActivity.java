package com.huawei.digitalpayment.customer.viewlib.pininput;

import V1.h;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.huawei.digitalpayment.customer.baselib.R$anim;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseActivityAbstractPinBinding;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputView;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.lang.reflect.ParameterizedType;
import s4.a;

public abstract class AbstractPinActivity<VM extends ViewModel> extends DataBindingActivity<BaseActivityAbstractPinBinding, VM> implements View.OnClickListener, PinInputView.a {
    public static final /* synthetic */ int d = 0;

    public final int C0() {
        return R$layout.base_activity_abstract_pin;
    }

    public final void D0() {
        try {
            this.c = new ViewModelProvider(this).get((Class) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0]);
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.digitalpayment.customer.viewlib.pininput.AbstractPinActivity, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity] */
    public final void E0(boolean z) {
        AbstractPinActivity.super.finish();
        if (z) {
            overridePendingTransition(R$anim.anim_silent, R$anim.from_top_to_bottom);
        }
    }

    public final void onBackPressed() {
        E0(true);
    }

    public void onClick(View view) {
        E0(true);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.view.View$OnClickListener, com.huawei.digitalpayment.customer.viewlib.pininput.PinInputView$a, com.huawei.digitalpayment.customer.viewlib.pininput.AbstractPinActivity, android.app.Activity, com.huawei.payment.mvvm.DataBindingActivity] */
    public void onCreate(@Nullable Bundle bundle) {
        overridePendingTransition(R$anim.from_bottom_to_top, R$anim.anim_silent);
        AbstractPinActivity.super.onCreate(bundle);
        getWindow().addFlags(8192);
        this.b.a.setOnClickListener(this);
        this.b.e.setOnClickListener(new a(this));
        this.b.b.setOnInputListener(new a(this));
        this.b.c.setOnInputFinishListener(this);
    }
}
