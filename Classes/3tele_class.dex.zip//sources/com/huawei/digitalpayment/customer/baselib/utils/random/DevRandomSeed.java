package com.huawei.digitalpayment.customer.baselib.utils.random;

import V1.h;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.ProviderException;
import java.security.SecureRandomSpi;
import java.util.Arrays;
import java.util.Objects;

public final class DevRandomSeed extends SecureRandomSpi {
    private static final String NAME_RANDOM = "/dev/random";
    private static final long serialVersionUID = -3725272688849712172L;

    private byte[] generateSeed(int i) {
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(new File(NAME_RANDOM));
            byte[] bArr = new byte[i];
            int i2 = 0;
            while (i > 0) {
                int read = fileInputStream.read(bArr, i2, i);
                if (read > 0) {
                    i2 += read;
                    i -= read;
                } else {
                    throw new EOFException("read file error");
                }
            }
            fileInputStream.close();
            return bArr;
        } catch (IOException e) {
            throw new ProviderException("generateSeed() failed", e);
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }

    public synchronized byte[] engineGenerateSeed(int i) {
        h.b();
        return generateSeed(i);
    }

    public synchronized void engineNextBytes(byte[] bArr) {
        h.b();
        Objects.requireNonNull(bArr);
        byte[] generateSeed = generateSeed(bArr.length);
        System.arraycopy(generateSeed, 0, bArr, 0, generateSeed.length);
        Arrays.fill(generateSeed, (byte) 0);
    }

    /* JADX WARNING: CFG modification limit reached, blocks count: 111 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void engineSetSeed(byte[] r1) {
        /*
            r0 = this;
            monitor-enter(r0)
            V1.h.b()     // Catch:{ all -> 0x0008 }
            monitor-exit(r0)
            return
        L_0x0006:
            monitor-exit(r0)     // Catch:{ all -> 0x0008 }
            throw r1
        L_0x0008:
            r1 = move-exception
            goto L_0x0006
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.baselib.utils.random.DevRandomSeed.engineSetSeed(byte[]):void");
    }
}
