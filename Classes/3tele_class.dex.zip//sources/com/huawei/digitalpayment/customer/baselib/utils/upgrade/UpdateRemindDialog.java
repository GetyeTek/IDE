package com.huawei.digitalpayment.customer.baselib.utils.upgrade;

import A6.a;
import A6.b;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.R$string;
import com.huawei.digitalpayment.customer.baselib.utils.upgrade.provider.AppUpdate;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public class UpdateRemindDialog extends BaseDialog {
    public static UpdateRemindDialog f;
    public Button c;
    public LoadingButton d;
    public AppUpdate e;

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        if (getArguments() != null) {
            AppUpdate appUpdate = (AppUpdate) getArguments().getParcelable("appUpdate");
            this.e = appUpdate;
            if (!(appUpdate == null || appUpdate.getUpdateResourceId() == 0)) {
                return layoutInflater.inflate(this.e.getUpdateResourceId(), viewGroup, false);
            }
        }
        return layoutInflater.inflate(R$layout.dialog_update, viewGroup, false);
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        String str;
        UpdateRemindDialog.super.onViewCreated(view, bundle);
        AppUpdate appUpdate = this.e;
        if (appUpdate == null) {
            dismiss();
            return;
        }
        if (appUpdate.getUpdateResourceId() == R$layout.dialog_update) {
            TextView textView = (TextView) view.findViewById(R$id.tv_version);
            TextView textView2 = (TextView) view.findViewById(R$id.tvContent);
            ((TextView) view.findViewById(R$id.tv_new_versions)).setText(this.e.getUpdateTitle());
            if (TextUtils.isEmpty(this.e.getNewVersionCode())) {
                textView.setVisibility(8);
            } else {
                textView.setVisibility(0);
                textView.setText(this.e.getNewVersionCode());
            }
            if (TextUtils.isEmpty(this.e.getUpdateInfo())) {
                str = getResources().getString(R$string.designstandard_fix_some_bugs);
            } else {
                str = this.e.getUpdateInfo();
            }
            textView2.setText(str);
            textView2.setMovementMethod(new ScrollingMovementMethod());
        }
        Button button = (Button) view.findViewById(R$id.btnUpdateLater);
        this.c = button;
        button.setText(this.e.getUpdateCancelText());
        this.d = (LoadingButton) view.findViewById(R$id.btn_update);
        if (this.e.getForceUpdate() == 0) {
            this.c.setVisibility(0);
        } else {
            this.c.setVisibility(8);
        }
        this.c.setOnClickListener(new a(this, 6));
        this.d.setOnClickListener(new b(this, 4));
    }

    public final int v0() {
        return R$layout.dialog_update;
    }
}
