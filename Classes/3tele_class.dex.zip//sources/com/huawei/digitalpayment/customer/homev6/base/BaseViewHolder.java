package com.huawei.digitalpayment.customer.homev6.base;

import android.content.Context;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public class BaseViewHolder<T extends ViewDataBinding> extends RecyclerView.ViewHolder {
    public final T a;

    public BaseViewHolder(T t) {
        super(t.getRoot());
        this.a = t;
    }

    public final Context a() {
        return this.a.getRoot().getContext();
    }
}
