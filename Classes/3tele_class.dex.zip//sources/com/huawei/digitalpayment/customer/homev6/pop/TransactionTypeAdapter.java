package com.huawei.digitalpayment.customer.homev6.pop;

import R9.h;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.navigation.ui.b;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.digitalpayment.customer.homev6.R$layout;
import com.huawei.digitalpayment.customer.homev6.R$mipmap;
import com.huawei.digitalpayment.customer.homev6.base.BaseViewHolder;
import com.huawei.digitalpayment.customer.homev6.databinding.TransactionTypeGroupBinding;
import java.util.ArrayList;
import java.util.List;

public class TransactionTypeAdapter extends RecyclerView.Adapter<BaseViewHolder<ViewDataBinding>> {
    public ArrayList a;

    /* renamed from: a */
    public final void onBindViewHolder(@NonNull BaseViewHolder<ViewDataBinding> baseViewHolder, int i) {
        int i2;
        TransactionTypeGroup transactionTypeGroup = (TransactionTypeGroup) this.a.get(i);
        T t = baseViewHolder.a;
        List<TransactionTypeBean> list = transactionTypeGroup.getList();
        TransactionTypeGroupBinding transactionTypeGroupBinding = (TransactionTypeGroupBinding) t;
        transactionTypeGroupBinding.e.setText(transactionTypeGroup.getGroupName());
        RecyclerView recyclerView = transactionTypeGroupBinding.a;
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setLayoutManager(new GridLayoutManager(baseViewHolder.a(), 3));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.transaction_type_child);
        baseQuickAdapter.setNewData(list);
        recyclerView.setAdapter(baseQuickAdapter);
        baseQuickAdapter.setOnItemClickListener(new f(this, transactionTypeGroup));
        if (transactionTypeGroup.isShow()) {
            recyclerView.setVisibility(0);
        } else {
            recyclerView.setVisibility(8);
        }
        int a2 = h.a(baseViewHolder.a(), 8.0f);
        if (recyclerView.getItemDecorationCount() <= 0) {
            RecyclerView.ItemDecoration itemDecoration = new RecyclerView.ItemDecoration();
            itemDecoration.a = a2;
            recyclerView.addItemDecoration(itemDecoration);
        }
        if (!transactionTypeGroup.isShow()) {
            i2 = R$mipmap.home_v6_icon_arrow_down;
        } else {
            i2 = R$mipmap.transaction_down;
        }
        ImageView imageView = transactionTypeGroupBinding.b;
        imageView.setImageResource(i2);
        imageView.setVisibility(0);
        transactionTypeGroupBinding.d.setOnClickListener(new b(1, this, transactionTypeGroup));
        transactionTypeGroupBinding.e.setVisibility(0);
    }

    public final int getItemCount() {
        ArrayList arrayList = this.a;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }

    public final int getItemViewType(int i) {
        return R$layout.transaction_type_group;
    }

    @NonNull
    public final RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new BaseViewHolder(DataBindingUtil.inflate(LayoutInflater.from(viewGroup.getContext()), i, viewGroup, false));
    }

    public final void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i, @NonNull List list) {
        BaseViewHolder baseViewHolder = (BaseViewHolder) viewHolder;
        if (!list.isEmpty()) {
            T t = baseViewHolder.a;
            if (t instanceof TransactionTypeGroupBinding) {
                ((TransactionTypeGroupBinding) t).b.setImageResource(!((TransactionTypeGroup) this.a.get(i)).isShow() ? R$mipmap.home_v6_icon_arrow_down : R$mipmap.transaction_down);
                return;
            }
            return;
        }
        onBindViewHolder(baseViewHolder, i);
    }
}
