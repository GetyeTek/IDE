package com.huawei.digitalpayment.customer.homev6.pop;

import java.io.Serializable;
import java.util.List;

public class TransactionTypeGroup implements Serializable {
    private String groupId;
    private String groupName;
    private List<TransactionTypeBean> list;
    private boolean show;

    public String getGroupId() {
        return this.groupId;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public List<TransactionTypeBean> getList() {
        return this.list;
    }

    public boolean isShow() {
        return this.show;
    }

    public void setGroupId(String str) {
        this.groupId = str;
    }

    public void setGroupName(String str) {
        this.groupName = str;
    }

    public void setList(List<TransactionTypeBean> list2) {
        this.list = list2;
    }

    public void setShow(boolean z) {
        this.show = z;
    }
}
