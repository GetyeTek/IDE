package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.customer.baselib.R$drawable;
import com.huawei.digitalpayment.customer.baselib.R$styleable;
import java.util.ArrayList;

public class EnterPinView extends LinearLayout {
    public int a = 6;
    public final ArrayList<View> b = new ArrayList<>();
    public int c;
    public String d = "";
    public int e = -1;
    public boolean f;
    public a g;

    public interface a {
    }

    public EnterPinView(Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f = false;
        setGravity(17);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.EnterPinView);
        this.c = obtainStyledAttributes.getDimensionPixelSize(R$styleable.EnterPinView_pin_radius, 14);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(R$styleable.EnterPinView_pin_space, 10);
        for (int i = 0; i < this.a; i++) {
            View view = new View(context);
            int i2 = this.c;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i2, i2);
            layoutParams.setMargins(dimensionPixelSize, dimensionPixelSize, dimensionPixelSize, dimensionPixelSize);
            view.setLayoutParams(layoutParams);
            view.setBackgroundResource(R$drawable.enter_pin_view_bg);
            this.b.add(view);
            addView(view);
        }
        obtainStyledAttributes.recycle();
    }

    public final void a() {
        int i = this.e;
        if (i != -1) {
            while (i >= 0) {
                this.b.get(i).setBackgroundResource(R$drawable.enter_pin_view_bg);
                i--;
            }
            this.d = "";
            this.e = -1;
            this.f = false;
        }
    }

    public String getPinText() {
        return this.d;
    }

    public void setDigits(int i) {
        this.a = i;
    }

    public void setEnterFinishListener(a aVar) {
        this.g = aVar;
    }

    public void setPinText(String str) {
        this.d = str;
    }

    public void setRadius(int i) {
        this.c = i;
    }
}
