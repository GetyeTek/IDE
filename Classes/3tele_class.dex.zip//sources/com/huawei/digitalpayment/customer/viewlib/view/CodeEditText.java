package com.huawei.digitalpayment.customer.viewlib.view;

import R9.h;
import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import com.blankj.utilcode.util.l;
import com.huawei.digitalpayment.customer.baselib.R$styleable;
import java.util.Timer;
import t4.c;

public class CodeEditText extends SafeKeyBoardEditText {
    public final Activity A;
    public final c B;
    public final String C = "1";
    public final int i = Color.parseColor("#1AAD19");
    public final int j = Color.parseColor("#EFEFEF");
    public final int k = Color.parseColor("#A4AEB5");
    public final int l = Color.parseColor("#D1D6DA");
    public int m;
    public final boolean n;
    public boolean o = false;
    public final float p;
    public final float q;
    public float r;
    public float s;
    public final float t;
    public final RectF u = new RectF();
    public final Rect v = new Rect();
    public final Paint w;
    public final Paint x;
    public final Paint y;
    public Timer z;

    public interface a {
    }

    /* JADX WARNING: type inference failed for: r6v19, types: [java.lang.Object, android.view.ActionMode$Callback] */
    public CodeEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.A = (Activity) context;
        if (!hasFocus()) {
            requestFocus();
        }
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.CodeEditText);
        this.i = obtainStyledAttributes.getColor(R$styleable.CodeEditText_focus_color, this.i);
        this.j = obtainStyledAttributes.getColor(R$styleable.CodeEditText_empty_bg_color, this.j);
        this.k = obtainStyledAttributes.getColor(R$styleable.CodeEditText_stroke_color, this.k);
        this.p = obtainStyledAttributes.getDimension(R$styleable.CodeEditText_stroke_width, (float) h.a(getContext(), 2.0f));
        this.q = obtainStyledAttributes.getDimension(R$styleable.CodeEditText_rect_margin, (float) h.a(getContext(), 6.0f));
        this.t = obtainStyledAttributes.getDimension(R$styleable.CodeEditText_corner_radius, (float) h.a(getContext(), 3.0f));
        this.n = obtainStyledAttributes.getBoolean(R$styleable.CodeEditText_use_safe_keyboard, false);
        this.C = obtainStyledAttributes.getString(R$styleable.CodeEditText_edit_test_style);
        obtainStyledAttributes.recycle();
        setBackground((Drawable) null);
        setCursorVisible(false);
        setInputType(2);
        setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        this.B = new c(this);
        this.z = new Timer();
        Paint paint = new Paint();
        this.w = paint;
        paint.setStyle(Paint.Style.STROKE);
        this.w.setStrokeWidth(1.0f);
        this.w.setColor(this.k);
        Paint paint2 = new Paint(1);
        this.x = paint2;
        paint2.setStyle(Paint.Style.FILL);
        this.x.setColor(this.j);
        Paint paint3 = new Paint(1);
        this.y = paint3;
        paint3.setStyle(Paint.Style.FILL_AND_STROKE);
        this.y.setStrokeWidth((float) h.a(getContext(), 2.0f));
        this.y.setColor(this.i);
        if (this.n) {
            l.b(this);
        }
        setCustomSelectionActionModeCallback(new Object());
        setLongClickable(false);
        setImeOptions(268435456);
    }

    public final void b() {
        if (this.n) {
            super.b();
        } else {
            l.a(this.A);
        }
    }

    public final void d() {
        if (this.n) {
            super.d();
        } else {
            l.c(this.A);
        }
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.z.scheduleAtFixedRate(this.B, 0, 500);
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.z.cancel();
        this.z = null;
    }

    /* JADX WARNING: type inference failed for: r12v0, types: [com.huawei.digitalpayment.customer.viewlib.view.CodeEditText, android.widget.TextView, android.view.View] */
    public final void onDraw(Canvas canvas) {
        int i2;
        int i5;
        int i6;
        int i7;
        int i8;
        boolean isEmpty = TextUtils.isEmpty(this.C);
        int i9 = this.l;
        RectF rectF = this.u;
        if (isEmpty || TextUtils.equals(this.C, "1")) {
            float f = this.p;
            canvas.translate(f, f);
            this.w.setStrokeWidth(1.0f);
            for (int i10 = 0; i10 < 6; i10++) {
                float f2 = this.r;
                float f5 = (this.q + f2) * ((float) i10);
                rectF.set(f5, 0.0f, f2 + f5, this.s);
                Paint paint = this.x;
                if (i10 > getEditableText().length()) {
                    i5 = this.j;
                } else {
                    i5 = 0;
                }
                paint.setColor(i5);
                Paint paint2 = this.w;
                if (i10 > getEditableText().length()) {
                    i6 = i9;
                } else {
                    i6 = this.k;
                }
                paint2.setColor(i6);
                float f6 = this.t;
                canvas.drawRoundRect(rectF, f6, f6, this.x);
                float f7 = this.t;
                canvas.drawRoundRect(rectF, f7, f7, this.w);
            }
            this.m = Math.max(0, getEditableText().length());
            this.w.setColor(this.i);
            this.w.setStrokeWidth(this.p);
            float f8 = this.r;
            float f9 = (this.q + f8) * ((float) this.m);
            rectF.set(f9, 0.0f, f8 + f9, this.s);
            float f10 = this.t;
            canvas.drawRoundRect(rectF, f10, f10, this.w);
        } else {
            float f11 = this.p;
            canvas.translate(f11, f11);
            this.w.setStrokeWidth(1.0f);
            for (int i11 = 0; i11 < 6; i11++) {
                float f12 = (float) i11;
                float f13 = this.r;
                float f14 = (this.q + f13) * f12;
                rectF.set(f14, 0.0f, f13 + f14, this.s);
                Paint paint3 = this.x;
                if (i11 > getEditableText().length()) {
                    i7 = this.j;
                } else {
                    i7 = 0;
                }
                paint3.setColor(i7);
                Paint paint4 = this.w;
                if (i11 > getEditableText().length()) {
                    i8 = i9;
                } else {
                    i8 = this.k;
                }
                paint4.setColor(i8);
                float f15 = this.r;
                float f16 = (this.q + f15) * f12;
                float f17 = this.s;
                canvas.drawLine(f16, f17, f16 + f15, f17, this.w);
            }
            this.m = Math.max(0, getEditableText().length());
            this.w.setColor(this.i);
            this.w.setStrokeWidth(this.p);
            float f18 = this.r;
            float f19 = (this.q + f18) * ((float) this.m);
            rectF.set(f19, 0.0f, f18 + f19, this.s);
            float f20 = this.r;
            float f21 = (this.q + f20) * ((float) this.m);
            float f22 = this.s;
            canvas.drawLine(f21, f22, f21 + f20, f22, this.w);
        }
        int length = getEditableText().length();
        for (int i12 = 0; i12 < length; i12++) {
            String valueOf = String.valueOf(getEditableText().charAt(i12));
            TextPaint paint5 = getPaint();
            paint5.setColor(getCurrentTextColor());
            Rect rect = this.v;
            paint5.getTextBounds(valueOf, 0, 1, rect);
            float f23 = this.r;
            float centerX = (((f23 + this.q) * ((float) i12)) + (f23 / 2.0f)) - ((float) rect.centerX());
            float height = (this.s / 2.0f) + ((float) (rect.height() / 2));
            if (this.n) {
                valueOf = "*";
            }
            canvas.drawText(valueOf, centerX, height, paint5);
        }
        if (hasFocus() && this.o && (i2 = this.m) < 6) {
            float f24 = this.r;
            float f25 = ((f24 + this.q) * ((float) i2)) + (f24 / 2.0f);
            float f26 = this.s;
            float f27 = f26 / 4.0f;
            canvas.drawLine(f25, f27, f25, f26 - f27, this.y);
        }
    }

    public final void onFocusChanged(boolean z2, int i2, Rect rect) {
        super.onFocusChanged(z2, i2, rect);
        if (z2) {
            d();
        } else {
            b();
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.digitalpayment.customer.viewlib.view.CodeEditText, android.widget.EditText] */
    public final void onSizeChanged(int i2, int i5, int i6, int i7) {
        CodeEditText.super.onSizeChanged(i2, i5, i6, i7);
        float f = this.p;
        this.r = ((((float) i2) - (f * 2.0f)) - (this.q * 5.0f)) / 6.0f;
        this.s = ((float) i5) - (f * 2.0f);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.digitalpayment.customer.viewlib.view.CodeEditText, android.widget.TextView, android.widget.EditText] */
    public final void onTextChanged(CharSequence charSequence, int i2, int i5, int i6) {
        CodeEditText.super.onTextChanged(charSequence, i2, i5, i6);
        getEditableText().length();
    }

    public void setOnInputFinishListener(a aVar) {
    }
}
