package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.blankj.utilcode.util.p;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseNormalTextlinerBinding;
import d2.a;

public class NormalTextLayout extends ConstraintLayout implements View.OnFocusChangeListener {
    public final Context a;
    public BaseNormalTextlinerBinding b;

    public NormalTextLayout(@NonNull Context context) {
        super(context);
        this.a = context;
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [com.huawei.digitalpayment.customer.viewlib.view.NormalTextLayout, android.view.View, android.view.ViewGroup] */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0046, code lost:
        r0 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(android.util.AttributeSet r11) {
        /*
            r10 = this;
            if (r11 == 0) goto L_0x0013
            android.content.Context r0 = r10.a
            int[] r1 = com.huawei.digitalpayment.customer.baselib.R$styleable.NormalEditText
            android.content.res.TypedArray r11 = r0.obtainStyledAttributes(r11, r1)
            int r0 = com.huawei.digitalpayment.customer.baselib.R$styleable.NormalEditText_isNeedRegEx
            r1 = 1
            r11.getBoolean(r0, r1)
            r11.recycle()
        L_0x0013:
            android.content.Context r11 = r10.getContext()
            android.view.LayoutInflater r11 = android.view.LayoutInflater.from(r11)
            int r0 = com.huawei.digitalpayment.customer.baselib.R$layout.base_normal__textliner
            r1 = 0
            android.view.View r11 = r11.inflate(r0, r10, r1)
            r10.addView(r11)
            int r0 = com.huawei.digitalpayment.customer.baselib.R$id.et_mobile_number
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r0)
            r4 = r1
            android.widget.LinearLayout r4 = (android.widget.LinearLayout) r4
            if (r4 == 0) goto L_0x0073
            int r0 = com.huawei.digitalpayment.customer.baselib.R$id.imageselectdown
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r0)
            r5 = r1
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            if (r5 == 0) goto L_0x0073
            int r0 = com.huawei.digitalpayment.customer.baselib.R$id.iv_input_error
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r0)
            r6 = r1
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x0073
            int r0 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r0)
            r7 = r1
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            if (r7 == 0) goto L_0x0073
            int r0 = com.huawei.digitalpayment.customer.baselib.R$id.tv_error_tip
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r0)
            r8 = r1
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0073
            int r0 = com.huawei.digitalpayment.customer.baselib.R$id.tvshowmessage
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r0)
            r9 = r1
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0073
            com.huawei.digitalpayment.customer.baselib.databinding.BaseNormalTextlinerBinding r0 = new com.huawei.digitalpayment.customer.baselib.databinding.BaseNormalTextlinerBinding
            r3 = r11
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r2 = r0
            r2.<init>(r3, r4, r5, r6, r7, r8, r9)
            r10.b = r0
            return
        L_0x0073:
            android.content.res.Resources r11 = r11.getResources()
            java.lang.String r11 = r11.getResourceName(r0)
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Missing required view with ID: "
            java.lang.String r11 = r1.concat(r11)
            r0.<init>(r11)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.viewlib.view.NormalTextLayout.a(android.util.AttributeSet):void");
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.digitalpayment.customer.viewlib.view.NormalTextLayout, android.view.View] */
    public final void b() {
        a baseFilletView = this.b.e.getBaseFilletView();
        if (!TextUtils.isEmpty(this.b.f.getText().toString())) {
            baseFilletView.e(getResources().getColor(R$color.colorError));
        } else {
            baseFilletView.e(getResources().getColor(R$color.colorPageBackgroundDark));
        }
    }

    public String getText() {
        return this.b.g.getText().toString().trim();
    }

    public final void onFocusChange(View view, boolean z) {
        b();
    }

    public void setAreaCode(String str) {
        this.b.g.setText(str);
        if (p.b(str)) {
            this.b.g.setVisibility(8);
        } else {
            this.b.g.setVisibility(0);
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.digitalpayment.customer.viewlib.view.NormalTextLayout, android.view.ViewGroup] */
    public void setEnabled(boolean z) {
        if (!z) {
            this.b.c.setVisibility(4);
        }
        NormalTextLayout.super.setEnabled(z);
    }

    public void setError(String str) {
        if (str == null) {
            str = "";
        }
        this.b.f.setText(str);
        if (TextUtils.isEmpty(str)) {
            this.b.d.setVisibility(8);
            this.b.f.setVisibility(8);
            this.b.c.setVisibility(0);
        } else {
            this.b.d.setVisibility(0);
            this.b.f.setVisibility(0);
            this.b.c.setVisibility(8);
        }
        b();
    }

    public void setMessageSize(int i) {
        this.b.g.setTextSize(2, (float) i);
    }

    public void setNeedRegEx(boolean z) {
    }

    public void setRegEx(String str) {
    }

    public void setStrokeWidth(int i) {
        this.b.e.getBaseFilletView().f(i);
    }

    public void setText(String str) {
        this.b.g.setText(str);
    }

    public NormalTextLayout(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = context;
        a(attributeSet);
    }

    public NormalTextLayout(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = context;
        a(attributeSet);
    }
}
