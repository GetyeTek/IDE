package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutPwdEditTextBinding;
import d2.a;

public class PwdInputEditText extends ConstraintLayout implements View.OnFocusChangeListener {
    public LayoutPwdEditTextBinding a;
    public boolean b;

    public PwdInputEditText(@NonNull Context context) {
        super(context);
        a();
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.view.View$OnFocusChangeListener, android.view.View, java.lang.Object, com.huawei.digitalpayment.customer.viewlib.view.PwdInputEditText, android.view.ViewGroup] */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0026, code lost:
        r1 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a() {
        /*
            r5 = this;
            android.content.Context r0 = r5.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r1 = com.huawei.digitalpayment.customer.baselib.R$layout.layout_pwd_edit_text
            r2 = 0
            android.view.View r0 = r0.inflate(r1, r5, r2)
            r5.addView(r0)
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.et_input
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.EditText r2 = (android.widget.EditText) r2
            if (r2 == 0) goto L_0x0054
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.iv_pwd_mode
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            if (r3 == 0) goto L_0x0054
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundLinearLayout r4 = (com.huawei.common.widget.round.RoundLinearLayout) r4
            if (r4 == 0) goto L_0x0054
            com.huawei.digitalpayment.customer.baselib.databinding.LayoutPwdEditTextBinding r1 = new com.huawei.digitalpayment.customer.baselib.databinding.LayoutPwdEditTextBinding
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1.<init>(r0, r2, r3, r4)
            r5.a = r1
            r2.setOnFocusChangeListener(r5)
            com.huawei.digitalpayment.customer.baselib.databinding.LayoutPwdEditTextBinding r0 = r5.a
            android.widget.EditText r0 = r0.b
            r1 = 18
            r0.setInputType(r1)
            com.huawei.digitalpayment.customer.baselib.databinding.LayoutPwdEditTextBinding r0 = r5.a
            android.widget.ImageView r0 = r0.c
            R4.a r1 = new R4.a
            r2 = 9
            r1.<init>(r5, r2)
            r0.setOnClickListener(r1)
            return
        L_0x0054:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.viewlib.view.PwdInputEditText.a():void");
    }

    public EditText getEditText() {
        return this.a.b;
    }

    public String getText() {
        return this.a.b.getText().toString();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.view.View, com.huawei.digitalpayment.customer.viewlib.view.PwdInputEditText] */
    public final void onFocusChange(View view, boolean z) {
        a baseFilletView = this.a.d.getBaseFilletView();
        if (!z) {
            baseFilletView.e(getResources().getColor(R$color.colorWhite));
        } else {
            baseFilletView.e(getResources().getColor(R$color.colorPrimary));
        }
    }

    public PwdInputEditText(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        a();
    }

    public PwdInputEditText(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a();
    }
}
