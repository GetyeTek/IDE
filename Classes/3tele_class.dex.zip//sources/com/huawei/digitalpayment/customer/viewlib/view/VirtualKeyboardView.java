package com.huawei.digitalpayment.customer.viewlib.view;

import H6.i;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Vibrator;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RelativeLayout;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.l;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.R$styleable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import p4.c;

public class VirtualKeyboardView extends RelativeLayout implements c.a {
    public static final /* synthetic */ int f = 0;
    public final Context a;
    public EditText b;
    public final GridView c;
    public final ArrayList<Map<String, String>> d;
    public final boolean e;

    public interface a {
    }

    public VirtualKeyboardView(Context context) {
        this(context, (AttributeSet) null);
    }

    public final void F(String str) {
        if (this.b != null) {
            Vibrator vibrator = (Vibrator) this.a.getSystemService("vibrator");
            if (vibrator != null) {
                vibrator.vibrate(30);
            }
            int selectionEnd = this.b.getSelectionEnd();
            Editable text = this.b.getText();
            if (!"BACK_COMMAND".equals(str)) {
                text.insert(selectionEnd, str);
            } else if (selectionEnd > 0) {
                text.replace(selectionEnd - 1, selectionEnd, "");
            }
        }
    }

    public final void K() {
        EditText editText = this.b;
        if (editText != null) {
            editText.getSelectionEnd();
            this.b.getText();
            int selectionEnd = this.b.getSelectionEnd();
            Editable text = this.b.getText();
            Vibrator vibrator = (Vibrator) this.a.getSystemService("vibrator");
            if (vibrator != null) {
                vibrator.vibrate(30);
            }
            while (selectionEnd > 0) {
                text.replace(selectionEnd - 1, selectionEnd, "");
                selectionEnd = this.b.getSelectionEnd();
                text = this.b.getText();
            }
        }
    }

    public final void a(FragmentActivity fragmentActivity, EditText editText) {
        this.b = editText;
        l.a(fragmentActivity);
        this.b.setOnClickListener(new i(this, 8));
    }

    public GridView getGridView() {
        return this.c;
    }

    public ArrayList<Map<String, String>> getValueList() {
        return this.d;
    }

    public void setEditText(EditText editText) {
        this.b = editText;
    }

    public void setOnVirtualKeyboardFinish(a aVar) {
    }

    public VirtualKeyboardView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        c cVar;
        this.a = context;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VirtualKeyboardView);
        obtainStyledAttributes.getBoolean(R$styleable.VirtualKeyboardView_show_finish, true);
        this.e = obtainStyledAttributes.getBoolean(R$styleable.VirtualKeyboardView_isShuffleKeyboard, false);
        obtainStyledAttributes.recycle();
        View inflate = View.inflate(context, R$layout.layout_key_board, (ViewGroup) null);
        this.d = new ArrayList<>();
        this.c = (GridView) inflate.findViewById(R$id.gv_keybord);
        for (int i = 1; i < 13; i++) {
            HashMap hashMap = new HashMap();
            if (i < 10) {
                hashMap.put("name", String.valueOf(i));
            } else if (i == 10) {
                hashMap.put("name", "");
            } else if (i == 11) {
                hashMap.put("name", String.valueOf(0));
            } else {
                hashMap.put("name", "back");
            }
            this.d.add(hashMap);
        }
        boolean z = this.e;
        ArrayList<Map<String, String>> arrayList = this.d;
        Context context2 = this.a;
        if (z) {
            B1.c.b(arrayList);
            cVar = new c(context2, arrayList);
        } else {
            cVar = new c(context2, arrayList);
        }
        cVar.c = this;
        this.c.setAdapter(cVar);
        addView(inflate);
    }
}
