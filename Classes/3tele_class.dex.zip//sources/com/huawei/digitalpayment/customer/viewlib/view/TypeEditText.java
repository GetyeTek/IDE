package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.blankj.utilcode.util.p;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding;
import d2.a;

public class TypeEditText extends ConstraintLayout implements View.OnFocusChangeListener {
    public BaseInputEditTextBinding a;

    public TypeEditText(@NonNull Context context) {
        super(context);
        a();
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [com.huawei.digitalpayment.customer.viewlib.view.TypeEditText, android.view.View$OnFocusChangeListener, android.view.View, java.lang.Object, android.view.ViewGroup] */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0027, code lost:
        r1 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a() {
        /*
            r10 = this;
            android.content.Context r0 = r10.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r1 = com.huawei.digitalpayment.customer.baselib.R$layout.base_input_edit_text
            r2 = 0
            android.view.View r0 = r0.inflate(r1, r10, r2)
            r10.addView(r0)
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.et_mobile_number
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.EditText r2 = (android.widget.EditText) r2
            if (r2 == 0) goto L_0x0065
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.iv_input_error
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r3
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x0065
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r3
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            if (r7 == 0) goto L_0x0065
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.tv_area_code
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r3
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0065
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.tv_error_tip
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r3
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0065
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r1 = new com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r5 = r2
            r3.<init>(r4, r5, r6, r7, r8, r9)
            r10.a = r1
            r2.setOnFocusChangeListener(r10)
            com.huawei.digitalpayment.customer.baselib.databinding.BaseInputEditTextBinding r0 = r10.a
            android.widget.EditText r0 = r0.b
            com.huawei.kbz.chat.chat_room.t r1 = new com.huawei.kbz.chat.chat_room.t
            r2 = 1
            r1.<init>(r10, r2)
            r0.addTextChangedListener(r1)
            return
        L_0x0065:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.viewlib.view.TypeEditText.a():void");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.digitalpayment.customer.viewlib.view.TypeEditText, android.view.View] */
    public final void b(boolean z) {
        a baseFilletView = this.a.d.getBaseFilletView();
        if (!TextUtils.isEmpty(this.a.f.getText().toString())) {
            baseFilletView.e(getResources().getColor(R$color.colorError));
        } else if (!z) {
            baseFilletView.e(getResources().getColor(R$color.common_input_unfocus_color));
        } else {
            baseFilletView.e(getResources().getColor(R$color.common_input_focus_color));
        }
    }

    public String getText() {
        return this.a.e.getText().toString().trim() + this.a.b.getText().toString().trim();
    }

    public final void onFocusChange(View view, boolean z) {
        b(z);
    }

    public void setAreaCode(String str) {
        this.a.e.setText(str);
        if (p.b(str)) {
            this.a.e.setVisibility(8);
        } else {
            this.a.e.setVisibility(0);
        }
    }

    public void setError(String str) {
        this.a.f.setText(str);
        if (TextUtils.isEmpty(str)) {
            this.a.c.setVisibility(8);
            this.a.f.setVisibility(8);
        } else {
            this.a.c.setVisibility(0);
            this.a.f.setVisibility(0);
        }
        b(this.a.b.hasFocus());
    }

    public TypeEditText(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        a();
    }

    public TypeEditText(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a();
    }
}
