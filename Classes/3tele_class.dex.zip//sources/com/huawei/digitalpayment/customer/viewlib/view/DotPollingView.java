package com.huawei.digitalpayment.customer.viewlib.view;

import V1.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.R$styleable;

public class DotPollingView extends View {
    public final Paint a;
    public final Paint b;
    public int c;
    public int d;
    public int e;
    public int f;
    public float g;
    public float h;
    public int i;
    public int j;
    public int k;
    public int l;
    public final int m;
    public int n;

    public DotPollingView(Context context) {
        this(context, (AttributeSet) null);
    }

    public final void onDraw(Canvas canvas) {
        int i2;
        int i5;
        super.onDraw(canvas);
        Paint paint = this.b;
        paint.setAlpha(255);
        Paint paint2 = this.a;
        paint2.setAlpha(255);
        if (this.n == 257) {
            this.g += this.h;
            this.l += 12;
        } else {
            this.g -= this.h;
            this.l -= 12;
        }
        int i6 = this.l;
        int i7 = this.m;
        if (i6 >= i7) {
            this.l = i7;
        }
        int i8 = this.e;
        int i9 = this.f;
        int width = ((getWidth() / 2) - ((((i8 - 1) * this.j) + ((i8 * i9) * 2)) / 2)) + i9;
        int height = getHeight() / 2;
        int i10 = 0;
        while (true) {
            i2 = this.e;
            if (i10 >= i2) {
                break;
            }
            int i11 = this.k;
            if (i11 == i10) {
                paint2.setAlpha(255 - this.l);
                int i12 = this.k;
                int i13 = this.f;
                canvas.drawCircle((float) ((((i13 * 2) + this.j) * i12) + width), (float) height, ((float) i13) + this.g, paint2);
            } else if (i11 <= 1 || i11 - 2 != i10) {
                paint.setAlpha(255);
                int i14 = this.f;
                canvas.drawCircle((float) ((((i14 * 2) + this.j) * i10) + width), (float) height, (float) i14, paint);
            } else {
                paint.setAlpha(255 - this.l);
                int i15 = this.f;
                canvas.drawCircle((float) ((((i15 * 2) + this.j) * (this.k - 2)) + width), (float) height, (float) i15, paint);
            }
            i10++;
        }
        float f2 = this.g;
        float f5 = (float) (this.i - this.f);
        if (f2 >= f5 && this.n == 257) {
            this.g = f5;
            this.n = 258;
        } else if (f2 <= 0.0f && this.n == 258) {
            this.n = 257;
            this.g = 0.0f;
            int i16 = this.k;
            if (i16 == i2 - 1) {
                i5 = 0;
            } else {
                i5 = i16 + 1;
            }
            this.k = i5;
            this.l = 0;
        }
        invalidate();
    }

    public final void onMeasure(int i2, int i5) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i5);
        int size2 = View.MeasureSpec.getSize(i5);
        if (mode == 1073741824) {
            h.b();
        } else {
            int i6 = this.e;
            int i7 = this.f;
            int i8 = ((this.i - i7) * 2) + ((i6 - 1) * this.j) + (i6 * i7 * 2);
            h.b();
            if (mode == Integer.MIN_VALUE) {
                size = Math.min(i8, size);
                h.b();
            } else {
                size = i8;
            }
        }
        if (mode2 == 1073741824) {
            h.b();
        } else {
            int i9 = this.i * 2;
            h.b();
            if (mode2 == Integer.MIN_VALUE) {
                size2 = Math.min(i9, size2);
                h.b();
            } else {
                size2 = i9;
            }
        }
        setMeasuredDimension(size, size2);
    }

    public void setColor(int i2) {
        this.c = i2;
        this.b.setColor(i2);
    }

    public void setDotMaxRadius(int i2) {
        this.i = i2;
    }

    public void setDotRadius(int i2) {
        this.f = i2;
    }

    public void setDotSpacing(int i2) {
        this.j = i2;
    }

    public void setDotTotalCount(int i2) {
        this.e = i2;
    }

    public void setRadiusChangeRate(float f2) {
        this.h = f2;
    }

    public void setSelectedColor(int i2) {
        this.d = i2;
        this.a.setColor(i2);
    }

    public DotPollingView(Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DotPollingView(Context context, @Nullable AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        Paint paint = new Paint();
        this.a = paint;
        Paint paint2 = new Paint();
        this.b = paint2;
        this.e = 3;
        this.k = 0;
        this.l = 0;
        this.m = 220;
        this.n = 257;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.DotPollingView, i2, 0);
        this.c = obtainStyledAttributes.getColor(R$styleable.DotPollingView_dotP_dot_color, ContextCompat.getColor(getContext(), R$color.colorTextLevel4));
        this.d = obtainStyledAttributes.getColor(R$styleable.DotPollingView_dotP_dot_selected_color, ContextCompat.getColor(getContext(), R$color.colorWhite));
        this.f = obtainStyledAttributes.getDimensionPixelSize(R$styleable.DotPollingView_dotP_dot_radius, R9.h.a(getContext(), 3.0f));
        this.i = obtainStyledAttributes.getDimensionPixelSize(R$styleable.DotPollingView_dotP_dot_max_radius, R9.h.a(getContext(), 5.0f));
        this.j = obtainStyledAttributes.getDimensionPixelSize(R$styleable.DotPollingView_dotP_dot_spacing, R9.h.a(getContext(), 6.0f));
        this.e = obtainStyledAttributes.getInteger(R$styleable.DotPollingView_dotP_dot_count, 3);
        this.h = obtainStyledAttributes.getFloat(R$styleable.DotPollingView_dotP_dot_size_change_rate, 0.3f);
        obtainStyledAttributes.recycle();
        this.g = 0.0f;
        paint.setColor(this.d);
        paint.setAntiAlias(true);
        Paint.Style style = Paint.Style.FILL;
        paint.setStyle(style);
        paint2.setColor(this.c);
        paint2.setAntiAlias(true);
        paint2.setStyle(style);
    }
}
