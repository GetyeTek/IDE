package com.huawei.digitalpayment.customer.homev6.pop;

import java.io.Serializable;

public class TransactionTypeFilterEvent implements Serializable {
    private String accountType = "";
    private String oppositeParty = "";
    private String transactionType = "";

    public String getAccountType() {
        return this.accountType;
    }

    public String getOppositeParty() {
        return this.oppositeParty;
    }

    public String getTransactionType() {
        return this.transactionType;
    }

    public void setAccountType(String str) {
        this.accountType = str;
    }

    public void setOppositeParty(String str) {
        this.oppositeParty = str;
    }

    public void setTransactionType(String str) {
        this.transactionType = str;
    }
}
