package com.huawei.digitalpayment.customer.homev6.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.homev6.repository.LogoutRepository;
import y9.b;

public class LogoutViewModel extends ViewModel {
    public final MutableLiveData<Boolean> a;
    public final MutableLiveData<Boolean> b;
    public final LogoutRepository c = new LogoutRepository();
    public b d;

    public LogoutViewModel() {
        Boolean bool = Boolean.FALSE;
        this.a = new MutableLiveData<>(bool);
        this.b = new MutableLiveData<>(bool);
    }
}
