package com.huawei.digitalpayment.customer.homev6.model;

import com.huawei.http.BaseResp;

public class GroupReceivePocketMoneyResp extends BaseResp {
    private int fragmentFlag;
    private String functionId;
    private int waiteReceiveNum;

    public int getFragmentFlag() {
        return this.fragmentFlag;
    }

    public String getFunctionId() {
        return this.functionId;
    }

    public int getWaiteReceiveNum() {
        return this.waiteReceiveNum;
    }

    public void setFragmentFlag(int i) {
        this.fragmentFlag = i;
    }

    public void setFunctionId(String str) {
        this.functionId = str;
    }

    public void setWaiteReceiveNum(int i) {
        this.waiteReceiveNum = i;
    }
}
