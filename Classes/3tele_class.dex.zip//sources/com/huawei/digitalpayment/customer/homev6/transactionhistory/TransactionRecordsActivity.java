package com.huawei.digitalpayment.customer.homev6.transactionhistory;

import H3.c;
import P2.a;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.loadmore.BaseLoadMoreView;
import com.huawei.common.widget.dialog.DialogManager;
import com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity;
import com.huawei.digitalpayment.customer.homev6.R$layout;
import com.huawei.digitalpayment.customer.homev6.R$string;
import com.huawei.digitalpayment.customer.homev6.databinding.ActivityTransactionHistoryListBinding;
import com.huawei.digitalpayment.customer.homev6.transactionhistory.adapter.TransRecordsAdapter;
import com.huawei.digitalpayment.customer.httplib.bean.RecordsBean;
import com.huawei.digitalpayment.customer.httplib.request.TransactionSearchBean;
import com.scwang.smart.refresh.header.MaterialHeader;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import h9.e;
import java.util.ArrayList;
import java.util.List;
import x3.C0074a;
import x3.C0075b;
import x3.C0076c;

@Route(path = "/mainModule/transactionHistoryList")
public class TransactionRecordsActivity extends BaseMvpActivity<C0075b> implements C0076c, e {
    public ActivityTransactionHistoryListBinding j;
    public int k = 1;
    public ArrayList l;
    public TransRecordsAdapter m;
    public boolean n = false;
    public boolean o = false;
    public TransactionSearchBean p;
    public String q;

    public final void D0() {
        this.k = 0;
        this.n = false;
        this.p.setPageNum(0);
        C0075b bVar = (C0075b) this.i;
        TransactionSearchBean transactionSearchBean = this.p;
        bVar.getClass();
        transactionSearchBean.setPageSize(10);
        bVar.a(c.e().H0(transactionSearchBean), new C0074a(bVar, (a) bVar.a, true));
    }

    public final void G(String str) {
        DialogManager.b(getSupportFragmentManager());
        this.j.b.i();
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, com.huawei.digitalpayment.customer.homev6.transactionhistory.TransactionRecordsActivity, com.huawei.digitalpayment.customer.baselib.mvp.BaseMvpActivity, h9.e, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity] */
    public final void G0() {
        super.G0();
        this.p = (TransactionSearchBean) getIntent().getSerializableExtra("searchBean");
        this.q = getIntent().getStringExtra("iconUrl");
        N0(this.p.getTransactionType() + getResources().getString(R$string.transaction_title));
        SmartRefreshLayout smartRefreshLayout = this.j.b;
        smartRefreshLayout.S0 = this;
        smartRefreshLayout.r(new MaterialHeader(this));
        if (this.l == null) {
            this.l = new ArrayList();
            ArrayList arrayList = this.l;
            String str = this.q;
            TransactionSearchBean transactionSearchBean = this.p;
            BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_transaction_list, arrayList);
            baseQuickAdapter.a = str;
            baseQuickAdapter.b = transactionSearchBean;
            this.m = baseQuickAdapter;
            baseQuickAdapter.getLoadMoreModule().setLoadMoreView(new BaseLoadMoreView());
            this.m.getLoadMoreModule().setEnableLoadMoreIfNotFullPage(false);
            this.m.getLoadMoreModule().setOnLoadMoreListener(new com.huawei.astp.macle.ui.map.a(this));
            this.j.a.setItemAnimator((RecyclerView.ItemAnimator) null);
            this.j.a.setAdapter(this.m);
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.digitalpayment.customer.homev6.transactionhistory.TransactionRecordsActivity, android.app.Activity] */
    public final ViewBinding K0() {
        LayoutInflater layoutInflater = getLayoutInflater();
        int i = ActivityTransactionHistoryListBinding.c;
        ActivityTransactionHistoryListBinding inflateInternal = ViewDataBinding.inflateInternal(layoutInflater, R$layout.activity_transaction_history_list, (ViewGroup) null, false, DataBindingUtil.getDefaultComponent());
        this.j = inflateInternal;
        return inflateInternal;
    }

    public final A8.c U0() {
        return new A8.c(this);
    }

    public final void V(String str) {
        DialogManager.d(getSupportFragmentManager(), true);
    }

    public final void a(List<RecordsBean> list) {
        this.o = true;
        if (list == null || list.size() <= 0) {
            this.m.getLoadMoreModule().loadMoreComplete();
            return;
        }
        this.k++;
        if (!this.n) {
            this.l.clear();
            this.m.getLoadMoreModule().setEnableLoadMoreIfNotFullPage(false);
        } else if (list.isEmpty()) {
            this.m.getLoadMoreModule().loadMoreEnd();
        } else {
            this.m.getLoadMoreModule().loadMoreComplete();
        }
        this.l.addAll(list);
        this.m.notifyDataSetChanged();
    }

    public final void onRefresh() {
        if (this.o) {
            this.k = 0;
            this.n = false;
            this.p.setPageNum(0);
            C0075b bVar = (C0075b) this.i;
            TransactionSearchBean transactionSearchBean = this.p;
            bVar.getClass();
            transactionSearchBean.setPageSize(10);
            bVar.a(c.e().H0(transactionSearchBean), new C0074a(bVar, (a) bVar.a, true));
        }
    }
}
