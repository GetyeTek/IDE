package com.huawei.digitalpayment.customer.baselib.http;

import java.io.Serializable;

public class BaseResp implements Serializable {
    private static final long serialVersionUID = 4823784496486148578L;
    private String responseCode;
    private String responseDesc;
    private String serverTimestamp;

    public BaseResp() {
    }

    public String getResponseCode() {
        return this.responseCode;
    }

    public String getResponseDesc() {
        return this.responseDesc;
    }

    public String getServerTimestamp() {
        return this.serverTimestamp;
    }

    public void setResponseCode(String str) {
        this.responseCode = str;
    }

    public void setResponseDesc(String str) {
        this.responseDesc = str;
    }

    public void setServerTimestamp(String str) {
        this.serverTimestamp = str;
    }

    public BaseResp(String str, String str2) {
        this.responseCode = str;
        this.responseDesc = str2;
    }

    public BaseResp(String str, String str2, String str3, String str4, String str5, String str6) {
        this.responseCode = str;
        this.responseDesc = str2;
    }
}
