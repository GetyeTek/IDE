package com.huawei.digitalpayment.customer.baselib.session;

import com.huawei.http.BaseResp;
import com.huawei.http.b;

public class TokenTimeRepository extends b<BaseResp, BaseResp> {
    public final String getApiPath() {
        return "v1/ethiopia/appTokenRenewal";
    }
}
