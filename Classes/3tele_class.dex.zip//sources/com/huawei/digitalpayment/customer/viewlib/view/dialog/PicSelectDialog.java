package com.huawei.digitalpayment.customer.viewlib.view.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import com.blankj.utilcode.util.A;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.R$style;

public class PicSelectDialog extends BaseDialog {
    public final Boolean c;
    public d d;

    public class a implements View.OnClickListener {
        public a() {
        }

        public final void onClick(View view) {
            PicSelectDialog.this.d.b();
        }
    }

    public class b implements View.OnClickListener {
        public b() {
        }

        public final void onClick(View view) {
            PicSelectDialog.this.d.a();
        }
    }

    public class c implements View.OnClickListener {

        public class a implements Runnable {
            public a() {
            }

            public final void run() {
                PicSelectDialog picSelectDialog = PicSelectDialog.this;
                picSelectDialog.getDialog().dismiss();
                picSelectDialog.d.cancel();
            }
        }

        public c() {
        }

        public final void onClick(View view) {
            A.h(new a(), 50);
        }
    }

    public interface d {
        void a();

        void b();

        void cancel();
    }

    public PicSelectDialog() {
        this.c = Boolean.TRUE;
    }

    public void onStart() {
        Window window;
        PicSelectDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            window.setBackgroundDrawableResource(17170445);
            H1.c.b(window, R$style.BottomAnimation, dialog, true, true);
        }
    }

    public final void onViewCreated(View view, Bundle bundle) {
        int i;
        PicSelectDialog.super.onViewCreated(view, bundle);
        TextView textView = (TextView) view.findViewById(R$id.tv_take_photo);
        TextView textView2 = (TextView) view.findViewById(R$id.tv_choose_album);
        if (this.c.booleanValue()) {
            i = 0;
        } else {
            i = 8;
        }
        textView2.setVisibility(i);
        textView.setOnClickListener(new a());
        textView2.setOnClickListener(new b());
        ((TextView) view.findViewById(R$id.btn_cancle)).setOnClickListener(new c());
    }

    public final int v0() {
        return R$layout.pic_select_dialog_layout;
    }

    public PicSelectDialog(Boolean bool) {
        this.c = bool;
    }
}
