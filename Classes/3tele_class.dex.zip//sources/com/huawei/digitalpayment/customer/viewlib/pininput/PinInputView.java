package com.huawei.digitalpayment.customer.viewlib.pininput;

import R9.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.customer.baselib.R$drawable;
import com.huawei.digitalpayment.customer.baselib.R$styleable;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

public class PinInputView extends LinearLayout {
    public int a = 6;
    public int b;
    public int c;
    public boolean[] d;
    public final ArrayList e = new ArrayList();
    public a f;

    public interface a {
        void C(byte[] bArr);
    }

    public PinInputView(Context context) {
        super(context);
        c(context, (AttributeSet) null);
    }

    private byte[] getInput() {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (true) {
            ArrayList arrayList = this.e;
            if (i >= arrayList.size()) {
                return sb.toString().getBytes(StandardCharsets.UTF_8);
            }
            sb.append(arrayList.get(i));
            i++;
        }
    }

    public final void a(char c2) {
        a aVar;
        ArrayList arrayList = this.e;
        if (arrayList.size() < this.a) {
            this.d[arrayList.size()] = true;
            arrayList.add(Character.valueOf(c2));
            e();
            if (arrayList.size() == this.a && (aVar = this.f) != null) {
                aVar.C(getInput());
            }
        }
    }

    public final void b() {
        this.e.clear();
        Arrays.fill(this.d, false);
        e();
    }

    public final void c(Context context, @Nullable AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.PinInputView);
        this.a = obtainStyledAttributes.getInt(R$styleable.PinInputView_pin_length, this.a);
        this.c = obtainStyledAttributes.getDimensionPixelSize(R$styleable.PinInputView_pin_circle_size, h.a(context, 14.0f));
        this.b = obtainStyledAttributes.getDimensionPixelSize(R$styleable.PinInputView_pin_circle_margin, h.a(context, 7.5f));
        obtainStyledAttributes.recycle();
        setOrientation(0);
        setGravity(17);
        boolean[] zArr = new boolean[this.a];
        this.d = zArr;
        Arrays.fill(zArr, false);
        int i = this.c;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i, i);
        int i2 = this.b;
        layoutParams.leftMargin = i2;
        layoutParams.rightMargin = i2;
        for (boolean enabled : this.d) {
            View view = new View(getContext());
            view.setEnabled(enabled);
            view.setBackgroundResource(R$drawable.pin_input_view_selector);
            addView(view, layoutParams);
        }
    }

    public final void d() {
        ArrayList arrayList = this.e;
        if (!arrayList.isEmpty()) {
            this.d[arrayList.size() - 1] = false;
            arrayList.remove(arrayList.size() - 1);
            e();
        }
    }

    public final void e() {
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).setEnabled(this.d[i]);
        }
    }

    public void setOnInputFinishListener(a aVar) {
        this.f = aVar;
    }

    public PinInputView(Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        c(context, attributeSet);
    }

    public PinInputView(Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        c(context, attributeSet);
    }
}
