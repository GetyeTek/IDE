package com.huawei.digitalpayment.customer.baselib.service;

import com.alibaba.android.arouter.facade.template.IProvider;

public interface IBasicUiService extends IProvider {
}
