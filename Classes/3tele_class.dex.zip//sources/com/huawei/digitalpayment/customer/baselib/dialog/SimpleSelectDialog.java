package com.huawei.digitalpayment.customer.baselib.dialog;

import androidx.annotation.NonNull;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.bean.user.SimpleSelectItem;
import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;

public class SimpleSelectDialog extends SelectDialog<SimpleSelectItem> {
    public final void x0(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        SimpleSelectItem simpleSelectItem = (SimpleSelectItem) obj;
        super.x0(baseViewHolder, simpleSelectItem);
        baseViewHolder.setText(R$id.tv_content, simpleSelectItem.getTitle());
    }

    public final boolean z0(Object obj) {
        SimpleSelectItem simpleSelectItem = (SimpleSelectItem) obj;
        return false;
    }
}
