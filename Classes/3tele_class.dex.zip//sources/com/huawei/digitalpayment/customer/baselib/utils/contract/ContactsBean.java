package com.huawei.digitalpayment.customer.baselib.utils.contract;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ContactsBean implements Serializable {
    private int id;
    private List<String> mobiles = new ArrayList();
    private String name;

    public void addMobile(String str) {
        if (!this.mobiles.contains(str)) {
            this.mobiles.add(str);
        }
    }

    public int getId() {
        return this.id;
    }

    public List<String> getMobiles() {
        return this.mobiles;
    }

    public String getName() {
        return this.name;
    }

    public void setId(int i) {
        this.id = i;
    }

    public void setMobiles(List<String> list) {
        this.mobiles = list;
    }

    public void setName(String str) {
        this.name = str;
    }
}
