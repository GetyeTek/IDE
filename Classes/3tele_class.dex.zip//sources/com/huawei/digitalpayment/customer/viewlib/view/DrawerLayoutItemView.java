package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import com.bumptech.glide.c;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.R$styleable;
import java.util.Locale;

public class DrawerLayoutItemView extends LinearLayout {
    public final Context a;
    public final ImageView b;
    public final TextView c;
    public final TextView d;
    public final ImageView e;
    public final ImageView f;

    public DrawerLayoutItemView(Context context) {
        this(context, (AttributeSet) null);
    }

    public void setContentDot(String str) {
        TextView textView = (TextView) findViewById(R$id.tv_content_dot);
        textView.setVisibility(0);
        textView.setText(str);
    }

    public void setLeftText(String str) {
        ((TextView) findViewById(R$id.tv_title_content)).setText(str);
    }

    public void setLiftIcon(String str) {
        ImageView imageView = this.b;
        imageView.setVisibility(0);
        Context context = imageView.getContext();
        if (TextUtils.isEmpty(str)) {
            c.h(context).load(-1).into(imageView);
        } else if (str.toLowerCase(Locale.ENGLISH).startsWith("http")) {
            c.h(context).load(str).into(imageView);
        } else {
            int identifier = context.getResources().getIdentifier(str, "mipmap", context.getPackageName());
            if (identifier != 0) {
                c.d(context).c(context).load(Integer.valueOf(identifier)).into(imageView);
            } else {
                c.d(context).c(context).load(-1).into(imageView);
            }
        }
    }

    public void setRightText(String str) {
        ((TextView) findViewById(R$id.tv_text_right)).setText(str);
    }

    public DrawerLayoutItemView(Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(R$layout.menu_item, this);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.DrawerLayoutItemView);
        this.b = (ImageView) findViewById(R$id.iv_left_icon);
        this.c = (TextView) findViewById(R$id.tv_title_content);
        this.d = (TextView) findViewById(R$id.tv_text_right);
        this.e = (ImageView) findViewById(R$id.iv_right_more_icon);
        this.f = (ImageView) findViewById(R$id.iv_right_icon);
        int resourceId = obtainStyledAttributes.getResourceId(R$styleable.DrawerLayoutItemView_leftIcon, -1);
        Context context2 = this.a;
        if (resourceId != -1) {
            float dimension = obtainStyledAttributes.getDimension(R$styleable.DrawerLayoutItemView_leftIconSize, -1.0f);
            if (dimension != -1.0f) {
                int i = (int) ((float) ((int) ((dimension / context2.getResources().getDisplayMetrics().scaledDensity) + 0.5f)));
                this.b.getLayoutParams().height = i;
                this.b.getLayoutParams().width = i;
            }
            this.b.setImageResource(resourceId);
        } else {
            this.b.setVisibility(8);
        }
        int resourceId2 = obtainStyledAttributes.getResourceId(R$styleable.DrawerLayoutItemView_rightIcon, -1);
        if (resourceId2 != -1) {
            this.f.setImageResource(resourceId2);
        } else {
            this.f.setVisibility(8);
        }
        String string = obtainStyledAttributes.getString(R$styleable.DrawerLayoutItemView_titleContent);
        float dimension2 = obtainStyledAttributes.getDimension(R$styleable.DrawerLayoutItemView_titleContentSize, -1.0f);
        this.c.setText(string);
        if (dimension2 != -1.0f) {
            this.c.setTextSize((float) ((int) ((dimension2 / context2.getResources().getDisplayMetrics().scaledDensity) + 0.5f)));
        }
        int color = obtainStyledAttributes.getColor(R$styleable.DrawerLayoutItemView_titleColor, -1);
        if (color != -1) {
            this.c.setTextColor(color);
        }
        this.d.setText(obtainStyledAttributes.getString(R$styleable.DrawerLayoutItemView_rightContent));
        if (obtainStyledAttributes.getBoolean(R$styleable.DrawerLayoutItemView_moreVisible, true)) {
            this.e.setVisibility(0);
        } else {
            this.e.setVisibility(8);
        }
        int color2 = obtainStyledAttributes.getColor(R$styleable.DrawerLayoutItemView_moreIconColor, -1);
        if (color2 != -1) {
            this.e.setColorFilter(color2);
        }
    }

    public DrawerLayoutItemView(Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i, 0);
        this.a = context;
    }
}
