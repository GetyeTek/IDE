package com.huawei.digitalpayment.customer.baselib.utils.random;

import java.security.Provider;

public final class HRIProvider extends Provider {
    private static final long serialVersionUID = 253423509590484384L;

    public HRIProvider() {
        super("HRI", 1.0d, "HRI crypto");
        put("SecureRandom.DevRandomSeed", DevRandomSeed.class.getCanonicalName());
        put("SecureRandom.DevRandomSeed ImplementedIn", "Software");
    }
}
