package com.huawei.digitalpayment.customer.homev6.model;

import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public class QueryVisaResp extends BaseResp {
    private boolean apply;
    private String visaBackgroundUrl;
    private String visaPAN;

    public String getVisaBackgroundUrl() {
        return this.visaBackgroundUrl;
    }

    public String getVisaPAN() {
        return this.visaPAN;
    }

    public boolean isApply() {
        return this.apply;
    }

    public void setApply(boolean z) {
        this.apply = z;
    }

    public void setVisaBackgroundUrl(String str) {
        this.visaBackgroundUrl = str;
    }

    public void setVisaPAN(String str) {
        this.visaPAN = str;
    }
}
