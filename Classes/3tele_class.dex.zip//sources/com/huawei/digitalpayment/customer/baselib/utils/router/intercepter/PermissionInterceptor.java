package com.huawei.digitalpayment.customer.baselib.utils.router.intercepter;

import V1.h;
import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.camera.camera2.internal.c;
import com.alibaba.android.arouter.facade.Postcard;
import com.alibaba.android.arouter.facade.annotation.Interceptor;
import com.alibaba.android.arouter.facade.callback.InterceptorCallback;
import com.alibaba.android.arouter.facade.template.IInterceptor;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.e;
import com.blankj.utilcode.util.q;
import f3.C0019a;
import java.util.ArrayList;

@Interceptor(priority = 2)
public class PermissionInterceptor implements IInterceptor {

    public class a implements q.a {
        public final /* synthetic */ InterceptorCallback a;
        public final /* synthetic */ Postcard b;
        public final /* synthetic */ String c;

        public a(InterceptorCallback interceptorCallback, Postcard postcard, String str) {
            this.a = interceptorCallback;
            this.b = postcard;
            this.c = str;
        }

        public final void a(@NonNull ArrayList arrayList) {
            this.a.onContinue(this.b);
        }

        public final void b(@NonNull ArrayList arrayList) {
            h.b();
            this.a.onInterrupt(new Exception(c.a(new StringBuilder("Not accept "), this.c, " permission!!!")));
            e.b();
        }
    }

    public final void init(Context context) {
    }

    public final void process(Postcard postcard, InterceptorCallback interceptorCallback) {
        String str;
        if (postcard.getExtra() != 1) {
            str = null;
        } else {
            str = "android.permission.CAMERA";
        }
        if (TextUtils.isEmpty(str)) {
            interceptorCallback.onContinue(postcard);
        } else if (q.c(new String[]{str})) {
            interceptorCallback.onContinue(postcard);
        } else {
            A.g(new C0019a(this, postcard, str, interceptorCallback));
        }
    }
}
