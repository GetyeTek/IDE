package com.huawei.digitalpayment.customer.bean.homeconfig;

import java.io.Serializable;

public class HomeSearch implements Serializable {
    private String historyCount;
    private String url;
    private String version;
    private String zxji;

    public String getHistoryCount() {
        return this.historyCount;
    }

    public String getUrl() {
        return this.url;
    }

    public String getVersion() {
        return this.version;
    }

    public String getZxji() {
        return this.zxji;
    }

    public void setHistoryCount(String str) {
        this.historyCount = str;
    }

    public void setUrl(String str) {
        this.url = str;
    }

    public void setVersion(String str) {
        this.version = str;
    }

    public void setZxji(String str) {
        this.zxji = str;
    }
}
