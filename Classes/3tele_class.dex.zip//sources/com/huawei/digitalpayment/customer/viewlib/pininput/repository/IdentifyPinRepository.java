package com.huawei.digitalpayment.customer.viewlib.pininput.repository;

import com.google.gson.JsonObject;
import com.huawei.http.b;

public class IdentifyPinRepository extends b<JsonObject, JsonObject> {
    public final String getApiPath() {
        return "v1/authSensitiveOperation";
    }
}
