package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.viewlib.view.EnterPinView;

public final class LayoutEnterPinFragmentBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final GridView c;
    @NonNull
    public final EnterPinView d;
    @NonNull
    public final TextView e;

    public LayoutEnterPinFragmentBinding(@NonNull ConstraintLayout constraintLayout, @NonNull ImageView imageView, @NonNull GridView gridView, @NonNull EnterPinView enterPinView, @NonNull TextView textView) {
        this.a = constraintLayout;
        this.b = imageView;
        this.c = gridView;
        this.d = enterPinView;
        this.e = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
