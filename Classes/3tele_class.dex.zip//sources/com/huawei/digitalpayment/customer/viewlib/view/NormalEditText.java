package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.blankj.utilcode.util.p;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.databinding.BaseNormalinputEditTextBinding;
import d2.a;
import java.util.regex.Pattern;

public class NormalEditText extends ConstraintLayout implements View.OnFocusChangeListener {
    public final Context a;
    public BaseNormalinputEditTextBinding b;
    public String c = "^{2,30}$";
    public final String d = "^{1,30}$";
    public boolean e;
    public boolean f;
    public String g = "";

    public NormalEditText(@NonNull Context context) {
        super(context);
        this.a = context;
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [android.view.View$OnFocusChangeListener, com.huawei.digitalpayment.customer.viewlib.view.NormalEditText, android.view.View, android.view.ViewGroup] */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0045, code lost:
        r1 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(android.util.AttributeSet r11) {
        /*
            r10 = this;
            r0 = 0
            if (r11 == 0) goto L_0x001f
            android.content.Context r1 = r10.a
            int[] r2 = com.huawei.digitalpayment.customer.baselib.R$styleable.NormalEditText
            android.content.res.TypedArray r11 = r1.obtainStyledAttributes(r11, r2)
            int r1 = com.huawei.digitalpayment.customer.baselib.R$styleable.NormalEditText_isNeedRegEx
            r2 = 1
            boolean r1 = r11.getBoolean(r1, r2)
            r10.e = r1
            int r1 = com.huawei.digitalpayment.customer.baselib.R$styleable.NormalEditText_isJudugeContinuationWords
            boolean r1 = r11.getBoolean(r1, r0)
            r10.f = r1
            r11.recycle()
        L_0x001f:
            android.content.Context r11 = r10.getContext()
            android.view.LayoutInflater r11 = android.view.LayoutInflater.from(r11)
            int r1 = com.huawei.digitalpayment.customer.baselib.R$layout.base_normalinput_edit_text
            android.view.View r11 = r11.inflate(r1, r10, r0)
            r10.addView(r11)
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.et_mobile_number
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r1)
            android.widget.EditText r2 = (android.widget.EditText) r2
            if (r2 == 0) goto L_0x0085
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.iv_input_error
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r1)
            r6 = r3
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x0085
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.ll_input
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r1)
            r7 = r3
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            if (r7 == 0) goto L_0x0085
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.tv_area_code
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r1)
            r8 = r3
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0085
            int r1 = com.huawei.digitalpayment.customer.baselib.R$id.tv_error_tip
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r11, r1)
            r9 = r3
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0085
            com.huawei.digitalpayment.customer.baselib.databinding.BaseNormalinputEditTextBinding r1 = new com.huawei.digitalpayment.customer.baselib.databinding.BaseNormalinputEditTextBinding
            r4 = r11
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r5 = r2
            r3.<init>(r4, r5, r6, r7, r8, r9)
            r10.b = r1
            r2.setOnFocusChangeListener(r10)
            com.huawei.digitalpayment.customer.baselib.databinding.BaseNormalinputEditTextBinding r11 = r10.b
            android.widget.EditText r11 = r11.b
            t4.g r1 = new t4.g
            r1.<init>(r10)
            r11.addTextChangedListener(r1)
            r10.c(r0)
            return
        L_0x0085:
            android.content.res.Resources r11 = r11.getResources()
            java.lang.String r11 = r11.getResourceName(r1)
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Missing required view with ID: "
            java.lang.String r11 = r1.concat(r11)
            r0.<init>(r11)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.viewlib.view.NormalEditText.a(android.util.AttributeSet):void");
    }

    public final boolean b() {
        return Pattern.matches(this.c, getText());
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.digitalpayment.customer.viewlib.view.NormalEditText, android.view.View] */
    public final void c(boolean z) {
        a baseFilletView = this.b.d.getBaseFilletView();
        if (!TextUtils.isEmpty(this.b.f.getText().toString())) {
            baseFilletView.e(getResources().getColor(R$color.colorError));
        } else if (!z) {
            baseFilletView.e(getResources().getColor(R$color.color_F4F4F4));
        } else {
            baseFilletView.e(getResources().getColor(R$color.color_F4F4F4));
        }
    }

    public String getErrorTips() {
        return this.g;
    }

    public String getText() {
        return this.b.b.getText().toString().trim();
    }

    public final void onFocusChange(View view, boolean z) {
        c(z);
    }

    public void setAreaCode(String str) {
        this.b.e.setText(str);
        if (p.b(str)) {
            this.b.e.setVisibility(8);
        } else {
            this.b.e.setVisibility(0);
        }
    }

    public void setError(String str) {
        this.b.f.setText(str);
        if (TextUtils.isEmpty(str)) {
            this.b.c.setVisibility(8);
            this.b.f.setVisibility(8);
        } else {
            this.b.c.setVisibility(0);
            this.b.f.setVisibility(0);
        }
        c(this.b.b.hasFocus());
    }

    public void setErrorTips(String str) {
        this.g = str;
    }

    public void setNeedRegEx(boolean z) {
        this.e = z;
    }

    public void setRegEx(String str) {
        if (TextUtils.isEmpty(str)) {
            this.c = this.d;
        } else {
            this.c = str;
        }
    }

    public void setText(String str) {
        this.b.b.setText(str);
    }

    public NormalEditText(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = context;
        a(attributeSet);
    }

    public NormalEditText(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = context;
        a(attributeSet);
    }
}
