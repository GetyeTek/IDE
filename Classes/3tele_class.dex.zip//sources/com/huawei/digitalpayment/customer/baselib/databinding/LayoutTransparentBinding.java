package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.digitalpayment.customer.baselib.R$layout;

public final class LayoutTransparentBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;

    public LayoutTransparentBinding(@NonNull ConstraintLayout constraintLayout) {
        this.a = constraintLayout;
    }

    @NonNull
    public static LayoutTransparentBinding a(@NonNull LayoutInflater layoutInflater) {
        ConstraintLayout inflate = layoutInflater.inflate(R$layout.layout_transparent, (ViewGroup) null, false);
        if (inflate != null) {
            return new LayoutTransparentBinding(inflate);
        }
        throw new NullPointerException("rootView");
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
