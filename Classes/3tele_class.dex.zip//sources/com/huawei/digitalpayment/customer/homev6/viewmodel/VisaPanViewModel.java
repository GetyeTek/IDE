package com.huawei.digitalpayment.customer.homev6.viewmodel;

import S2.b;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.homev6.model.ApplyVisaPanResp;
import com.huawei.digitalpayment.customer.homev6.model.QueryVisaResp;

public class VisaPanViewModel extends ViewModel {
    public final MutableLiveData<b<ApplyVisaPanResp>> a = new MutableLiveData<>();
    public final MutableLiveData<b<QueryVisaResp>> b = new MutableLiveData<>();
}
