package com.huawei.digitalpayment.customer.viewlib.view.dialog;

import R9.h;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.R$style;
import java.util.List;

public class SelectDialog<T> extends BaseDialog {
    public final String c;
    public final List<T> d;
    public final b<T> e;
    public View f;

    public class a implements View.OnClickListener {
        public final /* synthetic */ BaseViewHolder a;
        public final /* synthetic */ Object b;

        public a(BaseViewHolder baseViewHolder, Object obj) {
            this.a = baseViewHolder;
            this.b = obj;
        }

        public final void onClick(View view) {
            SelectDialog selectDialog = SelectDialog.this;
            View view2 = selectDialog.f;
            if (view2 != null) {
                view2.setVisibility(8);
            }
            int i = R$id.iv_selected;
            BaseViewHolder baseViewHolder = this.a;
            baseViewHolder.setVisible(i, true);
            b<T> bVar = selectDialog.e;
            if (bVar != null) {
                baseViewHolder.getAdapterPosition();
                bVar.a(this.b);
            }
        }
    }

    public interface b<T> {
        void a(Object obj);
    }

    public class c extends BaseQuickAdapter<T, BaseViewHolder> {
        public c(@LayoutRes int i, @Nullable List<T> list) {
            super(i, list);
        }

        public final void convert(@NonNull BaseViewHolder baseViewHolder, T t) {
            SelectDialog.this.x0(baseViewHolder, t);
        }
    }

    public SelectDialog(String str, List<T> list, b<T> bVar) {
        this.c = str;
        this.d = list;
        this.e = bVar;
    }

    public final void onStart() {
        Window window;
        SelectDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            H1.c.b(window, R$style.BottomAnimation, dialog, true, true);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        SelectDialog.super.onViewCreated(view, bundle);
        RecyclerView findViewById = view.findViewById(R$id.rv_list);
        Context context = view.getContext();
        RecycleViewDivider recycleViewDivider = new RecycleViewDivider(-1, h.a(context, 1.0f));
        recycleViewDivider.c = h.a(context, 16.0f);
        findViewById.addItemDecoration(recycleViewDivider);
        findViewById.setLayoutManager(new LinearLayoutManager(view.getContext()));
        findViewById.setAdapter(new c(y0(), this.d));
        ((TextView) view.findViewById(R$id.tv_title)).setText(this.c);
    }

    public final int v0() {
        return R$layout.dialog_select;
    }

    public void x0(@NonNull BaseViewHolder baseViewHolder, T t) {
        boolean z0 = z0(t);
        int i = R$id.iv_selected;
        baseViewHolder.setGone(i, !z0);
        if (z0) {
            this.f = baseViewHolder.getView(i);
        }
        baseViewHolder.itemView.setOnClickListener(new a(baseViewHolder, t));
    }

    public int y0() {
        return R$layout.item_select_dialog;
    }

    public boolean z0(T t) {
        return false;
    }
}
