package com.huawei.digitalpayment.customer.baselib.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputKeyboard;
import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputView;

public final class LayoutInputPinBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final PinInputKeyboard c;
    @NonNull
    public final PinInputView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public LayoutInputPinBinding(@NonNull ConstraintLayout constraintLayout, @NonNull ImageView imageView, @NonNull PinInputKeyboard pinInputKeyboard, @NonNull PinInputView pinInputView, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = imageView;
        this.c = pinInputKeyboard;
        this.d = pinInputView;
        this.e = textView;
        this.f = textView2;
    }

    @NonNull
    public static LayoutInputPinBinding a(@NonNull LayoutInflater layoutInflater) {
        ConstraintLayout inflate = layoutInflater.inflate(R$layout.layout_input_pin, (ViewGroup) null, false);
        int i = R$id.iv_back;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i);
        if (imageView != null) {
            i = R$id.pin_input_keyboard;
            PinInputKeyboard pinInputKeyboard = (PinInputKeyboard) ViewBindings.findChildViewById(inflate, i);
            if (pinInputKeyboard != null) {
                i = R$id.pin_input_view;
                PinInputView pinInputView = (PinInputView) ViewBindings.findChildViewById(inflate, i);
                if (pinInputView != null) {
                    i = R$id.tv_enter_pin;
                    if (((TextView) ViewBindings.findChildViewById(inflate, i)) != null) {
                        i = R$id.tv_error;
                        TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
                        if (textView != null) {
                            i = R$id.tv_forget_pin;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(inflate, i);
                            if (textView2 != null) {
                                return new LayoutInputPinBinding(inflate, imageView, pinInputKeyboard, pinInputView, textView, textView2);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
