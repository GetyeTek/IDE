package com.huawei.digitalpayment.customer.baselib.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.customer.baselib.R$id;

public class BaseActivityAbstractPinBindingImpl extends BaseActivityAbstractPinBinding {
    @Nullable
    public static final SparseIntArray g;
    public long f;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.pin_input_keyboard, 1);
        sparseIntArray.put(R$id.iv_back, 2);
        sparseIntArray.put(R$id.tv_enter_pin, 3);
        sparseIntArray.put(R$id.pin_input_view, 4);
        sparseIntArray.put(R$id.tv_forget_pin, 5);
        sparseIntArray.put(R$id.tv_error, 6);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.f = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.f != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.f = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
