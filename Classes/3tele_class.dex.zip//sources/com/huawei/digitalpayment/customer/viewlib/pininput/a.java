package com.huawei.digitalpayment.customer.viewlib.pininput;

import com.huawei.digitalpayment.customer.viewlib.pininput.PinInputKeyboard;

public final class a implements PinInputKeyboard.a {
    public final /* synthetic */ AbstractPinActivity a;

    public a(AbstractPinActivity abstractPinActivity) {
        this.a = abstractPinActivity;
    }

    public final void a(char c) {
        int i = AbstractPinActivity.d;
        AbstractPinActivity abstractPinActivity = this.a;
        abstractPinActivity.b.c.a(c);
        abstractPinActivity.b.d.setText("");
    }

    public final void onDelete() {
        int i = AbstractPinActivity.d;
        this.a.b.c.d();
    }
}
