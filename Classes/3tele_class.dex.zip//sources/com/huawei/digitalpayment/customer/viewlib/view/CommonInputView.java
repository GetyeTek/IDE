package com.huawei.digitalpayment.customer.viewlib.view;

import R9.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.digitalpayment.customer.baselib.R$color;
import com.huawei.digitalpayment.customer.baselib.R$id;
import com.huawei.digitalpayment.customer.baselib.R$layout;
import com.huawei.digitalpayment.customer.baselib.R$styleable;
import d2.a;

public class CommonInputView extends ConstraintLayout implements View.OnFocusChangeListener {
    public RoundConstraintLayout a;
    public TextView b;
    public EditText c;
    public TextView d;
    public ImageView e;
    public int f;
    public int g;
    public int h;

    public CommonInputView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        a(context, attributeSet);
    }

    /* JADX WARNING: type inference failed for: r12v0, types: [android.view.View$OnFocusChangeListener, android.view.View, com.huawei.digitalpayment.customer.viewlib.view.CommonInputView, android.view.ViewGroup] */
    public final void a(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        View.inflate(context, R$layout.pin_input_view, this);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.CommonInputView);
        String string = obtainStyledAttributes.getString(R$styleable.CommonInputView_input_area_code);
        Drawable drawable = obtainStyledAttributes.getDrawable(R$styleable.CommonInputView_input_icon);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(R$styleable.CommonInputView_input_padding_left, 0);
        int dimensionPixelOffset2 = obtainStyledAttributes.getDimensionPixelOffset(R$styleable.CommonInputView_input_area_code_margin, 0);
        int dimensionPixelOffset3 = obtainStyledAttributes.getDimensionPixelOffset(R$styleable.CommonInputView_input_padding_right, 0);
        int dimensionPixelOffset4 = obtainStyledAttributes.getDimensionPixelOffset(R$styleable.CommonInputView_input_corner, 0);
        int dimensionPixelOffset5 = obtainStyledAttributes.getDimensionPixelOffset(R$styleable.CommonInputView_input_height, h.a(context, 44.0f));
        int i = obtainStyledAttributes.getInt(R$styleable.CommonInputView_input_length, Integer.MAX_VALUE);
        this.f = obtainStyledAttributes.getColor(R$styleable.CommonInputView_input_error_color, getResources().getColor(R$color.colorError));
        this.g = obtainStyledAttributes.getColor(R$styleable.CommonInputView_input_focus_color, getResources().getColor(R$color.colorPrimary));
        this.h = obtainStyledAttributes.getColor(R$styleable.CommonInputView_input_un_focus_color, 0);
        int color = obtainStyledAttributes.getColor(R$styleable.CommonInputView_input_background_color, -1);
        obtainStyledAttributes.recycle();
        RoundConstraintLayout findViewById = findViewById(R$id.cl_input);
        this.a = findViewById;
        findViewById.getBaseFilletView().f(h.a(context, 2.0f));
        this.b = (TextView) findViewById(R$id.tv_area_code);
        this.c = (EditText) findViewById(R$id.et_input);
        this.e = (ImageView) findViewById(R$id.iv_icon);
        this.d = (TextView) findViewById(R$id.tv_error);
        this.c.setOnFocusChangeListener(this);
        this.a.getLayoutParams().height = dimensionPixelOffset5;
        RoundConstraintLayout roundConstraintLayout = this.a;
        roundConstraintLayout.setPadding(dimensionPixelOffset, roundConstraintLayout.getPaddingTop(), dimensionPixelOffset3, this.a.getPaddingBottom());
        this.a.getBaseFilletView().d(dimensionPixelOffset4);
        this.a.setBackgroundColor(color);
        this.e.setImageDrawable(drawable);
        this.c.setFilters(new InputFilter[]{new InputFilter.LengthFilter(i)});
        TextView textView = this.b;
        textView.setPadding(textView.getPaddingLeft(), this.b.getPaddingTop(), dimensionPixelOffset2, this.b.getPaddingBottom());
        TextView textView2 = this.d;
        textView2.setPadding(dimensionPixelOffset, textView2.getPaddingTop(), dimensionPixelOffset3, this.d.getPaddingBottom());
        setError("");
        setAreaCode(string);
        b();
    }

    public final void b() {
        String charSequence = this.d.getText().toString();
        a baseFilletView = this.a.getBaseFilletView();
        if (!TextUtils.isEmpty(charSequence)) {
            baseFilletView.e(this.f);
        } else if (this.c.hasFocus()) {
            baseFilletView.e(this.g);
        } else {
            baseFilletView.e(this.h);
        }
    }

    public String getCompleteText() {
        String obj = this.c.getText().toString();
        if (obj.length() > 9) {
            return this.b.getText().toString() + obj.substring(obj.length() - 9);
        }
        return this.b.getText().toString() + obj;
    }

    public EditText getEditText() {
        return this.c;
    }

    public ImageView getIvIcon() {
        return this.e;
    }

    public String getText() {
        return this.c.getText().toString();
    }

    public TextView getTvError() {
        return this.d;
    }

    public final void onFocusChange(View view, boolean z) {
        b();
    }

    public void setAreaCode(String str) {
        this.b.setText(str);
        if (TextUtils.isEmpty(str)) {
            this.b.setVisibility(8);
        } else {
            this.b.setVisibility(0);
        }
    }

    public void setError(String str) {
        this.d.setText(str);
        if (TextUtils.isEmpty(str)) {
            this.d.setVisibility(8);
        } else {
            this.d.setVisibility(0);
        }
        b();
    }

    public void setOnIconListener(View.OnClickListener onClickListener) {
        this.e.setOnClickListener(onClickListener);
    }

    public CommonInputView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a(context, attributeSet);
    }
}
