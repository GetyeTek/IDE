package com.huawei.digitalpayment.customer.homev6.pop;

import V1.h;
import V1.k;
import W2.a;
import W2.r;
import Yb.c;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import com.blankj.utilcode.util.C;
import com.huawei.digitalpayment.customer.homev6.R$id;
import com.huawei.digitalpayment.customer.homev6.R$string;
import com.huawei.digitalpayment.customer.homev6.databinding.TransactionFilterDateBinding;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public final class b extends PopupWindow implements View.OnClickListener {
    public View a;
    public TransactionFilterDateBinding b;
    public FragmentActivity c;
    public RecordFilterEvent d;
    public FragmentManager e;
    public int f;
    public Calendar g;
    public Calendar h;

    public final void a() {
        TransactionFilterDateBinding transactionFilterDateBinding = this.b;
        TextView textView = transactionFilterDateBinding.c;
        RecordFilterEvent recordFilterEvent = this.d;
        textView.setText(C.a("yyyy-MM-dd", recordFilterEvent.getFromCalendar().getTime()));
        transactionFilterDateBinding.b.setText(C.a("yyyy-MM-dd", recordFilterEvent.getEndCalendar().getTime()));
    }

    public final void dismiss() {
        super.dismiss();
        View view = this.a;
        if (view != null && view.getParent() != null) {
            ((ViewGroup) this.a.getParent()).removeView(this.a);
        }
    }

    public final void onClick(View view) {
        int i = this.f;
        int id = view.getId();
        if (id == R$id.ll_content) {
            dismiss();
            return;
        }
        int i2 = R$id.btn_ok;
        RecordFilterEvent recordFilterEvent = this.d;
        if (id == i2) {
            if (!a.a(1500, view)) {
                String a2 = C.a("yyyy-MM-dd", recordFilterEvent.getFromCalendar().getTime());
                Boolean bool = Boolean.TRUE;
                String f2 = L3.a.f(a2, bool);
                String f5 = L3.a.f(C.a("yyyy-MM-dd", recordFilterEvent.getEndCalendar().getTime()), bool);
                if (r.b(f2).longValue() > r.b(f5).longValue()) {
                    k.a(R$string.history_the_start_time_must_be_less_than_the_end_time);
                    return;
                }
                String a3 = C.a("yyyy-MM-dd HH:mm", recordFilterEvent.getFromCalendar().getTime());
                String a5 = C.a("yyyy-MM-dd HH:mm", recordFilterEvent.getEndCalendar().getTime());
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                try {
                    Date parse = simpleDateFormat.parse(a3);
                    Date parse2 = simpleDateFormat.parse(a5);
                    Calendar instance = Calendar.getInstance();
                    instance.setTime(parse2);
                    instance.add(5, i * -1);
                    if (parse.getTime() < instance.getTimeInMillis()) {
                        k.b(1, this.c.getString(R$string.query_time_rang_cannot_excees_30_days, new Object[]{Integer.valueOf(i)}));
                        return;
                    }
                    c.b().e(recordFilterEvent);
                    dismiss();
                } catch (ParseException e2) {
                    e2.getMessage();
                    h.b();
                }
            }
        } else if (id == R$id.btnReset) {
            recordFilterEvent.setFromCalendar(this.g);
            recordFilterEvent.setEndCalendar(this.h);
            a();
        }
    }
}
