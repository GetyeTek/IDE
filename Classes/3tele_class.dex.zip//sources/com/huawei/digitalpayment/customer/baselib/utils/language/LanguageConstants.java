package com.huawei.digitalpayment.customer.baselib.utils.language;

public class LanguageConstants {
    public static final String AM = "am";
    public static final String CN = "zh_CN";
    public static final String EN = "en";
    public static final String ENGLISH = "English";
    public static final String LANGUAGE = "LANGUAGE";
    public static final String LANGUAGE_CODE = "LANGUAGE_CODE";
    public static final String OM = "om";
    public static final String SO = "so";
    public static final String TI = "ti";
}
