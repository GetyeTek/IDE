package com.huawei.digitalpayment.customer.homev6.model;

import H9.a;
import L2.c;
import V1.h;
import android.text.TextUtils;
import com.huawei.common.widget.banner.CycleViewPager;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class HomeFunction implements Serializable, a, CycleViewPager.b {
    private List<HomeFunction> childMenus;
    private String content;
    private String delayTime;
    private String execute;
    private String funcId;
    private String funcName;
    private String icon;
    private String iconSelected;
    private String imageUrl;
    private String imgUrl;
    private String marker;
    private String order;
    private Map<String, String> params;
    private String reportTag;
    private String startTime;
    private String startTimeUTC;
    private String stopTime;
    private String stopTimeUTC;

    public void fillEmptyWithOther(HomeFunction homeFunction) {
        for (Field field : getClass().getDeclaredFields()) {
            if (field.getType().equals(String.class)) {
                try {
                    if (TextUtils.isEmpty((String) field.get(this))) {
                        field.set(this, (String) field.get(homeFunction));
                    }
                } catch (Exception e) {
                    e.toString();
                    h.b();
                }
            }
        }
    }

    public List<HomeFunction> getChildMenus() {
        return this.childMenus;
    }

    public String getContent() {
        return this.content;
    }

    public String getDelayTime() {
        if (TextUtils.isEmpty(this.delayTime)) {
            return "4";
        }
        return this.delayTime;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getFuncId() {
        return this.funcId;
    }

    public String getFuncName() {
        return this.funcName;
    }

    public String getIcon() {
        c.a.getClass();
        return a.b(this.icon);
    }

    public String getIconSelected() {
        c.a.getClass();
        return a.b(this.iconSelected);
    }

    public String getImageUrl() {
        if (TextUtils.isEmpty(this.imageUrl)) {
            return this.imgUrl;
        }
        return this.imageUrl;
    }

    public String getImgUrl() {
        return this.imgUrl;
    }

    public String getMarker() {
        c.a.getClass();
        return a.b(this.marker);
    }

    public String getOrder() {
        return this.order;
    }

    public Map<String, String> getParams() {
        return this.params;
    }

    public List<String> getReportParams() {
        if (TextUtils.isEmpty(this.reportTag)) {
            return new ArrayList();
        }
        return Arrays.asList(this.reportTag.split("&"));
    }

    public String getReportTag() {
        return this.reportTag;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public String getStartTimeUTC() {
        return this.startTimeUTC;
    }

    public String getStopTime() {
        return this.stopTime;
    }

    public String getStopTimeUTC() {
        return this.stopTimeUTC;
    }

    public void setChildMenus(List<HomeFunction> list) {
        this.childMenus = list;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public void setDelayTime(String str) {
        this.delayTime = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setFuncId(String str) {
        this.funcId = str;
    }

    public void setFuncName(String str) {
        this.funcName = str;
    }

    public void setIcon(String str) {
        this.icon = str;
    }

    public void setIconSelected(String str) {
        this.iconSelected = str;
    }

    public void setImageUrl(String str) {
        this.imageUrl = str;
    }

    public void setImgUrl(String str) {
        this.imgUrl = str;
    }

    public void setMarker(String str) {
        this.marker = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setParams(Map<String, String> map) {
        this.params = map;
    }

    public void setReportTag(String str) {
        this.reportTag = str;
    }

    public void setStartTime(String str) {
        this.startTime = str;
    }

    public void setStartTimeUTC(String str) {
        this.startTimeUTC = str;
    }

    public void setStopTime(String str) {
        this.stopTime = str;
    }

    public void setStopTimeUTC(String str) {
        this.stopTimeUTC = str;
    }
}
