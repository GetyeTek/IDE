package com.huawei.digitalpayment.customer.viewlib.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatEditText;
import com.blankj.utilcode.util.v;
import com.huawei.digitalpayment.customer.baselib.R$mipmap;
import com.huawei.digitalpayment.customer.httplib.response.VerifySecurityQuestionResp;
import java.util.regex.Pattern;

public class InputItemEditText extends AppCompatEditText implements TextWatcher {
    public static final /* synthetic */ int i = 0;
    public String a = "(Birr)";
    public int b = 0;
    public int c = 0;
    public int d = 0;
    public boolean e;
    public Paint f;
    public boolean g;
    public int h;

    public static class a implements InputFilter {
        public static final Pattern a = Pattern.compile("([0-9]|\\.)*");

        /* JADX WARNING: Code restructure failed: missing block: B:25:0x004d, code lost:
            if ((r7.length() - r0) <= 2) goto L_0x0079;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:39:0x0076, code lost:
            if (r0.equals(r7) != false) goto L_0x004f;
         */
        /* JADX WARNING: Removed duplicated region for block: B:43:0x0081 A[RETURN] */
        /* JADX WARNING: Removed duplicated region for block: B:44:0x0082 A[SYNTHETIC, Splitter:B:44:0x0082] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.CharSequence filter(java.lang.CharSequence r5, int r6, int r7, android.text.Spanned r8, int r9, int r10) {
            /*
                r4 = this;
                java.lang.String r6 = ""
                if (r5 == 0) goto L_0x0009
                java.lang.String r5 = r5.toString()
                goto L_0x000a
            L_0x0009:
                r5 = r6
            L_0x000a:
                if (r8 == 0) goto L_0x0011
                java.lang.String r7 = r8.toString()
                goto L_0x0012
            L_0x0011:
                r7 = r6
            L_0x0012:
                boolean r0 = r5.isEmpty()
                if (r0 == 0) goto L_0x0019
                return r6
            L_0x0019:
                java.lang.String r0 = "0"
                java.lang.String r1 = "."
                if (r9 != 0) goto L_0x0026
                boolean r2 = r7.contains(r1)
                if (r2 == 0) goto L_0x0026
                return r0
            L_0x0026:
                java.util.regex.Pattern r2 = a
                java.util.regex.Matcher r2 = r2.matcher(r5)
                boolean r3 = r7.contains(r1)
                if (r3 == 0) goto L_0x0051
                boolean r0 = r5.contains(r1)
                if (r0 != 0) goto L_0x004f
                boolean r0 = r2.matches()
                if (r0 != 0) goto L_0x003f
                goto L_0x004f
            L_0x003f:
                int r0 = r7.indexOf(r1)
                if (r0 < 0) goto L_0x0079
                if (r9 <= r0) goto L_0x0079
                int r1 = r7.length()
                int r1 = r1 - r0
                r0 = 2
                if (r1 <= r0) goto L_0x0079
            L_0x004f:
                r0 = r6
                goto L_0x007b
            L_0x0051:
                boolean r2 = r2.matches()
                if (r2 != 0) goto L_0x0058
                goto L_0x004f
            L_0x0058:
                boolean r1 = r5.contains(r1)
                if (r1 == 0) goto L_0x0063
                if (r9 != 0) goto L_0x0063
                java.lang.String r0 = "0."
                goto L_0x007b
            L_0x0063:
                boolean r1 = r5.contains(r0)
                if (r1 == 0) goto L_0x006c
                if (r9 != 0) goto L_0x006c
                goto L_0x007b
            L_0x006c:
                boolean r1 = r5.contains(r0)
                if (r1 == 0) goto L_0x0079
                boolean r0 = r0.equals(r7)
                if (r0 == 0) goto L_0x0079
                goto L_0x004f
            L_0x0079:
                java.lang.String r0 = "no"
            L_0x007b:
                boolean r0 = r0.equals(r6)
                if (r0 == 0) goto L_0x0082
                return r6
            L_0x0082:
                java.lang.String r6 = r7.concat(r5)     // Catch:{ NumberFormatException -> 0x008b }
                double r6 = java.lang.Double.parseDouble(r6)     // Catch:{ NumberFormatException -> 0x008b }
                goto L_0x0096
            L_0x008b:
                r6 = move-exception
                int r7 = com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText.i
                r6.toString()
                V1.h.b()
                r6 = 0
            L_0x0096:
                r0 = 4741671816366307410(0x41cdcd64fffeb852, double:9.9999999999E8)
                int r2 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1))
                if (r2 <= 0) goto L_0x00a4
                java.lang.CharSequence r5 = r8.subSequence(r9, r10)
                return r5
            L_0x00a4:
                java.lang.StringBuilder r6 = new java.lang.StringBuilder
                r6.<init>()
                java.lang.CharSequence r7 = r8.subSequence(r9, r10)
                r6.append(r7)
                r6.append(r5)
                java.lang.String r5 = r6.toString()
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText.a.filter(java.lang.CharSequence, int, int, android.text.Spanned, int, int):java.lang.CharSequence");
        }
    }

    static {
        Pattern.compile("^(([1-9][0-9]{0,14})|([0]{1})|(([0]\\.\\d{1,2}|[1-9][0-9]{0,14}\\.\\d{1,2})))$");
    }

    public InputItemEditText(Context context) {
        super(context);
        a(context, (AttributeSet) null);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v4, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(android.content.Context r6, android.util.AttributeSet r7) {
        /*
            r5 = this;
            r0 = 0
            r1 = 1
            android.graphics.Paint r2 = new android.graphics.Paint
            r3 = 3
            r2.<init>(r3)
            r5.f = r2
            android.content.res.Resources r3 = r6.getResources()
            android.util.DisplayMetrics r3 = r3.getDisplayMetrics()
            r4 = 1094713344(0x41400000, float:12.0)
            float r3 = android.util.TypedValue.applyDimension(r1, r4, r3)
            int r3 = (int) r3
            float r3 = (float) r3
            r2.setTextSize(r3)
            android.graphics.Paint r2 = r5.f
            android.graphics.Paint$Align r3 = android.graphics.Paint.Align.CENTER
            r2.setTextAlign(r3)
            if (r7 == 0) goto L_0x0049
            int[] r2 = com.huawei.digitalpayment.customer.baselib.R$styleable.InputItemEditText
            android.content.res.TypedArray r7 = r6.obtainStyledAttributes(r7, r2)
            int r2 = com.huawei.digitalpayment.customer.baselib.R$styleable.InputItemEditText_isShowCurrency
            boolean r2 = r7.getBoolean(r2, r0)
            r5.e = r2
            int r2 = com.huawei.digitalpayment.customer.baselib.R$styleable.InputItemEditText_isSelect
            boolean r2 = r7.getBoolean(r2, r0)
            r5.g = r2
            int r2 = com.huawei.digitalpayment.customer.baselib.R$styleable.InputItemEditText_currencyColor
            r3 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            int r2 = r7.getColor(r2, r3)
            r5.h = r2
            r7.recycle()
        L_0x0049:
            int r7 = r5.b
            r2 = 1098907648(0x41800000, float:16.0)
            if (r7 != 0) goto L_0x005e
            android.content.res.Resources r7 = r6.getResources()
            android.util.DisplayMetrics r7 = r7.getDisplayMetrics()
            float r7 = android.util.TypedValue.applyDimension(r1, r2, r7)
            int r7 = (int) r7
            r5.b = r7
        L_0x005e:
            int r7 = r5.c
            if (r7 != 0) goto L_0x0071
            android.content.res.Resources r6 = r6.getResources()
            android.util.DisplayMetrics r6 = r6.getDisplayMetrics()
            float r6 = android.util.TypedValue.applyDimension(r1, r2, r6)
            int r6 = (int) r6
            r5.c = r6
        L_0x0071:
            android.graphics.Paint r6 = r5.f
            java.lang.String r7 = r5.a
            float r6 = r6.measureText(r7)
            int r6 = (int) r6
            r5.d = r6
            boolean r6 = r5.e
            if (r6 == 0) goto L_0x0094
            r5.addTextChangedListener(r5)
            r6 = 8194(0x2002, float:1.1482E-41)
            r5.setInputType(r6)
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText$a r6 = new com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText$a
            r6.<init>()
            android.text.InputFilter[] r7 = new android.text.InputFilter[r1]
            r7[r0] = r6
            r5.setFilters(r7)
        L_0x0094:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText.a(android.content.Context, android.util.AttributeSet):void");
    }

    public final void afterTextChanged(Editable editable) {
        if (editable.toString().length() == 2 && editable.toString().startsWith(VerifySecurityQuestionResp.CODE_SUCCESS) && !editable.toString().equals("0.")) {
            editable.delete(0, 1);
        }
    }

    public final void beforeTextChanged(CharSequence charSequence, int i2, int i5, int i6) {
    }

    public String getCurrency() {
        return this.a;
    }

    /* JADX WARNING: type inference failed for: r11v0, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.view.View, android.widget.EditText] */
    public final void onDraw(Canvas canvas) {
        InputItemEditText.super.onDraw(canvas);
        this.d = (int) this.f.measureText(this.a);
        if (this.e) {
            int scrollX = (getScrollX() + getWidth()) - this.b;
            int scrollX2 = ((getScrollX() + getWidth()) - this.b) - this.d;
            int height = getHeight();
            int i2 = this.c;
            int i5 = (height - i2) / 2;
            Rect rect = new Rect(scrollX2, i5, scrollX, i2 + i5);
            Paint.FontMetrics fontMetrics = this.f.getFontMetrics();
            float f2 = fontMetrics.bottom;
            float centerY = ((float) rect.centerY()) + (((f2 - fontMetrics.top) / 2.0f) - f2);
            this.f.setColor(this.h);
            canvas.drawText(this.a, (float) rect.centerX(), centerY, this.f);
            int scrollX3 = (((getScrollX() + getWidth()) - this.b) - this.d) - v.a(10.0f);
            int height2 = ((getHeight() - this.c) / 2) - v.a(5.0f);
            int a2 = v.a(10.0f) + this.c + height2;
            this.f.setStrokeWidth(0.5f);
            this.f.setColor(Color.parseColor("#DBDBDB"));
            float f5 = (float) scrollX3;
            canvas.drawLine(f5, (float) height2, f5, (float) a2, this.f);
        } else if (this.g) {
            int scrollX4 = (getScrollX() + getWidth()) - this.b;
            int scrollX5 = ((getScrollX() + getWidth()) - this.b) - this.d;
            int height3 = getHeight();
            int i6 = this.c;
            int i7 = (height3 - i6) / 2;
            Rect rect2 = new Rect(scrollX5, i7, scrollX4, i6 + i7);
            Context context = getContext();
            Bitmap decodeResource = BitmapFactory.decodeResource(context.getResources(), R$mipmap.bankaccount_icon_arrow_right);
            canvas.drawBitmap(decodeResource, (float) rect2.centerX(), (float) (rect2.centerY() - (decodeResource.getHeight() / 2)), this.f);
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.widget.EditText] */
    public final void onMeasure(int i2, int i5) {
        InputItemEditText.super.onMeasure(i2, i5);
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i5, int i6) {
    }

    public void setCurrency(String str) {
        this.a = str;
    }

    public InputItemEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a(context, attributeSet);
    }

    public InputItemEditText(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        a(context, attributeSet);
    }
}
