package com.huawei.digitalpayment.customer.homev6.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import java.util.List;

public class HomeFavoriteViewModel extends ViewModel {
    public final MutableLiveData<c<List<HomeFunction>>> a = new MutableLiveData<>();
    public final MutableLiveData<c<List<HomeFunction>>> b = new MutableLiveData<>();
    public final MutableLiveData<c<List<HomeFunction>>> c = new MutableLiveData<>();
}
