package com.huawei.digitalpayment.customer.homev6.model;

import android.text.TextUtils;
import java.io.Serializable;

public class UserBean implements Serializable {
    private String avatar;
    private String customerLevel;
    private String execute;
    private String identityId;
    private String msisdn;
    private String nickName;
    private String photoProfile;

    public String getAvatar() {
        return this.avatar;
    }

    public String getCustomerLevel() {
        return this.customerLevel;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getIdentityId() {
        return this.identityId;
    }

    public String getMsisdn() {
        return this.msisdn;
    }

    public String getNickName() {
        if (TextUtils.isEmpty(this.nickName)) {
            return "";
        }
        return this.nickName;
    }

    public String getPhotoProfile() {
        return this.photoProfile;
    }

    public void setAvatar(String str) {
        this.avatar = str;
    }

    public void setCustomerLevel(String str) {
        this.customerLevel = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setIdentityId(String str) {
        this.identityId = str;
    }

    public void setMsisdn(String str) {
        this.msisdn = str;
    }

    public void setNickName(String str) {
        this.nickName = str;
    }

    public void setPhotoProfile(String str) {
        this.photoProfile = str;
    }
}
