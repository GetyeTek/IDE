package com.huawei.digitalpayment.paybill.activity;

import R1.a;
import android.text.TextUtils;
import androidx.fragment.app.FragmentActivity;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import i7.a;
import java.util.HashMap;

public final class c implements a {
    public Object a;
    public Object b;

    public /* synthetic */ void onComplete() {
    }

    public /* synthetic */ void onError(BaseException baseException) {
    }

    public /* synthetic */ void onLoading(Object obj) {
    }

    public void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        int i = BillDetailsActivity.i;
        FragmentActivity fragmentActivity = (BillDetailsActivity) this.b;
        HashMap a2 = com.google.android.gms.ads.identifier.a.a("tradeType", "QrCode");
        a2.put("amount", (String) this.a);
        a2.put("note", "");
        if (!TextUtils.isEmpty(fragmentActivity.f)) {
            a2.put("msisdn", fragmentActivity.f);
        } else if (!TextUtils.isEmpty(fragmentActivity.g)) {
            a2.put("accountCode", fragmentActivity.g);
        }
        a.a.a.c(fragmentActivity, fragmentActivity.getString(R$string.pay), PaySceneEnum.PAY_ET_BILL, a2, new d(fragmentActivity));
    }
}
