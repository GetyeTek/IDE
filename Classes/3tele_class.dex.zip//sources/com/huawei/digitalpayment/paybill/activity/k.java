package com.huawei.digitalpayment.paybill.activity;

import O2.a;
import android.text.Editable;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import com.huawei.customer.digitalpayment.miniapp.macle.ui.activity.MacleMiniAppSearchActivity;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.ArrayList;
import x2.c;

public final class k extends a {
    public final /* synthetic */ int b;
    public final /* synthetic */ DataBindingActivity c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ k(DataBindingActivity dataBindingActivity, int i) {
        super(1);
        this.b = i;
        this.c = dataBindingActivity;
    }

    public final void afterTextChanged(Editable editable) {
        MacleMiniAppSearchActivity macleMiniAppSearchActivity = this.c;
        switch (this.b) {
            case 0:
                PayBillActivity payBillActivity = (PayBillActivity) macleMiniAppSearchActivity;
                if (!TextUtils.isEmpty(editable.toString())) {
                    int i = PayBillActivity.n;
                    payBillActivity.b.d.getEditText().setText("");
                }
                int i2 = PayBillActivity.n;
                payBillActivity.G0();
                MutableLiveData<Boolean> mutableLiveData = payBillActivity.c.c;
                if (((Boolean) mutableLiveData.getValue()).booleanValue()) {
                    mutableLiveData.setValue(Boolean.FALSE);
                }
                payBillActivity.c.a.setValue(editable.toString());
                return;
            default:
                String trim = editable.toString().trim();
                int i5 = MacleMiniAppSearchActivity.g;
                MacleMiniAppSearchActivity macleMiniAppSearchActivity2 = macleMiniAppSearchActivity;
                if (TextUtils.isEmpty(trim)) {
                    macleMiniAppSearchActivity2.c.a.setValue(new ArrayList());
                    macleMiniAppSearchActivity2.c.a("SHOW_RECENTLY_KEYWORD");
                    c cVar = macleMiniAppSearchActivity2.f;
                    if (cVar != null) {
                        cVar.cancel();
                        return;
                    }
                    return;
                }
                macleMiniAppSearchActivity2.b.d.setVisibility(0);
                macleMiniAppSearchActivity2.c.a("SHOW_SEARCHING");
                c cVar2 = macleMiniAppSearchActivity2.f;
                if (cVar2 != null) {
                    cVar2.cancel();
                    macleMiniAppSearchActivity2.f.start();
                    return;
                }
                c cVar3 = new c(macleMiniAppSearchActivity2);
                macleMiniAppSearchActivity2.f = cVar3;
                cVar3.start();
                return;
        }
    }
}
