package com.huawei.digitalpayment.paybill.activity;

import R1.a;
import com.blankj.utilcode.util.A;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.db.PayBillDatabase;
import com.huawei.digitalpayment.paybill.resp.PayBillHistory;
import org.json.JSONObject;
import v4.f;
import v4.g;

public final class e implements a<JSONObject> {
    public final /* synthetic */ BillDetailsActivity a;

    public e(BillDetailsActivity billDetailsActivity) {
        this.a = billDetailsActivity;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        JSONObject jSONObject = (JSONObject) obj;
        PayBillHistory payBillHistory = new PayBillHistory();
        payBillHistory.setPhoneNumber(this.a.f);
        if (jSONObject != null) {
            payBillHistory.setName(jSONObject.optString("name"));
            payBillHistory.setAvatar(jSONObject.optString("avatar"));
        }
        PayBillDatabase payBillDatabase = g.a;
        A.c(new f(payBillHistory));
    }
}
