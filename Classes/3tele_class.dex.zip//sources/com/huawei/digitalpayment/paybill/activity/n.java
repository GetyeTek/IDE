package com.huawei.digitalpayment.paybill.activity;

import R1.a;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import com.huawei.payment.mvvm.DataBindingActivity;
import i7.a;
import java.util.HashMap;

public final class n implements a<Boolean> {
    public final /* synthetic */ HashMap a;
    public final /* synthetic */ PayBillActivity b;

    public n(PayBillActivity payBillActivity, HashMap hashMap) {
        this.b = payBillActivity;
        this.a = hashMap;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        int i = PayBillActivity.n;
        DataBindingActivity dataBindingActivity = this.b;
        String obj2 = dataBindingActivity.b.c.getText().toString();
        HashMap hashMap = this.a;
        hashMap.put("tradeType", "QrCode");
        hashMap.put("amount", obj2);
        a.a.a.c(dataBindingActivity, dataBindingActivity.getString(R$string.pay), PaySceneEnum.PAY_ET_DEPOSIT, hashMap, new o(dataBindingActivity));
    }
}
