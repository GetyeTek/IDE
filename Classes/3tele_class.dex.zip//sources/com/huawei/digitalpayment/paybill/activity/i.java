package com.huawei.digitalpayment.paybill.activity;

import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.MutableLiveData;
import com.blankj.utilcode.util.A;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.cubeim.client.api.HistoryMessagesCallback;
import com.huawei.cubeim.client.api.ReadonlyMessageList;
import com.huawei.customer.digitalpayment.miniapp.macle.bean.SearchKeyWord;
import com.huawei.customer.digitalpayment.miniapp.macle.db.MacleDatabase;
import com.huawei.customer.digitalpayment.miniapp.macle.ui.activity.MacleMiniAppSearchActivity;
import com.huawei.digitalpayment.customer.httplib.bean.TransRecordBean;
import com.huawei.digitalpayment.paybill.resp.PayBillHistory;
import com.huawei.kbz.chat.contact.EditNoteNameActivity;
import com.huawei.module_history.RecordActivity;
import com.huawei.payment.mvvm.DataBindingAdapter;
import i2.a;
import j2.F;
import kotlin.jvm.internal.h;
import m2.k;
import m2.l;
import n6.b;

public final /* synthetic */ class i implements DataBindingAdapter.a, b, OnItemClickListener, HistoryMessagesCallback {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ i(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public void c(View view, int i, Object obj) {
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                int i2 = PayBillActivity.n;
                PayBillActivity payBillActivity = (PayBillActivity) obj2;
                payBillActivity.b.e.getEditText().setText(((PayBillHistory) obj).getPhoneNumber());
                MutableLiveData<Boolean> mutableLiveData = payBillActivity.c.c;
                if (!((Boolean) mutableLiveData.getValue()).booleanValue()) {
                    mutableLiveData.setValue(Boolean.TRUE);
                    return;
                }
                return;
            default:
                int i5 = MacleMiniAppSearchActivity.g;
                MacleMiniAppSearchActivity macleMiniAppSearchActivity = (MacleMiniAppSearchActivity) obj2;
                String keyWord = ((SearchKeyWord) obj).getKeyWord();
                macleMiniAppSearchActivity.b.b.setText(keyWord);
                macleMiniAppSearchActivity.b.b.setSelection(keyWord.length());
                macleMiniAppSearchActivity.F0();
                InputMethodManager inputMethodManager = (InputMethodManager) macleMiniAppSearchActivity.getSystemService("input_method");
                if (inputMethodManager != null) {
                    inputMethodManager.hideSoftInputFromWindow(macleMiniAppSearchActivity.b.b.getWindowToken(), 2);
                }
                macleMiniAppSearchActivity.c.getClass();
                SearchKeyWord searchKeyWord = new SearchKeyWord(keyWord);
                MacleDatabase macleDatabase = l.a;
                A.c(new k(searchKeyWord));
                return;
        }
    }

    public void callback(Exception exc, ReadonlyMessageList readonlyMessageList) {
        g1.i iVar = (g1.i) this.b;
        h.f(iVar, "$callback");
        a.c(new F(exc, readonlyMessageList, iVar));
    }

    public void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        int i2 = RecordActivity.r;
        n.a.b().getClass();
        n.a.a("/historyModule/historyDetails").withString("orderId", ((TransRecordBean) ((RecordActivity) this.b).m.get(i)).getOrderId()).navigation();
    }

    public void onRightClick(String str) {
        int i = EditNoteNameActivity.f;
        ((EditNoteNameActivity) this.b).E0();
    }
}
