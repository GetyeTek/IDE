package com.huawei.digitalpayment.paybill.activity;

import V7.c;
import V7.f;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.E;
import com.blankj.utilcode.util.ToastUtils;
import com.blankj.utilcode.util.v;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.customer.digitalpayment.miniapp.macle.ui.activity.MacleMiniAppSearchActivity;
import com.huawei.customer.digitalpayment.miniapp.macle.ui.adapter.SearchResultAdapter;
import com.huawei.digitalpayment.customer.login_module.resetpin.AnswerOtherQuestionActivity;
import com.huawei.ethiopia.finance.saving.activity.SavingActivity;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.List;
import java.util.Map;
import o0.b;

public final /* synthetic */ class h implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ DataBindingActivity b;

    public /* synthetic */ h(DataBindingActivity dataBindingActivity, int i) {
        this.a = i;
        this.b = dataBindingActivity;
    }

    /* JADX WARNING: type inference failed for: r1v7, types: [java.lang.Object, com.huawei.common.widget.banner.CycleViewPager$c] */
    /* JADX WARNING: type inference failed for: r3v0, types: [java.lang.Object, com.chad.library.adapter.base.listener.OnItemClickListener] */
    public final void onChanged(Object obj) {
        List list;
        MacleMiniAppSearchActivity macleMiniAppSearchActivity = this.b;
        switch (this.a) {
            case 0:
                c cVar = (c) obj;
                int i = PayBillActivity.n;
                PayBillActivity payBillActivity = (PayBillActivity) macleMiniAppSearchActivity;
                if (cVar.f() && (list = (List) cVar.c) != null && !list.isEmpty()) {
                    payBillActivity.b.b.setVisibility(0);
                    payBillActivity.b.b.c(list, new Object(), 0);
                    return;
                }
                return;
            case 1:
                c cVar2 = (c) obj;
                int i2 = AnswerOtherQuestionActivity.p;
                FragmentActivity fragmentActivity = (AnswerOtherQuestionActivity) macleMiniAppSearchActivity;
                f.b(fragmentActivity, cVar2);
                if (cVar2.b()) {
                    f.c(cVar2);
                    return;
                } else if (cVar2.f()) {
                    ToastUtils toastUtils = ToastUtils.b;
                    String str = "resetPinSuccess";
                    if (str.length() == 0) {
                        str = "toast nothing";
                    }
                    A.g(new E(str));
                    b.d(fragmentActivity, "/mainModule/main", (Bundle) null, (Map) null);
                    fragmentActivity.finish();
                    return;
                } else {
                    return;
                }
            case 2:
                c cVar3 = (c) obj;
                int i5 = SavingActivity.g;
                SavingActivity savingActivity = (SavingActivity) macleMiniAppSearchActivity;
                f.b(savingActivity, cVar3);
                if (cVar3.b()) {
                    f.c(cVar3);
                    savingActivity.e.a(3);
                    return;
                } else if (cVar3.f()) {
                    savingActivity.d.submitList((List) cVar3.c);
                    if (savingActivity.d.getItemCount() == 0) {
                        savingActivity.e.a(4);
                        return;
                    } else {
                        savingActivity.e.a(2);
                        return;
                    }
                } else {
                    return;
                }
            default:
                List list2 = (List) obj;
                int i6 = MacleMiniAppSearchActivity.g;
                MacleMiniAppSearchActivity macleMiniAppSearchActivity2 = macleMiniAppSearchActivity;
                String trim = macleMiniAppSearchActivity2.b.b.getText().toString().trim();
                if (!list2.isEmpty()) {
                    if (macleMiniAppSearchActivity2.d == null) {
                        SearchResultAdapter searchResultAdapter = new SearchResultAdapter();
                        macleMiniAppSearchActivity2.d = searchResultAdapter;
                        searchResultAdapter.setOnItemClickListener(new Object());
                        RecycleViewDivider recycleViewDivider = new RecycleViewDivider(Color.parseColor("#E9E9E9"), v.a(0.67f));
                        recycleViewDivider.c = v.a(16.0f);
                        macleMiniAppSearchActivity2.b.f.addItemDecoration(recycleViewDivider);
                        macleMiniAppSearchActivity2.b.f.setLayoutManager(new LinearLayoutManager(macleMiniAppSearchActivity2));
                        macleMiniAppSearchActivity2.b.f.setAdapter(macleMiniAppSearchActivity2.d);
                    }
                    SearchResultAdapter searchResultAdapter2 = macleMiniAppSearchActivity2.d;
                    searchResultAdapter2.a = trim;
                    searchResultAdapter2.setNewData(list2);
                    macleMiniAppSearchActivity2.c.a("SHOW_MINI_APP_LIST");
                    return;
                } else if (TextUtils.isEmpty(trim)) {
                    macleMiniAppSearchActivity2.c.a("SHOW_RECENTLY_KEYWORD");
                    return;
                } else {
                    macleMiniAppSearchActivity2.c.a("SHOW_EMPTY");
                    return;
                }
        }
    }
}
