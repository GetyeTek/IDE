package com.huawei.digitalpayment.paybill.activity;

import B4.b;
import W2.h;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.A;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.digitalpayment.db.PayBillDatabase;
import com.huawei.digitalpayment.paybill.resp.PayBillHistory;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.payment.mvvm.DataBindingActivity;
import i7.a;
import java.util.HashMap;
import java.util.Map;
import v4.f;
import v4.g;

public final class d implements a.b<TransferResp> {
    public final /* synthetic */ BillDetailsActivity a;

    public d(BillDetailsActivity billDetailsActivity) {
        this.a = billDetailsActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    public final void onSuccess(Object obj) {
        TransferResp transferResp = (TransferResp) obj;
        DataBindingActivity dataBindingActivity = this.a;
        if (!TextUtils.isEmpty(dataBindingActivity.f)) {
            HashMap hashMap = b.a;
            String c = h.c(dataBindingActivity.f);
            if (hashMap == null || !hashMap.containsKey(c)) {
                PayBillHistory payBillHistory = new PayBillHistory();
                payBillHistory.setPhoneNumber(dataBindingActivity.f);
                PayBillDatabase payBillDatabase = g.a;
                A.c(new f(payBillHistory));
            } else {
                long longValue = ((Long) hashMap.get(c)).longValue();
                e eVar = new e(dataBindingActivity);
                if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(dataBindingActivity, "android.permission.READ_CONTACTS") != 0) {
                    eVar.onSuccess((Object) null);
                } else {
                    A.d(new Y2.b(dataBindingActivity, longValue, eVar));
                }
            }
        }
        Bundle bundle = new Bundle();
        bundle.putString("buttonText", dataBindingActivity.getString(R$string.baselib_finished));
        bundle.putSerializable("TransferResp", transferResp);
        o0.b.d((Activity) null, "/basicUiModule/commonSuccess", bundle, (Map) null);
        dataBindingActivity.finish();
    }
}
