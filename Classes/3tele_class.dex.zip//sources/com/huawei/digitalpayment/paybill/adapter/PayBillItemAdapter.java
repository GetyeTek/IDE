package com.huawei.digitalpayment.paybill.adapter;

import android.widget.TextView;
import androidx.databinding.ViewDataBinding;
import com.huawei.digitalpayment.paybill.resp.PayBillResp;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.databinding.ItemPayBillDetailsBinding;
import com.huawei.payment.mvvm.DataBindingAdapter;
import k3.C0033a;

public class PayBillItemAdapter extends DataBindingAdapter<PayBillResp.PayBillItem, ItemPayBillDetailsBinding> {
    public final int a() {
        return R$layout.item_pay_bill_details;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        ItemPayBillDetailsBinding itemPayBillDetailsBinding = (ItemPayBillDetailsBinding) viewDataBinding;
        PayBillResp.PayBillItem payBillItem = (PayBillResp.PayBillItem) obj;
        TextView textView = itemPayBillDetailsBinding.a;
        textView.setText(payBillItem.getOpenAmount() + C0033a.e.b());
        itemPayBillDetailsBinding.b.setText(payBillItem.getDueDate());
        itemPayBillDetailsBinding.c.setText(payBillItem.getBillCycleID());
    }
}
