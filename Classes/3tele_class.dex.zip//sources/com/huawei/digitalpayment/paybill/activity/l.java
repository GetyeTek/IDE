package com.huawei.digitalpayment.paybill.activity;

import O2.a;
import W2.n;
import android.text.Editable;
import android.text.TextUtils;
import android.widget.EditText;

public final class l extends a {
    public final /* synthetic */ PayBillActivity b;

    public l(PayBillActivity payBillActivity) {
        super(1);
        this.b = payBillActivity;
    }

    public final void afterTextChanged(Editable editable) {
        boolean isEmpty = TextUtils.isEmpty(editable.toString());
        PayBillActivity payBillActivity = this.b;
        if (!isEmpty) {
            int i = PayBillActivity.n;
            payBillActivity.b.e.getEditText().setText("");
        }
        if (payBillActivity.m == 1) {
            if (!TextUtils.isEmpty(editable.toString())) {
                payBillActivity.b.f.getEditText().setText("");
            } else {
                EditText editText = payBillActivity.b.f.getEditText();
                editText.setText("+251 " + n.b("").e("recent_login_phone_number").substring(3));
            }
        }
        payBillActivity.G0();
    }
}
