package com.huawei.digitalpayment.paybill.activity;

import H8.c;
import android.view.View;
import com.blankj.utilcode.util.A;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;

public final /* synthetic */ class a implements CustomKeyBroadPop.a {
    public final /* synthetic */ BillDetailsActivity a;

    public /* synthetic */ a(BillDetailsActivity billDetailsActivity) {
        this.a = billDetailsActivity;
    }

    public final void b(boolean z) {
        int i;
        int i2 = BillDetailsActivity.i;
        BillDetailsActivity billDetailsActivity = this.a;
        View view = billDetailsActivity.b.b;
        if (z) {
            i = 0;
        } else {
            i = 8;
        }
        view.setVisibility(i);
        if (z) {
            A.h(new c(billDetailsActivity, 1), 350);
        }
    }
}
