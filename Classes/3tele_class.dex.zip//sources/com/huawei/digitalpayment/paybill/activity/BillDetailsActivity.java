package com.huawei.digitalpayment.paybill.activity;

import androidx.lifecycle.ViewModel;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.digitalpayment.paybill.resp.PayBillResp;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding;
import com.huawei.payment.mvvm.DataBindingActivity;

public class BillDetailsActivity extends DataBindingActivity<ActivityBillDetailsBinding, ViewModel> {
    public static final /* synthetic */ int i = 0;
    public PayBillResp d;
    public CustomKeyBroadPop e;
    public String f;
    public String g;
    public Boolean h;

    public final int C0() {
        return R$layout.activity_bill_details;
    }

    public final void E0() {
        if (!this.h.booleanValue()) {
            this.b.c.setVisibility(0);
        } else {
            this.b.c.setVisibility(4);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    @android.annotation.SuppressLint({"SetTextI18n"})
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r10) {
        /*
            r9 = this;
            r0 = 2
            r1 = 1
            r2 = 0
            com.huawei.digitalpayment.paybill.activity.BillDetailsActivity.super.onCreate(r10)
            int r10 = com.huawei.digitalpayment.topup.R$color.color_F4F4F4
            int r10 = androidx.core.content.ContextCompat.getColor(r9, r10)
            com.blankj.utilcode.util.f.e(r9, r10, r2)
            int r10 = com.huawei.digitalpayment.topup.R$string.pay_ethio_telecom_bill
            java.lang.String r10 = r9.getString(r10)
            int r3 = com.huawei.payment.mvvm.R.layout.common_toolbar
            V7.e.a(r9, r10, r3)
            android.content.Intent r10 = r9.getIntent()
            java.lang.String r3 = "PayBillResp"
            java.io.Serializable r10 = r10.getSerializableExtra(r3)
            com.huawei.digitalpayment.paybill.resp.PayBillResp r10 = (com.huawei.digitalpayment.paybill.resp.PayBillResp) r10
            r9.d = r10
            android.content.Intent r10 = r9.getIntent()
            java.lang.String r3 = "phoneNumber"
            java.lang.String r10 = r10.getStringExtra(r3)
            r9.f = r10
            android.content.Intent r10 = r9.getIntent()
            java.lang.String r3 = "accountCode"
            java.lang.String r10 = r10.getStringExtra(r3)
            r9.g = r10
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            android.widget.TextView r10 = r10.h
            com.huawei.digitalpayment.paybill.resp.PayBillResp r3 = r9.d
            java.lang.String r3 = r3.getCustomerName()
            r10.setText(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            com.huawei.common.widget.recyclerview.HFRecyclerView r10 = r10.f
            androidx.recyclerview.widget.LinearLayoutManager r3 = new androidx.recyclerview.widget.LinearLayoutManager
            r3.<init>(r9)
            r10.setLayoutManager(r3)
            com.huawei.digitalpayment.paybill.adapter.PayBillItemAdapter r10 = new com.huawei.digitalpayment.paybill.adapter.PayBillItemAdapter
            r10.<init>()
            androidx.databinding.ViewDataBinding r3 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r3
            com.huawei.common.widget.recyclerview.HFRecyclerView r3 = r3.f
            r3.setAdapter(r10)
            com.huawei.digitalpayment.paybill.resp.PayBillResp r3 = r9.d
            java.util.List r3 = r3.getInvoiceInfo()
            r10.submitList(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            android.widget.TextView r10 = r10.k
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            com.huawei.digitalpayment.paybill.resp.PayBillResp r4 = r9.d
            java.lang.String r4 = r4.getTotalMoney()
            r3.append(r4)
            java.lang.String r4 = " "
            r3.append(r4)
            k3.a r4 = k3.C0033a.e
            java.lang.String r5 = r4.b()
            r3.append(r5)
            java.lang.String r3 = r3.toString()
            r10.setText(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            com.huawei.common.widget.input.CommonInputView r10 = r10.c
            android.widget.EditText r10 = r10.getEditText()
            r3 = 8194(0x2002, float:1.1482E-41)
            r10.setInputType(r3)
            android.view.LayoutInflater r10 = r9.getLayoutInflater()
            int r3 = com.huawei.digitalpayment.topup.R$layout.item_pay_bill_details
            androidx.databinding.ViewDataBinding r5 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r5 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r5
            com.huawei.common.widget.recyclerview.HFRecyclerView r5 = r5.f
            androidx.databinding.ViewDataBinding r10 = androidx.databinding.DataBindingUtil.inflate(r10, r3, r5, r2)
            com.huawei.digitalpayment.topup.databinding.ItemPayBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ItemPayBillDetailsBinding) r10
            android.widget.TextView r3 = r10.c
            int r5 = com.huawei.digitalpayment.topup.R$string.month
            r3.setText(r5)
            int r3 = com.huawei.digitalpayment.topup.R$string.amount
            android.widget.TextView r5 = r10.a
            r5.setText(r3)
            int r3 = com.huawei.digitalpayment.topup.R$string.due_date
            android.widget.TextView r6 = r10.b
            r6.setText(r3)
            int r3 = com.huawei.digitalpayment.topup.R$color.colorTextLevel4
            int r7 = androidx.core.content.ContextCompat.getColor(r9, r3)
            android.widget.TextView r8 = r10.c
            r8.setTextColor(r7)
            int r7 = androidx.core.content.ContextCompat.getColor(r9, r3)
            r5.setTextColor(r7)
            int r3 = androidx.core.content.ContextCompat.getColor(r9, r3)
            r6.setTextColor(r3)
            androidx.databinding.ViewDataBinding r3 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r3 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r3
            com.huawei.common.widget.recyclerview.HFRecyclerView r3 = r3.f
            android.view.View r10 = r10.getRoot()
            r5 = -1
            r3.a(r5, r10)
            java.lang.Boolean r10 = java.lang.Boolean.TRUE
            r9.h = r10
            r9.E0()
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            android.widget.ImageView r10 = r10.e
            com.huawei.astp.macle.ui.w r3 = new com.huawei.astp.macle.ui.w
            r3.<init>(r9, r1)
            r10.setOnClickListener(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            android.widget.ImageView r10 = r10.d
            D6.a r3 = new D6.a
            r3.<init>(r9, r0)
            r10.setOnClickListener(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            android.widget.TextView r10 = r10.j
            H6.i r3 = new H6.i
            r5 = 4
            r3.<init>(r9, r5)
            r10.setOnClickListener(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            android.widget.TextView r10 = r10.i
            D6.c r3 = new D6.c
            r5 = 8
            r3.<init>(r9, r5)
            r10.setOnClickListener(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            com.huawei.common.widget.input.CommonInputView r10 = r10.c
            android.widget.EditText r10 = r10.getEditText()
            com.huawei.digitalpayment.paybill.activity.b r3 = new com.huawei.digitalpayment.paybill.activity.b
            r3.<init>(r9)
            r10.addTextChangedListener(r3)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            com.huawei.common.widget.input.CommonInputView r10 = r10.c
            android.widget.EditText r10 = r10.getEditText()
            t4.e r3 = new t4.e
            r3.<init>()
            t4.a r5 = new t4.a
            r5.<init>()
            android.text.InputFilter[] r0 = new android.text.InputFilter[r0]
            r0[r2] = r3
            r0[r1] = r5
            r10.setFilters(r0)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            com.huawei.common.widget.input.CommonInputView r10 = r10.c
            int r0 = com.huawei.digitalpayment.topup.R$id.tv_unit
            android.view.View r10 = r10.findViewById(r0)
            android.widget.TextView r10 = (android.widget.TextView) r10
            java.lang.String r0 = r4.b()
            r10.setText(r0)
            androidx.databinding.ViewDataBinding r10 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r10 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r10
            com.huawei.common.widget.LoadingButton r10 = r10.a
            D6.f r0 = new D6.f
            r1 = 3
            r0.<init>(r9, r1)
            r10.setOnClickListener(r0)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r10 = new com.huawei.common.widget.keyboard.CustomKeyBroadPop
            c2.d r0 = c2.d.a()
            r10.<init>(r9, r0)
            r9.e = r10
            com.huawei.digitalpayment.paybill.activity.a r0 = new com.huawei.digitalpayment.paybill.activity.a
            r0.<init>(r9)
            r10.e = r0
            Y4.e r0 = new Y4.e
            r0.<init>(r9)
            r10.d = r0
            androidx.databinding.ViewDataBinding r0 = r9.b
            com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityBillDetailsBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.c
            android.widget.EditText r0 = r0.getEditText()
            r10.a(r9, r0, r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.paybill.activity.BillDetailsActivity.onCreate(android.os.Bundle):void");
    }
}
