package com.huawei.digitalpayment.paybill.adapter;

import V1.h;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.text.TextUtils;
import android.util.Base64;
import android.widget.TextView;
import androidx.databinding.ViewDataBinding;
import com.blankj.utilcode.util.J;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.paybill.resp.PayBillHistory;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$mipmap;
import com.huawei.digitalpayment.topup.databinding.ItemPayBillHistoryBinding;
import com.huawei.payment.mvvm.DataBindingAdapter;
import java.util.HashMap;

public class PayBillHistoryAdapter extends DataBindingAdapter<PayBillHistory, ItemPayBillHistoryBinding> {
    public final HashMap c;

    public PayBillHistoryAdapter() {
        HashMap hashMap = new HashMap();
        this.c = hashMap;
        hashMap.put(0, Integer.valueOf(R$color.colorEmbellishment));
        hashMap.put(1, Integer.valueOf(R$color.color_pay_bill_avatar2));
        hashMap.put(2, Integer.valueOf(R$color.color_pay_bill_avatar3));
        hashMap.put(3, Integer.valueOf(R$color.color_pay_bill_avatar4));
    }

    public final int a() {
        return R$layout.item_pay_bill_history;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        String str;
        Bitmap bitmap;
        ItemPayBillHistoryBinding itemPayBillHistoryBinding = (ItemPayBillHistoryBinding) viewDataBinding;
        PayBillHistory payBillHistory = (PayBillHistory) obj;
        itemPayBillHistoryBinding.b.setText(payBillHistory.getName());
        itemPayBillHistoryBinding.c.setText(payBillHistory.getPhoneNumber());
        boolean isEmpty = TextUtils.isEmpty(payBillHistory.getName());
        TextView textView = itemPayBillHistoryBinding.b;
        if (isEmpty) {
            textView.setVisibility(8);
        } else {
            textView.setVisibility(0);
        }
        boolean isEmpty2 = TextUtils.isEmpty(payBillHistory.getAvatar());
        RoundTextView roundTextView = itemPayBillHistoryBinding.a;
        if (!isEmpty2) {
            String avatar = payBillHistory.getAvatar();
            if (avatar.startsWith("data:image/jpg;base64,")) {
                str = avatar.replace("data:image/jpg;base64,", "");
            } else if (avatar.startsWith("data:image/png;base64,")) {
                str = avatar.replace("data:image/png;base64,", "");
            } else {
                str = "";
            }
            try {
                byte[] decode = Base64.decode(str, 2);
                bitmap = BitmapFactory.decodeByteArray(decode, 0, decode.length);
            } catch (Exception e) {
                e.getMessage();
                h.b();
                bitmap = null;
            }
            roundTextView.setBackground(new BitmapDrawable(J.a().getResources(), bitmap));
            roundTextView.setText("");
        } else if (TextUtils.isEmpty(payBillHistory.getName())) {
            roundTextView.setBackgroundResource(R$mipmap.topup_pay_bill_default_avatar);
            roundTextView.setText("");
        } else {
            roundTextView.setText(payBillHistory.getName().substring(0, 1));
            roundTextView.setBackgroundResource(((Integer) this.c.get(Integer.valueOf(i % 4))).intValue());
        }
    }
}
