package com.huawei.digitalpayment.paybill.resp;

import android.text.TextUtils;
import com.google.gson.annotations.SerializedName;
import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class PayBillResp extends BaseResp {
    private String enterpriseCustomerName;
    private String firstName;
    private List<PayBillItem> invoiceInfo;
    private String lastName;
    private String middleName;
    private String totalMoney;

    public static class PayBillItem implements Serializable {
        private String billCycleEndTime;
        @SerializedName(alternate = {"billCycleId"}, value = "billCycleID")
        private String billCycleID;
        private String dueDate;
        private String openAmount;
        private String unit;

        public BigDecimal getAmountValue() {
            try {
                return new BigDecimal(this.openAmount).divide(new BigDecimal("10000"), 2, 6);
            } catch (Exception unused) {
                return BigDecimal.ZERO;
            }
        }

        public String getBillCycleEndTime() {
            return this.billCycleEndTime;
        }

        public String getBillCycleID() {
            return this.billCycleID;
        }

        public String getDueDate() {
            return this.dueDate;
        }

        public String getOpenAmount() {
            return getAmountValue().toString();
        }

        public String getUnit() {
            return this.unit;
        }

        public void setBillCycleEndTime(String str) {
            this.billCycleEndTime = str;
        }

        public void setBillCycleID(String str) {
            this.billCycleID = str;
        }

        public void setDueDate(String str) {
            this.dueDate = str;
        }

        public void setOpenAmount(String str) {
            this.openAmount = str;
        }

        public void setUnit(String str) {
            this.unit = str;
        }
    }

    private String getEnterpriseCustomerName() {
        String str = this.enterpriseCustomerName;
        if (str == null) {
            return "";
        }
        return str;
    }

    public String getCustomerName() {
        if (TextUtils.isEmpty(this.firstName) && TextUtils.isEmpty(this.middleName) && TextUtils.isEmpty(this.lastName)) {
            return getEnterpriseCustomerName();
        }
        return getFirstName() + " " + getMiddleName() + " " + getLastName();
    }

    public String getFirstName() {
        String str = this.firstName;
        if (str == null) {
            return "";
        }
        return str;
    }

    public List<PayBillItem> getInvoiceInfo() {
        return this.invoiceInfo;
    }

    public String getLastName() {
        if (this.middleName == null) {
            return "";
        }
        return this.lastName;
    }

    public String getMiddleName() {
        String str = this.middleName;
        if (str == null) {
            return "";
        }
        return str;
    }

    public String getTotalMoney() {
        return this.totalMoney;
    }

    public boolean isNoBill() {
        try {
            return BigDecimal.ZERO.equals(new BigDecimal(this.totalMoney));
        } catch (Exception unused) {
            return true;
        }
    }

    public void setEnterpriseCustomerName(String str) {
        this.enterpriseCustomerName = str;
    }

    public void setFirstName(String str) {
        this.firstName = str;
    }

    public void setInvoiceInfo(List<PayBillItem> list) {
        this.invoiceInfo = list;
    }

    public void setLastName(String str) {
        this.lastName = str;
    }

    public void setMiddleName(String str) {
        this.middleName = str;
    }

    public void setTotalMoney(String str) {
        this.totalMoney = str;
    }
}
