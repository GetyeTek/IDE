package com.huawei.digitalpayment.paybill.activity;

import android.app.Activity;
import android.os.Bundle;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.payment.mvvm.DataBindingActivity;
import i7.a;
import java.util.Map;
import o0.b;

public final class o implements a.b<TransferResp> {
    public final /* synthetic */ PayBillActivity a;

    public o(PayBillActivity payBillActivity) {
        this.a = payBillActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    public final void onSuccess(Object obj) {
        Bundle bundle = new Bundle();
        int i = R$string.baselib_finished;
        DataBindingActivity dataBindingActivity = this.a;
        bundle.putString("buttonText", dataBindingActivity.getString(i));
        bundle.putSerializable("TransferResp", (TransferResp) obj);
        b.d((Activity) null, "/basicUiModule/commonSuccess", bundle, (Map) null);
        dataBindingActivity.finish();
    }
}
