package com.huawei.digitalpayment.paybill.activity;

import O2.a;
import W2.g;
import android.text.Editable;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.digitalpayment.customer.httplib.response.VerifySecurityQuestionResp;
import com.huawei.digitalpayment.topup.R$string;
import k3.C0033a;

public final class b extends a {
    public final /* synthetic */ BillDetailsActivity b;

    public b(BillDetailsActivity billDetailsActivity) {
        super(1);
        this.b = billDetailsActivity;
    }

    public final void afterTextChanged(Editable editable) {
        String str;
        if (editable.toString().length() == 2 && editable.toString().startsWith(VerifySecurityQuestionResp.CODE_SUCCESS) && !editable.toString().equals("0.")) {
            editable.delete(0, 1);
        }
        BillDetailsActivity billDetailsActivity = this.b;
        billDetailsActivity.e.d(g.a(editable.toString()));
        billDetailsActivity.b.a.setEnabled(g.a(editable.toString()));
        CommonInputView commonInputView = billDetailsActivity.b.c;
        if (g.a(editable.toString())) {
            str = null;
        } else {
            String string = billDetailsActivity.getResources().getString(R$string.sorry_the_amount_must_be_multiple_of);
            str = String.format(string, new Object[]{" 1 " + C0033a.e.b()});
        }
        commonInputView.setError(str);
    }
}
