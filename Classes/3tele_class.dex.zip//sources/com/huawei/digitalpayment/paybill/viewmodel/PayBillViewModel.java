package com.huawei.digitalpayment.paybill.viewmodel;

import C4.a;
import C4.b;
import C4.d;
import V7.c;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.digitalpayment.paybill.repository.QueryPayBillRepository;
import com.huawei.digitalpayment.paybill.resp.PayBillHistory;
import com.huawei.digitalpayment.paybill.resp.PayBillResp;
import java.util.HashMap;
import java.util.List;

public class PayBillViewModel extends ViewModel {
    public final MutableLiveData<String> a;
    public final MutableLiveData<c<List<HomeBannerBean>>> b = new MutableLiveData<>();
    public final MutableLiveData<Boolean> c;
    public final MutableLiveData<c<PayBillResp>> d;
    public QueryPayBillRepository e;
    public final MediatorLiveData<Object> f;
    public final LiveData<List<PayBillHistory>> g;
    public BannerRepository h;

    public PayBillViewModel() {
        MutableLiveData<String> mutableLiveData = new MutableLiveData<>();
        this.a = mutableLiveData;
        MutableLiveData<Boolean> mutableLiveData2 = new MutableLiveData<>(Boolean.FALSE);
        this.c = mutableLiveData2;
        this.d = new MutableLiveData<>();
        MediatorLiveData<Object> mediatorLiveData = new MediatorLiveData<>();
        this.f = mediatorLiveData;
        this.g = Transformations.switchMap(mediatorLiveData, new a(this));
        mediatorLiveData.addSource(mutableLiveData, new b(this, 0));
        mediatorLiveData.addSource(mutableLiveData2, new C4.c(this, 0));
    }

    public final void a(HashMap hashMap) {
        this.d.setValue(c.c());
        com.huawei.http.b bVar = new com.huawei.http.b();
        bVar.addParams(hashMap);
        this.e = bVar;
        bVar.sendRequest(new d(this, 0));
    }

    public final void onCleared() {
        PayBillViewModel.super.onCleared();
        QueryPayBillRepository queryPayBillRepository = this.e;
        if (queryPayBillRepository != null) {
            queryPayBillRepository.cancel();
        }
        BannerRepository bannerRepository = this.h;
        if (bannerRepository != null) {
            bannerRepository.cancel();
        }
    }
}
