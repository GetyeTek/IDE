package com.huawei.digitalpayment.paybill.activity;

import O2.a;
import android.text.Editable;

public final class m extends a {
    public final /* synthetic */ PayBillActivity b;

    public m(PayBillActivity payBillActivity) {
        super(1);
        this.b = payBillActivity;
    }

    public final void afterTextChanged(Editable editable) {
        int i = PayBillActivity.n;
        this.b.G0();
    }
}
