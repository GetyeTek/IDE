package com.huawei.digitalpayment.paybill.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import java.util.Map;
import o0.b;

public final /* synthetic */ class f implements View.OnClickListener {
    public final /* synthetic */ PayBillActivity a;

    public /* synthetic */ f(PayBillActivity payBillActivity) {
        this.a = payBillActivity;
    }

    public final void onClick(View view) {
        b.d((Activity) null, this.a.secondExecute, (Bundle) null, (Map) null);
    }
}
