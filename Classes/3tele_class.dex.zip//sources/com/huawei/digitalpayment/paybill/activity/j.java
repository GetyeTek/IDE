package com.huawei.digitalpayment.paybill.activity;

import com.google.android.material.tabs.TabLayout;

public final class j implements TabLayout.OnTabSelectedListener {
    public final /* synthetic */ PayBillActivity a;

    public j(PayBillActivity payBillActivity) {
        this.a = payBillActivity;
    }

    public final void onTabReselected(TabLayout.Tab tab) {
    }

    public final void onTabSelected(TabLayout.Tab tab) {
        int i = PayBillActivity.n;
        this.a.F0(tab, true);
    }

    public final void onTabUnselected(TabLayout.Tab tab) {
        int i = PayBillActivity.n;
        this.a.F0(tab, false);
    }
}
