package com.huawei.digitalpayment.paybill.resp;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import com.huawei.http.BaseResp;

@Entity
public class PayBillHistory extends BaseResp {
    private String avatar;
    private String name;
    @NonNull
    @PrimaryKey
    private String phoneNumber;
    private int recent;
    private long time;

    public String getAvatar() {
        return this.avatar;
    }

    public String getName() {
        return this.name;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public int getRecent() {
        return this.recent;
    }

    public long getTime() {
        return this.time;
    }

    public void setAvatar(String str) {
        this.avatar = str;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setPhoneNumber(String str) {
        this.phoneNumber = str;
    }

    public void setRecent(int i) {
        this.recent = i;
    }

    public void setTime(long j) {
        this.time = j;
    }
}
