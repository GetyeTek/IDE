package com.huawei.digitalpayment.paybill.repository;

import com.huawei.digitalpayment.paybill.resp.PayBillResp;
import com.huawei.http.b;

public class QueryPayBillRepository extends b<PayBillResp, PayBillResp> {
    public QueryPayBillRepository() {
        throw null;
    }

    public final String getApiPath() {
        return "v1/ethiopia/queryPayEtBill";
    }
}
