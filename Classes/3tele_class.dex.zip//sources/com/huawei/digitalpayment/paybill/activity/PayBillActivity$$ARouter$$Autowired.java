package com.huawei.digitalpayment.paybill.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class PayBillActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.digitalpayment.paybill.activity.PayBillActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        this.serializationService = e.c(SerializationService.class);
        ? r42 = (PayBillActivity) obj;
        if (r42.getIntent().getExtras() == null) {
            str = r42.secondExecute;
        } else {
            str = r42.getIntent().getExtras().getString("secondExecute", r42.secondExecute);
        }
        r42.secondExecute = str;
        if (r42.getIntent().getExtras() == null) {
            str2 = r42.entrance;
        } else {
            str2 = r42.getIntent().getExtras().getString("entrance", r42.entrance);
        }
        r42.entrance = str2;
        if (r42.getIntent().getExtras() == null) {
            str3 = r42.msisdn;
        } else {
            str3 = r42.getIntent().getExtras().getString("msisdn", r42.msisdn);
        }
        r42.msisdn = str3;
    }
}
