package com.huawei.digitalpayment.paybill.activity;

import A6.a;
import C6.c;
import J6.b;
import V7.e;
import Y4.m;
import Y4.r;
import Y4.u;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.f;
import com.google.android.material.tabs.TabLayout;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.digitalpayment.customer.httplib.response.VerifySecurityQuestionResp;
import com.huawei.digitalpayment.paybill.adapter.PayBillHistoryAdapter;
import com.huawei.digitalpayment.paybill.viewmodel.PayBillViewModel;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$mipmap;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.Arrays;
import java.util.List;
import k3.C0033a;

@Route(path = "/topUpModule/PayBill")
public class PayBillActivity extends DataBindingActivity<ActivityPayBillBinding, PayBillViewModel> {
    public static final /* synthetic */ int n = 0;
    public String d;
    public String e;
    @Autowired
    String entrance;
    public PayBillHistoryAdapter f;
    public List<Integer> g;
    public List<Integer> h;
    public List<Integer> i;
    public List<Integer> j;
    public TextView k;
    public boolean l;
    public int m;
    @Autowired
    String msisdn;
    @Autowired
    String secondExecute;

    public final int C0() {
        return R$layout.activity_pay_bill;
    }

    public final void E0() {
        if (this.l) {
            this.b.f.setVisibility(0);
            this.b.e.setVisibility(8);
            this.b.k.setVisibility(8);
        } else {
            this.b.f.setVisibility(8);
            this.b.e.setVisibility(0);
            this.b.k.setVisibility(0);
        }
        if (!this.l || this.m != 0) {
            this.b.d.setVisibility(0);
        } else {
            this.b.d.setVisibility(8);
        }
        if (this.m == 1) {
            this.b.i.setVisibility(0);
        } else {
            this.b.i.setVisibility(8);
        }
    }

    /* JADX WARNING: type inference failed for: r5v14, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText] */
    public final void F0(TabLayout.Tab tab, boolean z) {
        List<Integer> list;
        int i2;
        int i5;
        int position = tab.getPosition();
        View customView = tab.getCustomView();
        ImageView imageView = (ImageView) customView.findViewById(R$id.iv_bill);
        TextView textView = (TextView) customView.findViewById(R$id.tv_bill);
        if (z) {
            list = this.i;
        } else {
            list = this.h;
        }
        imageView.setImageResource(list.get(position).intValue());
        if (z) {
            i2 = R$color.colorPrimary;
        } else {
            i2 = R$color.colorTextLevel3;
        }
        textView.setTextColor(ContextCompat.getColor(this, i2));
        if (z) {
            tab.view.setBackground(ContextCompat.getDrawable(this, this.j.get(position).intValue()));
            this.m = position;
            E0();
            TextView textView2 = this.k;
            if (textView2 != null) {
                if (position == 0) {
                    textView2.setText(R$string.pay_ethio_telecom_bill);
                } else {
                    textView2.setText(R$string.postpaid_credit_limit_deposit);
                }
            }
            this.b.e.getEditText().setText("");
            this.b.d.getEditText().setText("");
            this.b.c.setText("");
            this.b.n.performClick();
            LinearLayout linearLayout = this.b.j;
            if (position == 0) {
                i5 = 0;
            } else {
                i5 = 8;
            }
            linearLayout.setVisibility(i5);
            G0();
            return;
        }
        tab.view.setBackground((Drawable) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x002a, code lost:
        if (r5.b.e.getText().length() < 2) goto L_0x002d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void G0() {
        /*
            r5 = this;
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.d
            java.lang.String r0 = r0.getText()
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            int r1 = r5.m
            r2 = 0
            r3 = 2
            r4 = 1
            if (r1 != 0) goto L_0x002f
            boolean r1 = r5.l
            if (r1 == 0) goto L_0x001a
            goto L_0x0079
        L_0x001a:
            if (r0 == 0) goto L_0x002c
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.e
            java.lang.String r0 = r0.getText()
            int r0 = r0.length()
            if (r0 < r3) goto L_0x002d
        L_0x002c:
            r2 = 1
        L_0x002d:
            r4 = r2
            goto L_0x0079
        L_0x002f:
            boolean r1 = r5.l
            if (r1 == 0) goto L_0x0056
            if (r0 == 0) goto L_0x0045
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.f
            java.lang.String r0 = r0.getText()
            int r0 = r0.length()
            if (r0 < r3) goto L_0x002d
        L_0x0045:
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding) r0
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r0 = r0.c
            android.text.Editable r0 = r0.getText()
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x002d
            goto L_0x002c
        L_0x0056:
            if (r0 == 0) goto L_0x0068
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding) r0
            com.huawei.common.widget.input.CommonInputView r0 = r0.e
            java.lang.String r0 = r0.getText()
            int r0 = r0.length()
            if (r0 < r3) goto L_0x002d
        L_0x0068:
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding) r0
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r0 = r0.c
            android.text.Editable r0 = r0.getText()
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x002d
            goto L_0x002c
        L_0x0079:
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayBillBinding) r0
            com.huawei.common.widget.LoadingButton r0 = r0.a
            r0.setEnabled(r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.paybill.activity.PayBillActivity.G0():void");
    }

    public final void H0() {
        PayBillHistoryAdapter payBillHistoryAdapter;
        if (this.l || (payBillHistoryAdapter = this.f) == null || payBillHistoryAdapter.getItemCount() <= 0) {
            this.b.o.setVisibility(8);
        } else {
            this.b.o.setVisibility(0);
        }
    }

    /* JADX WARNING: type inference failed for: r10v81, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText] */
    public final void onCreate(@Nullable Bundle bundle) {
        getWindow().setSoftInputMode(16);
        PayBillActivity.super.onCreate(bundle);
        ((ViewGroup.MarginLayoutParams) this.b.getRoot().getLayoutParams()).topMargin = -f.c();
        f.e(this, ContextCompat.getColor(this, R$color.colorPrimary), false);
        e.a(this, getString(R$string.pay_ethio_telecom_bill), R$layout.pay_bill_toolbar);
        this.k = (TextView) ((ViewGroup) this.a.findViewById(16908290)).findViewById(R$id.tvTitle);
        this.g = Arrays.asList(new Integer[]{Integer.valueOf(R$string.bill), Integer.valueOf(R$string.designstandard_deposit)});
        this.h = Arrays.asList(new Integer[]{Integer.valueOf(R$mipmap.icon_bill_unselected), Integer.valueOf(R$mipmap.icon_deposit_unselected)});
        this.i = Arrays.asList(new Integer[]{Integer.valueOf(R$mipmap.icon_bill_selected), Integer.valueOf(R$mipmap.icon_deposit_selected)});
        this.j = Arrays.asList(new Integer[]{Integer.valueOf(R$mipmap.icon_pay_bill_right_bg), Integer.valueOf(R$mipmap.icon_pay_bill_left_bg)});
        for (int i2 = 0; i2 < this.g.size(); i2++) {
            TabLayout.Tab newTab = this.b.l.newTab();
            View inflate = LayoutInflater.from(this).inflate(R$layout.item_tab, (ViewGroup) null);
            inflate.setLongClickable(false);
            ((ImageView) inflate.findViewById(R$id.iv_bill)).setImageResource(this.h.get(i2).intValue());
            ((TextView) inflate.findViewById(R$id.tv_bill)).setText(this.g.get(i2).intValue());
            newTab.setCustomView(inflate);
            this.b.l.addTab(newTab);
            if (i2 == 0) {
                F0(newTab, true);
            }
        }
        this.b.l.addOnTabSelectedListener(new j(this));
        this.b.h.setOnClickListener(new b(this, 3));
        this.b.g.setOnClickListener(new m(this, 3));
        this.b.n.setOnClickListener(new C6.b(this, 3));
        this.b.m.setOnClickListener(new c(this, 1));
        this.b.c.setCurrency(C0033a.e.b());
        this.b.d.setError((String) null);
        this.b.f.setError((String) null);
        this.b.e.setError((String) null);
        this.b.e.getEditText().setFilters(new InputFilter[]{new InputFilter.LengthFilter(18)});
        this.b.e.setOnIconListener(new a(this, 4));
        EditText editText = this.b.e.getEditText();
        editText.setHint(getString(R$string.enter_service_number) + "...");
        this.b.e.getEditText().addTextChangedListener(new k(this, 0));
        this.b.d.getEditText().setFilters(new InputFilter[]{new InputFilter.LengthFilter(18)});
        this.b.d.getEditText().addTextChangedListener(new l(this));
        this.b.c.addTextChangedListener(new m(this));
        this.b.a.setOnClickListener(new A6.b(this, 2));
        this.b.k.setLayoutManager(new LinearLayoutManager(this));
        PayBillHistoryAdapter payBillHistoryAdapter = new PayBillHistoryAdapter();
        this.f = payBillHistoryAdapter;
        payBillHistoryAdapter.a = new i(this, 0);
        this.b.k.setAdapter(payBillHistoryAdapter);
        this.c.g.observe(this, new u(this, 1));
        this.b.j.setOnClickListener(new f(this));
        PayBillViewModel payBillViewModel = this.c;
        payBillViewModel.getClass();
        BannerRepository bannerRepository = new BannerRepository("Application Page", "Pay Ethio-telecom Bill");
        payBillViewModel.h = bannerRepository;
        bannerRepository.sendRequest(new C4.e(payBillViewModel));
        this.c.d.observe(this, new r(this, 1));
        this.c.b.observe(this, new h(this, 0));
        if (TextUtils.equals(this.entrance, "chat")) {
            this.b.m.performClick();
            if (!TextUtils.isEmpty(this.msisdn)) {
                this.b.e.getEditText().setText(this.msisdn.replace("251", VerifySecurityQuestionResp.CODE_SUCCESS));
                return;
            }
            return;
        }
        this.b.n.performClick();
    }

    public final void onResume() {
        PayBillActivity.super.onResume();
        if (B4.b.a == null) {
            A.d(new A.b());
        }
    }
}
