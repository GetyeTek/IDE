package com.huawei.digitalpayment.payformerchant;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class CNetParams implements Serializable {
    private static final long serialVersionUID = -690589599034231655L;
    private List<CNetItems> displayItems;
    private Map<String, Object> params;

    public List<CNetItems> getDisplayItems() {
        return this.displayItems;
    }

    public Map<String, Object> getParams() {
        return this.params;
    }

    public void setDisplayItems(List<CNetItems> list) {
        this.displayItems = list;
    }

    public void setParams(Map<String, Object> map) {
        this.params = map;
    }
}
