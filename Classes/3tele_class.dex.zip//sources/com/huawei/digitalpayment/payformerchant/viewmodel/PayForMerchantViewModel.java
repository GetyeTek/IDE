package com.huawei.digitalpayment.payformerchant.viewmodel;

import V7.c;
import W2.n;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.digitalpayment.payformerchant.bean.MerchantInfo;
import com.huawei.digitalpayment.payformerchant.bean.MerchantInfoResp;
import com.huawei.digitalpayment.payformerchant.repository.ApplyVoucherRepository;
import com.huawei.digitalpayment.payformerchant.repository.VerifyCustomerBuyGoodsRepository;
import com.huawei.http.BaseResp;
import java.util.List;

public class PayForMerchantViewModel extends ViewModel {
    public final MutableLiveData<c<MerchantInfoResp>> a = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> b = new MutableLiveData<>();
    public final MutableLiveData<c<List<HomeBannerBean>>> c = new MutableLiveData<>();
    public VerifyCustomerBuyGoodsRepository d;
    public ApplyVoucherRepository e;
    public BannerRepository f;
    public final MutableLiveData<List<MerchantInfo>> g = new MutableLiveData<>();

    public static String a() {
        return androidx.camera.core.c.a(n.b("").e("recent_login_phone_number"), "recent_pay_for_merchant");
    }

    public final void onCleared() {
        PayForMerchantViewModel.super.onCleared();
        VerifyCustomerBuyGoodsRepository verifyCustomerBuyGoodsRepository = this.d;
        if (verifyCustomerBuyGoodsRepository != null) {
            verifyCustomerBuyGoodsRepository.cancel();
        }
        ApplyVoucherRepository applyVoucherRepository = this.e;
        if (applyVoucherRepository != null) {
            applyVoucherRepository.cancel();
        }
        BannerRepository bannerRepository = this.f;
        if (bannerRepository != null) {
            bannerRepository.cancel();
        }
    }
}
