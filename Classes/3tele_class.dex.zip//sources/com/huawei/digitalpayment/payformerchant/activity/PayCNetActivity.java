package com.huawei.digitalpayment.payformerchant.activity;

import D4.a;
import D4.b;
import V1.h;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.google.gson.Gson;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.digitalpayment.payformerchant.CNetItems;
import com.huawei.digitalpayment.payformerchant.CNetParams;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.databinding.ActivityPayCnetBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.List;

@Route(path = "/topUpModule/cNet")
public class PayCNetActivity extends DataBindingActivity<ActivityPayCnetBinding, ViewModel> {
    public static final /* synthetic */ int e = 0;
    public CNetParams d;

    public final int C0() {
        return R$layout.activity_pay_cnet;
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [java.lang.Object, com.huawei.digitalpayment.payformerchant.activity.PayCNetActivity, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity] */
    public final void onCreate(@Nullable Bundle bundle) {
        PayCNetActivity.super.onCreate(bundle);
        this.b.b.setOnClickListener(new a(this, 0));
        String stringExtra = getIntent().getStringExtra("params");
        if (!TextUtils.isEmpty(stringExtra)) {
            try {
                this.d = (CNetParams) new Gson().fromJson(stringExtra, CNetParams.class);
            } catch (Exception e2) {
                e2.getMessage();
                h.b();
            }
            CNetParams cNetParams = this.d;
            if (cNetParams != null) {
                List<CNetItems> displayItems = cNetParams.getDisplayItems();
                if (displayItems != null) {
                    for (CNetItems next : displayItems) {
                        RoundLinearLayout roundLinearLayout = this.b.c;
                        View inflate = getLayoutInflater().inflate(R$layout.item_cnet_list_field, (ViewGroup) null, false);
                        String key = next.getKey();
                        String value = next.getValue();
                        ((TextView) inflate.findViewById(R$id.tv_field_name)).setText(key);
                        ((TextView) inflate.findViewById(R$id.tv_field_value)).setText(value);
                        roundLinearLayout.addView(inflate);
                    }
                }
                this.b.a.setOnClickListener(new b(this, 0));
            }
        }
    }
}
