package com.huawei.digitalpayment.payformerchant;

import java.io.Serializable;

public class CNetItems implements Serializable {
    private boolean display;
    private String key;
    private String value;

    public String getKey() {
        return this.key;
    }

    public String getValue() {
        return this.value;
    }

    public boolean isDisplay() {
        return this.display;
    }

    public void setDisplay(boolean z) {
        this.display = z;
    }

    public void setKey(String str) {
        this.key = str;
    }

    public void setValue(String str) {
        this.value = str;
    }
}
