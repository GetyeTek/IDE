package com.huawei.digitalpayment.payformerchant.activity;

import R1.b;
import V7.c;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.digitalpayment.payformerchant.adapter.RecentPayForMerchantAdapter;
import com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import r4.f;

@Route(path = "/topUpModule/payForMerchant")
public class PayForMerchantActivity extends DataBindingActivity<ActivityPayForMerchantBinding, PayForMerchantViewModel> {
    public static final /* synthetic */ int h = 0;
    public CustomKeyBroadPop d;
    public String e;
    public RecentPayForMerchantAdapter f;
    public Boolean g;

    public class a extends b {
        public a() {
        }

        public final void a(View view) {
            FragmentActivity fragmentActivity = PayForMerchantActivity.this;
            if (fragmentActivity.g.booleanValue()) {
                f.b.a(fragmentActivity, new Va.a(fragmentActivity, 1));
                return;
            }
            w5.a.a("Pay_for_Merchant_Apply_voucher_next_V1");
            o0.b.e(fragmentActivity, "/loginModule/openBiometricIdentifyPin", (Bundle) null, (Map) null, 0, 11);
        }
    }

    public final int C0() {
        return R$layout.activity_pay_for_merchant;
    }

    @SuppressLint({"ResourceAsColor"})
    public final void E0() {
        if (this.g.booleanValue()) {
            this.b.o.setTextColor(getResources().getColor(R$color.colorPrimary));
            this.b.k.setVisibility(0);
            this.b.n.setTextColor(getResources().getColor(R$color.colorTextLevel3));
            this.b.a.setVisibility(4);
            this.b.j.setVisibility(0);
            this.b.l.setVisibility(8);
            return;
        }
        this.b.o.setTextColor(getResources().getColor(R$color.colorTextLevel3));
        this.b.k.setVisibility(4);
        this.b.n.setTextColor(getResources().getColor(R$color.colorPrimary));
        this.b.a.setVisibility(0);
        this.b.j.setVisibility(8);
        this.b.l.setVisibility(0);
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        PayForMerchantActivity.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 11 && i2 == -1) {
            byte[] byteArrayExtra = intent.getByteArrayExtra("pin");
            PayForMerchantViewModel payForMerchantViewModel = this.c;
            String g2 = L3.a.g(new String(byteArrayExtra, StandardCharsets.UTF_8));
            payForMerchantViewModel.b.setValue(c.c());
            com.huawei.http.b bVar = new com.huawei.http.b();
            bVar.addParams("initiatorPin", g2);
            bVar.addParams("pinVersion", L3.a.b.getPinKeyVersion());
            payForMerchantViewModel.e = bVar;
            bVar.sendRequest(new F4.c(payForMerchantViewModel, 0));
        }
    }

    public final void onBackPressed() {
        if (this.d.isShowing()) {
            this.d.c();
        } else {
            PayForMerchantActivity.super.onBackPressed();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v1, resolved type: android.text.InputFilter[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: type inference failed for: r2v7, types: [android.view.View$OnClickListener, com.huawei.digitalpayment.payformerchant.activity.PayForMerchantActivity$a] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r7) {
        /*
            r6 = this;
            r0 = 1
            r1 = 0
            com.huawei.digitalpayment.payformerchant.activity.PayForMerchantActivity.super.onCreate(r7)
            int r7 = com.huawei.digitalpayment.topup.R$color.color_F4F4F4
            int r7 = androidx.core.content.ContextCompat.getColor(r6, r7)
            com.blankj.utilcode.util.f.e(r6, r7, r1)
            int r7 = com.huawei.digitalpayment.topup.R$string.pay_for_merchant
            java.lang.String r7 = r6.getString(r7)
            int r2 = com.huawei.payment.mvvm.R.layout.common_toolbar
            V7.e.a(r6, r7, r2)
            java.lang.Boolean r7 = java.lang.Boolean.TRUE
            r6.g = r7
            r6.E0()
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            android.widget.TextView r7 = r7.o
            D4.n r2 = new D4.n
            r2.<init>(r6, r1)
            r7.setOnClickListener(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            android.widget.TextView r7 = r7.n
            D4.o r2 = new D4.o
            r2.<init>(r6, r1)
            r7.setOnClickListener(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.e
            D4.p r2 = new D4.p
            r2.<init>(r6, r1)
            r7.setOnIconListener(r2)
            D4.t r7 = new D4.t
            r7.<init>(r6)
            W2.q.a(r6, r7)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            int r2 = com.huawei.digitalpayment.topup.R$id.tv_unit
            android.view.View r7 = r7.findViewById(r2)
            android.widget.TextView r7 = (android.widget.TextView) r7
            k3.a r2 = k3.C0033a.e
            java.lang.String r2 = r2.b()
            r7.setText(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.LoadingButton r7 = r7.b
            com.huawei.digitalpayment.payformerchant.activity.PayForMerchantActivity$a r2 = new com.huawei.digitalpayment.payformerchant.activity.PayForMerchantActivity$a
            r2.<init>()
            r7.setOnClickListener(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.d
            android.widget.EditText r7 = r7.getEditText()
            r7.setInputType(r0)
            r7 = 50
            com.huawei.digitalpayment.customer.cache.BasicConfig r2 = com.huawei.digitalpayment.customer.cache.BasicConfig.getInstance()     // Catch:{ Exception -> 0x00a3 }
            com.huawei.digitalpayment.customer.httplib.bean.ParameterLimitBean r2 = r2.getParameterLimit()     // Catch:{ Exception -> 0x00a3 }
            if (r2 == 0) goto L_0x00a6
            java.lang.String r3 = r2.getNoteLimit()     // Catch:{ Exception -> 0x00a3 }
            boolean r3 = android.text.TextUtils.isEmpty(r3)     // Catch:{ Exception -> 0x00a3 }
            if (r3 != 0) goto L_0x00a6
            java.lang.String r2 = r2.getNoteLimit()     // Catch:{ Exception -> 0x00a3 }
            int r7 = java.lang.Integer.parseInt(r2)     // Catch:{ Exception -> 0x00a3 }
            goto L_0x00a6
        L_0x00a3:
            V1.h.b()
        L_0x00a6:
            androidx.databinding.ViewDataBinding r2 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r2
            com.huawei.common.widget.input.CommonInputView r2 = r2.d
            android.widget.EditText r2 = r2.getEditText()
            android.text.InputFilter$LengthFilter r3 = new android.text.InputFilter$LengthFilter
            r3.<init>(r7)
            t4.h r7 = new t4.h
            r7.<init>()
            r4 = 2
            android.text.InputFilter[] r4 = new android.text.InputFilter[r4]
            r4[r1] = r3
            r4[r0] = r7
            r2.setFilters(r4)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r7 = new com.huawei.common.widget.keyboard.CustomKeyBroadPop
            c2.d r2 = c2.d.a()
            r7.<init>(r6, r2)
            r6.d = r7
            D4.e r2 = new D4.e
            r2.<init>(r6, r1)
            r7.d = r2
            androidx.databinding.ViewDataBinding r2 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r2 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r2
            com.huawei.common.widget.input.CommonInputView r2 = r2.g
            android.widget.EditText r2 = r2.getEditText()
            r7.a(r6, r2, r1)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            D4.j r2 = new D4.j
            r2.<init>(r6)
            java.util.ArrayList r3 = r7.m
            if (r3 != 0) goto L_0x00f9
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r7.m = r3
        L_0x00f9:
            java.util.ArrayList r3 = r7.m
            boolean r3 = r3.contains(r2)
            if (r3 != 0) goto L_0x0106
            java.util.ArrayList r7 = r7.m
            r7.add(r2)
        L_0x0106:
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            android.widget.EditText r7 = r7.getEditText()
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText$a r2 = new com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText$a
            r2.<init>()
            android.text.InputFilter[] r3 = new android.text.InputFilter[r0]
            r3[r1] = r2
            r7.setFilters(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            android.widget.TextView r7 = r7.getTvTitle()
            android.graphics.Typeface r2 = android.graphics.Typeface.defaultFromStyle(r0)
            r7.setTypeface(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            android.widget.TextView r7 = r7.getTvTitle()
            android.content.res.Resources r2 = r6.getResources()
            int r3 = com.huawei.digitalpayment.topup.R$color.standard_black
            int r2 = r2.getColor(r3)
            r7.setTextColor(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.g
            android.widget.EditText r7 = r7.getEditText()
            D4.u r2 = new D4.u
            r2.<init>(r6)
            r7.addTextChangedListener(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.e
            android.widget.TextView r7 = r7.getTvTitle()
            android.graphics.Typeface r2 = android.graphics.Typeface.defaultFromStyle(r0)
            r7.setTypeface(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.e
            android.widget.TextView r7 = r7.getTvTitle()
            android.content.res.Resources r2 = r6.getResources()
            int r2 = r2.getColor(r3)
            r7.setTextColor(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.e
            android.widget.EditText r7 = r7.getEditText()
            r7.requestFocus()
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.e
            android.widget.EditText r7 = r7.getEditText()
            D4.k r2 = new D4.k
            r2.<init>(r6, r1)
            r4 = 200(0xc8, double:9.9E-322)
            r7.postDelayed(r2, r4)
            com.huawei.digitalpayment.payformerchant.adapter.RecentPayForMerchantAdapter r7 = new com.huawei.digitalpayment.payformerchant.adapter.RecentPayForMerchantAdapter
            r7.<init>()
            r6.f = r7
            D4.l r2 = new D4.l
            r2.<init>(r6)
            r7.a = r2
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.f
            android.widget.TextView r7 = r7.getTvTitle()
            android.graphics.Typeface r2 = android.graphics.Typeface.defaultFromStyle(r0)
            r7.setTypeface(r2)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.input.CommonInputView r7 = r7.f
            android.widget.TextView r7 = r7.getTvTitle()
            android.content.res.Resources r2 = r6.getResources()
            int r2 = r2.getColor(r3)
            r7.setTextColor(r2)
            com.huawei.common.widget.recyclerview.RecycleViewDivider r7 = new com.huawei.common.widget.recyclerview.RecycleViewDivider
            int r2 = com.huawei.digitalpayment.topup.R$color.colorDividerDark
            int r2 = androidx.core.content.ContextCompat.getColor(r6, r2)
            r7.<init>(r2, r0)
            r0 = 1114898432(0x42740000, float:61.0)
            int r0 = com.blankj.utilcode.util.v.a(r0)
            r7.c = r0
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r0 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r0
            com.huawei.common.widget.round.RoundRecyclerView r0 = r0.m
            r0.addItemDecoration(r7)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            com.huawei.common.widget.round.RoundRecyclerView r7 = r7.m
            com.huawei.digitalpayment.payformerchant.adapter.RecentPayForMerchantAdapter r0 = r6.f
            r7.setAdapter(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding r7 = (com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantBinding) r7
            android.widget.ImageView r7 = r7.h
            D4.m r0 = new D4.m
            r0.<init>(r6, r1)
            r7.setOnClickListener(r0)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel r7 = (com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel) r7
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.digitalpayment.payformerchant.bean.MerchantInfoResp>> r7 = r7.a
            D4.q r0 = new D4.q
            r0.<init>(r6, r1)
            r7.observe(r6, r0)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel r7 = (com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel) r7
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.http.BaseResp>> r7 = r7.b
            D4.r r0 = new D4.r
            r0.<init>(r6, r1)
            r7.observe(r6, r0)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel r7 = (com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel) r7
            androidx.lifecycle.MutableLiveData<V7.c<java.util.List<com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean>>> r7 = r7.c
            D4.f r0 = new D4.f
            r0.<init>(r6)
            r7.observe(r6, r0)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel r7 = (com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel) r7
            androidx.lifecycle.MutableLiveData<java.util.List<com.huawei.digitalpayment.payformerchant.bean.MerchantInfo>> r7 = r7.g
            D4.g r0 = new D4.g
            r0.<init>(r6, r1)
            r7.observe(r6, r0)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel r7 = (com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel) r7
            r7.getClass()
            com.huawei.digitalpayment.customer.httplib.repository.BannerRepository r0 = new com.huawei.digitalpayment.customer.httplib.repository.BannerRepository
            java.lang.String r2 = "Application Page"
            java.lang.String r3 = "Pay For Merchant"
            r0.<init>(r2, r3)
            r7.f = r0
            F4.b r2 = new F4.b
            r2.<init>(r7, r1)
            r0.sendRequest(r2)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel r7 = (com.huawei.digitalpayment.payformerchant.viewmodel.PayForMerchantViewModel) r7
            r7.getClass()
            F4.d r0 = new F4.d
            r0.<init>(r7)
            com.blankj.utilcode.util.A.d(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.payformerchant.activity.PayForMerchantActivity.onCreate(android.os.Bundle):void");
    }
}
