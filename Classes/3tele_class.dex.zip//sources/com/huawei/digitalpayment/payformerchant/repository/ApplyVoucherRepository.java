package com.huawei.digitalpayment.payformerchant.repository;

import com.huawei.http.BaseResp;
import com.huawei.http.b;

public class ApplyVoucherRepository extends b<BaseResp, BaseResp> {
    public final String getApiPath() {
        return "v1/applyBuyGoodsVoucher";
    }
}
