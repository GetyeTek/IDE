package com.huawei.digitalpayment.payformerchant.bean;

import com.huawei.http.BaseResp;

public class MerchantInfoResp extends BaseResp {
    private String publicName;
    private String shortCode;

    public String getPublicName() {
        return this.publicName;
    }

    public String getShortCode() {
        return this.shortCode;
    }

    public void setPublicName(String str) {
        this.publicName = str;
    }

    public void setShortCode(String str) {
        this.shortCode = str;
    }
}
