package com.huawei.digitalpayment.payformerchant.activity;

import D4.w;
import V7.e;
import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModel;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityPayForMerchantConfirmBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import i7.a;
import java.util.Map;
import o0.b;

public class PayForMerchantConfirmActivity extends DataBindingActivity<ActivityPayForMerchantConfirmBinding, ViewModel> {
    public static final /* synthetic */ int d = 0;

    public class a implements a.b<TransferResp> {
        public a() {
        }

        public final /* synthetic */ void a(int i, String str) {
        }

        public final /* synthetic */ void b(CheckoutResp checkoutResp) {
        }

        public final void onCancel() {
        }

        public final void onSuccess(Object obj) {
            Bundle bundle = new Bundle();
            int i = R$string.baselib_finished;
            DataBindingActivity dataBindingActivity = PayForMerchantConfirmActivity.this;
            bundle.putString("buttonText", dataBindingActivity.getString(i));
            bundle.putSerializable("TransferResp", (TransferResp) obj);
            b.d((Activity) null, "/basicUiModule/commonSuccess", bundle, (Map) null);
            dataBindingActivity.finish();
        }
    }

    public final int C0() {
        return R$layout.activity_pay_for_merchant_confirm;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.digitalpayment.payformerchant.activity.PayForMerchantConfirmActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        PayForMerchantConfirmActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.color_F4F4F4), false);
        e.a(this, getString(R$string.payment), R.layout.common_toolbar);
        this.b.a.setOnClickListener(new w(0, this, (CheckoutResp) getIntent().getSerializableExtra("checkoutResp")));
    }
}
