package com.huawei.digitalpayment.payformerchant.adapter;

import androidx.databinding.ViewDataBinding;
import com.huawei.digitalpayment.payformerchant.bean.MerchantInfo;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.databinding.TopupItemRecentPayForMerchantBinding;
import com.huawei.payment.mvvm.DataBindingAdapter;

public class RecentPayForMerchantAdapter extends DataBindingAdapter<MerchantInfo, TopupItemRecentPayForMerchantBinding> {
    public final int a() {
        return R$layout.topup_item_recent_pay_for_merchant;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        TopupItemRecentPayForMerchantBinding topupItemRecentPayForMerchantBinding = (TopupItemRecentPayForMerchantBinding) viewDataBinding;
        MerchantInfo merchantInfo = (MerchantInfo) obj;
        topupItemRecentPayForMerchantBinding.a.setText(merchantInfo.getMerchantId());
        topupItemRecentPayForMerchantBinding.b.setText(merchantInfo.getPublicName());
    }
}
