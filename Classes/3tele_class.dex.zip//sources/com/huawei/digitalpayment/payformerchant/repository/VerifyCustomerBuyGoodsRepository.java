package com.huawei.digitalpayment.payformerchant.repository;

import com.huawei.digitalpayment.payformerchant.bean.MerchantInfoResp;
import com.huawei.http.b;

public class VerifyCustomerBuyGoodsRepository extends b<MerchantInfoResp, MerchantInfoResp> {
    public final String getApiPath() {
        return "v1/verifyCustomerBuyGoods";
    }
}
