package com.huawei.digitalpayment.payformerchant.bean;

import java.io.Serializable;

public class MerchantInfo implements Serializable {
    private String merchantId;
    private String operatorId;
    private String publicName;

    public String getMerchantId() {
        return this.merchantId;
    }

    public String getOperatorId() {
        return this.operatorId;
    }

    public String getPublicName() {
        return this.publicName;
    }

    public void setMerchantId(String str) {
        this.merchantId = str;
    }

    public void setOperatorId(String str) {
        this.operatorId = str;
    }

    public void setPublicName(String str) {
        this.publicName = str;
    }
}
