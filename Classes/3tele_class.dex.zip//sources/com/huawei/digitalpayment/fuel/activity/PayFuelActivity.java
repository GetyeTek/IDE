package com.huawei.digitalpayment.fuel.activity;

import L3.a;
import V7.c;
import android.os.Bundle;
import android.view.ViewPropertyAnimator;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import com.huawei.bank.transfer.activity.j;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.fuel.repository.FuelPaymentRepository;
import com.huawei.digitalpayment.fuel.viewmodel.FuelPaymentViewModel;
import com.huawei.http.b;
import com.huawei.module_checkout.requestpin.BaseRequestPinActivity;

public class PayFuelActivity extends BaseRequestPinActivity {
    public static final /* synthetic */ int k = 0;
    public ViewPropertyAnimator g;
    public FuelPaymentViewModel h;
    public CheckoutResp i;
    public String j;

    public final void D0(String str) {
        FuelPaymentViewModel fuelPaymentViewModel = this.h;
        String prepayId = this.i.getPrepayId();
        String str2 = this.j;
        fuelPaymentViewModel.a.setValue(c.c());
        FuelPaymentRepository fuelPaymentRepository = fuelPaymentViewModel.b;
        if (fuelPaymentRepository != null) {
            fuelPaymentRepository.cancel();
        }
        b bVar = new b();
        bVar.addParams("prepayId", prepayId);
        bVar.addParams("pinVersion", a.b.getPinKeyVersion());
        bVar.addParams("initiatorPin", a.g(str));
        bVar.addParams("businessType", str2);
        fuelPaymentViewModel.b = bVar;
        bVar.sendRequest(new B6.a(fuelPaymentViewModel, 4));
    }

    public final void K() {
        ViewPropertyAnimator viewPropertyAnimator = this.g;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
        this.a.b.setAlpha(0.0f);
        finish();
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [androidx.lifecycle.LifecycleOwner, java.lang.Object, androidx.lifecycle.ViewModelStoreOwner, com.huawei.digitalpayment.fuel.activity.PayFuelActivity, android.app.Activity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        PayFuelActivity.super.onCreate(bundle);
        this.i = (CheckoutResp) getIntent().getSerializableExtra("data");
        this.j = getIntent().getStringExtra("businessType");
        FuelPaymentViewModel fuelPaymentViewModel = new ViewModelProvider(this).get(FuelPaymentViewModel.class);
        this.h = fuelPaymentViewModel;
        fuelPaymentViewModel.a.observe(this, new j(this, 2));
        ViewPropertyAnimator animate = this.a.b.animate();
        this.g = animate;
        animate.alpha(1.0f);
        this.g.setDuration(300);
        this.g.setStartDelay(200);
        this.g.start();
    }
}
