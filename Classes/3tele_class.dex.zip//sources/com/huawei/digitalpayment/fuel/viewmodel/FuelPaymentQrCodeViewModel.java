package com.huawei.digitalpayment.fuel.viewmodel;

import O6.e;
import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.fuel.resp.FuelPaymentQrCodeEntity;
import java.util.Iterator;
import java.util.List;
import v4.d;
import y4.a;
import y4.i;

public class FuelPaymentQrCodeViewModel extends BaseViewModel {
    public final i g = new i();
    public final MutableLiveData<FuelPaymentQrCodeEntity> h = new MutableLiveData<>();
    public final MutableLiveData<BaseResp> i = new MutableLiveData<>();
    public final MutableLiveData<CheckoutResp> j = new MutableLiveData<>();
    public List<FuelPaymentQrCodeEntity> k;

    public static void d(FuelPaymentQrCodeViewModel fuelPaymentQrCodeViewModel, String str) {
        List<FuelPaymentQrCodeEntity> list = fuelPaymentQrCodeViewModel.k;
        if (list != null && list.size() != 0) {
            for (FuelPaymentQrCodeEntity next : fuelPaymentQrCodeViewModel.k) {
                if (next.getCodeId().equals(str)) {
                    fuelPaymentQrCodeViewModel.k.remove(next);
                    return;
                }
            }
        }
    }

    public static void e(String str, String str2) {
        List list = (List) a.C0005a.a.b.get(str);
        Iterator it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            FuelPaymentQrCodeEntity fuelPaymentQrCodeEntity = (FuelPaymentQrCodeEntity) it.next();
            if (fuelPaymentQrCodeEntity.getCodeId().equals(str2)) {
                list.remove(fuelPaymentQrCodeEntity);
                break;
            }
        }
        d.b.execute(new e(str2, 4));
    }
}
