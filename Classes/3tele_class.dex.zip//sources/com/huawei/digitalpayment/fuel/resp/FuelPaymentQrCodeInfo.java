package com.huawei.digitalpayment.fuel.resp;

import android.content.Context;
import android.text.TextUtils;
import com.huawei.common.display.DisplayItem;
import com.huawei.digitalpayment.topup.R$string;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FuelPaymentQrCodeInfo implements Serializable {
    public static final String TYPE_FUEL_BARREL = "FuelBarrel";
    public static final String TYPE_FUEL_COUPON = "FuelCoupon";
    public static final String TYPE_FUEL_KEROSENE = "Kerosene";
    public static final String TYPE_FUEL_PAYMENT_KEROSENE = "FuelPaymentKerosene";
    public static final String TYPE_FUEL_PAYMENT_WITHOUT_SUBSIDY = "FuelPaymentWithoutSubsidy";
    private String amount;
    private String barrel;
    private String company;
    private String fuelOrigConversationID;
    private String fuelPaymentQrCode;
    private String fuelType;
    private String lastKilometer;
    private String letterGivenBy;
    private String literAmount;
    private String operatorId;
    private String organizationName;
    private String plateNumber;
    private String qrCode;
    private String reference;
    private String shortCode;
    private String tinNumber;

    public String getAmount() {
        return this.amount;
    }

    public String getBarrel() {
        return this.barrel;
    }

    public String getCompany() {
        return this.company;
    }

    public List<DisplayItem> getDisplayItem(Context context) {
        ArrayList arrayList = new ArrayList();
        if (TYPE_FUEL_BARREL.equals(this.fuelPaymentQrCode)) {
            arrayList.add(0, new DisplayItem(context.getString(R$string.liter_amount), this.literAmount));
        }
        arrayList.add(new DisplayItem(context.getString(R$string.fuel_type), this.fuelType));
        if (TYPE_FUEL_BARREL.equals(this.fuelPaymentQrCode)) {
            arrayList.add(new DisplayItem(context.getString(R$string.reference), this.reference));
            arrayList.add(new DisplayItem(context.getString(R$string.company), this.company));
            arrayList.add(new DisplayItem(context.getString(R$string.letter_given_by), this.letterGivenBy));
            arrayList.add(new DisplayItem(context.getString(R$string.tin_number), this.tinNumber));
        }
        if (!TYPE_FUEL_KEROSENE.equals(this.fuelPaymentQrCode) && !TextUtils.isEmpty(this.plateNumber)) {
            arrayList.add(new DisplayItem(context.getString(R$string.plate_number), this.plateNumber));
        }
        if ("FuelCoupon".equals(this.fuelPaymentQrCode)) {
            arrayList.add(new DisplayItem(context.getString(R$string.last_kilometer), this.lastKilometer));
        }
        arrayList.add(new DisplayItem(context.getString(R$string.app_short_code), this.shortCode));
        arrayList.add(new DisplayItem(context.getString(R$string.operator_id), this.operatorId));
        arrayList.add(new DisplayItem(context.getString(R$string.organization_name), this.organizationName));
        return arrayList;
    }

    public String getFuelOrigConversationID() {
        return this.fuelOrigConversationID;
    }

    public String getFuelPaymentQrCode() {
        return this.fuelPaymentQrCode;
    }

    public String getFuelType() {
        return this.fuelType;
    }

    public String getLastKilometer() {
        return this.lastKilometer;
    }

    public String getLetterGivenBy() {
        return this.letterGivenBy;
    }

    public String getLiterAmount() {
        return this.literAmount;
    }

    public String getOperatorId() {
        return this.operatorId;
    }

    public String getOrganizationName() {
        return this.organizationName;
    }

    public String getPlateNumber() {
        return this.plateNumber;
    }

    public String getQrCode() {
        return this.qrCode;
    }

    public String getReference() {
        return this.reference;
    }

    public String getShortCode() {
        return this.shortCode;
    }

    public String getTinNumber() {
        return this.tinNumber;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setBarrel(String str) {
        this.barrel = str;
    }

    public void setCompany(String str) {
        this.company = str;
    }

    public void setFuelOrigConversationID(String str) {
        this.fuelOrigConversationID = str;
    }

    public void setFuelPaymentQrCode(String str) {
        this.fuelPaymentQrCode = str;
    }

    public void setFuelType(String str) {
        this.fuelType = str;
    }

    public void setLastKilometer(String str) {
        this.lastKilometer = str;
    }

    public void setLetterGivenBy(String str) {
        this.letterGivenBy = str;
    }

    public void setLiterAmount(String str) {
        this.literAmount = str;
    }

    public void setOperatorId(String str) {
        this.operatorId = str;
    }

    public void setOrganizationName(String str) {
        this.organizationName = str;
    }

    public void setPlateNumber(String str) {
        this.plateNumber = str;
    }

    public void setQrCode(String str) {
        this.qrCode = str;
    }

    public void setReference(String str) {
        this.reference = str;
    }

    public void setShortCode(String str) {
        this.shortCode = str;
    }

    public void setTinNumber(String str) {
        this.tinNumber = str;
    }
}
