package com.huawei.digitalpayment.fuel.activity;

import B7.b;
import B7.c;
import F0.h;
import L4.e;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.l;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.dialog.SimpleSelectDialog;
import com.huawei.digitalpayment.customer.bean.user.SimpleSelectItem;
import com.huawei.digitalpayment.customer.httplib.response.VehicleBean;
import com.huawei.digitalpayment.customer.viewlib.view.dialog.SelectDialog;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityNewOrEditVehicleBinding;
import com.huawei.digitalpayment.topup.widget.PlateInputView;
import com.huawei.digitalpayment.topup.widget.TypeSelectView;
import java.util.ArrayList;
import java.util.List;
import x4.k;
import x4.m;
import x4.n;

@Route(path = "/topUpModule/fuelPaymentAddOrEditVehicle")
public class NewOrEditVehicleActivity extends AppCompatActivity {
    public static final /* synthetic */ int f = 0;
    public SimpleSelectDialog a;
    public ActivityNewOrEditVehicleBinding b;
    public VehicleBean c;
    public boolean d;
    public final a e = new a(this);

    public class a extends O2.a {
        public final /* synthetic */ NewOrEditVehicleActivity b;

        public a(NewOrEditVehicleActivity newOrEditVehicleActivity) {
            super(0);
            this.b = newOrEditVehicleActivity;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:7:0x003f, code lost:
            if (android.text.TextUtils.isEmpty(r4.b.d.getText()) == false) goto L_0x0043;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void afterTextChanged(android.text.Editable r4) {
            /*
                r3 = this;
                com.huawei.digitalpayment.fuel.activity.NewOrEditVehicleActivity r4 = r3.b
                com.huawei.digitalpayment.topup.databinding.ActivityNewOrEditVehicleBinding r0 = r4.b
                android.widget.Button r1 = r0.b
                com.huawei.digitalpayment.topup.widget.PlateInputView r0 = r0.c
                android.widget.TextView r0 = r0.getTvCarCode()
                java.lang.CharSequence r0 = r0.getText()
                boolean r0 = android.text.TextUtils.isEmpty(r0)
                if (r0 != 0) goto L_0x0042
                com.huawei.digitalpayment.topup.databinding.ActivityNewOrEditVehicleBinding r0 = r4.b
                com.huawei.digitalpayment.topup.widget.PlateInputView r0 = r0.c
                java.lang.String r0 = r0.getText()
                boolean r0 = android.text.TextUtils.isEmpty(r0)
                if (r0 != 0) goto L_0x0042
                com.huawei.digitalpayment.topup.databinding.ActivityNewOrEditVehicleBinding r0 = r4.b
                com.huawei.digitalpayment.topup.widget.PlateInputView r0 = r0.c
                java.lang.String r0 = r0.getText()
                int r0 = r0.length()
                r2 = 1
                if (r0 <= r2) goto L_0x0042
                com.huawei.digitalpayment.topup.databinding.ActivityNewOrEditVehicleBinding r4 = r4.b
                com.huawei.digitalpayment.topup.widget.TypeSelectView r4 = r4.d
                java.lang.String r4 = r4.getText()
                boolean r4 = android.text.TextUtils.isEmpty(r4)
                if (r4 != 0) goto L_0x0042
                goto L_0x0043
            L_0x0042:
                r2 = 0
            L_0x0043:
                r1.setEnabled(r2)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.fuel.activity.NewOrEditVehicleActivity.a.afterTextChanged(android.text.Editable):void");
        }
    }

    public final void C0(List<String> list, List<String> list2, TextView textView, String str) {
        l.a(this);
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            arrayList.add(new SimpleSelectItem(list.get(i), list2.get(i)));
        }
        BaseDialog selectDialog = new SelectDialog(str, arrayList, new m(this, textView));
        this.a = selectDialog;
        selectDialog.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.digitalpayment.fuel.activity.NewOrEditVehicleActivity, android.app.Activity] */
    public final void finish() {
        NewOrEditVehicleActivity.super.finish();
        overridePendingTransition(0, 0);
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [android.content.Context, com.huawei.digitalpayment.fuel.activity.NewOrEditVehicleActivity, java.lang.Object, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        NewOrEditVehicleActivity.super.onCreate(bundle);
        overridePendingTransition(0, 0);
        View inflate = getLayoutInflater().inflate(R$layout.activity_new_or_edit_vehicle, (ViewGroup) null, false);
        int i = R$id.btn_confirm;
        Button button = (Button) ViewBindings.findChildViewById(inflate, i);
        if (button != null) {
            i = R$id.inputPlateNumber;
            PlateInputView plateInputView = (PlateInputView) ViewBindings.findChildViewById(inflate, i);
            if (plateInputView != null) {
                i = R$id.input_select_fuel_type;
                TypeSelectView typeSelectView = (TypeSelectView) ViewBindings.findChildViewById(inflate, i);
                if (typeSelectView != null) {
                    i = R$id.ll_continue;
                    LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(inflate, i);
                    if (linearLayout != null) {
                        i = R$id.ll_space;
                        LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(inflate, i);
                        if (linearLayout2 != null) {
                            i = R$id.tv_title;
                            TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i);
                            if (textView != null) {
                                i = R$id.view_divider;
                                if (ViewBindings.findChildViewById(inflate, i) != null) {
                                    LinearLayout linearLayout3 = (LinearLayout) inflate;
                                    this.b = new ActivityNewOrEditVehicleBinding(linearLayout3, button, plateInputView, typeSelectView, linearLayout, linearLayout2, textView);
                                    setContentView(linearLayout3);
                                    f.e(this, 0, false);
                                    f.f(this, false);
                                    e.a.getClass();
                                    List list = (List) e.a.c.getValue();
                                    this.b.d.e(new DisplayItem("1", getString(R$string.benzene)), new DisplayItem("2", getString(R$string.diesel)));
                                    this.b.c.setError((String) null);
                                    TextView tvCarCode = this.b.c.getTvCarCode();
                                    a aVar = this.e;
                                    tvCarCode.addTextChangedListener(aVar);
                                    this.b.c.getEditText().addTextChangedListener(aVar);
                                    this.b.d.getEditText().addTextChangedListener(aVar);
                                    this.b.c.getEtInput().addTextChangedListener(new n(this));
                                    this.b.f.setOnClickListener(new h(this, 7));
                                    PlateInputView plateInputView2 = this.b.c;
                                    plateInputView2.getLlCarCode().setOnClickListener(new k(this, plateInputView2));
                                    plateInputView2.getLlRegion().setOnClickListener(new x4.l(this, plateInputView2));
                                    plateInputView2.getEditText().setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
                                    plateInputView2.getEditText().setKeyListener(new DigitsKeyListener());
                                    this.b.b.setOnClickListener(new b(this, 4));
                                    this.b.e.setOnClickListener(new c(this, 9));
                                    this.d = getIntent().getBooleanExtra("isAdd", false);
                                    this.c = (VehicleBean) getIntent().getSerializableExtra("vehicleBean");
                                    if (this.d) {
                                        this.b.g.setText(getString(R$string.add_new_vehicle));
                                        this.b.e.setVisibility(0);
                                        return;
                                    }
                                    this.b.g.setText(getString(R$string.edit_vehicle));
                                    this.b.e.setVisibility(8);
                                    String[] split = this.c.getPlateNumber().split("-");
                                    if (split.length == 3) {
                                        this.b.c.getTvCarCode().setText(split[0]);
                                        this.b.c.getTvRegion().setText(split[1]);
                                        this.b.c.getEditText().setText(split[2]);
                                    } else if (split.length == 2) {
                                        this.b.c.getTvCarCode().setText(split[0]);
                                        this.b.c.getEditText().setText(split[1]);
                                    }
                                    if ("1".equals(this.c.getFuelType())) {
                                        this.b.d.c();
                                        return;
                                    } else {
                                        this.b.d.d();
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }
}
