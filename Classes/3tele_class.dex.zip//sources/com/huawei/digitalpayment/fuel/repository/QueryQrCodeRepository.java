package com.huawei.digitalpayment.fuel.repository;

import com.huawei.digitalpayment.fuel.resp.QueryAuthNoticeResp;
import com.huawei.http.b;

public class QueryQrCodeRepository extends b<QueryAuthNoticeResp, QueryAuthNoticeResp> {
    public final String getApiPath() {
        return "v1/queryAuthNotice";
    }
}
