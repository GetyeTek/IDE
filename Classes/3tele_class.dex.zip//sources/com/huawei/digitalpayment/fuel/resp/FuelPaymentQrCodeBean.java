package com.huawei.digitalpayment.fuel.resp;

import java.io.Serializable;

public class FuelPaymentQrCodeBean implements Serializable {
    public static final String TYPE_FUEL_COUPON = "FuelCoupon";
    public static final String TYPE_FUEL_PAYMENT_WITHOUT_SUBSIDY = "FuelPaymentWithoutSubsidy";
    private String CodeId;
    private String amount;
    private String businessType;
    private String fuelType;
    private String lastKilometer;
    private String plateNumber;
    private String qrCode;

    public String getAmount() {
        return this.amount;
    }

    public String getBusinessType() {
        return this.businessType;
    }

    public String getCodeId() {
        return this.CodeId;
    }

    public String getFuelType() {
        return this.fuelType;
    }

    public String getLastKilometer() {
        return this.lastKilometer;
    }

    public String getPlateNumber() {
        return this.plateNumber;
    }

    public String getQrCode() {
        return this.qrCode;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setBusinessType(String str) {
        this.businessType = str;
    }

    public void setCodeId(String str) {
        this.CodeId = str;
    }

    public void setFuelType(String str) {
        this.fuelType = str;
    }

    public void setLastKilometer(String str) {
        this.lastKilometer = str;
    }

    public void setPlateNumber(String str) {
        this.plateNumber = str;
    }

    public void setQrCode(String str) {
        this.qrCode = str;
    }
}
