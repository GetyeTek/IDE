package com.huawei.digitalpayment.fuel.viewmodel;

import androidx.lifecycle.MutableLiveData;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.httplib.response.VehicleResp;
import y4.e;

public class FuelPaymentVehicleMangeViewModel extends BaseViewModel {
    public final e g = new e();
    public final MutableLiveData<VehicleResp> h = new MutableLiveData<>();
    public final MutableLiveData<BaseResp> i = new MutableLiveData<>();
    public final MutableLiveData<BaseResp> j = new MutableLiveData<>();
    public final MutableLiveData<BaseResp> k = new MutableLiveData<>();
}
