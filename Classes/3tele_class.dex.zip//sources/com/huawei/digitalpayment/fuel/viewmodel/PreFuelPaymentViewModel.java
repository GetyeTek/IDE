package com.huawei.digitalpayment.fuel.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.fuel.repository.PreFuelPaymentRepository;

public class PreFuelPaymentViewModel extends ViewModel {
    public final MutableLiveData<c<CheckoutResp>> a = new MutableLiveData<>();
    public PreFuelPaymentRepository b;

    public final void onCleared() {
        PreFuelPaymentViewModel.super.onCleared();
        PreFuelPaymentRepository preFuelPaymentRepository = this.b;
        if (preFuelPaymentRepository != null) {
            preFuelPaymentRepository.cancel();
        }
    }
}
