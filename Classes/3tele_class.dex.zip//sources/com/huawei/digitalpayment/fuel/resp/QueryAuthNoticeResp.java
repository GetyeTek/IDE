package com.huawei.digitalpayment.fuel.resp;

import com.huawei.digitalpayment.customer.baselib.http.BaseResp;

public class QueryAuthNoticeResp extends BaseResp {
    private String appId;
    private String codeAlias;
    private boolean exist;
    private String expire;
    private String merchCode;
    private String payType;
    private String prepayId;
    private String tradeType;

    public String getAppId() {
        return this.appId;
    }

    public String getCodeAlias() {
        return this.codeAlias;
    }

    public String getExpire() {
        return this.expire;
    }

    public String getMerchCode() {
        return this.merchCode;
    }

    public String getPayType() {
        return this.payType;
    }

    public String getPrepayId() {
        return this.prepayId;
    }

    public String getTradeType() {
        return this.tradeType;
    }

    public boolean isExist() {
        return this.exist;
    }

    public void setAppId(String str) {
        this.appId = str;
    }

    public void setCodeAlias(String str) {
        this.codeAlias = str;
    }

    public void setExist(boolean z) {
        this.exist = z;
    }

    public void setExpire(String str) {
        this.expire = str;
    }

    public void setMerchCode(String str) {
        this.merchCode = str;
    }

    public void setPayType(String str) {
        this.payType = str;
    }

    public void setPrepayId(String str) {
        this.prepayId = str;
    }

    public void setTradeType(String str) {
        this.tradeType = str;
    }
}
