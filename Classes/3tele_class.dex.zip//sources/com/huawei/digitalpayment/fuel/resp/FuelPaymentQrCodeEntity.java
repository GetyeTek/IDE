package com.huawei.digitalpayment.fuel.resp;

import Zb.b;
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.httplib.response.ApplyQrCodeBean;
import com.huawei.digitalpayment.customer.httplib.response.ApplyQrCodeResp;

@Entity
public class FuelPaymentQrCodeEntity extends BaseResp {
    private String barCode;
    @NonNull
    @PrimaryKey
    private String codeId;
    private String effectAt;
    private String invalidAt;
    private String phoneNumber;
    @TypeConverters({b.class})
    private int[] pollFreq;
    private String qrCode;
    private String qrType;
    private String refreshFreq;
    private String serverTime;

    public FuelPaymentQrCodeEntity() {
    }

    public String getBarCode() {
        return this.barCode;
    }

    @NonNull
    public String getCodeId() {
        return this.codeId;
    }

    public String getEffectAt() {
        return this.effectAt;
    }

    public String getInvalidAt() {
        return this.invalidAt;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public int[] getPollFreq() {
        return this.pollFreq;
    }

    public String getQrCode() {
        return this.qrCode;
    }

    public String getQrType() {
        return this.qrType;
    }

    public String getRefreshFreq() {
        return this.refreshFreq;
    }

    public String getServerTime() {
        return this.serverTime;
    }

    public void setBarCode(String str) {
        this.barCode = str;
    }

    public void setCodeId(@NonNull String str) {
        this.codeId = str;
    }

    public void setEffectAt(String str) {
        this.effectAt = str;
    }

    public void setInvalidAt(String str) {
        this.invalidAt = str;
    }

    public void setPhoneNumber(String str) {
        this.phoneNumber = str;
    }

    public void setPollFreq(int[] iArr) {
        this.pollFreq = iArr;
    }

    public void setQrCode(String str) {
        this.qrCode = str;
    }

    public void setQrType(String str) {
        this.qrType = str;
    }

    public void setRefreshFreq(String str) {
        this.refreshFreq = str;
    }

    public void setServerTime(String str) {
        this.serverTime = str;
    }

    public FuelPaymentQrCodeEntity(ApplyQrCodeBean applyQrCodeBean, ApplyQrCodeResp applyQrCodeResp, String str) {
        this.serverTime = applyQrCodeResp.getServerTime();
        this.refreshFreq = applyQrCodeResp.getServerTime();
        this.pollFreq = applyQrCodeResp.getPollFreq();
        this.effectAt = applyQrCodeResp.getEffectAt();
        this.invalidAt = applyQrCodeResp.getInvalidAt();
        this.qrType = applyQrCodeBean.getQrType();
        this.codeId = applyQrCodeBean.getCodeId();
        this.barCode = applyQrCodeBean.getBarCode();
        this.qrCode = applyQrCodeBean.getQrCode();
        this.phoneNumber = str;
    }
}
