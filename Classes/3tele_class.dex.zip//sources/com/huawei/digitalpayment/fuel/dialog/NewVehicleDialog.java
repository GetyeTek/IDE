package com.huawei.digitalpayment.fuel.dialog;

import H1.c;
import android.app.Dialog;
import android.view.Window;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$style;

public class NewVehicleDialog extends BaseDialog {
    public final void onStart() {
        Window window;
        NewVehicleDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            window.setBackgroundDrawableResource(17170445);
            c.b(window, R$style.BottomAnimation, dialog, true, true);
        }
    }

    public final int v0() {
        return R$layout.new_vehicle_dialog_layout;
    }
}
