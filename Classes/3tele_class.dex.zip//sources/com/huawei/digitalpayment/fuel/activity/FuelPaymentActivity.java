package com.huawei.digitalpayment.fuel.activity;

import K6.b;
import V7.e;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.display.DisplayAdapter;
import com.huawei.digitalpayment.fuel.resp.FuelPaymentQrCodeInfo;
import com.huawei.digitalpayment.fuel.viewmodel.PreFuelPaymentViewModel;
import com.huawei.digitalpayment.schedule.activity.c;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentBinding;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import k3.C0033a;

@Route(path = "/topUpModule/fuelWithoutSubsidy")
public class FuelPaymentActivity extends DataBindingActivity<ActivityFuelPaymentBinding, PreFuelPaymentViewModel> {
    public static final /* synthetic */ int e = 0;
    public FuelPaymentQrCodeInfo d;

    public final int C0() {
        return R$layout.activity_fuel_payment;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.digitalpayment.fuel.activity.FuelPaymentActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FuelPaymentActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.payment), R.layout.common_toolbar);
        FuelPaymentQrCodeInfo fuelPaymentQrCodeInfo = (FuelPaymentQrCodeInfo) getIntent().getSerializableExtra("fuelPaymentQrCodeInfo");
        this.d = fuelPaymentQrCodeInfo;
        if (fuelPaymentQrCodeInfo == null) {
            FuelPaymentQrCodeInfo fuelPaymentQrCodeInfo2 = new FuelPaymentQrCodeInfo();
            this.d = fuelPaymentQrCodeInfo2;
            fuelPaymentQrCodeInfo2.setQrCode(getIntent().getStringExtra("qrCode"));
            this.d.setOrganizationName(getIntent().getStringExtra("OrganizationName"));
            this.d.setAmount(getIntent().getStringExtra("amount"));
            this.d.setFuelOrigConversationID(getIntent().getStringExtra("FuelOrigConversationID"));
            this.d.setOperatorId(getIntent().getStringExtra("operatorId"));
            this.d.setShortCode(getIntent().getStringExtra("shortCode"));
            this.d.setFuelType(getIntent().getStringExtra("FuelType"));
            this.d.setLastKilometer(getIntent().getStringExtra("lastKilometer"));
            this.d.setLetterGivenBy(getIntent().getStringExtra("letterGivenBy"));
            this.d.setPlateNumber(getIntent().getStringExtra("plateNumber"));
            this.d.setFuelPaymentQrCode(getIntent().getStringExtra("fuelPaymentQrCode"));
            if (FuelPaymentQrCodeInfo.TYPE_FUEL_BARREL.equals(this.d.getFuelPaymentQrCode())) {
                this.d.setReference(getIntent().getStringExtra("reference"));
                this.d.setBarrel(getIntent().getStringExtra("barrel"));
                this.d.setCompany(getIntent().getStringExtra("company"));
            }
        }
        this.b.b.setLayoutManager(new LinearLayoutManager(this));
        DisplayAdapter displayAdapter = new DisplayAdapter();
        this.b.b.setAdapter(displayAdapter);
        this.b.a.setOnClickListener(new b(this, 4));
        this.b.c.setText(C0033a.e.b());
        this.b.d.setText(this.d.getAmount());
        displayAdapter.setNewData(this.d.getDisplayItem(this));
        this.c.a.observe(this, new c(this, 4));
    }
}
