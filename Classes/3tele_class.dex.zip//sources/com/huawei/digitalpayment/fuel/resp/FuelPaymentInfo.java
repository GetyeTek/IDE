package com.huawei.digitalpayment.fuel.resp;

import com.huawei.common.display.DisplayItem;
import com.huawei.http.BaseResp;
import java.util.List;

public class FuelPaymentInfo extends BaseResp {
    private String amount;
    private List<DisplayItem> displayItems;

    public String getAmount() {
        return this.amount;
    }

    public List<DisplayItem> getDisplayItems() {
        return this.displayItems;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setDisplayItems(List<DisplayItem> list) {
        this.displayItems = list;
    }
}
