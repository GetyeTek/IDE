package com.huawei.digitalpayment.fuel.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.digitalpayment.fuel.repository.FuelPaymentRepository;

public class FuelPaymentViewModel extends ViewModel {
    public final MutableLiveData<c<TransferResp>> a = new MutableLiveData<>();
    public FuelPaymentRepository b;

    public final void onCleared() {
        FuelPaymentViewModel.super.onCleared();
        FuelPaymentRepository fuelPaymentRepository = this.b;
        if (fuelPaymentRepository != null) {
            fuelPaymentRepository.cancel();
        }
    }
}
