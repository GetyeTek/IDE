package com.huawei.digitalpayment.fuel.activity;

import W2.g;
import W2.q;
import android.text.InputFilter;
import android.text.TextUtils;
import android.widget.Button;
import androidx.camera.view.e;
import c2.d;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.httplib.response.VehicleBean;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentAmountBinding;
import g4.h;
import i4.C0030a;
import java.util.ArrayList;
import k3.C0033a;
import t4.a;
import x4.b;
import x4.c;
import x4.f;

@Route(path = "/topUpModule/fuelPaymentVehicleAmount")
public class FuelPaymentAmountActivity extends BaseTitleActivity {
    public static final /* synthetic */ int l = 0;
    public ActivityFuelPaymentAmountBinding i;
    public CustomKeyBroadPop j;
    public VehicleBean k;

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void U0(com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity r1, boolean r2, int r3) {
        /*
            com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentAmountBinding r0 = r1.i
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r0.f
            android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r0 = (android.view.ViewGroup.MarginLayoutParams) r0
            if (r2 == 0) goto L_0x0017
            int r2 = r0.bottomMargin
            float r3 = (float) r3
            int r3 = R9.h.a(r1, r3)
            int r3 = r3 + r2
            r0.bottomMargin = r3
            goto L_0x0021
        L_0x0017:
            int r2 = r0.bottomMargin
            float r3 = (float) r3
            int r3 = R9.h.a(r1, r3)
            int r2 = r2 - r3
            r0.bottomMargin = r2
        L_0x0021:
            com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentAmountBinding r1 = r1.i
            com.huawei.common.widget.round.RoundConstraintLayout r1 = r1.f
            r1.setLayoutParams(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity.U0(com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity, boolean, int):void");
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void V0(com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity r1, boolean r2, int r3) {
        /*
            com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentAmountBinding r0 = r1.i
            androidx.constraintlayout.widget.ConstraintLayout r0 = r0.a
            android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r0 = (android.view.ViewGroup.MarginLayoutParams) r0
            if (r2 == 0) goto L_0x0017
            int r2 = r0.topMargin
            float r3 = (float) r3
            int r3 = R9.h.a(r1, r3)
            int r2 = r2 - r3
            r0.topMargin = r2
            goto L_0x0021
        L_0x0017:
            int r2 = r0.topMargin
            float r3 = (float) r3
            int r3 = R9.h.a(r1, r3)
            int r3 = r3 + r2
            r0.topMargin = r3
        L_0x0021:
            com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentAmountBinding r1 = r1.i
            androidx.constraintlayout.widget.ConstraintLayout r1 = r1.a
            r1.setLayoutParams(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity.V0(com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity, boolean, int):void");
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.view.View] */
    /* JADX WARNING: type inference failed for: r0v4, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText] */
    /* JADX WARNING: type inference failed for: r0v9, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText] */
    public static void W0(FuelPaymentAmountActivity fuelPaymentAmountActivity) {
        boolean z = false;
        if (fuelPaymentAmountActivity.i.d.getVisibility() == 0) {
            ActivityFuelPaymentAmountBinding activityFuelPaymentAmountBinding = fuelPaymentAmountActivity.i;
            Button button = activityFuelPaymentAmountBinding.b;
            if (g.a(activityFuelPaymentAmountBinding.c.getEditableText().toString()) && !TextUtils.isEmpty(fuelPaymentAmountActivity.i.e.getText()) && !TextUtils.isEmpty(fuelPaymentAmountActivity.i.d.getText().toString())) {
                z = true;
            }
            button.setEnabled(z);
            return;
        }
        ActivityFuelPaymentAmountBinding activityFuelPaymentAmountBinding2 = fuelPaymentAmountActivity.i;
        Button button2 = activityFuelPaymentAmountBinding2.b;
        if (g.a(activityFuelPaymentAmountBinding2.c.getEditableText().toString()) && !TextUtils.isEmpty(fuelPaymentAmountActivity.i.e.getText())) {
            z = true;
        }
        button2.setEnabled(z);
    }

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r3v3, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.widget.EditText] */
    /* JADX WARNING: type inference failed for: r2v4, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText] */
    /* JADX WARNING: type inference failed for: r2v6, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.view.View] */
    /* JADX WARNING: type inference failed for: r3v22, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText] */
    /* JADX WARNING: type inference failed for: r3v24, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.view.View] */
    /* JADX WARNING: type inference failed for: r2v19, types: [android.widget.TextView, com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText] */
    /* JADX WARNING: type inference failed for: r0v4, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.view.View] */
    /* JADX WARNING: type inference failed for: r0v6, types: [com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText, android.view.View] */
    public final void G0() {
        String str;
        super.G0();
        N0(getString(R$string.fuel_payment));
        CustomKeyBroadPop customKeyBroadPop = new CustomKeyBroadPop(this, new d(4, d.b(getString(R$string.ok))));
        this.j = customKeyBroadPop;
        customKeyBroadPop.d = new e(this);
        customKeyBroadPop.a(this, this.i.c, true);
        this.i.c.addTextChangedListener(new x4.e(this));
        this.i.c.setOnClickListener(new h(this, 3));
        this.j.e = new f(this);
        q.a(this, new x4.g(this));
        VehicleBean vehicleBean = (VehicleBean) getIntent().getSerializableExtra("vehicleBean");
        this.k = vehicleBean;
        this.i.h.setText(vehicleBean.getPlateNumber());
        if ("1".equals(this.k.getFuelType())) {
            str = getString(R$string.benzene);
        } else {
            str = getString(R$string.diesel);
        }
        this.i.g.setText(str);
        ArrayList arrayList = new ArrayList();
        arrayList.add(getString(R$string.without_subsidy));
        arrayList.add(getString(R$string.organization_fuel_payment));
        this.i.e.e(new DisplayItem((String) arrayList.get(0), (String) arrayList.get(0)), new DisplayItem((String) arrayList.get(1), (String) arrayList.get(1)));
        this.i.e.getEditText().addTextChangedListener(new c(this, arrayList));
        this.i.d.addTextChangedListener(new x4.d(this));
        this.i.d.setOnFocusChangeListener(new b(this));
        this.i.e.c();
        this.i.b.setOnClickListener(new C0030a(2, this, arrayList));
        ? r2 = this.i.c;
        a aVar = new a();
        aVar.a = 50000.0d;
        r2.setFilters(new InputFilter[]{aVar});
        InputItemEditText inputItemEditText = this.i.c;
        inputItemEditText.setCurrency("(" + C0033a.e.b() + ")");
        this.i.c.requestFocus();
        this.i.c.setFocusableInTouchMode(true);
        this.i.d.setCurrency(getString(R$string.km));
    }

    /* JADX WARNING: type inference failed for: r12v0, types: [com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004a, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.rl_container;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r12 = this;
            android.view.LayoutInflater r0 = r12.getLayoutInflater()
            int r1 = com.huawei.digitalpayment.topup.R$layout.activity_fuel_payment_amount
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.digitalpayment.topup.R$id.btn_confirm
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r5 = r2
            android.widget.Button r5 = (android.widget.Button) r5
            if (r5 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.et_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r6 = r2
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r6 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r6
            if (r6 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.et_km
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r7 = r2
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r7 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r7
            if (r7 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.input_select_fuel_type
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r8 = r2
            com.huawei.digitalpayment.topup.widget.TypeSelectView r8 = (com.huawei.digitalpayment.topup.widget.TypeSelectView) r8
            if (r8 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.iv_blus
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            if (r2 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.line
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            if (r2 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.rl_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r9 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r9 = (com.huawei.common.widget.round.RoundConstraintLayout) r9
            if (r9 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.rl_et_km_container
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundLinearLayout r2 = (com.huawei.common.widget.round.RoundLinearLayout) r2
            if (r2 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.tv_amount
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r2 = (android.widget.TextView) r2
            if (r2 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.tv_fuel_type
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r10 = r2
            android.widget.TextView r10 = (android.widget.TextView) r10
            if (r10 == 0) goto L_0x008b
            int r1 = com.huawei.digitalpayment.topup.R$id.tv_plate_number
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            r11 = r2
            android.widget.TextView r11 = (android.widget.TextView) r11
            if (r11 == 0) goto L_0x008b
            com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentAmountBinding r1 = new com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentAmountBinding
            r4 = r0
            androidx.constraintlayout.widget.ConstraintLayout r4 = (androidx.constraintlayout.widget.ConstraintLayout) r4
            r3 = r1
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11)
            r12.i = r1
            return r1
        L_0x008b:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.fuel.activity.FuelPaymentAmountActivity.K0():androidx.viewbinding.ViewBinding");
    }
}
