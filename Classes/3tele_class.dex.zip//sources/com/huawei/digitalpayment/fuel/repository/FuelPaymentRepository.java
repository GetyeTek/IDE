package com.huawei.digitalpayment.fuel.repository;

import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.http.b;

public class FuelPaymentRepository extends b<TransferResp, TransferResp> {
    public final String getApiPath() {
        return "v1/ethiopia/payFuel";
    }
}
