package com.huawei.digitalpayment.fuel.repository;

import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.http.b;

public class PreFuelPaymentRepository extends b<CheckoutResp, CheckoutResp> {
    public PreFuelPaymentRepository() {
        throw null;
    }

    public final String getApiPath() {
        return "v1/ethiopia/prePayFuel";
    }
}
