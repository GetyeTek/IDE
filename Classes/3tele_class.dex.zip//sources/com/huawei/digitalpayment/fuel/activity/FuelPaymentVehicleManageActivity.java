package com.huawei.digitalpayment.fuel.activity;

import B6.b;
import D1.q;
import G5.f;
import N4.d;
import android.content.Intent;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.httplib.response.VehicleBean;
import com.huawei.digitalpayment.fuel.viewmodel.FuelPaymentVehicleMangeViewModel;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.adapter.VehicleManageAdapter;
import com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentVehicleManageBinding;
import com.huawei.requestmoney.g;
import java.util.HashMap;
import t3.h;
import t3.i;
import y4.c;
import y4.e;

@Route(path = "/topUpModule/fuelPaymentVehicle")
public class FuelPaymentVehicleManageActivity extends BaseTitleActivity {
    public static final /* synthetic */ int o = 0;
    public ActivityFuelPaymentVehicleManageBinding i;
    public VehicleManageAdapter j;
    public int k;
    public FuelPaymentVehicleMangeViewModel l;
    public VehicleBean m;
    public VehicleBean n;

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.digitalpayment.fuel.activity.FuelPaymentVehicleManageActivity, java.lang.Object, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, androidx.lifecycle.ViewModelStoreOwner, androidx.appcompat.app.AppCompatActivity] */
    public final void G0() {
        super.G0();
        N0(getString(R$string.fuel_payment));
        this.i.b.setOnClickListener(new q(this, 11));
        this.i.d.setLayoutManager(new LinearLayoutManager(this));
        int i2 = R$layout.item_vehicle_manage;
        b bVar = new b(this, 3);
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(i2);
        baseQuickAdapter.a = this;
        baseQuickAdapter.b = bVar;
        this.j = baseQuickAdapter;
        this.i.d.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(this, R$color.colorDividerLight), v.a(12.0f)));
        this.i.d.setAdapter(this.j);
        if (this.j.getData().size() == 0) {
            this.i.c.setVisibility(0);
        }
        if (this.l == null) {
            this.l = new ViewModelProvider(this).get(FuelPaymentVehicleMangeViewModel.class);
        }
        this.l.c.observe(this, new d(this, 3));
        this.l.d.observe(this, new f(1));
        this.l.h.observe(this, new h(this, 1));
        this.l.i.observe(this, new g(this, 2));
        this.l.j.observe(this, new i(this, 1));
        this.l.k.observe(this, new N4.h(this, 4));
        FuelPaymentVehicleMangeViewModel fuelPaymentVehicleMangeViewModel = this.l;
        e eVar = fuelPaymentVehicleMangeViewModel.g;
        eVar.getClass();
        fuelPaymentVehicleMangeViewModel.b(new y4.b(eVar).a, new z4.d(fuelPaymentVehicleMangeViewModel));
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [com.huawei.digitalpayment.fuel.activity.FuelPaymentVehicleManageActivity, android.app.Activity] */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0016, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.cl_empty;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0034, code lost:
        r1 = com.huawei.digitalpayment.topup.R$id.rv_list;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding K0() {
        /*
            r6 = this;
            android.view.LayoutInflater r0 = r6.getLayoutInflater()
            int r1 = com.huawei.digitalpayment.topup.R$layout.activity_fuel_payment_vehicle_manage
            r2 = 0
            r3 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            int r1 = com.huawei.digitalpayment.topup.R$id.bt_add_new_vehicle
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.Button r2 = (android.widget.Button) r2
            if (r2 == 0) goto L_0x0052
            int r1 = com.huawei.digitalpayment.topup.R$id.cl_empty
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            if (r3 == 0) goto L_0x0052
            int r1 = com.huawei.digitalpayment.topup.R$id.iv_empty
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            if (r4 == 0) goto L_0x0052
            int r1 = com.huawei.digitalpayment.topup.R$id.rl_container
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            com.huawei.common.widget.round.RoundConstraintLayout r4 = (com.huawei.common.widget.round.RoundConstraintLayout) r4
            if (r4 == 0) goto L_0x0052
            int r1 = com.huawei.digitalpayment.topup.R$id.rv_list
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            androidx.recyclerview.widget.RecyclerView r4 = (androidx.recyclerview.widget.RecyclerView) r4
            if (r4 == 0) goto L_0x0052
            int r1 = com.huawei.digitalpayment.topup.R$id.tv_title
            android.view.View r5 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r1)
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x0052
            com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentVehicleManageBinding r1 = new com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentVehicleManageBinding
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1.<init>(r0, r2, r3, r4)
            r6.i = r1
            return r1
        L_0x0052:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r1)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.digitalpayment.fuel.activity.FuelPaymentVehicleManageActivity.K0():androidx.viewbinding.ViewBinding");
    }

    public final void onActivityResult(int i2, int i5, @Nullable Intent intent) {
        FuelPaymentVehicleManageActivity.super.onActivityResult(i2, i5, intent);
        if (intent != null && i5 == -1) {
            VehicleBean vehicleBean = (VehicleBean) intent.getSerializableExtra("vehicle");
            this.n = vehicleBean;
            if (i2 == 1001) {
                FuelPaymentVehicleMangeViewModel fuelPaymentVehicleMangeViewModel = this.l;
                String plateNumber = vehicleBean.getPlateNumber();
                String fuelType = this.n.getFuelType();
                fuelPaymentVehicleMangeViewModel.getClass();
                HashMap hashMap = new HashMap();
                hashMap.put("plateNumber", plateNumber);
                hashMap.put("fuelType", fuelType);
                e eVar = fuelPaymentVehicleMangeViewModel.g;
                eVar.getClass();
                fuelPaymentVehicleMangeViewModel.b(new c(eVar, hashMap).a, new z4.e(fuelPaymentVehicleMangeViewModel));
                return;
            }
            FuelPaymentVehicleMangeViewModel fuelPaymentVehicleMangeViewModel2 = this.l;
            String plateNumber2 = vehicleBean.getPlateNumber();
            String fuelType2 = this.n.getFuelType();
            String carId = this.n.getCarId();
            fuelPaymentVehicleMangeViewModel2.getClass();
            HashMap hashMap2 = new HashMap();
            hashMap2.put("carId", carId);
            hashMap2.put("plateNumber", plateNumber2);
            hashMap2.put("fuelType", fuelType2);
            e eVar2 = fuelPaymentVehicleMangeViewModel2.g;
            eVar2.getClass();
            fuelPaymentVehicleMangeViewModel2.b(new y4.d(eVar2, hashMap2).a, new z4.g(fuelPaymentVehicleMangeViewModel2));
        }
    }
}
