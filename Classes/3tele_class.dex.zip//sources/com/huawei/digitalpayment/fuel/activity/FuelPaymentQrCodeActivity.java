package com.huawei.digitalpayment.fuel.activity;

import D1.l;
import W2.n;
import W2.r;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import b4.C0009b;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.A;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.SetAmountPop;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.fuel.repository.QueryQrCodeRepository;
import com.huawei.digitalpayment.fuel.resp.FuelPaymentQrCodeBean;
import com.huawei.digitalpayment.fuel.resp.FuelPaymentQrCodeEntity;
import com.huawei.digitalpayment.fuel.resp.QueryAuthNoticeResp;
import com.huawei.digitalpayment.fuel.viewmodel.FuelPaymentQrCodeViewModel;
import com.huawei.digitalpayment.topup.R$id;
import com.huawei.digitalpayment.topup.R$layout;
import com.huawei.digitalpayment.topup.R$string;
import com.huawei.digitalpayment.topup.databinding.ActivityFuelPaymentQrCodeBinding;
import com.huawei.http.b;
import java.util.HashMap;
import java.util.List;
import k3.C0033a;
import v4.d;
import y4.a;
import y4.f;
import y4.h;
import y4.i;
import z4.c;

@Route(path = "/topUpModule/fuelPaymentQrCode")
public class FuelPaymentQrCodeActivity extends BaseTitleActivity implements Runnable {
    public static final /* synthetic */ int r = 0;
    public FuelPaymentQrCodeViewModel i;
    public ActivityFuelPaymentQrCodeBinding j;
    public FuelPaymentQrCodeBean k;
    public QueryQrCodeRepository l;
    public FuelPaymentQrCodeEntity m;
    public QueryAuthNoticeResp n;
    public int o;
    public SetAmountPop p;
    public String q;

    public class a implements R1.a<QueryAuthNoticeResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FuelPaymentQrCodeActivity fuelPaymentQrCodeActivity = FuelPaymentQrCodeActivity.this;
            A.h(fuelPaymentQrCodeActivity, (long) (fuelPaymentQrCodeActivity.m.getPollFreq()[fuelPaymentQrCodeActivity.o] * 1000));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            QueryAuthNoticeResp queryAuthNoticeResp = (QueryAuthNoticeResp) obj;
            FuelPaymentQrCodeActivity fuelPaymentQrCodeActivity = FuelPaymentQrCodeActivity.this;
            if (queryAuthNoticeResp == null || !queryAuthNoticeResp.isExist() || TextUtils.isEmpty(queryAuthNoticeResp.getPrepayId())) {
                A.h(fuelPaymentQrCodeActivity, (long) (fuelPaymentQrCodeActivity.m.getPollFreq()[fuelPaymentQrCodeActivity.o] * 1000));
                return;
            }
            fuelPaymentQrCodeActivity.n = queryAuthNoticeResp;
            FuelPaymentQrCodeViewModel fuelPaymentQrCodeViewModel = fuelPaymentQrCodeActivity.i;
            fuelPaymentQrCodeViewModel.getClass();
            HashMap hashMap = new HashMap();
            hashMap.put("prepayId", queryAuthNoticeResp.getPrepayId());
            hashMap.put("appId", queryAuthNoticeResp.getAppId());
            hashMap.put("merchCode", queryAuthNoticeResp.getMerchCode());
            hashMap.put("tradeType", "QuickPay");
            i iVar = fuelPaymentQrCodeViewModel.g;
            iVar.getClass();
            fuelPaymentQrCodeViewModel.b(new h(iVar, hashMap).a, new c(fuelPaymentQrCodeViewModel));
        }
    }

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r1v6, types: [androidx.lifecycle.Observer, java.lang.Object] */
    public final void G0() {
        super.G0();
        N0(getString(R$string.fuel_payment));
        this.k = (FuelPaymentQrCodeBean) getIntent().getSerializableExtra("qrCodeBean");
        this.j.e.setText(C0033a.e.b());
        this.j.d.setText(this.k.getAmount());
        if (this.i == null) {
            this.i = new ViewModelProvider(this).get(FuelPaymentQrCodeViewModel.class);
        }
        this.i.c.observe(this, new l(this, 5));
        this.i.d.observe(this, new Object());
        this.i.h.observe(this, new C0009b(this, 3));
        this.i.i.observe(this, new l7.c(this, 1));
        this.i.j.observe(this, new com.huawei.digitalpayment.customer.login_module.modifypin.a(this, 1));
        String e = n.b("").e("recent_login_phone_number");
        this.q = e;
        FuelPaymentQrCodeViewModel fuelPaymentQrCodeViewModel = this.i;
        fuelPaymentQrCodeViewModel.getClass();
        y4.a aVar = a.C0005a.a;
        List<FuelPaymentQrCodeEntity> list = (List) aVar.b.get(e);
        fuelPaymentQrCodeViewModel.k = list;
        if (list.size() != 0) {
            fuelPaymentQrCodeViewModel.k.size();
            V1.h.b();
            FuelPaymentQrCodeEntity fuelPaymentQrCodeEntity = fuelPaymentQrCodeViewModel.k.get(0);
            if (System.currentTimeMillis() - r.b(fuelPaymentQrCodeEntity.getServerTime()).longValue() > Long.valueOf(fuelPaymentQrCodeEntity.getInvalidAt()).longValue()) {
                aVar.b.remove(e);
                d.b.execute(new H8.c(e, 2));
                i iVar = fuelPaymentQrCodeViewModel.g;
                iVar.getClass();
                fuelPaymentQrCodeViewModel.b(new f(iVar).a, new z4.a(fuelPaymentQrCodeViewModel, e));
            } else {
                fuelPaymentQrCodeViewModel.h.setValue(fuelPaymentQrCodeEntity);
            }
        } else {
            i iVar2 = fuelPaymentQrCodeViewModel.g;
            iVar2.getClass();
            fuelPaymentQrCodeViewModel.b(new f(iVar2).a, new z4.a(fuelPaymentQrCodeViewModel, e));
        }
        this.j.b.setOnClickListener(new D1.i(this, 7));
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.huawei.digitalpayment.fuel.activity.FuelPaymentQrCodeActivity, android.app.Activity] */
    public final ViewBinding K0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_fuel_payment_qr_code, (ViewGroup) null, false);
        int i2 = R$id.btn_change_amount;
        Button button = (Button) ViewBindings.findChildViewById(inflate, i2);
        if (button != null) {
            i2 = R$id.iv_qr_code;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i2);
            if (imageView != null) {
                i2 = R$id.iv_qr_container;
                if (((ImageView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                    i2 = R$id.ll_amount;
                    if (((LinearLayout) ViewBindings.findChildViewById(inflate, i2)) != null) {
                        i2 = R$id.tv_amount;
                        TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i2);
                        if (textView != null) {
                            i2 = R$id.tvCurrency;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(inflate, i2);
                            if (textView2 != null) {
                                i2 = R$id.tv_qr_tips;
                                if (((TextView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                                    ActivityFuelPaymentQrCodeBinding activityFuelPaymentQrCodeBinding = new ActivityFuelPaymentQrCodeBinding(inflate, button, imageView, textView, textView2);
                                    this.j = activityFuelPaymentQrCodeBinding;
                                    return activityFuelPaymentQrCodeBinding;
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }

    public final void U0() {
        if (this.o >= this.m.getPollFreq().length - 1) {
            this.o = 0;
            FuelPaymentQrCodeViewModel fuelPaymentQrCodeViewModel = this.i;
            List<FuelPaymentQrCodeEntity> list = fuelPaymentQrCodeViewModel.k;
            MutableLiveData<FuelPaymentQrCodeEntity> mutableLiveData = fuelPaymentQrCodeViewModel.h;
            if (list == null || list.size() == 0) {
                mutableLiveData.setValue((Object) null);
            } else {
                mutableLiveData.setValue(fuelPaymentQrCodeViewModel.k.get(0));
            }
        } else {
            if (this.l == null) {
                String e = n.b("").e("recent_login_phone_number");
                b bVar = new b();
                bVar.addParams("initiatorMsisdn", e);
                this.l = bVar;
            }
            this.l.sendRequest(new a());
            this.o++;
        }
    }

    public final void onDestroy() {
        FuelPaymentQrCodeActivity.super.onDestroy();
        A.a.removeCallbacks(this);
    }

    public final void run() {
        U0();
    }
}
