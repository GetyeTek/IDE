package com.huawei.digitalpayment.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import com.huawei.digitalpayment.fuel.resp.FuelPaymentQrCodeEntity;
import v4.a;

@Database(entities = {FuelPaymentQrCodeEntity.class}, exportSchema = false, version = 1)
public abstract class FuelPaymentQrCodeDateBase extends RoomDatabase {
    public abstract a c();
}
