package com.huawei.digitalpayment.db;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import v4.h;
import v4.j;

public final class PayBillDatabase_Impl extends PayBillDatabase {
    public volatile j a;

    public class a extends RoomOpenHelper.Delegate {
        public a() {
            super(1);
        }

        public final void createAllTables(SupportSQLiteDatabase supportSQLiteDatabase) {
            supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `PayBillHistory` (`phoneNumber` TEXT NOT NULL, `avatar` TEXT, `name` TEXT, `recent` INTEGER NOT NULL, `time` INTEGER NOT NULL, `responseCode` TEXT, `responseDesc` TEXT, `serverTimestamp` TEXT, PRIMARY KEY(`phoneNumber`))");
            supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            supportSQLiteDatabase.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '7c0e2752d6cfab358e66fa1f1b306a30')");
        }

        public final void dropAllTables(SupportSQLiteDatabase supportSQLiteDatabase) {
            supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `PayBillHistory`");
            PayBillDatabase_Impl payBillDatabase_Impl = PayBillDatabase_Impl.this;
            if (payBillDatabase_Impl.mCallbacks != null) {
                int size = payBillDatabase_Impl.mCallbacks.size();
                for (int i = 0; i < size; i++) {
                    ((RoomDatabase.Callback) payBillDatabase_Impl.mCallbacks.get(i)).onDestructiveMigration(supportSQLiteDatabase);
                }
            }
        }

        public final void onCreate(SupportSQLiteDatabase supportSQLiteDatabase) {
            PayBillDatabase_Impl payBillDatabase_Impl = PayBillDatabase_Impl.this;
            if (payBillDatabase_Impl.mCallbacks != null) {
                int size = payBillDatabase_Impl.mCallbacks.size();
                for (int i = 0; i < size; i++) {
                    ((RoomDatabase.Callback) payBillDatabase_Impl.mCallbacks.get(i)).onCreate(supportSQLiteDatabase);
                }
            }
        }

        public final void onOpen(SupportSQLiteDatabase supportSQLiteDatabase) {
            PayBillDatabase_Impl payBillDatabase_Impl = PayBillDatabase_Impl.this;
            payBillDatabase_Impl.mDatabase = supportSQLiteDatabase;
            payBillDatabase_Impl.internalInitInvalidationTracker(supportSQLiteDatabase);
            if (payBillDatabase_Impl.mCallbacks != null) {
                int size = payBillDatabase_Impl.mCallbacks.size();
                for (int i = 0; i < size; i++) {
                    ((RoomDatabase.Callback) payBillDatabase_Impl.mCallbacks.get(i)).onOpen(supportSQLiteDatabase);
                }
            }
        }

        public final void onPostMigrate(SupportSQLiteDatabase supportSQLiteDatabase) {
        }

        public final void onPreMigrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            DBUtil.dropFtsSyncTriggers(supportSQLiteDatabase);
        }

        public final RoomOpenHelper.ValidationResult onValidateSchema(SupportSQLiteDatabase supportSQLiteDatabase) {
            HashMap hashMap = new HashMap(8);
            hashMap.put("phoneNumber", new TableInfo.Column("phoneNumber", "TEXT", true, 1, (String) null, 1));
            hashMap.put("avatar", new TableInfo.Column("avatar", "TEXT", false, 0, (String) null, 1));
            hashMap.put("name", new TableInfo.Column("name", "TEXT", false, 0, (String) null, 1));
            hashMap.put("recent", new TableInfo.Column("recent", "INTEGER", true, 0, (String) null, 1));
            hashMap.put("time", new TableInfo.Column("time", "INTEGER", true, 0, (String) null, 1));
            hashMap.put("responseCode", new TableInfo.Column("responseCode", "TEXT", false, 0, (String) null, 1));
            hashMap.put("responseDesc", new TableInfo.Column("responseDesc", "TEXT", false, 0, (String) null, 1));
            hashMap.put("serverTimestamp", new TableInfo.Column("serverTimestamp", "TEXT", false, 0, (String) null, 1));
            TableInfo tableInfo = new TableInfo("PayBillHistory", hashMap, new HashSet(0), new HashSet(0));
            TableInfo read = TableInfo.read(supportSQLiteDatabase, "PayBillHistory");
            if (tableInfo.equals(read)) {
                return new RoomOpenHelper.ValidationResult(true, (String) null);
            }
            return new RoomOpenHelper.ValidationResult(false, "PayBillHistory(com.huawei.digitalpayment.paybill.resp.PayBillHistory).\n Expected:\n" + tableInfo + "\n Found:\n" + read);
        }
    }

    public final h c() {
        j jVar;
        if (this.a != null) {
            return this.a;
        }
        synchronized (this) {
            try {
                if (this.a == null) {
                    this.a = new j(this);
                }
                jVar = this.a;
            } catch (Throwable th) {
                throw th;
            }
        }
        return jVar;
    }

    public final void clearAllTables() {
        PayBillDatabase_Impl.super.assertNotMainThread();
        SupportSQLiteDatabase writableDatabase = PayBillDatabase_Impl.super.getOpenHelper().getWritableDatabase();
        try {
            PayBillDatabase_Impl.super.beginTransaction();
            writableDatabase.execSQL("DELETE FROM `PayBillHistory`");
            PayBillDatabase_Impl.super.setTransactionSuccessful();
        } finally {
            PayBillDatabase_Impl.super.endTransaction();
            writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close();
            if (!writableDatabase.inTransaction()) {
                writableDatabase.execSQL("VACUUM");
            }
        }
    }

    public final InvalidationTracker createInvalidationTracker() {
        return new InvalidationTracker(this, new HashMap(0), new HashMap(0), new String[]{"PayBillHistory"});
    }

    public final SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration databaseConfiguration) {
        return databaseConfiguration.sqliteOpenHelperFactory.create(SupportSQLiteOpenHelper.Configuration.builder(databaseConfiguration.context).name(databaseConfiguration.name).callback(new RoomOpenHelper(databaseConfiguration, new a(), "7c0e2752d6cfab358e66fa1f1b306a30", "e35ec8f612722f38ce339999e1fb7c8e")).build());
    }

    public final List<Migration> getAutoMigrations(@NonNull Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> map) {
        return Arrays.asList(new Migration[0]);
    }

    public final Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
        return new HashSet();
    }

    public final Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
        HashMap hashMap = new HashMap();
        hashMap.put(h.class, Collections.emptyList());
        return hashMap;
    }
}
