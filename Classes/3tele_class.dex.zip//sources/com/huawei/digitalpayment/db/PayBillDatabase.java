package com.huawei.digitalpayment.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import com.huawei.digitalpayment.paybill.resp.PayBillHistory;
import v4.h;

@Database(entities = {PayBillHistory.class}, exportSchema = false, version = 1)
public abstract class PayBillDatabase extends RoomDatabase {
    public abstract h c();
}
