package com.huawei.digitalpayment.db;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import v4.c;

public final class FuelPaymentQrCodeDateBase_Impl extends FuelPaymentQrCodeDateBase {
    public volatile c a;

    public class a extends RoomOpenHelper.Delegate {
        public a() {
            super(1);
        }

        public final void createAllTables(SupportSQLiteDatabase supportSQLiteDatabase) {
            supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `FuelPaymentQrCodeEntity` (`codeId` TEXT NOT NULL, `serverTime` TEXT, `refreshFreq` TEXT, `pollFreq` TEXT, `effectAt` TEXT, `invalidAt` TEXT, `qrType` TEXT, `barCode` TEXT, `qrCode` TEXT, `phoneNumber` TEXT, `responseCode` TEXT, `responseDesc` TEXT, `serverTimestamp` TEXT, PRIMARY KEY(`codeId`))");
            supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            supportSQLiteDatabase.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'dabf485da9bf5b5c5f3af9c35cdd9014')");
        }

        public final void dropAllTables(SupportSQLiteDatabase supportSQLiteDatabase) {
            supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `FuelPaymentQrCodeEntity`");
            FuelPaymentQrCodeDateBase_Impl fuelPaymentQrCodeDateBase_Impl = FuelPaymentQrCodeDateBase_Impl.this;
            if (fuelPaymentQrCodeDateBase_Impl.mCallbacks != null) {
                int size = fuelPaymentQrCodeDateBase_Impl.mCallbacks.size();
                for (int i = 0; i < size; i++) {
                    ((RoomDatabase.Callback) fuelPaymentQrCodeDateBase_Impl.mCallbacks.get(i)).onDestructiveMigration(supportSQLiteDatabase);
                }
            }
        }

        public final void onCreate(SupportSQLiteDatabase supportSQLiteDatabase) {
            FuelPaymentQrCodeDateBase_Impl fuelPaymentQrCodeDateBase_Impl = FuelPaymentQrCodeDateBase_Impl.this;
            if (fuelPaymentQrCodeDateBase_Impl.mCallbacks != null) {
                int size = fuelPaymentQrCodeDateBase_Impl.mCallbacks.size();
                for (int i = 0; i < size; i++) {
                    ((RoomDatabase.Callback) fuelPaymentQrCodeDateBase_Impl.mCallbacks.get(i)).onCreate(supportSQLiteDatabase);
                }
            }
        }

        public final void onOpen(SupportSQLiteDatabase supportSQLiteDatabase) {
            FuelPaymentQrCodeDateBase_Impl fuelPaymentQrCodeDateBase_Impl = FuelPaymentQrCodeDateBase_Impl.this;
            fuelPaymentQrCodeDateBase_Impl.mDatabase = supportSQLiteDatabase;
            fuelPaymentQrCodeDateBase_Impl.internalInitInvalidationTracker(supportSQLiteDatabase);
            if (fuelPaymentQrCodeDateBase_Impl.mCallbacks != null) {
                int size = fuelPaymentQrCodeDateBase_Impl.mCallbacks.size();
                for (int i = 0; i < size; i++) {
                    ((RoomDatabase.Callback) fuelPaymentQrCodeDateBase_Impl.mCallbacks.get(i)).onOpen(supportSQLiteDatabase);
                }
            }
        }

        public final void onPostMigrate(SupportSQLiteDatabase supportSQLiteDatabase) {
        }

        public final void onPreMigrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            DBUtil.dropFtsSyncTriggers(supportSQLiteDatabase);
        }

        public final RoomOpenHelper.ValidationResult onValidateSchema(SupportSQLiteDatabase supportSQLiteDatabase) {
            HashMap hashMap = new HashMap(13);
            hashMap.put("codeId", new TableInfo.Column("codeId", "TEXT", true, 1, (String) null, 1));
            hashMap.put("serverTime", new TableInfo.Column("serverTime", "TEXT", false, 0, (String) null, 1));
            hashMap.put("refreshFreq", new TableInfo.Column("refreshFreq", "TEXT", false, 0, (String) null, 1));
            hashMap.put("pollFreq", new TableInfo.Column("pollFreq", "TEXT", false, 0, (String) null, 1));
            hashMap.put("effectAt", new TableInfo.Column("effectAt", "TEXT", false, 0, (String) null, 1));
            hashMap.put("invalidAt", new TableInfo.Column("invalidAt", "TEXT", false, 0, (String) null, 1));
            hashMap.put("qrType", new TableInfo.Column("qrType", "TEXT", false, 0, (String) null, 1));
            hashMap.put("barCode", new TableInfo.Column("barCode", "TEXT", false, 0, (String) null, 1));
            hashMap.put("qrCode", new TableInfo.Column("qrCode", "TEXT", false, 0, (String) null, 1));
            hashMap.put("phoneNumber", new TableInfo.Column("phoneNumber", "TEXT", false, 0, (String) null, 1));
            hashMap.put("responseCode", new TableInfo.Column("responseCode", "TEXT", false, 0, (String) null, 1));
            hashMap.put("responseDesc", new TableInfo.Column("responseDesc", "TEXT", false, 0, (String) null, 1));
            hashMap.put("serverTimestamp", new TableInfo.Column("serverTimestamp", "TEXT", false, 0, (String) null, 1));
            TableInfo tableInfo = new TableInfo("FuelPaymentQrCodeEntity", hashMap, new HashSet(0), new HashSet(0));
            TableInfo read = TableInfo.read(supportSQLiteDatabase, "FuelPaymentQrCodeEntity");
            if (tableInfo.equals(read)) {
                return new RoomOpenHelper.ValidationResult(true, (String) null);
            }
            return new RoomOpenHelper.ValidationResult(false, "FuelPaymentQrCodeEntity(com.huawei.digitalpayment.fuel.resp.FuelPaymentQrCodeEntity).\n Expected:\n" + tableInfo + "\n Found:\n" + read);
        }
    }

    public final v4.a c() {
        c cVar;
        if (this.a != null) {
            return this.a;
        }
        synchronized (this) {
            try {
                if (this.a == null) {
                    this.a = new c(this);
                }
                cVar = this.a;
            } catch (Throwable th) {
                throw th;
            }
        }
        return cVar;
    }

    public final void clearAllTables() {
        FuelPaymentQrCodeDateBase_Impl.super.assertNotMainThread();
        SupportSQLiteDatabase writableDatabase = FuelPaymentQrCodeDateBase_Impl.super.getOpenHelper().getWritableDatabase();
        try {
            FuelPaymentQrCodeDateBase_Impl.super.beginTransaction();
            writableDatabase.execSQL("DELETE FROM `FuelPaymentQrCodeEntity`");
            FuelPaymentQrCodeDateBase_Impl.super.setTransactionSuccessful();
        } finally {
            FuelPaymentQrCodeDateBase_Impl.super.endTransaction();
            writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close();
            if (!writableDatabase.inTransaction()) {
                writableDatabase.execSQL("VACUUM");
            }
        }
    }

    public final InvalidationTracker createInvalidationTracker() {
        return new InvalidationTracker(this, new HashMap(0), new HashMap(0), new String[]{"FuelPaymentQrCodeEntity"});
    }

    public final SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration databaseConfiguration) {
        return databaseConfiguration.sqliteOpenHelperFactory.create(SupportSQLiteOpenHelper.Configuration.builder(databaseConfiguration.context).name(databaseConfiguration.name).callback(new RoomOpenHelper(databaseConfiguration, new a(), "dabf485da9bf5b5c5f3af9c35cdd9014", "a35bd5a1d4929f96384661b2b54f4f0d")).build());
    }

    public final List<Migration> getAutoMigrations(@NonNull Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> map) {
        return Arrays.asList(new Migration[0]);
    }

    public final Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
        return new HashSet();
    }

    public final Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
        HashMap hashMap = new HashMap();
        hashMap.put(v4.a.class, Collections.emptyList());
        return hashMap;
    }
}
