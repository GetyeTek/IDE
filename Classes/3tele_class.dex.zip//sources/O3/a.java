package O3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.huawei.digitalpayment.customer.login_module.R$id;
import com.huawei.digitalpayment.customer.login_module.R$layout;

public final class a extends Toast {
    public a(Context context, String str) {
        super(context);
        View inflate = LayoutInflater.from(context).inflate(R$layout.toast_account_active_success, (ViewGroup) null);
        ((TextView) inflate.findViewById(R$id.tipTextView)).setText(str);
        setView(inflate);
        setGravity(17, 0, 0);
        setDuration(1);
    }
}
