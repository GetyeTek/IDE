package d4;

import R1.a;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.huawei.digitalpayment.customer.login_module.registerverify.repository.QueryRegionRepository;
import com.huawei.digitalpayment.customer.login_module.registerverify.resp.DictCode;
import com.huawei.digitalpayment.customer.login_module.registerverify.resp.RegionListResp;
import com.huawei.http.b;

/* renamed from: d4.a  reason: case insensitive filesystem */
public final class C0017a {
    public QueryRegionRepository a;

    public final void a(@NonNull DictCode dictCode, @Nullable String str, @Nullable a<RegionListResp> aVar) {
        QueryRegionRepository queryRegionRepository = this.a;
        if (queryRegionRepository != null) {
            queryRegionRepository.cancel();
            this.a = null;
        }
        b bVar = new b();
        bVar.addParams("dictCode", dictCode.toString());
        if (str != null) {
            bVar.addParams("parentItemCode", str);
        }
        this.a = bVar;
        bVar.sendRequest(aVar);
    }
}
