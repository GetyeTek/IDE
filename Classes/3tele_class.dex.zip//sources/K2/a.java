package K2;

import R8.b;
import V1.h;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.k;
import com.huawei.digitalpayment.customer.httplib.response.ScanQrResp;
import java.util.Map;

public final class a extends A2.a {
    public static final a c = new A2.a();
    public b b;

    public final boolean b(FragmentActivity fragmentActivity, String str, String str2) {
        if (this.b != null) {
            try {
                Map<String, String> params = ((ScanQrResp) k.a(str2, ScanQrResp.class)).getParams();
                if (params.containsKey("msisdn")) {
                    fragmentActivity.finish();
                    this.b.onSuccess(params.get("msisdn"));
                    return true;
                }
            } catch (Exception e) {
                e.getMessage();
                h.b();
            }
        }
        this.b = null;
        return false;
    }
}
