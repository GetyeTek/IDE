package B4;

import V1.h;
import com.blankj.utilcode.util.A;
import java.util.HashMap;

public final class b {
    public static HashMap a;

    static {
        if (a == null) {
            A.d(new A.b());
        }
        h.b();
    }
}
