package B4;

import com.blankj.utilcode.util.A;

public final class a extends A.b<Void> {
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0052 A[SYNTHETIC, Splitter:B:17:0x0052] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a() throws java.lang.Throwable {
        /*
            r7 = this;
            android.app.Application r0 = com.blankj.utilcode.util.J.a()
            android.content.ContentResolver r1 = r0.getContentResolver()
            r0 = 0
            android.net.Uri r2 = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI     // Catch:{ Exception -> 0x005b }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            android.database.Cursor r1 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ Exception -> 0x005b }
            int r2 = r1.getCount()     // Catch:{ all -> 0x004e }
            java.util.HashMap r3 = new java.util.HashMap     // Catch:{ all -> 0x004e }
            r3.<init>(r2)     // Catch:{ all -> 0x004e }
        L_0x001c:
            boolean r2 = r1.moveToNext()     // Catch:{ all -> 0x0048 }
            if (r2 == 0) goto L_0x004a
            java.lang.String r2 = "data1"
            int r2 = r1.getColumnIndex(r2)     // Catch:{ all -> 0x0048 }
            java.lang.String r2 = r1.getString(r2)     // Catch:{ all -> 0x0048 }
            java.lang.String r2 = W2.h.c(r2)     // Catch:{ all -> 0x0048 }
            java.lang.String r4 = "contact_id"
            int r4 = r1.getColumnIndex(r4)     // Catch:{ all -> 0x0048 }
            long r4 = r1.getLong(r4)     // Catch:{ all -> 0x0048 }
            boolean r6 = r3.containsKey(r2)     // Catch:{ all -> 0x0048 }
            if (r6 != 0) goto L_0x001c
            java.lang.Long r4 = java.lang.Long.valueOf(r4)     // Catch:{ all -> 0x0048 }
            r3.put(r2, r4)     // Catch:{ all -> 0x0048 }
            goto L_0x001c
        L_0x0048:
            r2 = move-exception
            goto L_0x0050
        L_0x004a:
            r1.close()     // Catch:{ Exception -> 0x005c }
            goto L_0x005c
        L_0x004e:
            r2 = move-exception
            r3 = r0
        L_0x0050:
            if (r1 == 0) goto L_0x005a
            r1.close()     // Catch:{ all -> 0x0056 }
            goto L_0x005a
        L_0x0056:
            r1 = move-exception
            r2.addSuppressed(r1)     // Catch:{ Exception -> 0x005c }
        L_0x005a:
            throw r2     // Catch:{ Exception -> 0x005c }
        L_0x005b:
            r3 = r0
        L_0x005c:
            B4.b.a = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: B4.a.a():java.lang.Object");
    }

    public final /* bridge */ /* synthetic */ void f(Object obj) {
        Void voidR = (Void) obj;
    }
}
