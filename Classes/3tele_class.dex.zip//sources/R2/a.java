package R2;

import S2.a;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import com.blankj.utilcode.util.J;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.R$string;
import fc.A;
import fc.b;
import fc.d;
import fc.r;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.Response;

public final class a extends LiveData<S2.a<Object>> {
    public final AtomicBoolean a = new AtomicBoolean(false);
    public final /* synthetic */ r b;

    /* renamed from: R2.a$a  reason: collision with other inner class name */
    public class C0000a implements d<Object> {
        public C0000a() {
        }

        /* JADX WARNING: type inference failed for: r3v6, types: [S2.a, S2.a$c] */
        public final void a(@NonNull b<Object> bVar, @NonNull A<Object> a2) {
            S2.a aVar;
            a.b bVar2;
            Response response = a2.a;
            if (response.isSuccessful()) {
                T t = a2.b;
                if (t == null) {
                    aVar = new S2.a();
                    a.this.postValue(aVar);
                }
                ? aVar2 = new S2.a();
                aVar2.a = t;
                bVar2 = aVar2;
            } else {
                response.code();
                String message = response.message();
                if (TextUtils.isEmpty(message)) {
                    message = J.a().getResources().getString(R$string.designstandard_failed_to_parse_data);
                }
                bVar2 = new a.b(new BaseException(message));
            }
            aVar = bVar2;
            a.this.postValue(aVar);
        }

        public final void b(@NonNull b<Object> bVar, @NonNull Throwable th) {
            BaseException baseException;
            a aVar = a.this;
            aVar.getClass();
            if (th instanceof BaseException) {
                baseException = (BaseException) th;
            } else {
                baseException = new BaseException(G2.b.d());
            }
            aVar.postValue(new a.b(baseException));
        }
    }

    public a(r rVar) {
        this.b = rVar;
    }

    public final void onActive() {
        a.super.onActive();
        if (this.a.compareAndSet(false, true)) {
            this.b.a(new C0000a());
        }
    }
}
