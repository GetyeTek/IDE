package R2;

import S2.a;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import fc.F;
import fc.c;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public final class c extends c.a {
    @Nullable
    public final fc.c a(@NonNull Type type, @NonNull Annotation[] annotationArr) {
        if (F.e(type) != LiveData.class) {
            return null;
        }
        Type d = F.d(0, (ParameterizedType) type);
        if (F.e(d) != a.class) {
            throw new IllegalArgumentException("type must be a resource");
        } else if (d instanceof ParameterizedType) {
            return new b(F.d(0, (ParameterizedType) d));
        } else {
            throw new IllegalArgumentException("resource must be parameterized");
        }
    }
}
