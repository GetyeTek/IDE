package R2;

import S2.a;
import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import fc.c;
import fc.r;
import java.lang.reflect.Type;

public final class b<R> implements c<R, LiveData<a<R>>> {
    public final Type a;

    public b(Type type) {
        this.a = type;
    }

    @NonNull
    public final Type a() {
        return this.a;
    }

    @NonNull
    public final Object b(@NonNull r rVar) {
        return new a(rVar);
    }
}
