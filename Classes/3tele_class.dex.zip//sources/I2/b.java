package I2;

import com.huawei.common.widget.date.WheelPicker;
import com.huawei.digitalpayment.customer.baselib.dialog.ScheduleDatePickerDialog;

public final /* synthetic */ class b implements WheelPicker.a {
    public final /* synthetic */ ScheduleDatePickerDialog a;
    public final /* synthetic */ int b;

    public /* synthetic */ b(ScheduleDatePickerDialog scheduleDatePickerDialog, int i) {
        this.a = scheduleDatePickerDialog;
        this.b = i;
    }

    public final void a(int i) {
        this.a.i = this.b + i;
    }
}
