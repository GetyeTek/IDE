package I2;

import com.huawei.common.widget.date.WheelPicker;
import com.huawei.digitalpayment.customer.baselib.dialog.ScheduleDatePickerDialog;

public final /* synthetic */ class a implements WheelPicker.a {
    public final /* synthetic */ ScheduleDatePickerDialog a;
    public final /* synthetic */ int b;

    public /* synthetic */ a(ScheduleDatePickerDialog scheduleDatePickerDialog, int i) {
        this.a = scheduleDatePickerDialog;
        this.b = i;
    }

    public final void a(int i) {
        int i2 = this.b + i;
        ScheduleDatePickerDialog scheduleDatePickerDialog = this.a;
        scheduleDatePickerDialog.h = i2;
        scheduleDatePickerDialog.y0();
    }
}
