package k3;

import S1.e;
import S1.f;
import V1.h;
import W2.n;
import android.os.Bundle;
import androidx.camera.core.c;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.a;
import com.blankj.utilcode.util.k;
import com.google.gson.reflect.TypeToken;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.httplib.bean.Profiles;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import o0.b;

/* renamed from: k3.a  reason: case insensitive filesystem */
public final class C0033a {
    public static final C0033a e = new Object();
    public String a;
    public String b;
    public List<Profiles> c;
    public boolean d;

    /* renamed from: k3.a$a  reason: collision with other inner class name */
    public class C0004a extends TypeToken<List<Profiles>> {
    }

    public static String c(String str) {
        return c.a(str, LanguageUtils.getInstance().getCurrentLang());
    }

    @Deprecated
    public final List<Profiles> a() {
        try {
            if (this.c == null) {
                this.c = (List) k.b(n.b("").e(c("consumer_profiles")), new TypeToken().getType());
            }
        } catch (Exception e2) {
            e2.getMessage();
            h.b();
        }
        return this.c;
    }

    public final String b() {
        String str = this.a;
        if (str == null) {
            return n.b("").e(c("CURRENCY"));
        }
        return str;
    }

    public final void d() {
        f fVar = f.b;
        J.a();
        for (e onLogout : Collections.unmodifiableCollection(fVar.a)) {
            onLogout.onLogout();
        }
        E0.c.d();
        this.a = null;
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckedService", false);
        a.b();
        b.d(a.d(), "/mainModule/main", bundle, (Map) null);
    }
}
