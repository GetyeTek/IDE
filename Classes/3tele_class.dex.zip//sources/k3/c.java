package k3;

import M1.e;
import W2.n;
import android.text.TextUtils;

public final class c {
    public static final c c;
    public String a;
    public boolean b;

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, k3.c] */
    static {
        ? obj = new Object();
        obj.b = false;
        c = obj;
    }

    public final String a() {
        if (TextUtils.isEmpty(this.a)) {
            this.a = e.a.b(n.b("").e("businessToken"));
        }
        return this.a;
    }

    public final boolean b() {
        if (!this.b || TextUtils.isEmpty(this.a)) {
            return false;
        }
        return true;
    }

    public final void c(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.a = str;
            n.b("").g("businessToken", e.a.a(str), false);
            I3.c.b();
        }
    }
}
