package k3;

import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import java.util.Comparator;

/* renamed from: k3.b  reason: case insensitive filesystem */
public final /* synthetic */ class C0034b implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return ((BasicConfigResp.SettingsConfig) obj).getGroupOrder().compareTo(((BasicConfigResp.SettingsConfig) obj2).getGroupOrder());
    }
}
