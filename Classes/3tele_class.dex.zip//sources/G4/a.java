package G4;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.schedule.resp.AutomaticDisplayItem;
import com.huawei.digitalpayment.topup.R$color;
import com.huawei.digitalpayment.topup.R$id;

public final class a extends BaseQuickAdapter<AutomaticDisplayItem, BaseViewHolder> {
    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i;
        AutomaticDisplayItem automaticDisplayItem = (AutomaticDisplayItem) obj;
        baseViewHolder.setText(R$id.tvLabel, automaticDisplayItem.getLabel());
        int i2 = R$id.tvValue;
        baseViewHolder.setText(i2, automaticDisplayItem.getValue());
        Application a = J.a();
        if ("transactionType".equals(automaticDisplayItem.getKey())) {
            i = R$color.colorPrimary;
        } else {
            i = R$color.colorBlack;
        }
        baseViewHolder.setTextColor(i2, ContextCompat.getColor(a, i));
    }
}
