package P4;

import android.text.TextWatcher;

public class a implements TextWatcher {
    public final void beforeTextChanged(CharSequence charSequence, int i, int i2, int i5) {
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i5) {
    }
}
