package n3;

import C3.e;
import C3.g;
import F0.t;
import W2.a;
import android.view.View;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.customer.homev6.adapter.HomeRecyclerAdapter;
import com.huawei.digitalpayment.customer.homev6.adapter.LifeFunctionAdapter;
import com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomePopularServicesBinding;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import f2.c;
import java.util.List;

/* renamed from: n3.e  reason: case insensitive filesystem */
public final /* synthetic */ class C0049e implements OnItemClickListener {
    public final /* synthetic */ HomeRecyclerAdapter a;
    public final /* synthetic */ LifeFunctionAdapter b;
    public final /* synthetic */ Homev6HomePopularServicesBinding c;

    public /* synthetic */ C0049e(HomeRecyclerAdapter homeRecyclerAdapter, LifeFunctionAdapter lifeFunctionAdapter, Homev6HomePopularServicesBinding homev6HomePopularServicesBinding) {
        this.a = homeRecyclerAdapter;
        this.b = lifeFunctionAdapter;
        this.c = homev6HomePopularServicesBinding;
    }

    public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        HomeRecyclerAdapter homeRecyclerAdapter = this.a;
        if (!a.a(1000, view)) {
            HomeFunction homeFunction = (HomeFunction) this.b.getData().get(i);
            if ("showMore".equals(homeFunction.getFuncId())) {
                List<String> reportParams = homeFunction.getReportParams();
                if (!g.d()) {
                    ReportViewModel reportViewModel = c.b;
                    c.a.a.b("click_Lv1HomePg_specific_app", reportParams);
                }
                homeRecyclerAdapter.c = !homeRecyclerAdapter.c;
                homeRecyclerAdapter.notifyDataSetChanged();
                this.c.a.postDelayed(new t(homeRecyclerAdapter, 6), 200);
                return;
            }
            e.a(view, homeFunction);
        }
    }
}
