package n3;

import android.view.View;
import com.huawei.digitalpayment.customer.homev6.adapter.EditFavoriteFunctionAdapter;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;

/* renamed from: n3.a  reason: case insensitive filesystem */
public final /* synthetic */ class C0045a implements View.OnClickListener {
    public final /* synthetic */ EditFavoriteFunctionAdapter a;
    public final /* synthetic */ HomeFunction b;
    public final /* synthetic */ int c;

    public /* synthetic */ C0045a(EditFavoriteFunctionAdapter editFavoriteFunctionAdapter, HomeFunction homeFunction, int i) {
        this.a = editFavoriteFunctionAdapter;
        this.b = homeFunction;
        this.c = i;
    }

    public final void onClick(View view) {
        EditFavoriteFunctionAdapter.a aVar = this.a.c;
        if (aVar != null) {
            aVar.a(this.b, this.c);
        }
    }
}
