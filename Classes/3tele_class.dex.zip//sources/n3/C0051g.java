package n3;

import R1.a;
import android.annotation.SuppressLint;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.homev6.adapter.HomeFavFunctionAdapter;
import com.huawei.digitalpayment.customer.homev6.adapter.HomeRecyclerAdapter;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import java.util.List;

/* renamed from: n3.g  reason: case insensitive filesystem */
public final class C0051g implements a<List<HomeFunction>> {
    public final /* synthetic */ List a;
    public final /* synthetic */ HomeRecyclerAdapter b;

    public C0051g(HomeRecyclerAdapter homeRecyclerAdapter, List list) {
        this.b = homeRecyclerAdapter;
        this.a = list;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    @SuppressLint({"NotifyDataSetChanged"})
    public final void onSuccess(Object obj) {
        List list = (List) obj;
        List list2 = this.a;
        list2.clear();
        if (!J8.a.i(list)) {
            list2.addAll(list);
        }
        HomeFavFunctionAdapter homeFavFunctionAdapter = this.b.e;
        if (homeFavFunctionAdapter != null) {
            homeFavFunctionAdapter.notifyDataSetChanged();
        }
    }
}
