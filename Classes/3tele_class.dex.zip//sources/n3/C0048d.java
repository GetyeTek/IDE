package n3;

import C3.e;
import W2.a;
import android.view.View;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;

/* renamed from: n3.d  reason: case insensitive filesystem */
public final /* synthetic */ class C0048d implements CycleViewPager.c {
    public final void b(CycleViewPager.b bVar, View view) {
        HomeFunction homeFunction = (HomeFunction) bVar;
        if (!a.a(1000, view)) {
            e.b(homeFunction);
        }
    }
}
