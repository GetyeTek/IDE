package n3;

import C3.e;
import R1.b;
import V1.h;
import android.view.View;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;

/* renamed from: n3.b  reason: case insensitive filesystem */
public final class C0046b extends b {
    public final /* synthetic */ HomeFunction b;

    public C0046b(HomeFunction homeFunction) {
        this.b = homeFunction;
    }

    public final void a(View view) {
        try {
            e.a(view, this.b);
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
    }
}
