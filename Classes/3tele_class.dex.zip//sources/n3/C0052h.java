package n3;

import R1.b;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import java.util.Map;

/* renamed from: n3.h  reason: case insensitive filesystem */
public final class C0052h extends b {
    public final void a(View view) {
        o0.b.d((Activity) null, "/qrCodeModule/scan", (Bundle) null, (Map) null);
    }
}
