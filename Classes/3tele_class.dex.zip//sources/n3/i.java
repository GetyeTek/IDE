package n3;

import C3.g;
import R1.b;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.homev6.adapter.HomeRecyclerAdapter;
import f2.c;
import java.util.Map;

public final class i extends b {
    public final /* synthetic */ HomeRecyclerAdapter b;

    public i(HomeRecyclerAdapter homeRecyclerAdapter) {
        this.b = homeRecyclerAdapter;
    }

    public final void a(View view) {
        String[] strArr = new String[0];
        if (!g.d()) {
            ReportViewModel reportViewModel = c.b;
            c.a.a.c("click_Lv1HomePg_trx_details", strArr);
        }
        o0.b.d((Activity) null, BasicConfig.getInstance().getReferenceDataValueByKey("transactionDetailsUrl", this.b.a), (Bundle) null, (Map) null);
    }
}
