package n3;

import R1.b;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.huawei.digitalpayment.customer.homev6.adapter.HomeRecyclerAdapter;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import q3.C0059a;

/* renamed from: n3.f  reason: case insensitive filesystem */
public final class C0050f extends b {
    public final /* synthetic */ List b;
    public final /* synthetic */ HomeRecyclerAdapter c;

    public C0050f(HomeRecyclerAdapter homeRecyclerAdapter, List list) {
        this.c = homeRecyclerAdapter;
        this.b = list;
    }

    public final void a(View view) {
        HomeRecyclerAdapter homeRecyclerAdapter = this.c;
        Bundle bundle = new Bundle();
        List list = this.b;
        bundle.putSerializable("editFunctions", (Serializable) list);
        o0.b.d((Activity) null, "/mainModule/editFunction", bundle, (Map) null);
        C0059a.b.a = new C0051g(homeRecyclerAdapter, list);
    }
}
