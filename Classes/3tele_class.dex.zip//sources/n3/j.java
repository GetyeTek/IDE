package n3;

import C3.e;
import E0.c;
import android.view.View;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.homev6.adapter.PayRecyclerAdapter;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final /* synthetic */ class j implements OnItemClickListener {
    public final /* synthetic */ PayRecyclerAdapter a;
    public final /* synthetic */ List b;

    public /* synthetic */ j(PayRecyclerAdapter payRecyclerAdapter, List list) {
        this.a = payRecyclerAdapter;
        this.b = list;
    }

    public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        this.a.getClass();
        List list = this.b;
        HomeFunction homeFunction = (HomeFunction) list.get(i);
        if ("merchant://1000000009".equals(homeFunction.getExecute())) {
            Customer f = c.f();
            Map params = homeFunction.getParams();
            if (params == null) {
                params = new HashMap();
            }
            params.put("to", "customAmount");
            params.put("payeeConsumerId", f.getIdentityId());
            params.put("payeePhone", f.getMsisdn());
            params.put("payeeName", f.getNickName());
            params.put("payeeAvatar", f.getAvatar());
            homeFunction.setParams(params);
        }
        e.b((HomeFunction) list.get(i));
    }
}
