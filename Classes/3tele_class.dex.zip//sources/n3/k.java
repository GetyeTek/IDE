package n3;

import android.view.View;
import com.huawei.digitalpayment.customer.homev6.adapter.PayRecyclerAdapter;
import com.huawei.digitalpayment.customer.homev6.model.FunctionGroup;

public final /* synthetic */ class k implements View.OnClickListener {
    public final /* synthetic */ PayRecyclerAdapter a;
    public final /* synthetic */ FunctionGroup b;
    public final /* synthetic */ int c;

    public /* synthetic */ k(PayRecyclerAdapter payRecyclerAdapter, FunctionGroup functionGroup, int i) {
        this.a = payRecyclerAdapter;
        this.b = functionGroup;
        this.c = i;
    }

    public final void onClick(View view) {
        PayRecyclerAdapter payRecyclerAdapter = this.a;
        payRecyclerAdapter.getClass();
        FunctionGroup functionGroup = this.b;
        boolean isShow = functionGroup.isShow();
        int i = 0;
        while (true) {
            int size = payRecyclerAdapter.a.size();
            int i2 = this.c;
            if (i < size) {
                FunctionGroup functionGroup2 = payRecyclerAdapter.a.get(i);
                if (functionGroup2.isShow() && i != i2) {
                    functionGroup2.setShow(false);
                    payRecyclerAdapter.notifyItemChanged(i, "show");
                }
                i++;
            } else {
                functionGroup.setShow(!isShow);
                payRecyclerAdapter.notifyItemChanged(i2, "show");
                return;
            }
        }
    }
}
