package q6;

import com.huawei.kbz.jobqueue.BaseJob;

public final class f {
    public int a;
    public final int b;
    public Long c;
    public final String d;
    public final long e;
    public final long f;
    public final boolean g;
    public long h;
    public final transient BaseJob i;

    public f(Long l, int i2, String str, int i3, BaseJob baseJob, long j, long j2, long j3) {
        this.c = l;
        this.b = i2;
        this.d = str;
        this.a = i3;
        this.e = j;
        this.f = j2;
        this.i = baseJob;
        this.h = j3;
        this.g = baseJob.requiresNetwork();
    }

    public final boolean equals(Object obj) {
        Long l;
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        Long l2 = this.c;
        if (l2 == null || (l = fVar.c) == null) {
            return false;
        }
        return l2.equals(l);
    }

    public final int hashCode() {
        Long l = this.c;
        if (l == null) {
            return super.hashCode();
        }
        return l.intValue();
    }
}
