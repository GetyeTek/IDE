package q6;

import java.util.ArrayList;
import java.util.TreeSet;

public final class a {
    public ArrayList<String> a;
    public final TreeSet<String> b = new TreeSet<>();

    public final synchronized void a(String str) {
        if (this.b.add(str)) {
            this.a = null;
        }
    }

    public final synchronized ArrayList b() {
        try {
            if (this.a == null) {
                this.a = new ArrayList<>(this.b);
            }
        } catch (Throwable th) {
            while (true) {
                throw th;
            }
        }
        return this.a;
    }

    public final synchronized void c(String str) {
        if (this.b.remove(str)) {
            this.a = null;
        }
    }
}
