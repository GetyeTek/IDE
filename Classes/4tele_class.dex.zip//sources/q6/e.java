package q6;

import com.huawei.payment.base.App;

public final class e {
    public App a;
    public c b;

    public static class a {
        public static final e a = new Object();
    }
}
