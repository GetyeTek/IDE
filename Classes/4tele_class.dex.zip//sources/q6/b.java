package q6;

import V1.h;
import com.huawei.kbz.chat.message.customize.job.UpdateContactInfoJob;

public final /* synthetic */ class b implements Runnable {
    public final /* synthetic */ c a;
    public final /* synthetic */ long b;
    public final /* synthetic */ int c;
    public final /* synthetic */ long d;
    public final /* synthetic */ UpdateContactInfoJob e;

    public /* synthetic */ b(c cVar, long j, int i, long j2, UpdateContactInfoJob updateContactInfoJob) {
        this.a = cVar;
        this.b = j;
        this.c = i;
        this.d = j2;
        this.e = updateContactInfoJob;
    }

    public final void run() {
        long j = this.b;
        int i = this.c;
        long j2 = this.d;
        UpdateContactInfoJob updateContactInfoJob = this.e;
        c cVar = this.a;
        cVar.getClass();
        try {
            cVar.b(i, Math.max(0, j2 - ((System.nanoTime() - j) / 1000000)), updateContactInfoJob);
        } catch (Throwable unused) {
            "addJobInBackground received an exception. job class: ".concat(updateContactInfoJob.getClass().getSimpleName());
            h.b();
        }
    }
}
