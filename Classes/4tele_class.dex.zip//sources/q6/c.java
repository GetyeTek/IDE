package q6;

import V1.h;
import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.huawei.kbz.chat.message.customize.job.UpdateContactInfoJob;
import com.huawei.kbz.jobqueue.persistentQueue.sqlite.b;
import com.huawei.payment.base.App;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import v6.f;

public final class c {
    public final boolean a;
    public final Context b;
    public final u6.b c;
    public final r6.a d;
    public final r6.a e;
    public final a f;
    public final t6.a g;
    public final Object h = new Object();
    public final ConcurrentHashMap<Long, CountDownLatch> i;
    public final ConcurrentHashMap<Long, CountDownLatch> j;
    public final ScheduledExecutorService k;
    public final Object l = new Object();
    public final a m = new a();

    public class a implements Runnable {
        public a() {
        }

        public final void run() {
            c.this.e();
        }
    }

    public class b {
        public b() {
        }

        public final int a() {
            boolean z;
            int e;
            int e2;
            c cVar = c.this;
            if (cVar.c instanceof u6.b) {
                z = cVar.d();
            } else {
                z = true;
            }
            synchronized (cVar.e) {
                e = cVar.e.e(cVar.f.b(), z);
            }
            synchronized (cVar.d) {
                e2 = e + cVar.d.e(cVar.f.b(), z);
            }
            return e2;
        }

        /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x0070 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:36:0x008a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final q6.f b(int r11, java.util.concurrent.TimeUnit r12) {
            /*
                r10 = this;
                q6.c r0 = q6.c.this
                q6.f r0 = q6.c.a(r0)
                if (r0 == 0) goto L_0x0009
                return r0
            L_0x0009:
                long r1 = java.lang.System.nanoTime()
                long r3 = (long) r11
                long r11 = r12.toNanos(r3)
                long r11 = r11 + r1
                q6.c r1 = q6.c.this
                r2 = 0
                long r3 = r1.c(r2)
            L_0x001a:
                if (r0 != 0) goto L_0x0091
                long r5 = java.lang.System.nanoTime()
                int r1 = (r11 > r5 ? 1 : (r11 == r5 ? 0 : -1))
                if (r1 <= 0) goto L_0x0091
                q6.c r0 = q6.c.this
                boolean r1 = r0.a
                if (r1 == 0) goto L_0x002f
                q6.f r0 = q6.c.a(r0)
                goto L_0x0030
            L_0x002f:
                r0 = r2
            L_0x0030:
                if (r0 != 0) goto L_0x001a
                long r5 = java.lang.System.nanoTime()
                long r5 = r11 - r5
                r7 = 0
                int r1 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
                if (r1 > 0) goto L_0x003f
                goto L_0x001a
            L_0x003f:
                long r5 = java.lang.System.nanoTime()
                long r5 = r11 - r5
                int r1 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
                if (r1 > 0) goto L_0x004a
                goto L_0x001a
            L_0x004a:
                java.util.concurrent.TimeUnit r1 = java.util.concurrent.TimeUnit.NANOSECONDS
                long r5 = r1.toMillis(r5)
                long r5 = java.lang.Math.min(r3, r5)
                r7 = 1
                int r1 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
                if (r1 >= 0) goto L_0x005b
                goto L_0x001a
            L_0x005b:
                q6.c r1 = q6.c.this
                u6.b r7 = r1.c
                boolean r7 = r7 instanceof u6.b
                if (r7 == 0) goto L_0x0077
                java.lang.Object r7 = r1.h
                monitor-enter(r7)
                q6.c r1 = q6.c.this     // Catch:{ InterruptedException -> 0x0070 }
                java.lang.Object r1 = r1.h     // Catch:{ InterruptedException -> 0x0070 }
                r1.wait(r5)     // Catch:{ InterruptedException -> 0x0070 }
                goto L_0x0073
            L_0x006e:
                r11 = move-exception
                goto L_0x0075
            L_0x0070:
                V1.h.b()     // Catch:{ all -> 0x006e }
            L_0x0073:
                monitor-exit(r7)     // Catch:{ all -> 0x006e }
                goto L_0x001a
            L_0x0075:
                monitor-exit(r7)     // Catch:{ all -> 0x006e }
                throw r11
            L_0x0077:
                java.lang.Object r1 = r1.h
                monitor-enter(r1)
                q6.c r7 = q6.c.this     // Catch:{ InterruptedException -> 0x008a }
                java.lang.Object r7 = r7.h     // Catch:{ InterruptedException -> 0x008a }
                r8 = 500(0x1f4, double:2.47E-321)
                long r5 = java.lang.Math.min(r8, r5)     // Catch:{ InterruptedException -> 0x008a }
                r7.wait(r5)     // Catch:{ InterruptedException -> 0x008a }
                goto L_0x008d
            L_0x0088:
                r11 = move-exception
                goto L_0x008f
            L_0x008a:
                V1.h.b()     // Catch:{ all -> 0x0088 }
            L_0x008d:
                monitor-exit(r1)     // Catch:{ all -> 0x0088 }
                goto L_0x001a
            L_0x008f:
                monitor-exit(r1)     // Catch:{ all -> 0x0088 }
                throw r11
            L_0x0091:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: q6.c.b.b(int, java.util.concurrent.TimeUnit):q6.f");
        }

        public final void c(f fVar) {
            c cVar = c.this;
            cVar.getClass();
            h.b();
            if (fVar.i.isPersistent()) {
                synchronized (cVar.d) {
                    cVar.d.f(fVar);
                }
            } else {
                synchronized (cVar.e) {
                    cVar.e.f(fVar);
                }
            }
            String str = fVar.d;
            if (str != null) {
                cVar.f.c(str);
            }
        }

        public final void d(f fVar) {
            c cVar = c.this;
            cVar.getClass();
            if (fVar.i.isPersistent()) {
                synchronized (cVar.d) {
                    cVar.d.a(fVar);
                }
            } else {
                synchronized (cVar.e) {
                    cVar.e.a(fVar);
                }
            }
            String str = fVar.d;
            if (str != null) {
                cVar.f.c(str);
            }
        }
    }

    /* renamed from: q6.c$c  reason: collision with other inner class name */
    public static class C0014c {
        public b.C0012b a;
    }

    public c(App app, s6.a aVar) {
        b bVar = new b();
        this.b = app.getApplicationContext();
        this.a = true;
        this.f = new a();
        long nanoTime = System.nanoTime();
        C0014c cVar = aVar.d;
        cVar.getClass();
        this.d = new r6.a(new com.huawei.kbz.jobqueue.persistentQueue.sqlite.b(app, nanoTime, cVar.a));
        aVar.d.getClass();
        this.e = new r6.a(new f(nanoTime));
        this.i = new ConcurrentHashMap<>();
        this.j = new ConcurrentHashMap<>();
        u6.b bVar2 = aVar.e;
        this.c = bVar2;
        if (bVar2 instanceof u6.b) {
            bVar2.a = this;
            Context context = bVar2.b;
            if (context != null) {
                context.getApplicationContext().registerReceiver(new u6.a(bVar2), new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
            }
        }
        this.g = new t6.a(aVar, bVar);
        this.k = Executors.newSingleThreadScheduledExecutor();
        if (!this.a) {
            this.a = true;
            e();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x003a, code lost:
        if (r0 == false) goto L_0x0050;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x003c, code lost:
        r5 = r5.i;
        r0 = r4.c;
        r0.getClass();
        r5 = r5.get(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0049, code lost:
        if (r5 != null) goto L_0x004c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:?, code lost:
        r5.await();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0050, code lost:
        r5 = r5.j;
        r0 = r4.c;
        r0.getClass();
        r5 = r5.get(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x005d, code lost:
        if (r5 != null) goto L_0x0060;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:?, code lost:
        r5.await();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:?, code lost:
        return r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:?, code lost:
        return r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:?, code lost:
        return r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:?, code lost:
        return r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:?, code lost:
        return r4;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static q6.f a(q6.c r5) {
        /*
            boolean r0 = r5.d()
            java.lang.Object r1 = r5.l
            monitor-enter(r1)
            q6.a r2 = r5.f     // Catch:{ all -> 0x0028 }
            java.util.ArrayList r2 = r2.b()     // Catch:{ all -> 0x0028 }
            r6.a r3 = r5.e     // Catch:{ all -> 0x0028 }
            monitor-enter(r3)     // Catch:{ all -> 0x0028 }
            r6.a r4 = r5.e     // Catch:{ all -> 0x0064 }
            q6.f r4 = r4.c(r2, r0)     // Catch:{ all -> 0x0064 }
            monitor-exit(r3)     // Catch:{ all -> 0x0064 }
            if (r4 != 0) goto L_0x002a
            r6.a r3 = r5.d     // Catch:{ all -> 0x0028 }
            monitor-enter(r3)     // Catch:{ all -> 0x0028 }
            r6.a r4 = r5.d     // Catch:{ all -> 0x0025 }
            q6.f r4 = r4.c(r2, r0)     // Catch:{ all -> 0x0025 }
            monitor-exit(r3)     // Catch:{ all -> 0x0025 }
            r0 = 1
            goto L_0x002b
        L_0x0025:
            r5 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0025 }
            throw r5     // Catch:{ all -> 0x0028 }
        L_0x0028:
            r5 = move-exception
            goto L_0x0067
        L_0x002a:
            r0 = 0
        L_0x002b:
            if (r4 != 0) goto L_0x0030
            monitor-exit(r1)     // Catch:{ all -> 0x0028 }
            r4 = 0
            goto L_0x0063
        L_0x0030:
            java.lang.String r2 = r4.d     // Catch:{ all -> 0x0028 }
            if (r2 == 0) goto L_0x0039
            q6.a r3 = r5.f     // Catch:{ all -> 0x0028 }
            r3.a(r2)     // Catch:{ all -> 0x0028 }
        L_0x0039:
            monitor-exit(r1)     // Catch:{ all -> 0x0028 }
            if (r0 == 0) goto L_0x0050
            java.util.concurrent.ConcurrentHashMap<java.lang.Long, java.util.concurrent.CountDownLatch> r5 = r5.i
            java.lang.Long r0 = r4.c
            r0.getClass()
            java.lang.Object r5 = r5.get(r0)
            java.util.concurrent.CountDownLatch r5 = (java.util.concurrent.CountDownLatch) r5
            if (r5 != 0) goto L_0x004c
            goto L_0x0063
        L_0x004c:
            r5.await()     // Catch:{ InterruptedException -> 0x0063 }
            goto L_0x0063
        L_0x0050:
            java.util.concurrent.ConcurrentHashMap<java.lang.Long, java.util.concurrent.CountDownLatch> r5 = r5.j
            java.lang.Long r0 = r4.c
            r0.getClass()
            java.lang.Object r5 = r5.get(r0)
            java.util.concurrent.CountDownLatch r5 = (java.util.concurrent.CountDownLatch) r5
            if (r5 != 0) goto L_0x0060
            goto L_0x0063
        L_0x0060:
            r5.await()     // Catch:{ InterruptedException -> 0x0063 }
        L_0x0063:
            return r4
        L_0x0064:
            r5 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0064 }
            throw r5     // Catch:{ all -> 0x0028 }
        L_0x0067:
            monitor-exit(r1)     // Catch:{ all -> 0x0028 }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: q6.c.a(q6.c):q6.f");
    }

    @Deprecated
    public final long b(int i2, long j2, UpdateContactInfoJob updateContactInfoJob) {
        long j3;
        long j4;
        if (j2 > 0) {
            j3 = (1000000 * j2) + System.nanoTime();
        } else {
            j3 = Long.MIN_VALUE;
        }
        f fVar = new f((Long) null, i2, updateContactInfoJob.getRunGroupId(), 0, updateContactInfoJob, System.nanoTime(), j3, Long.MIN_VALUE);
        if (updateContactInfoJob.isPersistent()) {
            synchronized (this.d) {
                j4 = this.d.b(fVar);
                this.i.put(Long.valueOf(j4), new CountDownLatch(1));
            }
        } else {
            synchronized (this.e) {
                j4 = this.e.b(fVar);
                this.j.put(Long.valueOf(j4), new CountDownLatch(1));
            }
        }
        Locale locale = Locale.ENGLISH;
        updateContactInfoJob.getRunGroupId();
        updateContactInfoJob.isPersistent();
        updateContactInfoJob.requiresNetwork();
        h.b();
        updateContactInfoJob.onAdded();
        if (updateContactInfoJob.isPersistent()) {
            synchronized (this.d) {
                ConcurrentHashMap<Long, CountDownLatch> concurrentHashMap = this.i;
                CountDownLatch countDownLatch = concurrentHashMap.get(Long.valueOf(j4));
                if (countDownLatch != null) {
                    countDownLatch.countDown();
                }
                concurrentHashMap.remove(Long.valueOf(j4));
            }
        } else {
            synchronized (this.e) {
                ConcurrentHashMap<Long, CountDownLatch> concurrentHashMap2 = this.j;
                CountDownLatch countDownLatch2 = concurrentHashMap2.get(Long.valueOf(j4));
                if (countDownLatch2 != null) {
                    countDownLatch2.countDown();
                }
                concurrentHashMap2.remove(Long.valueOf(j4));
            }
        }
        e();
        return j4;
    }

    public final long c(Boolean bool) {
        Long d2;
        Long d3;
        boolean z;
        if (bool == null) {
            if (this.c instanceof u6.b) {
                z = d();
            } else {
                z = true;
            }
            bool = Boolean.valueOf(z);
        }
        synchronized (this.e) {
            d2 = this.e.d(bool.booleanValue());
        }
        if (d2 == null || d2.longValue() > System.nanoTime()) {
            synchronized (this.d) {
                d3 = this.d.d(bool.booleanValue());
            }
            if (d3 != null && (d2 == null || d3.longValue() < d2.longValue())) {
                d2 = d3;
            }
            if (d2 == null) {
                return Long.MAX_VALUE;
            }
            if (d2.longValue() < System.nanoTime()) {
                e();
                return 0;
            }
            long ceil = (long) Math.ceil(((double) (d2.longValue() - System.nanoTime())) / 1000000.0d);
            this.k.schedule(this.m, ceil, TimeUnit.MILLISECONDS);
            return ceil;
        }
        e();
        return 0;
    }

    public final boolean d() {
        NetworkInfo activeNetworkInfo;
        if (this.c == null || ((activeNetworkInfo = ((ConnectivityManager) this.b.getSystemService("connectivity")).getActiveNetworkInfo()) != null && activeNetworkInfo.isConnectedOrConnecting())) {
            return true;
        }
        return false;
    }

    public final void e() {
        synchronized (this.h) {
            this.h.notifyAll();
        }
        this.g.d(false, true);
    }
}
