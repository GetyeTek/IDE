package q6;

public final class g {
    public String a;
    public boolean b;
    public boolean c;
}
