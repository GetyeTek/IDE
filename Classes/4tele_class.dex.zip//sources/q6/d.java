package q6;

import java.util.ArrayList;

public interface d {
    void a(f fVar);

    long b(f fVar);

    f c(ArrayList arrayList, boolean z);

    int count();

    Long d(boolean z);

    int e(ArrayList arrayList, boolean z);

    long f(f fVar);
}
