package v6;

import com.huawei.kbz.jobqueue.nonPersistentQueue.MergedQueue;
import com.huawei.kbz.jobqueue.nonPersistentQueue.a;
import java.util.ArrayList;
import q6.d;

public final class f implements d {
    public long a = -2147483648L;
    public final a b;
    public final long c;

    /* JADX WARNING: type inference failed for: r0v1, types: [v6.e, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r3v1, types: [com.huawei.kbz.jobqueue.nonPersistentQueue.a, com.huawei.kbz.jobqueue.nonPersistentQueue.MergedQueue] */
    public f(long j) {
        ? obj = new Object();
        this.c = j;
        this.b = new MergedQueue(obj, new g(obj));
    }

    public final void a(q6.f fVar) {
        this.b.a(fVar);
    }

    public final synchronized long b(q6.f fVar) {
        long j = this.a + 1;
        this.a = j;
        fVar.c = Long.valueOf(j);
        this.b.b(fVar);
        return fVar.c.longValue();
    }

    public final q6.f c(ArrayList arrayList, boolean z) {
        q6.f fVar;
        a aVar = this.b;
        if (z) {
            fVar = aVar.d(arrayList);
        } else {
            aVar.getClass();
            if (MergedQueue.SetId.S1 == MergedQueue.SetId.S0) {
                fVar = aVar.a.d(arrayList);
            } else {
                fVar = aVar.b.d(arrayList);
            }
        }
        if (fVar == null) {
            return fVar;
        }
        if (fVar.f > System.nanoTime()) {
            return null;
        }
        fVar.h = this.c;
        fVar.a++;
        aVar.a(fVar);
        return fVar;
    }

    public final int count() {
        return this.b.size();
    }

    public final Long d(boolean z) {
        q6.f fVar;
        a aVar = this.b;
        if (z) {
            fVar = aVar.d((ArrayList) null);
        } else {
            aVar.getClass();
            if (MergedQueue.SetId.S1 == MergedQueue.SetId.S0) {
                fVar = aVar.a.d((ArrayList) null);
            } else {
                fVar = aVar.b.d((ArrayList) null);
            }
        }
        if (fVar == null) {
            return null;
        }
        return Long.valueOf(fVar.f);
    }

    public final int e(ArrayList arrayList, boolean z) {
        b bVar;
        a aVar = this.b;
        aVar.getClass();
        long nanoTime = System.nanoTime();
        if (z) {
            bVar = aVar.f(MergedQueue.SetId.S0, nanoTime, arrayList);
            bVar.a(aVar.f(MergedQueue.SetId.S1, nanoTime, arrayList));
        } else {
            bVar = aVar.f(MergedQueue.SetId.S1, nanoTime, arrayList);
        }
        return bVar.a;
    }

    public final long f(q6.f fVar) {
        a(fVar);
        fVar.h = Long.MIN_VALUE;
        this.b.b(fVar);
        return fVar.c.longValue();
    }
}
