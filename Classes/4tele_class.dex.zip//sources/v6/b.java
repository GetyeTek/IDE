package v6;

import java.util.HashSet;

public final class b {
    public int a;
    public HashSet b;

    public b(int i, HashSet hashSet) {
        this.a = i;
        this.b = hashSet;
    }

    public final void a(b bVar) {
        HashSet<String> hashSet;
        HashSet hashSet2 = this.b;
        if (hashSet2 == null || (hashSet = bVar.b) == null) {
            this.a += bVar.a;
            if (hashSet2 == null) {
                this.b = bVar.b;
                return;
            }
            return;
        }
        int i = 0;
        for (String add : hashSet) {
            if (!this.b.add(add)) {
                i++;
            }
        }
        this.a = (this.a + bVar.a) - i;
    }
}
