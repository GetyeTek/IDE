package v6;

import java.util.Comparator;
import q6.f;

public final class g implements Comparator<f> {
    public final e a;

    public g(e eVar) {
        this.a = eVar;
    }

    public final int compare(Object obj, Object obj2) {
        boolean z;
        f fVar = (f) obj;
        f fVar2 = (f) obj2;
        long nanoTime = System.nanoTime();
        long j = fVar.f;
        boolean z2 = false;
        if (j <= nanoTime) {
            z = true;
        } else {
            z = false;
        }
        long j2 = fVar2.f;
        if (j2 <= nanoTime) {
            z2 = true;
        }
        e eVar = this.a;
        if (z) {
            if (z2) {
                return eVar.compare(fVar, fVar2);
            }
        } else if (!z2) {
            int i = (j > j2 ? 1 : (j == j2 ? 0 : -1));
            if (i >= 0) {
                if (i > 0) {
                    return 1;
                }
                return eVar.compare(fVar, fVar2);
            }
        } else if (z) {
            return eVar.compare(fVar, fVar2);
        } else {
            return 1;
        }
        return -1;
    }
}
