package v6;

import java.util.ArrayList;
import q6.f;

public interface c {
    boolean a(f fVar);

    boolean b(f fVar);

    b c(ArrayList arrayList);

    f d(ArrayList arrayList);

    b e(long j, ArrayList arrayList);

    int size();
}
