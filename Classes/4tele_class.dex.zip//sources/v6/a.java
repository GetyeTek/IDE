package v6;

import java.util.Comparator;
import q6.f;

public final class a implements Comparator<f> {
    public final e a;

    public a(e eVar) {
        this.a = eVar;
    }

    public final int compare(Object obj, Object obj2) {
        f fVar = (f) obj;
        f fVar2 = (f) obj2;
        int i = (fVar.f > fVar2.f ? 1 : (fVar.f == fVar2.f ? 0 : -1));
        if (i < 0) {
            return -1;
        }
        if (i > 0) {
            return 1;
        }
        return this.a.compare(fVar, fVar2);
    }
}
