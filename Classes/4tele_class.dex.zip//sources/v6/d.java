package v6;

import V1.h;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;
import q6.f;

public final class d implements c {
    public final TreeSet<f> a;
    public final HashMap b = new HashMap();
    public final HashMap c = new HashMap();

    public d(Comparator<f> comparator) {
        this.a = new TreeSet<>(comparator);
    }

    public final boolean a(f fVar) {
        boolean remove = this.a.remove(fVar);
        if (remove) {
            this.c.remove(fVar.c);
            String str = fVar.d;
            if (str != null) {
                HashMap hashMap = this.b;
                Integer num = (Integer) hashMap.get(str);
                if (num == null || num.intValue() == 0) {
                    h.b();
                } else if (num.intValue() - 1 == 0) {
                    hashMap.remove(str);
                }
            }
        }
        return remove;
    }

    public final boolean b(f fVar) {
        if (fVar.c != null) {
            TreeSet<f> treeSet = this.a;
            boolean add = treeSet.add(fVar);
            if (!add) {
                a(fVar);
                add = treeSet.add(fVar);
            }
            if (add) {
                this.c.put(fVar.c, fVar);
                String str = fVar.d;
                if (str != null) {
                    HashMap hashMap = this.b;
                    if (!hashMap.containsKey(str)) {
                        hashMap.put(str, 1);
                    } else {
                        hashMap.put(str, Integer.valueOf(((Integer) hashMap.get(str)).intValue() + 1));
                    }
                }
            }
            return add;
        }
        throw new RuntimeException("cannot add job jobsHolder w/o an ID");
    }

    public final b c(ArrayList arrayList) {
        int size = this.b.size();
        TreeSet<f> treeSet = this.a;
        HashSet hashSet = null;
        if (size == 0) {
            return new b(treeSet.size(), (HashSet) null);
        }
        Iterator<f> it = treeSet.iterator();
        int i = 0;
        while (it.hasNext()) {
            f next = it.next();
            i++;
            String str = next.d;
            if (str != null && (arrayList == null || !arrayList.contains(str))) {
                String str2 = next.d;
                if (hashSet == null) {
                    hashSet = new HashSet();
                    hashSet.add(str2);
                } else {
                    boolean add = hashSet.add(str2);
                }
            }
        }
        return new b(i, hashSet);
    }

    /* JADX WARNING: Removed duplicated region for block: B:7:0x0016  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final q6.f d(java.util.ArrayList r5) {
        /*
            r4 = this;
            java.util.TreeSet<q6.f> r0 = r4.a
            r1 = 0
            if (r5 == 0) goto L_0x002a
            int r2 = r5.size()
            if (r2 != 0) goto L_0x000c
            goto L_0x002a
        L_0x000c:
            java.util.Iterator r0 = r0.iterator()
        L_0x0010:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x0029
            java.lang.Object r2 = r0.next()
            q6.f r2 = (q6.f) r2
            java.lang.String r3 = r2.d
            if (r3 != 0) goto L_0x0021
            return r2
        L_0x0021:
            boolean r3 = r5.contains(r3)
            if (r3 == 0) goto L_0x0028
            goto L_0x0010
        L_0x0028:
            return r2
        L_0x0029:
            return r1
        L_0x002a:
            int r5 = r0.size()
            r2 = 1
            if (r5 >= r2) goto L_0x0032
            goto L_0x0039
        L_0x0032:
            java.lang.Object r5 = r0.first()
            r1 = r5
            q6.f r1 = (q6.f) r1
        L_0x0039:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: v6.d.d(java.util.ArrayList):q6.f");
    }

    public final b e(long j, ArrayList arrayList) {
        HashSet hashSet;
        String str;
        int size = this.b.keySet().size();
        if (size > 0) {
            hashSet = new HashSet();
        } else {
            hashSet = null;
        }
        Iterator<f> it = this.a.iterator();
        int i = 0;
        while (it.hasNext()) {
            f next = it.next();
            if (next.f < j && ((str = next.d) == null || ((arrayList == null || !arrayList.contains(str)) && size > 0 && hashSet.add(str)))) {
                i++;
            }
        }
        return new b(i, hashSet);
    }

    public final int size() {
        return this.a.size();
    }
}
