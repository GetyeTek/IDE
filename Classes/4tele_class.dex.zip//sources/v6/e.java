package v6;

import java.util.Comparator;
import q6.f;

public final /* synthetic */ class e implements Comparator {
    public final int compare(Object obj, Object obj2) {
        f fVar = (f) obj;
        f fVar2 = (f) obj2;
        int compare = Integer.compare(fVar2.b, fVar.b);
        if (compare != 0) {
            return compare;
        }
        int i = -Long.compare(fVar2.e, fVar.e);
        if (i != 0) {
            return i;
        }
        return -Long.compare(fVar2.c.longValue(), fVar.c.longValue());
    }
}
