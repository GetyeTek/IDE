package U5;

import com.shinemo.chat.CYConversation;

public final class b {
    public static String a(CYConversation.CYConversationType cYConversationType) {
        switch (a.a[cYConversationType.ordinal()]) {
            case 1:
                return "Official";
            case 2:
                return "GroupChat";
            case 3:
                return "CustomerServiceEntrance";
            case 4:
                return "CustomerService";
            case 5:
                return "officialEntrance";
            case 6:
                return "content";
            default:
                return "Single";
        }
    }
}
