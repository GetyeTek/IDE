package W4;

import W1.b;
import android.view.View;
import com.huawei.ethiopia.finance.loading.FinanceGlobalLoadingStatusView;

public final class a implements b.a {
    public final View a(b.b bVar, View view, int i) {
        FinanceGlobalLoadingStatusView financeGlobalLoadingStatusView;
        if (view instanceof FinanceGlobalLoadingStatusView) {
            financeGlobalLoadingStatusView = (FinanceGlobalLoadingStatusView) view;
        } else {
            financeGlobalLoadingStatusView = null;
        }
        if (financeGlobalLoadingStatusView == null) {
            financeGlobalLoadingStatusView = new FinanceGlobalLoadingStatusView(bVar.a, bVar.b);
        }
        financeGlobalLoadingStatusView.setStatus(i);
        bVar.getClass();
        financeGlobalLoadingStatusView.setMsgViewVisibility(!"hide_loading_status_msg".equals((Object) null));
        return financeGlobalLoadingStatusView;
    }
}
