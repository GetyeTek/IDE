package x6;

import E6.e;
import V1.h;
import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.c;
import com.huawei.digitalpayment.customer.httplib.pic.GlideApp;
import com.huawei.kbz.chat.R$color;
import com.huawei.kbz.chat.R$id;
import com.huawei.kbz.chat.R$layout;
import com.huawei.kbz.chat.message.customize.CardMessageContent;
import com.huawei.kbz.official_account.SearchHistoryArticleActivity;
import h6.C0096a;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class a extends BaseAdapter {
    public ArrayList a;
    public SearchHistoryArticleActivity b;
    public String c;

    /* renamed from: x6.a$a  reason: collision with other inner class name */
    public class C0020a implements View.OnClickListener {
        public final /* synthetic */ List a;

        public C0020a(a aVar, List list) {
            this.a = list;
        }

        public final void onClick(View view) {
            String str = ((O5.a) this.a.get(0)).c;
            if (!TextUtils.isEmpty(str)) {
                if (str.toLowerCase(Locale.ENGLISH).startsWith("http")) {
                    C0096a.b().getClass();
                } else {
                    o0.b.d((Activity) null, str, (Bundle) null, (Map) null);
                }
            }
        }
    }

    public class b {
        public TextView a;
        public TextView b;
        public TextView c;
        public ImageView d;
        public View e;
    }

    public final int getCount() {
        ArrayList arrayList = this.a;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }

    public final Object getItem(int i) {
        return this.a.get(i);
    }

    public final long getItemId(int i) {
        return (long) i;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.content.Context, com.huawei.kbz.official_account.SearchHistoryArticleActivity, com.huawei.kbz.base.BaseActivity] */
    /* JADX WARNING: type inference failed for: r4v6, types: [v.h, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r12v5, types: [java.lang.Object, x6.a$b] */
    public final View getView(int i, View view, ViewGroup viewGroup) {
        b bVar;
        ? r0 = this.b;
        int i2 = 0;
        if (view == null) {
            view = LayoutInflater.from(r0).inflate(R$layout.search_result_layout, viewGroup, false);
            ? obj = new Object();
            obj.a = (TextView) view.findViewById(R$id.article_title);
            obj.b = (TextView) view.findViewById(R$id.article_time);
            obj.c = (TextView) view.findViewById(R$id.article_read_count);
            obj.d = (ImageView) view.findViewById(R$id.article_icon);
            obj.e = view.findViewById(R$id.line);
            view.setTag(obj);
            bVar = obj;
        } else {
            bVar = (b) view.getTag();
        }
        bVar.b.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Long.valueOf(((CardMessageContent) this.a.get(i)).getPubTime())));
        List<O5.a> contentList = ((CardMessageContent) this.a.get(i)).getContentList();
        String str = contentList.get(0).a;
        Locale locale = Locale.ENGLISH;
        int indexOf = str.toLowerCase(locale).indexOf(this.c.toLowerCase(locale));
        if (TextUtils.isEmpty(this.c) || indexOf < 0) {
            bVar.a.setText(str);
        } else {
            SpannableString spannableString = new SpannableString(str);
            spannableString.setSpan(new ForegroundColorSpan(r0.getResources().getColor(R$color.them_blue)), indexOf, this.c.length() + indexOf, 33);
            bVar.a.setText(spannableString);
        }
        bVar.c.setText(String.valueOf(((CardMessageContent) this.a.get(i)).getReadCount()));
        ImageView imageView = bVar.d;
        imageView.setTag("RECYCLE_VIEW_HISTORY_TAG" + i);
        if (!TextUtils.isEmpty(contentList.get(0).b)) {
            ImageView imageView2 = bVar.d;
            String str2 = contentList.get(0).b;
            String a2 = android.support.v4.media.b.a(i, "RECYCLE_VIEW_HISTORY_TAG");
            if (!TextUtils.isEmpty(str2)) {
                if (str2.endsWith(".webp")) {
                    GlideApp.with(r0).load(str2).optionalTransform(new Object()).into(imageView2);
                } else if (str2.toLowerCase(locale).startsWith("http")) {
                    c.h(r0).load(str2).into(new e(imageView2, a2));
                } else {
                    Resources resources = r0.getResources();
                    int identifier = resources.getIdentifier(str2, "mipmap", r0.getPackageName());
                    if (identifier <= 0) {
                        identifier = resources.getIdentifier(str2, "drawable", r0.getPackageName());
                    }
                    if (identifier != -1) {
                        try {
                            imageView2.setImageDrawable(resources.getDrawable(identifier));
                        } catch (Exception e) {
                            e.toString();
                            h.b();
                        }
                    }
                }
            }
        }
        View view2 = bVar.e;
        if (i == this.a.size() - 1) {
            i2 = 4;
        }
        view2.setVisibility(i2);
        view.setOnClickListener(new C0020a(this, contentList));
        return view;
    }
}
