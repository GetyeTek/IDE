package C5;

import java.util.ArrayList;

public final class b {
    public static final b b;
    public ArrayList a;

    /* JADX WARNING: type inference failed for: r0v0, types: [C5.b, java.lang.Object] */
    static {
        ? obj = new Object();
        ArrayList arrayList = new ArrayList();
        obj.a = arrayList;
        arrayList.add(new Object());
        b = obj;
    }
}
