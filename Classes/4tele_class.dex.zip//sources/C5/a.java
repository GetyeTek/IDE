package C5;

public interface a {
}
