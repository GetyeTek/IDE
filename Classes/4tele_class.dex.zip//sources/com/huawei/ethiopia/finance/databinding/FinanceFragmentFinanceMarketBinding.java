package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public abstract class FinanceFragmentFinanceMarketBinding extends ViewDataBinding {
    @NonNull
    public final RecyclerView a;

    public FinanceFragmentFinanceMarketBinding(DataBindingComponent dataBindingComponent, View view, RecyclerView recyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = recyclerView;
    }
}
