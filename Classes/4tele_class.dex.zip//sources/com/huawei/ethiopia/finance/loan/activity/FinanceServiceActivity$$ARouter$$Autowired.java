package com.huawei.ethiopia.finance.loan.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class FinanceServiceActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.ethiopia.finance.loan.activity.FinanceServiceActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (FinanceServiceActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.bankCode;
        } else {
            str = r4.getIntent().getExtras().getString("bankCode", r4.bankCode);
        }
        r4.bankCode = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.bankName;
        } else {
            str2 = r4.getIntent().getExtras().getString("bankName", r4.bankName);
        }
        r4.bankName = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.bankIcon;
        } else {
            str3 = r4.getIntent().getExtras().getString("bankIcon", r4.bankIcon);
        }
        r4.bankIcon = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.selectOverDraft;
        } else {
            str4 = r4.getIntent().getExtras().getString("selectOverDraft", r4.selectOverDraft);
        }
        r4.selectOverDraft = str4;
    }
}
