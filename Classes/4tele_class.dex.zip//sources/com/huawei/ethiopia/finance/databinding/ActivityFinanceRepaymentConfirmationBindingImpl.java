package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class ActivityFinanceRepaymentConfirmationBindingImpl extends ActivityFinanceRepaymentConfirmationBinding {
    @Nullable
    public static final SparseIntArray g;
    public long f = -1;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.tv_title, 1);
        sparseIntArray.put(R$id.ll_amount, 2);
        sparseIntArray.put(R$id.tvReceiveNum, 3);
        sparseIntArray.put(R$id.tvCurrency, 4);
        sparseIntArray.put(R$id.recyclerview, 5);
        sparseIntArray.put(R$id.ll_btn, 6);
        sparseIntArray.put(R$id.lb_confirm, 7);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActivityFinanceRepaymentConfirmationBindingImpl(@androidx.annotation.NonNull android.view.View r12, @androidx.annotation.Nullable androidx.databinding.DataBindingComponent r13) {
        /*
            r11 = this;
            android.util.SparseIntArray r0 = g
            r1 = 8
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r13, r12, r1, r2, r0)
            r1 = 7
            r1 = r0[r1]
            r6 = r1
            com.huawei.common.widget.LoadingButton r6 = (com.huawei.common.widget.LoadingButton) r6
            r1 = 2
            r1 = r0[r1]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1 = 6
            r1 = r0[r1]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1 = 5
            r1 = r0[r1]
            r7 = r1
            com.huawei.common.widget.round.RoundRecyclerView r7 = (com.huawei.common.widget.round.RoundRecyclerView) r7
            r1 = 4
            r1 = r0[r1]
            r8 = r1
            android.widget.TextView r8 = (android.widget.TextView) r8
            r1 = 3
            r1 = r0[r1]
            r9 = r1
            android.widget.TextView r9 = (android.widget.TextView) r9
            r1 = 1
            r1 = r0[r1]
            r10 = r1
            android.widget.TextView r10 = (android.widget.TextView) r10
            r3 = r11
            r4 = r13
            r5 = r12
            r3.<init>(r4, r5, r6, r7, r8, r9, r10)
            r3 = -1
            r11.f = r3
            r13 = 0
            r13 = r0[r13]
            android.widget.LinearLayout r13 = (android.widget.LinearLayout) r13
            r13.setTag(r2)
            r11.setRootTag(r12)
            r11.invalidateAll()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.ActivityFinanceRepaymentConfirmationBindingImpl.<init>(android.view.View, androidx.databinding.DataBindingComponent):void");
    }

    public final void executeBindings() {
        synchronized (this) {
            this.f = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.f != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.f = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
