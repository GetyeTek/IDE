package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;
import java.util.List;

public class CreditContractsInfo extends BaseResp {
    private CreditPayContractsInfo contractInfo;
    private List<TransactionInfo> transactionItems;

    public CreditPayContractsInfo getContractInfo() {
        return this.contractInfo;
    }

    public List<TransactionInfo> getTransactionItems() {
        return this.transactionItems;
    }

    public void setContractInfo(CreditPayContractsInfo creditPayContractsInfo) {
        this.contractInfo = creditPayContractsInfo;
    }

    public void setTransactionItems(List<TransactionInfo> list) {
        this.transactionItems = list;
    }
}
