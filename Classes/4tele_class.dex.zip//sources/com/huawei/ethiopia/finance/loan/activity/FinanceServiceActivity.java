package com.huawei.ethiopia.finance.loan.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceBinding;
import com.huawei.ethiopia.finance.loan.fragment.FinanceServiceFragment;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceServiceViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.ArrayList;
import java.util.List;

@Deprecated
public class FinanceServiceActivity extends DataBindingActivity<FinanceActivityFinanceServiceBinding, FinanceServiceViewModel> {
    public static final /* synthetic */ int d = 0;
    @Autowired
    String bankCode;
    @Autowired
    String bankIcon;
    @Autowired
    String bankName;
    @Autowired
    String selectOverDraft;

    public class a implements View.OnClickListener {
        public a() {
        }

        public final void onClick(View view) {
            int i = FinanceServiceActivity.d;
            FinanceServiceActivity.this.E0(0);
        }
    }

    public class b implements View.OnClickListener {
        public b() {
        }

        public final void onClick(View view) {
            int i = FinanceServiceActivity.d;
            FinanceServiceActivity.this.E0(0);
        }
    }

    public class c implements View.OnClickListener {
        public c() {
        }

        public final void onClick(View view) {
            int i = FinanceServiceActivity.d;
            FinanceServiceActivity.this.E0(1);
        }
    }

    public class d implements View.OnClickListener {
        public d() {
        }

        public final void onClick(View view) {
            int i = FinanceServiceActivity.d;
            FinanceServiceActivity.this.E0(1);
        }
    }

    public class e extends ViewPager2.OnPageChangeCallback {
        public e() {
        }

        public final void onPageSelected(int i) {
            int i2 = FinanceServiceActivity.d;
            FinanceServiceActivity.this.E0(i);
        }
    }

    public final int C0() {
        return R$layout.finance_activity_finance_service;
    }

    public final void E0(int i) {
        int i2;
        this.b.e.setCurrentItem(i);
        RoundTextView roundTextView = this.b.b;
        int i3 = 8;
        if (i == 0) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        roundTextView.setVisibility(i2);
        RoundTextView roundTextView2 = this.b.a;
        if (i != 0) {
            i3 = 0;
        }
        roundTextView2.setVisibility(i3);
    }

    public final void F0() {
        FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(this);
        this.b.e.setAdapter(fragmentStateAdapter);
        ArrayList arrayList = new ArrayList();
        arrayList.add(FinanceServiceFragment.y0("Dashen", this.selectOverDraft));
        arrayList.add(FinanceServiceFragment.y0("CBE", this.selectOverDraft));
        fragmentStateAdapter.a(arrayList);
        this.b.d.setOnClickListener(new a());
        this.b.b.setOnClickListener(new b());
        this.b.c.setOnClickListener(new c());
        this.b.a.setOnClickListener(new d());
        this.b.e.registerOnPageChangeCallback(new e());
        E0(0);
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        FinanceServiceActivity.super.onActivityResult(i, i2, intent);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments != null && !fragments.isEmpty()) {
            for (Fragment onActivityResult : fragments) {
                onActivityResult.onActivityResult(i, i2, intent);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.content.Context, com.huawei.ethiopia.finance.loan.activity.FinanceServiceActivity, com.huawei.payment.mvvm.DataBindingActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceServiceActivity.super.onCreate(bundle);
        V7.e.a(this, getString(R$string.financial_service), R.layout.common_toolbar);
        F0();
    }

    public final void onNewIntent(Intent intent) {
        FinanceServiceActivity.super.onNewIntent(intent);
        F0();
    }
}
