package com.huawei.ethiopia.finance.saving.activity;

import D4.o;
import D4.q;
import V7.c;
import V7.e;
import a5.j;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.activity.result.a;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityActiveSavingBinding;
import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import com.huawei.ethiopia.finance.saving.adapter.SavingCanActiveProductAdapter;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingActivatableProductRepository;
import com.huawei.ethiopia.finance.saving.viewmodel.ActiveSavingViewModel;
import com.huawei.http.b;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.nio.charset.StandardCharsets;
import o5.C0104a;
import p5.g;
import w5.C0112a;

@Route(path = "/finance/activeSaving")
public class ActiveSavingActivity extends DataBindingActivity<FinanceActivityActiveSavingBinding, ActiveSavingViewModel> {
    public static final /* synthetic */ int h = 0;
    public SavingActivatableProduct d;
    public SavingCanActiveProductAdapter e;
    public String f;
    public String g;

    public final int C0() {
        return R$layout.finance_activity_active_saving;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [com.huawei.http.b, com.huawei.ethiopia.finance.saving.repository.ActiveSavingProductRepository] */
    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        ActiveSavingActivity.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 100 && i2 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            String c = g.c(this.f);
            C0112a.a("MS_" + c + "_active_pin_v1");
            ActiveSavingViewModel activeSavingViewModel = this.c;
            SavingActivatableProduct savingActivatableProduct = this.d;
            activeSavingViewModel.b.setValue(c.c());
            ? bVar = new b();
            bVar.addParams("initiatorMsisdn", g.k());
            bVar.addParams("initiatorPin", g.a(str));
            bVar.addParams("pinVersion", g.l());
            bVar.addParams("productId", savingActivatableProduct.getProductId());
            bVar.addParams("agreeTermCondition", "Y");
            activeSavingViewModel.d = bVar;
            bVar.sendRequest(new C0104a(activeSavingViewModel));
        }
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.ethiopia.finance.saving.activity.ActiveSavingActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        ActiveSavingActivity.super.onCreate(bundle);
        String c = g.c(this.f);
        C0112a.a("MS_" + c + "_agreement_v1");
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        this.f = getIntent().getStringExtra("bankCode");
        String string = getString(R$string.activate_sanduq);
        if (!(g.i().a == null || g.i().a.getFinanceServiceUIConfig() == null || g.i().a.getFinanceServiceUIConfig().getSaving() == null || TextUtils.isEmpty(g.i().a.getFinanceServiceUIConfig().getSaving().getSavingActivateTitle()))) {
            string = g.i().a.getFinanceServiceUIConfig().getSaving().getSavingActivateTitle();
        }
        e.a(this, string, R.layout.common_toolbar);
        this.g = getIntent().getStringExtra("fundsLenderId");
        this.b.b.setLayoutManager(new LinearLayoutManager(this));
        SavingCanActiveProductAdapter savingCanActiveProductAdapter = new SavingCanActiveProductAdapter();
        this.e = savingCanActiveProductAdapter;
        savingCanActiveProductAdapter.c = this.f;
        this.b.b.setAdapter(savingCanActiveProductAdapter);
        this.e.a = new a(this);
        this.b.a.setOnClickListener(new o(this, 5));
        this.c.a.observe(this, new T2.b(this, 1));
        this.c.b.observe(this, new q(this, 4));
        ActiveSavingViewModel activeSavingViewModel = this.c;
        String str = this.g;
        activeSavingViewModel.a.setValue(c.c());
        QuerySavingActivatableProductRepository querySavingActivatableProductRepository = new QuerySavingActivatableProductRepository(false, str);
        activeSavingViewModel.c = querySavingActivatableProductRepository;
        querySavingActivatableProductRepository.sendRequest(new j(activeSavingViewModel, 1));
    }
}
