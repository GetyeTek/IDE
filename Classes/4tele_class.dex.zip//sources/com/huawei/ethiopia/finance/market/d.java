package com.huawei.ethiopia.finance.market;

import android.view.View;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;

public final /* synthetic */ class d implements OnItemClickListener {
    public final /* synthetic */ LoanCategoryMarketActivity a;

    public /* synthetic */ d(LoanCategoryMarketActivity loanCategoryMarketActivity) {
        this.a = loanCategoryMarketActivity;
    }

    public final void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        LoanCategoryMarketActivity loanCategoryMarketActivity = this.a;
        loanCategoryMarketActivity.f = loanCategoryMarketActivity.childMenus.get(i);
        loanCategoryMarketActivity.c.a();
    }
}
