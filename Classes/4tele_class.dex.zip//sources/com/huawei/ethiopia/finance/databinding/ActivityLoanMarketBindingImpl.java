package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class ActivityLoanMarketBindingImpl extends ActivityLoanMarketBinding {
    @Nullable
    public static final SparseIntArray p;
    public long o = -1;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        p = sparseIntArray;
        sparseIntArray.put(R$id.rv_recycler_view_filter, 1);
        sparseIntArray.put(R$id.llLimitLayout, 2);
        sparseIntArray.put(R$id.ivBackgroundVein, 3);
        sparseIntArray.put(R$id.baseline, 4);
        sparseIntArray.put(R$id.tvBottomBalance, 5);
        sparseIntArray.put(R$id.verticalGuideline, 6);
        sparseIntArray.put(R$id.tvBottomBalanceValue, 7);
        sparseIntArray.put(R$id.llTopBalance, 8);
        sparseIntArray.put(R$id.tvLeftBalance, 9);
        sparseIntArray.put(R$id.tvRightBalance, 10);
        sparseIntArray.put(R$id.tvLeftBalanceValue, 11);
        sparseIntArray.put(R$id.tvRightBalanceValue, 12);
        sparseIntArray.put(R$id.rlMyCredit, 13);
        sparseIntArray.put(R$id.iv_sinq, 14);
        sparseIntArray.put(R$id.tv_my_telebirr_mela, 15);
        sparseIntArray.put(R$id.iv_right, 16);
        sparseIntArray.put(R$id.rlTermCondition, 17);
        sparseIntArray.put(R$id.filter_layout, 18);
        sparseIntArray.put(R$id.tv_title, 19);
        sparseIntArray.put(R$id.tvMaxLimit, 20);
        sparseIntArray.put(R$id.tvInstallment, 21);
        sparseIntArray.put(R$id.rv_recycler_view, 22);
        sparseIntArray.put(R$id.flLoading, 23);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActivityLoanMarketBindingImpl(@androidx.annotation.NonNull android.view.View r21, @androidx.annotation.Nullable androidx.databinding.DataBindingComponent r22) {
        /*
            r20 = this;
            android.util.SparseIntArray r0 = p
            r1 = 24
            r2 = 0
            r5 = r21
            r4 = r22
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r4, r5, r1, r2, r0)
            r1 = 4
            r1 = r0[r1]
            android.view.View r1 = (android.view.View) r1
            r1 = 18
            r1 = r0[r1]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1 = 23
            r1 = r0[r1]
            android.widget.FrameLayout r1 = (android.widget.FrameLayout) r1
            r1 = 3
            r1 = r0[r1]
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            r1 = 16
            r1 = r0[r1]
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            r1 = 14
            r1 = r0[r1]
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            r1 = 2
            r1 = r0[r1]
            r6 = r1
            com.huawei.common.widget.round.RoundConstraintLayout r6 = (com.huawei.common.widget.round.RoundConstraintLayout) r6
            r1 = 8
            r1 = r0[r1]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1 = 13
            r1 = r0[r1]
            r7 = r1
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            r1 = 17
            r1 = r0[r1]
            r8 = r1
            android.widget.TextView r8 = (android.widget.TextView) r8
            r1 = 22
            r1 = r0[r1]
            r9 = r1
            com.huawei.common.widget.round.RoundRecyclerView r9 = (com.huawei.common.widget.round.RoundRecyclerView) r9
            r1 = 1
            r1 = r0[r1]
            r10 = r1
            androidx.recyclerview.widget.RecyclerView r10 = (androidx.recyclerview.widget.RecyclerView) r10
            r1 = 5
            r1 = r0[r1]
            r11 = r1
            android.widget.TextView r11 = (android.widget.TextView) r11
            r1 = 7
            r1 = r0[r1]
            r12 = r1
            android.widget.TextView r12 = (android.widget.TextView) r12
            r1 = 21
            r1 = r0[r1]
            r13 = r1
            com.huawei.common.widget.round.RoundTextView r13 = (com.huawei.common.widget.round.RoundTextView) r13
            r1 = 9
            r1 = r0[r1]
            r14 = r1
            android.widget.TextView r14 = (android.widget.TextView) r14
            r1 = 11
            r1 = r0[r1]
            r15 = r1
            android.widget.TextView r15 = (android.widget.TextView) r15
            r1 = 20
            r1 = r0[r1]
            r16 = r1
            com.huawei.common.widget.round.RoundTextView r16 = (com.huawei.common.widget.round.RoundTextView) r16
            r1 = 15
            r1 = r0[r1]
            android.widget.TextView r1 = (android.widget.TextView) r1
            r1 = 10
            r1 = r0[r1]
            r17 = r1
            android.widget.TextView r17 = (android.widget.TextView) r17
            r1 = 12
            r1 = r0[r1]
            r18 = r1
            android.widget.TextView r18 = (android.widget.TextView) r18
            r1 = 19
            r1 = r0[r1]
            r19 = r1
            android.widget.TextView r19 = (android.widget.TextView) r19
            r1 = 6
            r1 = r0[r1]
            androidx.constraintlayout.widget.Guideline r1 = (androidx.constraintlayout.widget.Guideline) r1
            r3 = r20
            r4 = r22
            r5 = r21
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19)
            r3 = -1
            r1 = r20
            r1.o = r3
            r3 = 0
            r0 = r0[r3]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0.setTag(r2)
            r20.setRootTag(r21)
            r20.invalidateAll()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.ActivityLoanMarketBindingImpl.<init>(android.view.View, androidx.databinding.DataBindingComponent):void");
    }

    public final void executeBindings() {
        synchronized (this) {
            this.o = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.o != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.o = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
