package com.huawei.ethiopia.finance.loan.activity;

import Zb.c;
import android.text.TextUtils;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;
import c6.u;
import com.huawei.album.R;
import com.huawei.album.ui.AlbumActivity;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import g0.b;
import h0.d;
import java.util.ArrayList;
import m0.a;

public final /* synthetic */ class a implements CustomKeyBroadPop.a, a.a {
    public final /* synthetic */ AppCompatActivity a;

    public /* synthetic */ a(AppCompatActivity appCompatActivity) {
        this.a = appCompatActivity;
    }

    public void a() {
        int i = AlbumActivity.t;
        AlbumActivity albumActivity = this.a;
        ArrayList arrayList = (ArrayList) c.b.a;
        if (!arrayList.isEmpty()) {
            if (albumActivity.s == null) {
                albumActivity.s = new d((ViewGroup) albumActivity.findViewById(R.id.album_preview_container), new u(albumActivity));
            }
            albumActivity.s.b(new ArrayList(arrayList), (b) arrayList.get(0), true);
        }
    }

    public void b(boolean z) {
        int i = ApplyLoanProductActivity.o;
        ApplyLoanProductActivity applyLoanProductActivity = this.a;
        String obj = applyLoanProductActivity.b.b.getText().toString();
        if (!TextUtils.isEmpty(applyLoanProductActivity.f) && !TextUtils.equals(applyLoanProductActivity.f, obj)) {
            applyLoanProductActivity.b.b.setText(applyLoanProductActivity.f);
            applyLoanProductActivity.b.b.setSelection(applyLoanProductActivity.f.length());
        }
    }
}
