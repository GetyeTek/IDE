package com.huawei.ethiopia.finance.saving.repository;

import com.huawei.ethiopia.finance.resp.TimeSavingProductInfo;
import com.huawei.http.b;

public class LockedSavingProductDetailRepository extends b<TimeSavingProductInfo, TimeSavingProductInfo> {
    public final String getApiPath() {
        return "v1/ethiopia/recurring/product/detail";
    }
}
