package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;

public class AppRepaymentSchedule implements Serializable {
    private String endDate;
    private String periodId;
    private String statementId;
    private String status;
    private String totalScheduleAmount;

    public String getEndDate() {
        return this.endDate;
    }

    public String getPeriodId() {
        return this.periodId;
    }

    public String getStatementId() {
        return this.statementId;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTotalScheduleAmount() {
        return this.totalScheduleAmount;
    }

    public void setEndDate(String str) {
        this.endDate = str;
    }

    public void setPeriodId(String str) {
        this.periodId = str;
    }

    public void setStatementId(String str) {
        this.statementId = str;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setTotalScheduleAmount(String str) {
        this.totalScheduleAmount = str;
    }
}
