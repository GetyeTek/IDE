package com.huawei.ethiopia.finance.saving.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.ethiopia.finance.resp.FinanceProductListResp;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingAccountRepository;
import java.util.Collections;
import java.util.List;

public class LockedSavingViewModel extends ViewModel {
    public final MutableLiveData<c<List<FinanceProductInfo>>> a = new MutableLiveData<>();
    public final MutableLiveData<c<FinanceProductListResp>> b = new MutableLiveData<>();
    public QuerySavingAccountRepository c;

    public class a implements R1.a<FinanceProductListResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            LockedSavingViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            FinanceProductListResp financeProductListResp = (FinanceProductListResp) obj;
            LockedSavingViewModel lockedSavingViewModel = LockedSavingViewModel.this;
            if (financeProductListResp == null) {
                lockedSavingViewModel.a.setValue(c.e(Collections.emptyList()));
                return;
            }
            lockedSavingViewModel.b.setValue(c.e(financeProductListResp));
            List<FinanceProductInfo> productList = financeProductListResp.getProductList();
            MutableLiveData<c<List<FinanceProductInfo>>> mutableLiveData = lockedSavingViewModel.a;
            if (productList == null) {
                mutableLiveData.setValue(c.e(Collections.emptyList()));
            } else {
                mutableLiveData.setValue(c.e(productList));
            }
        }
    }

    public final void a(String str, boolean z) {
        this.a.setValue(c.c());
        QuerySavingAccountRepository querySavingAccountRepository = new QuerySavingAccountRepository(str, true, z);
        this.c = querySavingAccountRepository;
        querySavingAccountRepository.sendRequest(new a());
    }

    public final void onCleared() {
        LockedSavingViewModel.super.onCleared();
        QuerySavingAccountRepository querySavingAccountRepository = this.c;
        if (querySavingAccountRepository != null) {
            querySavingAccountRepository.cancel();
        }
    }
}
