package com.huawei.ethiopia.finance.loan.activity;

import L3.a;
import O9.c;
import a5.m;
import android.content.Intent;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.ActivityManualRolloverBinding;
import com.huawei.ethiopia.finance.loan.adapter.LoanValidationAdapter;
import com.huawei.ethiopia.finance.loan.viewmodel.ManualRolloverViewModel;
import com.huawei.ethiopia.finance.resp.LoanTrialResp;
import com.huawei.ethiopia.finance.resp.RolloverPreValidationResp;
import com.huawei.http.BaseResp;
import com.huawei.http.b;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.Locale;

@Route(path = "/finance/manualRollover")
public class ManualRolloverActivity extends BaseActivity {
    public static final /* synthetic */ int f = 0;
    @Autowired
    String bankCode;
    public ActivityManualRolloverBinding d;
    public ManualRolloverViewModel e;
    @Autowired
    boolean isInstall;
    @Autowired
    RolloverPreValidationResp rolloverPreValidation;

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.ethiopia.finance.loan.activity.ManualRolloverActivity, android.app.Activity] */
    public final ViewBinding C0() {
        ActivityManualRolloverBinding a = ActivityManualRolloverBinding.a(getLayoutInflater());
        this.d = a;
        return a;
    }

    public final void D0() {
        ManualRolloverViewModel manualRolloverViewModel = new ViewModelProvider(this).get(ManualRolloverViewModel.class);
        this.e = manualRolloverViewModel;
        manualRolloverViewModel.a.observe(this, new w(this));
    }

    /* JADX WARNING: type inference failed for: r3v2, types: [android.view.View$OnClickListener, com.huawei.ethiopia.finance.loan.activity.x] */
    /* JADX WARNING: type inference failed for: r1v5, types: [com.huawei.ethiopia.finance.loan.activity.y, android.view.View$OnClickListener] */
    public final void G0() {
        int i;
        f.g(getWindow());
        f.f(this, false);
        TextView textView = this.d.g;
        if (this.isInstall) {
            i = R$string.finance_installment_plan;
        } else {
            i = R$string.loan_extension;
        }
        textView.setText(i);
        this.d.c.setOnClickListener(new x(this));
        RolloverPreValidationResp rolloverPreValidationResp = this.rolloverPreValidation;
        if (rolloverPreValidationResp != null) {
            c.c(this.d.d, rolloverPreValidationResp.getBankIcon(), -1);
            if (this.isInstall) {
                this.d.f.setText(String.format(Locale.ENGLISH, getString(R$string.produce_s_installment), new Object[]{this.rolloverPreValidation.getProductName()}));
            } else {
                this.d.f.setText(MessageFormat.format("{0} {1}", new Object[]{this.rolloverPreValidation.getProductName(), getString(R$string.loan_extension)}));
            }
            this.d.e.setLayoutManager(new LinearLayoutManager(this));
            LoanValidationAdapter loanValidationAdapter = new LoanValidationAdapter(this);
            LoanTrialResp loanTrialResp = new LoanTrialResp();
            loanTrialResp.setPreValidationItems(this.rolloverPreValidation.getDisplayItems());
            loanTrialResp.setRepaymentSchedules(this.rolloverPreValidation.getRepaymentSchedules());
            loanValidationAdapter.e(loanTrialResp);
            this.d.e.setAdapter(loanValidationAdapter);
            this.d.b.setOnClickListener(new y(this));
        }
    }

    public final boolean H0() {
        return false;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        byte[] byteArrayExtra;
        RolloverPreValidationResp rolloverPreValidationResp;
        ManualRolloverViewModel manualRolloverViewModel;
        ManualRolloverActivity.super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null && (byteArrayExtra = intent.getByteArrayExtra("pin")) != null && (rolloverPreValidationResp = this.rolloverPreValidation) != null && (manualRolloverViewModel = this.e) != null) {
            boolean z = this.isInstall;
            MutableLiveData<V7.c<BaseResp>> mutableLiveData = manualRolloverViewModel.a;
            if (!z) {
                String contractID = rolloverPreValidationResp.getContractID();
                String statementID = this.rolloverPreValidation.getStatementID();
                String str = new String(byteArrayExtra, StandardCharsets.UTF_8);
                mutableLiveData.setValue(V7.c.c());
                b bVar = new b();
                bVar.addParams("contractID", contractID);
                bVar.addParams("statementID", statementID);
                bVar.addParams("initiatorPin", a.g(str));
                bVar.sendRequest(new m(manualRolloverViewModel, 0));
                return;
            }
            String contractID2 = rolloverPreValidationResp.getContractID();
            String str2 = new String(byteArrayExtra, StandardCharsets.UTF_8);
            mutableLiveData.setValue(V7.c.c());
            b bVar2 = new b();
            bVar2.addParams("contractID", contractID2);
            bVar2.addParams("initiatorPin", a.g(str2));
            bVar2.sendRequest(new I4.c(manualRolloverViewModel, 1));
        }
    }
}
