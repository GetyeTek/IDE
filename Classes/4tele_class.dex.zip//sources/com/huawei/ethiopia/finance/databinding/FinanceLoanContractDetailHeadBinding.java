package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceLoanContractDetailHeadBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final RoundRecyclerView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final RoundTextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;

    public FinanceLoanContractDetailHeadBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, RoundRecyclerView roundRecyclerView, TextView textView, RoundTextView roundTextView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = roundRecyclerView;
        this.c = textView;
        this.d = roundTextView;
        this.e = textView2;
        this.f = textView3;
        this.g = textView4;
        this.h = textView5;
        this.i = textView6;
    }
}
