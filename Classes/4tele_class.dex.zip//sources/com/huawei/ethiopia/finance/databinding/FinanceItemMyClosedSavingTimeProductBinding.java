package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundLinearLayout;

public abstract class FinanceItemMyClosedSavingTimeProductBinding extends ViewDataBinding {
    @NonNull
    public final RoundLinearLayout a;

    public FinanceItemMyClosedSavingTimeProductBinding(DataBindingComponent dataBindingComponent, View view, RoundLinearLayout roundLinearLayout) {
        super(dataBindingComponent, view, 0);
        this.a = roundLinearLayout;
    }
}
