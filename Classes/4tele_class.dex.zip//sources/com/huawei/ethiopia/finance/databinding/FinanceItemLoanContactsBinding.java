package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemLoanContactsBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final RoundConstraintLayout c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final RoundTextView h;

    public FinanceItemLoanContactsBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, RoundTextView roundTextView2, RoundConstraintLayout roundConstraintLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4, RoundTextView roundTextView3) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = roundTextView2;
        this.c = roundConstraintLayout;
        this.d = textView;
        this.e = textView2;
        this.f = textView3;
        this.g = textView4;
        this.h = roundTextView3;
    }
}
