package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemSavingTimeProductBindingImpl extends FinanceItemSavingTimeProductBinding {
    @Nullable
    public static final SparseIntArray m;
    public long l;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        m = sparseIntArray;
        sparseIntArray.put(R$id.tvTitle, 1);
        sparseIntArray.put(R$id.btn_apply, 2);
        sparseIntArray.put(R$id.recycler_view, 3);
        sparseIntArray.put(R$id.cl_detail, 4);
        sparseIntArray.put(R$id.rcl_detail, 5);
        sparseIntArray.put(R$id.tvInterestRateValue, 6);
        sparseIntArray.put(R$id.tvInterestRate, 7);
        sparseIntArray.put(R$id.tvMiniDepositAmountValue, 8);
        sparseIntArray.put(R$id.tvMiniDepositAmount, 9);
        sparseIntArray.put(R$id.llMore, 10);
        sparseIntArray.put(R$id.tvMore, 11);
        sparseIntArray.put(R$id.ivMore, 12);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.l = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.l != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.l = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
