package com.huawei.ethiopia.finance.od.viewmodel;

import V7.c;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.od.repository.ActiveFinanceRepository;
import com.huawei.http.BaseResp;

public class FinanceActiveViewModel extends ViewModel {
    public final MutableLiveData<c<BaseResp>> a = new MutableLiveData<>();
    public ActiveFinanceRepository b;

    public class a implements R1.a<BaseResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceActiveViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            FinanceActiveViewModel.this.a.setValue(c.e((BaseResp) obj));
        }
    }

    public final void a(String str, String str2, String str3) {
        this.a.setValue(c.c());
        this.b = new ActiveFinanceRepository(str, str2);
        if (!TextUtils.isEmpty(str3)) {
            this.b.addParams("serviceTypeId", str3);
        }
        this.b.sendRequest(new a());
    }

    public final void onCleared() {
        FinanceActiveViewModel.super.onCleared();
        ActiveFinanceRepository activeFinanceRepository = this.b;
        if (activeFinanceRepository != null) {
            activeFinanceRepository.cancel();
        }
    }
}
