package com.huawei.ethiopia.finance.loan.activity;

import V7.c;
import Y6.a;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewPropertyAnimator;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceLoanRepayViewModel;
import com.huawei.http.b;
import com.huawei.module_checkout.requestpin.BaseRequestPinActivity;
import p5.g;
import w5.C0112a;

@Route(path = "/finance/repayLoan")
public class FinanceLoanRepayActivity extends BaseRequestPinActivity {
    public static final /* synthetic */ int q = 0;
    public FinanceLoanRepayViewModel g;
    public String h;
    public String i;
    public String j;
    public ViewPropertyAnimator k;
    public String l;
    public String m;
    public String n;
    public String o;
    public String p;

    /* JADX WARNING: type inference failed for: r7v1, types: [com.huawei.http.b, com.huawei.ethiopia.finance.loan.repository.RepayLoanRepository] */
    public final void D0(String str) {
        String c = g.c(this.l);
        C0112a.a(c + "_contractID_repay_pin_v1");
        if (TextUtils.equals(this.o, "Y")) {
            FinanceLoanRepayViewModel financeLoanRepayViewModel = this.g;
            String str2 = this.m;
            String str3 = this.h;
            financeLoanRepayViewModel.a.setValue(c.c());
            b bVar = new b();
            bVar.addParams("initiatorPin", g.a(str));
            bVar.addParams("pinVersion", g.l());
            bVar.addParams("repaymentAmount", str3);
            bVar.addParams("contractId", str2);
            bVar.sendRequest(new a(financeLoanRepayViewModel, 1));
            return;
        }
        FinanceLoanRepayViewModel financeLoanRepayViewModel2 = this.g;
        String str4 = this.h;
        String str5 = this.i;
        String str6 = this.j;
        financeLoanRepayViewModel2.a.setValue(c.c());
        ? bVar2 = new b();
        bVar2.addParams("initiatorPin", g.a(str));
        bVar2.addParams("pinVersion", g.l());
        bVar2.addParams("statementId", str5);
        bVar2.addParams("repaymentAmount", str4);
        bVar2.addParams("isFullRepayment", str6);
        financeLoanRepayViewModel2.b = bVar2;
        bVar2.sendRequest(new a5.g(financeLoanRepayViewModel2, 0));
    }

    public final void K() {
        ViewPropertyAnimator viewPropertyAnimator = this.k;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
        this.a.b.setAlpha(0.0f);
        finish();
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.ethiopia.finance.loan.activity.FinanceLoanRepayActivity, androidx.lifecycle.LifecycleOwner, androidx.lifecycle.ViewModelStoreOwner, android.app.Activity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceLoanRepayActivity.super.onCreate(bundle);
        this.g = new ViewModelProvider(this).get(FinanceLoanRepayViewModel.class);
        this.h = getIntent().getStringExtra("repaymentAmount");
        this.i = getIntent().getStringExtra("statementId");
        this.j = getIntent().getStringExtra("isFullRepayment");
        this.l = getIntent().getStringExtra("bankCode");
        this.m = getIntent().getStringExtra("contractId");
        this.n = getIntent().getStringExtra("productId");
        this.p = getIntent().getStringExtra("productName");
        this.o = getIntent().getStringExtra("allowRepayInAdvance");
        this.g.a.observe(this, new g(this));
        ViewPropertyAnimator animate = this.a.b.animate();
        this.k = animate;
        animate.alpha(1.0f);
        this.k.setDuration(300);
        this.k.setStartDelay(200);
        this.k.start();
    }
}
