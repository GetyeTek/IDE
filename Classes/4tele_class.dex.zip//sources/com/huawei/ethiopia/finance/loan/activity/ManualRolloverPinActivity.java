package com.huawei.ethiopia.finance.loan.activity;

import V1.h;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewPropertyAnimator;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.module_checkout.requestpin.BaseRequestPinActivity;
import java.nio.charset.StandardCharsets;

@Route(path = "/finance/manualRolloverPin")
public class ManualRolloverPinActivity extends BaseRequestPinActivity {
    public ViewPropertyAnimator g;

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.ethiopia.finance.loan.activity.ManualRolloverPinActivity, android.app.Activity, com.huawei.module_checkout.requestpin.BaseRequestPinActivity] */
    public final void D0(String str) {
        if (!TextUtils.isEmpty(str)) {
            try {
                Intent intent = new Intent();
                intent.putExtra("pin", str.getBytes(StandardCharsets.UTF_8));
                setResult(-1, intent);
                finish();
            } catch (Exception e) {
                e.getMessage();
                h.b();
            }
        }
    }

    public final void K() {
        ViewPropertyAnimator viewPropertyAnimator = this.g;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
        this.a.b.setAlpha(0.0f);
        finish();
    }

    public final void onCreate(@Nullable Bundle bundle) {
        ManualRolloverPinActivity.super.onCreate(bundle);
        ViewPropertyAnimator animate = this.a.b.animate();
        this.g = animate;
        animate.alpha(1.0f);
        this.g.setDuration(300);
        this.g.setStartDelay(200);
        this.g.start();
    }
}
