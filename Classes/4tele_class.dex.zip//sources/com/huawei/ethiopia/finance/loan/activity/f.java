package com.huawei.ethiopia.finance.loan.activity;

import C3.e;
import android.os.Bundle;
import android.view.View;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import com.huawei.digitalpayment.customer.login_module.widget.TermDialog;
import com.huawei.kbz.chat.contact.ChatSettingActivity;
import com.huawei.kbz.chat.widget.ConversationInputPanel;
import com.huawei.requestmoney.RequestMoneyDetailActivity;
import com.huawei.requestmoney.view.TypeSelectView;
import java.util.Map;
import kotlin.jvm.internal.h;
import o0.b;

public final /* synthetic */ class f implements View.OnClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ f(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [java.lang.Object, com.huawei.kbz.chat.contact.ChatSettingActivity, android.app.Activity] */
    public final void onClick(View view) {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = FinanceLoanHomeActivity.d;
                ((FinanceLoanHomeActivity) obj).b.g.setCurrentItem(0, false);
                return;
            case 1:
                int i2 = ChatSettingActivity.c;
                ? r0 = (ChatSettingActivity) obj;
                r0.getClass();
                b.d(r0, "/chat/set_nick_name", (Bundle) null, (Map) null);
                return;
            case 2:
                RequestMoneyDetailActivity requestMoneyDetailActivity = (RequestMoneyDetailActivity) obj;
                if (requestMoneyDetailActivity.f != null) {
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("requestMoneyInfo", requestMoneyDetailActivity.f);
                    bundle.putSerializable("type", requestMoneyDetailActivity.d);
                    b.e(requestMoneyDetailActivity, "/requestMoneyModule/editRequestMoney", bundle, (Map) null, 0, 3);
                    return;
                }
                return;
            case 3:
                int i3 = ConversationInputPanel.Y0;
                ((ConversationInputPanel) obj).d();
                return;
            case 4:
                TermDialog.v0((TermDialog) obj, view);
                return;
            case 5:
                e.b((HomeFunction) obj);
                return;
            default:
                int i4 = TypeSelectView.C0;
                TypeSelectView typeSelectView = (TypeSelectView) obj;
                h.f(typeSelectView, "this$0");
                typeSelectView.e();
                return;
        }
    }
}
