package com.huawei.ethiopia.finance.saving.activity;

import F3.a;
import V7.c;
import V7.e;
import W1.b;
import Y4.n;
import Y4.o;
import Y4.q;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingProductDetailBinding;
import com.huawei.ethiopia.finance.resp.TimeSavingProductInfo;
import com.huawei.ethiopia.finance.saving.adapter.LockedSavingContractAdapter;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingAccountRepository;
import com.huawei.ethiopia.finance.saving.viewmodel.LockedSavingProductDetailViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;

public class LockedSavingProductDetailActivity extends DataBindingActivity<FinanceActivityLockedSavingProductDetailBinding, LockedSavingProductDetailViewModel> {
    public static final /* synthetic */ int l = 0;
    public b.b d;
    public String e;
    public String f;
    public TimeSavingProductInfo g;
    public TimeSavingProductInfo.ProductInfoBean h;
    public LockedSavingContractAdapter i;
    public String j;
    public String k;

    public final int C0() {
        return R$layout.finance_activity_locked_saving_product_detail;
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.ethiopia.finance.saving.activity.LockedSavingProductDetailActivity, android.content.Context, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        LockedSavingProductDetailActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.standard_white), false);
        e.a(this, "", R$layout.common_toolbar);
        this.e = getIntent().getStringExtra("productId");
        getIntent().getStringExtra("accountNo");
        this.k = getIntent().getStringExtra("bankCode");
        this.j = getIntent().getStringExtra("fundsLenderId");
        this.f = getIntent().getStringExtra("productUnquieID");
        b.b c = b.b().c(this.b.d);
        c.b = new F2.b(this, 3);
        this.d = c;
        this.b.a.a.setOnClickListener(new a(this, 9));
        this.c.a(this.f);
        LockedSavingProductDetailViewModel lockedSavingProductDetailViewModel = this.c;
        String str = this.j;
        String str2 = this.e;
        lockedSavingProductDetailViewModel.a.setValue(c.c());
        new QuerySavingAccountRepository(str, true, true).sendRequest(new o5.b(lockedSavingProductDetailViewModel, str2));
        LockedSavingProductDetailViewModel lockedSavingProductDetailViewModel2 = this.c;
        lockedSavingProductDetailViewModel2.getClass();
        BannerRepository bannerRepository = new BannerRepository("Application Page", "Finance Saving");
        lockedSavingProductDetailViewModel2.d = bannerRepository;
        bannerRepository.sendRequest(new I4.e(lockedSavingProductDetailViewModel2, 3));
        this.c.c.observe(this, new C6.a(this, 1));
        this.c.b.observe(this, new n(this, 3));
        this.c.a.observe(this, new o(this, 2));
        LockedSavingContractAdapter lockedSavingContractAdapter = new LockedSavingContractAdapter();
        this.i = lockedSavingContractAdapter;
        lockedSavingContractAdapter.a = new q(this);
        this.b.d.setAdapter(lockedSavingContractAdapter);
    }
}
