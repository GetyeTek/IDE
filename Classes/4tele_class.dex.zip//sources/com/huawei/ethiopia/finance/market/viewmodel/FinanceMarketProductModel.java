package com.huawei.ethiopia.finance.market.viewmodel;

import V7.c;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.blankj.utilcode.util.s;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.loan.repository.QueryFinanceIsActiveRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryLoanContractsRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryLoanLimitRepository;
import com.huawei.ethiopia.finance.market.dialog.ShowLoanLimitBean;
import com.huawei.ethiopia.finance.market.repository.FinanceMarketProductRepository;
import com.huawei.ethiopia.finance.resp.ActiveState;
import com.huawei.ethiopia.finance.resp.FinanceLoanResp;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import com.huawei.kbz.event.FaceVerificationResult;
import e5.C0072b;
import java.util.List;
import p5.g;

public class FinanceMarketProductModel extends ViewModel {
    public final MutableLiveData<c<ProductInfo>> a = new MutableLiveData<>();
    public final MutableLiveData<c<ProductInfo>> b = new MutableLiveData<>();
    public final MutableLiveData<c<FinanceLoanResp>> c = new MutableLiveData<>();
    public final MutableLiveData<c<List<FinanceMarketBankConfig.FinanceMarketBankItem>>> d;
    public final MutableLiveData<ShowLoanLimitBean> e;
    public QueryFinanceIsActiveRepository f;
    public QueryLoanLimitRepository g;
    public FinanceMarketProductRepository h;
    public QueryFinanceIsActiveRepository i;
    public final MutableLiveData<c<ActiveState>> j;
    public String k;
    public QueryLoanContractsRepository l;
    public String m;

    public class a implements R1.a<ActiveState> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceMarketProductModel.this.j.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            ActiveState activeState = (ActiveState) obj;
            String protocolUrl = activeState.getProtocolUrl();
            FinanceMarketProductModel financeMarketProductModel = FinanceMarketProductModel.this;
            financeMarketProductModel.k = protocolUrl;
            financeMarketProductModel.j.setValue(c.e(activeState));
        }
    }

    public class b implements R1.a<ActiveState> {
        public final /* synthetic */ String a;
        public final /* synthetic */ String b;

        public b(String str, String str2) {
            this.a = str;
            this.b = str2;
        }

        public final /* synthetic */ void onComplete() {
        }

        public final /* synthetic */ void onError(BaseException baseException) {
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            boolean isActive = ((ActiveState) obj).isActive();
            FinanceMarketProductModel financeMarketProductModel = FinanceMarketProductModel.this;
            if (isActive) {
                QueryLoanLimitRepository queryLoanLimitRepository = new QueryLoanLimitRepository(this.a);
                financeMarketProductModel.g = queryLoanLimitRepository;
                queryLoanLimitRepository.sendRequest(new a(this));
                return;
            }
            financeMarketProductModel.getClass();
            String k = g.k();
            s a2 = s.a("");
            StringBuilder sb = new StringBuilder();
            String str = this.b;
            a2.d(androidx.camera.core.processing.util.b.a(sb, str, "_", k, "_KEY_LOAN_MAX_LIMIT"));
            s a3 = s.a("");
            a3.d(str + "_" + k + "_KEY_AVAILABLE_MELA_LIMIT");
            financeMarketProductModel.e.setValue(new ShowLoanLimitBean(true, str));
        }
    }

    public FinanceMarketProductModel() {
        new MutableLiveData();
        this.d = new MutableLiveData<>();
        this.e = new MutableLiveData<>();
        this.j = new MutableLiveData<>();
    }

    public final void a() {
        this.j.setValue(c.c());
        QueryFinanceIsActiveRepository queryFinanceIsActiveRepository = new QueryFinanceIsActiveRepository("v1/ethiopia/loan/subscribe/check");
        this.i = queryFinanceIsActiveRepository;
        String o = g.o();
        if (!TextUtils.isEmpty(o)) {
            queryFinanceIsActiveRepository.addParams("serviceTypeId", o);
        }
        this.i.sendRequest(new a());
    }

    public final void b(String str, String str2) {
        QueryFinanceIsActiveRepository queryFinanceIsActiveRepository = this.f;
        if (queryFinanceIsActiveRepository != null) {
            queryFinanceIsActiveRepository.cancel();
        }
        QueryLoanLimitRepository queryLoanLimitRepository = this.g;
        if (queryLoanLimitRepository != null) {
            queryLoanLimitRepository.cancel();
        }
        QueryFinanceIsActiveRepository queryFinanceIsActiveRepository2 = new QueryFinanceIsActiveRepository("v1/ethiopia/loan/subscribe/check");
        this.f = queryFinanceIsActiveRepository2;
        String o = g.o();
        if (!TextUtils.isEmpty(o)) {
            queryFinanceIsActiveRepository2.addParams("serviceTypeId", o);
        }
        this.f.sendRequest(new b(str2, str));
    }

    public final void c(FinanceLoanResp financeLoanResp) {
        QueryLoanContractsRepository queryLoanContractsRepository = new QueryLoanContractsRepository(this.m, FaceVerificationResult.RESULT_SUCCESS, true);
        this.l = queryLoanContractsRepository;
        queryLoanContractsRepository.sendRequest(new C0072b(this, financeLoanResp));
    }
}
