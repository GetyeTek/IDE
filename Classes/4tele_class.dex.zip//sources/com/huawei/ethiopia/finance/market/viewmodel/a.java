package com.huawei.ethiopia.finance.market.viewmodel;

import androidx.camera.core.processing.util.b;
import com.blankj.utilcode.util.s;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.market.dialog.ShowLoanLimitBean;
import com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketProductModel;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import p5.g;

public final class a implements R1.a<ProductInfo> {
    public final /* synthetic */ FinanceMarketProductModel.b a;

    public a(FinanceMarketProductModel.b bVar) {
        this.a = bVar;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final /* synthetic */ void onError(BaseException baseException) {
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        ProductInfo productInfo = (ProductInfo) obj;
        String k = g.k();
        s a2 = s.a("");
        StringBuilder sb = new StringBuilder();
        FinanceMarketProductModel.b bVar = this.a;
        String str = bVar.b;
        a2.c(b.a(sb, str, "_", k, "_KEY_LOAN_MAX_LIMIT"), productInfo.getMaxLimit());
        s a3 = s.a("");
        a3.c(str + "_" + k + "_KEY_AVAILABLE_MELA_LIMIT", productInfo.getAvaiableLimit());
        FinanceMarketProductModel.this.e.setValue(new ShowLoanLimitBean(true, str));
    }
}
