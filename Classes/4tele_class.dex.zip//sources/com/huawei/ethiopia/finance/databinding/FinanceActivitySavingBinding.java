package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class FinanceActivitySavingBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final FrameLayout b;
    @NonNull
    public final FinanceFragmentLoanHomeUnactiveBinding c;
    @NonNull
    public final FinanceMyFixedSavingLayoutBinding d;
    @NonNull
    public final HFRecyclerView e;
    @NonNull
    public final HFRecyclerView f;

    public FinanceActivitySavingBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, FrameLayout frameLayout, FinanceFragmentLoanHomeUnactiveBinding financeFragmentLoanHomeUnactiveBinding, FinanceMyFixedSavingLayoutBinding financeMyFixedSavingLayoutBinding, HFRecyclerView hFRecyclerView, HFRecyclerView hFRecyclerView2) {
        super(dataBindingComponent, view, 1);
        this.a = loadingButton;
        this.b = frameLayout;
        this.c = financeFragmentLoanHomeUnactiveBinding;
        this.d = financeMyFixedSavingLayoutBinding;
        this.e = hFRecyclerView;
        this.f = hFRecyclerView2;
    }
}
