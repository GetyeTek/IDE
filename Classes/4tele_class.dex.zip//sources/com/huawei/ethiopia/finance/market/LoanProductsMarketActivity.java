package com.huawei.ethiopia.finance.market;

import F0.o;
import K5.d;
import N0.E;
import N0.F;
import N0.G;
import S3.c;
import V7.e;
import W1.b;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.s;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.digitalpayment.customer.login_module.login.a;
import com.huawei.digitalpayment.customer.login_module.login.f;
import com.huawei.digitalpayment.paybill.activity.i;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.ActivityLoanMarketBinding;
import com.huawei.ethiopia.finance.loan.activity.MyTelebirrTelaActivity;
import com.huawei.ethiopia.finance.loan.repository.QueryFinanceBankListRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryLoanContractsRepository;
import com.huawei.ethiopia.finance.market.adapter.FinanceLoanMarketProductAdapter;
import com.huawei.ethiopia.finance.market.adapter.LoanMarketFilterAdapter;
import com.huawei.ethiopia.finance.market.bean.LoanCategoryMenuInfo;
import com.huawei.ethiopia.finance.market.dialog.FinanceFilterDialog;
import com.huawei.ethiopia.finance.market.repository.FinanceMarketProductRepository;
import com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketProductModel;
import com.huawei.ethiopia.finance.resp.FinanceLoanResp;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import com.huawei.kbz.event.FaceVerificationResult;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import p5.g;
import p5.j;
import w5.C0112a;

@Route(path = "/finance/loanProductsMarket")
public class LoanProductsMarketActivity extends DataBindingActivity<ActivityLoanMarketBinding, FinanceMarketProductModel> {
    public static final /* synthetic */ int v = 0;
    @Autowired
    LoanCategoryMenuInfo categoryMenuInfo;
    public FinanceLoanMarketProductAdapter d;
    public final ArrayList<ProductInfo> e = new ArrayList<>();
    public final ArrayList f = new ArrayList();
    public b.b g;
    public FinanceLoanResp h;
    public boolean i;
    public boolean j;
    public List<FinanceMarketBankConfig.FinanceMarketBankItem> k;
    public LoanMarketFilterAdapter l;
    public ArrayList m;
    public String n = "";
    public String o;
    public String p;
    public String q;
    public String r;
    public int s;
    public int t;
    public String u;

    public final int C0() {
        return R$layout.activity_loan_market;
    }

    public final ArrayList E0(List list) {
        ArrayList arrayList = new ArrayList();
        FinanceMarketBankConfig.FinanceMarketBankItem financeMarketBankItem = new FinanceMarketBankConfig.FinanceMarketBankItem();
        financeMarketBankItem.setBankName(getResources().getString(R$string.all));
        financeMarketBankItem.setBankCode("ALL");
        financeMarketBankItem.setLogo("finance_all_bank");
        financeMarketBankItem.setThemeColor("#8DC63F");
        arrayList.add(financeMarketBankItem);
        if (list.size() <= 3) {
            arrayList.addAll(list);
        } else {
            arrayList.addAll(list.subList(0, 2));
            FinanceMarketBankConfig.FinanceMarketBankItem financeMarketBankItem2 = new FinanceMarketBankConfig.FinanceMarketBankItem();
            financeMarketBankItem2.setBankName(getResources().getString(R$string.more));
            financeMarketBankItem2.setBankCode("More");
            financeMarketBankItem2.setLogo("home_icon_more");
            arrayList.add(financeMarketBankItem2);
        }
        return arrayList;
    }

    public final ArrayList<ProductInfo> F0() {
        ArrayList<ProductInfo> arrayList = this.e;
        if (arrayList == null) {
            return new ArrayList<>();
        }
        ArrayList<ProductInfo> arrayList2 = new ArrayList<>();
        Iterator<ProductInfo> it = arrayList.iterator();
        while (it.hasNext()) {
            ProductInfo next = it.next();
            if (TextUtils.isEmpty(this.o)) {
                arrayList2.add(next);
            } else if (TextUtils.equals(next.getCompanyName(), this.o)) {
                arrayList2.add(next);
            }
        }
        return arrayList2;
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, com.huawei.ethiopia.finance.market.LoanProductsMarketActivity, com.huawei.payment.mvvm.DataBindingActivity] */
    public final void G0() {
        List<FinanceMarketBankConfig.FinanceMarketBankItem> list = this.k;
        if (list != null) {
            Collections.sort(list, new d(1));
            this.l = new LoanMarketFilterAdapter();
            ArrayList E0 = E0(this.k);
            this.m = E0;
            this.l.setList(E0);
            RecyclerView recyclerView = this.b.e;
            ArrayList arrayList = this.m;
            int i2 = 4;
            if (arrayList.size() < 4) {
                i2 = arrayList.size();
            }
            recyclerView.setLayoutManager(new GridLayoutManager(this, i2));
            this.b.e.setAdapter(this.l);
            this.l.setOnItemClickListener(new l(this));
        }
    }

    public final boolean H0(String str) {
        s a = s.a("finance_sp_name_no_cache");
        return a.a.getBoolean(o.a(new StringBuilder(), this.n, "_hideBalance_", str), true);
    }

    public final void I0(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.b.a.setBackgroundColor(Color.parseColor(str));
            FinanceLoanMarketProductAdapter financeLoanMarketProductAdapter = this.d;
            financeLoanMarketProductAdapter.d = str;
            financeLoanMarketProductAdapter.notifyDataSetChanged();
        }
    }

    public final void J0(ArrayList arrayList) {
        if (arrayList.isEmpty()) {
            this.g.a(4);
        } else {
            this.g.a(2);
        }
        ArrayList arrayList2 = this.f;
        arrayList2.clear();
        arrayList2.addAll(arrayList);
        this.d.notifyDataSetChanged();
    }

    public final void K0(FinanceMarketBankConfig.FinanceMarketBankItem financeMarketBankItem) {
        int i2;
        this.o = financeMarketBankItem.getCompanyName();
        this.n = financeMarketBankItem.getBankCode();
        this.p = financeMarketBankItem.getFundsLenderId();
        this.q = financeMarketBankItem.getThemeColor();
        this.c.b(this.n, financeMarketBankItem.getFundsLenderId());
        String termAndCondition = financeMarketBankItem.getTermAndCondition();
        this.u = termAndCondition;
        TextView textView = this.b.c;
        if (TextUtils.isEmpty(termAndCondition)) {
            i2 = 8;
        } else {
            i2 = 0;
        }
        textView.setVisibility(i2);
        this.c.m = this.p;
        s.a("finance_sp_name_no_cache").c("finance_market_bank_code", this.n);
        s.a("finance_sp_name_no_cache").c("finance_market_bank_fundId", this.p);
        s.a("finance_sp_name_no_cache").c("finance_market_bank_company_name", this.o);
        s.a("finance_sp_name_no_cache").c("finance_market_bank_color", this.q);
        s.a("finance_sp_name_no_cache").c("finance_market_term_and_condition", this.u);
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.ethiopia.finance.market.LoanProductsMarketActivity, androidx.fragment.app.FragmentActivity] */
    @SuppressLint({"NotifyDataSetChanged"})
    public final void L0(List<FinanceMarketBankConfig.FilterBean> list, View view) {
        int i2;
        int i3;
        int id = view.getId();
        int i4 = R$id.tvInstallment;
        if (id == i4) {
            i2 = R$string.payment_mode;
        } else {
            i2 = R$string.maximun_limit;
        }
        String string = getString(i2);
        if (view.getId() == i4) {
            i3 = this.t;
        } else {
            i3 = this.s;
        }
        FinanceFilterDialog financeFilterDialog = new FinanceFilterDialog(i3, string, list);
        financeFilterDialog.f = new g(this, financeFilterDialog, list, view);
        financeFilterDialog.show(getSupportFragmentManager(), "");
    }

    public final void M0(String str, String str2, TextView textView, TextView textView2) {
        int i2;
        if (H0(str)) {
            i2 = R$mipmap.homev6_icon_eyes_close;
            textView2.setText("******");
        } else {
            i2 = R$mipmap.homev6_icon_eyes_open;
            s a = s.a("");
            textView2.setText(a.a.getString(this.n + "_" + g.k() + "_" + str, "--"));
        }
        j.a(textView, str2, i2, new j(this, str, str2, textView, textView2), new f());
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        LoanProductsMarketActivity.super.onActivityResult(i2, i3, intent);
        if (i2 == 1000 && i3 == -1) {
            o0.b.d((Activity) null, "/finance/transactionResult", (Bundle) null, (Map) null);
        }
    }

    /* JADX WARNING: type inference failed for: r6v38, types: [W4.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v26, types: [com.huawei.http.b, com.huawei.ethiopia.finance.market.repository.FinanceMarketProductRepository] */
    @SuppressLint({"NotifyDataSetChanged"})
    public final void onCreate(@Nullable Bundle bundle) {
        LoanProductsMarketActivity.super.onCreate(bundle);
        int i2 = 0;
        if (this.categoryMenuInfo != null) {
            com.blankj.utilcode.util.f.e(this, ContextCompat.getColor(this, R$color.colorPrimary), false);
            e.a(this, this.categoryMenuInfo.getProductNameI18n(), R$layout.loan_category_toolbar);
            this.r = this.categoryMenuInfo.getLoanType();
        }
        List<FinanceMarketBankConfig.FinanceMarketBankItem> d2 = g.d();
        this.k = d2;
        if (d2 == null) {
            FinanceMarketProductModel financeMarketProductModel = this.c;
            financeMarketProductModel.getClass();
            new QueryFinanceBankListRepository().sendRequest(new e5.e(financeMarketProductModel));
        }
        ArrayList arrayList = this.f;
        arrayList.addAll(this.e);
        FinanceLoanMarketProductAdapter financeLoanMarketProductAdapter = new FinanceLoanMarketProductAdapter(R$layout.finance_item_loan_market_product, arrayList);
        this.d = financeLoanMarketProductAdapter;
        this.b.d.setAdapter(financeLoanMarketProductAdapter);
        this.b.n.setText(R$string.loan_product);
        this.b.h.setOnClickListener(new F(this, 5));
        this.b.k.setOnClickListener(new G(this, 3));
        FinanceLoanMarketProductAdapter financeLoanMarketProductAdapter2 = this.d;
        financeLoanMarketProductAdapter2.b = new c(this);
        financeLoanMarketProductAdapter2.a = new f(this);
        financeLoanMarketProductAdapter2.g = new i(this, 1);
        this.b.b.setOnClickListener(new S3.e(this, 4));
        this.b.c.setOnClickListener(new E(this, 2));
        G0();
        this.c.c.observe(this, new com.huawei.digitalpayment.schedule.activity.c(this, 1));
        this.c.b.observe(this, new com.huawei.digitalpayment.customer.login_module.login.i(this, 1));
        this.c.a.observe(this, new com.huawei.digitalpayment.customer.login_module.login.j(this, 1));
        this.c.e.observe(this, new k(this));
        this.c.d.observe(this, new e(this, 0));
        b.b c = b.a(new Object()).c(this.b.d);
        c.b = new I3.g();
        this.g = c;
        List<FinanceMarketBankConfig.FinanceMarketBankItem> list = this.k;
        if (list != null && !list.isEmpty()) {
            this.n = s.a("finance_sp_name_no_cache").b("finance_market_bank_code");
            this.p = s.a("finance_sp_name_no_cache").b("finance_market_bank_fundId");
            this.o = s.a("finance_sp_name_no_cache").b("finance_market_bank_company_name");
            this.q = s.a("finance_sp_name_no_cache").b("finance_market_bank_color");
            String b = s.a("finance_sp_name_no_cache").b("finance_market_term_and_condition");
            this.u = b;
            TextView textView = this.b.c;
            if (TextUtils.isEmpty(b)) {
                i2 = 8;
            }
            textView.setVisibility(i2);
            if (!TextUtils.isEmpty(this.q)) {
                I0(this.q);
            }
            FinanceMarketProductModel financeMarketProductModel2 = this.c;
            String str = this.p;
            financeMarketProductModel2.m = str;
            financeMarketProductModel2.b(this.n, str);
            this.l.notifyDataSetChanged();
        }
        String string = getString(R$string.maximum_credit_limit);
        String string2 = getString(R$string.sanduq_balance);
        String string3 = getString(R$string.available_credit_limit);
        ActivityLoanMarketBinding activityLoanMarketBinding = this.b;
        M0("KEY_SAVING_BALANCE", string2, activityLoanMarketBinding.l, activityLoanMarketBinding.m);
        ActivityLoanMarketBinding activityLoanMarketBinding2 = this.b;
        M0("KEY_LOAN_MAX_LIMIT", string, activityLoanMarketBinding2.i, activityLoanMarketBinding2.j);
        ActivityLoanMarketBinding activityLoanMarketBinding3 = this.b;
        M0("KEY_AVAILABLE_MELA_LIMIT", string3, activityLoanMarketBinding3.f, activityLoanMarketBinding3.g);
        a5.f fVar = a5.f.c;
        fVar.a("financeMarket").observe(this, new a(this, 1));
        fVar.b("financeMarket").observe(this, new i(this, 0));
        FinanceMarketProductModel financeMarketProductModel3 = this.c;
        if (financeMarketProductModel3 != null) {
            FinanceMarketProductModel financeMarketProductModel4 = financeMarketProductModel3;
            String str2 = this.r;
            FinanceMarketProductRepository financeMarketProductRepository = financeMarketProductModel4.h;
            if (financeMarketProductRepository != null) {
                financeMarketProductRepository.cancel();
            }
            QueryLoanContractsRepository queryLoanContractsRepository = financeMarketProductModel4.l;
            if (queryLoanContractsRepository != null) {
                queryLoanContractsRepository.cancel();
            }
            financeMarketProductModel4.c.setValue(V7.c.c());
            ? bVar = new com.huawei.http.b();
            bVar.addParams("loanType", str2);
            bVar.addParams("status", "Active");
            financeMarketProductModel4.h = bVar;
            if (!TextUtils.isEmpty(g.o())) {
                financeMarketProductModel4.h.addParams("serviceTypeId", g.o());
            }
            financeMarketProductModel4.h.sendRequest(new C2.b(financeMarketProductModel4, 3));
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.ethiopia.finance.market.LoanProductsMarketActivity] */
    public void onMyLoanClick(View view) {
        C0112a.a("finance market MyLoanClick_my_telebirr_mela_v1");
        Intent intent = new Intent(this, MyTelebirrTelaActivity.class);
        intent.putExtra("bankCode", "financeMarket");
        intent.putExtra("fundsLenderId", this.p);
        intent.putExtra("queryLoanMarketType", FaceVerificationResult.RESULT_SUCCESS);
        startActivity(intent);
    }
}
