package com.huawei.ethiopia.finance.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class FinanceHomeBalanceBinding extends ViewDataBinding {
}
