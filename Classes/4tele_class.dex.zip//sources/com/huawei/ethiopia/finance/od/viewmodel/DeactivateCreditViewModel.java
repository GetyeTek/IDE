package com.huawei.ethiopia.finance.od.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.od.repository.DeactivateCreditRepository;
import com.huawei.http.BaseResp;

public class DeactivateCreditViewModel extends ViewModel {
    public final MutableLiveData<c<BaseResp>> a = new MutableLiveData<>();
    public DeactivateCreditRepository b;

    public final void onCleared() {
        DeactivateCreditViewModel.super.onCleared();
        DeactivateCreditRepository deactivateCreditRepository = this.b;
        if (deactivateCreditRepository != null) {
            deactivateCreditRepository.cancel();
        }
    }
}
