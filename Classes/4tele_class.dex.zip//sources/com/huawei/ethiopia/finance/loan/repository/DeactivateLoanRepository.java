package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.http.BaseResp;
import com.huawei.http.b;
import p5.g;

public class DeactivateLoanRepository extends b<BaseResp, BaseResp> {
    public DeactivateLoanRepository(String str) {
        addParams("initiatorPin", g.a(str));
        addParams("pinVersion", g.l());
        addParams("actionReason", "");
    }

    public final String getApiPath() {
        return "v1/ethiopia/loan/deactive";
    }
}
