package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;

public class LoanConfig implements Serializable {
    private String applyLoanTitle;
    private String loanActivateTitle;
    private String loanAgreeTxt;
    private String loanIcon;
    private String loanProductsTitle;
    private String myLoanIcon;
    private String myLoanTxt;

    public String getApplyLoanTitle() {
        return this.applyLoanTitle;
    }

    public String getLoanActivateTitle() {
        return this.loanActivateTitle;
    }

    public String getLoanAgreeTxt() {
        return this.loanAgreeTxt;
    }

    public String getLoanIcon() {
        return this.loanIcon;
    }

    public String getLoanProductsTitle() {
        return this.loanProductsTitle;
    }

    public String getMyLoanIcon() {
        return this.myLoanIcon;
    }

    public String getMyLoanTxt() {
        return this.myLoanTxt;
    }

    public void setApplyLoanTitle(String str) {
        this.applyLoanTitle = str;
    }

    public void setLoanActivateTitle(String str) {
        this.loanActivateTitle = str;
    }

    public void setLoanAgreeTxt(String str) {
        this.loanAgreeTxt = str;
    }

    public void setLoanIcon(String str) {
        this.loanIcon = str;
    }

    public void setLoanProductsTitle(String str) {
        this.loanProductsTitle = str;
    }

    public void setMyLoanIcon(String str) {
        this.myLoanIcon = str;
    }

    public void setMyLoanTxt(String str) {
        this.myLoanTxt = str;
    }
}
