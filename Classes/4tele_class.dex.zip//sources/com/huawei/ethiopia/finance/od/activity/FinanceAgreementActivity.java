package com.huawei.ethiopia.finance.od.activity;

import V7.e;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.schedule.activity.n;
import com.huawei.ethiopia.component.service.WebViewCallBackService;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceAgreementBinding;
import com.huawei.ethiopia.finance.od.viewmodel.FinanceActiveViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import f5.C0083f;
import f5.C0084g;
import java.nio.charset.StandardCharsets;
import o0.b;
import p5.g;
import w5.C0112a;

@Route(path = "/finance/financeAgreement")
public class FinanceAgreementActivity extends DataBindingActivity<FinanceActivityFinanceAgreementBinding, FinanceActiveViewModel> {
    public static final /* synthetic */ int g = 0;
    public String d;
    public String e;
    public String f;

    public class a extends WebViewClient {
        public a() {
        }

        public final void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            int i = FinanceAgreementActivity.g;
            FinanceAgreementActivity.this.b.b.setEnabled(true);
        }
    }

    public final int C0() {
        return R$layout.finance_activity_finance_agreement;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        FinanceAgreementActivity.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 100 && i2 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            String c = g.c(this.f);
            C0112a.a("OD_" + c + "_active_pin_v1");
            if (TextUtils.equals(this.f, "financeMarket")) {
                this.c.a(this.d, str, g.o());
            } else {
                this.c.a(this.d, str, "");
            }
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.ethiopia.finance.od.activity.FinanceAgreementActivity, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceAgreementActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getIntent().getStringExtra("agreementTitle"), R.layout.common_toolbar);
        this.d = getIntent().getStringExtra("id");
        this.e = getIntent().getStringExtra("fundsLenderId");
        this.f = getIntent().getStringExtra("bankCode");
        this.b.b.setEnabled(false);
        this.b.b.setOnCheckedChangeListener(new C0084g(this));
        String str = "";
        if ("finance_saving".equals(this.d)) {
            if (!(g.i().a == null || g.i().a.getFinanceServiceUIConfig() == null || g.i().a.getFinanceServiceUIConfig().getSaving() == null)) {
                str = g.i().a.getFinanceServiceUIConfig().getSaving().getSavingAgreeTxt();
            }
            if (!TextUtils.isEmpty(str)) {
                this.b.b.setText(str);
            } else {
                this.b.b.setText(R$string.i_have_read_and_accept_the_terms_and_conditions_for_telebirr_sanduq);
            }
        } else if ("finance_overdraft".equals(this.d)) {
            this.b.b.setText(R$string.i_have_read_and_accept_the_terms_and_conditions_for_telebirr_endekise);
        } else {
            if (!(g.i().a == null || g.i().a.getFinanceServiceUIConfig() == null || g.i().a.getFinanceServiceUIConfig().getLoan() == null)) {
                str = g.i().a.getFinanceServiceUIConfig().getLoan().getLoanAgreeTxt();
            }
            if (!TextUtils.isEmpty(str)) {
                this.b.b.setText(str);
            } else {
                this.b.b.setText(R$string.i_have_read_and_accept_the_terms_and_conditions_for_credit_pay);
            }
        }
        this.b.a.setOnClickListener(new n(this, 4));
        b.c(WebViewCallBackService.class).a(new a());
        n.a.b().getClass();
        getSupportFragmentManager().beginTransaction().add(R$id.ll_container, (Fragment) n.a.a("/webViewModule/webviewFragment").withString("url", getIntent().getStringExtra("protocolUrl")).navigation()).commit();
        this.c.a.observe(this, new C0083f(this));
    }
}
