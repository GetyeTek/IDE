package com.huawei.ethiopia.finance.saving.adapter;

import androidx.databinding.ViewDataBinding;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingAccountBinding;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.payment.mvvm.DataBindingAdapter;

public class LockedSavingAccountAdapter extends DataBindingAdapter<FinanceProductInfo, FinanceItemLockedSavingAccountBinding> {
    public final int a() {
        return R$layout.finance_item_locked_saving_account;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        FinanceItemLockedSavingAccountBinding financeItemLockedSavingAccountBinding = (FinanceItemLockedSavingAccountBinding) viewDataBinding;
        FinanceProductInfo financeProductInfo = (FinanceProductInfo) obj;
        financeItemLockedSavingAccountBinding.c.setText(financeProductInfo.getProductNameI18n());
        financeItemLockedSavingAccountBinding.d.setText(financeProductInfo.getPrincipalAmount());
        financeItemLockedSavingAccountBinding.b.setText(financeProductInfo.getMaturityDate());
        financeItemLockedSavingAccountBinding.e.setText(financeProductInfo.getTotalCapitalizationAmount());
    }
}
