package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundImageView;

public abstract class FinanceItemFilterProductBinding extends ViewDataBinding {
    @NonNull
    public final RoundImageView a;
    @NonNull
    public final TextView b;

    public FinanceItemFilterProductBinding(DataBindingComponent dataBindingComponent, View view, RoundImageView roundImageView, TextView textView) {
        super(dataBindingComponent, view, 0);
        this.a = roundImageView;
        this.b = textView;
    }
}
