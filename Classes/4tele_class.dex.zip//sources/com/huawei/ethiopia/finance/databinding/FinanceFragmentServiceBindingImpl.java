package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceFragmentServiceBindingImpl extends FinanceFragmentServiceBinding {
    @Nullable
    public static final SparseIntArray r;
    public long q;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        r = sparseIntArray;
        sparseIntArray.put(R$id.ivBackgroundVein, 1);
        sparseIntArray.put(R$id.baseline, 2);
        sparseIntArray.put(R$id.tvBottomBalance, 3);
        sparseIntArray.put(R$id.verticalGuideline, 4);
        sparseIntArray.put(R$id.tvBottomBalanceValue, 5);
        sparseIntArray.put(R$id.llTopBalance, 6);
        sparseIntArray.put(R$id.tvLeftBalance, 7);
        sparseIntArray.put(R$id.tvRightBalance, 8);
        sparseIntArray.put(R$id.tvLeftBalanceValue, 9);
        sparseIntArray.put(R$id.tvRightBalanceValue, 10);
        sparseIntArray.put(R$id.clLoan, 11);
        sparseIntArray.put(R$id.ivMela, 12);
        sparseIntArray.put(R$id.tvMela, 13);
        sparseIntArray.put(R$id.clSaving, 14);
        sparseIntArray.put(R$id.ivSanduq, 15);
        sparseIntArray.put(R$id.tvSanduq, 16);
        sparseIntArray.put(R$id.clOverDraft, 17);
        sparseIntArray.put(R$id.ivEndekise, 18);
        sparseIntArray.put(R$id.tvEndekise, 19);
        sparseIntArray.put(R$id.viewPager, 20);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.q = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.q != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.q = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
