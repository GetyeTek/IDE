package com.huawei.ethiopia.finance.market.adapter;

import O9.c;
import android.graphics.Color;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import java.util.Map;

public class LoanMarketGuideAdapter extends BaseQuickAdapter<FinanceMarketBankConfig.FinanceMarketBankItem, BaseViewHolder> {
    public LoanMarketGuideAdapter() {
        super(R$layout.item_loan_market_guide);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        FinanceMarketBankConfig.FinanceMarketBankItem financeMarketBankItem = (FinanceMarketBankConfig.FinanceMarketBankItem) obj;
        RoundImageView view = baseViewHolder.getView(R$id.ivBankIcon);
        int i = R$id.tvBankName;
        ((TextView) baseViewHolder.getView(i)).setTextColor(ContextCompat.getColor(getContext(), R$color.black));
        baseViewHolder.getView(R$id.rlBankItem).getBaseFilletView().e(Color.parseColor(financeMarketBankItem.getThemeColor()));
        Map bankNameI18n = financeMarketBankItem.getBankNameI18n();
        String currentLang = LanguageUtils.getInstance().getCurrentLang();
        if (bankNameI18n != null) {
            baseViewHolder.setText(i, (CharSequence) bankNameI18n.get(currentLang));
        }
        c.c(view, financeMarketBankItem.getLogo(), R$mipmap.finance_bankaccount_icon_default_bank_logo);
    }
}
