package com.huawei.ethiopia.finance.loan.adapter;

import android.text.TextUtils;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceItemFinanceLoanContractsBinding;
import com.huawei.ethiopia.finance.resp.AppRepaymentSchedule;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import java.util.ArrayList;
import java.util.List;
import p5.g;

public class FinanceLoanContractsAdapter extends BaseQuickAdapter<LoanContractsInfo, BaseViewHolder> {
    public FinanceLoanContractsAdapter(@Nullable ArrayList arrayList) {
        super(R$layout.finance_item_finance_loan_contracts, arrayList);
        addChildClickViewIds(new int[]{R$id.btn_repay, R$id.btn_extend});
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        LoanContractsInfo loanContractsInfo = (LoanContractsInfo) obj;
        FinanceItemFinanceLoanContractsBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        if (loanContractsInfo.isInstallments()) {
            if (!TextUtils.equals(loanContractsInfo.getCurrentInstallment(), loanContractsInfo.getTotalInstallments())) {
                bind.f.setVisibility(0);
                bind.f.setText(String.format("(%1$s/%2$s)", new Object[]{loanContractsInfo.getCurrentInstallment(), loanContractsInfo.getTotalInstallments()}));
            }
            List<AppRepaymentSchedule> repaymentSchedules = loanContractsInfo.getRepaymentSchedules();
            if (repaymentSchedules == null || repaymentSchedules.isEmpty()) {
                bind.c.setText(loanContractsInfo.getLoanBalance());
                bind.d.setText(loanContractsInfo.getContractId());
                bind.f.setVisibility(8);
            } else {
                AppRepaymentSchedule appRepaymentSchedule = repaymentSchedules.get(0);
                bind.c.setText(appRepaymentSchedule.getTotalScheduleAmount());
                String format = String.format("%1$s %2$s", new Object[]{J.a().getString(R$string.due_date), appRepaymentSchedule.getEndDate()});
                if (TextUtils.equals("overdue", appRepaymentSchedule.getStatus())) {
                    TextView textView = bind.e;
                    textView.setVisibility(0);
                    textView.setText(appRepaymentSchedule.getStatus());
                }
                bind.d.setText(format);
            }
        } else {
            List<AppRepaymentSchedule> repaymentSchedules2 = loanContractsInfo.getRepaymentSchedules();
            if (repaymentSchedules2 == null || repaymentSchedules2.isEmpty()) {
                bind.d.setText(loanContractsInfo.getContractId());
                bind.f.setVisibility(8);
            } else {
                AppRepaymentSchedule appRepaymentSchedule2 = repaymentSchedules2.get(0);
                String format2 = String.format("%1$s %2$s", new Object[]{J.a().getString(R$string.due_date), appRepaymentSchedule2.getEndDate()});
                if (TextUtils.equals("overdue", appRepaymentSchedule2.getStatus())) {
                    bind.e.setVisibility(0);
                    bind.e.setText(appRepaymentSchedule2.getStatus());
                }
                bind.d.setText(format2);
            }
            bind.c.setText(loanContractsInfo.getLoanBalance());
            bind.f.setVisibility(8);
        }
        TextView textView2 = bind.g;
        textView2.setText("（" + g.g() + "）");
        boolean isActive = loanContractsInfo.isActive();
        RoundTextView roundTextView = bind.b;
        if (isActive) {
            roundTextView.setVisibility(0);
        } else {
            roundTextView.setVisibility(8);
        }
        boolean isAllowRollover = loanContractsInfo.isAllowRollover();
        RoundTextView roundTextView2 = bind.a;
        if (isAllowRollover) {
            roundTextView2.setText(R$string.extend);
            roundTextView2.setVisibility(0);
        } else if (loanContractsInfo.isAllowIntall()) {
            roundTextView2.setVisibility(0);
            roundTextView2.setText(R$string.finance_install);
        } else {
            roundTextView2.setVisibility(8);
        }
    }
}
