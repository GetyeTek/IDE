package com.huawei.ethiopia.finance.saving.adapter;

import U7.a;
import U7.b;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.camera.camera2.internal.O;
import androidx.core.widget.NestedScrollView;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.v;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceItemSavingTimeProductBinding;
import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import java.util.List;
import l2.M;
import n5.C0103a;
import n5.c;
import p5.g;

public class LockedSavingProductAdapter extends RecyclerView.Adapter<BaseViewHolder<ViewDataBinding>> {
    public a a;
    public b b;
    public int c;
    public String d;
    public FragmentActivity e;
    public List<SavingActivatableProduct> f;

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return LockedSavingProductAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }

    public final int getItemCount() {
        List<SavingActivatableProduct> list = this.f;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public final int getItemViewType(int i) {
        return R$layout.finance_item_saving_time_product;
    }

    public final void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        String str;
        BaseViewHolder baseViewHolder = (BaseViewHolder) viewHolder;
        List<SavingActivatableProduct> list = this.f;
        if (list != null) {
            SavingActivatableProduct savingActivatableProduct = list.get(i);
            T t = baseViewHolder.a;
            if (t instanceof FinanceItemSavingTimeProductBinding) {
                FinanceItemSavingTimeProductBinding financeItemSavingTimeProductBinding = (FinanceItemSavingTimeProductBinding) t;
                financeItemSavingTimeProductBinding.f.setLayoutManager(new LinearLayoutManager(financeItemSavingTimeProductBinding.getRoot().getContext()));
                financeItemSavingTimeProductBinding.g.getBaseFilletView().e(g.f(financeItemSavingTimeProductBinding.getRoot().getContext(), g.i().a, this.d));
                financeItemSavingTimeProductBinding.k.setText(savingActivatableProduct.getProductNameI18n());
                financeItemSavingTimeProductBinding.h.setText(savingActivatableProduct.getRateValue());
                String string = this.e.getString(R$string.min_deposit_amount);
                if (TextUtils.isEmpty(savingActivatableProduct.getMinOpeningBalance())) {
                    str = "0.00";
                } else {
                    str = savingActivatableProduct.getMinOpeningBalance();
                }
                financeItemSavingTimeProductBinding.i.setText(O.a(string, " ：", str));
                boolean isShow = savingActivatableProduct.isShow();
                ImageView imageView = financeItemSavingTimeProductBinding.c;
                TextView textView = financeItemSavingTimeProductBinding.j;
                RoundRecyclerView roundRecyclerView = financeItemSavingTimeProductBinding.f;
                NestedScrollView nestedScrollView = financeItemSavingTimeProductBinding.b;
                if (isShow) {
                    textView.setText(J.a().getString(R$string.less));
                    imageView.setRotation(180.0f);
                    nestedScrollView.getLayoutParams().height = Math.max(this.c, v.a(87.0f));
                    nestedScrollView.requestLayout();
                    ViewGroup.LayoutParams layoutParams = roundRecyclerView.getLayoutParams();
                    v.a(62.0f);
                    layoutParams.height = 0;
                    roundRecyclerView.requestLayout();
                } else {
                    textView.setText(J.a().getString(R$string.more));
                    imageView.setRotation(0.0f);
                    nestedScrollView.getLayoutParams().height = 1;
                    nestedScrollView.requestLayout();
                    roundRecyclerView.getLayoutParams().height = v.a(62.0f) * Math.min(2, 0);
                    roundRecyclerView.requestLayout();
                }
                financeItemSavingTimeProductBinding.e.setOnClickListener(new C0103a(this, savingActivatableProduct));
                financeItemSavingTimeProductBinding.d.setOnClickListener(new n5.b(this, savingActivatableProduct, financeItemSavingTimeProductBinding));
                financeItemSavingTimeProductBinding.a.setOnClickListener(new M(1, this, savingActivatableProduct));
                financeItemSavingTimeProductBinding.getRoot().setOnClickListener(new c(this, savingActivatableProduct));
            }
        }
    }

    @NonNull
    public final RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new BaseViewHolder(DataBindingUtil.inflate(LayoutInflater.from(viewGroup.getContext()), i, viewGroup, false));
    }
}
