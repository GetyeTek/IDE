package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceActivityTransactionResultBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final View b;
    @NonNull
    public final RecyclerView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;

    public FinanceActivityTransactionResultBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, View view2, RecyclerView recyclerView, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = view2;
        this.c = recyclerView;
        this.d = textView;
        this.e = textView2;
        this.f = textView3;
        this.g = textView4;
    }
}
