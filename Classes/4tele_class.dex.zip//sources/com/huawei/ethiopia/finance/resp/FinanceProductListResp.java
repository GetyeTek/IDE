package com.huawei.ethiopia.finance.resp;

import com.google.gson.annotations.SerializedName;
import com.huawei.http.BaseResp;
import java.util.List;

public class FinanceProductListResp extends BaseResp {
    @SerializedName(alternate = {"accountItems"}, value = "productList")
    private List<FinanceProductInfo> productList;
    private String totalBalance;

    public List<FinanceProductInfo> getProductList() {
        return this.productList;
    }

    public String getTotalBalance() {
        return this.totalBalance;
    }

    public void setProductList(List<FinanceProductInfo> list) {
        this.productList = list;
    }

    public void setTotalBalance(String str) {
        this.totalBalance = str;
    }
}
