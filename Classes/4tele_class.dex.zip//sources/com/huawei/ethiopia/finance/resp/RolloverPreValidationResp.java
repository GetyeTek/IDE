package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;
import java.util.List;

public class RolloverPreValidationResp extends BaseResp {
    private String bankIcon;
    private String contractID;
    private List<FinanceDisplayItem> displayItems;
    private String freeChargeDays;
    private String productName;
    private List<RepaymentSchedule> repaymentSchedules;
    private String rolloverChargeDays;
    private String rolloverDays;
    private String rolloverFee;
    private String statementID;

    public String getBankIcon() {
        return this.bankIcon;
    }

    public String getContractID() {
        return this.contractID;
    }

    public List<FinanceDisplayItem> getDisplayItems() {
        return this.displayItems;
    }

    public String getFreeChargeDays() {
        return this.freeChargeDays;
    }

    public String getProductName() {
        return this.productName;
    }

    public List<RepaymentSchedule> getRepaymentSchedules() {
        return this.repaymentSchedules;
    }

    public String getRolloverChargeDays() {
        return this.rolloverChargeDays;
    }

    public String getRolloverDays() {
        return this.rolloverDays;
    }

    public String getRolloverFee() {
        return this.rolloverFee;
    }

    public String getStatementID() {
        return this.statementID;
    }

    public void setBankIcon(String str) {
        this.bankIcon = str;
    }

    public void setContractID(String str) {
        this.contractID = str;
    }

    public void setDisplayItems(List<FinanceDisplayItem> list) {
        this.displayItems = list;
    }

    public void setFreeChargeDays(String str) {
        this.freeChargeDays = str;
    }

    public void setProductName(String str) {
        this.productName = str;
    }

    public void setRepaymentSchedules(List<RepaymentSchedule> list) {
        this.repaymentSchedules = list;
    }

    public void setRolloverChargeDays(String str) {
        this.rolloverChargeDays = str;
    }

    public void setRolloverDays(String str) {
        this.rolloverDays = str;
    }

    public void setRolloverFee(String str) {
        this.rolloverFee = str;
    }

    public void setStatementID(String str) {
        this.statementID = str;
    }
}
