package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.digitalpayment.customer.httplib.response.BasicConfigResp;
import com.huawei.http.b;
import java.util.ArrayList;

public class QueryFinanceBankListRepository extends b<BasicConfigResp, BasicConfigResp> {
    public QueryFinanceBankListRepository() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("financeMarketBankConfig");
        addParams("configTypes", arrayList);
    }

    public final String getApiPath() {
        return "v1/basicConfig";
    }
}
