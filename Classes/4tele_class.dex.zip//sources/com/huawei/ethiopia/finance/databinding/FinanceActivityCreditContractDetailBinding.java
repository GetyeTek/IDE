package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class FinanceActivityCreditContractDetailBinding extends ViewDataBinding {
    @NonNull
    public final HFRecyclerView a;

    public FinanceActivityCreditContractDetailBinding(DataBindingComponent dataBindingComponent, View view, HFRecyclerView hFRecyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = hFRecyclerView;
    }
}
