package com.huawei.ethiopia.finance.saving.activity;

import N0.F;
import O9.c;
import S3.i;
import U7.a;
import W1.b;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBindings;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.v;
import com.huawei.digitalpayment.customer.login_module.login.j;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceActivitySavingBinding;
import com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding;
import com.huawei.ethiopia.finance.databinding.FinanceLockedSavingProductTitleLayoutBinding;
import com.huawei.ethiopia.finance.databinding.FinanceMyFixedSavingLayoutBinding;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel;
import com.huawei.ethiopia.finance.resp.FinanceMenu;
import com.huawei.ethiopia.finance.resp.FinanceMenuListResp;
import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import com.huawei.ethiopia.finance.saving.adapter.LockedSavingProductAdapter;
import com.huawei.ethiopia.finance.saving.adapter.SavingProductAdapter;
import com.huawei.ethiopia.finance.saving.viewmodel.SavingViewModel;
import com.huawei.payment.mvvm.DataBindingAdapter;
import java.nio.charset.StandardCharsets;
import m5.C0101b;
import p5.g;

@Route(path = "/finance/savingHome")
public class SavingFragment extends Fragment {
    public SavingProductAdapter a;
    public FinanceActivitySavingBinding b;
    public SavingViewModel c;
    public FinanceDispacherViewModel d;
    public String e;
    public FinanceMenu f;
    public b.b g;
    public String h;
    public boolean i;
    public LockedSavingProductAdapter j;
    public FinanceMyFixedSavingLayoutBinding k;
    public FinanceLockedSavingProductTitleLayoutBinding l;

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        SavingFragment.super.onActivityResult(i2, i3, intent);
        if (intent != null && i2 == 102 && i3 == -1) {
            this.c.a(new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8), this.e);
        }
    }

    /* JADX WARNING: type inference failed for: r2v3, types: [W4.a, java.lang.Object] */
    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        this.b = DataBindingUtil.inflate(layoutInflater, R$layout.finance_activity_saving, viewGroup, false);
        b.b c2 = b.a(new Object()).c(this.b.b);
        c2.b = new C0101b(this);
        this.g = c2;
        return this.b.getRoot();
    }

    /* JADX WARNING: type inference failed for: r0v21, types: [androidx.lifecycle.Observer, java.lang.Object] */
    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        SavingFragment.super.onViewCreated(view, bundle);
        if (getArguments() != null) {
            Bundle arguments = getArguments();
            this.e = arguments.getString("fundsLenderId");
            this.f = (FinanceMenu) arguments.getSerializable("financeMenu");
            this.h = arguments.getString("bankCode");
        }
        FinanceDispacherViewModel financeDispacherViewModel = new ViewModelProvider(this).get(FinanceDispacherViewModel.class);
        this.d = financeDispacherViewModel;
        financeDispacherViewModel.b("finance_saving", this.e);
        FinanceFragmentLoanHomeUnactiveBinding financeFragmentLoanHomeUnactiveBinding = this.b.c;
        financeFragmentLoanHomeUnactiveBinding.a.setOnClickListener(new i(this, 6));
        FinanceMenu financeMenu = this.f;
        if (financeMenu != null) {
            financeFragmentLoanHomeUnactiveBinding.b.setText(financeMenu.getSubTitle());
        }
        this.b.e.setLayoutManager(new LinearLayoutManager(requireContext()));
        FragmentActivity activity = getActivity();
        String str = this.h;
        DataBindingAdapter dataBindingAdapter = new DataBindingAdapter();
        dataBindingAdapter.d = str;
        dataBindingAdapter.c = activity;
        this.a = dataBindingAdapter;
        this.b.f.setLayoutManager(new LinearLayoutManager(requireContext()));
        FragmentActivity activity2 = getActivity();
        RecyclerView.Adapter adapter = new RecyclerView.Adapter();
        adapter.e = activity2;
        this.j = adapter;
        adapter.d = this.h;
        adapter.a = new a(this);
        adapter.b = new U7.b(this);
        this.k = this.b.d;
        View inflate = getLayoutInflater().inflate(R$layout.finance_locked_saving_product_title_layout, (ViewGroup) null, false);
        int i2 = R$id.tvSavingLockedTitle;
        TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i2);
        if (textView != null) {
            this.l = new FinanceLockedSavingProductTitleLayoutBinding((LinearLayout) inflate, textView);
            FinanceMenuListResp financeMenuListResp = g.i().a;
            if (!(financeMenuListResp == null || financeMenuListResp.getFinanceServiceUIConfig() == null || financeMenuListResp.getFinanceServiceUIConfig().getSaving() == null)) {
                if (!TextUtils.isEmpty(financeMenuListResp.getFinanceServiceUIConfig().getSaving().getMySavingIcon())) {
                    c.c(this.k.b, financeMenuListResp.getFinanceServiceUIConfig().getSaving().getMySavingIcon(), -1);
                }
                if (!TextUtils.isEmpty(financeMenuListResp.getFinanceServiceUIConfig().getSaving().getMySavingTxt())) {
                    this.k.d.setText(financeMenuListResp.getFinanceServiceUIConfig().getSaving().getMySavingTxt());
                }
                if (this.l != null) {
                    if (!TextUtils.isEmpty(financeMenuListResp.getFinanceServiceUIConfig().getSaving().getSavingProductsTitle())) {
                        this.l.b.setVisibility(0);
                        this.l.b.setText(financeMenuListResp.getFinanceServiceUIConfig().getSaving().getSavingProductsTitle());
                    } else {
                        this.l.b.setVisibility(8);
                    }
                }
            }
            this.k.c.getBaseFilletView().e(g.f(requireContext(), financeMenuListResp, this.h));
            this.k.a.setVisibility(8);
            this.l.a.setVisibility(8);
            this.b.f.a(-1, this.l.a);
            this.k.c.setOnClickListener(new K6.a(this, 6));
            this.b.f.setAdapter(this.j);
            int f2 = g.f(requireContext(), g.i().a, this.h);
            this.b.c.b.getBaseFilletView().f(v.a(1.5f));
            this.b.c.b.getBaseFilletView().e(f2);
            this.l.b.setTextColor(f2);
            this.b.e.setAdapter(this.a);
            this.b.a.setOnClickListener(new F(this, 12));
            this.c = new ViewModelProvider(this).get(SavingViewModel.class);
            this.d.a.observe(getViewLifecycleOwner(), new com.huawei.digitalpayment.schedule.activity.b(this, 3));
            this.c.b.observe(getViewLifecycleOwner(), new com.huawei.digitalpayment.schedule.activity.c(this, 3));
            this.c.d.observe(getViewLifecycleOwner(), new com.huawei.digitalpayment.customer.login_module.login.i(this, 3));
            this.c.a.observe(getViewLifecycleOwner(), new j(this, 2));
            this.c.c.observe(getViewLifecycleOwner(), new Object());
            return;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }

    public final void v0(SavingActivatableProduct savingActivatableProduct) {
        Intent intent = new Intent(requireContext(), LockedSavingProductDetailActivity.class);
        intent.putExtra("bankCode", this.h);
        intent.putExtra("fundsLenderId", this.e);
        intent.putExtra("productId", savingActivatableProduct.getProductId());
        intent.putExtra("productUnquieID", savingActivatableProduct.getUniqueID());
        startActivity(intent);
    }
}
