package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceActivityCreditPayHomeBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final FrameLayout c;
    @NonNull
    public final LinearLayout d;
    @NonNull
    public final LinearLayout e;
    @NonNull
    public final LinearLayout f;
    @NonNull
    public final FinanceFragmentLoanHomeUnactiveBinding g;
    @NonNull
    public final FinanceNoRelevantDataBinding h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final ViewPager2 k;

    public FinanceActivityCreditPayHomeBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, RoundTextView roundTextView2, FrameLayout frameLayout, LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, FinanceFragmentLoanHomeUnactiveBinding financeFragmentLoanHomeUnactiveBinding, FinanceNoRelevantDataBinding financeNoRelevantDataBinding, TextView textView, TextView textView2, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 2);
        this.a = roundTextView;
        this.b = roundTextView2;
        this.c = frameLayout;
        this.d = linearLayout;
        this.e = linearLayout2;
        this.f = linearLayout3;
        this.g = financeFragmentLoanHomeUnactiveBinding;
        this.h = financeNoRelevantDataBinding;
        this.i = textView;
        this.j = textView2;
        this.k = viewPager2;
    }
}
