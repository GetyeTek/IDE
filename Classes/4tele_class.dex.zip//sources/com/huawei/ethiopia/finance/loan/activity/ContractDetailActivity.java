package com.huawei.ethiopia.finance.loan.activity;

import V7.c;
import V7.e;
import a5.C0023a;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.ActivityContractDetailBinding;
import com.huawei.ethiopia.finance.loan.adapter.ResultAdapter;
import com.huawei.ethiopia.finance.loan.viewmodel.ContractDetailViewModel;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.ethiopia.finance.resp.LoanStatementResp;
import com.huawei.http.b;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;

@Route(path = "/finance/contractDetail")
public class ContractDetailActivity extends DataBindingActivity<ActivityContractDetailBinding, ContractDetailViewModel> {
    public static final /* synthetic */ int i = 0;
    public String d;
    public String e;
    public LoanStatementResp f;
    public LoanContractsInfo g;
    public ResultAdapter h;

    public final int C0() {
        return R$layout.activity_contract_detail;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.ethiopia.finance.loan.activity.ContractDetailActivity, android.app.Activity, com.huawei.payment.mvvm.DataBindingActivity, androidx.fragment.app.FragmentActivity] */
    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        ContractDetailActivity.super.onActivityResult(i2, i3, intent);
        if (i2 == 1113 && i3 == -1) {
            setResult(-1);
            finish();
        }
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.ethiopia.finance.loan.activity.ContractDetailActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        ContractDetailActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.contract_details), R.layout.common_toolbar);
        this.d = getIntent().getStringExtra("bankCode");
        this.e = getIntent().getStringExtra("contractId");
        this.f = (LoanStatementResp) getIntent().getSerializableExtra("loanStatementResp");
        this.g = (LoanContractsInfo) getIntent().getSerializableExtra("loanContractsInfo");
        ContractDetailViewModel contractDetailViewModel = this.c;
        String str = this.e;
        String repaymentAmount = this.f.getRepaymentAmount();
        contractDetailViewModel.a.setValue(c.c());
        b bVar = new b();
        bVar.addParams("contractID", str);
        bVar.addParams("repaymentAmount", repaymentAmount);
        bVar.sendRequest(new C0023a(contractDetailViewModel, 0));
        this.b.b.setLayoutManager(new LinearLayoutManager(this));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.finance_item_contract_display);
        this.h = baseQuickAdapter;
        this.b.b.setAdapter(baseQuickAdapter);
        this.b.a.setOnClickListener(new com.huawei.common.widget.banner.b(this, 2));
        this.c.a.observe(this, new e(this, 0));
    }
}
