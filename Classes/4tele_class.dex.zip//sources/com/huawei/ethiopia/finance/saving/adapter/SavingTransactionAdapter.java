package com.huawei.ethiopia.finance.saving.adapter;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.camera.view.e;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import c0.b;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionBinding;
import com.huawei.ethiopia.finance.resp.TransactionInfo;
import com.huawei.payment.mvvm.DataBindingViewHolder;

public class SavingTransactionAdapter extends ListAdapter<TransactionInfo, DataBindingViewHolder<FinanceItemSavingProductTransactionBinding>> {
    public static final a b = new DiffUtil.ItemCallback();
    public e a;

    public class a extends DiffUtil.ItemCallback<TransactionInfo> {
        public static boolean a(@NonNull TransactionInfo transactionInfo, @NonNull TransactionInfo transactionInfo2) {
            if (!TextUtils.equals(transactionInfo.getShowTitle(), transactionInfo2.getShowTitle()) || !TextUtils.equals(transactionInfo.getShowContent(), transactionInfo2.getShowContent()) || !TextUtils.equals(transactionInfo.getShowAmount(), transactionInfo2.getShowAmount())) {
                return false;
            }
            return true;
        }

        public final /* bridge */ /* synthetic */ boolean areContentsTheSame(@NonNull Object obj, @NonNull Object obj2) {
            return a((TransactionInfo) obj, (TransactionInfo) obj2);
        }

        public final boolean areItemsTheSame(@NonNull Object obj, @NonNull Object obj2) {
            return a((TransactionInfo) obj, (TransactionInfo) obj2);
        }
    }

    public SavingTransactionAdapter() {
        super(b);
    }

    public final void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        String str;
        DataBindingViewHolder dataBindingViewHolder = (DataBindingViewHolder) viewHolder;
        TransactionInfo transactionInfo = (TransactionInfo) getItem(i);
        dataBindingViewHolder.a.c.setText(transactionInfo.getShowTitle());
        FinanceItemSavingProductTransactionBinding financeItemSavingProductTransactionBinding = dataBindingViewHolder.a;
        financeItemSavingProductTransactionBinding.b.setText(transactionInfo.getShowContent());
        String showTitle = transactionInfo.getShowTitle();
        TextView textView = financeItemSavingProductTransactionBinding.a;
        textView.setText(showTitle);
        if (TextUtils.isEmpty(transactionInfo.getTransactionAmount())) {
            str = transactionInfo.getShowAmount();
        } else {
            str = transactionInfo.getTransactionAmount();
        }
        textView.setText(str);
        financeItemSavingProductTransactionBinding.getRoot().setOnClickListener(new b(2, this, transactionInfo));
    }

    @NonNull
    public final RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new DataBindingViewHolder(DataBindingUtil.inflate(LayoutInflater.from(viewGroup.getContext()), R$layout.finance_item_saving_product_transaction, viewGroup, false));
    }
}
