package com.huawei.ethiopia.finance.loan.activity;

import V7.e;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityMyTelebirrMelaBinding;
import com.huawei.ethiopia.finance.loan.fragment.MyTelebirrTelaFragment;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.List;
import p5.g;

public class MyTelebirrTelaActivity extends DataBindingActivity<FinanceActivityMyTelebirrMelaBinding, ViewModel> implements d {
    public String d;
    public String e;
    public String f;
    public String g;

    public final int C0() {
        return R$layout.finance_activity_my_telebirr_mela;
    }

    public final String i() {
        return this.e;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        MyTelebirrTelaActivity.super.onActivityResult(i, i2, intent);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments != null && !fragments.isEmpty()) {
            for (Fragment onActivityResult : fragments) {
                onActivityResult.onActivityResult(i, i2, intent);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.content.Context, com.huawei.ethiopia.finance.loan.activity.MyTelebirrTelaActivity, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        MyTelebirrTelaActivity.super.onCreate(bundle);
        Intent intent = getIntent();
        if (intent != null) {
            this.d = intent.getStringExtra("bankCode");
            this.e = intent.getStringExtra("bankIcon");
            this.f = intent.getStringExtra("fundsLenderId");
            this.g = intent.getStringExtra("queryLoanMarketType");
        }
        String string = getString(R$string.my_credit);
        if (!(g.i().a == null || g.i().a.getFinanceServiceUIConfig() == null || g.i().a.getFinanceServiceUIConfig().getLoan() == null || TextUtils.isEmpty(g.i().a.getFinanceServiceUIConfig().getLoan().getMyLoanTxt()))) {
            string = g.i().a.getFinanceServiceUIConfig().getLoan().getMyLoanTxt();
        }
        e.a(this, string, R.layout.common_toolbar);
        String str = this.d;
        String str2 = this.f;
        String str3 = this.g;
        Bundle bundle2 = new Bundle();
        bundle2.putString("bankCode", str);
        bundle2.putString("fundsLenderId", str2);
        bundle2.putString("queryLoanMarketType", str3);
        MyTelebirrTelaFragment myTelebirrTelaFragment = new MyTelebirrTelaFragment();
        myTelebirrTelaFragment.setArguments(bundle2);
        getSupportFragmentManager().beginTransaction().add(R$id.container, myTelebirrTelaFragment).commit();
    }
}
