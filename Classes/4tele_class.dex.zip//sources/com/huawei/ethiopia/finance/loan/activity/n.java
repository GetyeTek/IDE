package com.huawei.ethiopia.finance.loan.activity;

public final /* synthetic */ class n implements Runnable {
    public final /* synthetic */ FinanceServiceConfigActivity a;

    public /* synthetic */ n(FinanceServiceConfigActivity financeServiceConfigActivity) {
        this.a = financeServiceConfigActivity;
    }

    public final void run() {
        int i = FinanceServiceConfigActivity.h;
        FinanceServiceConfigActivity financeServiceConfigActivity = this.a;
        financeServiceConfigActivity.c.a(financeServiceConfigActivity.bankCode);
    }
}
