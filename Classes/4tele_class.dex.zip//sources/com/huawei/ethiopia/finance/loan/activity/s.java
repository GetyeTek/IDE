package com.huawei.ethiopia.finance.loan.activity;

import androidx.viewpager2.widget.ViewPager2;

public final class s extends ViewPager2.OnPageChangeCallback {
    public final /* synthetic */ FinanceServiceConfigActivity a;

    public s(FinanceServiceConfigActivity financeServiceConfigActivity) {
        this.a = financeServiceConfigActivity;
    }

    public final void onPageSelected(int i) {
        int i2 = FinanceServiceConfigActivity.h;
        this.a.E0(i);
    }
}
