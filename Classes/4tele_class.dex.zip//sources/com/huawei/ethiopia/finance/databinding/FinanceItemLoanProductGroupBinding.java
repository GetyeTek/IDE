package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemLoanProductGroupBinding extends ViewDataBinding {
    @NonNull
    public final RecyclerView a;
    @NonNull
    public final RoundTextView b;

    public FinanceItemLoanProductGroupBinding(View view, DataBindingComponent dataBindingComponent, RecyclerView recyclerView, RoundTextView roundTextView) {
        super(dataBindingComponent, view, 0);
        this.a = recyclerView;
        this.b = roundTextView;
    }
}
