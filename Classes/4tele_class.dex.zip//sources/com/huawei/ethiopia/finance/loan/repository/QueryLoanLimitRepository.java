package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.ProductInfo;
import com.huawei.http.b;

public class QueryLoanLimitRepository extends b<ProductInfo, ProductInfo> {
    public QueryLoanLimitRepository(String str) {
        addParams("fundsLenderId", str);
    }

    public final String getApiPath() {
        return "v1/ethiopia/loan/limit";
    }
}
