package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;

public abstract class FinanceActivityLockedSavingProductDetailBinding extends ViewDataBinding {
    @NonNull
    public final FinanceItemTimeSavingProductDetailBinding a;
    @NonNull
    public final FinanceLayoutServiceBannerBinding b;
    @NonNull
    public final RoundLinearLayout c;
    @NonNull
    public final RoundRecyclerView d;

    public FinanceActivityLockedSavingProductDetailBinding(DataBindingComponent dataBindingComponent, View view, FinanceItemTimeSavingProductDetailBinding financeItemTimeSavingProductDetailBinding, FinanceLayoutServiceBannerBinding financeLayoutServiceBannerBinding, RoundLinearLayout roundLinearLayout, RoundRecyclerView roundRecyclerView) {
        super(dataBindingComponent, view, 2);
        this.a = financeItemTimeSavingProductDetailBinding;
        this.b = financeLayoutServiceBannerBinding;
        this.c = roundLinearLayout;
        this.d = roundRecyclerView;
    }
}
