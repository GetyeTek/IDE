package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LifecycleOwner;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;

public class FinanceFragmentLoanContractsBindingImpl extends FinanceFragmentLoanContractsBinding {
    @Nullable
    public static final ViewDataBinding.IncludedLayouts f;
    @Nullable
    public static final SparseIntArray g;
    public long e;

    static {
        ViewDataBinding.IncludedLayouts includedLayouts = new ViewDataBinding.IncludedLayouts(6);
        f = includedLayouts;
        includedLayouts.setIncludes(1, new String[]{"finance_loan_active_contracts_balance", "finance_deactive_loan_layout"}, new int[]{2, 3}, new int[]{R$layout.finance_loan_active_contracts_balance, R$layout.finance_deactive_loan_layout});
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.ll_list, 4);
        sparseIntArray.put(R$id.recycler_view, 5);
    }

    public final boolean a(int i) {
        if (i != 0) {
            return false;
        }
        synchronized (this) {
            this.e |= 1;
        }
        return true;
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
        ViewDataBinding.executeBindingsOn(this.a);
        ViewDataBinding.executeBindingsOn(this.b);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0015, code lost:
        if (r6.a.hasPendingBindings() == false) goto L_0x0018;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0017, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001e, code lost:
        if (r6.b.hasPendingBindings() == false) goto L_0x0021;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0020, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0021, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean hasPendingBindings() {
        /*
            r6 = this;
            monitor-enter(r6)
            long r0 = r6.e     // Catch:{ all -> 0x000c }
            r2 = 0
            r4 = 1
            int r5 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r5 == 0) goto L_0x000e
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            return r4
        L_0x000c:
            r0 = move-exception
            goto L_0x0023
        L_0x000e:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            com.huawei.ethiopia.finance.databinding.FinanceLoanActiveContractsBalanceBinding r0 = r6.a
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0018
            return r4
        L_0x0018:
            com.huawei.ethiopia.finance.databinding.FinanceDeactiveLoanLayoutBinding r0 = r6.b
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0021
            return r4
        L_0x0021:
            r0 = 0
            return r0
        L_0x0023:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanContractsBindingImpl.hasPendingBindings():boolean");
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 4;
        }
        this.a.invalidateAll();
        this.b.invalidateAll();
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        if (i == 0) {
            FinanceLoanActiveContractsBalanceBinding financeLoanActiveContractsBalanceBinding = (FinanceLoanActiveContractsBalanceBinding) obj;
            return a(i2);
        } else if (i != 1) {
            return false;
        } else {
            FinanceDeactiveLoanLayoutBinding financeDeactiveLoanLayoutBinding = (FinanceDeactiveLoanLayoutBinding) obj;
            if (i2 != 0) {
                return false;
            }
            synchronized (this) {
                this.e |= 2;
            }
            return true;
        }
    }

    public final void setLifecycleOwner(@Nullable LifecycleOwner lifecycleOwner) {
        FinanceFragmentLoanContractsBindingImpl.super.setLifecycleOwner(lifecycleOwner);
        this.a.setLifecycleOwner(lifecycleOwner);
        this.b.setLifecycleOwner(lifecycleOwner);
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
