package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemLoanContactsBindingImpl extends FinanceItemLoanContactsBinding {
    @Nullable
    public static final SparseIntArray j;
    public long i;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        j = sparseIntArray;
        sparseIntArray.put(R$id.tvAmount, 1);
        sparseIntArray.put(R$id.tvUnit, 2);
        sparseIntArray.put(R$id.tvSchedules, 3);
        sparseIntArray.put(R$id.tvDate, 4);
        sparseIntArray.put(R$id.view, 5);
        sparseIntArray.put(R$id.btn_extend, 6);
        sparseIntArray.put(R$id.btn_repay, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.i = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.i != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.i = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i2, Object obj, int i3) {
        return false;
    }

    public final boolean setVariable(int i2, @Nullable Object obj) {
        return true;
    }
}
