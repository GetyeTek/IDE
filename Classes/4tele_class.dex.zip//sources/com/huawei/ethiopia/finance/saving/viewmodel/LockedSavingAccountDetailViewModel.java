package com.huawei.ethiopia.finance.saving.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.resp.SavingProductInfo;
import com.huawei.ethiopia.finance.resp.TimeSavingAccountInfo;
import com.huawei.ethiopia.finance.saving.repository.LockedSavingAccountDetailRepository;
import com.huawei.ethiopia.finance.saving.repository.LockedSavingAccountEntryRepository;
import com.huawei.http.b;
import p5.g;

public class LockedSavingAccountDetailViewModel extends ViewModel {
    public final MutableLiveData<c<TimeSavingAccountInfo>> a = new MutableLiveData<>();
    public final MutableLiveData<c<SavingProductInfo>> b = new MutableLiveData<>();
    public LockedSavingAccountDetailRepository c;
    public LockedSavingAccountEntryRepository d;

    public class a implements R1.a<TimeSavingAccountInfo> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            LockedSavingAccountDetailViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            LockedSavingAccountDetailViewModel.this.a.setValue(c.e((TimeSavingAccountInfo) obj));
        }
    }

    public LockedSavingAccountDetailViewModel() {
        new MutableLiveData();
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.http.b, com.huawei.ethiopia.finance.saving.repository.LockedSavingAccountDetailRepository] */
    public final void a(String str) {
        this.a.setValue(c.c());
        a aVar = new a();
        ? bVar = new b();
        bVar.addParams("accountNo", str);
        bVar.addParams("initiatorMsisdn", g.k());
        this.c = bVar;
        bVar.sendRequest(aVar);
    }

    public final void onCleared() {
        LockedSavingAccountDetailViewModel.super.onCleared();
        LockedSavingAccountDetailRepository lockedSavingAccountDetailRepository = this.c;
        if (lockedSavingAccountDetailRepository != null) {
            lockedSavingAccountDetailRepository.cancel();
        }
        LockedSavingAccountEntryRepository lockedSavingAccountEntryRepository = this.d;
        if (lockedSavingAccountEntryRepository != null) {
            lockedSavingAccountEntryRepository.cancel();
        }
    }
}
