package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemLoanMarketProductBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final HorizontalScrollView b;
    @NonNull
    public final RoundConstraintLayout c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final ImageView e;
    @NonNull
    public final LinearLayout f;
    @NonNull
    public final RoundRecyclerView g;
    @NonNull
    public final RoundLinearLayout h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;
    @NonNull
    public final TextView l;
    @NonNull
    public final TextView m;
    @NonNull
    public final TextView n;
    @NonNull
    public final TextView o;
    @NonNull
    public final TextView p;
    @NonNull
    public final TextView q;
    @NonNull
    public final TextView r;
    @NonNull
    public final TextView s;
    @NonNull
    public final TextView t;
    @NonNull
    public final TextView u;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FinanceItemLoanMarketProductBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, HorizontalScrollView horizontalScrollView, RoundConstraintLayout roundConstraintLayout, ImageView imageView, ImageView imageView2, LinearLayout linearLayout, RoundRecyclerView roundRecyclerView, RoundLinearLayout roundLinearLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11, TextView textView12, TextView textView13) {
        super(dataBindingComponent, view, 0);
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        this.a = roundTextView;
        this.b = horizontalScrollView;
        this.c = roundConstraintLayout;
        this.d = imageView;
        this.e = imageView2;
        this.f = linearLayout;
        this.g = roundRecyclerView;
        this.h = roundLinearLayout;
        this.i = textView;
        this.j = textView2;
        this.k = textView3;
        this.l = textView4;
        this.m = textView5;
        this.n = textView6;
        this.o = textView7;
        this.p = textView8;
        this.q = textView9;
        this.r = textView10;
        this.s = textView11;
        this.t = textView12;
        this.u = textView13;
    }
}
