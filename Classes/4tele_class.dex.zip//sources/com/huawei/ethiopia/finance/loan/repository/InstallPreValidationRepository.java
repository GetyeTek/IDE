package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.RolloverPreValidationResp;
import com.huawei.http.b;

public class InstallPreValidationRepository extends b<RolloverPreValidationResp, RolloverPreValidationResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/preNplValidation";
    }
}
