package com.huawei.ethiopia.finance.loan.fragment;

import N0.F;
import N0.G;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$dimen;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMyTelebirrTelaBinding;
import java.util.ArrayList;
import p5.g;
import w5.C0112a;

public class MyTelebirrTelaFragment extends Fragment {
    public FinanceFragmentFinanceMyTelebirrTelaBinding a;
    public ArrayList<LoanContractsFragment> b;
    public String c;
    public String d;
    public String e;

    public class a extends ViewPager2.OnPageChangeCallback {
        public a() {
        }

        public final void onPageSelected(int i) {
            boolean z;
            MyTelebirrTelaFragment.super.onPageSelected(i);
            if (i == 0) {
                z = true;
            } else {
                z = false;
            }
            MyTelebirrTelaFragment.this.w0(z);
        }
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        FinanceFragmentFinanceMyTelebirrTelaBinding inflate = DataBindingUtil.inflate(layoutInflater, R$layout.finance_fragment_finance_my_telebirr_tela, viewGroup, false);
        this.a = inflate;
        return inflate.getRoot();
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        MyTelebirrTelaFragment.super.onViewCreated(view, bundle);
        if (getArguments() != null) {
            this.c = getArguments().getString("bankCode");
            this.d = getArguments().getString("fundsLenderId");
            this.e = getArguments().getString("queryLoanMarketType");
        }
        FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(requireActivity());
        ArrayList<LoanContractsFragment> arrayList = new ArrayList<>();
        this.b = arrayList;
        arrayList.add(LoanContractsFragment.v0(this.c, this.d, this.e, true));
        this.b.add(LoanContractsFragment.v0(this.c, this.d, this.e, false));
        fragmentStateAdapter.a(this.b);
        this.a.g.setAdapter(fragmentStateAdapter);
        this.a.g.registerOnPageChangeCallback(new a());
        this.a.c.setOnClickListener(new F(this, 2));
        this.a.d.setOnClickListener(new G(this, 2));
        v0(true);
        w0(true);
    }

    public final void v0(boolean z) {
        if (z) {
            this.a.e.setTextSize(0, getResources().getDimension(R$dimen.dp_16));
            this.a.a.setVisibility(0);
            this.a.f.setTextSize(0, getResources().getDimension(R$dimen.dp_14));
            this.a.b.setVisibility(8);
            return;
        }
        this.a.e.setTextSize(0, getResources().getDimension(R$dimen.dp_14));
        this.a.a.setVisibility(8);
        this.a.f.setTextSize(0, getResources().getDimension(R$dimen.dp_16));
        this.a.b.setVisibility(0);
    }

    public final void w0(boolean z) {
        if (z) {
            String c2 = g.c(this.c);
            C0112a.a(c2 + "_my_telebirr_mela_active_v1");
        } else {
            String c3 = g.c(this.c);
            C0112a.a(c3 + "_my_telebirr_mela_closed_v1");
        }
        v0(z);
        if (z) {
            this.a.e.setTextColor(ContextCompat.getColor(requireContext(), R$color.common_colorPrimary));
            this.a.f.setTextColor(ContextCompat.getColor(requireContext(), R$color.colorTextLevel4));
        } else {
            this.a.f.setTextColor(ContextCompat.getColor(requireContext(), R$color.common_colorPrimary));
            this.a.e.setTextColor(ContextCompat.getColor(requireContext(), R$color.colorTextLevel4));
        }
        this.a.f.setTypeface((Typeface) null, z ^ true ? 1 : 0);
        this.a.e.setTypeface((Typeface) null, z ? 1 : 0);
        this.a.e.invalidate();
        this.a.f.invalidate();
    }
}
