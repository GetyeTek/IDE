package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.banner.CycleViewPager;

public abstract class FinanceLayoutServiceBannerBinding extends ViewDataBinding {
    @NonNull
    public final CycleViewPager a;

    public FinanceLayoutServiceBannerBinding(DataBindingComponent dataBindingComponent, View view, CycleViewPager cycleViewPager) {
        super(dataBindingComponent, view, 0);
        this.a = cycleViewPager;
    }
}
