package com.huawei.ethiopia.finance.saving.repository;

import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import com.huawei.ethiopia.finance.resp.SavingActivatableProductList;
import com.huawei.http.b;
import java.util.List;

public class QuerySavingActivatableProductRepository extends b<SavingActivatableProductList, List<SavingActivatableProduct>> {
    public QuerySavingActivatableProductRepository(boolean z, String str) {
        if (z) {
            addParams("productType", "TermDeposit");
        } else {
            addParams("productType", "SavingDeposit");
        }
        addParams("fundsLenderId", str);
    }

    public final Object convert(Object obj) {
        return ((SavingActivatableProductList) obj).getProductList();
    }

    public final String getApiPath() {
        return "v1/ethiopia/saving/product/list";
    }
}
