package com.huawei.ethiopia.finance.saving.activity;

import O7.a;
import V7.c;
import V7.e;
import W1.b;
import Y4.j;
import Y4.l;
import a5.m;
import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.f;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.constants.TransactionType;
import com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountDetailBinding;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.ethiopia.finance.saving.adapter.SavingTransactionAdapter;
import com.huawei.ethiopia.finance.saving.viewmodel.LockedSavingAccountDetailViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.ArrayList;
import java.util.Map;
import p5.g;

public class LockedSavingAccountDetailActivity extends DataBindingActivity<FinanceActivityLockedSavingAccountDetailBinding, LockedSavingAccountDetailViewModel> {
    public static final /* synthetic */ int h = 0;
    public SavingTransactionAdapter d;
    public b.b e;
    public FinanceProductInfo f;
    public String g;

    public final int C0() {
        return R$layout.finance_activity_locked_saving_account_detail;
    }

    public final void E0(TransactionType transactionType) {
        String str;
        if (transactionType == TransactionType.DEPOSIT) {
            str = g.m();
        } else {
            FinanceProductInfo financeProductInfo = this.f;
            if (financeProductInfo != null) {
                str = financeProductInfo.getBalance();
            } else {
                str = "0.00";
            }
        }
        Bundle bundle = new Bundle(2);
        bundle.putSerializable("transactionType", transactionType);
        bundle.putString("limitAmountValue", str);
        bundle.putString("productId", this.f.getProductId());
        bundle.putString("accountNo", this.f.getAccountNo());
        bundle.putString("productUnquieID", this.f.getProductUnquieID());
        bundle.putString("bankCode", this.g);
        bundle.putString("isLocked", "true");
        o0.b.d((Activity) null, "/finance/savingTransaction", bundle, (Map) null);
    }

    /* JADX WARNING: type inference failed for: r2v2, types: [com.huawei.http.b, com.huawei.ethiopia.finance.saving.repository.LockedSavingAccountEntryRepository] */
    public final void onCreate(@Nullable Bundle bundle) {
        LockedSavingAccountDetailActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.standard_white), false);
        this.f = (FinanceProductInfo) getIntent().getSerializableExtra("productInfo");
        this.g = getIntent().getStringExtra("bankCode");
        FinanceProductInfo financeProductInfo = this.f;
        if (financeProductInfo != null) {
            e.a(this, financeProductInfo.getProductName(), R.layout.common_toolbar);
            this.c.a(this.f.getAccountNo());
            LockedSavingAccountDetailViewModel lockedSavingAccountDetailViewModel = this.c;
            String accountNo = this.f.getAccountNo();
            lockedSavingAccountDetailViewModel.b.setValue(c.c());
            m mVar = new m(lockedSavingAccountDetailViewModel, 2);
            ? bVar = new com.huawei.http.b();
            bVar.addParams("accountNo", accountNo);
            bVar.addParams("initiatorMsisdn", g.k());
            lockedSavingAccountDetailViewModel.d = bVar;
            bVar.sendRequest(mVar);
            if (TextUtils.equals(this.f.getStatus(), "Closed")) {
                this.b.c.setVisibility(8);
            }
        }
        SavingTransactionAdapter savingTransactionAdapter = new SavingTransactionAdapter();
        this.d = savingTransactionAdapter;
        this.b.b.setAdapter(savingTransactionAdapter);
        this.b.e.setOnClickListener(new D6.g(this, 7));
        this.b.d.setOnClickListener(new a(this, 5));
        this.d.submitList(new ArrayList());
        this.c.a.observe(this, new j(this, 1));
        this.c.b.observe(this, new C4.b(this, 2));
        b.b c = b.b().c(this.b.b);
        c.b = new l(this, 3);
        this.e = c;
    }
}
