package com.huawei.ethiopia.finance.loan.activity;

import V7.c;
import V7.f;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.lifecycle.Observer;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.loan.fragment.FinanceServiceFragment;
import com.huawei.ethiopia.finance.resp.FinanceMenuListResp;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.ArrayList;
import p5.g;
import p5.i;

public final /* synthetic */ class m implements Observer {
    public final /* synthetic */ FinanceServiceConfigActivity a;

    public /* synthetic */ m(FinanceServiceConfigActivity financeServiceConfigActivity) {
        this.a = financeServiceConfigActivity;
    }

    public final void onChanged(Object obj) {
        c cVar = (c) obj;
        int i = FinanceServiceConfigActivity.h;
        DataBindingActivity dataBindingActivity = this.a;
        if (cVar.d()) {
            dataBindingActivity.g.a(1);
        } else if (cVar.b()) {
            f.c(cVar);
            dataBindingActivity.g.a(3);
        } else if (cVar.f()) {
            FinanceMenuListResp financeMenuListResp = (FinanceMenuListResp) cVar.c;
            if (((ArrayList) financeMenuListResp.getMenuItems()) != null) {
                dataBindingActivity.d = financeMenuListResp;
                g.i().a = dataBindingActivity.d;
                dataBindingActivity.g.a(2);
                FinanceMenuListResp financeMenuListResp2 = dataBindingActivity.d;
                if (!(financeMenuListResp2 == null || financeMenuListResp2.getFinanceServiceUIConfig() == null || financeMenuListResp2.getFinanceServiceUIConfig().getLoan() == null || TextUtils.isEmpty(financeMenuListResp2.getFinanceServiceUIConfig().getBankName()))) {
                    dataBindingActivity.bankName = financeMenuListResp2.getFinanceServiceUIConfig().getBankName();
                }
                i iVar = i.e;
                String str = dataBindingActivity.bankCode;
                String str2 = dataBindingActivity.bankIcon;
                iVar.c = dataBindingActivity.bankName;
                iVar.b = str2;
                iVar.a = str;
                FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(dataBindingActivity);
                dataBindingActivity.e = fragmentStateAdapter;
                dataBindingActivity.b.e.setAdapter(fragmentStateAdapter);
                ArrayList arrayList = new ArrayList();
                String str3 = dataBindingActivity.bankCode;
                String str4 = dataBindingActivity.selectOverDraft;
                Bundle bundle = new Bundle();
                bundle.putString("bankCode", str3);
                bundle.putSerializable("financeresp", financeMenuListResp2);
                bundle.putString("IS_SELECT_OVERDRAFT", str4);
                FinanceServiceFragment financeServiceFragment = new FinanceServiceFragment();
                financeServiceFragment.setArguments(bundle);
                dataBindingActivity.f = financeServiceFragment;
                arrayList.add(financeServiceFragment);
                dataBindingActivity.e.a(arrayList);
                dataBindingActivity.b.c.setOnClickListener(new o(dataBindingActivity));
                dataBindingActivity.b.b.setOnClickListener(new p(dataBindingActivity));
                dataBindingActivity.b.d.setOnClickListener(new q(dataBindingActivity));
                dataBindingActivity.b.a.setOnClickListener(new r(dataBindingActivity));
                dataBindingActivity.b.e.registerOnPageChangeCallback(new s(dataBindingActivity));
                dataBindingActivity.b.a.setBackgroundColor(g.f(dataBindingActivity, dataBindingActivity.d, dataBindingActivity.bankCode));
                dataBindingActivity.E0(0);
                if (!TextUtils.isEmpty(dataBindingActivity.bankName)) {
                    dataBindingActivity.b.d.setText(dataBindingActivity.bankName);
                } else if (TextUtils.equals(dataBindingActivity.bankCode, "CBE")) {
                    dataBindingActivity.b.d.setText(dataBindingActivity.getResources().getString(R$string.commercial_bank_of_ethiopia));
                } else if (TextUtils.equals(dataBindingActivity.bankCode, "Siinqee")) {
                    dataBindingActivity.b.d.setText(dataBindingActivity.getResources().getString(R$string.bank_of_ethiopia_siinqee));
                }
                FinanceMenuListResp financeMenuListResp3 = dataBindingActivity.d;
                if (financeMenuListResp3 != null && financeMenuListResp3.getFinanceServiceUIConfig() != null && !TextUtils.isEmpty(dataBindingActivity.d.getFinanceServiceUIConfig().getIcon())) {
                    O9.c.c(dataBindingActivity.b.b, dataBindingActivity.d.getFinanceServiceUIConfig().getIcon(), -1);
                    return;
                }
                return;
            }
            dataBindingActivity.g.a(3);
        }
    }
}
