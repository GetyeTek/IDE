package com.huawei.ethiopia.finance.resp;

import com.huawei.common.display.DisplayItem;

public class FinanceDisplayItem extends DisplayItem {
    private String remark;

    public FinanceDisplayItem(String str, String str2) {
        super(str, str2);
    }

    public String getRemark() {
        return this.remark;
    }

    public void setRemark(String str) {
        this.remark = str;
    }
}
