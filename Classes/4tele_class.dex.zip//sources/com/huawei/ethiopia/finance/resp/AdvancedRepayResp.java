package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;

public class AdvancedRepayResp extends BaseResp {
    private String advancedRepaymentFee;

    public String getAdvancedRepaymentFee() {
        return this.advancedRepaymentFee;
    }

    public void setAdvancedRepaymentFee(String str) {
        this.advancedRepaymentFee = str;
    }
}
