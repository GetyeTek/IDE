package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class FinanceMenuListResp extends BaseResp implements Serializable {
    private List<FinanceBankConfig> bankConfigs;
    private FinanceServiceUIConfig financeServiceUIConfig;
    private List<FinanceMenu> menuItems;
    private List<CreditPayContractsInfo> overdraftContractItems;

    public List<FinanceBankConfig> getBankConfigs() {
        return this.bankConfigs;
    }

    public FinanceServiceUIConfig getFinanceServiceUIConfig() {
        return this.financeServiceUIConfig;
    }

    public String getFundsLenderId() {
        List<FinanceBankConfig> list = this.bankConfigs;
        if (list == null || list.isEmpty()) {
            return "";
        }
        return this.bankConfigs.get(0).getFundsLenderId();
    }

    public List<FinanceMenu> getMenuItems() {
        return this.menuItems;
    }

    public List<CreditPayContractsInfo> getOverdraftContractItems() {
        return this.overdraftContractItems;
    }

    public void setBankConfigs(List<FinanceBankConfig> list) {
        this.bankConfigs = list;
    }

    public void setFinanceServiceUIConfig(FinanceServiceUIConfig financeServiceUIConfig2) {
        this.financeServiceUIConfig = financeServiceUIConfig2;
    }

    public void setMenuItems(List<FinanceMenu> list) {
        this.menuItems = list;
    }

    public void setOverdraftContractItems(List<CreditPayContractsInfo> list) {
        this.overdraftContractItems = list;
    }
}
