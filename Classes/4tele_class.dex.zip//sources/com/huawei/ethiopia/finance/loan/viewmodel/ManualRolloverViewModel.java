package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.http.BaseResp;

public class ManualRolloverViewModel extends ViewModel {
    public final MutableLiveData<c<BaseResp>> a = new MutableLiveData<>();
}
