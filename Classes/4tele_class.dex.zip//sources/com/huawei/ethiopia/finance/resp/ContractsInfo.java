package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;

public class ContractsInfo implements Serializable {
    private String amount;
    private String contractId;
    private String currency;
    private String dueDate;
    private boolean isLoan;
    private String productId;
    private String title;

    public String getAmount() {
        return this.amount;
    }

    public String getContractId() {
        return this.contractId;
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getDueDate() {
        return this.dueDate;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getTitle() {
        return this.title;
    }

    public boolean isLoan() {
        return this.isLoan;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setContractId(String str) {
        this.contractId = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setDueDate(String str) {
        this.dueDate = str;
    }

    public void setLoan(boolean z) {
        this.isLoan = z;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setTitle(String str) {
        this.title = str;
    }
}
