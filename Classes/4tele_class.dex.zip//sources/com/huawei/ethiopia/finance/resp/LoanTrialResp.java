package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;
import java.util.List;

public class LoanTrialResp extends BaseResp {
    private boolean hasBindNationalId = true;
    private List<FinanceDisplayItem> preValidationItems;
    private String prompting;
    private List<RepaymentSchedule> repaymentSchedules;

    public List<FinanceDisplayItem> getPreValidationItems() {
        return this.preValidationItems;
    }

    public String getPrompting() {
        return this.prompting;
    }

    public List<RepaymentSchedule> getRepaymentSchedules() {
        return this.repaymentSchedules;
    }

    public boolean isHasBindNationalId() {
        return this.hasBindNationalId;
    }

    public void setHasBindNationalId(boolean z) {
        this.hasBindNationalId = z;
    }

    public void setPreValidationItems(List<FinanceDisplayItem> list) {
        this.preValidationItems = list;
    }

    public void setPrompting(String str) {
        this.prompting = str;
    }

    public void setRepaymentSchedules(List<RepaymentSchedule> list) {
        this.repaymentSchedules = list;
    }
}
