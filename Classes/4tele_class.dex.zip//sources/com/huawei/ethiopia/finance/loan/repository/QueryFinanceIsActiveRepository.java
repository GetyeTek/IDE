package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.ActiveState;
import com.huawei.http.b;
import p5.g;

public class QueryFinanceIsActiveRepository extends b<ActiveState, ActiveState> {
    public final String a;

    public QueryFinanceIsActiveRepository(String str) {
        addParams("initiatorMsisdn", g.k());
        this.a = str;
    }

    public final String getApiPath() {
        return this.a;
    }
}
