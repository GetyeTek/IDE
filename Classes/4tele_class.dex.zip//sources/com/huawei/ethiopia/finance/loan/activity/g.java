package com.huawei.ethiopia.finance.loan.activity;

import V7.c;
import V7.f;
import android.content.Intent;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.huawei.csm.viewmodel.ReportViewModel;
import f2.c;
import java.io.Serializable;

public final /* synthetic */ class g implements Observer {
    public final /* synthetic */ FinanceLoanRepayActivity a;

    public /* synthetic */ g(FinanceLoanRepayActivity financeLoanRepayActivity) {
        this.a = financeLoanRepayActivity;
    }

    public final void onChanged(Object obj) {
        c cVar = (c) obj;
        int i = FinanceLoanRepayActivity.q;
        FragmentActivity fragmentActivity = this.a;
        f.b(fragmentActivity, cVar);
        if (cVar.b()) {
            ReportViewModel reportViewModel = f2.c.b;
            c.a.a.c("Loan_Enter_PIN", new String[]{"failed", cVar.b.getMessage(), fragmentActivity.l, fragmentActivity.n, fragmentActivity.p, "Repay"});
            f.c(cVar);
            fragmentActivity.a.c.setText("");
        } else if (cVar.f()) {
            ReportViewModel reportViewModel2 = f2.c.b;
            c.a.a.c("Loan_Enter_PIN", new String[]{"successful", "successful", fragmentActivity.l, fragmentActivity.n, fragmentActivity.p, "Repay"});
            a5.f.c.c(fragmentActivity.l);
            Intent intent = new Intent();
            intent.putExtra("bankCode", fragmentActivity.l);
            intent.putExtra("data", (Serializable) cVar.c);
            fragmentActivity.setResult(-1, intent);
            fragmentActivity.finish();
        }
    }
}
