package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class TimeSavingAccountInfo extends BaseResp {
    private String accountNo;
    private List<AccountTransferListBean> accountTransferList;
    private String accountType;
    private String accruedInterest;
    private String availableBalance;
    private String balance;
    private String currency;
    private String custAccountNo;
    private String dailyInterestIncrement;
    private String firstDepositDate;
    private String frozenBalance;
    private String identityId;
    private String identityType;
    private String lastActiveDate;
    private String lastCapitalizationDate;
    private String lastTransactionDate;
    private String maturityDate;
    private String nextCapitalizationDate;
    private String openAccountDate;
    private String previousBalance;
    private String previousCapitalizationAmount;
    private String previousDate;
    private String principalAmount;
    private String productId;
    private String productName;
    private String productNameI18n;
    private String profitLossAmount;
    private String rateValue;
    private String rateValueMode;
    private String status;
    private String totalCapitalizationAmount;
    private String unclearingBalance;

    public static class AccountTransferListBean implements Serializable {
        private String accountNo;
        private String identityID;
        private String identityType;
        private String nextProductID;
        private String productID;
        private String productUniqueID;
        private String status;
        private String transferEndDate;
        private String transferID;
        private String transferMode;
        private String transferStartDate;

        public String getAccountNo() {
            return this.accountNo;
        }

        public String getIdentityID() {
            return this.identityID;
        }

        public String getIdentityType() {
            return this.identityType;
        }

        public String getNextProductID() {
            return this.nextProductID;
        }

        public String getProductID() {
            return this.productID;
        }

        public String getProductUniqueID() {
            return this.productUniqueID;
        }

        public String getStatus() {
            return this.status;
        }

        public String getTransferEndDate() {
            return this.transferEndDate;
        }

        public String getTransferID() {
            return this.transferID;
        }

        public String getTransferMode() {
            return this.transferMode;
        }

        public String getTransferStartDate() {
            return this.transferStartDate;
        }

        public void setAccountNo(String str) {
            this.accountNo = str;
        }

        public void setIdentityID(String str) {
            this.identityID = str;
        }

        public void setIdentityType(String str) {
            this.identityType = str;
        }

        public void setNextProductID(String str) {
            this.nextProductID = str;
        }

        public void setProductID(String str) {
            this.productID = str;
        }

        public void setProductUniqueID(String str) {
            this.productUniqueID = str;
        }

        public void setStatus(String str) {
            this.status = str;
        }

        public void setTransferEndDate(String str) {
            this.transferEndDate = str;
        }

        public void setTransferID(String str) {
            this.transferID = str;
        }

        public void setTransferMode(String str) {
            this.transferMode = str;
        }

        public void setTransferStartDate(String str) {
            this.transferStartDate = str;
        }
    }

    public String getAccountNo() {
        return this.accountNo;
    }

    public List<AccountTransferListBean> getAccountTransferList() {
        return this.accountTransferList;
    }

    public String getAccountType() {
        return this.accountType;
    }

    public String getAccruedInterest() {
        return this.accruedInterest;
    }

    public String getAvailableBalance() {
        return this.availableBalance;
    }

    public String getBalance() {
        return this.balance;
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getCustAccountNo() {
        return this.custAccountNo;
    }

    public String getDailyInterestIncrement() {
        return this.dailyInterestIncrement;
    }

    public String getFirstDepositDate() {
        return this.firstDepositDate;
    }

    public String getFrozenBalance() {
        return this.frozenBalance;
    }

    public String getIdentityId() {
        return this.identityId;
    }

    public String getIdentityType() {
        return this.identityType;
    }

    public String getLastActiveDate() {
        return this.lastActiveDate;
    }

    public String getLastCapitalizationDate() {
        return this.lastCapitalizationDate;
    }

    public String getLastTransactionDate() {
        return this.lastTransactionDate;
    }

    public String getMaturityDate() {
        return this.maturityDate;
    }

    public String getNextCapitalizationDate() {
        return this.nextCapitalizationDate;
    }

    public String getOpenAccountDate() {
        return this.openAccountDate;
    }

    public String getPreviousBalance() {
        return this.previousBalance;
    }

    public String getPreviousCapitalizationAmount() {
        return this.previousCapitalizationAmount;
    }

    public String getPreviousDate() {
        return this.previousDate;
    }

    public String getPrincipalAmount() {
        return this.principalAmount;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getProductName() {
        return this.productName;
    }

    public String getProductNameI18n() {
        return this.productNameI18n;
    }

    public String getProfitLossAmount() {
        return this.profitLossAmount;
    }

    public String getRateValue() {
        return this.rateValue;
    }

    public String getRateValueMode() {
        return this.rateValueMode;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTotalCapitalizationAmount() {
        return this.totalCapitalizationAmount;
    }

    public String getUnclearingBalance() {
        return this.unclearingBalance;
    }

    public void setAccountNo(String str) {
        this.accountNo = str;
    }

    public void setAccountTransferList(List<AccountTransferListBean> list) {
        this.accountTransferList = list;
    }

    public void setAccountType(String str) {
        this.accountType = str;
    }

    public void setAccruedInterest(String str) {
        this.accruedInterest = str;
    }

    public void setAvailableBalance(String str) {
        this.availableBalance = str;
    }

    public void setBalance(String str) {
        this.balance = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setCustAccountNo(String str) {
        this.custAccountNo = str;
    }

    public void setDailyInterestIncrement(String str) {
        this.dailyInterestIncrement = str;
    }

    public void setFirstDepositDate(String str) {
        this.firstDepositDate = str;
    }

    public void setFrozenBalance(String str) {
        this.frozenBalance = str;
    }

    public void setIdentityId(String str) {
        this.identityId = str;
    }

    public void setIdentityType(String str) {
        this.identityType = str;
    }

    public void setLastActiveDate(String str) {
        this.lastActiveDate = str;
    }

    public void setLastCapitalizationDate(String str) {
        this.lastCapitalizationDate = str;
    }

    public void setLastTransactionDate(String str) {
        this.lastTransactionDate = str;
    }

    public void setMaturityDate(String str) {
        this.maturityDate = str;
    }

    public void setNextCapitalizationDate(String str) {
        this.nextCapitalizationDate = str;
    }

    public void setOpenAccountDate(String str) {
        this.openAccountDate = str;
    }

    public void setPreviousBalance(String str) {
        this.previousBalance = str;
    }

    public void setPreviousCapitalizationAmount(String str) {
        this.previousCapitalizationAmount = str;
    }

    public void setPreviousDate(String str) {
        this.previousDate = str;
    }

    public void setPrincipalAmount(String str) {
        this.principalAmount = str;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setProductName(String str) {
        this.productName = str;
    }

    public void setProductNameI18n(String str) {
        this.productNameI18n = str;
    }

    public void setProfitLossAmount(String str) {
        this.profitLossAmount = str;
    }

    public void setRateValue(String str) {
        this.rateValue = str;
    }

    public void setRateValueMode(String str) {
        this.rateValueMode = str;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setTotalCapitalizationAmount(String str) {
        this.totalCapitalizationAmount = str;
    }

    public void setUnclearingBalance(String str) {
        this.unclearingBalance = str;
    }
}
