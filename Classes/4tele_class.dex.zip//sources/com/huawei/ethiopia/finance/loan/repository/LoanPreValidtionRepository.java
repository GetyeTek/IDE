package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.LoanTrialResp;
import com.huawei.http.b;

public class LoanPreValidtionRepository extends b<LoanTrialResp, LoanTrialResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/preValidation";
    }
}
