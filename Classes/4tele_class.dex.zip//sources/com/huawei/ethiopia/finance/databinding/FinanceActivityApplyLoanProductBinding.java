package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;

public abstract class FinanceActivityApplyLoanProductBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final EditText b;
    @NonNull
    public final RoundLinearLayout c;
    @NonNull
    public final RoundRecyclerView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;

    public FinanceActivityApplyLoanProductBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, EditText editText, RoundLinearLayout roundLinearLayout, RoundRecyclerView roundRecyclerView, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = editText;
        this.c = roundLinearLayout;
        this.d = roundRecyclerView;
        this.e = textView;
        this.f = textView2;
        this.g = textView3;
    }
}
