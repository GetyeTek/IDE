package com.huawei.ethiopia.finance.loan.activity;

import D4.m;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModel;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityTransactionResultBinding;
import com.huawei.kbz.event.FaceVerificationResult;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.ArrayList;
import java.util.Map;
import o0.b;

@Route(path = "/finance/transactionResult")
public class FinanceResultActivity extends DataBindingActivity<FinanceActivityTransactionResultBinding, ViewModel> {
    public static final /* synthetic */ int e = 0;
    public String d;

    public final int C0() {
        return R$layout.finance_activity_transaction_result;
    }

    public void E0() {
        if (!TextUtils.isEmpty(this.d)) {
            b.d((Activity) null, this.d, (Bundle) null, (Map) null);
        }
        finish();
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [android.content.Context, com.huawei.ethiopia.finance.loan.activity.FinanceResultActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceResultActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.common_colorWhite), false);
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra(FaceVerificationResult.RESULT);
        if (stringExtra == null) {
            stringExtra = getString(R$string.successful);
        }
        this.d = intent.getStringExtra("execute");
        String stringExtra2 = intent.getStringExtra("title");
        String stringExtra3 = intent.getStringExtra("amount");
        String stringExtra4 = intent.getStringExtra("unit");
        String stringExtra5 = intent.getStringExtra("buttonText");
        if (stringExtra5 == null) {
            stringExtra5 = getString(R$string.baselib_finished);
        }
        this.b.e.setText(stringExtra);
        this.b.f.setText(stringExtra2);
        this.b.d.setText(stringExtra3);
        this.b.g.setText(stringExtra4);
        this.b.a.setText(stringExtra5);
        this.b.a.setOnClickListener(new m(this, 4));
        ArrayList arrayList = (ArrayList) intent.getSerializableExtra("displayItems");
        if (arrayList == null || arrayList.isEmpty()) {
            this.b.b.setVisibility(8);
            return;
        }
        this.b.b.setVisibility(0);
        this.b.c.setLayoutManager(new LinearLayoutManager(this));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.finance_item_result_display);
        this.b.c.setAdapter(baseQuickAdapter);
        baseQuickAdapter.setNewData(arrayList);
    }
}
