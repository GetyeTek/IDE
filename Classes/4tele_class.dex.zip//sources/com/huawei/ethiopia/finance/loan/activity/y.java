package com.huawei.ethiopia.finance.loan.activity;

import R1.b;
import android.os.Bundle;
import android.view.View;
import java.util.Map;

public final class y extends b {
    public final /* synthetic */ ManualRolloverActivity b;

    public y(ManualRolloverActivity manualRolloverActivity) {
        this.b = manualRolloverActivity;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.ethiopia.finance.loan.activity.ManualRolloverActivity, android.app.Activity] */
    public final void a(View view) {
        int i = ManualRolloverActivity.f;
        o0.b.e(this.b, "/finance/manualRolloverPin", new Bundle(), (Map) null, 0, 1111);
    }
}
