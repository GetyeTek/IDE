package com.huawei.ethiopia.finance.resp;

import com.google.gson.annotations.SerializedName;
import com.huawei.facerecognition.FaceManager;
import com.huawei.http.BaseResp;
import java.util.ArrayList;
import java.util.List;

public class FinanceLoanResp extends BaseResp {
    private String creditLimit;
    private String creditScore;
    @SerializedName(alternate = {"productList"}, value = "loanProductInfos")
    private List<ProductInfo> productList;

    public String getCreditLimit() {
        return this.creditLimit;
    }

    public int getCreditLimitValue() {
        try {
            return Integer.parseInt(this.creditLimit);
        } catch (Exception unused) {
            return FaceManager.FACE_ERROR_VENDOR_BASE;
        }
    }

    public String getCreditScore() {
        return this.creditScore;
    }

    public int getCreditScoreValue() {
        try {
            return Integer.parseInt(this.creditScore);
        } catch (Exception unused) {
            return 0;
        }
    }

    public List<ProductInfo> getProductList() {
        List<ProductInfo> list = this.productList;
        if (list == null) {
            return new ArrayList();
        }
        return list;
    }

    public void setCreditLimit(String str) {
        this.creditLimit = str;
    }

    public void setCreditScore(String str) {
        this.creditScore = str;
    }

    public void setProductList(List<ProductInfo> list) {
        this.productList = list;
    }
}
