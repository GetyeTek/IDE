package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.loan.repository.QueryFinanceIsActiveRepository;
import com.huawei.ethiopia.finance.resp.ActiveState;
import java.util.HashMap;

public class FinanceDispacherViewModel extends ViewModel {
    public static final HashMap d;
    public final MutableLiveData<c<ActiveState>> a = new MutableLiveData<>();
    public QueryFinanceIsActiveRepository b;
    public String c;

    public class a implements R1.a<ActiveState> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceDispacherViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            ActiveState activeState = (ActiveState) obj;
            String protocolUrl = activeState.getProtocolUrl();
            FinanceDispacherViewModel financeDispacherViewModel = FinanceDispacherViewModel.this;
            financeDispacherViewModel.c = protocolUrl;
            financeDispacherViewModel.a.setValue(c.e(activeState));
        }
    }

    static {
        HashMap hashMap = new HashMap();
        d = hashMap;
        hashMap.put("finance_loan", "v1/ethiopia/loan/subscribe/check");
        hashMap.put("finance_overdraft", "v1/ethiopia/od/subscribe/list");
        hashMap.put("finance_saving", "v1/ethiopia/saving/subscribe/check");
    }

    public final void a(String str) {
        b(str, "");
    }

    public final void b(String str, String str2) {
        this.a.setValue(c.c());
        this.b = new QueryFinanceIsActiveRepository((String) d.get(str));
        if (!TextUtils.isEmpty(str2)) {
            this.b.addParams("fundsLenderId", str2);
        }
        this.b.sendRequest(new a());
    }

    public final void onCleared() {
        FinanceDispacherViewModel.super.onCleared();
        QueryFinanceIsActiveRepository queryFinanceIsActiveRepository = this.b;
        if (queryFinanceIsActiveRepository != null) {
            queryFinanceIsActiveRepository.cancel();
        }
    }
}
