package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;

public abstract class FinanceActivityFinanceAgreementBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final AppCompatCheckBox b;

    public FinanceActivityFinanceAgreementBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, AppCompatCheckBox appCompatCheckBox) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = appCompatCheckBox;
    }
}
