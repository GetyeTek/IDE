package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;
import java.util.List;

public class CreditPayContractsGroup implements Serializable {
    private List<CreditPayContractsInfo> contractItems;
    private String groupName;

    public List<CreditPayContractsInfo> getContractItems() {
        return this.contractItems;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public void setContractItems(List<CreditPayContractsInfo> list) {
        this.contractItems = list;
    }

    public void setGroupName(String str) {
        this.groupName = str;
    }
}
