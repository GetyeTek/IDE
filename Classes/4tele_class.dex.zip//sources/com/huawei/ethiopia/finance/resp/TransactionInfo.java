package com.huawei.ethiopia.finance.resp;

import android.text.TextUtils;
import com.google.gson.annotations.SerializedName;
import com.huawei.http.BaseResp;
import p5.g;

public class TransactionInfo extends BaseResp {
    private String balance;
    private String businessScopeI18n;
    private String currency;
    private String orderID;
    private String symbol;
    @SerializedName(alternate = {"amount"}, value = "transactionAmount")
    private String transactionAmount;
    private String transactionId;
    @SerializedName(alternate = {"transactionEndTime", "completeTime"}, value = "transactionTime")
    private String transactionTime;
    @SerializedName(alternate = {"businessScope", "remark"}, value = "transactionTitle")
    private String transactionTitle;
    private String transactionType;
    private String transfer;
    private String unit;
    private String walletOrderID;

    public String getBalance() {
        return this.balance;
    }

    public String getBusinessScopeI18n() {
        return this.businessScopeI18n;
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getOrderID() {
        return this.orderID;
    }

    public String getShowAmount() {
        return getSymbol() + " " + getTransactionAmount();
    }

    public String getShowContent() {
        return getTransactionTime();
    }

    public String getShowTitle() {
        return getTransactionTitle() + "（" + g.g() + "）";
    }

    public String getSymbol() {
        if ("In".equals(this.transfer)) {
            return "+";
        }
        if ("Out".equals(this.transfer)) {
            return "-";
        }
        if (!TextUtils.isEmpty(this.symbol)) {
            return this.symbol;
        }
        return "";
    }

    public String getTransactionAmount() {
        return this.transactionAmount;
    }

    public String getTransactionId() {
        return this.transactionId;
    }

    public String getTransactionTime() {
        return this.transactionTime;
    }

    public String getTransactionTitle() {
        return this.transactionTitle;
    }

    public String getTransactionType() {
        return this.transactionType;
    }

    public String getTransfer() {
        return this.transfer;
    }

    public String getUnit() {
        if (TextUtils.isEmpty(this.unit)) {
            return this.currency;
        }
        return this.unit;
    }

    public String getWalletOrderID() {
        return this.walletOrderID;
    }

    public void setBalance(String str) {
        this.balance = str;
    }

    public void setBusinessScopeI18n(String str) {
        this.businessScopeI18n = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setOrderID(String str) {
        this.orderID = str;
    }

    public void setSymbol(String str) {
        this.symbol = str;
    }

    public void setTransactionAmount(String str) {
        this.transactionAmount = str;
    }

    public void setTransactionId(String str) {
        this.transactionId = str;
    }

    public void setTransactionTime(String str) {
        this.transactionTime = str;
    }

    public void setTransactionTitle(String str) {
        this.transactionTitle = str;
    }

    public void setTransactionType(String str) {
        this.transactionType = str;
    }

    public void setTransfer(String str) {
        this.transfer = str;
    }

    public void setUnit(String str) {
        this.unit = str;
    }

    public void setWalletOrderID(String str) {
        this.walletOrderID = str;
    }
}
