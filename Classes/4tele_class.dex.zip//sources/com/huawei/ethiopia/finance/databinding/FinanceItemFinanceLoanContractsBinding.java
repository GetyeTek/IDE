package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemFinanceLoanContractsBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;

    public FinanceItemFinanceLoanContractsBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, RoundTextView roundTextView2, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = roundTextView2;
        this.c = textView;
        this.d = textView2;
        this.e = textView3;
        this.f = textView4;
        this.g = textView5;
    }
}
