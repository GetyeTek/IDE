package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemMyFixedTimeSavingDetailBindingImpl extends FinanceItemMyFixedTimeSavingDetailBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.imageView2, 1);
        sparseIntArray.put(R$id.imageView4, 2);
        sparseIntArray.put(R$id.tvDepositAmount, 3);
        sparseIntArray.put(R$id.tvDepositAmountValue, 4);
        sparseIntArray.put(R$id.tvExpireTime, 5);
        sparseIntArray.put(R$id.tvTotalGainsValue, 6);
        sparseIntArray.put(R$id.tvTotalGains, 7);
        sparseIntArray.put(R$id.tvInterestRateValue, 8);
        sparseIntArray.put(R$id.tvInterestRate, 9);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
