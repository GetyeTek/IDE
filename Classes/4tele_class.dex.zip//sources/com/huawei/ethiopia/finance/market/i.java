package com.huawei.ethiopia.finance.market;

import V7.c;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.homev6.transactionhistory.TransactionReportFragment;
import com.huawei.digitalpayment.customer.httplib.response.DataDictResp;
import com.huawei.ethiopia.finance.resp.FinanceLoanResp;

public final /* synthetic */ class i implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ i(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        FinanceLoanResp financeLoanResp;
        switch (this.a) {
            case 0:
                Boolean bool = (Boolean) obj;
                LoanProductsMarketActivity loanProductsMarketActivity = (LoanProductsMarketActivity) this.b;
                if (!loanProductsMarketActivity.i) {
                    loanProductsMarketActivity.i = true;
                    return;
                } else if (bool.booleanValue() && (financeLoanResp = loanProductsMarketActivity.h) != null) {
                    loanProductsMarketActivity.c.c(financeLoanResp);
                    return;
                } else {
                    return;
                }
            default:
                c cVar = (c) obj;
                TransactionReportFragment transactionReportFragment = (TransactionReportFragment) this.b;
                transactionReportFragment.getClass();
                if (!cVar.b() && cVar.f()) {
                    transactionReportFragment.g = ((DataDictResp) cVar.c).getDictMap();
                    return;
                }
                return;
        }
    }
}
