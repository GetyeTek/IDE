package com.huawei.ethiopia.finance.loan.activity;

import R1.b;
import V7.c;
import a5.k;
import android.view.View;
import com.huawei.ethiopia.finance.loan.viewmodel.LoanContractDetailViewModel;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;

public final class t extends b {
    public final /* synthetic */ LoanContractsInfo b;
    public final /* synthetic */ LoanContractDetailActivity c;

    public t(LoanContractDetailActivity loanContractDetailActivity, LoanContractsInfo loanContractsInfo) {
        this.c = loanContractDetailActivity;
        this.b = loanContractsInfo;
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.http.b, com.huawei.ethiopia.finance.loan.repository.PreNewNplValidationRepository] */
    public final void a(View view) {
        int i = LoanContractDetailActivity.o;
        LoanContractDetailViewModel loanContractDetailViewModel = this.c.c;
        String contractId = this.b.getContractId();
        loanContractDetailViewModel.c.setValue(c.c());
        ? bVar = new com.huawei.http.b();
        bVar.addParams("contractID", contractId);
        loanContractDetailViewModel.e = bVar;
        bVar.sendRequest(new k(loanContractDetailViewModel, contractId));
    }
}
