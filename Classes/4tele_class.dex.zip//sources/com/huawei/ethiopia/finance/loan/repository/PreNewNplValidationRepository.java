package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.PreNewNplValidationResp;
import com.huawei.http.b;

public class PreNewNplValidationRepository extends b<PreNewNplValidationResp, PreNewNplValidationResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/preNewNplValidation";
    }
}
