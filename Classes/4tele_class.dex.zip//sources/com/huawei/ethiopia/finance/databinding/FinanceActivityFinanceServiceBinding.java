package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceActivityFinanceServiceBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final ViewPager2 e;

    public FinanceActivityFinanceServiceBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, RoundTextView roundTextView2, TextView textView, TextView textView2, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = roundTextView2;
        this.c = textView;
        this.d = textView2;
        this.e = viewPager2;
    }
}
