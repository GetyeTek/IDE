package com.huawei.ethiopia.finance.market;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.view.View;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.market.adapter.LoanMarketFilterAdapter;
import com.huawei.ethiopia.finance.market.dialog.FinanceSelectBankDialog;
import java.util.ArrayList;
import java.util.List;

public final class l implements OnItemClickListener {
    public final /* synthetic */ LoanProductsMarketActivity a;

    public l(LoanProductsMarketActivity loanProductsMarketActivity) {
        this.a = loanProductsMarketActivity;
    }

    @SuppressLint({"NotifyDataSetChanged"})
    public final void onItemClick(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter, @NonNull View view, int i) {
        LoanProductsMarketActivity loanProductsMarketActivity = this.a;
        ArrayList arrayList = loanProductsMarketActivity.m;
        if (arrayList != null && !arrayList.isEmpty()) {
            FinanceMarketBankConfig.FinanceMarketBankItem financeMarketBankItem = (FinanceMarketBankConfig.FinanceMarketBankItem) loanProductsMarketActivity.m.get(i);
            if (TextUtils.equals(financeMarketBankItem.getBankCode(), "More")) {
                List<FinanceMarketBankConfig.FinanceMarketBankItem> list = loanProductsMarketActivity.k;
                if (list != null && !list.isEmpty()) {
                    FinanceSelectBankDialog financeSelectBankDialog = new FinanceSelectBankDialog(loanProductsMarketActivity.k);
                    financeSelectBankDialog.e = new h(loanProductsMarketActivity, financeSelectBankDialog);
                    financeSelectBankDialog.show(loanProductsMarketActivity.getSupportFragmentManager(), "");
                }
            } else if (!TextUtils.equals(loanProductsMarketActivity.n, financeMarketBankItem.getBankCode())) {
                loanProductsMarketActivity.K0(financeMarketBankItem);
                if (TextUtils.equals(financeMarketBankItem.getBankCode(), "ALL")) {
                    ArrayList arrayList2 = loanProductsMarketActivity.f;
                    arrayList2.clear();
                    arrayList2.addAll(loanProductsMarketActivity.e);
                    loanProductsMarketActivity.d.notifyDataSetChanged();
                    loanProductsMarketActivity.g.a(2);
                } else {
                    loanProductsMarketActivity.J0(loanProductsMarketActivity.F0());
                }
                LoanMarketFilterAdapter loanMarketFilterAdapter = loanProductsMarketActivity.l;
                loanMarketFilterAdapter.a = i;
                loanMarketFilterAdapter.notifyDataSetChanged();
                loanProductsMarketActivity.I0(financeMarketBankItem.getThemeColor());
            }
        }
    }
}
