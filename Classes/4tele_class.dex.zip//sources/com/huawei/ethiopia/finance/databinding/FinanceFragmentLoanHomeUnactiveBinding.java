package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceFragmentLoanHomeUnactiveBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final RoundTextView b;

    public FinanceFragmentLoanHomeUnactiveBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, RoundTextView roundTextView) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = roundTextView;
    }
}
