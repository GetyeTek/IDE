package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.ethiopia.finance.widget.FinanceDisplayView;

public abstract class FinanceItemLoanRestructureBinding extends ViewDataBinding {
    @NonNull
    public final FinanceDisplayView a;

    public FinanceItemLoanRestructureBinding(DataBindingComponent dataBindingComponent, View view, FinanceDisplayView financeDisplayView) {
        super(dataBindingComponent, view, 0);
        this.a = financeDisplayView;
    }
}
