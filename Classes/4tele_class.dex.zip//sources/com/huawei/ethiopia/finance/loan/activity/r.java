package com.huawei.ethiopia.finance.loan.activity;

import android.view.View;

public final class r implements View.OnClickListener {
    public final /* synthetic */ FinanceServiceConfigActivity a;

    public r(FinanceServiceConfigActivity financeServiceConfigActivity) {
        this.a = financeServiceConfigActivity;
    }

    public final void onClick(View view) {
        int i = FinanceServiceConfigActivity.h;
        this.a.E0(0);
    }
}
