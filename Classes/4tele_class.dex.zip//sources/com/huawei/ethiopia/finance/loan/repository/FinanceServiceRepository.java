package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.ContractsInfo;
import com.huawei.ethiopia.finance.resp.CreditPayContractsInfo;
import com.huawei.ethiopia.finance.resp.FinanceMenu;
import com.huawei.ethiopia.finance.resp.FinanceMenuListResp;
import com.huawei.http.b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FinanceServiceRepository extends b<FinanceMenuListResp, FinanceMenuListResp> {
    public final Object convert(Object obj) {
        FinanceMenuListResp financeMenuListResp = (FinanceMenuListResp) obj;
        List<FinanceMenu> menuItems = financeMenuListResp.getMenuItems();
        List<CreditPayContractsInfo> overdraftContractItems = financeMenuListResp.getOverdraftContractItems();
        if (overdraftContractItems != null && !overdraftContractItems.isEmpty() && menuItems != null && !menuItems.isEmpty()) {
            ArrayList arrayList = new ArrayList(overdraftContractItems.size());
            for (CreditPayContractsInfo next : overdraftContractItems) {
                ContractsInfo contractsInfo = new ContractsInfo();
                contractsInfo.setLoan(false);
                contractsInfo.setAmount(next.getOutstandingAmount());
                contractsInfo.setTitle(next.getContractNameI18n());
                contractsInfo.setDueDate(next.getDueDate());
                contractsInfo.setCurrency(next.getCurrency());
                arrayList.add(contractsInfo);
            }
            Iterator<FinanceMenu> it = menuItems.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                FinanceMenu next2 = it.next();
                if ("finance_overdraft".equals(next2.getId())) {
                    next2.setContracts(arrayList);
                    break;
                }
            }
        }
        return financeMenuListResp;
    }

    public final String getApiPath() {
        return "v1/ethiopia/finance/menu";
    }
}
