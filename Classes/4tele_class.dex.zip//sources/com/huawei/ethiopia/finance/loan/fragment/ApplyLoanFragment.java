package com.huawei.ethiopia.finance.loan.fragment;

import A7.e;
import V1.h;
import V7.c;
import W1.b;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBinding;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanProductAdapter;
import com.huawei.ethiopia.finance.loan.repository.DeactivateLoanRepository;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel;
import com.huawei.ethiopia.finance.resp.FinanceLoanResp;
import com.huawei.ethiopia.finance.resp.FinanceMenu;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Map;
import p5.i;

public class ApplyLoanFragment extends Fragment {
    public FinanceApplyLoanViewModel a;
    public FinanceFragmentFinanceApplyLoanBinding b;
    public FinanceLoanProductAdapter c;
    public FinanceLoanResp d;
    public ArrayList<ProductInfo> e;
    public FinanceDispacherViewModel f;
    public String g;
    public FinanceMenu h;
    public b.b i;
    public String j;
    public boolean k;
    public boolean l;

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        ApplyLoanFragment.super.onActivityResult(i2, i3, intent);
        if (intent != null && i2 == 101 && i3 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            this.h.getTitle();
            h.b();
            FinanceApplyLoanViewModel financeApplyLoanViewModel = this.a;
            financeApplyLoanViewModel.c.setValue(c.c());
            new DeactivateLoanRepository(str).sendRequest(new e(financeApplyLoanViewModel, 2));
        }
        if (i2 == 1000 && i3 == -1 && intent != null) {
            if (this.j.equals(intent.getStringExtra("bankCode"))) {
                Bundle bundle = new Bundle();
                bundle.putString("execute", i.e.a(false));
                o0.b.d((Activity) null, "/finance/transactionResult", bundle, (Map) null);
            }
            this.h.getTitle();
            h.b();
        }
    }

    /* JADX WARNING: type inference failed for: r2v3, types: [W4.a, java.lang.Object] */
    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        this.b = DataBindingUtil.inflate(layoutInflater, R$layout.finance_fragment_finance_apply_loan, viewGroup, false);
        b.b c2 = b.a(new Object()).c(this.b.b);
        c2.b = new O1.b(this, 1);
        this.i = c2;
        return this.b.getRoot();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x00dd, code lost:
        r10 = com.huawei.ethiopia.finance.R$id.rootLayout;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onViewCreated(@androidx.annotation.NonNull android.view.View r9, @androidx.annotation.Nullable android.os.Bundle r10) {
        /*
            r8 = this;
            com.huawei.ethiopia.finance.loan.fragment.ApplyLoanFragment.super.onViewCreated(r9, r10)
            android.os.Bundle r9 = r8.getArguments()
            if (r9 == 0) goto L_0x0027
            android.os.Bundle r9 = r8.getArguments()
            java.lang.String r10 = "fundsLenderId"
            java.lang.String r10 = r9.getString(r10)
            r8.g = r10
            java.lang.String r10 = "financeMenu"
            java.io.Serializable r10 = r9.getSerializable(r10)
            com.huawei.ethiopia.finance.resp.FinanceMenu r10 = (com.huawei.ethiopia.finance.resp.FinanceMenu) r10
            r8.h = r10
            java.lang.String r10 = "bankCode"
            java.lang.String r9 = r9.getString(r10)
            r8.j = r9
        L_0x0027:
            com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBinding r9 = r8.b
            com.huawei.common.widget.recyclerview.HFRecyclerView r9 = r9.d
            androidx.recyclerview.widget.LinearLayoutManager r10 = new androidx.recyclerview.widget.LinearLayoutManager
            android.content.Context r0 = r8.getContext()
            r10.<init>(r0)
            r9.setLayoutManager(r10)
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            r8.e = r9
            com.huawei.ethiopia.finance.loan.adapter.FinanceLoanProductAdapter r9 = new com.huawei.ethiopia.finance.loan.adapter.FinanceLoanProductAdapter
            java.util.ArrayList<com.huawei.ethiopia.finance.resp.ProductInfo> r10 = r8.e
            r9.<init>(r10)
            r8.c = r9
            java.lang.String r10 = r8.j
            r9.d = r10
            Y4.e r10 = new Y4.e
            r10.<init>(r8)
            r9.f = r10
            Y4.e r10 = new Y4.e
            r10.<init>(r8)
            r9.e = r10
            Y4.f r10 = new Y4.f
            r10.<init>(r8)
            r9.a = r10
            com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBinding r9 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r9 = r9.c
            com.huawei.common.widget.LoadingButton r10 = r9.a
            D6.f r0 = new D6.f
            r1 = 1
            r0.<init>(r8, r1)
            r10.setOnClickListener(r0)
            com.huawei.ethiopia.finance.resp.FinanceMenu r10 = r8.h
            if (r10 == 0) goto L_0x007c
            com.huawei.common.widget.round.RoundTextView r9 = r9.b
            java.lang.String r10 = r10.getSubTitle()
            r9.setText(r10)
        L_0x007c:
            com.huawei.ethiopia.finance.loan.adapter.FinanceLoanProductAdapter r9 = r8.c
            Y4.g r10 = new Y4.g
            r10.<init>(r8)
            r9.b = r10
            com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBinding r10 = r8.b
            com.huawei.common.widget.recyclerview.HFRecyclerView r10 = r10.d
            r10.setAdapter(r9)
            androidx.lifecycle.ViewModelProvider r9 = new androidx.lifecycle.ViewModelProvider
            r9.<init>(r8)
            java.lang.Class<com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel> r10 = com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel.class
            androidx.lifecycle.ViewModel r9 = r9.get(r10)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel r9 = (com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel) r9
            r8.a = r9
            java.lang.String r10 = r8.g
            r9.a = r10
            androidx.lifecycle.ViewModelProvider r9 = new androidx.lifecycle.ViewModelProvider
            r9.<init>(r8)
            java.lang.Class<com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel> r10 = com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel.class
            androidx.lifecycle.ViewModel r9 = r9.get(r10)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel r9 = (com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel) r9
            r8.f = r9
            java.lang.String r10 = "finance_loan"
            r9.a(r10)
            android.view.LayoutInflater r9 = r8.getLayoutInflater()
            int r10 = com.huawei.ethiopia.finance.R$layout.finance_add_my_telebirr_mela_layout
            r0 = 0
            r1 = 0
            android.view.View r9 = r9.inflate(r10, r1, r0)
            int r10 = com.huawei.ethiopia.finance.R$id.iv_right
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r10)
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            if (r0 == 0) goto L_0x028a
            int r10 = com.huawei.ethiopia.finance.R$id.iv_sinq
            android.view.View r0 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r10)
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            if (r0 == 0) goto L_0x028a
            int r10 = com.huawei.ethiopia.finance.R$id.rlTermCondition
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r10)
            android.widget.TextView r1 = (android.widget.TextView) r1
            if (r1 == 0) goto L_0x028a
            int r10 = com.huawei.ethiopia.finance.R$id.rootLayout
            android.view.View r2 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r10)
            com.huawei.common.widget.round.RoundLinearLayout r2 = (com.huawei.common.widget.round.RoundLinearLayout) r2
            if (r2 == 0) goto L_0x028a
            int r10 = com.huawei.ethiopia.finance.R$id.tvMelaProducts
            android.view.View r3 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r10)
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L_0x028a
            int r10 = com.huawei.ethiopia.finance.R$id.tv_my_telebirr_mela
            android.view.View r4 = androidx.viewbinding.ViewBindings.findChildViewById(r9, r10)
            android.widget.TextView r4 = (android.widget.TextView) r4
            if (r4 == 0) goto L_0x028a
            com.huawei.common.widget.round.RoundConstraintLayout r9 = (com.huawei.common.widget.round.RoundConstraintLayout) r9
            int r10 = com.huawei.ethiopia.finance.R$string.enderase_product
            java.lang.String r10 = r8.getString(r10)
            int r5 = com.huawei.ethiopia.finance.R$string.my_enderas_and_adrash
            java.lang.String r5 = r8.getString(r5)
            p5.g r6 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r6 = r6.a
            if (r6 == 0) goto L_0x013f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r7 = r6.getFinanceServiceUIConfig()
            if (r7 == 0) goto L_0x013f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r7 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r7 = r7.getLoan()
            if (r7 == 0) goto L_0x013f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r7 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r7 = r7.getLoan()
            java.lang.String r7 = r7.getLoanProductsTitle()
            boolean r7 = android.text.TextUtils.isEmpty(r7)
            if (r7 != 0) goto L_0x013f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r10 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r10 = r10.getLoan()
            java.lang.String r10 = r10.getLoanProductsTitle()
        L_0x013f:
            if (r6 == 0) goto L_0x016f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r7 = r6.getFinanceServiceUIConfig()
            if (r7 == 0) goto L_0x016f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r7 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r7 = r7.getLoan()
            if (r7 == 0) goto L_0x016f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r7 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r7 = r7.getLoan()
            java.lang.String r7 = r7.getMyLoanTxt()
            boolean r7 = android.text.TextUtils.isEmpty(r7)
            if (r7 != 0) goto L_0x016f
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r5 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r5 = r5.getLoan()
            java.lang.String r5 = r5.getMyLoanTxt()
        L_0x016f:
            r3.setText(r10)
            r4.setText(r5)
            r10 = -1
            if (r6 == 0) goto L_0x01a9
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r4 = r6.getFinanceServiceUIConfig()
            if (r4 == 0) goto L_0x01a9
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r4 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r4 = r4.getLoan()
            if (r4 == 0) goto L_0x01a9
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r4 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r4 = r4.getLoan()
            java.lang.String r4 = r4.getMyLoanIcon()
            boolean r4 = android.text.TextUtils.isEmpty(r4)
            if (r4 != 0) goto L_0x01a9
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r4 = r6.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r4 = r4.getLoan()
            java.lang.String r4 = r4.getMyLoanIcon()
            O9.c.c(r0, r4, r10)
        L_0x01a9:
            d2.a r0 = r2.getBaseFilletView()
            androidx.fragment.app.FragmentActivity r4 = r8.requireActivity()
            p5.g r5 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r5 = r5.a
            java.lang.String r6 = r8.j
            int r4 = p5.g.f(r4, r5, r6)
            r0.e(r4)
            androidx.fragment.app.FragmentActivity r0 = r8.requireActivity()
            p5.g r4 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r4 = r4.a
            java.lang.String r5 = r8.j
            int r0 = p5.g.f(r0, r4, r5)
            r3.setTextColor(r0)
            com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBinding r0 = r8.b
            com.huawei.common.widget.recyclerview.HFRecyclerView r0 = r0.d
            r0.a(r10, r9)
            H6.i r9 = new H6.i
            r10 = 1
            r9.<init>(r8, r10)
            r2.setOnClickListener(r9)
            D6.c r9 = new D6.c
            r10 = 3
            r9.<init>(r8, r10)
            r1.setOnClickListener(r9)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel r9 = r8.a
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.FinanceLoanResp>> r9 = r9.b
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            Y4.c r0 = new Y4.c
            r0.<init>(r8)
            r9.observe(r10, r0)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel r9 = r8.a
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.ProductInfo>> r9 = r9.d
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            Y4.a r0 = new Y4.a
            r1 = 0
            r0.<init>(r8, r1)
            r9.observe(r10, r0)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel r9 = r8.a
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.ProductInfo>> r9 = r9.e
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            Y4.i r0 = new Y4.i
            r0.<init>(r8)
            r9.observe(r10, r0)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel r9 = r8.a
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.http.BaseResp>> r9 = r9.c
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            Y4.d r0 = new Y4.d
            r1 = 0
            r0.<init>(r8, r1)
            r9.observe(r10, r0)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel r9 = r8.f
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.ActiveState>> r9 = r9.a
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            Y4.b r0 = new Y4.b
            r1 = 0
            r0.<init>(r8, r1)
            r9.observe(r10, r0)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel r9 = r8.a
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.RolloverPreValidationResp>> r9 = r9.f
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            Y4.h r0 = new Y4.h
            r1 = 0
            r0.<init>(r8, r1)
            r9.observe(r10, r0)
            com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel r9 = r8.a
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.RolloverPreValidationResp>> r9 = r9.g
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            Y4.j r0 = new Y4.j
            r1 = 0
            r0.<init>(r8, r1)
            r9.observe(r10, r0)
            a5.f r9 = a5.f.c
            java.lang.String r10 = r8.j
            androidx.lifecycle.LiveData r10 = r9.a(r10)
            androidx.lifecycle.LifecycleOwner r0 = r8.getViewLifecycleOwner()
            D4.q r1 = new D4.q
            r2 = 2
            r1.<init>(r8, r2)
            r10.observe(r0, r1)
            java.lang.String r10 = r8.j
            androidx.lifecycle.LiveData r9 = r9.b(r10)
            androidx.lifecycle.LifecycleOwner r10 = r8.getViewLifecycleOwner()
            D4.r r0 = new D4.r
            r1 = 1
            r0.<init>(r8, r1)
            r9.observe(r10, r0)
            return
        L_0x028a:
            android.content.res.Resources r9 = r9.getResources()
            java.lang.String r9 = r9.getResourceName(r10)
            java.lang.NullPointerException r10 = new java.lang.NullPointerException
            java.lang.String r0 = "Missing required view with ID: "
            java.lang.String r9 = r0.concat(r9)
            r10.<init>(r9)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.loan.fragment.ApplyLoanFragment.onViewCreated(android.view.View, android.os.Bundle):void");
    }
}
