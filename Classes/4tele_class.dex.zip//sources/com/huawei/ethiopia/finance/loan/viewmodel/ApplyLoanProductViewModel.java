package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.loan.repository.ApplyLoanProductRepository;
import com.huawei.ethiopia.finance.loan.repository.LoanPreValidtionRepository;
import com.huawei.ethiopia.finance.resp.LoanTrialResp;
import com.huawei.http.BaseResp;

public class ApplyLoanProductViewModel extends ViewModel {
    public final MutableLiveData<c<BaseResp>> a = new MutableLiveData<>();
    public final MutableLiveData<c<LoanTrialResp>> b;
    public ApplyLoanProductRepository c;
    public LoanPreValidtionRepository d;

    public ApplyLoanProductViewModel() {
        new MutableLiveData();
        this.b = new MutableLiveData<>();
    }

    public final void onCleared() {
        ApplyLoanProductViewModel.super.onCleared();
        ApplyLoanProductRepository applyLoanProductRepository = this.c;
        if (applyLoanProductRepository != null) {
            applyLoanProductRepository.cancel();
        }
        LoanPreValidtionRepository loanPreValidtionRepository = this.d;
        if (loanPreValidtionRepository != null) {
            loanPreValidtionRepository.cancel();
        }
    }
}
