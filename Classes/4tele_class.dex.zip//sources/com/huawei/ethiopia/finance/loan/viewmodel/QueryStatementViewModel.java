package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.loan.repository.QueryStatementRepository;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.ethiopia.finance.resp.LoanStatementResp;
import com.huawei.http.b;

public class QueryStatementViewModel extends ViewModel {
    public final MutableLiveData<c<LoanStatementResp>> a = new MutableLiveData<>();
    public QueryStatementRepository b;

    public class a implements R1.a<LoanStatementResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            QueryStatementViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            QueryStatementViewModel.this.a.setValue(c.e((LoanStatementResp) obj));
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.http.b, com.huawei.ethiopia.finance.loan.repository.QueryStatementRepository] */
    public final void a(String str, LoanContractsInfo loanContractsInfo) {
        this.a.setValue(c.c());
        String productId = loanContractsInfo.getProductId();
        ? bVar = new b();
        bVar.addParams("contractId", str);
        bVar.addParams("productId", productId);
        bVar.addParams("status", "outstanding");
        this.b = bVar;
        bVar.sendRequest(new a());
    }

    public final void onCleared() {
        QueryStatementViewModel.super.onCleared();
        QueryStatementRepository queryStatementRepository = this.b;
        if (queryStatementRepository != null) {
            queryStatementRepository.cancel();
        }
    }
}
