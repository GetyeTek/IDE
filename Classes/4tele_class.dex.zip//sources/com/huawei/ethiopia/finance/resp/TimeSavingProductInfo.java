package com.huawei.ethiopia.finance.resp;

import android.text.TextUtils;
import com.huawei.http.BaseResp;
import java.io.Serializable;

public class TimeSavingProductInfo extends BaseResp {
    private String currency;
    private String interestRate;
    private String productId;
    private ProductInfoBean productInfo;
    private String productLifeTime;
    private String productName;
    private String rateValue;
    private String rateValueMode;
    private String taxRate;
    private String uniqueId;

    public static class ProductInfoBean implements Serializable {
        private String activatePolicy;
        private String availableIdentityType;
        private String currency;
        private String description;
        private String earlyWithDrawPolicy;
        private String endDate;
        private String maturityPolicy;
        private String maxAccountNumber;
        private String maxOpeningBalance;
        private String minOpeningBalance;
        private String productCategory;
        private String productID;
        private String productName;
        private String productType;
        private String rateIndicator;
        private String startDate;
        private String status;
        private String termUnit;
        private String termValue;
        private String uniqueID;
        private String version;

        public String getActivatePolicy() {
            return this.activatePolicy;
        }

        public String getAvailableIdentityType() {
            return this.availableIdentityType;
        }

        public String getCurrency() {
            return this.currency;
        }

        public String getDescription() {
            return this.description;
        }

        public String getEarlyWithDrawPolicy() {
            if (TextUtils.equals(this.earlyWithDrawPolicy, "Y")) {
                return "Yes";
            }
            return "No";
        }

        public String getEndDate() {
            return this.endDate;
        }

        public String getMaturityPolicy() {
            return this.maturityPolicy;
        }

        public String getMaxAccountNumber() {
            return this.maxAccountNumber;
        }

        public String getMaxOpeningBalance() {
            return this.maxOpeningBalance;
        }

        public String getMinOpeningBalance() {
            return this.minOpeningBalance;
        }

        public String getProductCategory() {
            return this.productCategory;
        }

        public String getProductID() {
            return this.productID;
        }

        public String getProductName() {
            return this.productName;
        }

        public String getProductType() {
            return this.productType;
        }

        public String getRateIndicator() {
            return this.rateIndicator;
        }

        public String getStartDate() {
            return this.startDate;
        }

        public String getStatus() {
            return this.status;
        }

        public String getTermUnit() {
            return this.termUnit;
        }

        public String getTermValue() {
            return this.termValue;
        }

        public String getUniqueID() {
            return this.uniqueID;
        }

        public String getVersion() {
            return this.version;
        }

        public void setActivatePolicy(String str) {
            this.activatePolicy = str;
        }

        public void setAvailableIdentityType(String str) {
            this.availableIdentityType = str;
        }

        public void setCurrency(String str) {
            this.currency = str;
        }

        public void setDescription(String str) {
            this.description = str;
        }

        public void setEarlyWithDrawPolicy(String str) {
            this.earlyWithDrawPolicy = str;
        }

        public void setEndDate(String str) {
            this.endDate = str;
        }

        public void setMaturityPolicy(String str) {
            this.maturityPolicy = str;
        }

        public void setMaxAccountNumber(String str) {
            this.maxAccountNumber = str;
        }

        public void setMaxOpeningBalance(String str) {
            this.maxOpeningBalance = str;
        }

        public void setMinOpeningBalance(String str) {
            this.minOpeningBalance = str;
        }

        public void setProductCategory(String str) {
            this.productCategory = str;
        }

        public void setProductID(String str) {
            this.productID = str;
        }

        public void setProductName(String str) {
            this.productName = str;
        }

        public void setProductType(String str) {
            this.productType = str;
        }

        public void setRateIndicator(String str) {
            this.rateIndicator = str;
        }

        public void setStartDate(String str) {
            this.startDate = str;
        }

        public void setStatus(String str) {
            this.status = str;
        }

        public void setTermUnit(String str) {
            this.termUnit = str;
        }

        public void setTermValue(String str) {
            this.termValue = str;
        }

        public void setUniqueID(String str) {
            this.uniqueID = str;
        }

        public void setVersion(String str) {
            this.version = str;
        }
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getInterestRate() {
        return this.interestRate;
    }

    public String getProductId() {
        return this.productId;
    }

    public ProductInfoBean getProductInfo() {
        return this.productInfo;
    }

    public String getProductLifeTime() {
        if (TextUtils.isEmpty(this.productLifeTime)) {
            return "--";
        }
        return this.productLifeTime;
    }

    public String getProductName() {
        return this.productName;
    }

    public String getRateValue() {
        return this.rateValue;
    }

    public String getRateValueMode() {
        return this.rateValueMode;
    }

    public String getTaxRate() {
        return this.taxRate;
    }

    public String getUniqueId() {
        return this.uniqueId;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setInterestRate(String str) {
        this.interestRate = str;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setProductInfo(ProductInfoBean productInfoBean) {
        this.productInfo = productInfoBean;
    }

    public void setProductLifeTime(String str) {
        this.productLifeTime = str;
    }

    public void setProductName(String str) {
        this.productName = str;
    }

    public void setRateValue(String str) {
        this.rateValue = str;
    }

    public void setRateValueMode(String str) {
        this.rateValueMode = str;
    }

    public void setTaxRate(String str) {
        this.taxRate = str;
    }

    public void setUniqueId(String str) {
        this.uniqueId = str;
    }
}
