package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public abstract class FinanceBottomDisplayDialogLayoutBinding extends ViewDataBinding {
    @NonNull
    public final ImageView a;
    @NonNull
    public final RecyclerView b;
    @NonNull
    public final TextView c;

    public FinanceBottomDisplayDialogLayoutBinding(DataBindingComponent dataBindingComponent, View view, ImageView imageView, RecyclerView recyclerView, TextView textView) {
        super(dataBindingComponent, view, 0);
        this.a = imageView;
        this.b = recyclerView;
        this.c = textView;
    }
}
