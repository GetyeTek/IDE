package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemLoanMarketProductBindingImpl extends FinanceItemLoanMarketProductBinding {
    @Nullable
    public static final SparseIntArray w;
    public long v;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        w = sparseIntArray;
        sparseIntArray.put(R$id.imageView, 1);
        sparseIntArray.put(R$id.tvTitle, 2);
        sparseIntArray.put(R$id.tv_desc, 3);
        sparseIntArray.put(R$id.btn_apply, 4);
        sparseIntArray.put(R$id.recycler_view, 5);
        sparseIntArray.put(R$id.cl_detail, 6);
        sparseIntArray.put(R$id.cl_more, 7);
        sparseIntArray.put(R$id.tvInterestRateValue, 8);
        sparseIntArray.put(R$id.tvInterestRate, 9);
        sparseIntArray.put(R$id.tvMaintenanceFeeValue, 10);
        sparseIntArray.put(R$id.tvMaintenanceFeeRate, 11);
        sparseIntArray.put(R$id.tvTotalGainsValue, 12);
        sparseIntArray.put(R$id.tvTotalGains, 13);
        sparseIntArray.put(R$id.tvMaxLimitValue, 14);
        sparseIntArray.put(R$id.tvMaxLimit, 15);
        sparseIntArray.put(R$id.tvAdvanceFeeValue, 16);
        sparseIntArray.put(R$id.tvAdvanceFee, 17);
        sparseIntArray.put(R$id.llMore, 18);
        sparseIntArray.put(R$id.tvMore, 19);
        sparseIntArray.put(R$id.ivMore, 20);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.v = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.v != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.v = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
