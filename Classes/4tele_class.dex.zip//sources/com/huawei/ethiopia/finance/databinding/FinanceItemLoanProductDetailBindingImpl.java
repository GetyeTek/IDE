package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemLoanProductDetailBindingImpl extends FinanceItemLoanProductDetailBinding {
    @Nullable
    public static final SparseIntArray c;
    public long b;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        c = sparseIntArray;
        sparseIntArray.put(R$id.tvInterestRateValue, 1);
        sparseIntArray.put(R$id.tvInterestRate, 2);
        sparseIntArray.put(R$id.tvTotalGainsValue, 3);
        sparseIntArray.put(R$id.tvTotalGains, 4);
        sparseIntArray.put(R$id.tvMaxLimitValue, 5);
        sparseIntArray.put(R$id.tvMaxLimit, 6);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.b = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.b != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.b = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
