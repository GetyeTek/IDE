package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class FinanceActivityMyTelebirrMelaBinding extends ViewDataBinding {
    @NonNull
    public final FrameLayout a;

    public FinanceActivityMyTelebirrMelaBinding(DataBindingComponent dataBindingComponent, View view, FrameLayout frameLayout) {
        super(dataBindingComponent, view, 0);
        this.a = frameLayout;
    }
}
