package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.loan.repository.RepayLoanRepository;
import com.huawei.http.BaseResp;

public class FinanceLoanRepayViewModel extends ViewModel {
    public final MutableLiveData<c<BaseResp>> a = new MutableLiveData<>();
    public RepayLoanRepository b;

    public final void onCleared() {
        FinanceLoanRepayViewModel.super.onCleared();
        RepayLoanRepository repayLoanRepository = this.b;
        if (repayLoanRepository != null) {
            repayLoanRepository.cancel();
        }
    }
}
