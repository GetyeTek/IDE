package com.huawei.ethiopia.finance.loan.activity;

import D4.q;
import D4.r;
import V7.e;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Window;
import androidx.annotation.Nullable;
import androidx.camera.core.impl.p;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityLoanContractDetailBinding;
import com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionTitleBinding;
import com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadBinding;
import com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadRepaymentScheduleBinding;
import com.huawei.ethiopia.finance.loan.adapter.ContractTransactionAdapter;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanContactScheduleAdapter;
import com.huawei.ethiopia.finance.loan.adapter.ResultAdapter;
import com.huawei.ethiopia.finance.loan.viewmodel.LoanContractDetailViewModel;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.Map;
import o0.b;

@Route(path = "/finance/loanContractDetail")
public class LoanContractDetailActivity extends DataBindingActivity<FinanceActivityLoanContractDetailBinding, LoanContractDetailViewModel> {
    public static final /* synthetic */ int o = 0;
    public ContractTransactionAdapter d;
    public FinanceLoanContractDetailHeadBinding e;
    public FinanceLoanContractDetailHeadRepaymentScheduleBinding f;
    public ResultAdapter g;
    public String h;
    public String i;
    public LoanContractsInfo j;
    public FinanceLoanContactScheduleAdapter k;
    public String l;
    public String m;
    public FinanceItemSavingProductTransactionTitleBinding n;

    public final int C0() {
        return R$layout.finance_activity_loan_contract_detail;
    }

    /* JADX WARNING: type inference failed for: r1v11, types: [android.view.View$OnClickListener, com.huawei.ethiopia.finance.loan.activity.t] */
    public final void E0(LoanContractsInfo loanContractsInfo) {
        this.e.e.setText(loanContractsInfo.getProductNameI18n());
        this.e.c.setText(loanContractsInfo.getContractId());
        this.e.d.setBackgroundColor(loanContractsInfo.getStateBackground());
        this.e.d.setText(loanContractsInfo.getShowStatusStr());
        this.e.d.setTextColor(loanContractsInfo.getStateTextColor());
        this.e.f.setText(loanContractsInfo.getTotalCreditAmountTitle());
        this.e.g.setText(loanContractsInfo.getPrincipalAmount());
        this.e.h.setText(loanContractsInfo.getTotalOutstandingAmountTitle());
        this.e.i.setText(loanContractsInfo.getOutstandingAmount());
        this.e.i.setTextColor(loanContractsInfo.getTotalOutstandingAmountTextColor());
        if (loanContractsInfo.isAllowLoadRestructure()) {
            this.e.a.setVisibility(0);
            this.e.a.setOnClickListener(new t(this, loanContractsInfo));
        }
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        LoanContractDetailActivity.super.onActivityResult(i2, i3, intent);
        if (i2 == 1112 && i3 == -1 && intent != null) {
            b.d((Activity) null, "/finance/transactionResult", (Bundle) null, (Map) null);
            this.c.a(this.j.getContractId());
        } else if (i2 == 1113 && i3 == -1) {
            b.d((Activity) null, "/finance/transactionResult", (Bundle) null, (Map) null);
            this.c.a(this.j.getContractId());
            this.f.a.setVisibility(8);
        }
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.ethiopia.finance.loan.activity.LoanContractDetailActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        LoanContractDetailActivity.super.onCreate(bundle);
        Window window = getWindow();
        int i2 = R$color.colorPageBackgroundDark;
        window.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, i2)));
        f.e(this, ContextCompat.getColor(this, i2), false);
        this.b.a.setLayoutManager(new LinearLayoutManager(this));
        ContractTransactionAdapter contractTransactionAdapter = new ContractTransactionAdapter();
        this.d = contractTransactionAdapter;
        this.b.a.setAdapter(contractTransactionAdapter);
        this.j = (LoanContractsInfo) getIntent().getSerializableExtra("contractsInfo");
        this.l = getIntent().getStringExtra("bankCode");
        this.m = getIntent().getStringExtra("bankIcon");
        e.a(this, getString(R$string.contract_details), R.layout.common_toolbar);
        FinanceLoanContractDetailHeadBinding inflate = DataBindingUtil.inflate(getLayoutInflater(), R$layout.finance_loan_contract_detail_head, this.b.a, false);
        this.e = inflate;
        this.b.a.a(-1, inflate.getRoot());
        this.e.b.setLayoutManager(new LinearLayoutManager(this));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.finance_item_contract_display);
        this.g = baseQuickAdapter;
        this.e.b.setAdapter(baseQuickAdapter);
        FinanceLoanContractDetailHeadRepaymentScheduleBinding inflate2 = DataBindingUtil.inflate(getLayoutInflater(), R$layout.finance_loan_contract_detail_head_repayment_schedule, this.b.a, false);
        this.f = inflate2;
        this.b.a.a(-1, inflate2.getRoot());
        LoanContractsInfo loanContractsInfo = this.j;
        BaseQuickAdapter baseQuickAdapter2 = new BaseQuickAdapter(R$layout.finance_item_loan_contact_schedule);
        baseQuickAdapter2.a = loanContractsInfo;
        baseQuickAdapter2.addChildClickViewIds(new int[]{R$id.btn_repay});
        this.k = baseQuickAdapter2;
        baseQuickAdapter2.setOnItemChildClickListener(new p(this, 2));
        this.f.b.setAdapter(this.k);
        this.c.a.observe(this, new q(this, 3));
        this.c.b.observe(this, new r(this, 2));
        this.c.c.observe(this, new Y4.b(this, 1));
        LoanContractsInfo loanContractsInfo2 = this.j;
        if (loanContractsInfo2 != null) {
            this.c.a(loanContractsInfo2.getContractId());
            E0(this.j);
        }
    }
}
