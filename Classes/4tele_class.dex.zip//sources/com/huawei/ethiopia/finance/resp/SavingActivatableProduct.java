package com.huawei.ethiopia.finance.resp;

import com.google.gson.annotations.SerializedName;
import com.huawei.http.BaseResp;

public class SavingActivatableProduct extends BaseResp {
    private String description;
    private String iconUrl;
    private String minOpeningBalance;
    @SerializedName(alternate = {"productDescI18N"}, value = "productDescI18n")
    private String productDescI18n;
    private String productIcon;
    @SerializedName("productID")
    private String productId;
    private String productName;
    @SerializedName(alternate = {"productNameI18N"}, value = "productNameI18n")
    private String productNameI18n;
    private String rateMode;
    private String rateValue;
    private String rateValueMode;
    private boolean show;
    private String uniqueID;

    public String getDescription() {
        return this.description;
    }

    public String getIconUrl() {
        return this.iconUrl;
    }

    public String getMinOpeningBalance() {
        return this.minOpeningBalance;
    }

    public String getProductDescI18n() {
        return this.productDescI18n;
    }

    public String getProductIcon() {
        return this.productIcon;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getProductName() {
        return this.productName;
    }

    public String getProductNameI18n() {
        return this.productNameI18n;
    }

    public String getRateMode() {
        return this.rateMode;
    }

    public String getRateValue() {
        return this.rateValue;
    }

    public String getRateValueMode() {
        return this.rateValueMode;
    }

    public String getUniqueID() {
        return this.uniqueID;
    }

    public boolean isShow() {
        return this.show;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public void setIconUrl(String str) {
        this.iconUrl = str;
    }

    public void setMinOpeningBalance(String str) {
        this.minOpeningBalance = str;
    }

    public void setProductDescI18n(String str) {
        this.productDescI18n = str;
    }

    public void setProductIcon(String str) {
        this.productIcon = str;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setProductName(String str) {
        this.productName = str;
    }

    public void setProductNameI18n(String str) {
        this.productNameI18n = str;
    }

    public void setRateMode(String str) {
        this.rateMode = str;
    }

    public void setRateValue(String str) {
        this.rateValue = str;
    }

    public void setRateValueMode(String str) {
        this.rateValueMode = str;
    }

    public void setShow(boolean z) {
        this.show = z;
    }

    public void setUniqueID(String str) {
        this.uniqueID = str;
    }
}
