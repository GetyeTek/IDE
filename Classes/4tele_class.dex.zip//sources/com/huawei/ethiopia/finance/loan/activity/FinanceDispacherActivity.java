package com.huawei.ethiopia.finance.loan.activity;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.customer.login_module.upgrade.b;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;

@Route(path = "/finance/financeDispacher")
public class FinanceDispacherActivity extends DataBindingActivity<ViewDataBinding, FinanceDispacherViewModel> {
    public static final /* synthetic */ int f = 0;
    public String d;
    public String e;

    public final int C0() {
        return 0;
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.ethiopia.finance.loan.activity.FinanceDispacherActivity, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceDispacherActivity.super.onCreate(bundle);
        overridePendingTransition(0, 0);
        this.d = getIntent().getStringExtra("id");
        this.e = getIntent().getStringExtra("fundsLenderId");
        this.c.a(this.d);
        this.c.a.observe(this, new b(this, 1));
    }
}
