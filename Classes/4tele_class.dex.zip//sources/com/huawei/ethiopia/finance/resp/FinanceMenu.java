package com.huawei.ethiopia.finance.resp;

import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.J;
import com.google.gson.annotations.SerializedName;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class FinanceMenu extends BaseResp implements Serializable {
    private List<ContractsInfo> contracts;
    @SerializedName("execute")
    private String execute;
    @SerializedName("icon")
    private String icon;
    @SerializedName("funcId")
    private String id;
    private String order;
    private String queryDetail;
    @SerializedName("funcDesc")
    private String subTitle;
    @SerializedName("funcName")
    private String title;

    public List<ContractsInfo> getContracts() {
        return this.contracts;
    }

    public String getExecute() {
        return this.execute;
    }

    public int getIcon() {
        if ("finance_overdraft".equals(this.id)) {
            return R$mipmap.finance_icon_endekise;
        }
        if ("finance_loan".equals(this.id)) {
            return R$mipmap.finance_icon_mela;
        }
        if ("finance_saving".equals(this.id)) {
            return R$mipmap.finance_icon_sanduq;
        }
        return 0;
    }

    public String getId() {
        return this.id;
    }

    public String getShowType() {
        if ("finance_overdraft".equals(this.id)) {
            return J.a().getString(R$string.overdraft);
        }
        if ("finance_loan".equals(this.id)) {
            return J.a().getString(R$string.micro_credit);
        }
        if ("finance_saving".equals(this.id)) {
            return J.a().getString(R$string.saving);
        }
        return "";
    }

    public int getShowTypeTextBackgroundColor() {
        if ("finance_overdraft".equals(this.id)) {
            return ContextCompat.getColor(J.a(), R$color.colorEmbellishment20);
        }
        if ("finance_loan".equals(this.id)) {
            return ContextCompat.getColor(J.a(), R$color.colorInputBoxFocus20);
        }
        if ("finance_saving".equals(this.id)) {
            return ContextCompat.getColor(J.a(), R$color.color_3300B936);
        }
        return -1;
    }

    public int getShowTypeTextColor() {
        if ("finance_overdraft".equals(this.id)) {
            return ContextCompat.getColor(J.a(), R$color.colorEmbellishment);
        }
        if ("finance_loan".equals(this.id)) {
            return ContextCompat.getColor(J.a(), R$color.colorInputBoxFocus);
        }
        if ("finance_saving".equals(this.id)) {
            return ContextCompat.getColor(J.a(), R$color.color_00B936);
        }
        return -1;
    }

    public String getSubTitle() {
        return this.subTitle;
    }

    public String getTitle() {
        return this.title;
    }

    public void setContracts(List<ContractsInfo> list) {
        this.contracts = list;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setIcon(String str) {
        this.icon = str;
    }

    public void setId(String str) {
        this.id = str;
    }

    public void setSubTitle(String str) {
        this.subTitle = str;
    }

    public void setTitle(String str) {
        this.title = str;
    }
}
