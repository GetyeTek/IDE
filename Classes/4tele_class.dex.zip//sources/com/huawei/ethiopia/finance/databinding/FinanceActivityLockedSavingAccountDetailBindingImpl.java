package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LifecycleOwner;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;

public class FinanceActivityLockedSavingAccountDetailBindingImpl extends FinanceActivityLockedSavingAccountDetailBinding {
    @Nullable
    public static final ViewDataBinding.IncludedLayouts g;
    @Nullable
    public static final SparseIntArray h;
    public long f;

    static {
        ViewDataBinding.IncludedLayouts includedLayouts = new ViewDataBinding.IncludedLayouts(8);
        g = includedLayouts;
        includedLayouts.setIncludes(0, new String[]{"finance_item_my_fixed_time_saving_detail"}, new int[]{1}, new int[]{R$layout.finance_item_my_fixed_time_saving_detail});
        SparseIntArray sparseIntArray = new SparseIntArray();
        h = sparseIntArray;
        sparseIntArray.put(R$id.tvTransactionType, 2);
        sparseIntArray.put(R$id.view2, 3);
        sparseIntArray.put(R$id.recycler_view, 4);
        sparseIntArray.put(R$id.roundLinearLayout, 5);
        sparseIntArray.put(R$id.tv_withdraw, 6);
        sparseIntArray.put(R$id.tv_deposit, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.f = 0;
        }
        ViewDataBinding.executeBindingsOn(this.a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0015, code lost:
        if (r6.a.hasPendingBindings() == false) goto L_0x0018;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0017, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0018, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean hasPendingBindings() {
        /*
            r6 = this;
            monitor-enter(r6)
            long r0 = r6.f     // Catch:{ all -> 0x000c }
            r2 = 0
            r4 = 1
            int r5 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r5 == 0) goto L_0x000e
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            return r4
        L_0x000c:
            r0 = move-exception
            goto L_0x001a
        L_0x000e:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            com.huawei.ethiopia.finance.databinding.FinanceItemMyFixedTimeSavingDetailBinding r0 = r6.a
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0018
            return r4
        L_0x0018:
            r0 = 0
            return r0
        L_0x001a:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountDetailBindingImpl.hasPendingBindings():boolean");
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.f = 2;
        }
        this.a.invalidateAll();
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        if (i != 0) {
            return false;
        }
        FinanceItemMyFixedTimeSavingDetailBinding financeItemMyFixedTimeSavingDetailBinding = (FinanceItemMyFixedTimeSavingDetailBinding) obj;
        if (i2 != 0) {
            return false;
        }
        synchronized (this) {
            this.f |= 1;
        }
        return true;
    }

    public final void setLifecycleOwner(@Nullable LifecycleOwner lifecycleOwner) {
        FinanceActivityLockedSavingAccountDetailBindingImpl.super.setLifecycleOwner(lifecycleOwner);
        this.a.setLifecycleOwner(lifecycleOwner);
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
