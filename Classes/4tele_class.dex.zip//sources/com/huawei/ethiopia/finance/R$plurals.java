package com.huawei.ethiopia.finance;

public final class R$plurals {
    public static final int mtrl_badge_content_description = 2131886080;

    private R$plurals() {
    }
}
