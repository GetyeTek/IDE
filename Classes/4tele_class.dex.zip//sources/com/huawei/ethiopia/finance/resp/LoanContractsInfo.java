package com.huawei.ethiopia.finance.resp;

import android.text.TextUtils;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.J;
import com.google.gson.annotations.SerializedName;
import com.huawei.common.display.DisplayItem;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.http.BaseResp;
import java.util.List;
import p5.g;

public class LoanContractsInfo extends BaseResp {
    private boolean allowIntall;
    private boolean allowRollover;
    private List<DisplayItem> contractDetailItems;
    @SerializedName(alternate = {"contractID"}, value = "contractId")
    private String contractId;
    private String currency;
    private String currentInstallment;
    private String disburseAmount = "0.00";
    private boolean installments;
    private boolean isActive;
    @SerializedName("allowNewIntall")
    private boolean isAllowLoadRestructure;
    private String loanBalance = "0.00";
    private String loanDueDate;
    private int order;
    private String outstandingAmount = "0.00";
    private String principal = "0.00";
    private String principalAmount = "0.00";
    @SerializedName(alternate = {"productID"}, value = "productId")
    private String productId;
    private String productName;
    private String productNameI18n;
    private List<AppRepaymentSchedule> repaymentSchedules;
    private String status;
    private String totalInstallments;
    @SerializedName(alternate = {"transactionItems"}, value = "transactionList")
    private List<TransactionInfo> transactionList;

    private int getColor(int i) {
        return ContextCompat.getColor(J.a(), i);
    }

    public List<DisplayItem> getContractDetailItems() {
        return this.contractDetailItems;
    }

    public String getContractId() {
        return this.contractId;
    }

    public String getCurrency() {
        return g.g();
    }

    public String getCurrentInstallment() {
        return this.currentInstallment;
    }

    public String getDisburseAmount() {
        return this.disburseAmount;
    }

    public int getItemOutstandingAmountTextColor() {
        if (isActive()) {
            return getColor(R$color.color_0072bc);
        }
        return getColor(R$color.common_colorBlack);
    }

    public String getLoanBalance() {
        return this.loanBalance;
    }

    public String getLoanDueDate() {
        return this.loanDueDate;
    }

    public int getOrder() {
        return this.order;
    }

    public String getOutstandingAmount() {
        return this.outstandingAmount;
    }

    public String getPayState() {
        if (isActive()) {
            return J.a().getString(R$string.pay);
        }
        return J.a().getString(R$string.paid);
    }

    public int getPayStateBackground() {
        if (isActive()) {
            return getColor(R$color.common_colorPrimary);
        }
        return 17170445;
    }

    public int getPayStateTextColor() {
        if (isActive()) {
            return getColor(R$color.common_colorWhite);
        }
        return getColor(R$color.colorTextLevel4);
    }

    public String getPrincipal() {
        return this.principal;
    }

    public String getPrincipalAmount() {
        return this.principalAmount;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getProductName() {
        return this.productName;
    }

    public String getProductNameI18n() {
        if (TextUtils.isEmpty(this.productNameI18n)) {
            return this.productName;
        }
        return this.productNameI18n;
    }

    public List<AppRepaymentSchedule> getRepaymentSchedules() {
        return this.repaymentSchedules;
    }

    public String getShowStatusStr() {
        if (isActive()) {
            return J.a().getString(R$string.on_time);
        }
        return J.a().getString(R$string.paid);
    }

    public int getStateBackground() {
        if (isActive()) {
            return getColor(R$color.color_0DFF504E);
        }
        return getColor(R$color.color_0D1A73E8);
    }

    public int getStateTextColor() {
        if (isActive()) {
            return getColor(R$color.colorError);
        }
        return getColor(R$color.common_colorPrimary);
    }

    public String getStatus() {
        return this.status;
    }

    public String getTotalCreditAmountTitle() {
        return J.a().getString(R$string.total_credit_amount) + "（" + getCurrency() + "）";
    }

    public String getTotalInstallments() {
        return this.totalInstallments;
    }

    public int getTotalOutstandingAmountTextColor() {
        if (isActive()) {
            return getColor(R$color.common_colorPrimary);
        }
        return getColor(R$color.common_colorBlack);
    }

    public String getTotalOutstandingAmountTitle() {
        return J.a().getString(R$string.total_outstanding_amount) + "（" + getCurrency() + "）";
    }

    public List<TransactionInfo> getTransactionList() {
        return this.transactionList;
    }

    public boolean isActive() {
        return this.isActive;
    }

    public boolean isAllowIntall() {
        return this.allowIntall;
    }

    public boolean isAllowLoadRestructure() {
        return this.isAllowLoadRestructure;
    }

    public boolean isAllowRollover() {
        return this.allowRollover;
    }

    public boolean isInstallments() {
        return this.installments;
    }

    public void setActive(boolean z) {
        this.isActive = z;
    }

    public void setAllowIntall(boolean z) {
        this.allowIntall = z;
    }

    public void setAllowLoadRestructure(boolean z) {
        this.isAllowLoadRestructure = z;
    }

    public void setAllowRollover(boolean z) {
        this.allowRollover = z;
    }

    public void setContractDetailItems(List<DisplayItem> list) {
        this.contractDetailItems = list;
    }

    public void setContractId(String str) {
        this.contractId = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setCurrentInstallment(String str) {
        this.currentInstallment = str;
    }

    public void setDisburseAmount(String str) {
        this.disburseAmount = str;
    }

    public void setInstallments(boolean z) {
        this.installments = z;
    }

    public void setLoanBalance(String str) {
        this.loanBalance = str;
    }

    public void setLoanDueDate(String str) {
        this.loanDueDate = str;
    }

    public void setOrder(int i) {
        this.order = i;
    }

    public void setOutstandingAmount(String str) {
        this.outstandingAmount = str;
    }

    public void setPrincipal(String str) {
        this.principal = str;
    }

    public void setPrincipalAmount(String str) {
        this.principalAmount = str;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setProductName(String str) {
        this.productName = str;
    }

    public void setProductNameI18n(String str) {
        this.productNameI18n = str;
    }

    public void setRepaymentSchedules(List<AppRepaymentSchedule> list) {
        this.repaymentSchedules = list;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setTotalInstallments(String str) {
        this.totalInstallments = str;
    }

    public void setTransactionList(List<TransactionInfo> list) {
        this.transactionList = list;
    }
}
