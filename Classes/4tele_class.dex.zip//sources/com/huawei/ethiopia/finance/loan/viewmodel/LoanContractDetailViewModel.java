package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.loan.repository.PreNewNplValidationRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryContractDetailRepository;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.ethiopia.finance.resp.PreNewNplValidationResp;
import com.huawei.ethiopia.finance.resp.ProductDetailInfo;
import com.huawei.http.b;

public class LoanContractDetailViewModel extends ViewModel {
    public final MutableLiveData<c<LoanContractsInfo>> a = new MutableLiveData<>();
    public final MutableLiveData<c<ProductDetailInfo>> b = new MutableLiveData<>();
    public final MutableLiveData<c<PreNewNplValidationResp>> c = new MutableLiveData<>();
    public QueryContractDetailRepository d;
    public PreNewNplValidationRepository e;

    public class a implements R1.a<LoanContractsInfo> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            LoanContractDetailViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            LoanContractDetailViewModel.this.a.setValue(c.e((LoanContractsInfo) obj));
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.http.b, com.huawei.ethiopia.finance.loan.repository.QueryContractDetailRepository] */
    public final void a(String str) {
        this.a.setValue(c.c());
        ? bVar = new b();
        bVar.addParams("contractId", str);
        this.d = bVar;
        bVar.sendRequest(new a());
    }

    public final void onCleared() {
        LoanContractDetailViewModel.super.onCleared();
        QueryContractDetailRepository queryContractDetailRepository = this.d;
        if (queryContractDetailRepository != null) {
            queryContractDetailRepository.cancel();
        }
        PreNewNplValidationRepository preNewNplValidationRepository = this.e;
        if (preNewNplValidationRepository != null) {
            preNewNplValidationRepository.cancel();
        }
    }
}
