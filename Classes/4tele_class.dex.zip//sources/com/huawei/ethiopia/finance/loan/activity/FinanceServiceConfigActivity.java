package com.huawei.ethiopia.finance.loan.activity;

import V7.e;
import W1.b;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceConfigBinding;
import com.huawei.ethiopia.finance.loan.adapter.SimpleFragmentStateAdapter;
import com.huawei.ethiopia.finance.loan.fragment.FinanceServiceFragment;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceServiceViewModel;
import com.huawei.ethiopia.finance.resp.FinanceMenuListResp;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.List;
import p5.i;

@Route(path = "/finance/finance")
public class FinanceServiceConfigActivity extends DataBindingActivity<FinanceActivityFinanceServiceConfigBinding, FinanceServiceViewModel> implements d {
    public static final /* synthetic */ int h = 0;
    @Autowired
    String bankCode;
    @Autowired
    String bankIcon;
    @Autowired
    String bankName;
    public FinanceMenuListResp d;
    public SimpleFragmentStateAdapter e;
    public FinanceServiceFragment f;
    public b.b g;
    @Autowired
    String selectOverDraft;

    public final int C0() {
        return R$layout.finance_activity_finance_service_config;
    }

    public final void E0(int i) {
        int i2;
        this.b.e.setCurrentItem(i);
        RoundTextView roundTextView = this.b.a;
        if (i == 0) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        roundTextView.setVisibility(i2);
    }

    public final String i() {
        FinanceMenuListResp financeMenuListResp = this.d;
        if (financeMenuListResp == null || financeMenuListResp.getFinanceServiceUIConfig() == null || TextUtils.isEmpty(this.d.getFinanceServiceUIConfig().getIcon())) {
            return "";
        }
        return this.d.getFinanceServiceUIConfig().getIcon();
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        FinanceServiceConfigActivity.super.onActivityResult(i, i2, intent);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments != null && !fragments.isEmpty()) {
            for (Fragment onActivityResult : fragments) {
                onActivityResult.onActivityResult(i, i2, intent);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r2v3, types: [W4.a, java.lang.Object] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceServiceConfigActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.financial_service), R.layout.common_toolbar);
        b.b c = b.a(new Object()).c(this.b.e);
        c.b = new n(this);
        this.g = c;
        FinanceServiceViewModel financeServiceViewModel = new ViewModelProvider(this).get(FinanceServiceViewModel.class);
        this.c = financeServiceViewModel;
        financeServiceViewModel.b.observe(this, new m(this));
        this.c.a(this.bankCode);
    }

    public final void onDestroy() {
        FinanceServiceConfigActivity.super.onDestroy();
        i.e.d = 0;
    }

    public final void onNewIntent(Intent intent) {
        FinanceServiceFragment financeServiceFragment;
        FinanceServiceConfigActivity.super.onNewIntent(intent);
        if (this.e != null && (financeServiceFragment = this.f) != null) {
            financeServiceFragment.z0();
        }
    }
}
