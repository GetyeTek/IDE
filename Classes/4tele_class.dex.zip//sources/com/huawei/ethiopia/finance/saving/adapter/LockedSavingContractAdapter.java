package com.huawei.ethiopia.finance.saving.adapter;

import androidx.databinding.ViewDataBinding;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingContractBinding;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.payment.mvvm.DataBindingAdapter;

public class LockedSavingContractAdapter extends DataBindingAdapter<FinanceProductInfo, FinanceItemLockedSavingContractBinding> {
    public final int a() {
        return R$layout.finance_item_locked_saving_contract;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        FinanceItemLockedSavingContractBinding financeItemLockedSavingContractBinding = (FinanceItemLockedSavingContractBinding) viewDataBinding;
        FinanceProductInfo financeProductInfo = (FinanceProductInfo) obj;
        financeItemLockedSavingContractBinding.c.setText(financeProductInfo.getPrincipalAmount());
        financeItemLockedSavingContractBinding.d.setText(financeProductInfo.getTotalCapitalizationAmount());
        financeItemLockedSavingContractBinding.b.setText(financeProductInfo.getMaturityDate());
    }
}
