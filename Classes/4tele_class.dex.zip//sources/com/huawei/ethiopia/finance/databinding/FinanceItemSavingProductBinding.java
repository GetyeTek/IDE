package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;

public abstract class FinanceItemSavingProductBinding extends ViewDataBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;

    public FinanceItemSavingProductBinding(DataBindingComponent dataBindingComponent, View view, RoundConstraintLayout roundConstraintLayout, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = roundConstraintLayout;
        this.b = textView;
        this.c = textView2;
    }
}
