package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.DisplayView;

public abstract class FinanceItemResultDisplayBinding extends ViewDataBinding {
    @NonNull
    public final DisplayView a;

    public FinanceItemResultDisplayBinding(DataBindingComponent dataBindingComponent, View view, DisplayView displayView) {
        super(dataBindingComponent, view, 0);
        this.a = displayView;
    }
}
