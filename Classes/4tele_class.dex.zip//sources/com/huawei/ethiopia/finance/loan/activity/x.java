package com.huawei.ethiopia.finance.loan.activity;

import R1.b;
import android.view.View;

public final class x extends b {
    public final /* synthetic */ ManualRolloverActivity b;

    public x(ManualRolloverActivity manualRolloverActivity) {
        this.b = manualRolloverActivity;
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.ethiopia.finance.loan.activity.ManualRolloverActivity, android.app.Activity] */
    public final void a(View view) {
        this.b.finish();
    }
}
