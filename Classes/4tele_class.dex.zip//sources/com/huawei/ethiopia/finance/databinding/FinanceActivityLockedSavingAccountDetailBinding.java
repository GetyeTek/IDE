package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceActivityLockedSavingAccountDetailBinding extends ViewDataBinding {
    @NonNull
    public final FinanceItemMyFixedTimeSavingDetailBinding a;
    @NonNull
    public final HFRecyclerView b;
    @NonNull
    public final RoundLinearLayout c;
    @NonNull
    public final RoundTextView d;
    @NonNull
    public final RoundTextView e;

    public FinanceActivityLockedSavingAccountDetailBinding(DataBindingComponent dataBindingComponent, View view, FinanceItemMyFixedTimeSavingDetailBinding financeItemMyFixedTimeSavingDetailBinding, HFRecyclerView hFRecyclerView, RoundLinearLayout roundLinearLayout, RoundTextView roundTextView, RoundTextView roundTextView2) {
        super(dataBindingComponent, view, 1);
        this.a = financeItemMyFixedTimeSavingDetailBinding;
        this.b = hFRecyclerView;
        this.c = roundLinearLayout;
        this.d = roundTextView;
        this.e = roundTextView2;
    }
}
