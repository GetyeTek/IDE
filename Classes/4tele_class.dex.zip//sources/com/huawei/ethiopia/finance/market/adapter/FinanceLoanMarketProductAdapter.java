package com.huawei.ethiopia.finance.market.adapter;

import S3.c;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import com.blankj.utilcode.util.t;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.digitalpayment.paybill.activity.i;
import com.huawei.ethiopia.finance.market.f;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import java.util.ArrayList;

public class FinanceLoanMarketProductAdapter extends BaseQuickAdapter<ProductInfo, BaseViewHolder> {
    public static final /* synthetic */ int h = 0;
    public f a;
    public c b;
    public int c;
    public String d;
    public final int e;
    public final int f;
    public i g;

    public FinanceLoanMarketProductAdapter(int i, @Nullable ArrayList arrayList) {
        super(i, arrayList);
        int b2 = t.b();
        this.e = b2;
        this.f = b2 / 4;
    }

    /* JADX WARNING: Removed duplicated region for block: B:51:0x01aa  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void convert(@androidx.annotation.NonNull com.chad.library.adapter.base.viewholder.BaseViewHolder r19, java.lang.Object r20) {
        /*
            r18 = this;
            r0 = r18
            r1 = 2
            r2 = 1
            r3 = 0
            r4 = r20
            com.huawei.ethiopia.finance.resp.ProductInfo r4 = (com.huawei.ethiopia.finance.resp.ProductInfo) r4
            java.lang.String r5 = ""
            r6 = r19
            android.view.View r6 = r6.itemView
            androidx.databinding.ViewDataBinding r6 = androidx.databinding.DataBindingUtil.bind(r6)
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanMarketProductBinding r6 = (com.huawei.ethiopia.finance.databinding.FinanceItemLoanMarketProductBinding) r6
            if (r6 != 0) goto L_0x0019
            goto L_0x02ba
        L_0x0019:
            androidx.recyclerview.widget.LinearLayoutManager r7 = new androidx.recyclerview.widget.LinearLayoutManager
            android.view.View r8 = r6.getRoot()
            android.content.Context r8 = r8.getContext()
            r7.<init>(r8)
            com.huawei.common.widget.round.RoundRecyclerView r8 = r6.g
            r8.setLayoutManager(r7)
            java.util.List r7 = r4.getLoanContractsInfos()
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            if (r7 == 0) goto L_0x0066
            java.util.Iterator r7 = r7.iterator()
        L_0x003a:
            boolean r10 = r7.hasNext()
            if (r10 == 0) goto L_0x0061
            java.lang.Object r10 = r7.next()
            com.huawei.ethiopia.finance.resp.LoanContractsInfo r10 = (com.huawei.ethiopia.finance.resp.LoanContractsInfo) r10
            boolean r11 = r10.isInstallments()
            if (r11 == 0) goto L_0x005d
            java.util.List r11 = r10.getRepaymentSchedules()
            if (r11 == 0) goto L_0x003a
            java.util.List r11 = r10.getRepaymentSchedules()
            boolean r11 = r11.isEmpty()
            if (r11 == 0) goto L_0x005d
            goto L_0x003a
        L_0x005d:
            r9.add(r10)
            goto L_0x003a
        L_0x0061:
            int r7 = r9.size()
            goto L_0x0067
        L_0x0066:
            r7 = 0
        L_0x0067:
            com.huawei.ethiopia.finance.loan.adapter.FinanceLoanContractsAdapter r10 = new com.huawei.ethiopia.finance.loan.adapter.FinanceLoanContractsAdapter
            r10.<init>(r9)
            b5.a r9 = new b5.a
            r9.<init>(r0, r10)
            r10.setOnItemChildClickListener(r9)
            java.lang.String r9 = r0.d
            boolean r9 = android.text.TextUtils.isEmpty(r9)
            if (r9 != 0) goto L_0x008b
            com.huawei.common.widget.round.RoundLinearLayout r9 = r6.h
            d2.a r9 = r9.getBaseFilletView()
            java.lang.String r11 = r0.d
            int r11 = android.graphics.Color.parseColor(r11)
            r9.e(r11)
        L_0x008b:
            r8.setAdapter(r10)
            android.widget.TextView r9 = r6.s
            java.lang.String r10 = r4.getProductNameI18n()
            r9.setText(r10)
            java.lang.String r9 = r4.getLogo()
            r10 = -1
            android.widget.ImageView r11 = r6.d
            O9.c.c(r11, r9, r10)
            android.app.Application r9 = com.blankj.utilcode.util.J.a()
            int r10 = com.huawei.ethiopia.finance.R$string.credit_limit_s_to_s
            java.lang.String r9 = r9.getString(r10)
            java.lang.String r10 = r4.getMinLimit()     // Catch:{ Exception -> 0x00d8 }
            java.lang.String r11 = "\\."
            if (r10 == 0) goto L_0x00bd
            java.lang.String[] r10 = r10.split(r11)     // Catch:{ Exception -> 0x00d8 }
            r10 = r10[r3]     // Catch:{ Exception -> 0x00d8 }
            java.lang.String r10 = W2.c.a(r10)     // Catch:{ Exception -> 0x00d8 }
        L_0x00bd:
            java.lang.String r12 = r4.getMaxLimit()     // Catch:{ Exception -> 0x00d8 }
            if (r12 == 0) goto L_0x00cd
            java.lang.String[] r11 = r12.split(r11)     // Catch:{ Exception -> 0x00d8 }
            r11 = r11[r3]     // Catch:{ Exception -> 0x00d8 }
            java.lang.String r12 = W2.c.a(r11)     // Catch:{ Exception -> 0x00d8 }
        L_0x00cd:
            java.lang.Object[] r11 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x00d8 }
            r11[r3] = r10     // Catch:{ Exception -> 0x00d8 }
            r11[r2] = r12     // Catch:{ Exception -> 0x00d8 }
            java.lang.String r9 = java.lang.String.format(r9, r11)     // Catch:{ Exception -> 0x00d8 }
            goto L_0x00dc
        L_0x00d8:
            V1.h.b()
            r9 = r5
        L_0x00dc:
            android.widget.TextView r10 = r6.k
            r10.setText(r9)
            r9 = 1112539136(0x42500000, float:52.0)
            int r9 = com.blankj.utilcode.util.v.a(r9)
            int r10 = r0.e
            int r9 = r10 - r9
            int r11 = r9 / 3
            com.huawei.common.widget.round.RoundConstraintLayout r12 = r6.c
            android.view.ViewGroup$LayoutParams r13 = r12.getLayoutParams()
            r13.width = r9
            android.widget.TextView r9 = r6.l
            r9.setWidth(r11)
            android.widget.TextView r13 = r6.t
            r13.setWidth(r11)
            android.widget.TextView r14 = r6.p
            r14.setWidth(r11)
            com.huawei.ethiopia.finance.resp.ProductDetailInfo r11 = r4.getProductDetailInfo()
            android.widget.TextView r15 = r6.j
            android.widget.TextView r1 = r6.i
            android.widget.TextView r2 = r6.o
            android.widget.TextView r3 = r6.n
            r20 = r5
            android.widget.TextView r5 = r6.u
            r19 = r7
            android.widget.TextView r7 = r6.q
            r16 = r8
            android.widget.TextView r8 = r6.m
            r17 = r6
            if (r11 == 0) goto L_0x020d
            java.lang.String r6 = r11.getFacilitationFeeShowValue()
            r8.setText(r6)
            java.lang.String r6 = r11.getAvailableLimit()
            r7.setText(r6)
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = r11.getPenaltyFeeShowValue()
            r6.append(r7)
            java.lang.String r7 = " "
            r6.append(r7)
            android.app.Application r7 = com.blankj.utilcode.util.J.a()
            int r8 = com.huawei.ethiopia.finance.R$string.daily_s
            java.lang.String r7 = r7.getString(r8)
            r6.append(r7)
            java.lang.String r6 = r6.toString()
            r5.setText(r6)
            java.lang.String r5 = r11.getMaintenanceFee()
            boolean r5 = android.text.TextUtils.isEmpty(r5)
            if (r5 != 0) goto L_0x01b1
            r5 = 0
            r2.setVisibility(r5)
            r3.setVisibility(r5)
            java.lang.String r5 = r11.getMaintenanceFee()
            java.lang.String r6 = "0%"
            boolean r6 = android.text.TextUtils.equals(r6, r5)
            if (r6 != 0) goto L_0x0171
            goto L_0x01ac
        L_0x0171:
            com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig r5 = p5.g.h()
            if (r5 != 0) goto L_0x017a
        L_0x0177:
            r5 = r20
            goto L_0x01a3
        L_0x017a:
            java.util.List r5 = r5.getFinanceMarketBankItems()
            if (r5 != 0) goto L_0x0181
            goto L_0x0177
        L_0x0181:
            java.util.Iterator r5 = r5.iterator()
        L_0x0185:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x0177
            java.lang.Object r6 = r5.next()
            com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig$FinanceMarketBankItem r6 = (com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig.FinanceMarketBankItem) r6
            java.lang.String r7 = r6.getCompanyName()
            java.lang.String r8 = r4.getCompanyName()
            boolean r7 = android.text.TextUtils.equals(r7, r8)
            if (r7 == 0) goto L_0x0185
            java.lang.String r5 = r6.getMaintenanceFee()
        L_0x01a3:
            boolean r6 = android.text.TextUtils.isEmpty(r5)
            if (r6 != 0) goto L_0x01aa
            goto L_0x01ac
        L_0x01aa:
            java.lang.String r5 = "0.3-1.2%"
        L_0x01ac:
            r2.setText(r5)
            r2 = 1
            goto L_0x01be
        L_0x01b1:
            r5 = 8
            r2.setVisibility(r5)
            r3.setVisibility(r5)
            r5 = 0
            r2.setText(r5)
            r2 = 0
        L_0x01be:
            java.lang.String r5 = r11.getAdvancedRepaymentFee()
            boolean r5 = android.text.TextUtils.isEmpty(r5)
            if (r5 != 0) goto L_0x01d9
            r5 = 0
            r1.setVisibility(r5)
            r15.setVisibility(r5)
            java.lang.String r5 = r11.getAdvancedRepaymentFee()
            r15.setText(r5)
            r5 = 1
            int r2 = r2 + r5
            goto L_0x01e6
        L_0x01d9:
            r5 = 1
            r6 = 8
            r1.setVisibility(r6)
            r15.setVisibility(r6)
            r6 = 0
            r15.setText(r6)
        L_0x01e6:
            if (r2 <= 0) goto L_0x022b
            if (r2 != r5) goto L_0x01f1
            android.view.ViewGroup$LayoutParams r2 = r12.getLayoutParams()
            r2.width = r10
            goto L_0x01fb
        L_0x01f1:
            android.view.ViewGroup$LayoutParams r2 = r12.getLayoutParams()
            int r10 = r10 * 5
            int r10 = r10 / 4
            r2.width = r10
        L_0x01fb:
            int r2 = r0.f
            r9.setWidth(r2)
            r3.setWidth(r2)
            r13.setWidth(r2)
            r14.setWidth(r2)
            r1.setWidth(r2)
            goto L_0x022b
        L_0x020d:
            r6 = 0
            r8.setText(r6)
            r2.setText(r6)
            r5.setText(r6)
            r7.setText(r6)
            r15.setText(r6)
            r5 = 8
            r2.setVisibility(r5)
            r3.setVisibility(r5)
            r1.setVisibility(r5)
            r15.setVisibility(r5)
        L_0x022b:
            boolean r1 = r4.isShow()
            r2 = 1115160576(0x42780000, float:62.0)
            r6 = r17
            android.widget.ImageView r3 = r6.e
            android.widget.TextView r5 = r6.r
            android.widget.HorizontalScrollView r7 = r6.b
            if (r1 == 0) goto L_0x0274
            android.app.Application r1 = com.blankj.utilcode.util.J.a()
            int r8 = com.huawei.ethiopia.finance.R$string.less
            java.lang.String r1 = r1.getString(r8)
            r5.setText(r1)
            r1 = 1127481344(0x43340000, float:180.0)
            r3.setRotation(r1)
            android.view.ViewGroup$LayoutParams r1 = r7.getLayoutParams()
            int r3 = r0.c
            r5 = 1118699520(0x42ae0000, float:87.0)
            int r5 = com.blankj.utilcode.util.v.a(r5)
            int r3 = java.lang.Math.max(r3, r5)
            r1.height = r3
            r7.requestLayout()
            android.view.ViewGroup$LayoutParams r1 = r16.getLayoutParams()
            int r2 = com.blankj.utilcode.util.v.a(r2)
            int r2 = r2 * r19
            r1.height = r2
            r16.requestLayout()
            r3 = r19
            goto L_0x02a5
        L_0x0274:
            android.app.Application r1 = com.blankj.utilcode.util.J.a()
            int r8 = com.huawei.ethiopia.finance.R$string.more
            java.lang.String r1 = r1.getString(r8)
            r5.setText(r1)
            r1 = 0
            r3.setRotation(r1)
            android.view.ViewGroup$LayoutParams r1 = r7.getLayoutParams()
            r3 = 1
            r1.height = r3
            r7.requestLayout()
            android.view.ViewGroup$LayoutParams r1 = r16.getLayoutParams()
            r3 = r19
            r5 = 2
            int r5 = java.lang.Math.min(r5, r3)
            int r2 = com.blankj.utilcode.util.v.a(r2)
            int r2 = r2 * r5
            r1.height = r2
            r16.requestLayout()
        L_0x02a5:
            b5.b r1 = new b5.b
            r1.<init>(r0, r4, r3, r6)
            android.widget.LinearLayout r2 = r6.f
            r2.setOnClickListener(r1)
            b5.c r1 = new b5.c
            r2 = 0
            r1.<init>(r0, r4, r2)
            com.huawei.common.widget.round.RoundTextView r2 = r6.a
            r2.setOnClickListener(r1)
        L_0x02ba:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.market.adapter.FinanceLoanMarketProductAdapter.convert(com.chad.library.adapter.base.viewholder.BaseViewHolder, java.lang.Object):void");
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return FinanceLoanMarketProductAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
