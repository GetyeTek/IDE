package com.huawei.ethiopia.finance.resp;

import androidx.camera.camera2.internal.c;
import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.math.BigDecimal;

public class ProductDetailInfo extends BaseResp {
    private RateInfo advancedRepaymentFee;
    private String allowRepayInAdvance;
    private String availableLimit;
    private String currency;
    private RateInfo facilitationFee;
    private RateInfo maintenanceFee;
    private String maxLimit;
    private RateInfo penaltyFee;

    public static class RateInfo implements Serializable {
        private String rateMode;
        private String rateValue;

        public String getRateMode() {
            return this.rateMode;
        }

        public String getRateValue() {
            return this.rateValue;
        }

        public String getShowValue(String str) {
            if ("P".equals(this.rateMode) && !this.rateValue.contains("%")) {
                str = "%";
            } else if (!"T".equals(this.rateMode)) {
                str = "";
            }
            return c.a(new StringBuilder(), this.rateValue, str);
        }

        public String getYearShowValue(String str) {
            if ("P".equals(this.rateMode)) {
                str = "%";
            } else if (!"T".equals(this.rateMode)) {
                str = "";
            }
            double doubleValue = new BigDecimal(Double.parseDouble(this.rateValue)).divide(new BigDecimal(365)).setScale(2, 4).doubleValue();
            return String.valueOf(doubleValue) + str;
        }

        public void setRateMode(String str) {
            this.rateMode = str;
        }

        public void setRateValue(String str) {
            this.rateValue = str;
        }
    }

    private String getRateValue(RateInfo rateInfo) {
        if (rateInfo == null) {
            return "";
        }
        return rateInfo.getShowValue(this.currency);
    }

    private String getYearRateValue(RateInfo rateInfo) {
        if (rateInfo == null) {
            return "";
        }
        return rateInfo.getYearShowValue(this.currency);
    }

    public String getAdvancedRepaymentFee() {
        return getRateValue(this.advancedRepaymentFee);
    }

    public String getAllowRepayInAdvance() {
        return this.allowRepayInAdvance;
    }

    public String getAvailableLimit() {
        double d;
        double d2 = 0.0d;
        try {
            d = Double.parseDouble(this.availableLimit.replaceAll(",", ""));
        } catch (Exception unused) {
            d = 0.0d;
        }
        try {
            d2 = Double.parseDouble(this.maxLimit.replaceAll(",", ""));
        } catch (Exception unused2) {
        }
        if (d > d2) {
            return this.maxLimit;
        }
        return this.availableLimit;
    }

    public String getCurrency() {
        return this.currency;
    }

    public RateInfo getFacilitationFee() {
        return this.facilitationFee;
    }

    public String getFacilitationFeeShowValue() {
        return getRateValue(this.facilitationFee);
    }

    public String getMaintenanceFee() {
        return getRateValue(this.maintenanceFee);
    }

    public String getMaxLimit() {
        return this.maxLimit;
    }

    public RateInfo getPenaltyFee() {
        return this.penaltyFee;
    }

    public String getPenaltyFeeShowValue() {
        return getRateValue(this.penaltyFee);
    }

    public void setAdvancedRepaymentFee(RateInfo rateInfo) {
        this.advancedRepaymentFee = rateInfo;
    }

    public void setAllowRepayInAdvance(String str) {
        this.allowRepayInAdvance = str;
    }

    public void setAvailableLimit(String str) {
        this.availableLimit = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setFacilitationFee(RateInfo rateInfo) {
        this.facilitationFee = rateInfo;
    }

    public void setMaintenanceFee(RateInfo rateInfo) {
        this.maintenanceFee = rateInfo;
    }

    public void setMaxLimit(String str) {
        this.maxLimit = str;
    }

    public void setPenaltyFee(RateInfo rateInfo) {
        this.penaltyFee = rateInfo;
    }
}
