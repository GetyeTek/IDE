package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.FinanceLoanResp;
import com.huawei.http.b;

public class QueryLoanProductRepository extends b<FinanceLoanResp, FinanceLoanResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/queryProducts";
    }
}
