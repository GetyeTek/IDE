package com.huawei.ethiopia.finance.market;

import F0.o;
import android.view.View;
import android.widget.TextView;
import com.blankj.utilcode.util.s;

public final /* synthetic */ class j implements View.OnClickListener {
    public final /* synthetic */ LoanProductsMarketActivity a;
    public final /* synthetic */ String b;
    public final /* synthetic */ String c;
    public final /* synthetic */ TextView d;
    public final /* synthetic */ TextView e;

    public /* synthetic */ j(LoanProductsMarketActivity loanProductsMarketActivity, String str, String str2, TextView textView, TextView textView2) {
        this.a = loanProductsMarketActivity;
        this.b = str;
        this.c = str2;
        this.d = textView;
        this.e = textView2;
    }

    public final void onClick(View view) {
        int i = LoanProductsMarketActivity.v;
        String str = this.b;
        LoanProductsMarketActivity loanProductsMarketActivity = this.a;
        boolean H0 = loanProductsMarketActivity.H0(str);
        s.a("finance_sp_name_no_cache").a.edit().putBoolean(o.a(new StringBuilder(), loanProductsMarketActivity.n, "_hideBalance_", str), !H0).apply();
        loanProductsMarketActivity.M0(str, this.c, this.d, this.e);
    }
}
