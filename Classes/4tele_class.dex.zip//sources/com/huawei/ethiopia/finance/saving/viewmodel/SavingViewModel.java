package com.huawei.ethiopia.finance.saving.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import com.huawei.ethiopia.finance.saving.repository.DeactivateSavingProductRepository;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingAccountRepository;
import com.huawei.http.BaseResp;
import com.huawei.http.b;
import java.util.List;
import p5.g;

public class SavingViewModel extends ViewModel {
    public final MutableLiveData<c<List<SavingActivatableProduct>>> a = new MutableLiveData<>();
    public final MutableLiveData<c<List<FinanceProductInfo>>> b = new MutableLiveData<>();
    public final MutableLiveData<c<List<FinanceProductInfo>>> c = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> d = new MutableLiveData<>();
    public QuerySavingAccountRepository e;
    public DeactivateSavingProductRepository f;

    public class a implements R1.a<BaseResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            SavingViewModel.this.d.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            BaseResp baseResp = (BaseResp) obj;
            SavingViewModel.this.d.setValue(c.e((Object) null));
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.http.b, com.huawei.ethiopia.finance.saving.repository.DeactivateSavingProductRepository] */
    public final void a(String str, String str2) {
        this.d.setValue(c.c());
        ? bVar = new b();
        bVar.addParams("initiatorMsisdn", g.k());
        bVar.addParams("initiatorPin", g.a(str));
        bVar.addParams("pinVersion", g.l());
        bVar.addParams("fundsLenderId", str2);
        this.f = bVar;
        bVar.sendRequest(new a());
    }

    public final void onCleared() {
        SavingViewModel.super.onCleared();
        QuerySavingAccountRepository querySavingAccountRepository = this.e;
        if (querySavingAccountRepository != null) {
            querySavingAccountRepository.cancel();
        }
        DeactivateSavingProductRepository deactivateSavingProductRepository = this.f;
        if (deactivateSavingProductRepository != null) {
            deactivateSavingProductRepository.cancel();
        }
    }
}
