package com.huawei.ethiopia.finance.loan.activity;

import V1.k;
import V7.c;
import V7.f;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.loan.adapter.LoanValidationAdapter;
import com.huawei.ethiopia.finance.resp.LoanTrialResp;
import java.util.List;

public final /* synthetic */ class b implements Observer {
    public final /* synthetic */ ApplyLoanProductActivity a;

    public /* synthetic */ b(ApplyLoanProductActivity applyLoanProductActivity) {
        this.a = applyLoanProductActivity;
    }

    public final void onChanged(Object obj) {
        c cVar = (c) obj;
        int i = ApplyLoanProductActivity.o;
        FragmentActivity fragmentActivity = this.a;
        f.b(fragmentActivity, cVar);
        if (cVar.b()) {
            BaseException baseException = cVar.b;
            if ("ERR3027".equals(baseException.getResponseCode())) {
                k.b(1, String.format(fragmentActivity.getString(R$string.apply_amount_is_below_s_limit), new Object[]{fragmentActivity.d.getMinLimit()}));
                LoanValidationAdapter loanValidationAdapter = fragmentActivity.h;
                loanValidationAdapter.b.clear();
                loanValidationAdapter.setNewData((List) null);
            } else if ("60500144".equals(baseException.getResponseCode())) {
                fragmentActivity.E0(baseException.getResponseDesc());
            } else {
                f.c(cVar);
            }
            fragmentActivity.b.d.setVisibility(8);
            fragmentActivity.b.c.setVisibility(8);
        } else if (cVar.f()) {
            LoanTrialResp loanTrialResp = (LoanTrialResp) cVar.c;
            if (!loanTrialResp.isHasBindNationalId()) {
                fragmentActivity.E0(loanTrialResp.getPrompting());
            }
            fragmentActivity.g = fragmentActivity.f;
            fragmentActivity.b.d.setVisibility(0);
            fragmentActivity.b.c.setVisibility(0);
            fragmentActivity.h.e(loanTrialResp);
        }
    }
}
