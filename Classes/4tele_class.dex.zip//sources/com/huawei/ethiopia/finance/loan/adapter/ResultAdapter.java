package com.huawei.ethiopia.finance.loan.adapter;

import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.DisplayView;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;

public class ResultAdapter extends BaseQuickAdapter<DisplayItem, BaseViewHolder> {
    public ResultAdapter() {
        super(R$layout.finance_item_pre_apply_result);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        DisplayItem displayItem = (DisplayItem) obj;
        DisplayView view = baseViewHolder.getView(R$id.display_view);
        view.getTvTitle().setMaxLines(2);
        view.setTitle(displayItem.getTitle());
        view.setContent(displayItem.getContent());
    }
}
