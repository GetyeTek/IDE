package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceActivityDepositWithDrawBindingImpl extends FinanceActivityDepositWithDrawBinding {
    @Nullable
    public static final SparseIntArray g;
    public long f;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.tv_title, 1);
        sparseIntArray.put(R$id.cl_input, 2);
        sparseIntArray.put(R$id.et_input, 3);
        sparseIntArray.put(R$id.tv_unit, 4);
        sparseIntArray.put(R$id.tv_error, 5);
        sparseIntArray.put(R$id.tv_amount, 6);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.f = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.f != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.f = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
