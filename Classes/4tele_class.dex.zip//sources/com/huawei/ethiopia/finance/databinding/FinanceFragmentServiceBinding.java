package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.common.widget.round.RoundImageView;

public abstract class FinanceFragmentServiceBinding extends ViewDataBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final ConstraintLayout b;
    @NonNull
    public final ConstraintLayout c;
    @NonNull
    public final RoundImageView d;
    @NonNull
    public final RoundImageView e;
    @NonNull
    public final RoundImageView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;
    @NonNull
    public final TextView l;
    @NonNull
    public final TextView m;
    @NonNull
    public final TextView n;
    @NonNull
    public final TextView o;
    @NonNull
    public final ViewPager2 p;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FinanceFragmentServiceBinding(DataBindingComponent dataBindingComponent, View view, ConstraintLayout constraintLayout, ConstraintLayout constraintLayout2, ConstraintLayout constraintLayout3, RoundImageView roundImageView, RoundImageView roundImageView2, RoundImageView roundImageView3, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 0);
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        this.a = constraintLayout;
        this.b = constraintLayout2;
        this.c = constraintLayout3;
        this.d = roundImageView;
        this.e = roundImageView2;
        this.f = roundImageView3;
        this.g = textView;
        this.h = textView2;
        this.i = textView3;
        this.j = textView4;
        this.k = textView5;
        this.l = textView6;
        this.m = textView7;
        this.n = textView8;
        this.o = textView9;
        this.p = viewPager2;
    }
}
