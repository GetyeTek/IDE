package com.huawei.ethiopia.finance.saving.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.resp.SavingTransactionResult;
import com.huawei.ethiopia.finance.saving.repository.DepositWithDrawRepository;

public class DepositWithDrawViewModel extends ViewModel {
    public final MutableLiveData<c<SavingTransactionResult>> a = new MutableLiveData<>();
    public DepositWithDrawRepository b;

    public final void onCleared() {
        DepositWithDrawViewModel.super.onCleared();
        DepositWithDrawRepository depositWithDrawRepository = this.b;
        if (depositWithDrawRepository != null) {
            depositWithDrawRepository.cancel();
        }
    }
}
