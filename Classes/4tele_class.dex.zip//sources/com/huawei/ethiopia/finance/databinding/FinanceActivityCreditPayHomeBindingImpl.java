package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LifecycleOwner;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;

public class FinanceActivityCreditPayHomeBindingImpl extends FinanceActivityCreditPayHomeBinding {
    @Nullable
    public static final ViewDataBinding.IncludedLayouts m;
    @Nullable
    public static final SparseIntArray n;
    public long l;

    static {
        ViewDataBinding.IncludedLayouts includedLayouts = new ViewDataBinding.IncludedLayouts(12);
        m = includedLayouts;
        includedLayouts.setIncludes(0, new String[]{"finance_no_relevant_data", "finance_fragment_loan_home_unactive"}, new int[]{1, 2}, new int[]{R$layout.finance_no_relevant_data, R$layout.finance_fragment_loan_home_unactive});
        SparseIntArray sparseIntArray = new SparseIntArray();
        n = sparseIntArray;
        sparseIntArray.put(R$id.llTab, 3);
        sparseIntArray.put(R$id.ll_active, 4);
        sparseIntArray.put(R$id.tv_active, 5);
        sparseIntArray.put(R$id.activeRTV, 6);
        sparseIntArray.put(R$id.ll_closed, 7);
        sparseIntArray.put(R$id.tv_closed, 8);
        sparseIntArray.put(R$id.closedRTV, 9);
        sparseIntArray.put(R$id.viewPager, 10);
        sparseIntArray.put(R$id.flLoading, 11);
    }

    public final boolean a(int i) {
        if (i != 0) {
            return false;
        }
        synchronized (this) {
            this.l |= 1;
        }
        return true;
    }

    public final void executeBindings() {
        synchronized (this) {
            this.l = 0;
        }
        ViewDataBinding.executeBindingsOn(this.h);
        ViewDataBinding.executeBindingsOn(this.g);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0015, code lost:
        if (r6.h.hasPendingBindings() == false) goto L_0x0018;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0017, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001e, code lost:
        if (r6.g.hasPendingBindings() == false) goto L_0x0021;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0020, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0021, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean hasPendingBindings() {
        /*
            r6 = this;
            monitor-enter(r6)
            long r0 = r6.l     // Catch:{ all -> 0x000c }
            r2 = 0
            r4 = 1
            int r5 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r5 == 0) goto L_0x000e
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            return r4
        L_0x000c:
            r0 = move-exception
            goto L_0x0023
        L_0x000e:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            com.huawei.ethiopia.finance.databinding.FinanceNoRelevantDataBinding r0 = r6.h
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0018
            return r4
        L_0x0018:
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r0 = r6.g
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0021
            return r4
        L_0x0021:
            r0 = 0
            return r0
        L_0x0023:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.FinanceActivityCreditPayHomeBindingImpl.hasPendingBindings():boolean");
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.l = 4;
        }
        this.h.invalidateAll();
        this.g.invalidateAll();
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        if (i == 0) {
            FinanceNoRelevantDataBinding financeNoRelevantDataBinding = (FinanceNoRelevantDataBinding) obj;
            return a(i2);
        } else if (i != 1) {
            return false;
        } else {
            FinanceFragmentLoanHomeUnactiveBinding financeFragmentLoanHomeUnactiveBinding = (FinanceFragmentLoanHomeUnactiveBinding) obj;
            if (i2 != 0) {
                return false;
            }
            synchronized (this) {
                this.l |= 2;
            }
            return true;
        }
    }

    public final void setLifecycleOwner(@Nullable LifecycleOwner lifecycleOwner) {
        FinanceActivityCreditPayHomeBindingImpl.super.setLifecycleOwner(lifecycleOwner);
        this.h.setLifecycleOwner(lifecycleOwner);
        this.g.setLifecycleOwner(lifecycleOwner);
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
