package com.huawei.ethiopia.finance.loan.adapter;

import G5.a;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.DisplayView;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.resp.FinanceDisplayItem;
import com.huawei.ethiopia.finance.resp.LoanTrialResp;
import com.huawei.ethiopia.finance.resp.RepaymentSchedule;
import com.huawei.ethiopia.finance.widget.FinanceDisplayView;
import java.util.ArrayList;
import java.util.List;

public class LoanValidationAdapter extends BaseQuickAdapter<FinanceDisplayItem, BaseViewHolder> {
    public static final /* synthetic */ int c = 0;
    public final AppCompatActivity a;
    public final ArrayList b = new ArrayList();

    public LoanValidationAdapter(AppCompatActivity appCompatActivity) {
        super(R$layout.finance_item_loan_restructure);
        this.a = appCompatActivity;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i;
        FinanceDisplayItem financeDisplayItem = (FinanceDisplayItem) obj;
        DisplayView displayView = (FinanceDisplayView) baseViewHolder.getView(R$id.display_view);
        boolean equals = "Due Date".equals(financeDisplayItem.getKey());
        displayView.setTitle(financeDisplayItem.getTitle());
        displayView.setContent(financeDisplayItem.getContent());
        ImageView ivIcon = displayView.getIvIcon();
        if (equals) {
            i = 0;
        } else {
            i = 8;
        }
        ivIcon.setVisibility(i);
        if (equals) {
            displayView.setOnClickListener(new a(this, 3));
        } else {
            displayView.setOnClickListener((View.OnClickListener) null);
        }
        if (!TextUtils.isEmpty(financeDisplayItem.getRemark())) {
            displayView.setDesVisible(true);
            displayView.setDes(financeDisplayItem.getRemark());
            displayView.setDesColor(getContext().getResources().getColor(R$color.colorPrimary));
            return;
        }
        displayView.setDesVisible(false);
    }

    public final void e(LoanTrialResp loanTrialResp) {
        ArrayList arrayList = this.b;
        arrayList.clear();
        List<RepaymentSchedule> repaymentSchedules = loanTrialResp.getRepaymentSchedules();
        if (repaymentSchedules != null && !repaymentSchedules.isEmpty()) {
            for (RepaymentSchedule next : repaymentSchedules) {
                arrayList.add(new FinanceDisplayItem(next.getEndDate(), next.getTotalScheduleAmount()));
            }
        }
        setNewData(loanTrialResp.getPreValidationItems());
    }

    public final void onViewAttachedToWindow(@NonNull RecyclerView.ViewHolder viewHolder) {
        LoanValidationAdapter.super.onViewAttachedToWindow((BaseViewHolder) viewHolder);
    }
}
