package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.http.BaseResp;
import com.huawei.http.b;

public class RepayLoanRepository extends b<BaseResp, BaseResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/repay";
    }
}
