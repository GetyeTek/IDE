package com.huawei.ethiopia.finance.loan.repository;

import android.text.TextUtils;
import com.huawei.ethiopia.finance.resp.ContractsListResp;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.http.b;
import java.util.List;

public class QueryLoanContractsRepository extends b<ContractsListResp, ContractsListResp> {
    public final boolean a;

    public QueryLoanContractsRepository(String str) {
        this.a = true;
        addParams("loanStatus", "outstanding");
        addParams("fundsLenderId", str);
    }

    public final Object convert(Object obj) {
        ContractsListResp contractsListResp = (ContractsListResp) obj;
        List<LoanContractsInfo> contracts = contractsListResp.getContracts();
        if (contracts != null && !contracts.isEmpty()) {
            for (LoanContractsInfo active : contracts) {
                active.setActive(this.a);
            }
        }
        return contractsListResp;
    }

    public final String getApiPath() {
        return "v1/ethiopia/loan/queryIdentityProduct";
    }

    public QueryLoanContractsRepository(String str, String str2, boolean z) {
        this.a = z;
        addParams("loanStatus", z ? "outstanding" : "closed");
        addParams("fundsLenderId", str);
        if (!TextUtils.isEmpty(str2)) {
            addParams("queryLoanMarketType", str2);
        }
    }
}
