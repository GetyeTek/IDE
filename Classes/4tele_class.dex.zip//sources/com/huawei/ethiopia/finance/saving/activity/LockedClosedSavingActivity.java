package com.huawei.ethiopia.finance.saving.activity;

import C1.g;
import V7.e;
import W1.b;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.camera.camera2.interop.d;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.f;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityLockedClosedSavingBinding;
import com.huawei.ethiopia.finance.saving.adapter.LockedCloseSavingAccountAdapter;
import com.huawei.ethiopia.finance.saving.viewmodel.LockedSavingViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.DataBindingAdapter;
import com.huawei.payment.mvvm.R;

public class LockedClosedSavingActivity extends DataBindingActivity<FinanceActivityLockedClosedSavingBinding, LockedSavingViewModel> {
    public static final /* synthetic */ int h = 0;
    public LockedCloseSavingAccountAdapter d;
    public String e;
    public b.b f;
    public String g;

    public final int C0() {
        return R$layout.finance_activity_locked_closed_saving;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.ethiopia.finance.saving.activity.LockedClosedSavingActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        LockedClosedSavingActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.standard_white), false);
        e.a(this, getString(R$string.closed), R.layout.common_toolbar);
        this.e = getIntent().getStringExtra("fundsLenderId");
        this.g = getIntent().getStringExtra("bankCode");
        DataBindingAdapter dataBindingAdapter = new DataBindingAdapter();
        dataBindingAdapter.c = this;
        this.d = dataBindingAdapter;
        dataBindingAdapter.a = new d(this);
        this.b.a.setAdapter(dataBindingAdapter);
        this.c.a.observe(this, new Y4.d(this, 2));
        this.c.a(this.e, false);
        b.b c = b.b().c(this.b.a);
        c.b = new g(this, 4);
        this.f = c;
    }
}
