package com.huawei.ethiopia.finance.saving.repository;

import com.blankj.utilcode.util.s;
import com.huawei.ethiopia.finance.resp.FinanceProductListResp;
import com.huawei.http.b;
import p5.g;

public class QuerySavingBalanceRepository extends b<FinanceProductListResp, FinanceProductListResp> {
    public final String a;

    public QuerySavingBalanceRepository(String str, String str2) {
        this.a = str;
        addParams("initiatorMsisdn", g.k());
        addParams("status", "Active");
        addParams("fundsLenderId", str2);
    }

    public final String getApiPath() {
        return "v1/ethiopia/saving/account/list";
    }

    public final void saveToLocal(Object obj) {
        FinanceProductListResp financeProductListResp = (FinanceProductListResp) obj;
        super.saveToLocal(financeProductListResp);
        if (financeProductListResp != null) {
            s.a("").c(androidx.camera.core.processing.util.b.a(new StringBuilder(), this.a, "_", g.k(), "_KEY_SAVING_BALANCE"), financeProductListResp.getTotalBalance());
        }
    }
}
