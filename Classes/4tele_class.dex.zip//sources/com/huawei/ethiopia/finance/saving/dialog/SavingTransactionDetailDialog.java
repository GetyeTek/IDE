package com.huawei.ethiopia.finance.saving.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.blankj.utilcode.util.t;
import com.blankj.utilcode.util.v;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceDialogSavingTransactionDetailBinding;
import com.huawei.ethiopia.finance.loan.adapter.ResultAdapter;
import com.huawei.ethiopia.finance.resp.TransactionInfo;
import java.util.ArrayList;

public class SavingTransactionDetailDialog extends BaseDialog {
    public final TransactionInfo c;

    public SavingTransactionDetailDialog(TransactionInfo transactionInfo) {
        this.c = transactionInfo;
    }

    public final void onStart() {
        Window window;
        SavingTransactionDetailDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(17);
            window.setLayout(t.b() - v.a(32.0f), -2);
            window.setBackgroundDrawableResource(17170445);
            dialog.setCanceledOnTouchOutside(true);
            dialog.setCancelable(true);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        SavingTransactionDetailDialog.super.onViewCreated(view, bundle);
        setCancelable(true);
        FinanceDialogSavingTransactionDetailBinding bind = DataBindingUtil.bind(view);
        ResultAdapter resultAdapter = new ResultAdapter();
        bind.a.setAdapter(resultAdapter);
        bind.a.setLayoutManager(new LinearLayoutManager(view.getContext()));
        ArrayList arrayList = new ArrayList();
        String string = getString(R$string.transaction_no);
        TransactionInfo transactionInfo = this.c;
        arrayList.add(new DisplayItem(string, transactionInfo.getWalletOrderID()));
        arrayList.add(new DisplayItem(getString(R$string.transaction_type), transactionInfo.getTransactionTitle()));
        arrayList.add(new DisplayItem(getString(R$string.checkout_transaction_amount), transactionInfo.getShowAmount()));
        arrayList.add(new DisplayItem(getString(R$string.designstandard_transaction_time), transactionInfo.getTransactionTime()));
        arrayList.add(new DisplayItem(getString(R$string.balance_in_current_period), transactionInfo.getBalance()));
        resultAdapter.setNewData(arrayList);
    }

    public final int v0() {
        return R$layout.finance_dialog_saving_transaction_detail;
    }
}
