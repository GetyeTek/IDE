package com.huawei.ethiopia.finance.resp;

public class PreNewNplValidationResp extends LoanTrialResp {
    private String bankIcon;
    private String contractID;

    public String getBankIcon() {
        return this.bankIcon;
    }

    public String getContractID() {
        return this.contractID;
    }

    public void setBankIcon(String str) {
        this.bankIcon = str;
    }

    public void setContractID(String str) {
        this.contractID = str;
    }
}
