package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.http.b;

public class QueryContractDetailRepository extends b<LoanContractsInfo, LoanContractsInfo> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/queryContractDetail";
    }
}
