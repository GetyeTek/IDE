package com.huawei.ethiopia.finance.market.adapter;

import androidx.databinding.ViewDataBinding;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemFilterProductBinding;
import com.huawei.payment.mvvm.DataBindingAdapter;
import p5.g;

public class FinanceFilterProductAdapter extends DataBindingAdapter<FinanceMarketBankConfig.FilterBean, FinanceItemFilterProductBinding> {
    public int c;

    public final int a() {
        return R$layout.finance_item_filter_product;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        int i2;
        FinanceItemFilterProductBinding financeItemFilterProductBinding = (FinanceItemFilterProductBinding) viewDataBinding;
        financeItemFilterProductBinding.b.setText(g.j(((FinanceMarketBankConfig.FilterBean) obj).getTitle()));
        if (this.c == i) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        financeItemFilterProductBinding.a.setVisibility(i2);
    }
}
