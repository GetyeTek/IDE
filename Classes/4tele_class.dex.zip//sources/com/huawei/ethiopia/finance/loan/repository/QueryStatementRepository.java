package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.LoanStatementResp;
import com.huawei.http.b;

public class QueryStatementRepository extends b<LoanStatementResp, LoanStatementResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/queryStatements";
    }
}
