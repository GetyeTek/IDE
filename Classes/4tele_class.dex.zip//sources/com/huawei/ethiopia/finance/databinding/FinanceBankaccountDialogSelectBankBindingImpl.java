package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceBankaccountDialogSelectBankBindingImpl extends FinanceBankaccountDialogSelectBankBinding {
    @Nullable
    public static final SparseIntArray e;
    public long d;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        e = sparseIntArray;
        sparseIntArray.put(R$id.line, 1);
        sparseIntArray.put(R$id.tv_title, 2);
        sparseIntArray.put(R$id.etSearch, 3);
        sparseIntArray.put(R$id.rv_list, 4);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.d = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.d != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.d = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
