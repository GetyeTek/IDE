package com.huawei.ethiopia.finance.loan.activity;

public interface d {
    String i();
}
