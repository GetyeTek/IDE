package com.huawei.ethiopia.finance.od.repository;

import com.blankj.utilcode.util.s;
import com.huawei.http.BaseResp;
import com.huawei.http.b;
import p5.g;

public class DeactivateCreditRepository extends b<BaseResp, BaseResp> {
    public final String a = "homev5_nocache";
    public final String b = "creditPayBalanceUpdateTime";

    public DeactivateCreditRepository(String str) {
        addParams("initiatorMsisdn", g.k());
        addParams("initiatorPin", g.a(str));
        addParams("pinVersion", g.l());
    }

    public final String getApiPath() {
        return "v1/ethiopia/od/unsubscribe";
    }

    public final void saveToLocal(Object obj) {
        s.a(this.a).d(this.b);
        super.saveToLocal((BaseResp) obj);
    }
}
