package com.huawei.ethiopia.finance.od.activity;

import A8.C;
import V7.c;
import W1.b;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.camera.core.W;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import b4.a;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.v;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.R$dimen;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceActivityCreditPayHomeBinding;
import com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceDispacherViewModel;
import com.huawei.ethiopia.finance.od.repository.DeactivateCreditRepository;
import com.huawei.ethiopia.finance.od.viewmodel.DeactivateCreditViewModel;
import com.huawei.ethiopia.finance.resp.FinanceMenu;
import f5.C0080c;
import java.nio.charset.StandardCharsets;
import p5.g;

@Route(path = "/finance/odHome")
public class CreditPayHomeFragment extends Fragment {
    public FinanceActivityCreditPayHomeBinding a;
    public DeactivateCreditViewModel b;
    public FinanceDispacherViewModel c;
    public String d;
    public FinanceMenu e;
    public b.b f;
    public String g;

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        CreditPayHomeFragment.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 103 && i2 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            DeactivateCreditViewModel deactivateCreditViewModel = this.b;
            deactivateCreditViewModel.a.setValue(c.c());
            DeactivateCreditRepository deactivateCreditRepository = new DeactivateCreditRepository(str);
            deactivateCreditViewModel.b = deactivateCreditRepository;
            deactivateCreditRepository.sendRequest(new C(deactivateCreditViewModel, 3));
        }
    }

    /* JADX WARNING: type inference failed for: r2v3, types: [W4.a, java.lang.Object] */
    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        this.a = DataBindingUtil.inflate(layoutInflater, R$layout.finance_activity_credit_pay_home, viewGroup, false);
        b.b c2 = b.a(new Object()).c(this.a.c);
        c2.b = new W(this, 1);
        this.f = c2;
        return this.a.getRoot();
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        CreditPayHomeFragment.super.onViewCreated(view, bundle);
        if (getArguments() != null) {
            Bundle arguments = getArguments();
            this.d = arguments.getString("fundsLenderId");
            this.e = (FinanceMenu) arguments.getSerializable("financeMenu");
            this.g = arguments.getString("bankCode");
        }
        FinanceFragmentLoanHomeUnactiveBinding financeFragmentLoanHomeUnactiveBinding = this.a.g;
        financeFragmentLoanHomeUnactiveBinding.a.setOnClickListener(new C0080c(this, 0));
        FinanceMenu financeMenu = this.e;
        if (financeMenu != null) {
            String subTitle = financeMenu.getSubTitle();
            RoundTextView roundTextView = financeFragmentLoanHomeUnactiveBinding.b;
            roundTextView.setText(subTitle);
            int f2 = g.f(requireContext(), g.i().a, this.g);
            this.a.g.b.getBaseFilletView().f(v.a(1.5f));
            roundTextView.getBaseFilletView().e(f2);
            this.a.h.getRoot().setVisibility(8);
            FinanceDispacherViewModel financeDispacherViewModel = new ViewModelProvider(this).get(FinanceDispacherViewModel.class);
            this.c = financeDispacherViewModel;
            financeDispacherViewModel.a("finance_overdraft");
            this.c.a.observe(getViewLifecycleOwner(), new a(this, 3));
        } else {
            this.a.h.getRoot().setVisibility(0);
        }
        DeactivateCreditViewModel deactivateCreditViewModel = new ViewModelProvider(this).get(DeactivateCreditViewModel.class);
        this.b = deactivateCreditViewModel;
        deactivateCreditViewModel.a.observe(getViewLifecycleOwner(), new com.huawei.bank.transfer.activity.c(this, 2));
    }

    public final void v0(Boolean bool) {
        if (bool.booleanValue()) {
            this.a.i.setTextSize(0, getResources().getDimension(R$dimen.dp_16));
            this.a.a.setVisibility(0);
            this.a.j.setTextSize(0, getResources().getDimension(R$dimen.dp_14));
            this.a.b.setVisibility(8);
            return;
        }
        this.a.i.setTextSize(0, getResources().getDimension(R$dimen.dp_14));
        this.a.a.setVisibility(8);
        this.a.j.setTextSize(0, getResources().getDimension(R$dimen.dp_16));
        this.a.b.setVisibility(0);
    }
}
