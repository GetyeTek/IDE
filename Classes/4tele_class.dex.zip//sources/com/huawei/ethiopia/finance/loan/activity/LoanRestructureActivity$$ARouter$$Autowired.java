package com.huawei.ethiopia.finance.loan.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import com.huawei.ethiopia.finance.resp.PreNewNplValidationResp;

public class LoanRestructureActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r3v1, types: [com.huawei.ethiopia.finance.loan.activity.LoanRestructureActivity, android.app.Activity] */
    public void inject(Object obj) {
        this.serializationService = e.c(SerializationService.class);
        ? r3 = (LoanRestructureActivity) obj;
        r3.preValidationResp = (PreNewNplValidationResp) r3.getIntent().getSerializableExtra("DATA");
    }
}
