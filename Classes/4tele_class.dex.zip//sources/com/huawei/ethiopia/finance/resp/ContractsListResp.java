package com.huawei.ethiopia.finance.resp;

import com.blankj.utilcode.util.J;
import com.google.gson.annotations.SerializedName;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.http.BaseResp;
import java.util.List;
import p5.g;

public class ContractsListResp extends BaseResp {
    private boolean active;
    @SerializedName("productList")
    private List<LoanContractsInfo> contracts;
    private String currency;
    private String totalCreditAmount = "0.00";
    @SerializedName("totalOutstandingAmount")
    private String totalOutstandingAmount = "0.00";
    private String totalPaidAmount = "0.00";

    public String getAvailableLimitTitle() {
        return J.a().getString(R$string.available_limits) + "（" + getCurrency() + "）";
    }

    public List<LoanContractsInfo> getContracts() {
        return this.contracts;
    }

    public String getCurrency() {
        return g.g();
    }

    public String getMainAmount() {
        if (this.active) {
            return this.totalOutstandingAmount;
        }
        return this.totalPaidAmount;
    }

    public String getMainAmountTitle() {
        if (this.active) {
            return getTotalOutstandingAmountTitle();
        }
        return J.a().getString(R$string.total_paid_amount) + "（" + getCurrency() + "）";
    }

    public String getTotalCreditAmount() {
        return this.totalCreditAmount;
    }

    public String getTotalCreditAmountTitle() {
        return J.a().getString(R$string.total_credit_amount) + "（" + getCurrency() + "）";
    }

    public String getTotalLimitTitle() {
        return J.a().getString(R$string.total_credit_limit) + "（" + getCurrency() + "）";
    }

    public String getTotalOutstandingAmount() {
        return this.totalOutstandingAmount;
    }

    public String getTotalOutstandingAmountTitle() {
        return J.a().getString(R$string.total_outstanding_amount) + "（" + getCurrency() + "）";
    }

    public String getTotalPaidAmount() {
        return this.totalPaidAmount;
    }

    public String getTotalPaidAmountTitle() {
        return J.a().getString(R$string.total_paid_amount) + "（" + getCurrency() + "）";
    }

    public boolean isActive() {
        return this.active;
    }

    public void setActive(boolean z) {
        this.active = z;
    }

    public void setContracts(List<LoanContractsInfo> list) {
        this.contracts = list;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setTotalCreditAmount(String str) {
        this.totalCreditAmount = str;
    }

    public void setTotalOutstandingAmount(String str) {
        this.totalOutstandingAmount = str;
    }

    public void setTotalPaidAmount(String str) {
        this.totalPaidAmount = str;
    }
}
