package com.huawei.ethiopia.finance.resp;

import android.text.TextUtils;
import androidx.camera.camera2.internal.c;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.J;
import com.google.gson.annotations.SerializedName;
import com.huawei.common.display.DisplayItem;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.http.BaseResp;
import java.util.List;
import p5.g;

public class CreditPayContractsInfo extends BaseResp {
    private List<DisplayItem> contractDetailItems;
    @SerializedName(alternate = {"contractID"}, value = "contractId")
    private String contractId;
    private String contractName;
    private String contractNameI18n;
    @SerializedName(alternate = {"status"}, value = "contractState")
    private String contractState;
    private String currency;
    private String disburseAmount = "0.00";
    private String dueDate = "";
    private boolean isActive;
    @SerializedName(alternate = {"unpaidAmount"}, value = "outstandingAmount")
    private String outstandingAmount = "0.00";
    private String paidAmount = "0.00";
    private String periodStartDate = "";
    private String principal = "0.00";
    @SerializedName(alternate = {"productID"}, value = "productId")
    private String productId;
    private String totalAmount = "0.00";
    @SerializedName(alternate = {"transactionItems"}, value = "transactionList")
    private List<TransactionInfo> transactionList;

    private int getColor(int i) {
        return ContextCompat.getColor(J.a(), i);
    }

    public List<DisplayItem> getContractDetailItems() {
        return this.contractDetailItems;
    }

    public String getContractId() {
        return this.contractId;
    }

    public String getContractName() {
        return this.contractName;
    }

    public String getContractNameI18n() {
        if (TextUtils.isEmpty(this.contractNameI18n)) {
            return this.contractName;
        }
        return this.contractNameI18n;
    }

    public String getContractState() {
        return this.contractState;
    }

    public String getContractTitle() {
        if (isActive()) {
            return J.a().getString(R$string.ethiotel_credit_service);
        }
        return J.a().getString(R$string.credit_pay_product);
    }

    public String getCurrency() {
        String str = this.currency;
        if (str == null) {
            return "";
        }
        return str;
    }

    public String getDisburseAmount() {
        return this.disburseAmount;
    }

    public String getDueDate() {
        return this.dueDate;
    }

    public String getOutstandingAmount() {
        return this.outstandingAmount;
    }

    public String getPaidAmount() {
        return this.paidAmount;
    }

    public String getPayState() {
        if (isActive()) {
            return J.a().getString(R$string.pay);
        }
        return J.a().getString(R$string.paid);
    }

    public int getPayStateBackground() {
        if (isActive()) {
            return getColor(R$color.common_colorPrimary);
        }
        return 17170445;
    }

    public int getPayStateTextColor() {
        if (isActive()) {
            return getColor(R$color.common_colorWhite);
        }
        return getColor(R$color.colorTextLevel4);
    }

    public String getPeriodStartDate() {
        return this.periodStartDate;
    }

    public String getPrincipal() {
        return this.principal;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getShowAmount() {
        if (isActive()) {
            return this.outstandingAmount;
        }
        return this.paidAmount;
    }

    public String getShowOdDetailAmountTitle() {
        if (isActive()) {
            return J.a().getString(R$string.outstanding_amount) + "（" + g.g() + "）";
        }
        return J.a().getString(R$string.paid_amount) + "（" + g.g() + "）";
    }

    public String getShowStatusStr() {
        if (isActive()) {
            return J.a().getString(R$string.on_time);
        }
        return J.a().getString(R$string.paid);
    }

    public int getStateBackground() {
        if (isActive()) {
            return getColor(R$color.color_0DFF504E);
        }
        return getColor(R$color.color_0D1A73E8);
    }

    public int getStateTextColor() {
        if (isActive()) {
            return getColor(R$color.colorError);
        }
        return getColor(R$color.common_colorPrimary);
    }

    public String getTotalAmount() {
        return this.totalAmount;
    }

    public String getTotalCreditAmountTitle() {
        StringBuilder sb = new StringBuilder();
        sb.append(J.a().getString(R$string.total_credit_amount));
        sb.append(" (");
        return c.a(sb, this.currency, ")");
    }

    public int getTotalOutstandingAmountTextColor() {
        if (isActive()) {
            return getColor(R$color.common_colorPrimary);
        }
        return getColor(R$color.common_colorBlack);
    }

    public String getTotalOutstandingAmountTitle() {
        StringBuilder sb = new StringBuilder();
        sb.append(J.a().getString(R$string.total_outstanding_amount));
        sb.append(" (");
        return c.a(sb, this.currency, ")");
    }

    public List<TransactionInfo> getTransactionList() {
        return this.transactionList;
    }

    public boolean isActive() {
        return this.isActive;
    }

    public void setActive(boolean z) {
        this.isActive = z;
    }

    public void setContractDetailItems(List<DisplayItem> list) {
        this.contractDetailItems = list;
    }

    public void setContractId(String str) {
        this.contractId = str;
    }

    public void setContractName(String str) {
        this.contractName = str;
    }

    public void setContractNameI18n(String str) {
        this.contractNameI18n = str;
    }

    public void setContractState(String str) {
        this.contractState = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setDisburseAmount(String str) {
        this.disburseAmount = str;
    }

    public void setDueDate(String str) {
        this.dueDate = str;
    }

    public void setOutstandingAmount(String str) {
        this.outstandingAmount = str;
    }

    public void setPaidAmount(String str) {
        this.paidAmount = str;
    }

    public void setPeriodStartDate(String str) {
        this.periodStartDate = str;
    }

    public void setPrincipal(String str) {
        this.principal = str;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setStatus(String str) {
        this.contractState = str;
    }

    public void setTotalAmount(String str) {
        this.totalAmount = str;
    }

    public void setTransactionList(List<TransactionInfo> list) {
        this.transactionList = list;
    }
}
