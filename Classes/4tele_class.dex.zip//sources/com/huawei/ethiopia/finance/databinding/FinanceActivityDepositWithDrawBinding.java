package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class FinanceActivityDepositWithDrawBinding extends ViewDataBinding {
    @NonNull
    public final EditText a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public FinanceActivityDepositWithDrawBinding(DataBindingComponent dataBindingComponent, View view, EditText editText, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = editText;
        this.b = textView;
        this.c = textView2;
        this.d = textView3;
        this.e = textView4;
    }
}
