package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.AdvancedRepayResp;
import com.huawei.http.b;

public class ContractDetailRepository extends b<AdvancedRepayResp, AdvancedRepayResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/repayPreValidation";
    }
}
