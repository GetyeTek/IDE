package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class FinanceLoanActiveContractsBalanceBinding extends ViewDataBinding {
    @NonNull
    public final TextView a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;

    public FinanceLoanActiveContractsBalanceBinding(DataBindingComponent dataBindingComponent, View view, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = textView;
        this.b = textView2;
        this.c = textView3;
        this.d = textView4;
    }
}
