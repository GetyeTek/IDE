package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;

public class SavingTransactionResult extends BaseResp {
    private String balance;
    private String currency;
    private String transactionAmount;

    public String getBalance() {
        return this.balance;
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getTransactionAmount() {
        return this.transactionAmount;
    }

    public void setBalance(String str) {
        this.balance = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setTransactionAmount(String str) {
        this.transactionAmount = str;
    }
}
