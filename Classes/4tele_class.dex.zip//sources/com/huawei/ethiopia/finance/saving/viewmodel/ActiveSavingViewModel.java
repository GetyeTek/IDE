package com.huawei.ethiopia.finance.saving.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import com.huawei.ethiopia.finance.saving.repository.ActiveSavingProductRepository;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingActivatableProductRepository;
import com.huawei.http.BaseResp;
import java.util.List;

public class ActiveSavingViewModel extends ViewModel {
    public final MutableLiveData<c<List<SavingActivatableProduct>>> a = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> b = new MutableLiveData<>();
    public QuerySavingActivatableProductRepository c;
    public ActiveSavingProductRepository d;

    public final void onCleared() {
        ActiveSavingViewModel.super.onCleared();
        QuerySavingActivatableProductRepository querySavingActivatableProductRepository = this.c;
        if (querySavingActivatableProductRepository != null) {
            querySavingActivatableProductRepository.cancel();
        }
        ActiveSavingProductRepository activeSavingProductRepository = this.d;
        if (activeSavingProductRepository != null) {
            activeSavingProductRepository.cancel();
        }
    }
}
