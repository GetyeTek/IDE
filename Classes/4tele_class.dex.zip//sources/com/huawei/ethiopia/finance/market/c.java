package com.huawei.ethiopia.finance.market;

public final /* synthetic */ class c implements Runnable {
    public final /* synthetic */ FinanceMarketGuideActivity a;

    public /* synthetic */ c(FinanceMarketGuideActivity financeMarketGuideActivity) {
        this.a = financeMarketGuideActivity;
    }

    public final void run() {
        int i = FinanceMarketGuideActivity.g;
        this.a.c.a();
    }
}
