package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemFinanceContractsBindingImpl extends FinanceItemFinanceContractsBinding {
    @Nullable
    public static final SparseIntArray b;
    public long a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        b = sparseIntArray;
        sparseIntArray.put(R$id.tvTitle, 1);
        sparseIntArray.put(R$id.line, 2);
        sparseIntArray.put(R$id.tvAmount, 3);
        sparseIntArray.put(R$id.tvUnit, 4);
        sparseIntArray.put(R$id.tvDueDate, 5);
        sparseIntArray.put(R$id.btn_repay, 6);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.a = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.a != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.a = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
