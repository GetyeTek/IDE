package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.LoadingButton;

public abstract class ActivityContractDetailBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final RecyclerView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;

    public ActivityContractDetailBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, RecyclerView recyclerView, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = recyclerView;
        this.c = textView;
        this.d = textView2;
    }
}
