package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;

public abstract class FinanceActivityFinanceLoanHomeBinding extends ViewDataBinding {
    @NonNull
    public final ImageView a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final LinearLayout d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final ViewPager2 g;

    public FinanceActivityFinanceLoanHomeBinding(DataBindingComponent dataBindingComponent, View view, ImageView imageView, ImageView imageView2, LinearLayout linearLayout, LinearLayout linearLayout2, TextView textView, TextView textView2, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 0);
        this.a = imageView;
        this.b = imageView2;
        this.c = linearLayout;
        this.d = linearLayout2;
        this.e = textView;
        this.f = textView2;
        this.g = viewPager2;
    }
}
