package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class ActivityFinanceMarketBindingImpl extends ActivityFinanceMarketBinding {
    @Nullable
    public static final SparseIntArray d;
    public long c = -1;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        d = sparseIntArray;
        sparseIntArray.put(R$id.cycle_view, 1);
        sparseIntArray.put(R$id.linearLayout, 2);
        sparseIntArray.put(R$id.rlMyCredit, 3);
        sparseIntArray.put(R$id.roundImageView, 4);
        sparseIntArray.put(R$id.viewPager, 5);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActivityFinanceMarketBindingImpl(@androidx.annotation.NonNull android.view.View r6, @androidx.annotation.Nullable androidx.databinding.DataBindingComponent r7) {
        /*
            r5 = this;
            android.util.SparseIntArray r0 = d
            r1 = 6
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r7, r6, r1, r2, r0)
            r1 = 1
            r1 = r0[r1]
            com.huawei.common.widget.banner.CycleViewPager r1 = (com.huawei.common.widget.banner.CycleViewPager) r1
            r3 = 2
            r3 = r0[r3]
            android.widget.LinearLayout r3 = (android.widget.LinearLayout) r3
            r3 = 3
            r3 = r0[r3]
            com.huawei.common.widget.round.RoundConstraintLayout r3 = (com.huawei.common.widget.round.RoundConstraintLayout) r3
            r3 = 4
            r3 = r0[r3]
            com.huawei.common.widget.round.RoundImageView r3 = (com.huawei.common.widget.round.RoundImageView) r3
            r3 = 5
            r3 = r0[r3]
            androidx.viewpager2.widget.ViewPager2 r3 = (androidx.viewpager2.widget.ViewPager2) r3
            r5.<init>(r7, r6, r1, r3)
            r3 = -1
            r5.c = r3
            r7 = 0
            r7 = r0[r7]
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            r7.setTag(r2)
            r5.setRootTag(r6)
            r5.invalidateAll()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketBindingImpl.<init>(android.view.View, androidx.databinding.DataBindingComponent):void");
    }

    public final void executeBindings() {
        synchronized (this) {
            this.c = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.c != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.c = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
