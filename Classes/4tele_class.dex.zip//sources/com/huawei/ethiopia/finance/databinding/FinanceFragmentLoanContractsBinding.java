package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class FinanceFragmentLoanContractsBinding extends ViewDataBinding {
    @NonNull
    public final FinanceLoanActiveContractsBalanceBinding a;
    @NonNull
    public final FinanceDeactiveLoanLayoutBinding b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final HFRecyclerView d;

    public FinanceFragmentLoanContractsBinding(DataBindingComponent dataBindingComponent, View view, FinanceLoanActiveContractsBalanceBinding financeLoanActiveContractsBalanceBinding, FinanceDeactiveLoanLayoutBinding financeDeactiveLoanLayoutBinding, LinearLayout linearLayout, HFRecyclerView hFRecyclerView) {
        super(dataBindingComponent, view, 2);
        this.a = financeLoanActiveContractsBalanceBinding;
        this.b = financeDeactiveLoanLayoutBinding;
        this.c = linearLayout;
        this.d = hFRecyclerView;
    }
}
