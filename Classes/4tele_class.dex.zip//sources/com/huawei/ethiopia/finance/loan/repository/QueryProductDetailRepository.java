package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.ProductDetailInfo;
import com.huawei.http.b;

public class QueryProductDetailRepository extends b<ProductDetailInfo, ProductDetailInfo> {
    public QueryProductDetailRepository(String str) {
        addParams("productId", str);
    }

    public final String getApiPath() {
        return "v1/ethiopia/loan/queryProductById";
    }
}
