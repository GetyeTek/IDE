package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemTimeSavingProductDetailBindingImpl extends FinanceItemTimeSavingProductDetailBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.tvProductName, 1);
        sparseIntArray.put(R$id.roundConstraintLayout, 2);
        sparseIntArray.put(R$id.tvInterestRateValue, 3);
        sparseIntArray.put(R$id.tvProductLifeValue, 4);
        sparseIntArray.put(R$id.tvProductLife, 5);
        sparseIntArray.put(R$id.tvInterestRate, 6);
        sparseIntArray.put(R$id.btn_deposit, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
