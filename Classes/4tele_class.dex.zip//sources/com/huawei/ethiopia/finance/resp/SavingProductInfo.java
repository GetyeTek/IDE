package com.huawei.ethiopia.finance.resp;

import com.blankj.utilcode.util.J;
import com.google.gson.annotations.SerializedName;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.http.BaseResp;
import java.util.List;
import p5.g;

public class SavingProductInfo extends BaseResp {
    private String accountNo;
    @SerializedName("totalCapitalizationAmount")
    private String accruedInterest;
    private String balance;
    private String currency;
    private String productId;
    private String rateValue;
    @SerializedName(alternate = {"accountEntryItems"}, value = "transactionList")
    private List<TransactionInfo> transactionList;

    public String getAccountNo() {
        return this.accountNo;
    }

    public String getAccruedInterest() {
        return this.accruedInterest;
    }

    public String getBalance() {
        return this.balance;
    }

    public String getCurrency() {
        return g.g();
    }

    public String getDepositAmountTitle() {
        return J.a().getString(R$string.deposit_amount) + "（" + g.g() + "）";
    }

    public String getInterestRateTitle() {
        return J.a().getString(R$string.interest_rate) + "（" + g.g() + "）";
    }

    public String getProductId() {
        return this.productId;
    }

    public String getRateValue() {
        return this.rateValue;
    }

    public String getTotalGainsTitle() {
        return J.a().getString(R$string.total_gains) + "（" + g.g() + "）";
    }

    public List<TransactionInfo> getTransactionList() {
        return this.transactionList;
    }

    public void setAccountNo(String str) {
        this.accountNo = str;
    }

    public void setAccruedInterest(String str) {
        this.accruedInterest = str;
    }

    public void setBalance(String str) {
        this.balance = str;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setRateValue(String str) {
        this.rateValue = str;
    }

    public void setTransactionList(List<TransactionInfo> list) {
        this.transactionList = list;
    }
}
