package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemSavingTimeProductBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final NestedScrollView b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final LinearLayout d;
    @NonNull
    public final RoundConstraintLayout e;
    @NonNull
    public final RoundRecyclerView f;
    @NonNull
    public final RoundLinearLayout g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;

    public FinanceItemSavingTimeProductBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, NestedScrollView nestedScrollView, ImageView imageView, LinearLayout linearLayout, RoundConstraintLayout roundConstraintLayout, RoundRecyclerView roundRecyclerView, RoundLinearLayout roundLinearLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = nestedScrollView;
        this.c = imageView;
        this.d = linearLayout;
        this.e = roundConstraintLayout;
        this.f = roundRecyclerView;
        this.g = roundLinearLayout;
        this.h = textView;
        this.i = textView2;
        this.j = textView3;
        this.k = textView4;
    }
}
