package com.huawei.ethiopia.finance.market.adapter;

import androidx.databinding.ViewDataBinding;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.databinding.FinanceBankaccountItemBankBinding;
import com.huawei.payment.mvvm.DataBindingAdapter;
import p5.g;
import y5.C0116b;

public class FinanceBankAdapter extends DataBindingAdapter<FinanceMarketBankConfig.FinanceMarketBankItem, FinanceBankaccountItemBankBinding> {
    public final int a() {
        return R$layout.finance_bankaccount_item_bank;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        FinanceBankaccountItemBankBinding financeBankaccountItemBankBinding = (FinanceBankaccountItemBankBinding) viewDataBinding;
        FinanceMarketBankConfig.FinanceMarketBankItem financeMarketBankItem = (FinanceMarketBankConfig.FinanceMarketBankItem) obj;
        financeBankaccountItemBankBinding.b.setText(g.j(financeMarketBankItem.getBankNameI18n()));
        C0116b.c(financeBankaccountItemBankBinding.a, financeMarketBankItem.getLogo(), R$mipmap.finance_bankaccount_icon_default_bank_logo);
    }
}
