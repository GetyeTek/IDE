package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.viewlib.view.LoadingButton;

public final class ActivityManualRolloverBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final ImageButton c;
    @NonNull
    public final RoundImageView d;
    @NonNull
    public final RecyclerView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;

    public ActivityManualRolloverBinding(@NonNull ConstraintLayout constraintLayout, @NonNull LoadingButton loadingButton, @NonNull ImageButton imageButton, @NonNull RoundImageView roundImageView, @NonNull RecyclerView recyclerView, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = loadingButton;
        this.c = imageButton;
        this.d = roundImageView;
        this.e = recyclerView;
        this.f = textView;
        this.g = textView2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x003b, code lost:
        r0 = com.huawei.ethiopia.finance.R$id.recyclerView;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0012, code lost:
        r0 = com.huawei.ethiopia.finance.R$id.btn_confirm;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0028, code lost:
        r0 = com.huawei.ethiopia.finance.R$id.iv_icon;
     */
    @androidx.annotation.NonNull
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.huawei.ethiopia.finance.databinding.ActivityManualRolloverBinding a(@androidx.annotation.NonNull android.view.LayoutInflater r10) {
        /*
            int r0 = com.huawei.ethiopia.finance.R$layout.activity_manual_rollover
            r1 = 0
            r2 = 0
            android.view.View r10 = r10.inflate(r0, r2, r1)
            int r0 = com.huawei.ethiopia.finance.R$id.bgitem
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            if (r1 == 0) goto L_0x0066
            int r0 = com.huawei.ethiopia.finance.R$id.btn_confirm
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r4 = r1
            com.huawei.digitalpayment.customer.viewlib.view.LoadingButton r4 = (com.huawei.digitalpayment.customer.viewlib.view.LoadingButton) r4
            if (r4 == 0) goto L_0x0066
            int r0 = com.huawei.ethiopia.finance.R$id.iv_back
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r5 = r1
            android.widget.ImageButton r5 = (android.widget.ImageButton) r5
            if (r5 == 0) goto L_0x0066
            int r0 = com.huawei.ethiopia.finance.R$id.iv_icon
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r6 = r1
            com.huawei.common.widget.round.RoundImageView r6 = (com.huawei.common.widget.round.RoundImageView) r6
            if (r6 == 0) goto L_0x0066
            int r0 = com.huawei.ethiopia.finance.R$id.line_divider
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            if (r1 == 0) goto L_0x0066
            int r0 = com.huawei.ethiopia.finance.R$id.recyclerView
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r7 = r1
            androidx.recyclerview.widget.RecyclerView r7 = (androidx.recyclerview.widget.RecyclerView) r7
            if (r7 == 0) goto L_0x0066
            int r0 = com.huawei.ethiopia.finance.R$id.tv_title
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r8 = r1
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0066
            int r0 = com.huawei.ethiopia.finance.R$id.tv_toolbar_title
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r9 = r1
            android.widget.TextView r9 = (android.widget.TextView) r9
            if (r9 == 0) goto L_0x0066
            com.huawei.ethiopia.finance.databinding.ActivityManualRolloverBinding r0 = new com.huawei.ethiopia.finance.databinding.ActivityManualRolloverBinding
            r3 = r10
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r2 = r0
            r2.<init>(r3, r4, r5, r6, r7, r8, r9)
            return r0
        L_0x0066:
            android.content.res.Resources r10 = r10.getResources()
            java.lang.String r10 = r10.getResourceName(r0)
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Missing required view with ID: "
            java.lang.String r10 = r1.concat(r10)
            r0.<init>(r10)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.ActivityManualRolloverBinding.a(android.view.LayoutInflater):com.huawei.ethiopia.finance.databinding.ActivityManualRolloverBinding");
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
