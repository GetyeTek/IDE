package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceHomeBalanceBindingImpl extends FinanceHomeBalanceBinding {
    @Nullable
    public static final SparseIntArray b;
    public long a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        b = sparseIntArray;
        sparseIntArray.put(R$id.bankLogo, 1);
        sparseIntArray.put(R$id.tvBankName, 2);
        sparseIntArray.put(R$id.ivBackgroundVein, 3);
        sparseIntArray.put(R$id.baseline, 4);
        sparseIntArray.put(R$id.tvBottomBalance, 5);
        sparseIntArray.put(R$id.verticalGuideline, 6);
        sparseIntArray.put(R$id.tvBottomBalanceValue, 7);
        sparseIntArray.put(R$id.llTopBalance, 8);
        sparseIntArray.put(R$id.tvLeftBalance, 9);
        sparseIntArray.put(R$id.tvRightBalance, 10);
        sparseIntArray.put(R$id.tvLeftBalanceValue, 11);
        sparseIntArray.put(R$id.tvRightBalanceValue, 12);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.a = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.a != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.a = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
