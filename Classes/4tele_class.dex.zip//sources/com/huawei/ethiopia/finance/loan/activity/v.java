package com.huawei.ethiopia.finance.loan.activity;

import R1.b;
import android.os.Bundle;
import android.view.View;
import java.util.Map;

public final class v extends b {
    public final /* synthetic */ LoanRestructureActivity b;

    public v(LoanRestructureActivity loanRestructureActivity) {
        this.b = loanRestructureActivity;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.ethiopia.finance.loan.activity.LoanRestructureActivity, android.app.Activity] */
    public final void a(View view) {
        int i = LoanRestructureActivity.f;
        o0.b.e(this.b, "/loginModule/openBiometricIdentifyPin", (Bundle) null, (Map) null, 0, 101);
    }
}
