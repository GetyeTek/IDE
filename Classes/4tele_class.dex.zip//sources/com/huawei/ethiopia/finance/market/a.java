package com.huawei.ethiopia.finance.market;

import V7.c;
import V7.f;
import android.content.Intent;
import androidx.lifecycle.Observer;
import com.huawei.customer.digitalpayment.miniapp.macle.ui.activity.MacleEnterPinActivity;
import com.huawei.ethiopia.finance.market.bean.FinanceMenuItemInfo;
import com.huawei.ethiopia.finance.market.bean.FinanceMenuResp;
import com.huawei.ethiopia.finance.resp.FinanceProductListResp;
import com.huawei.ethiopia.finance.saving.activity.LockedSavingAccountActivity;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final /* synthetic */ class a implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ DataBindingActivity b;

    public /* synthetic */ a(DataBindingActivity dataBindingActivity, int i) {
        this.a = i;
        this.b = dataBindingActivity;
    }

    public final void onChanged(Object obj) {
        ArrayList arrayList;
        List<FinanceMenuItemInfo> financeMarketMenuList;
        MacleEnterPinActivity macleEnterPinActivity = this.b;
        c cVar = (c) obj;
        switch (this.a) {
            case 0:
                int i = FinanceMarketActivity.g;
                FinanceMarketActivity financeMarketActivity = (FinanceMarketActivity) macleEnterPinActivity;
                f.b(financeMarketActivity, cVar);
                if (cVar.b()) {
                    f.c(cVar);
                    return;
                }
                FinanceMenuResp financeMenuResp = (FinanceMenuResp) cVar.c;
                financeMarketActivity.f = financeMenuResp;
                if (financeMenuResp != null && (arrayList = financeMarketActivity.d) != null && (financeMarketMenuList = financeMenuResp.getFinanceMarketMenuList()) != null) {
                    arrayList.clear();
                    arrayList.addAll(financeMarketMenuList);
                    financeMarketActivity.e = financeMarketActivity.f.getFinanceMarketMenuList();
                    financeMarketActivity.F0();
                    return;
                }
                return;
            case 1:
                int i2 = LockedSavingAccountActivity.j;
                LockedSavingAccountActivity lockedSavingAccountActivity = (LockedSavingAccountActivity) macleEnterPinActivity;
                lockedSavingAccountActivity.getClass();
                FinanceProductListResp financeProductListResp = (FinanceProductListResp) cVar.c;
                if (financeProductListResp != null) {
                    lockedSavingAccountActivity.i = financeProductListResp.getTotalBalance();
                    lockedSavingAccountActivity.E0(lockedSavingAccountActivity.F0());
                    return;
                }
                return;
            default:
                int i3 = MacleEnterPinActivity.f;
                MacleEnterPinActivity macleEnterPinActivity2 = macleEnterPinActivity;
                macleEnterPinActivity2.getClass();
                f.b(macleEnterPinActivity2, cVar);
                if (cVar.b()) {
                    macleEnterPinActivity2.b.d.setText(cVar.b.getMessage());
                    macleEnterPinActivity2.b.c.b();
                }
                if (cVar.f()) {
                    Intent intent = new Intent();
                    intent.putExtra("encryptPin", L3.a.g(new String(macleEnterPinActivity2.e, StandardCharsets.UTF_8)));
                    macleEnterPinActivity2.setResult(-1, intent);
                    macleEnterPinActivity2.E0(false);
                    return;
                }
                return;
        }
    }
}
