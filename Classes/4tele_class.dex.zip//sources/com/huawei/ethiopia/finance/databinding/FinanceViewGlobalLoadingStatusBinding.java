package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class FinanceViewGlobalLoadingStatusBinding implements ViewBinding {
    @NonNull
    public final View getRoot() {
        return null;
    }
}
