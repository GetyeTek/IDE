package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemLoanProductBindingImpl extends FinanceItemLoanProductBinding {
    @Nullable
    public static final SparseIntArray v;
    public long u;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        v = sparseIntArray;
        sparseIntArray.put(R$id.tvTitle, 1);
        sparseIntArray.put(R$id.tv_desc, 2);
        sparseIntArray.put(R$id.btn_apply, 3);
        sparseIntArray.put(R$id.recycler_view, 4);
        sparseIntArray.put(R$id.cl_detail, 5);
        sparseIntArray.put(R$id.cl_more, 6);
        sparseIntArray.put(R$id.tvInterestRateValue, 7);
        sparseIntArray.put(R$id.tvInterestRate, 8);
        sparseIntArray.put(R$id.tvMaintenanceFeeValue, 9);
        sparseIntArray.put(R$id.tvMaintenanceFeeRate, 10);
        sparseIntArray.put(R$id.tvTotalGainsValue, 11);
        sparseIntArray.put(R$id.tvTotalGains, 12);
        sparseIntArray.put(R$id.tvMaxLimitValue, 13);
        sparseIntArray.put(R$id.tvMaxLimit, 14);
        sparseIntArray.put(R$id.tvAdvanceFeeValue, 15);
        sparseIntArray.put(R$id.tvAdvanceFee, 16);
        sparseIntArray.put(R$id.llMore, 17);
        sparseIntArray.put(R$id.tvMore, 18);
        sparseIntArray.put(R$id.ivMore, 19);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.u = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.u != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.u = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
