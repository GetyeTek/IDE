package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundLinearLayout;

public abstract class FinanceFragmentCreditPayContractsBinding extends ViewDataBinding {
    @NonNull
    public final FinanceItemOdActiveContractBalanceBinding a;
    @NonNull
    public final LoadingButton b;
    @NonNull
    public final RoundLinearLayout c;
    @NonNull
    public final HFRecyclerView d;

    public FinanceFragmentCreditPayContractsBinding(DataBindingComponent dataBindingComponent, View view, FinanceItemOdActiveContractBalanceBinding financeItemOdActiveContractBalanceBinding, LoadingButton loadingButton, RoundLinearLayout roundLinearLayout, HFRecyclerView hFRecyclerView) {
        super(dataBindingComponent, view, 1);
        this.a = financeItemOdActiveContractBalanceBinding;
        this.b = loadingButton;
        this.c = roundLinearLayout;
        this.d = hFRecyclerView;
    }
}
