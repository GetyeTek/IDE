package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceLoanContractDetailHeadBindingImpl extends FinanceLoanContractDetailHeadBinding {
    @Nullable
    public static final SparseIntArray k;
    public long j;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        k = sparseIntArray;
        sparseIntArray.put(R$id.tv_title, 1);
        sparseIntArray.put(R$id.tvContractNo, 2);
        sparseIntArray.put(R$id.tvContractNoValue, 3);
        sparseIntArray.put(R$id.tvContractStatus, 4);
        sparseIntArray.put(R$id.tvContractStatusValue, 5);
        sparseIntArray.put(R$id.line, 6);
        sparseIntArray.put(R$id.line_v, 7);
        sparseIntArray.put(R$id.tvTotalCreditAmount, 8);
        sparseIntArray.put(R$id.tvTotalCreditAmountValue, 9);
        sparseIntArray.put(R$id.tvTotalOutstandingAmount, 10);
        sparseIntArray.put(R$id.tvTotalOutstandingAmountValue, 11);
        sparseIntArray.put(R$id.btnLoadRestructure, 12);
        sparseIntArray.put(R$id.recycler_view, 13);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.j = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.j != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.j = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
