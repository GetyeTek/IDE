package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.DisplayView;

public abstract class FinanceCreditContractDetailHeadBinding extends ViewDataBinding {
    @NonNull
    public final DisplayView a;
    @NonNull
    public final DisplayView b;
    @NonNull
    public final DisplayView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public FinanceCreditContractDetailHeadBinding(DataBindingComponent dataBindingComponent, View view, DisplayView displayView, DisplayView displayView2, DisplayView displayView3, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = displayView;
        this.b = displayView2;
        this.c = displayView3;
        this.d = textView;
        this.e = textView2;
        this.f = textView3;
    }
}
