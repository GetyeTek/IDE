package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.LoanStatementResp;
import com.huawei.http.b;

public class AdvanceRepayContractRepository extends b<LoanStatementResp, LoanStatementResp> {
    public final String getApiPath() {
        return "v1/ethiopia/loan/advanceRepay";
    }
}
