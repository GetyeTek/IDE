package com.huawei.ethiopia.finance.saving.viewmodel;

import I4.d;
import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.ethiopia.finance.resp.TimeSavingProductInfo;
import com.huawei.ethiopia.finance.saving.repository.LockedSavingProductDetailRepository;
import com.huawei.http.b;
import java.util.List;
import p5.g;

public class LockedSavingProductDetailViewModel extends ViewModel {
    public final MutableLiveData<c<List<FinanceProductInfo>>> a = new MutableLiveData<>();
    public final MutableLiveData<c<List<HomeBannerBean>>> b = new MutableLiveData<>();
    public final MutableLiveData<c<TimeSavingProductInfo>> c = new MutableLiveData<>();
    public BannerRepository d;
    public LockedSavingProductDetailRepository e;
    public boolean f = true;

    public class a implements R1.a<TimeSavingProductInfo> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            LockedSavingProductDetailViewModel.this.c.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            LockedSavingProductDetailViewModel.this.c.setValue(c.e((TimeSavingProductInfo) obj));
        }
    }

    /* JADX WARNING: type inference failed for: r3v2, types: [com.huawei.ethiopia.finance.saving.repository.LockedSavingProductDetailRepository, com.huawei.http.b] */
    /* JADX WARNING: type inference failed for: r3v5, types: [com.huawei.ethiopia.finance.saving.repository.LockedSavingProductDetailRepository, com.huawei.http.b] */
    public final void a(String str) {
        if (!this.f) {
            d dVar = new d(this, 3);
            LockedSavingProductDetailRepository lockedSavingProductDetailRepository = this.e;
            if (lockedSavingProductDetailRepository != null) {
                lockedSavingProductDetailRepository.cancel();
            }
            ? bVar = new b();
            bVar.addParams("uniqueId", str);
            bVar.addParams("initiatorMsisdn", g.k());
            this.e = bVar;
            bVar.sendRequest(dVar);
            return;
        }
        this.f = false;
        this.c.setValue(c.c());
        a aVar = new a();
        LockedSavingProductDetailRepository lockedSavingProductDetailRepository2 = this.e;
        if (lockedSavingProductDetailRepository2 != null) {
            lockedSavingProductDetailRepository2.cancel();
        }
        ? bVar2 = new b();
        bVar2.addParams("uniqueId", str);
        bVar2.addParams("initiatorMsisdn", g.k());
        this.e = bVar2;
        bVar2.sendRequest(aVar);
    }

    public final void onCleared() {
        LockedSavingProductDetailViewModel.super.onCleared();
        LockedSavingProductDetailRepository lockedSavingProductDetailRepository = this.e;
        if (lockedSavingProductDetailRepository != null) {
            lockedSavingProductDetailRepository.cancel();
        }
        BannerRepository bannerRepository = this.d;
        if (bannerRepository != null) {
            bannerRepository.cancel();
        }
    }
}
