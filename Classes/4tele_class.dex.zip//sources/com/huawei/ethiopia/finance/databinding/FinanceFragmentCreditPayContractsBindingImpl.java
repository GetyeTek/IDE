package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LifecycleOwner;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;

public class FinanceFragmentCreditPayContractsBindingImpl extends FinanceFragmentCreditPayContractsBinding {
    @Nullable
    public static final ViewDataBinding.IncludedLayouts f;
    @Nullable
    public static final SparseIntArray g;
    public long e;

    static {
        ViewDataBinding.IncludedLayouts includedLayouts = new ViewDataBinding.IncludedLayouts(5);
        f = includedLayouts;
        includedLayouts.setIncludes(0, new String[]{"finance_item_od_active_contract_balance"}, new int[]{1}, new int[]{R$layout.finance_item_od_active_contract_balance});
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.ll_list, 2);
        sparseIntArray.put(R$id.recycler_view, 3);
        sparseIntArray.put(R$id.btnDeactivate, 4);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
        ViewDataBinding.executeBindingsOn(this.a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0015, code lost:
        if (r6.a.hasPendingBindings() == false) goto L_0x0018;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0017, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0018, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean hasPendingBindings() {
        /*
            r6 = this;
            monitor-enter(r6)
            long r0 = r6.e     // Catch:{ all -> 0x000c }
            r2 = 0
            r4 = 1
            int r5 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r5 == 0) goto L_0x000e
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            return r4
        L_0x000c:
            r0 = move-exception
            goto L_0x001a
        L_0x000e:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            com.huawei.ethiopia.finance.databinding.FinanceItemOdActiveContractBalanceBinding r0 = r6.a
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0018
            return r4
        L_0x0018:
            r0 = 0
            return r0
        L_0x001a:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.FinanceFragmentCreditPayContractsBindingImpl.hasPendingBindings():boolean");
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 2;
        }
        this.a.invalidateAll();
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        if (i != 0) {
            return false;
        }
        FinanceItemOdActiveContractBalanceBinding financeItemOdActiveContractBalanceBinding = (FinanceItemOdActiveContractBalanceBinding) obj;
        if (i2 != 0) {
            return false;
        }
        synchronized (this) {
            this.e |= 1;
        }
        return true;
    }

    public final void setLifecycleOwner(@Nullable LifecycleOwner lifecycleOwner) {
        FinanceFragmentCreditPayContractsBindingImpl.super.setLifecycleOwner(lifecycleOwner);
        this.a.setLifecycleOwner(lifecycleOwner);
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
