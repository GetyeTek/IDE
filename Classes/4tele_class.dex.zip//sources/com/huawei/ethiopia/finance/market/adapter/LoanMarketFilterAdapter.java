package com.huawei.ethiopia.finance.market.adapter;

import O9.c;
import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.blankj.utilcode.util.s;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.R$string;
import d2.a;
import p5.g;

public class LoanMarketFilterAdapter extends BaseQuickAdapter<FinanceMarketBankConfig.FinanceMarketBankItem, BaseViewHolder> {
    public int a = -1;

    public LoanMarketFilterAdapter() {
        super(R$layout.item_loan_market_filter);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        FinanceMarketBankConfig.FinanceMarketBankItem financeMarketBankItem = (FinanceMarketBankConfig.FinanceMarketBankItem) obj;
        int itemPosition = getItemPosition(financeMarketBankItem);
        RoundImageView view = baseViewHolder.getView(R$id.ivBankIcon);
        int i = R$id.tvBankName;
        TextView textView = (TextView) baseViewHolder.getView(i);
        String b = s.a("finance_sp_name_no_cache").b("finance_market_bank_code");
        if (TextUtils.equals(financeMarketBankItem.getBankCode(), "More")) {
            textView.setTextColor(ContextCompat.getColor(getContext(), R$color.black));
            view.getBaseFilletView().e(ContextCompat.getColor(getContext(), R$color.white));
        } else if (this.a == itemPosition || TextUtils.equals(b, financeMarketBankItem.getBankCode())) {
            baseViewHolder.setTextColor(i, Color.parseColor(financeMarketBankItem.getThemeColor()));
            view.getBaseFilletView().e(Color.parseColor(financeMarketBankItem.getThemeColor()));
        } else {
            a baseFilletView = view.getBaseFilletView();
            Context context = getContext();
            int i2 = R$color.gray;
            baseFilletView.e(ContextCompat.getColor(context, i2));
            textView.setTextColor(ContextCompat.getColor(getContext(), i2));
        }
        if (TextUtils.equals(financeMarketBankItem.getBankCode(), "ALL")) {
            baseViewHolder.setText(i, getContext().getString(R$string.all));
        } else {
            baseViewHolder.setText(i, g.j(financeMarketBankItem.getBankNameI18n()));
        }
        c.c(view, financeMarketBankItem.getLogo(), R$mipmap.finance_bankaccount_icon_default_bank_logo);
    }
}
