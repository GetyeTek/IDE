package com.huawei.ethiopia.finance.saving.adapter;

import android.text.Html;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.databinding.ViewDataBinding;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.v;
import com.huawei.astp.macle.ui.u;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBinding;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.payment.mvvm.DataBindingAdapter;
import p5.g;

public class SavingProductAdapter extends DataBindingAdapter<FinanceProductInfo, FinanceItemSavingProductBinding> {
    public FragmentActivity c;
    public String d;

    public final int a() {
        return R$layout.finance_item_saving_product;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        String str;
        FinanceItemSavingProductBinding financeItemSavingProductBinding = (FinanceItemSavingProductBinding) viewDataBinding;
        FinanceProductInfo financeProductInfo = (FinanceProductInfo) obj;
        TextView textView = financeItemSavingProductBinding.b;
        if (financeProductInfo.getProductDescI18n() == null) {
            str = "";
        } else {
            str = financeProductInfo.getProductDescI18n();
        }
        textView.setText(Html.fromHtml(str));
        financeItemSavingProductBinding.c.setText(financeProductInfo.getProductNameI18n());
        String str2 = this.d;
        boolean isEmpty = TextUtils.isEmpty(str2);
        RoundConstraintLayout roundConstraintLayout = financeItemSavingProductBinding.a;
        if (!isEmpty) {
            roundConstraintLayout.getBaseFilletView().e(g.f(this.c, g.i().a, str2));
            roundConstraintLayout.getBaseFilletView().f(v.a(1.0f));
        }
        roundConstraintLayout.setOnClickListener(new u(2, this, financeProductInfo));
    }
}
