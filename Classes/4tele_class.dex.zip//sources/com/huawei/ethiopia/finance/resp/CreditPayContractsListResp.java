package com.huawei.ethiopia.finance.resp;

import com.blankj.utilcode.util.J;
import com.google.gson.annotations.SerializedName;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.http.BaseResp;
import java.util.List;
import p5.g;

public class CreditPayContractsListResp extends BaseResp {
    private boolean active;
    private String availableLimit = "0.00";
    @SerializedName("contractItems")
    private List<CreditPayContractsInfo> contracts;
    private String currency;
    private List<CreditPayContractsGroup> groupContractItems;
    private String totalLimit = "0.00";
    private String totalPaidAmount = "0.00";
    private String totalUnpaidAmount = "0.00";

    public String getAvailableLimit() {
        return this.availableLimit;
    }

    public String getAvailableLimitTitle() {
        return J.a().getString(R$string.available_limits) + "（" + getCurrency() + "）";
    }

    public List<CreditPayContractsInfo> getContracts() {
        return this.contracts;
    }

    public String getCurrency() {
        return g.g();
    }

    public List<CreditPayContractsGroup> getGroupContractItems() {
        return this.groupContractItems;
    }

    public String getMainAmount() {
        if (this.active) {
            return this.totalUnpaidAmount;
        }
        return this.totalPaidAmount;
    }

    public String getMainAmountTitle() {
        if (this.active) {
            return getTotalOutstandingAmountTitle();
        }
        return J.a().getString(R$string.total_paid_amount) + "（" + getCurrency() + "）";
    }

    public String getTotalLimit() {
        return this.totalLimit;
    }

    public String getTotalLimitTitle() {
        return J.a().getString(R$string.total_credit_limit) + "（" + getCurrency() + "）";
    }

    public String getTotalOutstandingAmountTitle() {
        return J.a().getString(R$string.total_outstanding_amount) + "（" + getCurrency() + "）";
    }

    public String getTotalPaidAmount() {
        return this.totalPaidAmount;
    }

    public String getTotalUnpaidAmount() {
        return this.totalUnpaidAmount;
    }

    public boolean isActive() {
        return this.active;
    }

    public void setActive(boolean z) {
        this.active = z;
    }

    public void setAvailableLimit(String str) {
        this.availableLimit = str;
    }

    public void setContracts(List<CreditPayContractsInfo> list) {
        this.contracts = list;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setGroupContractItems(List<CreditPayContractsGroup> list) {
        this.groupContractItems = list;
    }

    public void setTotalLimit(String str) {
        this.totalLimit = str;
    }

    public void setTotalPaidAmount(String str) {
        this.totalPaidAmount = str;
    }

    public void setTotalUnpaidAmount(String str) {
        this.totalUnpaidAmount = str;
    }
}
