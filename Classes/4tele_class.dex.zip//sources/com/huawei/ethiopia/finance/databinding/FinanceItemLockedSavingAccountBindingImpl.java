package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemLockedSavingAccountBindingImpl extends FinanceItemLockedSavingAccountBinding {
    @Nullable
    public static final SparseIntArray g;
    public long f;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.tvTitle, 1);
        sparseIntArray.put(R$id.tvTotalAmountValue, 2);
        sparseIntArray.put(R$id.tvTotalAmount, 3);
        sparseIntArray.put(R$id.tvTotalGainsValue, 4);
        sparseIntArray.put(R$id.tvTotalGains, 5);
        sparseIntArray.put(R$id.tvExpireAfterValue, 6);
        sparseIntArray.put(R$id.tvExpireAfter, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.f = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.f != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.f = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
