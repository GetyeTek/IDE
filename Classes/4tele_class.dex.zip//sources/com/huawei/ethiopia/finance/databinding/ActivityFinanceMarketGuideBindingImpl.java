package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class ActivityFinanceMarketGuideBindingImpl extends ActivityFinanceMarketGuideBinding {
    @Nullable
    public static final SparseIntArray i;
    public long h = -1;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        i = sparseIntArray;
        sparseIntArray.put(R$id.imageView6, 1);
        sparseIntArray.put(R$id.ivBack, 2);
        sparseIntArray.put(R$id.llContent, 3);
        sparseIntArray.put(R$id.loneLimitView, 4);
        sparseIntArray.put(R$id.btn_confirm, 5);
        sparseIntArray.put(R$id.cycle_view, 6);
        sparseIntArray.put(R$id.roundTextView, 7);
        sparseIntArray.put(R$id.roundTextView2, 8);
        sparseIntArray.put(R$id.roundTextView1, 9);
        sparseIntArray.put(R$id.rv_recycler_view_filter, 10);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActivityFinanceMarketGuideBindingImpl(@androidx.annotation.NonNull android.view.View r14, @androidx.annotation.Nullable androidx.databinding.DataBindingComponent r15) {
        /*
            r13 = this;
            android.util.SparseIntArray r0 = i
            r1 = 11
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r15, r14, r1, r2, r0)
            r1 = 5
            r1 = r0[r1]
            r6 = r1
            android.widget.Button r6 = (android.widget.Button) r6
            r1 = 6
            r1 = r0[r1]
            r7 = r1
            com.huawei.common.widget.banner.CycleViewPager r7 = (com.huawei.common.widget.banner.CycleViewPager) r7
            r1 = 1
            r1 = r0[r1]
            r8 = r1
            android.widget.ImageView r8 = (android.widget.ImageView) r8
            r1 = 2
            r1 = r0[r1]
            r9 = r1
            android.widget.ImageView r9 = (android.widget.ImageView) r9
            r1 = 3
            r1 = r0[r1]
            r10 = r1
            android.widget.LinearLayout r10 = (android.widget.LinearLayout) r10
            r1 = 4
            r1 = r0[r1]
            r11 = r1
            com.huawei.ethiopia.finance.widget.LoanAmountLimitView r11 = (com.huawei.ethiopia.finance.widget.LoanAmountLimitView) r11
            r1 = 7
            r1 = r0[r1]
            com.huawei.common.widget.round.RoundTextView r1 = (com.huawei.common.widget.round.RoundTextView) r1
            r1 = 9
            r1 = r0[r1]
            com.huawei.common.widget.round.RoundTextView r1 = (com.huawei.common.widget.round.RoundTextView) r1
            r1 = 8
            r1 = r0[r1]
            com.huawei.common.widget.round.RoundTextView r1 = (com.huawei.common.widget.round.RoundTextView) r1
            r1 = 10
            r1 = r0[r1]
            r12 = r1
            androidx.recyclerview.widget.RecyclerView r12 = (androidx.recyclerview.widget.RecyclerView) r12
            r3 = r13
            r4 = r15
            r5 = r14
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r3 = -1
            r13.h = r3
            r15 = 0
            r15 = r0[r15]
            androidx.core.widget.NestedScrollView r15 = (androidx.core.widget.NestedScrollView) r15
            r15.setTag(r2)
            r13.setRootTag(r14)
            r13.invalidateAll()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBindingImpl.<init>(android.view.View, androidx.databinding.DataBindingComponent):void");
    }

    public final void executeBindings() {
        synchronized (this) {
            this.h = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.h != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.h = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i2, Object obj, int i3) {
        return false;
    }

    public final boolean setVariable(int i2, @Nullable Object obj) {
        return true;
    }
}
