package com.huawei.ethiopia.finance.market.adapter;

import O9.c;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.market.bean.FinanceMenuItemInfo;

public class FinanceMarketAdapter extends BaseQuickAdapter<FinanceMenuItemInfo, BaseViewHolder> {
    public FinanceMarketAdapter() {
        super(R$layout.item_finance_market);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        FinanceMenuItemInfo financeMenuItemInfo = (FinanceMenuItemInfo) obj;
        baseViewHolder.setText(R$id.tv_title, financeMenuItemInfo.getFuncNameI18n());
        c.c((ImageView) baseViewHolder.getView(R$id.iv_logo), financeMenuItemInfo.getIcon(), -1);
    }
}
