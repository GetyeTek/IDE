package com.huawei.ethiopia.finance.saving.adapter;

import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public class BaseViewHolder<T extends ViewDataBinding> extends RecyclerView.ViewHolder {
    public final T a;

    public BaseViewHolder(T t) {
        super(t.getRoot());
        this.a = t;
    }
}
