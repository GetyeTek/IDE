package com.huawei.ethiopia.finance.loan.activity;

import E6.j;
import V7.c;
import V7.f;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.huawei.common.display.DisplayItem;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.resp.AdvancedRepayResp;
import com.huawei.kbz.chat.chat_room.ChatFragment;
import com.huawei.kbz.chat.chat_room.adapter.ConversationMessageAdapter;
import com.huawei.kbz.chat.chat_room.model.UiMessage;
import com.huawei.kbz.chat.contact.data.QueryChatUserInfoRepository;
import java.util.ArrayList;
import java.util.List;
import k3.a;

public final /* synthetic */ class e implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ e(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                c cVar = (c) obj;
                int i = ContractDetailActivity.i;
                FragmentActivity fragmentActivity = (ContractDetailActivity) obj2;
                fragmentActivity.getClass();
                f.b(fragmentActivity, cVar);
                if (cVar.b()) {
                    f.c(cVar);
                    return;
                } else if (cVar.f()) {
                    AdvancedRepayResp advancedRepayResp = (AdvancedRepayResp) cVar.c;
                    fragmentActivity.b.c.setText(String.valueOf(Double.parseDouble(advancedRepayResp.getAdvancedRepaymentFee()) + Double.parseDouble(fragmentActivity.f.getRepaymentAmount())));
                    TextView textView = fragmentActivity.b.d;
                    a aVar = a.e;
                    textView.setText(aVar.b());
                    List contractDetailItems = fragmentActivity.g.getContractDetailItems();
                    if (contractDetailItems == null) {
                        contractDetailItems = new ArrayList();
                    }
                    contractDetailItems.add(new DisplayItem(fragmentActivity.getString(R$string.contract_additional_fee) + "(" + aVar.b() + ")", advancedRepayResp.getAdvancedRepaymentFee()));
                    fragmentActivity.h.setNewData(contractDetailItems);
                    return;
                } else {
                    return;
                }
            default:
                List<UiMessage> list = (List) obj;
                ChatFragment chatFragment = (ChatFragment) obj2;
                ConversationMessageAdapter conversationMessageAdapter = chatFragment.b;
                conversationMessageAdapter.getClass();
                int i2 = 0;
                if (list != null && !list.isEmpty()) {
                    conversationMessageAdapter.c.addAll(0, list);
                    conversationMessageAdapter.notifyItemRangeInserted(0, list.size());
                }
                chatFragment.a.k.i();
                ArrayList arrayList = new ArrayList();
                for (UiMessage uiMessage : list) {
                    String sender = uiMessage.getMessage().getSender();
                    if (!TextUtils.isEmpty(sender) && chatFragment.m.a(sender) == null && !arrayList.contains(uiMessage.getMessage().getSender())) {
                        arrayList.add(uiMessage.getMessage().getSender());
                    }
                }
                if (!J8.a.i(arrayList) && arrayList.size() != 0) {
                    int i3 = 50;
                    try {
                        i3 = Integer.parseInt((String) j.b(String.valueOf(50), "QUERY_CHAT_USER_INFO_LIMIT"));
                    } catch (NumberFormatException unused) {
                    }
                    while (i2 < arrayList.size()) {
                        int i4 = i2 + i3;
                        new QueryChatUserInfoRepository((List<String>) new ArrayList(arrayList.subList(i2, Math.min(arrayList.size(), i4)))).sendRequest(new O6.f(chatFragment, 1));
                        i2 = i4;
                    }
                    return;
                }
                return;
        }
    }
}
