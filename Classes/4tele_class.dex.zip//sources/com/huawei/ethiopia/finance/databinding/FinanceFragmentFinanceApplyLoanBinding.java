package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.widget.CreditScoreView;

public abstract class FinanceFragmentFinanceApplyLoanBinding extends ViewDataBinding {
    @NonNull
    public final CreditScoreView a;
    @NonNull
    public final FrameLayout b;
    @NonNull
    public final FinanceFragmentLoanHomeUnactiveBinding c;
    @NonNull
    public final HFRecyclerView d;
    @NonNull
    public final RoundTextView e;

    public FinanceFragmentFinanceApplyLoanBinding(DataBindingComponent dataBindingComponent, View view, CreditScoreView creditScoreView, FrameLayout frameLayout, FinanceFragmentLoanHomeUnactiveBinding financeFragmentLoanHomeUnactiveBinding, HFRecyclerView hFRecyclerView, RoundTextView roundTextView) {
        super(dataBindingComponent, view, 1);
        this.a = creditScoreView;
        this.b = frameLayout;
        this.c = financeFragmentLoanHomeUnactiveBinding;
        this.d = hFRecyclerView;
        this.e = roundTextView;
    }
}
