package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class FinanceFilterProductSelectBinding extends ViewDataBinding {
    @NonNull
    public final HFRecyclerView a;
    @NonNull
    public final TextView b;

    public FinanceFilterProductSelectBinding(DataBindingComponent dataBindingComponent, View view, HFRecyclerView hFRecyclerView, TextView textView) {
        super(dataBindingComponent, view, 0);
        this.a = hFRecyclerView;
        this.b = textView;
    }
}
