package com.huawei.ethiopia.finance.market;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import com.huawei.ethiopia.finance.market.bean.LoanCategoryMenuInfo;

public class LoanProductsMarketActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r3v1, types: [com.huawei.ethiopia.finance.market.LoanProductsMarketActivity, android.app.Activity] */
    public void inject(Object obj) {
        this.serializationService = e.c(SerializationService.class);
        ? r3 = (LoanProductsMarketActivity) obj;
        r3.categoryMenuInfo = (LoanCategoryMenuInfo) r3.getIntent().getSerializableExtra("categoryMenuInfo");
    }
}
