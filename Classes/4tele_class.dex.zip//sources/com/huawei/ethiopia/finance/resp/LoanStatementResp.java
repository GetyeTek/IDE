package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;

public class LoanStatementResp extends BaseResp {
    private String repaymentAmount;
    private String statementId;

    public String getRepaymentAmount() {
        return this.repaymentAmount;
    }

    public String getStatementId() {
        return this.statementId;
    }

    public void setRepaymentAmount(String str) {
        this.repaymentAmount = str;
    }

    public void setStatementId(String str) {
        this.statementId = str;
    }
}
