package com.huawei.ethiopia.finance.saving.viewmodel;

import A8.C;
import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.ethiopia.finance.resp.SavingProductInfo;
import com.huawei.ethiopia.finance.saving.repository.SavingProductDetailRepository;
import com.huawei.http.b;
import java.util.List;
import p5.g;

public class SavingProductDetailViewModel extends ViewModel {
    public final MutableLiveData<c<List<HomeBannerBean>>> a = new MutableLiveData<>();
    public final MutableLiveData<c<SavingProductInfo>> b = new MutableLiveData<>();
    public BannerRepository c;
    public SavingProductDetailRepository d;
    public boolean e = true;

    public class a implements R1.a<SavingProductInfo> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            SavingProductDetailViewModel.this.b.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            SavingProductDetailViewModel.this.b.setValue(c.e((SavingProductInfo) obj));
        }
    }

    /* JADX WARNING: type inference failed for: r3v2, types: [com.huawei.http.b, com.huawei.ethiopia.finance.saving.repository.SavingProductDetailRepository] */
    /* JADX WARNING: type inference failed for: r3v5, types: [com.huawei.http.b, com.huawei.ethiopia.finance.saving.repository.SavingProductDetailRepository] */
    public final void a(String str) {
        if (!this.e) {
            C c2 = new C(this, 5);
            SavingProductDetailRepository savingProductDetailRepository = this.d;
            if (savingProductDetailRepository != null) {
                savingProductDetailRepository.cancel();
            }
            ? bVar = new b();
            bVar.addParams("uniqueId", str);
            bVar.addParams("initiatorMsisdn", g.k());
            this.d = bVar;
            bVar.sendRequest(c2);
            return;
        }
        this.e = false;
        this.b.setValue(c.c());
        a aVar = new a();
        SavingProductDetailRepository savingProductDetailRepository2 = this.d;
        if (savingProductDetailRepository2 != null) {
            savingProductDetailRepository2.cancel();
        }
        ? bVar2 = new b();
        bVar2.addParams("uniqueId", str);
        bVar2.addParams("initiatorMsisdn", g.k());
        this.d = bVar2;
        bVar2.sendRequest(aVar);
    }

    public final void onCleared() {
        SavingProductDetailViewModel.super.onCleared();
        SavingProductDetailRepository savingProductDetailRepository = this.d;
        if (savingProductDetailRepository != null) {
            savingProductDetailRepository.cancel();
        }
        BannerRepository bannerRepository = this.c;
        if (bannerRepository != null) {
            bannerRepository.cancel();
        }
    }
}
