package com.huawei.ethiopia.finance.od.fragment;

import I4.f;
import I4.g;
import V7.c;
import W1.b;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceFragmentCreditPayContractsBinding;
import com.huawei.ethiopia.finance.loan.repository.QueryCreditPayContractsRepository;
import com.huawei.ethiopia.finance.od.adapter.FinanceCreditPayGroupAdapter;
import com.huawei.ethiopia.finance.od.repository.DeactivateCreditRepository;
import com.huawei.ethiopia.finance.od.viewmodel.FinanceCreditPayViewModel;
import com.huawei.ethiopia.finance.resp.CreditPayContractsListResp;
import h5.C0094a;
import h5.C0095b;
import java.nio.charset.StandardCharsets;

public class CreditPayContractsFragment extends Fragment {
    public FinanceFragmentCreditPayContractsBinding a;
    public boolean b;
    public FinanceCreditPayGroupAdapter c;
    public FinanceCreditPayViewModel d;
    public CreditPayContractsListResp e;
    public b.b f;
    public String g;

    public static CreditPayContractsFragment w0(String str, boolean z) {
        Bundle bundle = new Bundle();
        bundle.putString("bankCode", str);
        bundle.putBoolean("isActive", z);
        CreditPayContractsFragment creditPayContractsFragment = new CreditPayContractsFragment();
        creditPayContractsFragment.setArguments(bundle);
        return creditPayContractsFragment;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        CreditPayContractsFragment.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 100 && i2 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            FinanceCreditPayViewModel financeCreditPayViewModel = this.d;
            financeCreditPayViewModel.b.setValue(c.c());
            DeactivateCreditRepository deactivateCreditRepository = new DeactivateCreditRepository(str);
            financeCreditPayViewModel.d = deactivateCreditRepository;
            deactivateCreditRepository.sendRequest(new g(financeCreditPayViewModel, 4));
        }
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        FinanceFragmentCreditPayContractsBinding inflate = DataBindingUtil.inflate(layoutInflater, R$layout.finance_fragment_credit_pay_contracts, viewGroup, false);
        this.a = inflate;
        return inflate.getRoot();
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        CreditPayContractsFragment.super.onViewCreated(view, bundle);
        b.b c2 = b.b().c(this.a.c);
        c2.b = new androidx.camera.core.impl.utils.futures.b(this, 3);
        this.f = c2;
        if (getArguments() != null) {
            this.b = getArguments().getBoolean("isActive", true);
            this.g = getArguments().getString("bankCode", "");
        }
        v0(this.b);
        this.a.d.setLayoutManager(new LinearLayoutManager(requireContext()));
        this.a.d.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(requireContext(), R$color.colorDividerLight), v.a(1.0f)));
        requireActivity();
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.finance_item_credit_pay_product_group);
        this.c = baseQuickAdapter;
        this.a.d.setAdapter(baseQuickAdapter);
        this.a.b.setOnClickListener(new J6.b(this, 6));
        CreditPayContractsListResp creditPayContractsListResp = new CreditPayContractsListResp();
        creditPayContractsListResp.setActive(this.b);
        x0(creditPayContractsListResp);
        FinanceCreditPayViewModel financeCreditPayViewModel = new ViewModelProvider(this).get(FinanceCreditPayViewModel.class);
        this.d = financeCreditPayViewModel;
        financeCreditPayViewModel.a.observe(getViewLifecycleOwner(), new C0094a(this));
        this.d.b.observe(getViewLifecycleOwner(), new C0095b(this, 0));
        FinanceCreditPayViewModel financeCreditPayViewModel2 = this.d;
        boolean z = this.b;
        financeCreditPayViewModel2.a.setValue(c.c());
        QueryCreditPayContractsRepository queryCreditPayContractsRepository = new QueryCreditPayContractsRepository(z);
        financeCreditPayViewModel2.c = queryCreditPayContractsRepository;
        queryCreditPayContractsRepository.sendRequest(new f(financeCreditPayViewModel2, 1));
    }

    public final void v0(boolean z) {
        if (z) {
            this.a.a.c.setVisibility(0);
            this.a.a.b.setVisibility(0);
            this.a.a.e.setVisibility(0);
            this.a.a.d.setVisibility(0);
            return;
        }
        this.a.a.c.setVisibility(8);
        this.a.a.b.setVisibility(8);
        this.a.a.e.setVisibility(8);
        this.a.a.d.setVisibility(8);
    }

    public final void x0(CreditPayContractsListResp creditPayContractsListResp) {
        if (creditPayContractsListResp != null) {
            this.a.a.d.setText(creditPayContractsListResp.getMainAmountTitle());
            this.a.a.a.setText(creditPayContractsListResp.getMainAmount());
            this.a.a.c.setText(creditPayContractsListResp.getAvailableLimit());
            this.a.a.b.setText(creditPayContractsListResp.getAvailableLimitTitle());
            this.a.a.e.setText(creditPayContractsListResp.getTotalLimit());
            this.a.a.d.setText(creditPayContractsListResp.getTotalLimitTitle());
        }
    }
}
