package com.huawei.ethiopia.finance.od.adapter;

import android.widget.TextView;
import androidx.databinding.ViewDataBinding;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayTransactionBinding;
import com.huawei.ethiopia.finance.resp.TransactionInfo;
import com.huawei.payment.mvvm.DataBindingAdapter;
import p5.g;

public class CreditPayTransactionAdapter extends DataBindingAdapter<TransactionInfo, FinanceItemCreditPayTransactionBinding> {
    public final int a() {
        return R$layout.finance_item_credit_pay_transaction;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        FinanceItemCreditPayTransactionBinding financeItemCreditPayTransactionBinding = (FinanceItemCreditPayTransactionBinding) viewDataBinding;
        TransactionInfo transactionInfo = (TransactionInfo) obj;
        TextView textView = financeItemCreditPayTransactionBinding.d;
        String businessScopeI18n = transactionInfo.getBusinessScopeI18n();
        String g = g.g();
        textView.setText(businessScopeI18n + "(" + g + ")");
        financeItemCreditPayTransactionBinding.c.setText(transactionInfo.getShowContent());
        financeItemCreditPayTransactionBinding.b.setText(transactionInfo.getShowAmount());
    }
}
