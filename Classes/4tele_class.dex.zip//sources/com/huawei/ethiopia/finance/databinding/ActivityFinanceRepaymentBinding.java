package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.digitalpayment.customer.viewlib.view.TypeSelectView;

public abstract class ActivityFinanceRepaymentBinding extends ViewDataBinding {
    @NonNull
    public final CommonInputView a;
    @NonNull
    public final TypeSelectView b;
    @NonNull
    public final TypeSelectView c;
    @NonNull
    public final LoadingButton d;

    public ActivityFinanceRepaymentBinding(DataBindingComponent dataBindingComponent, View view, CommonInputView commonInputView, TypeSelectView typeSelectView, TypeSelectView typeSelectView2, LoadingButton loadingButton) {
        super(dataBindingComponent, view, 0);
        this.a = commonInputView;
        this.b = typeSelectView;
        this.c = typeSelectView2;
        this.d = loadingButton;
    }
}
