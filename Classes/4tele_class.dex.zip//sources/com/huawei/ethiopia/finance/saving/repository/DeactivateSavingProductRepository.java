package com.huawei.ethiopia.finance.saving.repository;

import com.huawei.http.BaseResp;
import com.huawei.http.b;

public class DeactivateSavingProductRepository extends b<BaseResp, BaseResp> {
    public final String getApiPath() {
        return "v1/ethiopia/saving/unsubscribe";
    }
}
