package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.RolloverPreValidationResp;
import com.huawei.http.b;

public class RolloverPreValidationRepository extends b<RolloverPreValidationResp, RolloverPreValidationResp> {
    public RolloverPreValidationRepository(String str, String str2) {
        addParams("contractID", str);
        addParams("statementID", str2);
    }

    public final String getApiPath() {
        return "v1/ethiopia/loan/rolloverPreValidation";
    }
}
