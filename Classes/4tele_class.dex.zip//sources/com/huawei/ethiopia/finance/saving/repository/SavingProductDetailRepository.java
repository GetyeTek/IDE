package com.huawei.ethiopia.finance.saving.repository;

import com.huawei.ethiopia.finance.resp.SavingProductInfo;
import com.huawei.http.b;

public class SavingProductDetailRepository extends b<SavingProductInfo, SavingProductInfo> {
    public final String getApiPath() {
        return "v1/ethiopia/saving/product/detail";
    }
}
