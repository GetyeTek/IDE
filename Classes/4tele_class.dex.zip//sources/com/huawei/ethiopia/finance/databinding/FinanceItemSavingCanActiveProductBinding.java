package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundLinearLayout;

public abstract class FinanceItemSavingCanActiveProductBinding extends ViewDataBinding {
    @NonNull
    public final ImageView a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final RoundLinearLayout c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public FinanceItemSavingCanActiveProductBinding(DataBindingComponent dataBindingComponent, View view, ImageView imageView, ImageView imageView2, RoundLinearLayout roundLinearLayout, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = imageView;
        this.b = imageView2;
        this.c = roundLinearLayout;
        this.d = textView;
        this.e = textView2;
    }
}
