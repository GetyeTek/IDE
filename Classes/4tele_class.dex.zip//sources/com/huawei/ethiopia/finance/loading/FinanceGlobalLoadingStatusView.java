package com.huawei.ethiopia.finance.loading;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;

public class FinanceGlobalLoadingStatusView extends LinearLayout implements View.OnClickListener {
    public final TextView a = ((TextView) findViewById(R$id.text));
    public final Runnable b;
    public final ImageView c = ((ImageView) findViewById(R$id.image));
    public final View d = findViewById(R$id.progress_bar);
    public final View e = findViewById(R$id.lb_submit);

    public FinanceGlobalLoadingStatusView(Context context, Runnable runnable) {
        super(context);
        setOrientation(1);
        setGravity(1);
        LayoutInflater.from(context).inflate(R$layout.finance_view_global_loading_status, this, true);
        this.b = runnable;
    }

    public static Activity a(Context context) {
        if (context == null) {
            return null;
        }
        if (context instanceof Activity) {
            return (Activity) context;
        }
        if (context instanceof ContextWrapper) {
            return a(((ContextWrapper) context).getBaseContext());
        }
        return null;
    }

    public final void onClick(View view) {
        Runnable runnable = this.b;
        if (runnable != null) {
            runnable.run();
        }
    }

    public void setMsgViewVisibility(boolean z) {
        int i;
        if (z) {
            i = 0;
        } else {
            i = 8;
        }
        this.a.setVisibility(i);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0027  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0042  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0074  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setStatus(int r11) {
        /*
            r10 = this;
            int r0 = com.huawei.ethiopia.finance.R$string.str_none
            r1 = 2
            r2 = 3
            r3 = 0
            r4 = -1
            if (r11 == r1) goto L_0x001d
            r1 = 1
            if (r11 == r2) goto L_0x0015
            r5 = 4
            if (r11 == r5) goto L_0x0010
        L_0x000e:
            r5 = -1
            goto L_0x001f
        L_0x0010:
            int r0 = com.huawei.ethiopia.finance.R$string.baselib_no_record_yet
            int r5 = com.huawei.ethiopia.finance.R$mipmap.icon_no_record_yet
            goto L_0x001f
        L_0x0015:
            int r0 = com.huawei.ethiopia.finance.R$string.load_failed
            int r5 = com.huawei.ethiopia.finance.R$mipmap.icon_system_server_error
            r10.setOnClickListener(r10)
            goto L_0x001f
        L_0x001d:
            r1 = 0
            goto L_0x000e
        L_0x001f:
            android.view.View r6 = r10.d
            android.widget.ImageView r7 = r10.c
            r8 = 8
            if (r5 == r4) goto L_0x0042
            android.content.Context r4 = r10.getContext()
            android.app.Activity r4 = a(r4)
            android.view.Window r4 = r4.getWindow()
            r9 = 1065353216(0x3f800000, float:1.0)
            r4.setDimAmount(r9)
            r6.setVisibility(r8)
            r7.setVisibility(r3)
            r7.setImageResource(r5)
            goto L_0x005a
        L_0x0042:
            android.content.Context r4 = r10.getContext()
            android.app.Activity r4 = a(r4)
            android.view.Window r4 = r4.getWindow()
            r5 = 1058642330(0x3f19999a, float:0.6)
            r4.setDimAmount(r5)
            r6.setVisibility(r3)
            r7.setVisibility(r8)
        L_0x005a:
            java.lang.Runnable r4 = r10.b
            android.view.View r5 = r10.e
            if (r4 == 0) goto L_0x0069
            if (r2 != r11) goto L_0x0069
            r5.setVisibility(r3)
            r5.setOnClickListener(r10)
            goto L_0x006c
        L_0x0069:
            r5.setVisibility(r8)
        L_0x006c:
            android.widget.TextView r11 = r10.a
            r11.setText(r0)
            if (r1 == 0) goto L_0x0074
            goto L_0x0076
        L_0x0074:
            r3 = 8
        L_0x0076:
            r10.setVisibility(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.loading.FinanceGlobalLoadingStatusView.setStatus(int):void");
    }
}
