package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.LoadingButton;

public abstract class FinanceActivityActiveSavingBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final RecyclerView b;

    public FinanceActivityActiveSavingBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, RecyclerView recyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = recyclerView;
    }
}
