package com.huawei.ethiopia.finance.od.adapter;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayContactsBinding;
import com.huawei.ethiopia.finance.resp.CreditPayContractsInfo;
import p5.g;

public class FinanceCreditPayContactsAdapter extends BaseQuickAdapter<CreditPayContractsInfo, BaseViewHolder> {
    public FinanceCreditPayContactsAdapter() {
        super(R$layout.finance_item_credit_pay_contacts);
        addChildClickViewIds(new int[]{R$id.btn_repay});
        addChildClickViewIds(new int[]{R$id.view});
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        CreditPayContractsInfo creditPayContractsInfo = (CreditPayContractsInfo) obj;
        FinanceItemCreditPayContactsBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        bind.c.setText(creditPayContractsInfo.getShowAmount());
        bind.e.setText("（" + g.g() + "）");
        bind.d.setText(creditPayContractsInfo.getContractId());
        bind.a.setVisibility(8);
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return FinanceCreditPayContactsAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
