package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;

public abstract class FinanceActivityLockedSavingAccountBinding extends ViewDataBinding {
    @NonNull
    public final FinanceItemTimeSavingAllBalanceBinding a;
    @NonNull
    public final HFRecyclerView b;

    public FinanceActivityLockedSavingAccountBinding(DataBindingComponent dataBindingComponent, View view, FinanceItemTimeSavingAllBalanceBinding financeItemTimeSavingAllBalanceBinding, HFRecyclerView hFRecyclerView) {
        super(dataBindingComponent, view, 1);
        this.a = financeItemTimeSavingAllBalanceBinding;
        this.b = hFRecyclerView;
    }
}
