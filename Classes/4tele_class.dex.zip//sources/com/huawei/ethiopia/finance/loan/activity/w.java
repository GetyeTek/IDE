package com.huawei.ethiopia.finance.loan.activity;

import V1.k;
import V7.c;
import V7.f;
import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.kbz.event.FaceVerificationResult;
import java.util.Map;
import o0.b;

public final /* synthetic */ class w implements Observer {
    public final /* synthetic */ ManualRolloverActivity a;

    public /* synthetic */ w(ManualRolloverActivity manualRolloverActivity) {
        this.a = manualRolloverActivity;
    }

    public final void onChanged(Object obj) {
        int i;
        BaseException baseException;
        c cVar = (c) obj;
        int i2 = ManualRolloverActivity.f;
        FragmentActivity fragmentActivity = this.a;
        fragmentActivity.getClass();
        f.b(fragmentActivity, cVar);
        if (cVar.b() && (baseException = cVar.b) != null) {
            k.b(1, baseException.getMessage());
        }
        if (cVar.f()) {
            Bundle bundle = new Bundle();
            if (fragmentActivity.isInstall) {
                i = R$string.finance_installment_plan_success;
            } else {
                i = R$string.loan_extension_success;
            }
            bundle.putString(FaceVerificationResult.RESULT, fragmentActivity.getString(i));
            a5.f.c.c(fragmentActivity.bankCode);
            b.d((Activity) null, "/finance/transactionResult", bundle, (Map) null);
            fragmentActivity.finish();
        }
    }
}
