package com.huawei.ethiopia.finance.loan.activity;

import O9.c;
import V7.e;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceConfigBinding;
import com.huawei.ethiopia.finance.loan.fragment.FinanceServiceFragment;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceServiceViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.ArrayList;
import java.util.List;
import p5.g;
import p5.i;

@Route(path = "/finance/financeCBE")
@Deprecated
public class FinanceServiceCBEActivity extends DataBindingActivity<FinanceActivityFinanceServiceConfigBinding, FinanceServiceViewModel> {
    public static final /* synthetic */ int d = 0;
    @Autowired
    String bankCode;
    @Autowired
    String bankIcon;
    @Autowired
    String bankName;
    @Autowired
    String selectOverDraft;

    public final int C0() {
        return R$layout.finance_activity_finance_service_config;
    }

    public final void E0(int i) {
        int i2;
        this.b.e.setCurrentItem(i);
        RoundTextView roundTextView = this.b.a;
        if (i == 0) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        roundTextView.setVisibility(i2);
    }

    public final void F0() {
        int i;
        FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(this);
        this.b.e.setAdapter(fragmentStateAdapter);
        ArrayList arrayList = new ArrayList();
        arrayList.add(FinanceServiceFragment.y0(this.bankCode, this.selectOverDraft));
        fragmentStateAdapter.a(arrayList);
        this.b.c.setOnClickListener(new h(this));
        this.b.b.setOnClickListener(new i(this));
        this.b.d.setOnClickListener(new j(this));
        this.b.a.setOnClickListener(new k(this));
        this.b.e.registerOnPageChangeCallback(new l(this));
        RoundTextView roundTextView = this.b.a;
        Resources resources = getResources();
        String str = this.bankCode;
        List<FinanceMarketBankConfig.FinanceMarketBankItem> list = g.b;
        if ("CBE".equals(str)) {
            i = R$color.colorCBE;
        } else {
            i = R$color.colorDashen;
        }
        roundTextView.setBackground(resources.getDrawable(i));
        E0(0);
        if (!TextUtils.isEmpty(this.bankName)) {
            this.b.d.setText(this.bankName);
            if (TextUtils.equals(this.bankCode, "CBE")) {
                this.b.d.setText(getResources().getString(R$string.commercial_bank_of_ethiopia));
            }
        }
        c.c(this.b.b, this.bankIcon, -1);
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        FinanceServiceCBEActivity.super.onActivityResult(i, i2, intent);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments != null && !fragments.isEmpty()) {
            for (Fragment onActivityResult : fragments) {
                onActivityResult.onActivityResult(i, i2, intent);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.ethiopia.finance.loan.activity.FinanceServiceCBEActivity, android.content.Context, com.huawei.payment.mvvm.DataBindingActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceServiceCBEActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.financial_service), R.layout.common_toolbar);
        i iVar = i.e;
        String str = this.bankCode;
        String str2 = this.bankIcon;
        iVar.c = this.bankName;
        iVar.b = str2;
        iVar.a = str;
        F0();
    }

    public final void onDestroy() {
        FinanceServiceCBEActivity.super.onDestroy();
        i.e.d = 0;
    }

    public final void onNewIntent(Intent intent) {
        FinanceServiceCBEActivity.super.onNewIntent(intent);
        F0();
    }
}
