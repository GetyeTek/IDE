package com.huawei.ethiopia.finance.loan.fragment;

import W1.b;
import Y4.q;
import Y4.r;
import Y4.s;
import Y4.t;
import Y4.u;
import a5.f;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.blankj.utilcode.util.v;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanContractsBinding;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanGroupAdapter;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceMyTelebirrTelaViewModel;
import com.huawei.ethiopia.finance.resp.ContractsListResp;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import p5.g;

public class LoanContractsFragment extends Fragment {
    public FinanceFragmentLoanContractsBinding a;
    public boolean b;
    public FinanceLoanGroupAdapter c;
    public FinanceMyTelebirrTelaViewModel d;
    public ContractsListResp e = new ContractsListResp();
    public b.b f;
    public String g;
    public boolean h;
    public String i;
    public String j;

    public static LoanContractsFragment v0(String str, String str2, String str3, boolean z) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isActive", z);
        bundle.putString("bankCode", str);
        bundle.putString("fundsLenderId", str2);
        bundle.putString("queryLoanMarketType", str3);
        LoanContractsFragment loanContractsFragment = new LoanContractsFragment();
        loanContractsFragment.setArguments(bundle);
        return loanContractsFragment;
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        LoanContractsFragment.super.onActivityResult(i2, i3, intent);
        if (this.b && i2 == 1111 && i3 == -1) {
            o0.b.d((Activity) null, "/finance/transactionResult", (Bundle) null, (Map) null);
        }
        if (this.b && intent != null && i2 == 101 && i3 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            if (TextUtils.equals(this.g, "financeMarket")) {
                this.d.a(str, g.o());
            } else {
                this.d.a(str, "");
            }
        }
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        FinanceFragmentLoanContractsBinding inflate = DataBindingUtil.inflate(layoutInflater, R$layout.finance_fragment_loan_contracts, viewGroup, false);
        this.a = inflate;
        return inflate.getRoot();
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        int i2;
        LoanContractsFragment.super.onViewCreated(view, bundle);
        this.d = new ViewModelProvider(this).get(FinanceMyTelebirrTelaViewModel.class);
        b.b c2 = b.b().c(this.a.c);
        c2.b = new s(this, 0);
        this.f = c2;
        if (getArguments() != null) {
            this.b = getArguments().getBoolean("isActive", true);
            this.g = getArguments().getString("bankCode");
            this.i = getArguments().getString("fundsLenderId");
            this.j = getArguments().getString("queryLoanMarketType");
        }
        this.a.d.setLayoutManager(new LinearLayoutManager(requireContext()));
        this.a.d.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(requireContext(), R$color.colorDividerLight), v.a(1.0f)));
        FinanceLoanGroupAdapter financeLoanGroupAdapter = new FinanceLoanGroupAdapter(requireActivity());
        this.c = financeLoanGroupAdapter;
        financeLoanGroupAdapter.b = this.g;
        financeLoanGroupAdapter.c = new q(this);
        this.a.d.setAdapter(financeLoanGroupAdapter);
        w0();
        if (this.b) {
            this.d.b.observe(getViewLifecycleOwner(), new u(this, 0));
        }
        f.c.b(this.g).observe(getViewLifecycleOwner(), new Y4.v(this, 0));
        this.d.a.observe(getViewLifecycleOwner(), new r(this, 0));
        this.d.c.observe(getViewLifecycleOwner(), new t(this, 0));
        View root = this.a.b.getRoot();
        if (this.b) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        root.setVisibility(i2);
        this.a.b.getRoot().setOnClickListener(new A6.b(this, 1));
        this.d.b(this.i, this.j, this.b);
    }

    public final void w0() {
        if (this.b) {
            this.a.a.b.setText(this.e.getTotalOutstandingAmount());
            this.a.a.a.setText(this.e.getTotalOutstandingAmountTitle());
        } else {
            this.a.a.b.setText(this.e.getTotalPaidAmount());
            this.a.a.a.setText(this.e.getTotalPaidAmountTitle());
        }
        this.a.a.c.setText(this.e.getTotalCreditAmountTitle());
        this.a.a.d.setText(this.e.getTotalCreditAmount());
    }
}
