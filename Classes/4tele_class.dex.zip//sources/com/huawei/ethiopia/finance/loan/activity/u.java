package com.huawei.ethiopia.finance.loan.activity;

import R1.b;
import android.view.View;

public final class u extends b {
    public final /* synthetic */ LoanRestructureActivity b;

    public u(LoanRestructureActivity loanRestructureActivity) {
        this.b = loanRestructureActivity;
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.ethiopia.finance.loan.activity.LoanRestructureActivity, android.app.Activity] */
    public final void a(View view) {
        this.b.finish();
    }
}
