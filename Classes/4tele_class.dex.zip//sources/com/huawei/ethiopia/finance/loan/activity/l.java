package com.huawei.ethiopia.finance.loan.activity;

import androidx.viewpager2.widget.ViewPager2;

public final class l extends ViewPager2.OnPageChangeCallback {
    public final /* synthetic */ FinanceServiceCBEActivity a;

    public l(FinanceServiceCBEActivity financeServiceCBEActivity) {
        this.a = financeServiceCBEActivity;
    }

    public final void onPageSelected(int i) {
        int i2 = FinanceServiceCBEActivity.d;
        this.a.E0(i);
    }
}
