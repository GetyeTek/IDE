package com.huawei.ethiopia.finance.saving.repository;

import com.huawei.ethiopia.finance.resp.FinanceProductListResp;
import com.huawei.http.b;
import p5.g;

public class QuerySavingAccountRepository extends b<FinanceProductListResp, FinanceProductListResp> {
    public QuerySavingAccountRepository(String str, boolean z, boolean z2) {
        String str2;
        String str3;
        addParams("initiatorMsisdn", g.k());
        if (z2) {
            str2 = "Active";
        } else {
            str2 = "Closed";
        }
        addParams("status", str2);
        addParams("fundsLenderId", str);
        if (z) {
            str3 = "TermDeposit";
        } else {
            str3 = "SavingDeposit";
        }
        addParams("accountType", str3);
    }

    public final String getApiPath() {
        return "v1/ethiopia/saving/account/list";
    }
}
