package com.huawei.ethiopia.finance.constants;

import java.io.Serializable;

public enum TransactionType implements Serializable {
    DEPOSIT,
    WITHDRAW
}
