package com.huawei.ethiopia.finance.loan.adapter;

import V1.h;
import W2.c;
import X4.b;
import X4.d;
import Y4.e;
import Y4.f;
import Y4.g;
import android.text.TextUtils;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.t;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.digitalpayment.customer.cache.BasicConfig;
import com.huawei.digitalpayment.customer.httplib.bean.ParameterLimitBean;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductBinding;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.ethiopia.finance.resp.ProductDetailInfo;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import java.util.ArrayList;
import java.util.List;

public class FinanceLoanProductAdapter extends BaseQuickAdapter<ProductInfo, BaseViewHolder> {
    public static final /* synthetic */ int i = 0;
    public f a;
    public g b;
    public int c;
    public String d;
    public e e;
    public e f;
    public final int g;
    public final int h;

    public FinanceLoanProductAdapter(@Nullable ArrayList arrayList) {
        super(R$layout.finance_item_loan_product, arrayList);
        int b2 = t.b();
        this.g = b2;
        this.h = b2 / 4;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i2;
        String str;
        int i3;
        int i4;
        int i5;
        String str2;
        ProductInfo productInfo = (ProductInfo) obj;
        FinanceItemLoanProductBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        if (bind != null) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(bind.getRoot().getContext());
            RoundRecyclerView roundRecyclerView = bind.f;
            roundRecyclerView.setLayoutManager(linearLayoutManager);
            List<LoanContractsInfo> loanContractsInfos = productInfo.getLoanContractsInfos();
            ArrayList arrayList = new ArrayList();
            if (loanContractsInfos != null) {
                for (LoanContractsInfo next : loanContractsInfos) {
                    if (!next.isInstallments() || (next.getRepaymentSchedules() != null && !next.getRepaymentSchedules().isEmpty())) {
                        arrayList.add(next);
                    }
                }
                i2 = arrayList.size();
            } else {
                i2 = 0;
            }
            FinanceLoanContractsAdapter financeLoanContractsAdapter = new FinanceLoanContractsAdapter(arrayList);
            financeLoanContractsAdapter.setOnItemChildClickListener(new b(this, financeLoanContractsAdapter));
            bind.g.getBaseFilletView().e(p5.g.f(bind.getRoot().getContext(), p5.g.i().a, this.d));
            roundRecyclerView.setAdapter(financeLoanContractsAdapter);
            bind.r.setText(productInfo.getProductNameI18n());
            boolean isAllowApplyNPL = productInfo.isAllowApplyNPL();
            RoundTextView roundTextView = bind.a;
            if (isAllowApplyNPL) {
                roundTextView.setVisibility(0);
            } else {
                roundTextView.setVisibility(8);
            }
            String string = J.a().getString(R$string.credit_limit_s_to_s);
            try {
                String minLimit = productInfo.getMinLimit();
                if (minLimit != null) {
                    minLimit = c.a(minLimit.split("\\.")[0]);
                }
                String maxLimit = productInfo.getMaxLimit();
                if (maxLimit != null) {
                    maxLimit = c.a(maxLimit.split("\\.")[0]);
                }
                str = String.format(string, new Object[]{minLimit, maxLimit});
            } catch (Exception unused) {
                h.b();
                str = "";
            }
            bind.j.setText(str);
            int a2 = v.a(52.0f);
            int i7 = this.g;
            int i8 = i7 - a2;
            int i9 = i8 / 3;
            RoundConstraintLayout roundConstraintLayout = bind.c;
            roundConstraintLayout.getLayoutParams().width = i8;
            TextView textView = bind.k;
            textView.setWidth(i9);
            TextView textView2 = bind.s;
            textView2.setWidth(i9);
            TextView textView3 = bind.o;
            textView3.setWidth(i9);
            ProductDetailInfo productDetailInfo = productInfo.getProductDetailInfo();
            TextView textView4 = bind.i;
            TextView textView5 = bind.h;
            TextView textView6 = bind.n;
            TextView textView7 = bind.m;
            RoundTextView roundTextView2 = roundTextView;
            TextView textView8 = bind.t;
            int i10 = i2;
            TextView textView9 = bind.p;
            RoundRecyclerView roundRecyclerView2 = roundRecyclerView;
            TextView textView10 = bind.l;
            FinanceItemLoanProductBinding financeItemLoanProductBinding = bind;
            if (productDetailInfo != null) {
                textView10.setText(productDetailInfo.getFacilitationFeeShowValue());
                textView9.setText(productDetailInfo.getAvailableLimit());
                textView8.setText(productDetailInfo.getPenaltyFeeShowValue() + " " + J.a().getString(R$string.daily_s));
                if (!TextUtils.isEmpty(productDetailInfo.getMaintenanceFee())) {
                    textView6.setVisibility(0);
                    textView7.setVisibility(0);
                    String str3 = this.d;
                    String maintenanceFee = productDetailInfo.getMaintenanceFee();
                    List<FinanceMarketBankConfig.FinanceMarketBankItem> list = p5.g.b;
                    if (TextUtils.equals("0%", maintenanceFee)) {
                        ParameterLimitBean parameterLimit = BasicConfig.getInstance().getParameterLimit();
                        if (parameterLimit != null) {
                            if ("Dashen".equals(str3) && !TextUtils.isEmpty(parameterLimit.getMaintenanceFeeDashen())) {
                                maintenanceFee = parameterLimit.getMaintenanceFeeDashen();
                            } else if ("CBE".equals(str3) && !TextUtils.isEmpty(parameterLimit.getMaintenanceFeeCBE())) {
                                maintenanceFee = parameterLimit.getMaintenanceFeeCBE();
                            }
                        }
                        if ("Dashen".equals(str3)) {
                            str2 = "0.3-1.2%";
                        } else {
                            str2 = "0.5-0.8%";
                        }
                        maintenanceFee = str2;
                    }
                    textView6.setText(maintenanceFee);
                    i4 = 1;
                } else {
                    textView6.setVisibility(8);
                    textView7.setVisibility(8);
                    textView6.setText((CharSequence) null);
                    i4 = 0;
                }
                if (!TextUtils.isEmpty(productDetailInfo.getAdvancedRepaymentFee())) {
                    textView5.setVisibility(0);
                    textView4.setVisibility(0);
                    textView4.setText(productDetailInfo.getAdvancedRepaymentFee());
                    i5 = 1;
                    i4++;
                } else {
                    i5 = 1;
                    textView5.setVisibility(8);
                    textView4.setVisibility(8);
                    textView4.setText((CharSequence) null);
                }
                if (i4 > 0) {
                    if (i4 == i5) {
                        roundConstraintLayout.getLayoutParams().width = i7;
                    } else {
                        roundConstraintLayout.getLayoutParams().width = (i7 * 5) / 4;
                    }
                    int i11 = this.h;
                    textView.setWidth(i11);
                    textView7.setWidth(i11);
                    textView2.setWidth(i11);
                    textView3.setWidth(i11);
                    textView5.setWidth(i11);
                }
            } else {
                textView10.setText((CharSequence) null);
                textView6.setText((CharSequence) null);
                textView8.setText((CharSequence) null);
                textView9.setText((CharSequence) null);
                textView4.setText((CharSequence) null);
                textView6.setVisibility(8);
                textView7.setVisibility(8);
                textView5.setVisibility(8);
                textView4.setVisibility(8);
            }
            boolean isShow = productInfo.isShow();
            FinanceItemLoanProductBinding financeItemLoanProductBinding2 = financeItemLoanProductBinding;
            ImageView imageView = financeItemLoanProductBinding2.d;
            TextView textView11 = financeItemLoanProductBinding2.q;
            HorizontalScrollView horizontalScrollView = financeItemLoanProductBinding2.b;
            if (isShow) {
                textView11.setText(J.a().getString(R$string.less));
                imageView.setRotation(180.0f);
                horizontalScrollView.getLayoutParams().height = Math.max(this.c, v.a(87.0f));
                horizontalScrollView.requestLayout();
                roundRecyclerView2.getLayoutParams().height = v.a(62.0f) * i10;
                roundRecyclerView2.requestLayout();
                i3 = i10;
            } else {
                textView11.setText(J.a().getString(R$string.more));
                imageView.setRotation(0.0f);
                horizontalScrollView.getLayoutParams().height = 1;
                horizontalScrollView.requestLayout();
                i3 = i10;
                roundRecyclerView2.getLayoutParams().height = v.a(62.0f) * Math.min(2, i3);
                roundRecyclerView2.requestLayout();
            }
            financeItemLoanProductBinding2.e.setOnClickListener(new X4.c(this, productInfo, i3, financeItemLoanProductBinding2));
            roundTextView2.setOnClickListener(new d(this, productInfo));
        }
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i2) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i2 - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return FinanceLoanProductAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i2);
    }
}
