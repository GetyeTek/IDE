package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceFragmentFinanceMyTelebirrTelaBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final LinearLayout d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final ViewPager2 g;

    public FinanceFragmentFinanceMyTelebirrTelaBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, RoundTextView roundTextView2, LinearLayout linearLayout, LinearLayout linearLayout2, TextView textView, TextView textView2, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = roundTextView2;
        this.c = linearLayout;
        this.d = linearLayout2;
        this.e = textView;
        this.f = textView2;
        this.g = viewPager2;
    }
}
