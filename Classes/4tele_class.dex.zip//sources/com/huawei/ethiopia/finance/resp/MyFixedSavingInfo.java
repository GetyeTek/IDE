package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class MyFixedSavingInfo extends BaseResp {
    private List<AccountItemsBean> accountItems;
    private String endNumberOfReturned;
    private String numberOfTotal;
    private String startNumberOfReturned;

    public static class AccountItemsBean implements Serializable {
        private String accountNo;
        private String accountType;
        private String accruedInterest;
        private String availableBalance;
        private String balance;
        private String createTime;
        private String currency;
        private String custAccountNo;
        private String frozenBalance;
        private String maturityDate;
        private String openAccountDate;
        private String principalAmount;
        private String productDescI18N;
        private String productID;
        private String productName;
        private String productNameI18N;
        private String productRateValue;
        private String productRateValueMode;
        private String productUnquieID;
        private String status;
        private String totalCapitalizationAmount;
        private String unclearingBalance;

        public String getAccountNo() {
            return this.accountNo;
        }

        public String getAccountType() {
            return this.accountType;
        }

        public String getAccruedInterest() {
            return this.accruedInterest;
        }

        public String getAvailableBalance() {
            return this.availableBalance;
        }

        public String getBalance() {
            return this.balance;
        }

        public String getCreateTime() {
            return this.createTime;
        }

        public String getCurrency() {
            return this.currency;
        }

        public String getCustAccountNo() {
            return this.custAccountNo;
        }

        public String getFrozenBalance() {
            return this.frozenBalance;
        }

        public String getMaturityDate() {
            return this.maturityDate;
        }

        public String getOpenAccountDate() {
            return this.openAccountDate;
        }

        public String getPrincipalAmount() {
            return this.principalAmount;
        }

        public String getProductDescI18N() {
            return this.productDescI18N;
        }

        public String getProductID() {
            return this.productID;
        }

        public String getProductName() {
            return this.productName;
        }

        public String getProductNameI18N() {
            return this.productNameI18N;
        }

        public String getProductRateValue() {
            return this.productRateValue;
        }

        public String getProductRateValueMode() {
            return this.productRateValueMode;
        }

        public String getProductUnquieID() {
            return this.productUnquieID;
        }

        public String getStatus() {
            return this.status;
        }

        public String getTotalCapitalizationAmount() {
            return this.totalCapitalizationAmount;
        }

        public String getUnclearingBalance() {
            return this.unclearingBalance;
        }

        public void setAccountNo(String str) {
            this.accountNo = str;
        }

        public void setAccountType(String str) {
            this.accountType = str;
        }

        public void setAccruedInterest(String str) {
            this.accruedInterest = str;
        }

        public void setAvailableBalance(String str) {
            this.availableBalance = str;
        }

        public void setBalance(String str) {
            this.balance = str;
        }

        public void setCreateTime(String str) {
            this.createTime = str;
        }

        public void setCurrency(String str) {
            this.currency = str;
        }

        public void setCustAccountNo(String str) {
            this.custAccountNo = str;
        }

        public void setFrozenBalance(String str) {
            this.frozenBalance = str;
        }

        public void setMaturityDate(String str) {
            this.maturityDate = str;
        }

        public void setOpenAccountDate(String str) {
            this.openAccountDate = str;
        }

        public void setPrincipalAmount(String str) {
            this.principalAmount = str;
        }

        public void setProductDescI18N(String str) {
            this.productDescI18N = str;
        }

        public void setProductID(String str) {
            this.productID = str;
        }

        public void setProductName(String str) {
            this.productName = str;
        }

        public void setProductNameI18N(String str) {
            this.productNameI18N = str;
        }

        public void setProductRateValue(String str) {
            this.productRateValue = str;
        }

        public void setProductRateValueMode(String str) {
            this.productRateValueMode = str;
        }

        public void setProductUnquieID(String str) {
            this.productUnquieID = str;
        }

        public void setStatus(String str) {
            this.status = str;
        }

        public void setTotalCapitalizationAmount(String str) {
            this.totalCapitalizationAmount = str;
        }

        public void setUnclearingBalance(String str) {
            this.unclearingBalance = str;
        }
    }

    public List<AccountItemsBean> getAccountItems() {
        return this.accountItems;
    }

    public String getEndNumberOfReturned() {
        return this.endNumberOfReturned;
    }

    public String getNumberOfTotal() {
        return this.numberOfTotal;
    }

    public String getStartNumberOfReturned() {
        return this.startNumberOfReturned;
    }

    public void setAccountItems(List<AccountItemsBean> list) {
        this.accountItems = list;
    }

    public void setEndNumberOfReturned(String str) {
        this.endNumberOfReturned = str;
    }

    public void setNumberOfTotal(String str) {
        this.numberOfTotal = str;
    }

    public void setStartNumberOfReturned(String str) {
        this.startNumberOfReturned = str;
    }
}
