package com.huawei.ethiopia.finance.saving.activity;

import D6.a;
import V7.e;
import W1.b;
import W2.n;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.view.G;
import com.blankj.utilcode.util.f;
import com.huawei.astp.macle.ui.w;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountBinding;
import com.huawei.ethiopia.finance.saving.adapter.LockedSavingAccountAdapter;
import com.huawei.ethiopia.finance.saving.viewmodel.LockedSavingViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import p5.g;

public class LockedSavingAccountActivity extends DataBindingActivity<FinanceActivityLockedSavingAccountBinding, LockedSavingViewModel> {
    public static final /* synthetic */ int j = 0;
    public LockedSavingAccountAdapter d;
    public String e;
    public b.b f;
    public String g;
    public String h;
    public String i;

    public final int C0() {
        return R$layout.finance_activity_locked_saving_account;
    }

    public final void E0(boolean z) {
        String str;
        if (z) {
            this.b.a.b.setText("****");
            n b = n.b("");
            b.h(this.h + "_" + g.k() + "_FixedSaving", true);
            this.b.a.a.setImageResource(R$mipmap.homev6_icon_eyes_close);
            return;
        }
        TextView textView = this.b.a.b;
        if (TextUtils.isEmpty(this.i)) {
            str = "0.00";
        } else {
            str = this.i;
        }
        textView.setText(str);
        n b2 = n.b("");
        b2.h(this.h + "_" + g.k() + "_FixedSaving", false);
        this.b.a.a.setImageResource(R$mipmap.homev6_icon_eyes_open);
    }

    public final boolean F0() {
        n b = n.b("");
        return b.a.getBoolean(this.h + "_" + g.k() + "_FixedSaving", true);
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.ethiopia.finance.saving.activity.LockedSavingAccountActivity, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        LockedSavingAccountActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.finance_main_color), false);
        String string = getString(R$string.my_telebirr_sinq);
        if (!(g.i().a == null || g.i().a.getFinanceServiceUIConfig() == null || g.i().a.getFinanceServiceUIConfig().getSaving() == null || TextUtils.isEmpty(g.i().a.getFinanceServiceUIConfig().getSaving().getMySavingTxt()))) {
            string = g.i().a.getFinanceServiceUIConfig().getSaving().getMySavingTxt();
        }
        e.a(this, string, R$layout.finance_toolbar);
        this.e = getIntent().getStringExtra("fundsLenderId");
        this.g = getIntent().getStringExtra("productId");
        this.h = getIntent().getStringExtra("bankCode");
        LockedSavingAccountAdapter lockedSavingAccountAdapter = new LockedSavingAccountAdapter();
        this.d = lockedSavingAccountAdapter;
        lockedSavingAccountAdapter.a = new Y4.e(this);
        TextView textView = (TextView) ((ViewGroup) this.a.getWindow().getDecorView()).findViewWithTag("tag_toolbar").findViewById(R$id.tv_closed);
        textView.setVisibility(0);
        textView.setOnClickListener(new w(this, 2));
        this.b.a.a.setOnClickListener(new a(this, 5));
        E0(F0());
        this.b.b.setAdapter(this.d);
        this.c.a.observe(this, new com.huawei.module_checkout.startpay.activity.b(this, 1));
        this.c.b.observe(this, new com.huawei.ethiopia.finance.market.a(this, 1));
        this.c.a(this.e, true);
        b.b c = b.b().c(this.b.b);
        c.b = new G(this, 3);
        this.f = c;
    }
}
