package com.huawei.ethiopia.finance.loan.activity;

import android.view.View;

public final class j implements View.OnClickListener {
    public final /* synthetic */ FinanceServiceCBEActivity a;

    public j(FinanceServiceCBEActivity financeServiceCBEActivity) {
        this.a = financeServiceCBEActivity;
    }

    public final void onClick(View view) {
        int i = FinanceServiceCBEActivity.d;
        this.a.E0(0);
    }
}
