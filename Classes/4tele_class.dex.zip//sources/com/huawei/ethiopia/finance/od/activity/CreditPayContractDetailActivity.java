package com.huawei.ethiopia.finance.od.activity;

import V7.c;
import V7.e;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Window;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityCreditContractDetailBinding;
import com.huawei.ethiopia.finance.databinding.FinanceCreditContractDetailHeadBinding;
import com.huawei.ethiopia.finance.od.adapter.CreditPayTransactionAdapter;
import com.huawei.ethiopia.finance.od.viewmodel.CreditPayContractDetailViewModel;
import com.huawei.ethiopia.finance.resp.CreditPayContractsInfo;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import f5.C0078a;
import java.util.Map;
import o0.b;

@Route(path = "/finance/creditContractDetail")
public class CreditPayContractDetailActivity extends DataBindingActivity<FinanceActivityCreditContractDetailBinding, CreditPayContractDetailViewModel> {
    public static final /* synthetic */ int h = 0;
    public CreditPayTransactionAdapter d;
    public FinanceCreditContractDetailHeadBinding e;
    public CreditPayContractsInfo f;
    public String g;

    public final int C0() {
        return R$layout.finance_activity_credit_contract_detail;
    }

    public final void E0(CreditPayContractsInfo creditPayContractsInfo) {
        String str;
        TextView textView = this.e.d;
        String str2 = "";
        if (TextUtils.isEmpty(creditPayContractsInfo.getShowOdDetailAmountTitle())) {
            str = str2;
        } else {
            str = creditPayContractsInfo.getShowOdDetailAmountTitle();
        }
        textView.setText(str);
        TextView textView2 = this.e.e;
        if (!TextUtils.isEmpty(creditPayContractsInfo.getShowAmount())) {
            str2 = creditPayContractsInfo.getShowAmount();
        }
        textView2.setText(str2);
        this.e.a.setContent(creditPayContractsInfo.getContractId());
        this.e.c.setContent(creditPayContractsInfo.getDueDate());
        this.e.b.setContent(creditPayContractsInfo.getContractState());
        RoundTextView tvContent = this.e.b.getTvContent();
        tvContent.setTextColor(creditPayContractsInfo.getStateTextColor());
        tvContent.setBackgroundColor(creditPayContractsInfo.getStateBackground());
        this.e.f.setText(this.g);
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        CreditPayContractDetailActivity.super.onActivityResult(i, i2, intent);
        if (i == 1111 && i2 == -1 && intent != null) {
            b.d((Activity) null, "/finance/transactionResult", (Bundle) null, (Map) null);
        }
    }

    /* JADX WARNING: type inference failed for: r1v11, types: [com.huawei.http.b, com.huawei.ethiopia.finance.od.repository.QueryOdContractDetailRepository] */
    public final void onCreate(@Nullable Bundle bundle) {
        CreditPayContractDetailActivity.super.onCreate(bundle);
        Window window = getWindow();
        int i = R$color.colorPageBackgroundDark;
        window.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, i)));
        f.e(this, ContextCompat.getColor(this, i), false);
        e.a(this, getString(R$string.contract_details), R.layout.common_toolbar);
        this.b.a.setLayoutManager(new LinearLayoutManager(this));
        CreditPayTransactionAdapter creditPayTransactionAdapter = new CreditPayTransactionAdapter();
        this.d = creditPayTransactionAdapter;
        this.b.a.setAdapter(creditPayTransactionAdapter);
        this.g = getIntent().getStringExtra("title");
        this.f = (CreditPayContractsInfo) getIntent().getSerializableExtra("contractsInfo");
        FinanceCreditContractDetailHeadBinding inflate = DataBindingUtil.inflate(getLayoutInflater(), R$layout.finance_credit_contract_detail_head, this.b.a, false);
        this.e = inflate;
        this.b.a.a(-1, inflate.getRoot());
        this.c.a.observe(this, new C0078a(this));
        CreditPayContractDetailViewModel creditPayContractDetailViewModel = this.c;
        String contractId = this.f.getContractId();
        creditPayContractDetailViewModel.a.setValue(c.c());
        ? bVar = new com.huawei.http.b();
        bVar.addParams("contractId", contractId);
        creditPayContractDetailViewModel.b = bVar;
        bVar.sendRequest(new I4.e(creditPayContractDetailViewModel, 2));
        E0(this.f);
    }
}
