package com.huawei.ethiopia.finance.loan.activity;

import com.alibaba.android.arouter.facade.annotation.Route;

@Route(path = "/finance/loanRestructureResult")
public class LoanRestructureResultActivity extends FinanceResultActivity {
    /* JADX WARNING: type inference failed for: r0v0, types: [android.app.Activity] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void E0() {
        /*
            r6 = this;
            r4 = 67108864(0x4000000, float:1.5046328E-36)
            r5 = -1
            java.lang.String r1 = "/finance/finance"
            r2 = 0
            r3 = 0
            r0 = r6
            o0.b.e(r0, r1, r2, r3, r4, r5)
            r6.finish()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.loan.activity.LoanRestructureResultActivity.E0():void");
    }

    public final void onBackPressed() {
        E0();
    }
}
