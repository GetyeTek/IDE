package com.huawei.ethiopia.finance.market;

import androidx.lifecycle.Observer;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.ActivityLoanMarketBinding;
import com.huawei.ethiopia.finance.market.dialog.ShowLoanLimitBean;
import com.huawei.payment.mvvm.DataBindingActivity;

public final /* synthetic */ class k implements Observer {
    public final /* synthetic */ LoanProductsMarketActivity a;

    public /* synthetic */ k(LoanProductsMarketActivity loanProductsMarketActivity) {
        this.a = loanProductsMarketActivity;
    }

    public final void onChanged(Object obj) {
        ShowLoanLimitBean showLoanLimitBean = (ShowLoanLimitBean) obj;
        int i = LoanProductsMarketActivity.v;
        DataBindingActivity dataBindingActivity = this.a;
        dataBindingActivity.getClass();
        if (showLoanLimitBean.isUpdate()) {
            dataBindingActivity.n = showLoanLimitBean.getBankCode();
            String string = dataBindingActivity.getString(R$string.maximum_credit_limit);
            ActivityLoanMarketBinding activityLoanMarketBinding = dataBindingActivity.b;
            dataBindingActivity.M0("KEY_LOAN_MAX_LIMIT", string, activityLoanMarketBinding.i, activityLoanMarketBinding.j);
            String string2 = dataBindingActivity.getString(R$string.available_credit_limit);
            ActivityLoanMarketBinding activityLoanMarketBinding2 = dataBindingActivity.b;
            dataBindingActivity.M0("KEY_AVAILABLE_MELA_LIMIT", string2, activityLoanMarketBinding2.f, activityLoanMarketBinding2.g);
        }
    }
}
