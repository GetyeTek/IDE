package com.huawei.ethiopia.finance.saving.repository;

import com.huawei.ethiopia.finance.resp.SavingTransactionResult;
import com.huawei.http.b;
import java.util.HashMap;

public class DepositWithDrawRepository extends b<SavingTransactionResult, SavingTransactionResult> {
    public final String a;

    public DepositWithDrawRepository(String str, HashMap hashMap) {
        addParams(hashMap);
        this.a = str;
    }

    public final String getApiPath() {
        return this.a;
    }
}
