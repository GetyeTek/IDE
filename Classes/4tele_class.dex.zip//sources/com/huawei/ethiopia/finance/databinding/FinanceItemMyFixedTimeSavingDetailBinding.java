package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemMyFixedTimeSavingDetailBinding extends ViewDataBinding {
    @NonNull
    public final TextView a;
    @NonNull
    public final RoundTextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;

    public FinanceItemMyFixedTimeSavingDetailBinding(DataBindingComponent dataBindingComponent, View view, TextView textView, RoundTextView roundTextView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = textView;
        this.b = roundTextView;
        this.c = textView2;
        this.d = textView3;
    }
}
