package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.banner.CycleViewPager;
import com.huawei.ethiopia.finance.widget.LoanAmountLimitView;

public abstract class ActivityFinanceMarketGuideBinding extends ViewDataBinding {
    @NonNull
    public final Button a;
    @NonNull
    public final CycleViewPager b;
    @NonNull
    public final ImageView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final LinearLayout e;
    @NonNull
    public final LoanAmountLimitView f;
    @NonNull
    public final RecyclerView g;

    public ActivityFinanceMarketGuideBinding(DataBindingComponent dataBindingComponent, View view, Button button, CycleViewPager cycleViewPager, ImageView imageView, ImageView imageView2, LinearLayout linearLayout, LoanAmountLimitView loanAmountLimitView, RecyclerView recyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = button;
        this.b = cycleViewPager;
        this.c = imageView;
        this.d = imageView2;
        this.e = linearLayout;
        this.f = loanAmountLimitView;
        this.g = recyclerView;
    }
}
