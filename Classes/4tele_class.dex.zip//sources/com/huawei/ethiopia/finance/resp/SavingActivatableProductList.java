package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;
import java.util.List;

public class SavingActivatableProductList extends BaseResp {
    private List<SavingActivatableProduct> productList;

    public List<SavingActivatableProduct> getProductList() {
        return this.productList;
    }

    public void setProductList(List<SavingActivatableProduct> list) {
        this.productList = list;
    }
}
