package com.huawei.ethiopia.finance.od.repository;

import com.huawei.ethiopia.finance.resp.CreditContractsInfo;
import com.huawei.http.b;

public class QueryOdContractDetailRepository extends b<CreditContractsInfo, CreditContractsInfo> {
    public final String getApiPath() {
        return "v1/ethiopia/od/contract/detail";
    }
}
