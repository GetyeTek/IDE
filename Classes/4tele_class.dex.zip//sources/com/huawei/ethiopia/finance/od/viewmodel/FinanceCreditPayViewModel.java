package com.huawei.ethiopia.finance.od.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.loan.repository.QueryCreditPayContractsRepository;
import com.huawei.ethiopia.finance.od.repository.DeactivateCreditRepository;
import com.huawei.ethiopia.finance.resp.CreditPayContractsListResp;
import com.huawei.http.BaseResp;

public class FinanceCreditPayViewModel extends ViewModel {
    public final MutableLiveData<c<CreditPayContractsListResp>> a = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> b = new MutableLiveData<>();
    public QueryCreditPayContractsRepository c;
    public DeactivateCreditRepository d;

    public final void onCleared() {
        FinanceCreditPayViewModel.super.onCleared();
        QueryCreditPayContractsRepository queryCreditPayContractsRepository = this.c;
        if (queryCreditPayContractsRepository != null) {
            queryCreditPayContractsRepository.cancel();
        }
        DeactivateCreditRepository deactivateCreditRepository = this.d;
        if (deactivateCreditRepository != null) {
            deactivateCreditRepository.cancel();
        }
    }
}
