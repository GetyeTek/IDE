package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceActivityApplyLoanProductBindingImpl extends FinanceActivityApplyLoanProductBinding {
    @Nullable
    public static final SparseIntArray i;
    public long h;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        i = sparseIntArray;
        sparseIntArray.put(R$id.tv_title, 1);
        sparseIntArray.put(R$id.cl_input, 2);
        sparseIntArray.put(R$id.et_input, 3);
        sparseIntArray.put(R$id.tv_unit, 4);
        sparseIntArray.put(R$id.tv_error, 5);
        sparseIntArray.put(R$id.tv_amount, 6);
        sparseIntArray.put(R$id.recycler_view, 7);
        sparseIntArray.put(R$id.ll_button, 8);
        sparseIntArray.put(R$id.btn_confirm, 9);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.h = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.h != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.h = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i2, Object obj, int i3) {
        return false;
    }

    public final boolean setVariable(int i2, @Nullable Object obj) {
        return true;
    }
}
