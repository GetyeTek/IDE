package com.huawei.ethiopia.finance.loan.adapter;

import android.graphics.drawable.Drawable;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.camera.camera2.internal.P;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactsBinding;
import com.huawei.ethiopia.finance.resp.AppRepaymentSchedule;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import java.util.List;
import p5.g;

public class FinanceLoanContactsAdapter extends BaseQuickAdapter<LoanContractsInfo, BaseViewHolder> {
    public FinanceLoanContactsAdapter() {
        super(R$layout.finance_item_loan_contacts);
        addChildClickViewIds(new int[]{R$id.view, R$id.btn_repay, R$id.tvDate, R$id.btn_extend});
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i;
        LoanContractsInfo loanContractsInfo = (LoanContractsInfo) obj;
        FinanceItemLoanContactsBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        if (bind != null) {
            boolean isActive = loanContractsInfo.isActive();
            RoundTextView roundTextView = bind.h;
            TextView textView = bind.e;
            RoundTextView roundTextView2 = bind.b;
            if (isActive) {
                roundTextView.setVisibility(8);
                if (loanContractsInfo.isAllowRollover()) {
                    i = 0;
                } else {
                    i = 8;
                }
                bind.a.setVisibility(i);
                roundTextView2.setVisibility(0);
            } else {
                textView.setCompoundDrawables((Drawable) null, (Drawable) null, (Drawable) null, (Drawable) null);
                roundTextView.setVisibility(0);
                roundTextView2.setVisibility(8);
            }
            boolean isInstallments = loanContractsInfo.isInstallments();
            TextView textView2 = bind.d;
            TextView textView3 = bind.f;
            if (isInstallments) {
                textView3.setVisibility(0);
                textView3.setText(String.format("(%1$s/%2$s)", new Object[]{loanContractsInfo.getCurrentInstallment(), loanContractsInfo.getTotalInstallments()}));
                List<AppRepaymentSchedule> repaymentSchedules = loanContractsInfo.getRepaymentSchedules();
                if (repaymentSchedules == null || repaymentSchedules.isEmpty()) {
                    textView2.setText(loanContractsInfo.getLoanBalance());
                    textView.setText(loanContractsInfo.getContractId());
                    textView3.setVisibility(8);
                    roundTextView2.setEnabled(false);
                    roundTextView2.setBackgroundColor(ContextCompat.getColor(J.a(), R$color.colorInputBoxUnFocus));
                } else {
                    AppRepaymentSchedule appRepaymentSchedule = repaymentSchedules.get(0);
                    textView2.setText(appRepaymentSchedule.getTotalScheduleAmount());
                    textView.setText(String.format("%1$s %2$s", new Object[]{J.a().getString(R$string.due_date), appRepaymentSchedule.getEndDate()}));
                    roundTextView2.setEnabled(true);
                    roundTextView2.setBackgroundColor(ContextCompat.getColor(J.a(), R$color.colorPrimary));
                }
            } else {
                textView2.setText(loanContractsInfo.getLoanBalance());
                textView.setText(loanContractsInfo.getContractId());
                textView3.setVisibility(8);
                roundTextView2.setEnabled(true);
                roundTextView2.setBackgroundColor(ContextCompat.getColor(J.a(), R$color.colorPrimary));
            }
            bind.g.setText(P.a("(", g.g(), ")"));
        }
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return FinanceLoanContactsAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
