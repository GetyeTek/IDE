package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class ActivityLoanMarketBinding extends ViewDataBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final RoundLinearLayout b;
    @NonNull
    public final TextView c;
    @NonNull
    public final RoundRecyclerView d;
    @NonNull
    public final RecyclerView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final RoundTextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final RoundTextView k;
    @NonNull
    public final TextView l;
    @NonNull
    public final TextView m;
    @NonNull
    public final TextView n;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ActivityLoanMarketBinding(DataBindingComponent dataBindingComponent, View view, RoundConstraintLayout roundConstraintLayout, RoundLinearLayout roundLinearLayout, TextView textView, RoundRecyclerView roundRecyclerView, RecyclerView recyclerView, TextView textView2, TextView textView3, RoundTextView roundTextView, TextView textView4, TextView textView5, RoundTextView roundTextView2, TextView textView6, TextView textView7, TextView textView8) {
        super(dataBindingComponent, view, 0);
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        this.a = roundConstraintLayout;
        this.b = roundLinearLayout;
        this.c = textView;
        this.d = roundRecyclerView;
        this.e = recyclerView;
        this.f = textView2;
        this.g = textView3;
        this.h = roundTextView;
        this.i = textView4;
        this.j = textView5;
        this.k = roundTextView2;
        this.l = textView6;
        this.m = textView7;
        this.n = textView8;
    }
}
