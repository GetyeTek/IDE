package com.huawei.ethiopia.finance.od.adapter;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayProductGroupBinding;
import com.huawei.ethiopia.finance.resp.CreditPayContractsGroup;
import g5.C0086a;

public class FinanceCreditPayGroupAdapter extends BaseQuickAdapter<CreditPayContractsGroup, BaseViewHolder> {
    public static final /* synthetic */ int a = 0;

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        CreditPayContractsGroup creditPayContractsGroup = (CreditPayContractsGroup) obj;
        FinanceItemCreditPayProductGroupBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        bind.b.setText(creditPayContractsGroup.getGroupName());
        RecyclerView recyclerView = bind.a;
        recyclerView.setNestedScrollingEnabled(false);
        FinanceCreditPayContactsAdapter financeCreditPayContactsAdapter = new FinanceCreditPayContactsAdapter();
        financeCreditPayContactsAdapter.setOnItemChildClickListener(new C0086a(financeCreditPayContactsAdapter, creditPayContractsGroup));
        recyclerView.setAdapter(financeCreditPayContactsAdapter);
        financeCreditPayContactsAdapter.setNewData(creditPayContractsGroup.getContractItems());
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return FinanceCreditPayGroupAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
