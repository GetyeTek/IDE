package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;

public class FinanceBankConfig implements Serializable {
    private String bankCode;
    private String fundsLenderId;

    public String getBankCode() {
        return this.bankCode;
    }

    public String getFundsLenderId() {
        return this.fundsLenderId;
    }

    public void setBankCode(String str) {
        this.bankCode = str;
    }

    public void setFundsLenderId(String str) {
        this.fundsLenderId = str;
    }
}
