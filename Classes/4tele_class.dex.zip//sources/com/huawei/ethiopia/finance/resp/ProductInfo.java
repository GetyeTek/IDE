package com.huawei.ethiopia.finance.resp;

import android.text.TextUtils;
import com.huawei.http.BaseResp;
import java.util.ArrayList;
import java.util.List;

public class ProductInfo extends BaseResp {
    private boolean allowApplyNPL;
    private String avaiableLimit;
    private String companyName;
    private String creditSystemId;
    private String description;
    private List<LoanContractsInfo> loanContractsInfos;
    private String logo;
    private String maxLimit;
    private String minLimit;
    private ProductDetailInfo productDetailInfo;
    private String productId;
    private String productName;
    private String productNameI18n;
    private String serviceTypeId;
    private boolean show;
    private String strategyId;
    private int termDays;

    public void addLoanContractsInfo(LoanContractsInfo loanContractsInfo) {
        if (this.loanContractsInfos == null) {
            this.loanContractsInfos = new ArrayList();
        }
        this.loanContractsInfos.add(loanContractsInfo);
    }

    public void clearLoanContractsInfos() {
        List<LoanContractsInfo> list = this.loanContractsInfos;
        if (list != null) {
            list.clear();
        }
    }

    public String getAvaiableLimit() {
        return this.avaiableLimit;
    }

    public String getCompanyName() {
        return this.companyName;
    }

    public String getCreditSystemId() {
        return this.creditSystemId;
    }

    public String getDescription() {
        String str = this.description;
        if (str == null) {
            return "";
        }
        return str;
    }

    public List<LoanContractsInfo> getLoanContractsInfos() {
        return this.loanContractsInfos;
    }

    public String getLogo() {
        return this.logo;
    }

    public String getMaxLimit() {
        return this.maxLimit;
    }

    public String getMinLimit() {
        return this.minLimit;
    }

    public ProductDetailInfo getProductDetailInfo() {
        return this.productDetailInfo;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getProductName() {
        return this.productName;
    }

    public String getProductNameI18n() {
        if (!TextUtils.isEmpty(this.productNameI18n)) {
            return this.productNameI18n;
        }
        return this.productName;
    }

    public String getServiceTypeId() {
        return this.serviceTypeId;
    }

    public String getStrategyId() {
        return this.strategyId;
    }

    public int getTermDays() {
        return this.termDays;
    }

    public boolean isAllowApplyNPL() {
        return this.allowApplyNPL;
    }

    public boolean isShow() {
        return this.show;
    }

    public void setAllowApplyNPL(boolean z) {
        this.allowApplyNPL = z;
    }

    public void setAvaiableLimit(String str) {
        this.avaiableLimit = str;
    }

    public void setCompanyName(String str) {
        this.companyName = str;
    }

    public void setCreditSystemId(String str) {
        this.creditSystemId = str;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public void setLogo(String str) {
        this.logo = str;
    }

    public void setMaxLimit(String str) {
        this.maxLimit = str;
    }

    public void setMinLimit(String str) {
        this.minLimit = str;
    }

    public void setProductDetailInfo(ProductDetailInfo productDetailInfo2) {
        this.productDetailInfo = productDetailInfo2;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setProductName(String str) {
        this.productName = str;
    }

    public void setProductNameI18n(String str) {
        this.productNameI18n = str;
    }

    public void setServiceTypeId(String str) {
        this.serviceTypeId = str;
    }

    public void setShow(boolean z) {
        this.show = z;
    }

    public void setStrategyId(String str) {
        this.strategyId = str;
    }

    public void setTermDays(int i) {
        this.termDays = i;
    }
}
