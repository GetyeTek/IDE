package com.huawei.ethiopia.finance.saving.activity;

import N3.c;
import V7.e;
import W1.b;
import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.camera.core.W;
import androidx.core.content.ContextCompat;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.v;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.digitalpayment.customer.httplib.repository.BannerRepository;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.constants.TransactionType;
import com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBinding;
import com.huawei.ethiopia.finance.resp.SavingProductInfo;
import com.huawei.ethiopia.finance.saving.adapter.SavingTransactionAdapter;
import com.huawei.ethiopia.finance.saving.viewmodel.SavingProductDetailViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import f5.C0079b;
import g4.h;
import java.util.Map;
import p5.g;

@Route(path = "/finance/savingProductDetail")
public class SavingProductDetailActivity extends DataBindingActivity<FinanceActivitySavingProductDetailBinding, SavingProductDetailViewModel> {
    public static final /* synthetic */ int l = 0;
    public String d;
    public String e;
    public String f;
    public SavingTransactionAdapter g;
    public SavingProductInfo h;
    public ViewDataBinding i;
    public b.b j;
    public String k;

    public final int C0() {
        return R$layout.finance_activity_saving_product_detail;
    }

    public final void E0(SavingProductInfo savingProductInfo) {
        this.b.a.a.setText(savingProductInfo.getDepositAmountTitle());
        this.b.a.b.setText(savingProductInfo.getBalance());
        this.b.a.d.setText(savingProductInfo.getRateValue());
        this.b.a.c.setText(savingProductInfo.getInterestRateTitle());
        this.b.a.f.setText(savingProductInfo.getAccruedInterest());
        this.b.a.e.setText(savingProductInfo.getTotalGainsTitle());
    }

    public final void F0(TransactionType transactionType) {
        String str;
        if (transactionType == TransactionType.DEPOSIT) {
            str = g.m();
        } else {
            SavingProductInfo savingProductInfo = this.h;
            if (savingProductInfo != null) {
                str = savingProductInfo.getBalance();
            } else {
                str = "0.00";
            }
        }
        Bundle bundle = new Bundle(2);
        bundle.putSerializable("transactionType", transactionType);
        bundle.putString("limitAmountValue", str);
        bundle.putString("productId", this.d);
        bundle.putString("accountNo", this.e);
        bundle.putString("productUnquieID", this.f);
        bundle.putString("bankCode", this.k);
        o0.b.d((Activity) null, "/finance/savingTransaction", bundle, (Map) null);
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.ethiopia.finance.saving.activity.SavingProductDetailActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        SavingProductDetailActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getIntent().getStringExtra("productName"), R.layout.common_toolbar);
        b.b c = b.b().c(this.b.c);
        c.b = new W(this, 2);
        this.j = c;
        this.d = getIntent().getStringExtra("productId");
        this.e = getIntent().getStringExtra("accountNo");
        this.f = getIntent().getStringExtra("productUnquieID");
        this.b.d.setLayoutManager(new LinearLayoutManager(this));
        SavingTransactionAdapter savingTransactionAdapter = new SavingTransactionAdapter();
        this.g = savingTransactionAdapter;
        savingTransactionAdapter.a = new androidx.camera.view.e(this);
        this.b.d.setAdapter(savingTransactionAdapter);
        this.b.d.clearAnimation();
        this.b.d.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(this, R$color.colorDividerLight), v.a(1.0f)));
        this.k = getIntent().getStringExtra("bankCode");
        this.b.e.setOnClickListener(new h(this, 2));
        this.b.f.setOnClickListener(new c(this, 4));
        E0(new SavingProductInfo());
        this.c.b.observe(this, new com.huawei.digitalpayment.schedule.activity.g(this, 2));
        this.c.a.observe(this, new C0079b(this, 2));
        SavingProductDetailViewModel savingProductDetailViewModel = this.c;
        savingProductDetailViewModel.getClass();
        BannerRepository bannerRepository = new BannerRepository("Application Page", "Finance Saving");
        savingProductDetailViewModel.c = bannerRepository;
        bannerRepository.sendRequest(new I4.f(savingProductDetailViewModel, 2));
    }

    public final void onResume() {
        SavingProductDetailActivity.super.onResume();
        this.c.a(this.f);
    }
}
