package com.huawei.ethiopia.finance.saving.adapter;

import android.text.TextUtils;
import android.widget.ImageView;
import androidx.databinding.ViewDataBinding;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.databinding.FinanceItemSavingCanActiveProductBinding;
import com.huawei.ethiopia.finance.resp.SavingActivatableProduct;
import com.huawei.payment.mvvm.DataBindingAdapter;
import java.util.HashMap;
import p5.g;
import y5.C0116b;

public class SavingCanActiveProductAdapter extends DataBindingAdapter<SavingActivatableProduct, FinanceItemSavingCanActiveProductBinding> {
    public static final HashMap e;
    public String c = "Dashen";
    public SavingActivatableProduct d;

    static {
        HashMap hashMap = new HashMap();
        e = hashMap;
        hashMap.put("Interest Free", Integer.valueOf(R$mipmap.finance_ic_interest_free));
        hashMap.put("Interest Bearing", Integer.valueOf(R$mipmap.finance_ic_interest_bearing));
    }

    public final int a() {
        return R$layout.finance_item_saving_can_active_product;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        int i2;
        String str;
        String str2;
        int i3;
        FinanceItemSavingCanActiveProductBinding financeItemSavingCanActiveProductBinding = (FinanceItemSavingCanActiveProductBinding) viewDataBinding;
        SavingActivatableProduct savingActivatableProduct = (SavingActivatableProduct) obj;
        Integer num = (Integer) e.get(savingActivatableProduct.getProductName());
        ImageView imageView = financeItemSavingCanActiveProductBinding.a;
        String iconUrl = savingActivatableProduct.getIconUrl();
        if (num == null) {
            i2 = 0;
        } else {
            i2 = num.intValue();
        }
        C0116b.c(imageView, iconUrl, i2);
        if (TextUtils.isEmpty(savingActivatableProduct.getProductNameI18n())) {
            str = savingActivatableProduct.getProductName();
        } else {
            str = savingActivatableProduct.getProductNameI18n();
        }
        financeItemSavingCanActiveProductBinding.e.setText(str);
        if (TextUtils.isEmpty(savingActivatableProduct.getProductDescI18n())) {
            str2 = savingActivatableProduct.getDescription();
        } else {
            str2 = savingActivatableProduct.getProductDescI18n();
        }
        financeItemSavingCanActiveProductBinding.d.setText(str2);
        SavingActivatableProduct savingActivatableProduct2 = this.d;
        if (savingActivatableProduct2 == null || !TextUtils.equals(savingActivatableProduct2.getProductId(), savingActivatableProduct.getProductId())) {
            i3 = R$mipmap.ic_checkbox_unchecked;
        } else {
            i3 = R$mipmap.ic_checkbox_checked;
        }
        financeItemSavingCanActiveProductBinding.b.setImageResource(i3);
        financeItemSavingCanActiveProductBinding.c.getBaseFilletView().e(g.f(financeItemSavingCanActiveProductBinding.getRoot().getContext(), g.i().a, this.c));
    }
}
