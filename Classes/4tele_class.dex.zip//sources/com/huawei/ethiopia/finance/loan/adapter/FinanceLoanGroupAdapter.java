package com.huawei.ethiopia.finance.loan.adapter;

import X4.a;
import Y4.q;
import Y4.w;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductGroupBinding;

public class FinanceLoanGroupAdapter extends BaseQuickAdapter<w, BaseViewHolder> {
    public static final /* synthetic */ int d = 0;
    public final FragmentActivity a;
    public String b;
    public q c;

    public FinanceLoanGroupAdapter(FragmentActivity fragmentActivity) {
        super(R$layout.finance_item_loan_product_group);
        this.a = fragmentActivity;
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        w wVar = (w) obj;
        FinanceItemLoanProductGroupBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        bind.b.setText(wVar.a);
        RecyclerView recyclerView = bind.a;
        recyclerView.setNestedScrollingEnabled(false);
        FinanceLoanContactsAdapter financeLoanContactsAdapter = new FinanceLoanContactsAdapter();
        financeLoanContactsAdapter.setOnItemChildClickListener(new a(this, financeLoanContactsAdapter));
        recyclerView.setAdapter(financeLoanContactsAdapter);
        financeLoanContactsAdapter.setNewData(wVar.b);
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return FinanceLoanGroupAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
