package com.huawei.ethiopia.finance.saving.activity;

import A6.c;
import I4.g;
import V7.e;
import W1.b;
import Y4.t;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.paybill.activity.h;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivitySavingBinding;
import com.huawei.ethiopia.finance.saving.adapter.SavingProductAdapter;
import com.huawei.ethiopia.finance.saving.repository.QuerySavingAccountRepository;
import com.huawei.ethiopia.finance.saving.viewmodel.SavingViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.nio.charset.StandardCharsets;

@Route(path = "/finance/savingHome")
@Deprecated
public class SavingActivity extends DataBindingActivity<FinanceActivitySavingBinding, SavingViewModel> {
    public static final /* synthetic */ int g = 0;
    public SavingProductAdapter d;
    public b.b e;
    public String f;

    public final int C0() {
        return R$layout.finance_activity_saving;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        SavingActivity.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 100 && i2 == -1) {
            this.c.a(new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8), this.f);
        }
    }

    /* JADX WARNING: type inference failed for: r1v6, types: [java.lang.Object, java.lang.Runnable] */
    public final void onCreate(@Nullable Bundle bundle) {
        SavingActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getString(R$string.sanduq), R.layout.common_toolbar);
        this.f = getIntent().getStringExtra("fundsLenderId");
        getIntent().getStringExtra("bankCode");
        b.b c = b.b().c(this.b.e);
        c.b = new Object();
        this.e = c;
        this.b.e.setLayoutManager(new LinearLayoutManager(this));
        SavingProductAdapter savingProductAdapter = new SavingProductAdapter();
        this.d = savingProductAdapter;
        this.b.e.setAdapter(savingProductAdapter);
        this.b.a.setOnClickListener(new c(this, 4));
        this.c.b.observe(this, new h(this, 2));
        this.c.d.observe(this, new t(this, 1));
        SavingViewModel savingViewModel = this.c;
        String str = this.f;
        savingViewModel.b.setValue(V7.c.c());
        QuerySavingAccountRepository querySavingAccountRepository = new QuerySavingAccountRepository(str, false, true);
        savingViewModel.e = querySavingAccountRepository;
        querySavingAccountRepository.sendRequest(new g(savingViewModel, 5));
    }
}
