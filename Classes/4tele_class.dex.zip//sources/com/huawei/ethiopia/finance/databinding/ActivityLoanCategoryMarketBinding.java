package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.round.RoundConstraintLayout;

public abstract class ActivityLoanCategoryMarketBinding extends ViewDataBinding {
    @NonNull
    public final RoundConstraintLayout a;
    @NonNull
    public final RecyclerView b;

    public ActivityLoanCategoryMarketBinding(DataBindingComponent dataBindingComponent, View view, RoundConstraintLayout roundConstraintLayout, RecyclerView recyclerView) {
        super(dataBindingComponent, view, 0);
        this.a = roundConstraintLayout;
        this.b = recyclerView;
    }
}
