package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundLinearLayout;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemLoanProductBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final HorizontalScrollView b;
    @NonNull
    public final RoundConstraintLayout c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final LinearLayout e;
    @NonNull
    public final RoundRecyclerView f;
    @NonNull
    public final RoundLinearLayout g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;
    @NonNull
    public final TextView l;
    @NonNull
    public final TextView m;
    @NonNull
    public final TextView n;
    @NonNull
    public final TextView o;
    @NonNull
    public final TextView p;
    @NonNull
    public final TextView q;
    @NonNull
    public final TextView r;
    @NonNull
    public final TextView s;
    @NonNull
    public final TextView t;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FinanceItemLoanProductBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, HorizontalScrollView horizontalScrollView, RoundConstraintLayout roundConstraintLayout, ImageView imageView, LinearLayout linearLayout, RoundRecyclerView roundRecyclerView, RoundLinearLayout roundLinearLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11, TextView textView12, TextView textView13) {
        super(dataBindingComponent, view, 0);
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        this.a = roundTextView;
        this.b = horizontalScrollView;
        this.c = roundConstraintLayout;
        this.d = imageView;
        this.e = linearLayout;
        this.f = roundRecyclerView;
        this.g = roundLinearLayout;
        this.h = textView;
        this.i = textView2;
        this.j = textView3;
        this.k = textView4;
        this.l = textView5;
        this.m = textView6;
        this.n = textView7;
        this.o = textView8;
        this.p = textView9;
        this.q = textView10;
        this.r = textView11;
        this.s = textView12;
        this.t = textView13;
    }
}
