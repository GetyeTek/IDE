package com.huawei.ethiopia.finance.market;

import W1.b;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.viewpager.widget.ViewPager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding;
import com.huawei.ethiopia.finance.market.adapter.LoanMarketGuideAdapter;
import com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketModel;
import com.huawei.ethiopia.finance.widget.LoanAmountLimitView;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import p5.g;
import q5.C0107a;

@Route(path = "/finance/market")
public class FinanceMarketGuideActivity extends DataBindingActivity<ActivityFinanceMarketGuideBinding, FinanceMarketModel> {
    public static final /* synthetic */ int g = 0;
    public List<FinanceMarketBankConfig.FinanceMarketBankItem> d;
    public FinanceMarketBankConfig e;
    public b.b f;

    public class a implements View.OnClickListener {
        public a() {
        }

        public final void onClick(View view) {
            int i = FinanceMarketGuideActivity.g;
            FinanceMarketGuideActivity.this.c.a();
        }
    }

    public class b implements Comparator<FinanceMarketBankConfig.FinanceMarketBankItem> {
        public final int compare(Object obj, Object obj2) {
            return (int) (((FinanceMarketBankConfig.FinanceMarketBankItem) obj2).getTimestamp() - ((FinanceMarketBankConfig.FinanceMarketBankItem) obj).getTimestamp());
        }
    }

    public class c implements OnItemClickListener {
        public final void onItemClick(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter, @NonNull View view, int i) {
        }
    }

    public final int C0() {
        return R$layout.activity_finance_market_guide;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [java.lang.Object, com.huawei.common.widget.banner.CycleViewPager$c] */
    public final void E0() {
        List<HomeBannerBean> e2 = g.e();
        if (!J8.a.i(e2)) {
            if (e2 == null || e2.isEmpty()) {
                this.b.b.setVisibility(8);
                ViewPager findViewById = this.b.b.findViewById(R$id.cycle_view_pager);
                findViewById.setOffscreenPageLimit(2);
                findViewById.setPageMargin(v.a(16.0f));
                return;
            }
            this.b.b.setVisibility(0);
            this.b.b.c(e2, new Object(), 0);
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [java.lang.Object, java.util.Comparator] */
    /* JADX WARNING: type inference failed for: r1v8, types: [java.lang.Object, com.chad.library.adapter.base.listener.OnItemClickListener] */
    public final void F0() {
        List<FinanceMarketBankConfig.FinanceMarketBankItem> list = this.d;
        if (list != null) {
            Collections.sort(list, new Object());
            LoanMarketGuideAdapter loanMarketGuideAdapter = new LoanMarketGuideAdapter();
            loanMarketGuideAdapter.setList(this.d);
            this.b.g.setLayoutManager(new GridLayoutManager(this, 2));
            this.b.g.setAdapter(loanMarketGuideAdapter);
            loanMarketGuideAdapter.setOnItemClickListener(new Object());
        }
    }

    public final void G0() {
        FinanceMarketBankConfig financeMarketBankConfig = this.e;
        if (financeMarketBankConfig != null) {
            LoanAmountLimitView loanAmountLimitView = this.b.f;
            int maxAmountLimit = financeMarketBankConfig.getMaxAmountLimit();
            int maxAmountLimit2 = this.e.getMaxAmountLimit();
            loanAmountLimitView.getClass();
            if (maxAmountLimit >= 0 && maxAmountLimit2 >= 0 && maxAmountLimit2 <= maxAmountLimit) {
                loanAmountLimitView.d = maxAmountLimit;
                loanAmountLimitView.l = ((float) maxAmountLimit) / ((float) loanAmountLimitView.c);
                ValueAnimator ofInt = ValueAnimator.ofInt(new int[]{loanAmountLimitView.e, maxAmountLimit2});
                ofInt.setDuration(1000).addUpdateListener(new C0107a(loanAmountLimitView));
                ofInt.setInterpolator(new DecelerateInterpolator());
                ofInt.start();
            }
        }
    }

    /* JADX WARNING: type inference failed for: r6v18, types: [W4.a, java.lang.Object] */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x00b1, code lost:
        if (r6.equals("om") == false) goto L_0x0093;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r6) {
        /*
            r5 = this;
            r0 = 2
            r1 = 0
            r2 = 1
            com.huawei.ethiopia.finance.market.FinanceMarketGuideActivity.super.onCreate(r6)
            android.view.Window r6 = r5.getWindow()
            com.blankj.utilcode.util.f.g(r6)
            com.blankj.utilcode.util.f.e(r5, r1, r1)
            p5.i r6 = p5.i.e
            java.lang.String r3 = "financeMarket"
            r6.c = r3
            java.lang.String r4 = ""
            r6.b = r4
            r6.a = r3
            com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig r6 = p5.g.h()
            r5.e = r6
            if (r6 != 0) goto L_0x0039
            androidx.lifecycle.ViewModel r6 = r5.c
            com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketModel r6 = (com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketModel) r6
            r6.getClass()
            com.huawei.ethiopia.finance.loan.repository.QueryFinanceBankListRepository r3 = new com.huawei.ethiopia.finance.loan.repository.QueryFinanceBankListRepository
            r3.<init>()
            e5.a r4 = new e5.a
            r4.<init>(r6)
            r3.sendRequest(r4)
            goto L_0x0048
        L_0x0039:
            java.util.List r6 = p5.g.d()
            r5.d = r6
            r5.E0()
            r5.G0()
            r5.F0()
        L_0x0048:
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.Button r6 = r6.a
            com.huawei.ethiopia.finance.market.FinanceMarketGuideActivity$a r3 = new com.huawei.ethiopia.finance.market.FinanceMarketGuideActivity$a
            r3.<init>()
            r6.setOnClickListener(r3)
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.ImageView r6 = r6.d
            D6.k r3 = new D6.k
            r3.<init>(r5, r0)
            r6.setOnClickListener(r3)
            androidx.lifecycle.ViewModel r6 = r5.c
            com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketModel r6 = (com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketModel) r6
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig>> r6 = r6.c
            C4.b r3 = new C4.b
            r3.<init>(r5, r2)
            r6.observe(r5, r3)
            androidx.lifecycle.ViewModel r6 = r5.c
            com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketModel r6 = (com.huawei.ethiopia.finance.market.viewmodel.FinanceMarketModel) r6
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.ActiveState>> r6 = r6.e
            C4.c r3 = new C4.c
            r3.<init>(r5, r2)
            r6.observe(r5, r3)
            com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils r6 = com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils.getInstance()
            java.lang.String r6 = r6.getCurrentLang()
            r6.getClass()
            r3 = -1
            int r4 = r6.hashCode()
            switch(r4) {
                case 3116: goto L_0x00bf;
                case 3241: goto L_0x00b4;
                case 3550: goto L_0x00ab;
                case 3676: goto L_0x00a0;
                case 3701: goto L_0x0095;
                default: goto L_0x0093;
            }
        L_0x0093:
            r0 = -1
            goto L_0x00c9
        L_0x0095:
            java.lang.String r0 = "ti"
            boolean r6 = r6.equals(r0)
            if (r6 != 0) goto L_0x009e
            goto L_0x0093
        L_0x009e:
            r0 = 4
            goto L_0x00c9
        L_0x00a0:
            java.lang.String r0 = "so"
            boolean r6 = r6.equals(r0)
            if (r6 != 0) goto L_0x00a9
            goto L_0x0093
        L_0x00a9:
            r0 = 3
            goto L_0x00c9
        L_0x00ab:
            java.lang.String r2 = "om"
            boolean r6 = r6.equals(r2)
            if (r6 != 0) goto L_0x00c9
            goto L_0x0093
        L_0x00b4:
            java.lang.String r0 = "en"
            boolean r6 = r6.equals(r0)
            if (r6 != 0) goto L_0x00bd
            goto L_0x0093
        L_0x00bd:
            r0 = 1
            goto L_0x00c9
        L_0x00bf:
            java.lang.String r0 = "am"
            boolean r6 = r6.equals(r0)
            if (r6 != 0) goto L_0x00c8
            goto L_0x0093
        L_0x00c8:
            r0 = 0
        L_0x00c9:
            switch(r0) {
                case 0: goto L_0x0112;
                case 1: goto L_0x0106;
                case 2: goto L_0x00fa;
                case 3: goto L_0x00ee;
                case 4: goto L_0x00cd;
                default: goto L_0x00cc;
            }
        L_0x00cc:
            goto L_0x011d
        L_0x00cd:
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.ImageView r6 = r6.c
            int r0 = com.huawei.ethiopia.finance.R$mipmap.finance_market_guide_bg_ti
            r6.setImageResource(r0)
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.LinearLayout r6 = r6.e
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r6 = (android.widget.FrameLayout.LayoutParams) r6
            r0 = 1132593152(0x43820000, float:260.0)
            int r0 = R9.h.a(r5, r0)
            r6.setMargins(r1, r0, r1, r1)
            goto L_0x011d
        L_0x00ee:
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.ImageView r6 = r6.c
            int r0 = com.huawei.ethiopia.finance.R$mipmap.finance_market_guide_bg_so
            r6.setImageResource(r0)
            goto L_0x011d
        L_0x00fa:
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.ImageView r6 = r6.c
            int r0 = com.huawei.ethiopia.finance.R$mipmap.finance_market_guide_bg_om
            r6.setImageResource(r0)
            goto L_0x011d
        L_0x0106:
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.ImageView r6 = r6.c
            int r0 = com.huawei.ethiopia.finance.R$mipmap.finance_market_guide_bg_en
            r6.setImageResource(r0)
            goto L_0x011d
        L_0x0112:
            androidx.databinding.ViewDataBinding r6 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r6 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r6
            android.widget.ImageView r6 = r6.c
            int r0 = com.huawei.ethiopia.finance.R$mipmap.finance_market_guide_bg_am
            r6.setImageResource(r0)
        L_0x011d:
            W4.a r6 = new W4.a
            r6.<init>()
            W1.b r6 = W1.b.a(r6)
            androidx.databinding.ViewDataBinding r0 = r5.b
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding r0 = (com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBinding) r0
            android.widget.LinearLayout r0 = r0.e
            W1.b$b r6 = r6.c(r0)
            com.huawei.ethiopia.finance.market.c r0 = new com.huawei.ethiopia.finance.market.c
            r0.<init>(r5)
            r6.b = r0
            r5.f = r6
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.market.FinanceMarketGuideActivity.onCreate(android.os.Bundle):void");
    }
}
