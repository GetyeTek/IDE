package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LifecycleOwner;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;

public class FinanceActivitySavingProductDetailBindingImpl extends FinanceActivitySavingProductDetailBinding {
    @Nullable
    public static final ViewDataBinding.IncludedLayouts h;
    @Nullable
    public static final SparseIntArray i;
    public long g;

    static {
        ViewDataBinding.IncludedLayouts includedLayouts = new ViewDataBinding.IncludedLayouts(7);
        h = includedLayouts;
        includedLayouts.setIncludes(0, new String[]{"finance_layout_service_banner", "finance_item_saving_product_balance"}, new int[]{1, 2}, new int[]{R$layout.finance_layout_service_banner, R$layout.finance_item_saving_product_balance});
        SparseIntArray sparseIntArray = new SparseIntArray();
        i = sparseIntArray;
        sparseIntArray.put(R$id.ll_List, 3);
        sparseIntArray.put(R$id.recycler_view, 4);
        sparseIntArray.put(R$id.tv_withdraw, 5);
        sparseIntArray.put(R$id.tv_deposit, 6);
    }

    public final boolean a(int i2) {
        if (i2 != 0) {
            return false;
        }
        synchronized (this) {
            this.g |= 1;
        }
        return true;
    }

    public final void executeBindings() {
        synchronized (this) {
            this.g = 0;
        }
        ViewDataBinding.executeBindingsOn(this.b);
        ViewDataBinding.executeBindingsOn(this.a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0015, code lost:
        if (r6.b.hasPendingBindings() == false) goto L_0x0018;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0017, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001e, code lost:
        if (r6.a.hasPendingBindings() == false) goto L_0x0021;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0020, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0021, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean hasPendingBindings() {
        /*
            r6 = this;
            monitor-enter(r6)
            long r0 = r6.g     // Catch:{ all -> 0x000c }
            r2 = 0
            r4 = 1
            int r5 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r5 == 0) goto L_0x000e
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            return r4
        L_0x000c:
            r0 = move-exception
            goto L_0x0023
        L_0x000e:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBinding r0 = r6.b
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0018
            return r4
        L_0x0018:
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBalanceBinding r0 = r6.a
            boolean r0 = r0.hasPendingBindings()
            if (r0 == 0) goto L_0x0021
            return r4
        L_0x0021:
            r0 = 0
            return r0
        L_0x0023:
            monitor-exit(r6)     // Catch:{ all -> 0x000c }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBindingImpl.hasPendingBindings():boolean");
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.g = 4;
        }
        this.b.invalidateAll();
        this.a.invalidateAll();
        requestRebind();
    }

    public final boolean onFieldChange(int i2, Object obj, int i3) {
        if (i2 == 0) {
            FinanceItemSavingProductBalanceBinding financeItemSavingProductBalanceBinding = (FinanceItemSavingProductBalanceBinding) obj;
            return a(i3);
        } else if (i2 != 1) {
            return false;
        } else {
            FinanceLayoutServiceBannerBinding financeLayoutServiceBannerBinding = (FinanceLayoutServiceBannerBinding) obj;
            if (i3 != 0) {
                return false;
            }
            synchronized (this) {
                this.g |= 2;
            }
            return true;
        }
    }

    public final void setLifecycleOwner(@Nullable LifecycleOwner lifecycleOwner) {
        FinanceActivitySavingProductDetailBindingImpl.super.setLifecycleOwner(lifecycleOwner);
        this.b.setLifecycleOwner(lifecycleOwner);
        this.a.setLifecycleOwner(lifecycleOwner);
    }

    public final boolean setVariable(int i2, @Nullable Object obj) {
        return true;
    }
}
