package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.resp.AdvancedRepayResp;

public class ContractDetailViewModel extends ViewModel {
    public final MutableLiveData<c<AdvancedRepayResp>> a = new MutableLiveData<>();
}
