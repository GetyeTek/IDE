package com.huawei.ethiopia.finance.saving.adapter;

import androidx.databinding.ViewDataBinding;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceItemLockedCloseSavingAccountBinding;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.ethiopia.finance.saving.activity.LockedClosedSavingActivity;
import com.huawei.payment.mvvm.DataBindingAdapter;

public class LockedCloseSavingAccountAdapter extends DataBindingAdapter<FinanceProductInfo, FinanceItemLockedCloseSavingAccountBinding> {
    public LockedClosedSavingActivity c;

    public final int a() {
        return R$layout.finance_item_locked_close_saving_account;
    }

    /* JADX WARNING: type inference failed for: r0v4, types: [android.content.Context, com.huawei.ethiopia.finance.saving.activity.LockedClosedSavingActivity] */
    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        FinanceItemLockedCloseSavingAccountBinding financeItemLockedCloseSavingAccountBinding = (FinanceItemLockedCloseSavingAccountBinding) viewDataBinding;
        FinanceProductInfo financeProductInfo = (FinanceProductInfo) obj;
        financeItemLockedCloseSavingAccountBinding.d.setText(financeProductInfo.getProductNameI18n());
        financeItemLockedCloseSavingAccountBinding.e.setText(financeProductInfo.getPrincipalAmount());
        financeItemLockedCloseSavingAccountBinding.c.setText(financeProductInfo.getProductRateValue());
        financeItemLockedCloseSavingAccountBinding.f.setText(financeProductInfo.getTotalCapitalizationAmount());
        financeItemLockedCloseSavingAccountBinding.b.setText(this.c.getString(R$string.the_product_expires_in) + " " + financeProductInfo.getMaturityDate());
    }
}
