package com.huawei.ethiopia.finance.market.viewmodel;

import V7.c;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.bean.HomeBannerBean;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.loan.repository.QueryFinanceIsActiveRepository;
import com.huawei.ethiopia.finance.market.bean.FinanceMenuResp;
import com.huawei.ethiopia.finance.resp.ActiveState;
import java.util.List;
import p5.g;

public class FinanceMarketModel extends ViewModel {
    public final MutableLiveData<c<FinanceMenuResp>> a = new MutableLiveData<>();
    public final MutableLiveData<c<List<HomeBannerBean>>> b = new MutableLiveData<>();
    public final MutableLiveData<c<FinanceMarketBankConfig>> c = new MutableLiveData<>();
    public QueryFinanceIsActiveRepository d;
    public final MutableLiveData<c<ActiveState>> e = new MutableLiveData<>();
    public String f;

    public class a implements R1.a<ActiveState> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceMarketModel.this.e.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            ActiveState activeState = (ActiveState) obj;
            String protocolUrl = activeState.getProtocolUrl();
            FinanceMarketModel financeMarketModel = FinanceMarketModel.this;
            financeMarketModel.f = protocolUrl;
            financeMarketModel.e.setValue(c.e(activeState));
        }
    }

    public final void a() {
        this.e.setValue(c.c());
        QueryFinanceIsActiveRepository queryFinanceIsActiveRepository = new QueryFinanceIsActiveRepository("v1/ethiopia/loan/subscribe/check");
        this.d = queryFinanceIsActiveRepository;
        String o = g.o();
        if (!TextUtils.isEmpty(o)) {
            queryFinanceIsActiveRepository.addParams("serviceTypeId", o);
        }
        this.d.sendRequest(new a());
    }
}
