package com.huawei.ethiopia.finance.loan.adapter;

import androidx.databinding.ViewDataBinding;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.databinding.FinanceItemLoanContractTransactionBinding;
import com.huawei.ethiopia.finance.resp.TransactionInfo;
import com.huawei.payment.mvvm.DataBindingAdapter;

public class ContractTransactionAdapter extends DataBindingAdapter<TransactionInfo, FinanceItemLoanContractTransactionBinding> {
    public final int a() {
        return R$layout.finance_item_loan_contract_transaction;
    }

    public final void b(ViewDataBinding viewDataBinding, int i, Object obj) {
        FinanceItemLoanContractTransactionBinding financeItemLoanContractTransactionBinding = (FinanceItemLoanContractTransactionBinding) viewDataBinding;
        TransactionInfo transactionInfo = (TransactionInfo) obj;
        financeItemLoanContractTransactionBinding.d.setText(transactionInfo.getShowTitle());
        financeItemLoanContractTransactionBinding.b.setText(transactionInfo.getShowAmount());
        financeItemLoanContractTransactionBinding.c.setText(transactionInfo.getShowContent());
    }
}
