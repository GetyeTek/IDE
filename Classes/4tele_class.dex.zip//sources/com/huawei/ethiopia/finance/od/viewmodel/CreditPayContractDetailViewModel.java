package com.huawei.ethiopia.finance.od.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.od.repository.QueryOdContractDetailRepository;
import com.huawei.ethiopia.finance.resp.CreditContractsInfo;

public class CreditPayContractDetailViewModel extends ViewModel {
    public final MutableLiveData<c<CreditContractsInfo>> a = new MutableLiveData<>();
    public QueryOdContractDetailRepository b;

    public final void onCleared() {
        CreditPayContractDetailViewModel.super.onCleared();
        QueryOdContractDetailRepository queryOdContractDetailRepository = this.b;
        if (queryOdContractDetailRepository != null) {
            queryOdContractDetailRepository.cancel();
        }
    }
}
