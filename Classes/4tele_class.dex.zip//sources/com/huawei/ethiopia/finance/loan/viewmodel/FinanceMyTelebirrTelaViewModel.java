package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.loan.repository.DeactivateLoanRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryLoanContractsRepository;
import com.huawei.ethiopia.finance.resp.ContractsListResp;
import com.huawei.ethiopia.finance.resp.RolloverPreValidationResp;
import com.huawei.http.BaseResp;

public class FinanceMyTelebirrTelaViewModel extends ViewModel {
    public final MutableLiveData<c<ContractsListResp>> a = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> b = new MutableLiveData<>();
    public final MutableLiveData<c<RolloverPreValidationResp>> c = new MutableLiveData<>();
    public QueryLoanContractsRepository d;
    public DeactivateLoanRepository e;

    public class a implements R1.a<ContractsListResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceMyTelebirrTelaViewModel.this.a.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            FinanceMyTelebirrTelaViewModel.this.a.setValue(c.e((ContractsListResp) obj));
        }
    }

    public class b implements R1.a<BaseResp> {
        public b() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceMyTelebirrTelaViewModel.this.b.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            FinanceMyTelebirrTelaViewModel.this.b.setValue(c.e((BaseResp) obj));
        }
    }

    public final void a(String str, String str2) {
        this.b.setValue(c.c());
        this.e = new DeactivateLoanRepository(str);
        if (!TextUtils.isEmpty(str2)) {
            this.e.addParams("serviceTypeId", str2);
        }
        this.e.sendRequest(new b());
    }

    public final void b(String str, String str2, boolean z) {
        QueryLoanContractsRepository queryLoanContractsRepository = this.d;
        if (queryLoanContractsRepository != null) {
            queryLoanContractsRepository.cancel();
        }
        this.a.setValue(c.c());
        QueryLoanContractsRepository queryLoanContractsRepository2 = new QueryLoanContractsRepository(str, str2, z);
        this.d = queryLoanContractsRepository2;
        queryLoanContractsRepository2.sendRequest(new a());
    }

    public final void onCleared() {
        FinanceMyTelebirrTelaViewModel.super.onCleared();
        QueryLoanContractsRepository queryLoanContractsRepository = this.d;
        if (queryLoanContractsRepository != null) {
            queryLoanContractsRepository.cancel();
        }
    }
}
