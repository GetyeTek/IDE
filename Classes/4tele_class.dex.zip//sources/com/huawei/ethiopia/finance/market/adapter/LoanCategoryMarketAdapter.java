package com.huawei.ethiopia.finance.market.adapter;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.market.bean.LoanCategoryMenuInfo;

public class LoanCategoryMarketAdapter extends BaseQuickAdapter<LoanCategoryMenuInfo, BaseViewHolder> {
    public LoanCategoryMarketAdapter() {
        super(R$layout.item_loan_category_market);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        LoanCategoryMenuInfo loanCategoryMenuInfo = (LoanCategoryMenuInfo) obj;
        baseViewHolder.setText(R$id.tv_title, loanCategoryMenuInfo.getProductNameI18n());
        baseViewHolder.setText(R$id.tv_period, loanCategoryMenuInfo.getTimePeriod());
        baseViewHolder.getView(R$id.rootLayout).getBaseFilletView().e(ContextCompat.getColor(getContext(), R$color.colorPrimary));
    }
}
