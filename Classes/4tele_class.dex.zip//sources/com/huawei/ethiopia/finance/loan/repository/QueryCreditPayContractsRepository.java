package com.huawei.ethiopia.finance.loan.repository;

import com.huawei.ethiopia.finance.resp.CreditPayContractsGroup;
import com.huawei.ethiopia.finance.resp.CreditPayContractsInfo;
import com.huawei.ethiopia.finance.resp.CreditPayContractsListResp;
import com.huawei.http.b;
import java.util.List;

public class QueryCreditPayContractsRepository extends b<CreditPayContractsListResp, CreditPayContractsListResp> {
    public final boolean a;

    public QueryCreditPayContractsRepository(boolean z) {
        String str;
        this.a = z;
        if (z) {
            str = "Unpaid";
        } else {
            str = "Paid";
        }
        addParams("debtStatus", str);
    }

    public final Object convert(Object obj) {
        CreditPayContractsListResp creditPayContractsListResp = (CreditPayContractsListResp) obj;
        List<CreditPayContractsGroup> groupContractItems = creditPayContractsListResp.getGroupContractItems();
        if (groupContractItems != null && !groupContractItems.isEmpty()) {
            for (CreditPayContractsGroup contractItems : groupContractItems) {
                List<CreditPayContractsInfo> contractItems2 = contractItems.getContractItems();
                if (contractItems2 != null && !contractItems2.isEmpty()) {
                    for (CreditPayContractsInfo active : contractItems2) {
                        active.setActive(this.a);
                    }
                }
            }
        }
        return (CreditPayContractsListResp) super.convert(creditPayContractsListResp);
    }

    public final String getApiPath() {
        return "v1/ethiopia/od/contract/list";
    }
}
