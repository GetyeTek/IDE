package com.huawei.ethiopia.finance.loan.activity;

import V7.e;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceLoanHomeBinding;
import com.huawei.ethiopia.finance.loan.fragment.ApplyLoanFragment;
import com.huawei.ethiopia.finance.loan.fragment.MyTelebirrTelaFragment;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import java.util.ArrayList;
import java.util.List;

@Route(path = "/finance/loanHome")
public class FinanceLoanHomeActivity extends DataBindingActivity<FinanceActivityFinanceLoanHomeBinding, FinanceApplyLoanViewModel> {
    public static final /* synthetic */ int d = 0;

    public class a extends ViewPager2.OnPageChangeCallback {
        public a() {
        }

        public final void onPageSelected(int i) {
            FinanceLoanHomeActivity.super.onPageSelected(i);
            int i2 = FinanceLoanHomeActivity.d;
            DataBindingActivity dataBindingActivity = FinanceLoanHomeActivity.this;
            if (dataBindingActivity.b.g.getCurrentItem() == 0) {
                dataBindingActivity.b.a.setImageResource(R$mipmap.finance_icon_finance_apply_loan_select);
                dataBindingActivity.b.e.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.common_colorPrimary));
                dataBindingActivity.b.b.setImageResource(R$mipmap.finance_icon_finance_my_telebirr_mela_unselect);
                dataBindingActivity.b.f.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.colorTextLevel4));
                return;
            }
            dataBindingActivity.b.a.setImageResource(R$mipmap.finance_icon_finance_apply_loan_unselect);
            dataBindingActivity.b.e.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.colorTextLevel4));
            dataBindingActivity.b.b.setImageResource(R$mipmap.finance_icon_finance_my_telebirr_mela_select);
            dataBindingActivity.b.f.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.common_colorPrimary));
        }
    }

    public final int C0() {
        return R$layout.finance_activity_finance_loan_home;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        FinanceLoanHomeActivity.super.onActivityResult(i, i2, intent);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments != null && !fragments.isEmpty()) {
            for (Fragment onActivityResult : fragments) {
                onActivityResult.onActivityResult(i, i2, intent);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.ethiopia.finance.loan.activity.FinanceLoanHomeActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        FinanceLoanHomeActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getString(R$string.telebirr_mela), R.layout.common_toolbar);
        String stringExtra = getIntent().getStringExtra("fundsLenderId");
        getIntent().getStringExtra("bankCode");
        this.c.a = stringExtra;
        FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(this);
        ArrayList arrayList = new ArrayList();
        arrayList.add(new ApplyLoanFragment());
        arrayList.add(new MyTelebirrTelaFragment());
        fragmentStateAdapter.a(arrayList);
        this.b.g.setAdapter(fragmentStateAdapter);
        this.b.g.registerOnPageChangeCallback(new a());
        this.b.c.setOnClickListener(new f(this, 0));
        this.b.d.setOnClickListener(new H1.a(this, 2));
    }
}
