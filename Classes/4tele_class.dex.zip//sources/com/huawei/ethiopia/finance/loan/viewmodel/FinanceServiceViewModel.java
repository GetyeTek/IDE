package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import android.text.TextUtils;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.loan.repository.FinanceServiceRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryFinanceIsActiveRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryLoanLimitRepository;
import com.huawei.ethiopia.finance.resp.FinanceMenuListResp;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.http.b;
import java.util.List;
import p5.g;

public class FinanceServiceViewModel extends ViewModel {
    public final MutableLiveData<c<List<FinanceProductInfo>>> a = new MutableLiveData<>();
    public final MutableLiveData<c<FinanceMenuListResp>> b = new MutableLiveData<>();
    public FinanceServiceRepository c;
    public QueryFinanceIsActiveRepository d;
    public QueryLoanLimitRepository e;
    public final MutableLiveData<Boolean> f;

    public class a implements R1.a<FinanceMenuListResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceServiceViewModel.this.b.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            FinanceServiceViewModel financeServiceViewModel = FinanceServiceViewModel.this;
            financeServiceViewModel.getClass();
            financeServiceViewModel.b.setValue(c.e((FinanceMenuListResp) obj));
        }
    }

    public FinanceServiceViewModel() {
        new MutableLiveData();
        new MutableLiveData();
        this.f = new MutableLiveData<>(Boolean.FALSE);
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [com.huawei.http.b, com.huawei.ethiopia.finance.loan.repository.FinanceServiceRepository] */
    public final void a(String str) {
        FinanceServiceRepository financeServiceRepository = this.c;
        if (financeServiceRepository != null) {
            financeServiceRepository.cancel();
        }
        MutableLiveData<c<FinanceMenuListResp>> mutableLiveData = this.b;
        c cVar = (c) mutableLiveData.getValue();
        if (cVar == null || !cVar.f()) {
            mutableLiveData.setValue(c.c());
        }
        ? bVar = new b();
        bVar.addParams("initiatorMsisdn", g.k());
        if (!TextUtils.isEmpty(str)) {
            bVar.addParams("bankCode", str);
        }
        this.c = bVar;
        bVar.sendRequest(new a());
    }

    public final void onCleared() {
        FinanceServiceViewModel.super.onCleared();
        FinanceServiceRepository financeServiceRepository = this.c;
        if (financeServiceRepository != null) {
            financeServiceRepository.cancel();
        }
        QueryFinanceIsActiveRepository queryFinanceIsActiveRepository = this.d;
        if (queryFinanceIsActiveRepository != null) {
            queryFinanceIsActiveRepository.cancel();
        }
        QueryLoanLimitRepository queryLoanLimitRepository = this.e;
        if (queryLoanLimitRepository != null) {
            queryLoanLimitRepository.cancel();
        }
    }
}
