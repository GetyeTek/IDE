package com.huawei.ethiopia.finance.od.activity;

import A8.C;
import V7.c;
import V7.e;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$dimen;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityCreditPayHomeBinding;
import com.huawei.ethiopia.finance.od.fragment.CreditPayContractsFragment;
import com.huawei.ethiopia.finance.od.repository.DeactivateCreditRepository;
import com.huawei.ethiopia.finance.od.viewmodel.DeactivateCreditViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import f5.C0079b;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

@Route(path = "/finance/odHome")
public class CreditPayHomeActivity extends DataBindingActivity<FinanceActivityCreditPayHomeBinding, DeactivateCreditViewModel> {
    public static final /* synthetic */ int d = 0;

    public class a extends ViewPager2.OnPageChangeCallback {
        public a() {
        }

        public final void onPageSelected(int i) {
            boolean z;
            CreditPayHomeActivity.super.onPageSelected(i);
            if (i == 0) {
                z = true;
            } else {
                z = false;
            }
            int i2 = CreditPayHomeActivity.d;
            DataBindingActivity dataBindingActivity = CreditPayHomeActivity.this;
            dataBindingActivity.E0(z);
            if (z) {
                dataBindingActivity.b.i.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.common_colorPrimary));
                dataBindingActivity.b.j.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.colorTextLevel4));
            } else {
                dataBindingActivity.b.j.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.common_colorPrimary));
                dataBindingActivity.b.i.setTextColor(ContextCompat.getColor(dataBindingActivity, R$color.colorTextLevel4));
            }
            dataBindingActivity.b.j.setTypeface((Typeface) null, true ^ z ? 1 : 0);
            dataBindingActivity.b.i.setTypeface((Typeface) null, z ? 1 : 0);
            dataBindingActivity.b.i.invalidate();
            dataBindingActivity.b.j.invalidate();
        }
    }

    public final int C0() {
        return R$layout.finance_activity_credit_pay_home;
    }

    public final void E0(boolean z) {
        if (z) {
            this.b.i.setTextSize(0, getResources().getDimension(R$dimen.dp_16));
            this.b.a.setVisibility(0);
            this.b.j.setTextSize(0, getResources().getDimension(R$dimen.dp_14));
            this.b.b.setVisibility(8);
            return;
        }
        this.b.i.setTextSize(0, getResources().getDimension(R$dimen.dp_14));
        this.b.a.setVisibility(8);
        this.b.j.setTextSize(0, getResources().getDimension(R$dimen.dp_16));
        this.b.b.setVisibility(0);
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        CreditPayHomeActivity.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 100 && i2 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            DeactivateCreditViewModel deactivateCreditViewModel = this.c;
            deactivateCreditViewModel.a.setValue(c.c());
            DeactivateCreditRepository deactivateCreditRepository = new DeactivateCreditRepository(str);
            deactivateCreditViewModel.b = deactivateCreditRepository;
            deactivateCreditRepository.sendRequest(new C(deactivateCreditViewModel, 3));
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.ethiopia.finance.od.activity.CreditPayHomeActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        CreditPayHomeActivity.super.onCreate(bundle);
        f.e(this, ContextCompat.getColor(this, R$color.colorPageBackgroundDark), false);
        e.a(this, getString(R$string.endekise), R.layout.common_toolbar);
        FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(this);
        ArrayList arrayList = new ArrayList();
        arrayList.add(CreditPayContractsFragment.w0("", true));
        arrayList.add(CreditPayContractsFragment.w0("", false));
        fragmentStateAdapter.a(arrayList);
        this.b.k.setAdapter(fragmentStateAdapter);
        this.b.k.registerOnPageChangeCallback(new a());
        this.b.d.setOnClickListener(new N3.c(this, 2));
        this.b.e.setOnClickListener(new com.huawei.bank.transfer.activity.a(this, 4));
        E0(true);
        this.c.a.observe(this, new C0079b(this, 0));
    }
}
