package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundEditText;

public abstract class FinanceBankaccountDialogSelectBankBinding extends ViewDataBinding {
    @NonNull
    public final RoundEditText a;
    @NonNull
    public final HFRecyclerView b;
    @NonNull
    public final TextView c;

    public FinanceBankaccountDialogSelectBankBinding(DataBindingComponent dataBindingComponent, View view, RoundEditText roundEditText, HFRecyclerView hFRecyclerView, TextView textView) {
        super(dataBindingComponent, view, 0);
        this.a = roundEditText;
        this.b = hFRecyclerView;
        this.c = textView;
    }
}
