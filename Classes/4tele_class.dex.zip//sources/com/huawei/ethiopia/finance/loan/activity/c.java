package com.huawei.ethiopia.finance.loan.activity;

import O2.a;

public final class c extends a {
    public final /* synthetic */ ApplyLoanProductActivity b;

    public c(ApplyLoanProductActivity applyLoanProductActivity) {
        super(1);
        this.b = applyLoanProductActivity;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0033  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0042  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void afterTextChanged(android.text.Editable r9) {
        /*
            r8 = this;
            r0 = 1
            r1 = 0
            java.lang.String r2 = r9.toString()
            int r3 = com.huawei.ethiopia.finance.loan.activity.ApplyLoanProductActivity.o
            com.huawei.ethiopia.finance.loan.activity.ApplyLoanProductActivity r3 = r8.b
            double r4 = java.lang.Double.parseDouble(r2)     // Catch:{ Exception -> 0x000f }
            goto L_0x0011
        L_0x000f:
            r4 = 0
        L_0x0011:
            java.lang.String r9 = r9.toString()
            java.util.regex.Pattern r2 = p5.C0105a.a
            float r2 = java.lang.Float.parseFloat(r9)     // Catch:{ Exception -> 0x002d }
            r6 = 0
            int r2 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r2 != 0) goto L_0x0022
        L_0x0020:
            r9 = 0
            goto L_0x002f
        L_0x0022:
            java.util.regex.Pattern r2 = p5.C0105a.a
            java.util.regex.Matcher r9 = r2.matcher(r9)
            boolean r9 = r9.matches()
            goto L_0x002f
        L_0x002d:
            goto L_0x0020
        L_0x002f:
            r2 = 8
            if (r9 != 0) goto L_0x0042
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = r3.e
            r9.d(r1)
            androidx.databinding.ViewDataBinding r9 = r3.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r9
            android.widget.TextView r9 = r9.f
            r9.setVisibility(r2)
            return
        L_0x0042:
            double r6 = r3.k
            int r9 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r9 <= 0) goto L_0x0066
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = r3.e
            r9.d(r1)
            androidx.databinding.ViewDataBinding r9 = r3.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r9
            android.widget.TextView r9 = r9.f
            r9.setVisibility(r1)
            androidx.databinding.ViewDataBinding r9 = r3.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r9
            android.widget.TextView r9 = r9.f
            int r0 = com.huawei.ethiopia.finance.R$string.apply_amount_is_above_maximum_limit
            java.lang.String r0 = r3.getString(r0)
            r9.setText(r0)
            return
        L_0x0066:
            double r6 = r3.n
            int r9 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r9 >= 0) goto L_0x0090
            androidx.databinding.ViewDataBinding r9 = r3.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r9
            android.widget.TextView r9 = r9.f
            int r2 = com.huawei.ethiopia.finance.R$string.apply_amount_is_below_s_limit
            java.lang.String r4 = r3.m
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r0[r1] = r4
            java.lang.String r0 = r3.getString(r2, r0)
            r9.setText(r0)
            androidx.databinding.ViewDataBinding r9 = r3.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r9
            android.widget.TextView r9 = r9.f
            r9.setVisibility(r1)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = r3.e
            r9.d(r1)
            return
        L_0x0090:
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = r3.e
            r9.d(r0)
            androidx.databinding.ViewDataBinding r9 = r3.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r9
            android.widget.TextView r9 = r9.f
            r9.setVisibility(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.loan.activity.c.afterTextChanged(android.text.Editable):void");
    }
}
