package com.huawei.ethiopia.finance.loan.adapter;

import android.text.TextUtils;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.camera.camera2.internal.P;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.blankj.utilcode.util.J;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundTextView;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactScheduleBinding;
import com.huawei.ethiopia.finance.resp.AppRepaymentSchedule;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import p5.g;

public class FinanceLoanContactScheduleAdapter extends BaseQuickAdapter<AppRepaymentSchedule, BaseViewHolder> {
    public LoanContractsInfo a;

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        int i;
        AppRepaymentSchedule appRepaymentSchedule = (AppRepaymentSchedule) obj;
        FinanceItemLoanContactScheduleBinding bind = DataBindingUtil.bind(baseViewHolder.itemView);
        bind.c.setText(appRepaymentSchedule.getTotalScheduleAmount());
        LoanContractsInfo loanContractsInfo = this.a;
        bind.c.setTextColor(loanContractsInfo.getItemOutstandingAmountTextColor());
        String a2 = P.a("(", g.g(), ")");
        TextView textView = bind.f;
        textView.setText(a2);
        textView.setTextColor(loanContractsInfo.getItemOutstandingAmountTextColor());
        bind.d.setText(appRepaymentSchedule.getEndDate());
        int payStateTextColor = loanContractsInfo.getPayStateTextColor();
        RoundTextView roundTextView = bind.a;
        roundTextView.setTextColor(payStateTextColor);
        roundTextView.setBackgroundColor(loanContractsInfo.getPayStateBackground());
        if (loanContractsInfo.isActive()) {
            i = 0;
        } else {
            i = 8;
        }
        roundTextView.setVisibility(i);
        String status = appRepaymentSchedule.getStatus();
        if ("new".equals(status) || "overdue".equals(status) || "outstanding".equals(status) || "maturity".equals(status)) {
            roundTextView.setBackgroundColor(ContextCompat.getColor(J.a(), R$color.colorPrimary));
            roundTextView.setTextColor(ContextCompat.getColor(J.a(), R$color.standard_white));
            roundTextView.setEnabled(true);
            roundTextView.setText(R$string.pay);
        } else {
            if (TextUtils.isEmpty(g.n(appRepaymentSchedule.getStatus()))) {
                roundTextView.setBackgroundColor(ContextCompat.getColor(J.a(), R$color.colorInputBoxUnFocus));
                roundTextView.setTextColor(ContextCompat.getColor(J.a(), R$color.standard_white));
                roundTextView.setText(R$string.pay);
            } else {
                roundTextView.setBackgroundColor(ContextCompat.getColor(J.a(), R$color.transparent));
                roundTextView.setTextColor(ContextCompat.getColor(J.a(), R$color.colorTextLevel4));
                roundTextView.setText(g.n(appRepaymentSchedule.getStatus()));
            }
            roundTextView.setEnabled(false);
        }
        TextView textView2 = bind.e;
        textView2.setVisibility(0);
        textView2.setText(String.format("(%1$s/%2$s)", new Object[]{appRepaymentSchedule.getPeriodId(), loanContractsInfo.getTotalInstallments()}));
    }

    public final int findRelativeAdapterPositionIn(@NonNull RecyclerView.Adapter<? extends RecyclerView.ViewHolder> adapter, @NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (adapter instanceof HFRecyclerView.WrapAdapter) {
            return i - ((HFRecyclerView.WrapAdapter) adapter).a();
        }
        return FinanceLoanContactScheduleAdapter.super.findRelativeAdapterPositionIn(adapter, viewHolder, i);
    }
}
