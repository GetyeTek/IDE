package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class FinanceItemTimeSavingAllBalanceBinding extends ViewDataBinding {
    @NonNull
    public final ImageView a;
    @NonNull
    public final TextView b;

    public FinanceItemTimeSavingAllBalanceBinding(DataBindingComponent dataBindingComponent, View view, ImageView imageView, TextView textView) {
        super(dataBindingComponent, view, 0);
        this.a = imageView;
        this.b = textView;
    }
}
