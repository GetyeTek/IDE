package com.huawei.ethiopia.finance.saving.repository;

import com.huawei.ethiopia.finance.resp.TimeSavingAccountInfo;
import com.huawei.http.b;

public class LockedSavingAccountDetailRepository extends b<TimeSavingAccountInfo, TimeSavingAccountInfo> {
    public final String getApiPath() {
        return "v1/ethiopia/saving/account/detail";
    }
}
