package com.huawei.ethiopia.finance.saving.activity;

import V7.c;
import a5.l;
import android.content.Intent;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.constants.TransactionType;
import com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding;
import com.huawei.ethiopia.finance.saving.repository.DepositWithDrawRepository;
import com.huawei.ethiopia.finance.saving.viewmodel.DepositWithDrawViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import p5.g;

@Route(path = "/finance/savingTransaction")
public class DepositWithDrawActivity extends DataBindingActivity<FinanceActivityDepositWithDrawBinding, DepositWithDrawViewModel> {
    public static final /* synthetic */ int m = 0;
    public TransactionType d;
    public CustomKeyBroadPop e;
    public double f;
    public String g;
    public String h;
    public String i;
    public String j;
    public String k;
    public String l;

    public class a extends O2.a {
        public final /* synthetic */ String b;
        public final /* synthetic */ DepositWithDrawActivity c;

        public a(DepositWithDrawActivity depositWithDrawActivity, String str) {
            super(1);
            this.c = depositWithDrawActivity;
            this.b = str;
        }

        /* JADX WARNING: Removed duplicated region for block: B:15:0x0036  */
        /* JADX WARNING: Removed duplicated region for block: B:16:0x0038  */
        /* JADX WARNING: Removed duplicated region for block: B:19:0x0042  */
        /* JADX WARNING: Removed duplicated region for block: B:21:0x0057  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void afterTextChanged(android.text.Editable r8) {
            /*
                r7 = this;
                java.lang.String r0 = r8.toString()     // Catch:{ Exception -> 0x0009 }
                double r0 = java.lang.Double.parseDouble(r0)     // Catch:{ Exception -> 0x0009 }
                goto L_0x000b
            L_0x0009:
                r0 = 0
            L_0x000b:
                com.huawei.ethiopia.finance.saving.activity.DepositWithDrawActivity r2 = r7.c
                com.huawei.common.widget.keyboard.CustomKeyBroadPop r3 = r2.e
                java.lang.String r8 = r8.toString()
                java.util.regex.Pattern r4 = p5.C0105a.a
                r4 = 0
                float r5 = java.lang.Float.parseFloat(r8)     // Catch:{ Exception -> 0x002c }
                r6 = 0
                int r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
                if (r5 != 0) goto L_0x0021
            L_0x001f:
                r8 = 0
                goto L_0x002e
            L_0x0021:
                java.util.regex.Pattern r5 = p5.C0105a.a
                java.util.regex.Matcher r8 = r5.matcher(r8)
                boolean r8 = r8.matches()
                goto L_0x002e
            L_0x002c:
                goto L_0x001f
            L_0x002e:
                if (r8 == 0) goto L_0x0038
                double r5 = r2.f
                int r8 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
                if (r8 > 0) goto L_0x0038
                r8 = 1
                goto L_0x0039
            L_0x0038:
                r8 = 0
            L_0x0039:
                r3.d(r8)
                double r5 = r2.f
                int r8 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
                if (r8 <= 0) goto L_0x0057
                androidx.databinding.ViewDataBinding r8 = r2.b
                com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r8 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r8
                android.widget.TextView r8 = r8.c
                java.lang.String r0 = r7.b
                r8.setText(r0)
                androidx.databinding.ViewDataBinding r8 = r2.b
                com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r8 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r8
                android.widget.TextView r8 = r8.c
                r8.setVisibility(r4)
                return
            L_0x0057:
                androidx.databinding.ViewDataBinding r8 = r2.b
                com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r8 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r8
                android.widget.TextView r8 = r8.c
                r3 = 8
                r8.setVisibility(r3)
                java.lang.String r8 = r2.k
                boolean r8 = android.text.TextUtils.isEmpty(r8)
                if (r8 != 0) goto L_0x009e
                java.lang.String r8 = r2.k
                double r5 = java.lang.Double.parseDouble(r8)
                int r8 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
                if (r8 >= 0) goto L_0x009e
                java.lang.StringBuilder r8 = new java.lang.StringBuilder
                r8.<init>()
                int r0 = com.huawei.ethiopia.finance.R$string.deposit_amount_is_above_limit
                java.lang.String r0 = r2.getString(r0)
                r8.append(r0)
                java.lang.String r0 = r2.k
                r8.append(r0)
                java.lang.String r8 = r8.toString()
                androidx.databinding.ViewDataBinding r0 = r2.b
                com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r0 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r0
                android.widget.TextView r0 = r0.c
                r0.setVisibility(r4)
                androidx.databinding.ViewDataBinding r0 = r2.b
                com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r0 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r0
                android.widget.TextView r0 = r0.c
                r0.setText(r8)
                goto L_0x00a7
            L_0x009e:
                androidx.databinding.ViewDataBinding r8 = r2.b
                com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r8 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r8
                android.widget.TextView r8 = r8.c
                r8.setVisibility(r3)
            L_0x00a7:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.saving.activity.DepositWithDrawActivity.a.afterTextChanged(android.text.Editable):void");
        }
    }

    public final int C0() {
        return R$layout.finance_activity_deposit_with_draw;
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        DepositWithDrawActivity.super.onActivityResult(i2, i3, intent);
        if (intent != null && i2 == 100 && i3 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            String obj = this.b.a.getText().toString();
            if (this.d == TransactionType.DEPOSIT) {
                DepositWithDrawViewModel depositWithDrawViewModel = this.c;
                String str2 = this.g;
                String str3 = this.h;
                depositWithDrawViewModel.getClass();
                HashMap hashMap = new HashMap();
                hashMap.put("initiatorMsisdn", g.k());
                hashMap.put("initiatorPin", g.a(str));
                hashMap.put("pinVersion", g.l());
                if (!TextUtils.isEmpty(str3)) {
                    hashMap.put("accountNo", str3);
                }
                hashMap.put("applyAmount", obj);
                hashMap.put("productId", str2);
                depositWithDrawViewModel.a.setValue(c.c());
                DepositWithDrawRepository depositWithDrawRepository = new DepositWithDrawRepository("v1/ethiopia/saving/deposit", hashMap);
                depositWithDrawViewModel.b = depositWithDrawRepository;
                depositWithDrawRepository.sendRequest(new l(depositWithDrawViewModel, 5));
                return;
            }
            DepositWithDrawViewModel depositWithDrawViewModel2 = this.c;
            String str4 = this.h;
            depositWithDrawViewModel2.getClass();
            HashMap hashMap2 = new HashMap();
            hashMap2.put("initiatorMsisdn", g.k());
            hashMap2.put("initiatorPin", g.a(str));
            hashMap2.put("pinVersion", g.l());
            if (!TextUtils.isEmpty(str4)) {
                hashMap2.put("accountNo", str4);
            }
            hashMap2.put("applyAmount", obj);
            depositWithDrawViewModel2.a.setValue(c.c());
            DepositWithDrawRepository depositWithDrawRepository2 = new DepositWithDrawRepository("v1/ethiopia/saving/withdraw", hashMap2);
            depositWithDrawViewModel2.b = depositWithDrawRepository2;
            depositWithDrawRepository2.sendRequest(new l(depositWithDrawViewModel2, 5));
        }
    }

    public final void onBackPressed() {
        if (this.e.isShowing()) {
            this.e.c();
        } else {
            DepositWithDrawActivity.super.onBackPressed();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v9, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: type inference failed for: r2v14, types: [com.huawei.ethiopia.finance.saving.activity.DepositWithDrawActivity$a, android.text.TextWatcher] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r9) {
        /*
            r8 = this;
            r0 = 1
            r1 = 0
            com.huawei.ethiopia.finance.saving.activity.DepositWithDrawActivity.super.onCreate(r9)
            int r9 = com.huawei.ethiopia.finance.R$color.colorPageBackgroundDark
            int r9 = androidx.core.content.ContextCompat.getColor(r8, r9)
            com.blankj.utilcode.util.f.e(r8, r9, r1)
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r2 = "transactionType"
            java.io.Serializable r9 = r9.getSerializableExtra(r2)
            com.huawei.ethiopia.finance.constants.TransactionType r9 = (com.huawei.ethiopia.finance.constants.TransactionType) r9
            r8.d = r9
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r2 = "productId"
            java.lang.String r9 = r9.getStringExtra(r2)
            r8.g = r9
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r2 = "accountNo"
            java.lang.String r9 = r9.getStringExtra(r2)
            r8.h = r9
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r2 = "bankCode"
            r9.getStringExtra(r2)
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r3 = "productUnquieID"
            r9.getStringExtra(r3)
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r3 = "isLocked"
            java.lang.String r9 = r9.getStringExtra(r3)
            r8.l = r9
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r3 = "miniOpeningBalance"
            java.lang.String r9 = r9.getStringExtra(r3)
            r8.k = r9
            android.content.Intent r9 = r8.getIntent()     // Catch:{ Exception -> 0x0079 }
            java.lang.String r3 = "limitAmountValue"
            java.lang.String r9 = r9.getStringExtra(r3)     // Catch:{ Exception -> 0x0079 }
            r8.i = r9     // Catch:{ Exception -> 0x0079 }
            java.lang.String r3 = ","
            java.lang.String r4 = ""
            java.lang.String r9 = r9.replaceAll(r3, r4)     // Catch:{ Exception -> 0x0079 }
            double r3 = java.lang.Double.parseDouble(r9)     // Catch:{ Exception -> 0x0079 }
            r8.f = r3     // Catch:{ Exception -> 0x0079 }
            goto L_0x007a
        L_0x0079:
        L_0x007a:
            android.content.Intent r9 = r8.getIntent()
            java.lang.String r9 = r9.getStringExtra(r2)
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "（"
            r2.<init>(r3)
            java.lang.String r3 = p5.g.g()
            r2.append(r3)
            java.lang.String r3 = "）"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            com.huawei.ethiopia.finance.constants.TransactionType r3 = r8.d
            com.huawei.ethiopia.finance.constants.TransactionType r4 = com.huawei.ethiopia.finance.constants.TransactionType.DEPOSIT
            java.lang.String r5 = ": "
            java.lang.String r6 = " "
            java.lang.String r7 = "MS_"
            if (r3 != r4) goto L_0x00ed
            java.lang.String r9 = p5.g.c(r9)
            java.lang.String r3 = "_productID_deposit_AMT_v1"
            java.lang.String r9 = androidx.camera.camera2.internal.P.a(r7, r9, r3)
            r8.j = r9
            int r9 = com.huawei.ethiopia.finance.R$string.deposit
            java.lang.String r9 = r8.getString(r9)
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            int r4 = com.huawei.ethiopia.finance.R$string.deposit_amount
            java.lang.String r4 = r8.getString(r4)
            r3.append(r4)
            r3.append(r6)
            r3.append(r2)
            java.lang.String r3 = r3.toString()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            int r6 = com.huawei.ethiopia.finance.R$string.telebirr_balance
            java.lang.String r6 = r8.getString(r6)
            r4.append(r6)
            r4.append(r5)
            java.lang.String r5 = r8.i
            java.lang.String r4 = androidx.camera.camera2.internal.c.a(r4, r5, r2)
            int r5 = com.huawei.ethiopia.finance.R$string.deposit_amount_is_above_telebirr_balance
            java.lang.String r5 = r8.getString(r5)
            goto L_0x0134
        L_0x00ed:
            java.lang.String r9 = p5.g.c(r9)
            java.lang.String r3 = "_productID_withdraw_AMT_v1"
            java.lang.String r9 = androidx.camera.camera2.internal.P.a(r7, r9, r3)
            r8.j = r9
            int r9 = com.huawei.ethiopia.finance.R$string.withdraw
            java.lang.String r9 = r8.getString(r9)
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            int r4 = com.huawei.ethiopia.finance.R$string.withdraw_amount
            java.lang.String r4 = r8.getString(r4)
            r3.append(r4)
            r3.append(r6)
            r3.append(r2)
            java.lang.String r3 = r3.toString()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            int r6 = com.huawei.ethiopia.finance.R$string.saving_balance
            java.lang.String r6 = r8.getString(r6)
            r4.append(r6)
            r4.append(r5)
            java.lang.String r5 = r8.i
            java.lang.String r4 = androidx.camera.camera2.internal.c.a(r4, r5, r2)
            int r5 = com.huawei.ethiopia.finance.R$string.withdraw_amount_is_above_saving_balance
            java.lang.String r5 = r8.getString(r5)
        L_0x0134:
            int r6 = com.huawei.payment.mvvm.R.layout.common_toolbar
            V7.e.a(r8, r9, r6)
            androidx.databinding.ViewDataBinding r6 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r6 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r6
            android.widget.TextView r6 = r6.c
            r6.setText(r5)
            androidx.databinding.ViewDataBinding r6 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r6 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r6
            android.widget.TextView r6 = r6.e
            r6.setText(r2)
            androidx.databinding.ViewDataBinding r2 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r2 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r2
            android.widget.TextView r2 = r2.d
            r2.setText(r3)
            androidx.databinding.ViewDataBinding r2 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r2 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r2
            android.widget.TextView r2 = r2.b
            r2.setText(r4)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r2 = new com.huawei.common.widget.keyboard.CustomKeyBroadPop
            c2.d r3 = new c2.d
            java.util.ArrayList r9 = c2.d.b(r9)
            r4 = 4
            r3.<init>(r4, r9)
            r2.<init>(r8, r3)
            r8.e = r2
            a4.a r9 = new a4.a
            r9.<init>(r8)
            r2.d = r9
            androidx.databinding.ViewDataBinding r9 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r9
            android.widget.EditText r9 = r9.a
            r2.a(r8, r9, r0)
            androidx.databinding.ViewDataBinding r9 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r9
            android.widget.EditText r9 = r9.a
            e2.a r2 = new e2.a
            r2.<init>()
            android.text.InputFilter[] r3 = new android.text.InputFilter[r0]
            r3[r1] = r2
            r9.setFilters(r3)
            androidx.databinding.ViewDataBinding r9 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r9
            android.widget.EditText r9 = r9.a
            com.huawei.ethiopia.finance.saving.activity.DepositWithDrawActivity$a r2 = new com.huawei.ethiopia.finance.saving.activity.DepositWithDrawActivity$a
            r2.<init>(r8, r5)
            r9.addTextChangedListener(r2)
            java.lang.String r9 = r8.l
            java.lang.String r2 = "true"
            boolean r9 = android.text.TextUtils.equals(r9, r2)
            if (r9 == 0) goto L_0x01ce
            androidx.databinding.ViewDataBinding r9 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r9
            android.widget.EditText r9 = r9.a
            double r2 = r8.f
            java.lang.String r2 = java.lang.String.valueOf(r2)
            r9.setText(r2)
            androidx.databinding.ViewDataBinding r9 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r9
            android.widget.EditText r9 = r9.a
            r9.setEnabled(r1)
            androidx.databinding.ViewDataBinding r9 = r8.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBinding) r9
            android.widget.EditText r9 = r9.a
            r9.setClickable(r1)
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r9 = r8.e
            r9.d(r0)
        L_0x01ce:
            androidx.lifecycle.ViewModel r9 = r8.c
            com.huawei.ethiopia.finance.saving.viewmodel.DepositWithDrawViewModel r9 = (com.huawei.ethiopia.finance.saving.viewmodel.DepositWithDrawViewModel) r9
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.SavingTransactionResult>> r9 = r9.a
            Y4.a r0 = new Y4.a
            r1 = 2
            r0.<init>(r8, r1)
            r9.observe(r8, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.saving.activity.DepositWithDrawActivity.onCreate(android.os.Bundle):void");
    }

    public final void onDestroy() {
        DepositWithDrawActivity.super.onDestroy();
        this.e.dismiss();
    }
}
