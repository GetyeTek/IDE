package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class FinanceLockedSavingProductTitleLayoutBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final TextView b;

    public FinanceLockedSavingProductTitleLayoutBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView) {
        this.a = linearLayout;
        this.b = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
