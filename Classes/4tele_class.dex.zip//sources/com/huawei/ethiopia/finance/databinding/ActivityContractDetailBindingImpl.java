package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class ActivityContractDetailBindingImpl extends ActivityContractDetailBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e = -1;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.tv_amount_paid, 1);
        sparseIntArray.put(R$id.ll_amount_container, 2);
        sparseIntArray.put(R$id.tv_amount_value, 3);
        sparseIntArray.put(R$id.tv_currency, 4);
        sparseIntArray.put(R$id.rl_recycler_container, 5);
        sparseIntArray.put(R$id.rv_list, 6);
        sparseIntArray.put(R$id.lb_confirm, 7);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActivityContractDetailBindingImpl(@androidx.annotation.NonNull android.view.View r11, @androidx.annotation.Nullable androidx.databinding.DataBindingComponent r12) {
        /*
            r10 = this;
            android.util.SparseIntArray r0 = f
            r1 = 8
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r12, r11, r1, r2, r0)
            r1 = 7
            r1 = r0[r1]
            r6 = r1
            com.huawei.common.widget.LoadingButton r6 = (com.huawei.common.widget.LoadingButton) r6
            r1 = 2
            r1 = r0[r1]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1 = 5
            r1 = r0[r1]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1 = 6
            r1 = r0[r1]
            r7 = r1
            androidx.recyclerview.widget.RecyclerView r7 = (androidx.recyclerview.widget.RecyclerView) r7
            r1 = 1
            r1 = r0[r1]
            android.widget.TextView r1 = (android.widget.TextView) r1
            r1 = 3
            r1 = r0[r1]
            r8 = r1
            android.widget.TextView r8 = (android.widget.TextView) r8
            r1 = 4
            r1 = r0[r1]
            r9 = r1
            android.widget.TextView r9 = (android.widget.TextView) r9
            r3 = r10
            r4 = r12
            r5 = r11
            r3.<init>(r4, r5, r6, r7, r8, r9)
            r3 = -1
            r10.e = r3
            r12 = 0
            r12 = r0[r12]
            androidx.constraintlayout.widget.ConstraintLayout r12 = (androidx.constraintlayout.widget.ConstraintLayout) r12
            r12.setTag(r2)
            r10.setRootTag(r11)
            r10.invalidateAll()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.databinding.ActivityContractDetailBindingImpl.<init>(android.view.View, androidx.databinding.DataBindingComponent):void");
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
