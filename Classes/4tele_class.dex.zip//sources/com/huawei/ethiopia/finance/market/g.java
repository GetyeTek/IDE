package com.huawei.ethiopia.finance.market;

import android.view.View;
import com.huawei.digitalpayment.customer.httplib.response.FinanceMarketBankConfig;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.market.dialog.FinanceFilterDialog;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import com.huawei.payment.mvvm.DataBindingAdapter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final /* synthetic */ class g implements DataBindingAdapter.a {
    public final /* synthetic */ LoanProductsMarketActivity a;
    public final /* synthetic */ FinanceFilterDialog b;
    public final /* synthetic */ List c;
    public final /* synthetic */ View d;

    public /* synthetic */ g(LoanProductsMarketActivity loanProductsMarketActivity, FinanceFilterDialog financeFilterDialog, List list, View view) {
        this.a = loanProductsMarketActivity;
        this.b = financeFilterDialog;
        this.c = list;
        this.d = view;
    }

    public final void c(View view, int i, Object obj) {
        FinanceMarketBankConfig.FilterBean filterBean = (FinanceMarketBankConfig.FilterBean) obj;
        int i2 = LoanProductsMarketActivity.v;
        LoanProductsMarketActivity loanProductsMarketActivity = this.a;
        loanProductsMarketActivity.getClass();
        this.b.dismiss();
        FinanceMarketBankConfig.FilterBean filterBean2 = (FinanceMarketBankConfig.FilterBean) this.c.get(i);
        if (filterBean2 != null) {
            View view2 = this.d;
            if (view2.getId() == R$id.tvMaxLimit) {
                int value = filterBean2.getValue();
                ArrayList arrayList = new ArrayList();
                ArrayList<ProductInfo> F0 = loanProductsMarketActivity.F0();
                if (value == -1) {
                    loanProductsMarketActivity.J0(F0);
                } else if (!F0.isEmpty()) {
                    Iterator<ProductInfo> it = F0.iterator();
                    while (it.hasNext()) {
                        ProductInfo next = it.next();
                        if (Double.parseDouble(next.getMaxLimit()) <= ((double) value)) {
                            arrayList.add(next);
                        }
                    }
                    loanProductsMarketActivity.J0(arrayList);
                }
                loanProductsMarketActivity.s = i;
            } else if (view2.getId() == R$id.tvInstallment) {
                int value2 = filterBean2.getValue();
                loanProductsMarketActivity.t = i;
                ArrayList arrayList2 = new ArrayList();
                ArrayList<ProductInfo> F02 = loanProductsMarketActivity.F0();
                if (value2 == -1) {
                    loanProductsMarketActivity.J0(F02);
                } else if (!F02.isEmpty()) {
                    Iterator<ProductInfo> it2 = F02.iterator();
                    while (it2.hasNext()) {
                        ProductInfo next2 = it2.next();
                        if (value2 == next2.getTermDays()) {
                            arrayList2.add(next2);
                        }
                    }
                    loanProductsMarketActivity.J0(arrayList2);
                }
            }
        }
    }
}
