package com.huawei.ethiopia.finance.loan.activity;

import R1.b;
import V7.c;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.keyboard.CustomKeyBroadPop;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding;
import com.huawei.ethiopia.finance.loan.adapter.LoanValidationAdapter;
import com.huawei.ethiopia.finance.loan.viewmodel.ApplyLoanProductViewModel;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import com.huawei.payment.mvvm.DataBindingActivity;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import p5.g;
import w5.C0112a;

@Route(path = "/finance/applyLoanProduct")
public class ApplyLoanProductActivity extends DataBindingActivity<FinanceActivityApplyLoanProductBinding, ApplyLoanProductViewModel> {
    public static final /* synthetic */ int o = 0;
    public ProductInfo d;
    public CustomKeyBroadPop e;
    public String f;
    public String g;
    public LoanValidationAdapter h;
    public String i;
    public String j = null;
    public double k;
    public String l;
    public String m;
    public double n;

    public class a extends b {
        public final void a(View view) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isBind", true);
            o0.b.d((Activity) null, "/loginModule/upgradeLevel", bundle, (Map) null);
        }
    }

    public final int C0() {
        return R$layout.finance_activity_apply_loan_product;
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.ethiopia.finance.loan.activity.ApplyLoanProductActivity, android.content.Context, androidx.fragment.app.FragmentActivity] */
    public final void E0(String str) {
        String string = getString(R$string.dear_customer);
        String string2 = getString(R$string.confirm);
        String string3 = getString(R$string.app_cancel);
        b bVar = new b();
        BaseDialog baseDialog = new BaseDialog();
        baseDialog.g = string;
        baseDialog.h = str;
        baseDialog.i = string3;
        baseDialog.j = string2;
        baseDialog.k = null;
        baseDialog.l = bVar;
        baseDialog.show(getSupportFragmentManager(), "bind");
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [com.huawei.ethiopia.finance.loan.repository.ApplyLoanProductRepository, com.huawei.http.b] */
    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        ApplyLoanProductActivity.super.onActivityResult(i2, i3, intent);
        if (intent != null && i2 == 100 && i3 == -1) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            String c = g.c(this.l);
            C0112a.a(c + "_loan_AMT_PIN_v1");
            ApplyLoanProductViewModel applyLoanProductViewModel = this.c;
            String productId = this.d.getProductId();
            String str2 = this.g;
            applyLoanProductViewModel.a.setValue(c.c());
            ? bVar = new com.huawei.http.b();
            bVar.addParams("productId", productId);
            bVar.addParams("applyAmount", str2);
            bVar.addParams("initiatorPin", g.a(str));
            bVar.addParams("pinVersion", g.l());
            applyLoanProductViewModel.c = bVar;
            bVar.sendRequest(new F4.b(applyLoanProductViewModel, 1));
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: android.text.InputFilter[]} */
    /* JADX WARNING: type inference failed for: r0v1, types: [com.huawei.ethiopia.finance.loan.activity.c, android.text.TextWatcher] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(@androidx.annotation.Nullable android.os.Bundle r7) {
        /*
            r6 = this;
            r0 = 0
            r1 = 1
            com.huawei.ethiopia.finance.loan.activity.ApplyLoanProductActivity.super.onCreate(r7)
            int r7 = com.huawei.ethiopia.finance.R$color.colorPageBackgroundDark
            int r7 = androidx.core.content.ContextCompat.getColor(r6, r7)
            com.blankj.utilcode.util.f.e(r6, r7, r0)
            android.content.Intent r7 = r6.getIntent()
            java.lang.String r2 = "productInfo"
            java.io.Serializable r7 = r7.getSerializableExtra(r2)
            com.huawei.ethiopia.finance.resp.ProductInfo r7 = (com.huawei.ethiopia.finance.resp.ProductInfo) r7
            r6.d = r7
            if (r7 != 0) goto L_0x001f
            return
        L_0x001f:
            android.content.Intent r7 = r6.getIntent()
            java.lang.String r2 = "bankCode"
            java.lang.String r7 = r7.getStringExtra(r2)
            r6.l = r7
            int r7 = com.huawei.ethiopia.finance.R$string.apply_credit
            java.lang.String r7 = r6.getString(r7)
            p5.g r2 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r2 = r2.a
            if (r2 == 0) goto L_0x007f
            p5.g r2 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r2 = r2.a
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r2 = r2.getFinanceServiceUIConfig()
            if (r2 == 0) goto L_0x007f
            p5.g r2 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r2 = r2.a
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r2 = r2.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r2 = r2.getLoan()
            if (r2 == 0) goto L_0x007f
            p5.g r2 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r2 = r2.a
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r2 = r2.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r2 = r2.getLoan()
            java.lang.String r2 = r2.getApplyLoanTitle()
            boolean r2 = android.text.TextUtils.isEmpty(r2)
            if (r2 != 0) goto L_0x007f
            p5.g r7 = p5.g.i()
            com.huawei.ethiopia.finance.resp.FinanceMenuListResp r7 = r7.a
            com.huawei.ethiopia.finance.resp.FinanceServiceUIConfig r7 = r7.getFinanceServiceUIConfig()
            com.huawei.ethiopia.finance.resp.LoanConfig r7 = r7.getLoan()
            java.lang.String r7 = r7.getApplyLoanTitle()
        L_0x007f:
            int r2 = com.huawei.payment.mvvm.R.layout.common_toolbar
            V7.e.a(r6, r7, r2)
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            java.lang.String r2 = "("
            r7.<init>(r2)
            java.lang.String r2 = p5.g.g()
            r7.append(r2)
            java.lang.String r2 = ")"
            r7.append(r2)
            java.lang.String r7 = r7.toString()
            r6.i = r7
            com.huawei.ethiopia.finance.resp.ProductInfo r7 = r6.d
            com.huawei.ethiopia.finance.resp.ProductDetailInfo r7 = r7.getProductDetailInfo()
            if (r7 == 0) goto L_0x00ab
            java.lang.String r7 = r7.getAvailableLimit()
            r6.j = r7
        L_0x00ab:
            java.lang.String r7 = r6.j
            java.lang.String r2 = ""
            java.lang.String r3 = ","
            if (r7 == 0) goto L_0x00b9
            java.lang.String r7 = r7.replaceAll(r3, r2)
            r6.j = r7
        L_0x00b9:
            com.huawei.ethiopia.finance.resp.ProductInfo r7 = r6.d
            java.lang.String r7 = r7.getMinLimit()
            r6.m = r7
            if (r7 == 0) goto L_0x00c9
            java.lang.String r7 = r7.replaceAll(r3, r2)
            r6.m = r7
        L_0x00c9:
            java.lang.String r7 = r6.j
            r2 = 0
            double r4 = java.lang.Double.parseDouble(r7)     // Catch:{ Exception -> 0x00d2 }
            goto L_0x00d3
        L_0x00d2:
            r4 = r2
        L_0x00d3:
            r6.k = r4
            java.lang.String r7 = r6.m
            double r4 = java.lang.Double.parseDouble(r7)     // Catch:{ Exception -> 0x00dc }
            goto L_0x00de
        L_0x00dc:
            r4 = r2
        L_0x00de:
            r6.n = r4
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r7 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r7
            android.widget.TextView r7 = r7.e
            r7.setVisibility(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r7 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r7
            android.widget.TextView r7 = r7.e
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            int r5 = com.huawei.ethiopia.finance.R$string.available_limits
            java.lang.String r5 = r6.getString(r5)
            r4.append(r5)
            java.lang.String r5 = ": "
            r4.append(r5)
            java.lang.String r5 = r6.j
            r4.append(r5)
            java.lang.String r5 = r6.i
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            r7.setText(r4)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r7 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r7
            android.widget.TextView r7 = r7.g
            java.lang.String r4 = r6.i
            r7.setText(r4)
            double r4 = r6.k
            int r7 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r7 != 0) goto L_0x014f
            int r7 = com.huawei.ethiopia.finance.R$string.title_improve_available_limit
            java.lang.String r7 = r6.getString(r7)
            int r2 = com.huawei.ethiopia.finance.R$string.content_improve_available_limit
            java.lang.String r2 = r6.getString(r2)
            int r3 = com.huawei.ethiopia.finance.R$string.designstandard_ok
            java.lang.String r3 = r6.getString(r3)
            com.huawei.digitalpayment.customer.dialog.ContentGravityTipsDialog r4 = new com.huawei.digitalpayment.customer.dialog.ContentGravityTipsDialog
            r4.<init>()
            r4.g = r7
            r4.h = r2
            r4.i = r3
            r7 = 8388611(0x800003, float:1.1754948E-38)
            r4.j = r7
            androidx.fragment.app.FragmentManager r7 = r6.getSupportFragmentManager()
            java.lang.String r2 = "tips_improve_available_limit"
            r4.show(r7, r2)
        L_0x014f:
            com.huawei.common.widget.keyboard.CustomKeyBroadPop r7 = new com.huawei.common.widget.keyboard.CustomKeyBroadPop
            c2.d r2 = new c2.d
            int r3 = com.huawei.ethiopia.finance.R$string.view
            java.lang.String r3 = r6.getString(r3)
            java.util.ArrayList r3 = c2.d.b(r3)
            r4 = 4
            r2.<init>(r4, r3)
            r7.<init>(r6, r2)
            r6.e = r7
            com.google.android.datatransport.runtime.scheduling.jobscheduling.d r2 = new com.google.android.datatransport.runtime.scheduling.jobscheduling.d
            r2.<init>(r6)
            r7.d = r2
            com.huawei.ethiopia.finance.loan.activity.a r2 = new com.huawei.ethiopia.finance.loan.activity.a
            r2.<init>(r6)
            r7.e = r2
            androidx.databinding.ViewDataBinding r2 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r2 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r2
            android.widget.EditText r2 = r2.b
            r7.a(r6, r2, r1)
            e2.a r7 = new e2.a
            r7.<init>()
            androidx.databinding.ViewDataBinding r2 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r2 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r2
            android.widget.EditText r2 = r2.b
            android.text.InputFilter[] r3 = new android.text.InputFilter[r1]
            r3[r0] = r7
            r2.setFilters(r3)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r7 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r7
            android.widget.EditText r7 = r7.b
            com.huawei.ethiopia.finance.loan.activity.c r0 = new com.huawei.ethiopia.finance.loan.activity.c
            r0.<init>(r6)
            r7.addTextChangedListener(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r7 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r7
            com.huawei.common.widget.round.RoundRecyclerView r7 = r7.d
            androidx.recyclerview.widget.LinearLayoutManager r0 = new androidx.recyclerview.widget.LinearLayoutManager
            r0.<init>(r6)
            r7.setLayoutManager(r0)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r7 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r7
            com.huawei.common.widget.round.RoundRecyclerView r7 = r7.d
            com.huawei.common.widget.recyclerview.RecycleViewDivider r0 = new com.huawei.common.widget.recyclerview.RecycleViewDivider
            int r2 = com.huawei.ethiopia.finance.R$color.colorDividerLight
            int r2 = androidx.core.content.ContextCompat.getColor(r6, r2)
            r3 = 1051260355(0x3ea8f5c3, float:0.33)
            int r3 = com.blankj.utilcode.util.v.a(r3)
            r0.<init>(r2, r3)
            r7.addItemDecoration(r0)
            com.huawei.ethiopia.finance.loan.adapter.LoanValidationAdapter r7 = new com.huawei.ethiopia.finance.loan.adapter.LoanValidationAdapter
            r7.<init>(r6)
            r6.h = r7
            androidx.databinding.ViewDataBinding r0 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r0 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r0
            com.huawei.common.widget.round.RoundRecyclerView r0 = r0.d
            r0.setAdapter(r7)
            androidx.databinding.ViewDataBinding r7 = r6.b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding r7 = (com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBinding) r7
            com.huawei.common.widget.LoadingButton r7 = r7.a
            c6.p r0 = new c6.p
            r0.<init>(r6, r1)
            r7.setOnClickListener(r0)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.ethiopia.finance.loan.viewmodel.ApplyLoanProductViewModel r7 = (com.huawei.ethiopia.finance.loan.viewmodel.ApplyLoanProductViewModel) r7
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.http.BaseResp>> r7 = r7.a
            com.huawei.bank.transfer.activity.l r0 = new com.huawei.bank.transfer.activity.l
            r0.<init>(r6, r1)
            r7.observe(r6, r0)
            androidx.lifecycle.ViewModel r7 = r6.c
            com.huawei.ethiopia.finance.loan.viewmodel.ApplyLoanProductViewModel r7 = (com.huawei.ethiopia.finance.loan.viewmodel.ApplyLoanProductViewModel) r7
            androidx.lifecycle.MutableLiveData<V7.c<com.huawei.ethiopia.finance.resp.LoanTrialResp>> r7 = r7.b
            com.huawei.ethiopia.finance.loan.activity.b r0 = new com.huawei.ethiopia.finance.loan.activity.b
            r0.<init>(r6)
            r7.observe(r6, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.loan.activity.ApplyLoanProductActivity.onCreate(android.os.Bundle):void");
    }

    public final void onDestroy() {
        ApplyLoanProductActivity.super.onDestroy();
        CustomKeyBroadPop customKeyBroadPop = this.e;
        if (customKeyBroadPop != null) {
            customKeyBroadPop.dismiss();
        }
    }
}
