package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceActivitySavingProductDetailBinding extends ViewDataBinding {
    @NonNull
    public final FinanceItemSavingProductBalanceBinding a;
    @NonNull
    public final FinanceLayoutServiceBannerBinding b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final HFRecyclerView d;
    @NonNull
    public final RoundTextView e;
    @NonNull
    public final RoundTextView f;

    public FinanceActivitySavingProductDetailBinding(DataBindingComponent dataBindingComponent, View view, FinanceItemSavingProductBalanceBinding financeItemSavingProductBalanceBinding, FinanceLayoutServiceBannerBinding financeLayoutServiceBannerBinding, LinearLayout linearLayout, HFRecyclerView hFRecyclerView, RoundTextView roundTextView, RoundTextView roundTextView2) {
        super(dataBindingComponent, view, 2);
        this.a = financeItemSavingProductBalanceBinding;
        this.b = financeLayoutServiceBannerBinding;
        this.c = linearLayout;
        this.d = hFRecyclerView;
        this.e = roundTextView;
        this.f = roundTextView2;
    }
}
