package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceItemLoanContactScheduleBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final RoundConstraintLayout b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public FinanceItemLoanContactScheduleBinding(DataBindingComponent dataBindingComponent, View view, RoundTextView roundTextView, RoundConstraintLayout roundConstraintLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = roundConstraintLayout;
        this.c = textView;
        this.d = textView2;
        this.e = textView3;
        this.f = textView4;
    }
}
