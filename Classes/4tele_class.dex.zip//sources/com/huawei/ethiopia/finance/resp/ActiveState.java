package com.huawei.ethiopia.finance.resp;

import com.huawei.http.BaseResp;

public class ActiveState extends BaseResp {
    private String protocolUrl;
    private String subscribed;
    private String subscribedSavingDeposit;
    private String subscribedSavingRecurring;

    public boolean depositIsActive() {
        return "Y".equals(this.subscribedSavingDeposit);
    }

    public String getProtocolUrl() {
        return this.protocolUrl;
    }

    public String getSubscribed() {
        return this.subscribed;
    }

    public String getSubscribedSavingDeposit() {
        return this.subscribedSavingDeposit;
    }

    public String getSubscribedSavingRecurring() {
        return this.subscribedSavingRecurring;
    }

    public boolean isActive() {
        return "Y".equals(this.subscribed);
    }

    public boolean recurringIsActive() {
        return "Y".equals(this.subscribedSavingRecurring);
    }

    public void setProtocolUrl(String str) {
        this.protocolUrl = str;
    }

    public void setSubscribed(String str) {
        this.subscribed = str;
    }

    public void setSubscribedSavingDeposit(String str) {
        this.subscribedSavingDeposit = str;
    }

    public void setSubscribedSavingRecurring(String str) {
        this.subscribedSavingRecurring = str;
    }
}
