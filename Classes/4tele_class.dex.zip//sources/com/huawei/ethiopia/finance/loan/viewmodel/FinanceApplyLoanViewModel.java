package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.loan.repository.QueryLoanContractsRepository;
import com.huawei.ethiopia.finance.loan.repository.QueryLoanProductRepository;
import com.huawei.ethiopia.finance.resp.ContractsListResp;
import com.huawei.ethiopia.finance.resp.FinanceLoanResp;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import com.huawei.ethiopia.finance.resp.RolloverPreValidationResp;
import com.huawei.http.BaseResp;
import java.util.HashMap;
import java.util.List;

public class FinanceApplyLoanViewModel extends ViewModel {
    public String a;
    public final MutableLiveData<c<FinanceLoanResp>> b = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> c = new MutableLiveData<>();
    public final MutableLiveData<c<ProductInfo>> d = new MutableLiveData<>();
    public final MutableLiveData<c<ProductInfo>> e;
    public final MutableLiveData<c<RolloverPreValidationResp>> f;
    public final MutableLiveData<c<RolloverPreValidationResp>> g;
    public QueryLoanProductRepository h;
    public QueryLoanContractsRepository i;

    public class a implements R1.a<ContractsListResp> {
        public final /* synthetic */ FinanceLoanResp a;

        public a(FinanceLoanResp financeLoanResp) {
            this.a = financeLoanResp;
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            FinanceApplyLoanViewModel.this.b.setValue(c.e(this.a));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            HashMap hashMap;
            ContractsListResp contractsListResp = (ContractsListResp) obj;
            FinanceLoanResp financeLoanResp = this.a;
            if (financeLoanResp == null) {
                hashMap = new HashMap();
            } else {
                List<ProductInfo> productList = financeLoanResp.getProductList();
                if (productList == null || productList.isEmpty()) {
                    hashMap = new HashMap();
                } else {
                    HashMap hashMap2 = new HashMap();
                    for (ProductInfo next : productList) {
                        next.clearLoanContractsInfos();
                        hashMap2.put(next.getProductId(), next);
                    }
                    hashMap = hashMap2;
                }
            }
            List<LoanContractsInfo> contracts = contractsListResp.getContracts();
            if (contracts != null && !contracts.isEmpty()) {
                for (LoanContractsInfo next2 : contracts) {
                    ProductInfo productInfo = (ProductInfo) hashMap.get(next2.getProductId());
                    if (productInfo != null) {
                        productInfo.addLoanContractsInfo(next2);
                    }
                }
            }
            FinanceApplyLoanViewModel.this.b.setValue(c.e(financeLoanResp));
        }
    }

    public FinanceApplyLoanViewModel() {
        new MutableLiveData();
        this.e = new MutableLiveData<>();
        this.f = new MutableLiveData<>();
        this.g = new MutableLiveData<>();
    }

    public final void a(FinanceLoanResp financeLoanResp) {
        QueryLoanContractsRepository queryLoanContractsRepository = new QueryLoanContractsRepository(this.a);
        this.i = queryLoanContractsRepository;
        queryLoanContractsRepository.sendRequest(new a(financeLoanResp));
    }

    public final void onCleared() {
        FinanceApplyLoanViewModel.super.onCleared();
        QueryLoanProductRepository queryLoanProductRepository = this.h;
        if (queryLoanProductRepository != null) {
            queryLoanProductRepository.cancel();
        }
        QueryLoanContractsRepository queryLoanContractsRepository = this.i;
        if (queryLoanContractsRepository != null) {
            queryLoanContractsRepository.cancel();
        }
    }
}
