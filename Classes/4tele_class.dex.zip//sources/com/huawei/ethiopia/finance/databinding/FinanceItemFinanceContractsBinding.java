package com.huawei.ethiopia.finance.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class FinanceItemFinanceContractsBinding extends ViewDataBinding {
}
