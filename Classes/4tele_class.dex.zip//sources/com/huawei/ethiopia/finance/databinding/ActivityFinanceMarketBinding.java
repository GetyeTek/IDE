package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.common.widget.banner.CycleViewPager;

public abstract class ActivityFinanceMarketBinding extends ViewDataBinding {
    @NonNull
    public final CycleViewPager a;
    @NonNull
    public final ViewPager2 b;

    public ActivityFinanceMarketBinding(DataBindingComponent dataBindingComponent, View view, CycleViewPager cycleViewPager, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 0);
        this.a = cycleViewPager;
        this.b = viewPager2;
    }
}
