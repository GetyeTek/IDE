package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.round.RoundLinearLayout;

public final class FinanceMyFixedSavingLayoutBinding implements ViewBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final RoundLinearLayout c;
    @NonNull
    public final TextView d;

    public FinanceMyFixedSavingLayoutBinding(@NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull RoundLinearLayout roundLinearLayout, @NonNull TextView textView) {
        this.a = linearLayout;
        this.b = imageView;
        this.c = roundLinearLayout;
        this.d = textView;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
