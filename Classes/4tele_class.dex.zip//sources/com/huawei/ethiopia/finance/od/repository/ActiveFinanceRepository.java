package com.huawei.ethiopia.finance.od.repository;

import com.huawei.http.BaseResp;
import com.huawei.http.b;
import java.util.HashMap;
import p5.g;

public class ActiveFinanceRepository extends b<BaseResp, BaseResp> {
    public static final HashMap b;
    public final String a;

    static {
        HashMap hashMap = new HashMap();
        b = hashMap;
        hashMap.put("finance_loan", "v1/ethiopia/loan/active");
        hashMap.put("finance_overdraft", "v1/ethiopia/subscribeConsumerOD");
    }

    public ActiveFinanceRepository(String str, String str2) {
        this.a = str;
        if ("finance_overdraft".equals(b.get(str))) {
            addParams("initiatorMsisdn", g.k());
        }
        addParams("initiatorPin", g.a(str2));
        addParams("pinVersion", g.l());
        addParams("agreeTermCondition", "Y");
    }

    public final String getApiPath() {
        return (String) b.get(this.a);
    }
}
