package com.huawei.ethiopia.finance.loan.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.huawei.ethiopia.finance.loan.repository.ApplyNewNplRepository;
import com.huawei.http.BaseResp;

public class LoanRestructureViewModel extends ViewModel {
    public final MutableLiveData<c<BaseResp>> a = new MutableLiveData<>();
    public ApplyNewNplRepository b;

    public final void onCleared() {
        LoanRestructureViewModel.super.onCleared();
        ApplyNewNplRepository applyNewNplRepository = this.b;
        if (applyNewNplRepository != null) {
            applyNewNplRepository.cancel();
        }
    }
}
