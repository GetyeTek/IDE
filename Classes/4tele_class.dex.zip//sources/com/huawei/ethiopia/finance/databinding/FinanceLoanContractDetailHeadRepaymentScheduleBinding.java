package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.round.RoundTextView;

public abstract class FinanceLoanContractDetailHeadRepaymentScheduleBinding extends ViewDataBinding {
    @NonNull
    public final RoundTextView a;
    @NonNull
    public final RecyclerView b;

    public FinanceLoanContractDetailHeadRepaymentScheduleBinding(View view, DataBindingComponent dataBindingComponent, RecyclerView recyclerView, RoundTextView roundTextView) {
        super(dataBindingComponent, view, 0);
        this.a = roundTextView;
        this.b = recyclerView;
    }
}
