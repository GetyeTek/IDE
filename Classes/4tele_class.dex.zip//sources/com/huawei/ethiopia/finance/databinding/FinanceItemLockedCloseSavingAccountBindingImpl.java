package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceItemLockedCloseSavingAccountBindingImpl extends FinanceItemLockedCloseSavingAccountBinding {
    @Nullable
    public static final SparseIntArray h;
    public long g;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        h = sparseIntArray;
        sparseIntArray.put(R$id.tvTitle, 1);
        sparseIntArray.put(R$id.tvTotalAmountValue, 2);
        sparseIntArray.put(R$id.tvTotalAmount, 3);
        sparseIntArray.put(R$id.tvTotalGainsValue, 4);
        sparseIntArray.put(R$id.tvTotalGains, 5);
        sparseIntArray.put(R$id.tvInterestRateValue, 6);
        sparseIntArray.put(R$id.tvInterestRate, 7);
        sparseIntArray.put(R$id.tvExpireTime, 8);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.g = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.g != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.g = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
