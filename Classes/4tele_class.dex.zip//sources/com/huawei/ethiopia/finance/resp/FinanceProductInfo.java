package com.huawei.ethiopia.finance.resp;

import android.text.TextUtils;
import com.google.gson.annotations.SerializedName;
import com.huawei.http.BaseResp;

public class FinanceProductInfo extends BaseResp {
    private String accountNo;
    private String accountType;
    private String balance;
    private boolean isShow;
    private String maturityDate;
    private String principalAmount;
    private String productDesc;
    @SerializedName(alternate = {"productDescI18N"}, value = "productDescI18n")
    private String productDescI18n;
    @SerializedName(alternate = {"productID"}, value = "productId")
    private String productId;
    private String productName;
    @SerializedName(alternate = {"productNameI18N"}, value = "productNameI18n")
    private String productNameI18n;
    private String productRateValue;
    private String productUnquieID;
    private String status;
    private String totalCapitalizationAmount;

    public String getAccountNo() {
        return this.accountNo;
    }

    public String getAccountType() {
        return this.accountType;
    }

    public String getBalance() {
        return this.balance;
    }

    public String getMaturityDate() {
        return this.maturityDate;
    }

    public String getPrincipalAmount() {
        return this.principalAmount;
    }

    public String getProductDesc() {
        return this.productDesc;
    }

    public String getProductDescI18n() {
        if (TextUtils.isEmpty(this.productDescI18n)) {
            return this.productDesc;
        }
        return this.productDescI18n;
    }

    public String getProductId() {
        return this.productId;
    }

    public String getProductName() {
        return this.productName;
    }

    public String getProductNameI18n() {
        if (TextUtils.isEmpty(this.productNameI18n)) {
            return this.productName;
        }
        return this.productNameI18n;
    }

    public String getProductRateValue() {
        return this.productRateValue;
    }

    public String getProductUnquieID() {
        return this.productUnquieID;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTotalCapitalizationAmount() {
        return this.totalCapitalizationAmount;
    }

    public boolean isShow() {
        return this.isShow;
    }

    public void setAccountNo(String str) {
        this.accountNo = str;
    }

    public void setAccountType(String str) {
        this.accountType = str;
    }

    public void setBalance(String str) {
        this.balance = str;
    }

    public void setMaturityDate(String str) {
        this.maturityDate = str;
    }

    public void setPrincipalAmount(String str) {
        this.principalAmount = str;
    }

    public void setProductDesc(String str) {
        this.productDesc = str;
    }

    public void setProductDescI18n(String str) {
        this.productDescI18n = str;
    }

    public void setProductId(String str) {
        this.productId = str;
    }

    public void setProductName(String str) {
        this.productName = str;
    }

    public void setProductNameI18n(String str) {
        this.productNameI18n = str;
    }

    public void setProductRateValue(String str) {
        this.productRateValue = str;
    }

    public void setProductUnquieID(String str) {
        this.productUnquieID = str;
    }

    public void setShow(boolean z) {
        this.isShow = z;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setTotalCapitalizationAmount(String str) {
        this.totalCapitalizationAmount = str;
    }
}
