package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;

public class FinanceServiceUIConfig implements Serializable {
    private String avaliableLimitTitle;
    private String balanceTitle;
    private String bankName;
    private String color;
    private String icon;
    private LoanConfig loan;
    private String maxLimitTitle;
    private SavingConfig saving;

    public String getAvaliableLimitTitle() {
        return this.avaliableLimitTitle;
    }

    public String getBalanceTitle() {
        return this.balanceTitle;
    }

    public String getBankName() {
        return this.bankName;
    }

    public String getColor() {
        return this.color;
    }

    public String getIcon() {
        return this.icon;
    }

    public LoanConfig getLoan() {
        return this.loan;
    }

    public String getMaxLimitTitle() {
        return this.maxLimitTitle;
    }

    public SavingConfig getSaving() {
        return this.saving;
    }

    public void setAvaliableLimitTitle(String str) {
        this.avaliableLimitTitle = str;
    }

    public void setBalanceTitle(String str) {
        this.balanceTitle = str;
    }

    public void setBankName(String str) {
        this.bankName = str;
    }

    public void setColor(String str) {
        this.color = str;
    }

    public void setIcon(String str) {
        this.icon = str;
    }

    public void setLoan(LoanConfig loanConfig) {
        this.loan = loanConfig;
    }

    public void setMaxLimitTitle(String str) {
        this.maxLimitTitle = str;
    }

    public void setSaving(SavingConfig savingConfig) {
        this.saving = savingConfig;
    }
}
