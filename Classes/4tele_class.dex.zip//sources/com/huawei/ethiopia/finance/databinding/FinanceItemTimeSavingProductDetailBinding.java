package com.huawei.ethiopia.finance.databinding;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.LoadingButton;

public abstract class FinanceItemTimeSavingProductDetailBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final TextView b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;

    public FinanceItemTimeSavingProductDetailBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = textView;
        this.c = textView2;
        this.d = textView3;
    }
}
