package com.huawei.ethiopia.finance;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(81);
            a = hashMap;
            hashMap.put("layout/activity_contract_detail_0", Integer.valueOf(R$layout.activity_contract_detail));
            hashMap.put("layout/activity_finance_market_0", Integer.valueOf(R$layout.activity_finance_market));
            hashMap.put("layout/activity_finance_market_guide_0", Integer.valueOf(R$layout.activity_finance_market_guide));
            hashMap.put("layout/activity_finance_repayment_0", Integer.valueOf(R$layout.activity_finance_repayment));
            hashMap.put("layout/activity_finance_repayment_confirmation_0", Integer.valueOf(R$layout.activity_finance_repayment_confirmation));
            hashMap.put("layout/activity_loan_category_market_0", Integer.valueOf(R$layout.activity_loan_category_market));
            hashMap.put("layout/activity_loan_market_0", Integer.valueOf(R$layout.activity_loan_market));
            hashMap.put("layout/finance_activity_active_saving_0", Integer.valueOf(R$layout.finance_activity_active_saving));
            hashMap.put("layout/finance_activity_apply_loan_product_0", Integer.valueOf(R$layout.finance_activity_apply_loan_product));
            hashMap.put("layout/finance_activity_credit_contract_detail_0", Integer.valueOf(R$layout.finance_activity_credit_contract_detail));
            hashMap.put("layout/finance_activity_credit_pay_home_0", Integer.valueOf(R$layout.finance_activity_credit_pay_home));
            hashMap.put("layout/finance_activity_deposit_with_draw_0", Integer.valueOf(R$layout.finance_activity_deposit_with_draw));
            hashMap.put("layout/finance_activity_finance_agreement_0", Integer.valueOf(R$layout.finance_activity_finance_agreement));
            hashMap.put("layout/finance_activity_finance_loan_home_0", Integer.valueOf(R$layout.finance_activity_finance_loan_home));
            hashMap.put("layout/finance_activity_finance_service_0", Integer.valueOf(R$layout.finance_activity_finance_service));
            hashMap.put("layout/finance_activity_finance_service_config_0", Integer.valueOf(R$layout.finance_activity_finance_service_config));
            hashMap.put("layout/finance_activity_loan_contract_detail_0", Integer.valueOf(R$layout.finance_activity_loan_contract_detail));
            hashMap.put("layout/finance_activity_locked_closed_saving_0", Integer.valueOf(R$layout.finance_activity_locked_closed_saving));
            hashMap.put("layout/finance_activity_locked_saving_account_0", Integer.valueOf(R$layout.finance_activity_locked_saving_account));
            hashMap.put("layout/finance_activity_locked_saving_account_detail_0", Integer.valueOf(R$layout.finance_activity_locked_saving_account_detail));
            hashMap.put("layout/finance_activity_locked_saving_product_detail_0", Integer.valueOf(R$layout.finance_activity_locked_saving_product_detail));
            hashMap.put("layout/finance_activity_my_telebirr_mela_0", Integer.valueOf(R$layout.finance_activity_my_telebirr_mela));
            hashMap.put("layout/finance_activity_saving_0", Integer.valueOf(R$layout.finance_activity_saving));
            hashMap.put("layout/finance_activity_saving_product_detail_0", Integer.valueOf(R$layout.finance_activity_saving_product_detail));
            hashMap.put("layout/finance_activity_transaction_result_0", Integer.valueOf(R$layout.finance_activity_transaction_result));
            hashMap.put("layout/finance_bankaccount_dialog_select_bank_0", Integer.valueOf(R$layout.finance_bankaccount_dialog_select_bank));
            hashMap.put("layout/finance_bankaccount_item_bank_0", Integer.valueOf(R$layout.finance_bankaccount_item_bank));
            hashMap.put("layout/finance_bottom_display_dialog_layout_0", Integer.valueOf(R$layout.finance_bottom_display_dialog_layout));
            hashMap.put("layout/finance_credit_contract_detail_head_0", Integer.valueOf(R$layout.finance_credit_contract_detail_head));
            hashMap.put("layout/finance_deactive_loan_layout_0", Integer.valueOf(R$layout.finance_deactive_loan_layout));
            hashMap.put("layout/finance_dialog_saving_transaction_detail_0", Integer.valueOf(R$layout.finance_dialog_saving_transaction_detail));
            hashMap.put("layout/finance_filter_product_select_0", Integer.valueOf(R$layout.finance_filter_product_select));
            hashMap.put("layout/finance_filter_product_select_bank_0", Integer.valueOf(R$layout.finance_filter_product_select_bank));
            hashMap.put("layout/finance_fragment_credit_pay_contracts_0", Integer.valueOf(R$layout.finance_fragment_credit_pay_contracts));
            hashMap.put("layout/finance_fragment_finance_apply_loan_0", Integer.valueOf(R$layout.finance_fragment_finance_apply_loan));
            hashMap.put("layout/finance_fragment_finance_market_0", Integer.valueOf(R$layout.finance_fragment_finance_market));
            hashMap.put("layout/finance_fragment_finance_my_telebirr_tela_0", Integer.valueOf(R$layout.finance_fragment_finance_my_telebirr_tela));
            hashMap.put("layout/finance_fragment_loan_contracts_0", Integer.valueOf(R$layout.finance_fragment_loan_contracts));
            hashMap.put("layout/finance_fragment_loan_home_0", Integer.valueOf(R$layout.finance_fragment_loan_home));
            hashMap.put("layout/finance_fragment_loan_home_unactive_0", Integer.valueOf(R$layout.finance_fragment_loan_home_unactive));
            hashMap.put("layout/finance_fragment_service_0", Integer.valueOf(R$layout.finance_fragment_service));
            hashMap.put("layout/finance_home_balance_0", Integer.valueOf(R$layout.finance_home_balance));
            hashMap.put("layout/finance_item_contract_display_0", Integer.valueOf(R$layout.finance_item_contract_display));
            hashMap.put("layout/finance_item_credit_pay_contacts_0", Integer.valueOf(R$layout.finance_item_credit_pay_contacts));
            hashMap.put("layout/finance_item_credit_pay_product_group_0", Integer.valueOf(R$layout.finance_item_credit_pay_product_group));
            hashMap.put("layout/finance_item_credit_pay_transaction_0", Integer.valueOf(R$layout.finance_item_credit_pay_transaction));
            hashMap.put("layout/finance_item_filter_product_0", Integer.valueOf(R$layout.finance_item_filter_product));
            hashMap.put("layout/finance_item_finance_contracts_0", Integer.valueOf(R$layout.finance_item_finance_contracts));
            hashMap.put("layout/finance_item_finance_loan_contracts_0", Integer.valueOf(R$layout.finance_item_finance_loan_contracts));
            hashMap.put("layout/finance_item_finance_menu_0", Integer.valueOf(R$layout.finance_item_finance_menu));
            hashMap.put("layout/finance_item_loan_contact_schedule_0", Integer.valueOf(R$layout.finance_item_loan_contact_schedule));
            hashMap.put("layout/finance_item_loan_contacts_0", Integer.valueOf(R$layout.finance_item_loan_contacts));
            hashMap.put("layout/finance_item_loan_contract_transaction_0", Integer.valueOf(R$layout.finance_item_loan_contract_transaction));
            hashMap.put("layout/finance_item_loan_market_product_0", Integer.valueOf(R$layout.finance_item_loan_market_product));
            hashMap.put("layout/finance_item_loan_product_0", Integer.valueOf(R$layout.finance_item_loan_product));
            hashMap.put("layout/finance_item_loan_product_detail_0", Integer.valueOf(R$layout.finance_item_loan_product_detail));
            hashMap.put("layout/finance_item_loan_product_group_0", Integer.valueOf(R$layout.finance_item_loan_product_group));
            hashMap.put("layout/finance_item_loan_restructure_0", Integer.valueOf(R$layout.finance_item_loan_restructure));
            hashMap.put("layout/finance_item_locked_close_saving_account_0", Integer.valueOf(R$layout.finance_item_locked_close_saving_account));
            hashMap.put("layout/finance_item_locked_saving_account_0", Integer.valueOf(R$layout.finance_item_locked_saving_account));
            hashMap.put("layout/finance_item_locked_saving_contract_0", Integer.valueOf(R$layout.finance_item_locked_saving_contract));
            hashMap.put("layout/finance_item_market_product_title_0", Integer.valueOf(R$layout.finance_item_market_product_title));
            hashMap.put("layout/finance_item_my_closed_saving_time_product_0", Integer.valueOf(R$layout.finance_item_my_closed_saving_time_product));
            hashMap.put("layout/finance_item_my_fixed_time_saving_detail_0", Integer.valueOf(R$layout.finance_item_my_fixed_time_saving_detail));
            hashMap.put("layout/finance_item_od_active_contract_balance_0", Integer.valueOf(R$layout.finance_item_od_active_contract_balance));
            hashMap.put("layout/finance_item_pre_apply_result_0", Integer.valueOf(R$layout.finance_item_pre_apply_result));
            hashMap.put("layout/finance_item_result_display_0", Integer.valueOf(R$layout.finance_item_result_display));
            hashMap.put("layout/finance_item_saving_can_active_product_0", Integer.valueOf(R$layout.finance_item_saving_can_active_product));
            hashMap.put("layout/finance_item_saving_product_0", Integer.valueOf(R$layout.finance_item_saving_product));
            hashMap.put("layout/finance_item_saving_product_balance_0", Integer.valueOf(R$layout.finance_item_saving_product_balance));
            hashMap.put("layout/finance_item_saving_product_transaction_0", Integer.valueOf(R$layout.finance_item_saving_product_transaction));
            hashMap.put("layout/finance_item_saving_product_transaction_title_0", Integer.valueOf(R$layout.finance_item_saving_product_transaction_title));
            hashMap.put("layout/finance_item_saving_time_product_0", Integer.valueOf(R$layout.finance_item_saving_time_product));
            hashMap.put("layout/finance_item_time_saving_all_balance_0", Integer.valueOf(R$layout.finance_item_time_saving_all_balance));
            hashMap.put("layout/finance_item_time_saving_product_detail_0", Integer.valueOf(R$layout.finance_item_time_saving_product_detail));
            hashMap.put("layout/finance_layout_query_error_0", Integer.valueOf(R$layout.finance_layout_query_error));
            hashMap.put("layout/finance_layout_service_banner_0", Integer.valueOf(R$layout.finance_layout_service_banner));
            hashMap.put("layout/finance_loan_active_contracts_balance_0", Integer.valueOf(R$layout.finance_loan_active_contracts_balance));
            hashMap.put("layout/finance_loan_contract_detail_head_0", Integer.valueOf(R$layout.finance_loan_contract_detail_head));
            hashMap.put("layout/finance_loan_contract_detail_head_repayment_schedule_0", Integer.valueOf(R$layout.finance_loan_contract_detail_head_repayment_schedule));
            hashMap.put("layout/finance_no_relevant_data_0", Integer.valueOf(R$layout.finance_no_relevant_data));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(81);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_contract_detail, 1);
        sparseIntArray.put(R$layout.activity_finance_market, 2);
        sparseIntArray.put(R$layout.activity_finance_market_guide, 3);
        sparseIntArray.put(R$layout.activity_finance_repayment, 4);
        sparseIntArray.put(R$layout.activity_finance_repayment_confirmation, 5);
        sparseIntArray.put(R$layout.activity_loan_category_market, 6);
        sparseIntArray.put(R$layout.activity_loan_market, 7);
        sparseIntArray.put(R$layout.finance_activity_active_saving, 8);
        sparseIntArray.put(R$layout.finance_activity_apply_loan_product, 9);
        sparseIntArray.put(R$layout.finance_activity_credit_contract_detail, 10);
        sparseIntArray.put(R$layout.finance_activity_credit_pay_home, 11);
        sparseIntArray.put(R$layout.finance_activity_deposit_with_draw, 12);
        sparseIntArray.put(R$layout.finance_activity_finance_agreement, 13);
        sparseIntArray.put(R$layout.finance_activity_finance_loan_home, 14);
        sparseIntArray.put(R$layout.finance_activity_finance_service, 15);
        sparseIntArray.put(R$layout.finance_activity_finance_service_config, 16);
        sparseIntArray.put(R$layout.finance_activity_loan_contract_detail, 17);
        sparseIntArray.put(R$layout.finance_activity_locked_closed_saving, 18);
        sparseIntArray.put(R$layout.finance_activity_locked_saving_account, 19);
        sparseIntArray.put(R$layout.finance_activity_locked_saving_account_detail, 20);
        sparseIntArray.put(R$layout.finance_activity_locked_saving_product_detail, 21);
        sparseIntArray.put(R$layout.finance_activity_my_telebirr_mela, 22);
        sparseIntArray.put(R$layout.finance_activity_saving, 23);
        sparseIntArray.put(R$layout.finance_activity_saving_product_detail, 24);
        sparseIntArray.put(R$layout.finance_activity_transaction_result, 25);
        sparseIntArray.put(R$layout.finance_bankaccount_dialog_select_bank, 26);
        sparseIntArray.put(R$layout.finance_bankaccount_item_bank, 27);
        sparseIntArray.put(R$layout.finance_bottom_display_dialog_layout, 28);
        sparseIntArray.put(R$layout.finance_credit_contract_detail_head, 29);
        sparseIntArray.put(R$layout.finance_deactive_loan_layout, 30);
        sparseIntArray.put(R$layout.finance_dialog_saving_transaction_detail, 31);
        sparseIntArray.put(R$layout.finance_filter_product_select, 32);
        sparseIntArray.put(R$layout.finance_filter_product_select_bank, 33);
        sparseIntArray.put(R$layout.finance_fragment_credit_pay_contracts, 34);
        sparseIntArray.put(R$layout.finance_fragment_finance_apply_loan, 35);
        sparseIntArray.put(R$layout.finance_fragment_finance_market, 36);
        sparseIntArray.put(R$layout.finance_fragment_finance_my_telebirr_tela, 37);
        sparseIntArray.put(R$layout.finance_fragment_loan_contracts, 38);
        sparseIntArray.put(R$layout.finance_fragment_loan_home, 39);
        sparseIntArray.put(R$layout.finance_fragment_loan_home_unactive, 40);
        sparseIntArray.put(R$layout.finance_fragment_service, 41);
        sparseIntArray.put(R$layout.finance_home_balance, 42);
        sparseIntArray.put(R$layout.finance_item_contract_display, 43);
        sparseIntArray.put(R$layout.finance_item_credit_pay_contacts, 44);
        sparseIntArray.put(R$layout.finance_item_credit_pay_product_group, 45);
        sparseIntArray.put(R$layout.finance_item_credit_pay_transaction, 46);
        sparseIntArray.put(R$layout.finance_item_filter_product, 47);
        sparseIntArray.put(R$layout.finance_item_finance_contracts, 48);
        sparseIntArray.put(R$layout.finance_item_finance_loan_contracts, 49);
        sparseIntArray.put(R$layout.finance_item_finance_menu, 50);
        sparseIntArray.put(R$layout.finance_item_loan_contact_schedule, 51);
        sparseIntArray.put(R$layout.finance_item_loan_contacts, 52);
        sparseIntArray.put(R$layout.finance_item_loan_contract_transaction, 53);
        sparseIntArray.put(R$layout.finance_item_loan_market_product, 54);
        sparseIntArray.put(R$layout.finance_item_loan_product, 55);
        sparseIntArray.put(R$layout.finance_item_loan_product_detail, 56);
        sparseIntArray.put(R$layout.finance_item_loan_product_group, 57);
        sparseIntArray.put(R$layout.finance_item_loan_restructure, 58);
        sparseIntArray.put(R$layout.finance_item_locked_close_saving_account, 59);
        sparseIntArray.put(R$layout.finance_item_locked_saving_account, 60);
        sparseIntArray.put(R$layout.finance_item_locked_saving_contract, 61);
        sparseIntArray.put(R$layout.finance_item_market_product_title, 62);
        sparseIntArray.put(R$layout.finance_item_my_closed_saving_time_product, 63);
        sparseIntArray.put(R$layout.finance_item_my_fixed_time_saving_detail, 64);
        sparseIntArray.put(R$layout.finance_item_od_active_contract_balance, 65);
        sparseIntArray.put(R$layout.finance_item_pre_apply_result, 66);
        sparseIntArray.put(R$layout.finance_item_result_display, 67);
        sparseIntArray.put(R$layout.finance_item_saving_can_active_product, 68);
        sparseIntArray.put(R$layout.finance_item_saving_product, 69);
        sparseIntArray.put(R$layout.finance_item_saving_product_balance, 70);
        sparseIntArray.put(R$layout.finance_item_saving_product_transaction, 71);
        sparseIntArray.put(R$layout.finance_item_saving_product_transaction_title, 72);
        sparseIntArray.put(R$layout.finance_item_saving_time_product, 73);
        sparseIntArray.put(R$layout.finance_item_time_saving_all_balance, 74);
        sparseIntArray.put(R$layout.finance_item_time_saving_product_detail, 75);
        sparseIntArray.put(R$layout.finance_layout_query_error, 76);
        sparseIntArray.put(R$layout.finance_layout_service_banner, 77);
        sparseIntArray.put(R$layout.finance_loan_active_contracts_balance, 78);
        sparseIntArray.put(R$layout.finance_loan_contract_detail_head, 79);
        sparseIntArray.put(R$layout.finance_loan_contract_detail_head_repayment_schedule, 80);
        sparseIntArray.put(R$layout.finance_no_relevant_data, 81);
    }

    /* JADX WARNING: type inference failed for: r9v16, types: [com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBinding, com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r9v26, types: [com.huawei.ethiopia.finance.databinding.FinanceCreditContractDetailHeadBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r11v23, types: [com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBinding, com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r10v49, types: [androidx.databinding.ViewDataBinding, com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMyTelebirrTelaBindingImpl] */
    /* JADX WARNING: type inference failed for: r0v376, types: [com.huawei.ethiopia.finance.databinding.FinanceFragmentServiceBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r10v61, types: [com.huawei.ethiopia.finance.databinding.FinanceItemFinanceLoanContractsBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: Code restructure failed: missing block: B:171:0x0934, code lost:
        r2 = com.huawei.ethiopia.finance.R$id.rootLayout;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 6 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static androidx.databinding.ViewDataBinding a(androidx.databinding.DataBindingComponent r23, android.view.View r24, int r25, java.lang.Object r26) {
        /*
            r1 = r23
            r15 = r24
            r0 = r26
            r3 = 11
            r13 = 10
            r12 = 9
            r11 = 8
            r10 = 7
            r9 = 6
            r8 = 5
            r7 = 3
            r6 = 4
            r2 = 1
            r14 = 0
            r4 = 0
            switch(r25) {
                case 1: goto L_0x0fa0;
                case 2: goto L_0x0f85;
                case 3: goto L_0x0f6a;
                case 4: goto L_0x0f18;
                case 5: goto L_0x0efd;
                case 6: goto L_0x0ec1;
                case 7: goto L_0x0ea6;
                case 8: goto L_0x0e67;
                case 9: goto L_0x0df6;
                case 10: goto L_0x0dc1;
                case 11: goto L_0x0d2e;
                case 12: goto L_0x0cd1;
                case 13: goto L_0x0c8d;
                case 14: goto L_0x0c28;
                case 15: goto L_0x0bb9;
                case 16: goto L_0x0b56;
                case 17: goto L_0x0b21;
                case 18: goto L_0x0ae7;
                case 19: goto L_0x0a9c;
                case 20: goto L_0x0a2e;
                case 21: goto L_0x09d3;
                case 22: goto L_0x099e;
                case 23: goto L_0x08fc;
                case 24: goto L_0x088d;
                case 25: goto L_0x0814;
                case 26: goto L_0x07c2;
                case 27: goto L_0x0784;
                case 28: goto L_0x0737;
                case 29: goto L_0x06c8;
                case 30: goto L_0x0697;
                case 31: goto L_0x065a;
                case 32: goto L_0x0618;
                case 33: goto L_0x05d1;
                case 34: goto L_0x0576;
                case 35: goto L_0x0512;
                case 36: goto L_0x04d9;
                case 37: goto L_0x0464;
                case 38: goto L_0x03fc;
                case 39: goto L_0x03c9;
                case 40: goto L_0x038c;
                case 41: goto L_0x02cc;
                case 42: goto L_0x0265;
                case 43: goto L_0x0233;
                case 44: goto L_0x01e0;
                case 45: goto L_0x01a5;
                case 46: goto L_0x015e;
                case 47: goto L_0x0123;
                case 48: goto L_0x00d8;
                case 49: goto L_0x0070;
                case 50: goto L_0x001a;
                default: goto L_0x0019;
            }
        L_0x0019:
            return r4
        L_0x001a:
            java.lang.String r3 = "layout/finance_item_finance_menu_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x0064
            com.huawei.ethiopia.finance.databinding.FinanceItemFinanceMenuBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemFinanceMenuBindingImpl
            android.util.SparseIntArray r3 = com.huawei.ethiopia.finance.databinding.FinanceItemFinanceMenuBindingImpl.b
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r13, r4, r3)
            r5 = r3[r12]
            android.view.View r5 = (android.view.View) r5
            r2 = r3[r2]
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            r2 = r3[r11]
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            r2 = r3[r9]
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            r2 = r3[r8]
            androidx.recyclerview.widget.RecyclerView r2 = (androidx.recyclerview.widget.RecyclerView) r2
            r2 = r3[r6]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r3[r10]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r3[r7]
            com.huawei.common.widget.round.RoundTextView r2 = (com.huawei.common.widget.round.RoundTextView) r2
            r2 = 2
            r2 = r3[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0.<init>(r1, r15, r14)
            r12 = -1
            r0.a = r12
            r1 = r3[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r4)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0064:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_finance_menu is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0070:
            r12 = -1
            java.lang.String r3 = "layout/finance_item_finance_loan_contracts_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x00cc
            com.huawei.ethiopia.finance.databinding.FinanceItemFinanceLoanContractsBindingImpl r5 = new com.huawei.ethiopia.finance.databinding.FinanceItemFinanceLoanContractsBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemFinanceLoanContractsBindingImpl.i
            java.lang.Object[] r11 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r11, r4, r0)
            r0 = r11[r9]
            r3 = r0
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = r11[r10]
            r9 = r0
            com.huawei.common.widget.round.RoundTextView r9 = (com.huawei.common.widget.round.RoundTextView) r9
            r0 = r11[r2]
            r10 = r0
            android.widget.TextView r10 = (android.widget.TextView) r10
            r0 = r11[r6]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r11[r8]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = 2
            r0 = r11[r0]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = r11[r7]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = r5
            r1 = r23
            r2 = r24
            r7 = r4
            r4 = r9
            r9 = r5
            r5 = r10
            r10 = r7
            r7 = r8
            r8 = r16
            r10 = r9
            r9 = r17
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r10.h = r12
            r0 = r11[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r10.setRootTag(r15)
            r10.invalidateAll()
            return r10
        L_0x00cc:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_finance_loan_contracts is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x00d8:
            r11 = r4
            r12 = -1
            java.lang.String r3 = "layout/finance_item_finance_contracts_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x0117
            com.huawei.ethiopia.finance.databinding.FinanceItemFinanceContractsBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemFinanceContractsBindingImpl
            android.util.SparseIntArray r3 = com.huawei.ethiopia.finance.databinding.FinanceItemFinanceContractsBindingImpl.b
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r10, r11, r3)
            r4 = r3[r9]
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r4 = 2
            r4 = r3[r4]
            android.view.View r4 = (android.view.View) r4
            r4 = r3[r7]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r4 = r3[r8]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r2 = r3[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r3[r6]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0.<init>(r1, r15, r14)
            r0.a = r12
            r1 = r3[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r11)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0117:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_finance_contracts is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0123:
            r11 = r4
            r12 = -1
            java.lang.String r3 = "layout/finance_item_filter_product_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x0152
            com.huawei.ethiopia.finance.databinding.FinanceItemFilterProductBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemFilterProductBindingImpl
            android.util.SparseIntArray r3 = com.huawei.ethiopia.finance.databinding.FinanceItemFilterProductBindingImpl.d
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r11, r3)
            r4 = 2
            r4 = r3[r4]
            com.huawei.common.widget.round.RoundImageView r4 = (com.huawei.common.widget.round.RoundImageView) r4
            r2 = r3[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0.<init>(r1, r15, r4, r2)
            r0.c = r12
            r1 = r3[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r11)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0152:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_filter_product is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x015e:
            r11 = r4
            r12 = -1
            java.lang.String r3 = "layout/finance_item_credit_pay_transaction_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x0199
            com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayTransactionBindingImpl r8 = new com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayTransactionBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayTransactionBindingImpl.f
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r6, r11, r0)
            r3 = r0[r14]
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r4 = r0[r7]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r5 = 2
            r5 = r0[r5]
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r0[r2]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r8
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r8.e = r12
            androidx.constraintlayout.widget.ConstraintLayout r0 = r8.a
            r0.setTag(r11)
            r8.setRootTag(r15)
            r8.invalidateAll()
            return r8
        L_0x0199:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_credit_pay_transaction is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x01a5:
            r11 = r4
            r12 = -1
            java.lang.String r3 = "layout/finance_item_credit_pay_product_group_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x01d4
            com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayProductGroupBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayProductGroupBindingImpl
            android.util.SparseIntArray r3 = com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayProductGroupBindingImpl.d
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r11, r3)
            r4 = 2
            r4 = r3[r4]
            androidx.recyclerview.widget.RecyclerView r4 = (androidx.recyclerview.widget.RecyclerView) r4
            r2 = r3[r2]
            com.huawei.common.widget.round.RoundTextView r2 = (com.huawei.common.widget.round.RoundTextView) r2
            r0.<init>(r15, r1, r4, r2)
            r0.c = r12
            r1 = r3[r14]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r11)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x01d4:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_credit_pay_product_group is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x01e0:
            r11 = r4
            r12 = -1
            java.lang.String r3 = "layout/finance_item_credit_pay_contacts_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x0227
            com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayContactsBindingImpl r10 = new com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayContactsBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemCreditPayContactsBindingImpl.g
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r9, r11, r0)
            r3 = r0[r8]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r4 = r0[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r4 = (com.huawei.common.widget.round.RoundConstraintLayout) r4
            r2 = r0[r2]
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            r2 = r0[r7]
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            r2 = 2
            r2 = r0[r2]
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r0[r6]
            com.huawei.common.widget.round.RoundTextView r0 = (com.huawei.common.widget.round.RoundTextView) r0
            r0 = r10
            r1 = r23
            r2 = r24
            r6 = r7
            r7 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r10.f = r12
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r10.b
            r0.setTag(r11)
            r10.setRootTag(r15)
            r10.invalidateAll()
            return r10
        L_0x0227:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_credit_pay_contacts is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0233:
            r11 = r4
            r12 = -1
            java.lang.String r3 = "layout/finance_item_contract_display_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x0259
            com.huawei.ethiopia.finance.databinding.FinanceItemContractDisplayBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemContractDisplayBindingImpl
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r2, r11, r11)
            r2 = r2[r14]
            com.huawei.common.widget.DisplayView r2 = (com.huawei.common.widget.DisplayView) r2
            r0.<init>(r1, r15, r2)
            r0.b = r12
            com.huawei.common.widget.DisplayView r1 = r0.a
            r1.setTag(r11)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x0259:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_item_contract_display is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0265:
            java.lang.String r5 = "layout/finance_home_balance_0"
            boolean r5 = r5.equals(r0)
            if (r5 == 0) goto L_0x02c0
            com.huawei.ethiopia.finance.databinding.FinanceHomeBalanceBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceHomeBalanceBindingImpl
            android.util.SparseIntArray r5 = com.huawei.ethiopia.finance.databinding.FinanceHomeBalanceBindingImpl.b
            r14 = 13
            java.lang.Object[] r5 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r14, r4, r5)
            r2 = r5[r2]
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            r2 = r5[r6]
            android.view.View r2 = (android.view.View) r2
            r2 = r5[r7]
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            r2 = r5[r11]
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            r2 = 2
            r2 = r5[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r5[r8]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r5[r10]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r5[r12]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r5[r3]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r5[r13]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = 12
            r2 = r5[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r5[r9]
            androidx.constraintlayout.widget.Guideline r2 = (androidx.constraintlayout.widget.Guideline) r2
            r14 = 0
            r0.<init>(r1, r15, r14)
            r1 = -1
            r0.a = r1
            r1 = r5[r14]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1.setTag(r4)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x02c0:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_home_balance is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x02cc:
            r19 = -1
            java.lang.String r5 = "layout/finance_fragment_service_0"
            boolean r5 = r5.equals(r0)
            if (r5 == 0) goto L_0x0380
            com.huawei.ethiopia.finance.databinding.FinanceFragmentServiceBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentServiceBindingImpl
            android.util.SparseIntArray r5 = com.huawei.ethiopia.finance.databinding.FinanceFragmentServiceBindingImpl.r
            r6 = 21
            java.lang.Object[] r21 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r6, r4, r5)
            r5 = 2
            r5 = r21[r5]
            android.view.View r5 = (android.view.View) r5
            r3 = r21[r3]
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r5 = 17
            r5 = r21[r5]
            androidx.constraintlayout.widget.ConstraintLayout r5 = (androidx.constraintlayout.widget.ConstraintLayout) r5
            r6 = r4
            r4 = r5
            r5 = 14
            r5 = r21[r5]
            androidx.constraintlayout.widget.ConstraintLayout r5 = (androidx.constraintlayout.widget.ConstraintLayout) r5
            r2 = r21[r2]
            android.widget.ImageView r2 = (android.widget.ImageView) r2
            r2 = 18
            r2 = r21[r2]
            com.huawei.common.widget.round.RoundImageView r2 = (com.huawei.common.widget.round.RoundImageView) r2
            r6 = r2
            r2 = 12
            r2 = r21[r2]
            com.huawei.common.widget.round.RoundImageView r2 = (com.huawei.common.widget.round.RoundImageView) r2
            r10 = 3
            r7 = r2
            r2 = 15
            r2 = r21[r2]
            com.huawei.common.widget.round.RoundImageView r2 = (com.huawei.common.widget.round.RoundImageView) r2
            r11 = 5
            r8 = r2
            r2 = r21[r9]
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            r2 = r21[r10]
            r9 = r2
            android.widget.TextView r9 = (android.widget.TextView) r9
            r2 = r21[r11]
            r10 = r2
            android.widget.TextView r10 = (android.widget.TextView) r10
            r2 = 7
            r11 = 19
            r11 = r21[r11]
            android.widget.TextView r11 = (android.widget.TextView) r11
            r15 = 8
            r2 = r21[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r13 = 9
            r12 = r2
            r2 = r21[r13]
            r13 = r2
            android.widget.TextView r13 = (android.widget.TextView) r13
            r2 = 10
            r16 = 13
            r16 = r21[r16]
            android.widget.TextView r16 = (android.widget.TextView) r16
            r14 = r16
            r15 = r21[r15]
            android.widget.TextView r15 = (android.widget.TextView) r15
            r2 = r21[r2]
            r16 = r2
            android.widget.TextView r16 = (android.widget.TextView) r16
            r2 = 16
            r2 = r21[r2]
            r17 = r2
            android.widget.TextView r17 = (android.widget.TextView) r17
            r2 = 4
            r2 = r21[r2]
            androidx.constraintlayout.widget.Guideline r2 = (androidx.constraintlayout.widget.Guideline) r2
            r2 = 20
            r2 = r21[r2]
            r18 = r2
            androidx.viewpager2.widget.ViewPager2 r18 = (androidx.viewpager2.widget.ViewPager2) r18
            r2 = r0
            r1 = r23
            r22 = r2
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18)
            r0 = r22
            r12 = -1
            r0.q = r12
            r14 = 0
            r1 = r21[r14]
            androidx.core.widget.NestedScrollView r1 = (androidx.core.widget.NestedScrollView) r1
            r8 = 0
            r1.setTag(r8)
            r7 = r24
            r0.setRootTag(r7)
            r0.invalidateAll()
            return r0
        L_0x0380:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_service is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x038c:
            r8 = r4
            r7 = r15
            r10 = 3
            r12 = -1
            java.lang.String r3 = "layout/finance_fragment_loan_home_unactive_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x03bd
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBindingImpl
            android.util.SparseIntArray r3 = com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBindingImpl.d
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r10, r8, r3)
            r4 = 2
            r4 = r3[r4]
            com.huawei.common.widget.LoadingButton r4 = (com.huawei.common.widget.LoadingButton) r4
            r2 = r3[r2]
            com.huawei.common.widget.round.RoundTextView r2 = (com.huawei.common.widget.round.RoundTextView) r2
            r0.<init>(r1, r7, r4, r2)
            r0.c = r12
            r1 = r3[r14]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1.setTag(r8)
            r0.setRootTag(r7)
            r0.invalidateAll()
            return r0
        L_0x03bd:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_loan_home_unactive is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x03c9:
            r8 = r4
            r7 = r15
            r12 = -1
            java.lang.String r3 = "layout/finance_fragment_loan_home_0"
            boolean r3 = r3.equals(r0)
            if (r3 == 0) goto L_0x03f0
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeBindingImpl
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r2, r8, r8)
            r2 = r2[r14]
            android.widget.LinearLayout r2 = (android.widget.LinearLayout) r2
            r0.<init>(r1, r7, r2)
            r0.b = r12
            android.widget.LinearLayout r1 = r0.a
            r1.setTag(r8)
            r0.setRootTag(r7)
            r0.invalidateAll()
            return r0
        L_0x03f0:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_loan_home is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x03fc:
            r8 = r4
            r7 = r15
            r3 = 4
            r10 = 3
            r11 = 5
            r12 = -1
            java.lang.String r4 = "layout/finance_fragment_loan_contracts_0"
            boolean r4 = r4.equals(r0)
            if (r4 == 0) goto L_0x0458
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanContractsBindingImpl r15 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanContractsBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanContractsBindingImpl.f
            android.util.SparseIntArray r4 = com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanContractsBindingImpl.g
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r9, r0, r4)
            r0 = 2
            r0 = r9[r0]
            r4 = r0
            com.huawei.ethiopia.finance.databinding.FinanceLoanActiveContractsBalanceBinding r4 = (com.huawei.ethiopia.finance.databinding.FinanceLoanActiveContractsBalanceBinding) r4
            r0 = r9[r10]
            r5 = r0
            com.huawei.ethiopia.finance.databinding.FinanceDeactiveLoanLayoutBinding r5 = (com.huawei.ethiopia.finance.databinding.FinanceDeactiveLoanLayoutBinding) r5
            r0 = r9[r3]
            r6 = r0
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            r0 = r9[r11]
            r10 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r10 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r10
            r0 = r15
            r1 = r23
            r11 = 1
            r2 = r24
            r3 = r4
            r4 = r5
            r5 = r6
            r6 = r10
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r15.e = r12
            com.huawei.ethiopia.finance.databinding.FinanceLoanActiveContractsBalanceBinding r0 = r15.a
            r15.setContainedBinding(r0)
            com.huawei.ethiopia.finance.databinding.FinanceDeactiveLoanLayoutBinding r0 = r15.b
            r15.setContainedBinding(r0)
            r0 = r9[r14]
            androidx.core.widget.NestedScrollView r0 = (androidx.core.widget.NestedScrollView) r0
            r0.setTag(r8)
            r0 = r9[r11]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r8)
            r15.setRootTag(r7)
            r15.invalidateAll()
            return r15
        L_0x0458:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_loan_contracts is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0464:
            r8 = r4
            r7 = r15
            r2 = 7
            r3 = 4
            r4 = 1
            r10 = 3
            r11 = 5
            r12 = -1
            r15 = 8
            java.lang.String r5 = "layout/finance_fragment_finance_my_telebirr_tela_0"
            boolean r5 = r5.equals(r0)
            if (r5 == 0) goto L_0x04cd
            com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMyTelebirrTelaBindingImpl r6 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMyTelebirrTelaBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMyTelebirrTelaBindingImpl.i
            java.lang.Object[] r15 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r15, r8, r0)
            r0 = r15[r10]
            r5 = r0
            com.huawei.common.widget.round.RoundTextView r5 = (com.huawei.common.widget.round.RoundTextView) r5
            r0 = r15[r9]
            r9 = r0
            com.huawei.common.widget.round.RoundTextView r9 = (com.huawei.common.widget.round.RoundTextView) r9
            r0 = r15[r4]
            r10 = r0
            android.widget.LinearLayout r10 = (android.widget.LinearLayout) r10
            r0 = r15[r3]
            r17 = r0
            android.widget.LinearLayout r17 = (android.widget.LinearLayout) r17
            r0 = 2
            r0 = r15[r0]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = r15[r11]
            r11 = r0
            android.widget.TextView r11 = (android.widget.TextView) r11
            r0 = r15[r2]
            r18 = r0
            androidx.viewpager2.widget.ViewPager2 r18 = (androidx.viewpager2.widget.ViewPager2) r18
            r0 = r6
            r1 = r23
            r2 = r24
            r3 = r5
            r4 = r9
            r5 = r10
            r10 = r6
            r6 = r17
            r7 = r16
            r9 = r8
            r8 = r11
            r11 = r24
            r9 = r18
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r10.h = r12
            r0 = r15[r14]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r8 = 0
            r0.setTag(r8)
            r10.setRootTag(r11)
            r10.invalidateAll()
            return r10
        L_0x04cd:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_finance_my_telebirr_tela is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x04d9:
            r8 = r4
            r11 = r15
            r4 = 1
            r12 = -1
            java.lang.String r2 = "layout/finance_fragment_finance_market_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0506
            com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMarketBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMarketBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceMarketBindingImpl.c
            r3 = 2
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r11, r3, r8, r2)
            r3 = r2[r4]
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r0.<init>(r1, r11, r3)
            r0.b = r12
            r1 = r2[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r8)
            r0.setRootTag(r11)
            r0.invalidateAll()
            return r0
        L_0x0506:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_finance_market is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0512:
            r8 = r4
            r3 = 4
            r4 = 1
            r10 = 3
            r11 = 5
            r12 = -1
            java.lang.String r2 = "layout/finance_fragment_finance_apply_loan_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x056a
            com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBindingImpl.g
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceFragmentFinanceApplyLoanBindingImpl.h
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r9, r0, r2)
            r0 = 2
            r0 = r9[r0]
            r5 = r0
            com.huawei.ethiopia.finance.widget.CreditScoreView r5 = (com.huawei.ethiopia.finance.widget.CreditScoreView) r5
            r0 = r9[r11]
            r6 = r0
            android.widget.FrameLayout r6 = (android.widget.FrameLayout) r6
            r0 = r9[r4]
            r11 = r0
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r11 = (com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding) r11
            r0 = r9[r3]
            r16 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r16 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r16
            r0 = r9[r10]
            r10 = r0
            com.huawei.common.widget.round.RoundTextView r10 = (com.huawei.common.widget.round.RoundTextView) r10
            r0 = r7
            r1 = r23
            r2 = r24
            r3 = r5
            r4 = r6
            r5 = r11
            r6 = r16
            r11 = r7
            r7 = r10
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r11.f = r12
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r0 = r11.c
            r11.setContainedBinding(r0)
            r0 = r9[r14]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r8)
            r11.setRootTag(r15)
            r11.invalidateAll()
            return r11
        L_0x056a:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_finance_apply_loan is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0576:
            r8 = r4
            r3 = 4
            r4 = 1
            r10 = 3
            r11 = 5
            r12 = -1
            java.lang.String r2 = "layout/finance_fragment_credit_pay_contracts_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x05c5
            com.huawei.ethiopia.finance.databinding.FinanceFragmentCreditPayContractsBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceFragmentCreditPayContractsBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceFragmentCreditPayContractsBindingImpl.f
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceFragmentCreditPayContractsBindingImpl.g
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r11, r0, r2)
            r0 = r9[r4]
            r4 = r0
            com.huawei.ethiopia.finance.databinding.FinanceItemOdActiveContractBalanceBinding r4 = (com.huawei.ethiopia.finance.databinding.FinanceItemOdActiveContractBalanceBinding) r4
            r0 = r9[r3]
            r5 = r0
            com.huawei.common.widget.LoadingButton r5 = (com.huawei.common.widget.LoadingButton) r5
            r0 = 2
            r0 = r9[r0]
            r6 = r0
            com.huawei.common.widget.round.RoundLinearLayout r6 = (com.huawei.common.widget.round.RoundLinearLayout) r6
            r0 = r9[r10]
            r10 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r10 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r10
            r0 = r7
            r1 = r23
            r2 = r24
            r3 = r4
            r4 = r5
            r5 = r6
            r6 = r10
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r12
            com.huawei.ethiopia.finance.databinding.FinanceItemOdActiveContractBalanceBinding r0 = r7.a
            r7.setContainedBinding(r0)
            r0 = r9[r14]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r8)
            r7.setRootTag(r15)
            r7.invalidateAll()
            return r7
        L_0x05c5:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_fragment_credit_pay_contracts is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x05d1:
            r8 = r4
            r3 = 4
            r4 = 1
            r10 = 3
            r11 = 5
            r12 = -1
            java.lang.String r2 = "layout/finance_filter_product_select_bank_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x060c
            com.huawei.ethiopia.finance.databinding.FinanceFilterProductSelectBankBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceFilterProductSelectBankBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceFilterProductSelectBankBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r11, r8, r2)
            r5 = r2[r10]
            com.huawei.common.widget.round.RoundEditText r5 = (com.huawei.common.widget.round.RoundEditText) r5
            r4 = r2[r4]
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r3 = r2[r3]
            com.huawei.common.widget.recyclerview.HFRecyclerView r3 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r3
            r3 = 2
            r3 = r2[r3]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0.<init>(r1, r15, r14)
            r0.a = r12
            r1 = r2[r14]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r8)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x060c:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_filter_product_select_bank is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0618:
            r8 = r4
            r3 = 4
            r4 = 1
            r10 = 3
            r12 = -1
            java.lang.String r2 = "layout/finance_filter_product_select_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x064e
            com.huawei.ethiopia.finance.databinding.FinanceFilterProductSelectBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceFilterProductSelectBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceFilterProductSelectBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r8, r2)
            r3 = r2[r4]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r3 = r2[r10]
            com.huawei.common.widget.recyclerview.HFRecyclerView r3 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r3
            r4 = 2
            r4 = r2[r4]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0.<init>(r1, r15, r3, r4)
            r0.c = r12
            r1 = r2[r14]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r8)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x064e:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_filter_product_select is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x065a:
            r8 = r4
            r4 = 1
            r10 = 3
            r12 = -1
            java.lang.String r2 = "layout/finance_dialog_saving_transaction_detail_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x068b
            com.huawei.ethiopia.finance.databinding.FinanceDialogSavingTransactionDetailBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceDialogSavingTransactionDetailBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceDialogSavingTransactionDetailBindingImpl.c
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r10, r8, r2)
            r3 = 2
            r3 = r2[r3]
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r4 = r2[r4]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0.<init>(r1, r15, r3)
            r0.b = r12
            r1 = r2[r14]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r8)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x068b:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_dialog_saving_transaction_detail is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0697:
            r8 = r4
            r4 = 1
            r12 = -1
            java.lang.String r2 = "layout/finance_deactive_loan_layout_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x06bc
            com.huawei.ethiopia.finance.databinding.FinanceDeactiveLoanLayoutBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceDeactiveLoanLayoutBindingImpl
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r8, r8)
            r0.<init>(r1, r15, r14)
            r0.a = r12
            r1 = r2[r14]
            com.huawei.common.widget.round.RoundTextView r1 = (com.huawei.common.widget.round.RoundTextView) r1
            r1.setTag(r8)
            r0.setRootTag(r15)
            r0.invalidateAll()
            return r0
        L_0x06bc:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_deactive_loan_layout is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x06c8:
            r8 = r4
            r7 = r15
            r2 = 7
            r3 = 4
            r4 = 1
            r10 = 3
            r11 = 5
            r12 = -1
            r15 = 8
            java.lang.String r5 = "layout/finance_credit_contract_detail_head_0"
            boolean r5 = r5.equals(r0)
            if (r5 == 0) goto L_0x072b
            com.huawei.ethiopia.finance.databinding.FinanceCreditContractDetailHeadBindingImpl r6 = new com.huawei.ethiopia.finance.databinding.FinanceCreditContractDetailHeadBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceCreditContractDetailHeadBindingImpl.h
            java.lang.Object[] r15 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r15, r8, r0)
            r0 = 2
            r0 = r15[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = r15[r11]
            r5 = r0
            com.huawei.common.widget.DisplayView r5 = (com.huawei.common.widget.DisplayView) r5
            r0 = r15[r2]
            r11 = r0
            com.huawei.common.widget.DisplayView r11 = (com.huawei.common.widget.DisplayView) r11
            r0 = r15[r9]
            r9 = r0
            com.huawei.common.widget.DisplayView r9 = (com.huawei.common.widget.DisplayView) r9
            r0 = r15[r10]
            r10 = r0
            android.widget.TextView r10 = (android.widget.TextView) r10
            r0 = r15[r3]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = r15[r4]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = r6
            r1 = r23
            r2 = r24
            r3 = r5
            r4 = r11
            r5 = r9
            r9 = r6
            r6 = r10
            r11 = r7
            r7 = r16
            r10 = r8
            r8 = r17
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r9.g = r12
            r0 = r15[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0.setTag(r10)
            r9.setRootTag(r11)
            r9.invalidateAll()
            return r9
        L_0x072b:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_credit_contract_detail_head is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0737:
            r8 = r4
            r11 = r15
            r3 = 4
            r4 = 1
            r10 = 3
            r12 = -1
            java.lang.String r2 = "layout/finance_bottom_display_dialog_layout_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0778
            com.huawei.ethiopia.finance.databinding.FinanceBottomDisplayDialogLayoutBindingImpl r6 = new com.huawei.ethiopia.finance.databinding.FinanceBottomDisplayDialogLayoutBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceBottomDisplayDialogLayoutBindingImpl.e
            java.lang.Object[] r7 = androidx.databinding.ViewDataBinding.mapBindings(r1, r11, r3, r8, r0)
            r0 = 2
            r0 = r7[r0]
            r3 = r0
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r0 = r7[r10]
            r5 = r0
            androidx.recyclerview.widget.RecyclerView r5 = (androidx.recyclerview.widget.RecyclerView) r5
            r0 = r7[r4]
            r9 = r0
            android.widget.TextView r9 = (android.widget.TextView) r9
            r0 = r6
            r1 = r23
            r2 = r24
            r4 = r5
            r5 = r9
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r12
            r0 = r7[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0.setTag(r8)
            r6.setRootTag(r11)
            r6.invalidateAll()
            return r6
        L_0x0778:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_bottom_display_dialog_layout is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0784:
            r8 = r4
            r11 = r15
            r4 = 1
            r10 = 3
            r12 = -1
            java.lang.String r2 = "layout/finance_bankaccount_item_bank_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x07b6
            com.huawei.ethiopia.finance.databinding.FinanceBankaccountItemBankBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceBankaccountItemBankBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceBankaccountItemBankBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r11, r10, r8, r2)
            r3 = r2[r4]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r4 = 2
            r4 = r2[r4]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0.<init>(r1, r11, r3, r4)
            r0.c = r12
            r1 = r2[r14]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r8)
            r0.setRootTag(r11)
            r0.invalidateAll()
            return r0
        L_0x07b6:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_bankaccount_item_bank is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x07c2:
            r8 = r4
            r7 = r15
            r3 = 4
            r4 = 1
            r10 = 3
            r11 = 5
            r12 = -1
            java.lang.String r2 = "layout/finance_bankaccount_dialog_select_bank_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0808
            com.huawei.ethiopia.finance.databinding.FinanceBankaccountDialogSelectBankBindingImpl r6 = new com.huawei.ethiopia.finance.databinding.FinanceBankaccountDialogSelectBankBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceBankaccountDialogSelectBankBindingImpl.e
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r11, r8, r0)
            r0 = r9[r10]
            r5 = r0
            com.huawei.common.widget.round.RoundEditText r5 = (com.huawei.common.widget.round.RoundEditText) r5
            r0 = r9[r4]
            com.huawei.common.widget.round.RoundTextView r0 = (com.huawei.common.widget.round.RoundTextView) r0
            r0 = r9[r3]
            r4 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r4 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r4
            r0 = 2
            r0 = r9[r0]
            r10 = r0
            android.widget.TextView r10 = (android.widget.TextView) r10
            r0 = r6
            r1 = r23
            r2 = r24
            r3 = r5
            r5 = r10
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r12
            r0 = r9[r14]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0.setTag(r8)
            r6.setRootTag(r7)
            r6.invalidateAll()
            return r6
        L_0x0808:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_bankaccount_dialog_select_bank is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0814:
            r8 = r4
            r7 = r15
            r2 = 7
            r3 = 4
            r4 = 1
            r5 = -1
            r10 = 3
            r11 = 5
            r13 = 9
            r15 = 8
            java.lang.String r12 = "layout/finance_activity_transaction_result_0"
            boolean r12 = r12.equals(r0)
            if (r12 == 0) goto L_0x0881
            com.huawei.ethiopia.finance.databinding.FinanceActivityTransactionResultBindingImpl r12 = new com.huawei.ethiopia.finance.databinding.FinanceActivityTransactionResultBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityTransactionResultBindingImpl.i
            java.lang.Object[] r13 = androidx.databinding.ViewDataBinding.mapBindings(r1, r7, r13, r8, r0)
            r0 = r13[r15]
            r15 = r0
            com.huawei.common.widget.round.RoundTextView r15 = (com.huawei.common.widget.round.RoundTextView) r15
            r0 = r13[r4]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r13[r9]
            r4 = r0
            android.view.View r4 = (android.view.View) r4
            r0 = r13[r2]
            r9 = r0
            androidx.recyclerview.widget.RecyclerView r9 = (androidx.recyclerview.widget.RecyclerView) r9
            r0 = r13[r3]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = 2
            r0 = r13[r0]
            r16 = r0
            android.widget.TextView r16 = (android.widget.TextView) r16
            r0 = r13[r10]
            r10 = r0
            android.widget.TextView r10 = (android.widget.TextView) r10
            r0 = r13[r11]
            r11 = r0
            android.widget.TextView r11 = (android.widget.TextView) r11
            r0 = r12
            r1 = r23
            r2 = r24
            r3 = r15
            r14 = r5
            r5 = r9
            r6 = r17
            r7 = r16
            r9 = r8
            r8 = r10
            r10 = r24
            r9 = r11
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r12.h = r14
            r0 = 0
            r0 = r13[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r13 = 0
            r0.setTag(r13)
            r12.setRootTag(r10)
            r12.invalidateAll()
            return r12
        L_0x0881:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_transaction_result is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x088d:
            r13 = r4
            r12 = r15
            r2 = 7
            r3 = 4
            r4 = 1
            r10 = 3
            r11 = 5
            r14 = -1
            java.lang.String r5 = "layout/finance_activity_saving_product_detail_0"
            boolean r5 = r5.equals(r0)
            if (r5 == 0) goto L_0x08f0
            com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBindingImpl r8 = new com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBindingImpl.h
            android.util.SparseIntArray r5 = com.huawei.ethiopia.finance.databinding.FinanceActivitySavingProductDetailBindingImpl.i
            java.lang.Object[] r17 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r2, r0, r5)
            r0 = 2
            r0 = r17[r0]
            r5 = r0
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBalanceBinding r5 = (com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBalanceBinding) r5
            r0 = r17[r4]
            r4 = r0
            com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBinding r4 = (com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBinding) r4
            r0 = r17[r10]
            r6 = r0
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            r0 = r17[r3]
            r7 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r7 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r7
            r0 = r17[r9]
            r9 = r0
            com.huawei.common.widget.round.RoundTextView r9 = (com.huawei.common.widget.round.RoundTextView) r9
            r0 = r17[r11]
            r10 = r0
            com.huawei.common.widget.round.RoundTextView r10 = (com.huawei.common.widget.round.RoundTextView) r10
            r0 = r8
            r1 = r23
            r2 = r24
            r3 = r5
            r5 = r6
            r6 = r7
            r7 = r9
            r9 = r8
            r8 = r10
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r9.g = r14
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBalanceBinding r0 = r9.a
            r9.setContainedBinding(r0)
            com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBinding r0 = r9.b
            r9.setContainedBinding(r0)
            r0 = 0
            r0 = r17[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r13)
            r9.setRootTag(r12)
            r9.invalidateAll()
            return r9
        L_0x08f0:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_saving_product_detail is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x08fc:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_saving_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0992
            com.huawei.ethiopia.finance.databinding.FinanceActivitySavingBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceActivitySavingBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceActivitySavingBindingImpl.h
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceActivitySavingBindingImpl.i
            r3 = 7
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r3, r0, r2)
            r0 = 6
            r0 = r10[r0]
            r3 = r0
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r0 = 5
            r0 = r10[r0]
            r4 = r0
            android.widget.FrameLayout r4 = (android.widget.FrameLayout) r4
            r0 = 2
            r0 = r10[r0]
            r5 = r0
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r5 = (com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding) r5
            r0 = 1
            r0 = r10[r0]
            r11 = 0
            if (r0 == 0) goto L_0x0965
            android.view.View r0 = (android.view.View) r0
            int r2 = com.huawei.ethiopia.finance.R$id.ivSinq
            android.view.View r6 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r2)
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            if (r6 == 0) goto L_0x0951
            int r2 = com.huawei.ethiopia.finance.R$id.rootLayout
            android.view.View r7 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r2)
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            if (r7 == 0) goto L_0x0951
            int r2 = com.huawei.ethiopia.finance.R$id.tvSinq
            android.view.View r8 = androidx.viewbinding.ViewBindings.findChildViewById(r0, r2)
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0951
            com.huawei.ethiopia.finance.databinding.FinanceMyFixedSavingLayoutBinding r2 = new com.huawei.ethiopia.finance.databinding.FinanceMyFixedSavingLayoutBinding
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r2.<init>(r0, r6, r7, r8)
            r6 = r2
            goto L_0x0966
        L_0x0951:
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r0 = r0.getResourceName(r2)
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "Missing required view with ID: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L_0x0965:
            r6 = r11
        L_0x0966:
            r0 = 3
            r0 = r10[r0]
            r7 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r7 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r7
            r0 = 4
            r0 = r10[r0]
            r8 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r8 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r8
            r0 = r9
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r0 = -1
            r9.g = r0
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r0 = r9.c
            r9.setContainedBinding(r0)
            r0 = 0
            r0 = r10[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r11)
            r9.setRootTag(r12)
            r9.invalidateAll()
            return r9
        L_0x0992:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_saving is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x099e:
            r13 = r4
            r12 = r15
            r4 = 1
            r14 = -1
            java.lang.String r2 = "layout/finance_activity_my_telebirr_mela_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x09c7
            com.huawei.ethiopia.finance.databinding.FinanceActivityMyTelebirrMelaBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceActivityMyTelebirrMelaBindingImpl
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r4, r13, r13)
            r3 = 0
            r2 = r2[r3]
            android.widget.FrameLayout r2 = (android.widget.FrameLayout) r2
            r0.<init>(r1, r12, r2)
            r0.b = r14
            android.widget.FrameLayout r1 = r0.a
            r1.setTag(r13)
            r0.setRootTag(r12)
            r0.invalidateAll()
            return r0
        L_0x09c7:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_my_telebirr_mela is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x09d3:
            r13 = r4
            r12 = r15
            r3 = 4
            r4 = 1
            r10 = 3
            r14 = -1
            java.lang.String r2 = "layout/finance_activity_locked_saving_product_detail_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0a22
            com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingProductDetailBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingProductDetailBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingProductDetailBindingImpl.f
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingProductDetailBindingImpl.g
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r3, r0, r2)
            r2 = 2
            r2 = r0[r2]
            r3 = r2
            com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingProductDetailBinding r3 = (com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingProductDetailBinding) r3
            r2 = r0[r4]
            r4 = r2
            com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBinding r4 = (com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBinding) r4
            r2 = 0
            r2 = r0[r2]
            r5 = r2
            com.huawei.common.widget.round.RoundLinearLayout r5 = (com.huawei.common.widget.round.RoundLinearLayout) r5
            r0 = r0[r10]
            r6 = r0
            com.huawei.common.widget.round.RoundRecyclerView r6 = (com.huawei.common.widget.round.RoundRecyclerView) r6
            r0 = r7
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r14
            com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingProductDetailBinding r0 = r7.a
            r7.setContainedBinding(r0)
            com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBinding r0 = r7.b
            r7.setContainedBinding(r0)
            com.huawei.common.widget.round.RoundLinearLayout r0 = r7.c
            r0.setTag(r13)
            r7.setRootTag(r12)
            r7.invalidateAll()
            return r7
        L_0x0a22:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_locked_saving_product_detail is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0a2e:
            r13 = r4
            r12 = r15
            r2 = 7
            r3 = 4
            r4 = 1
            r5 = 8
            r10 = 3
            r11 = 5
            r14 = -1
            java.lang.String r6 = "layout/finance_activity_locked_saving_account_detail_0"
            boolean r6 = r6.equals(r0)
            if (r6 == 0) goto L_0x0a90
            com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountDetailBindingImpl r8 = new com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountDetailBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountDetailBindingImpl.g
            android.util.SparseIntArray r6 = com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountDetailBindingImpl.h
            java.lang.Object[] r17 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r5, r0, r6)
            r0 = r17[r4]
            r4 = r0
            com.huawei.ethiopia.finance.databinding.FinanceItemMyFixedTimeSavingDetailBinding r4 = (com.huawei.ethiopia.finance.databinding.FinanceItemMyFixedTimeSavingDetailBinding) r4
            r0 = r17[r3]
            r5 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r5 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r5
            r0 = r17[r11]
            r6 = r0
            com.huawei.common.widget.round.RoundLinearLayout r6 = (com.huawei.common.widget.round.RoundLinearLayout) r6
            r0 = r17[r2]
            r7 = r0
            com.huawei.common.widget.round.RoundTextView r7 = (com.huawei.common.widget.round.RoundTextView) r7
            r0 = 2
            r0 = r17[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r17[r9]
            r9 = r0
            com.huawei.common.widget.round.RoundTextView r9 = (com.huawei.common.widget.round.RoundTextView) r9
            r0 = r17[r10]
            android.view.View r0 = (android.view.View) r0
            r0 = r8
            r1 = r23
            r2 = r24
            r3 = r4
            r4 = r5
            r5 = r6
            r6 = r7
            r7 = r9
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r8.f = r14
            com.huawei.ethiopia.finance.databinding.FinanceItemMyFixedTimeSavingDetailBinding r0 = r8.a
            r8.setContainedBinding(r0)
            r0 = 0
            r0 = r17[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r13)
            r8.setRootTag(r12)
            r8.invalidateAll()
            return r8
        L_0x0a90:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_locked_saving_account_detail is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0a9c:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_locked_saving_account_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0adb
            com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r2 = com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountBindingImpl.d
            android.util.SparseIntArray r3 = com.huawei.ethiopia.finance.databinding.FinanceActivityLockedSavingAccountBindingImpl.e
            r4 = 4
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r4, r2, r3)
            r3 = 1
            r3 = r2[r3]
            com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingAllBalanceBinding r3 = (com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingAllBalanceBinding) r3
            r4 = 3
            r4 = r2[r4]
            androidx.constraintlayout.widget.Guideline r4 = (androidx.constraintlayout.widget.Guideline) r4
            r4 = 2
            r4 = r2[r4]
            com.huawei.common.widget.recyclerview.HFRecyclerView r4 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r4
            r0.<init>(r1, r12, r3, r4)
            r3 = -1
            r0.c = r3
            com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingAllBalanceBinding r1 = r0.a
            r0.setContainedBinding(r1)
            r1 = 0
            r1 = r2[r1]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r2 = 0
            r1.setTag(r2)
            r0.setRootTag(r12)
            r0.invalidateAll()
            return r0
        L_0x0adb:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_locked_saving_account is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0ae7:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_locked_closed_saving_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0b15
            com.huawei.ethiopia.finance.databinding.FinanceActivityLockedClosedSavingBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceActivityLockedClosedSavingBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceActivityLockedClosedSavingBindingImpl.c
            r3 = 2
            r4 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r3, r4, r2)
            r3 = 1
            r3 = r2[r3]
            com.huawei.common.widget.recyclerview.HFRecyclerView r3 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r3
            r0.<init>(r1, r12, r3)
            r5 = -1
            r0.b = r5
            r1 = 0
            r1 = r2[r1]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r4)
            r0.setRootTag(r12)
            r0.invalidateAll()
            return r0
        L_0x0b15:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_locked_closed_saving is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0b21:
            r13 = r4
            r12 = r15
            r4 = 1
            r14 = -1
            java.lang.String r2 = "layout/finance_activity_loan_contract_detail_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0b4a
            com.huawei.ethiopia.finance.databinding.FinanceActivityLoanContractDetailBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceActivityLoanContractDetailBindingImpl
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r4, r13, r13)
            r3 = 0
            r2 = r2[r3]
            com.huawei.common.widget.recyclerview.HFRecyclerView r2 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r2
            r0.<init>(r1, r12, r2)
            r0.b = r14
            com.huawei.common.widget.recyclerview.HFRecyclerView r1 = r0.a
            r1.setTag(r13)
            r0.setRootTag(r12)
            r0.invalidateAll()
            return r0
        L_0x0b4a:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_loan_contract_detail is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0b56:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_finance_service_config_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0bad
            com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceConfigBindingImpl r8 = new com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceConfigBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceConfigBindingImpl.g
            r2 = 8
            r9 = 0
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r2, r9, r0)
            r0 = 6
            r0 = r10[r0]
            r3 = r0
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = 1
            r0 = r10[r0]
            androidx.constraintlayout.widget.Guideline r0 = (androidx.constraintlayout.widget.Guideline) r0
            r0 = 2
            r0 = r10[r0]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = 3
            r0 = r10[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = 5
            r0 = r10[r0]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = 4
            r0 = r10[r0]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = 7
            r0 = r10[r0]
            r7 = r0
            androidx.viewpager2.widget.ViewPager2 r7 = (androidx.viewpager2.widget.ViewPager2) r7
            r0 = r8
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r0 = -1
            r8.f = r0
            r0 = 0
            r0 = r10[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r9)
            r8.setRootTag(r12)
            r8.invalidateAll()
            return r8
        L_0x0bad:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_finance_service_config is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0bb9:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_finance_service_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0c1c
            com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceBindingImpl r8 = new com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceServiceBindingImpl.g
            r2 = 10
            r9 = 0
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r2, r9, r0)
            r0 = 8
            r0 = r10[r0]
            r3 = r0
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = 7
            r0 = r10[r0]
            r4 = r0
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r0 = 1
            r0 = r10[r0]
            androidx.constraintlayout.widget.Guideline r0 = (androidx.constraintlayout.widget.Guideline) r0
            r0 = 3
            r0 = r10[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = 2
            r0 = r10[r0]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = 4
            r0 = r10[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = 6
            r0 = r10[r0]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = 5
            r0 = r10[r0]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = 9
            r0 = r10[r0]
            r7 = r0
            androidx.viewpager2.widget.ViewPager2 r7 = (androidx.viewpager2.widget.ViewPager2) r7
            r0 = r8
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r0 = -1
            r8.f = r0
            r0 = 0
            r0 = r10[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r9)
            r8.setRootTag(r12)
            r8.invalidateAll()
            return r8
        L_0x0c1c:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_finance_service is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0c28:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_finance_loan_home_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0c81
            com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceLoanHomeBindingImpl r10 = new com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceLoanHomeBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceLoanHomeBindingImpl.i
            r2 = 8
            r11 = 0
            java.lang.Object[] r13 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r2, r11, r0)
            r0 = 3
            r0 = r13[r0]
            r3 = r0
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r0 = 6
            r0 = r13[r0]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = 2
            r0 = r13[r0]
            r5 = r0
            android.widget.LinearLayout r5 = (android.widget.LinearLayout) r5
            r0 = 5
            r0 = r13[r0]
            r6 = r0
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            r0 = 4
            r0 = r13[r0]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = 7
            r0 = r13[r0]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = 1
            r0 = r13[r0]
            r9 = r0
            androidx.viewpager2.widget.ViewPager2 r9 = (androidx.viewpager2.widget.ViewPager2) r9
            r0 = r10
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r0 = -1
            r10.h = r0
            r0 = 0
            r0 = r13[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r11)
            r10.setRootTag(r12)
            r10.invalidateAll()
            return r10
        L_0x0c81:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_finance_loan_home is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0c8d:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_finance_agreement_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0cc5
            com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceAgreementBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceAgreementBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceActivityFinanceAgreementBindingImpl.d
            r3 = 4
            r4 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r3, r4, r2)
            r3 = 3
            r3 = r2[r3]
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r5 = 2
            r5 = r2[r5]
            androidx.appcompat.widget.AppCompatCheckBox r5 = (androidx.appcompat.widget.AppCompatCheckBox) r5
            r6 = 1
            r6 = r2[r6]
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            r0.<init>(r1, r12, r3, r5)
            r5 = -1
            r0.c = r5
            r1 = 0
            r1 = r2[r1]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1.setTag(r4)
            r0.setRootTag(r12)
            r0.invalidateAll()
            return r0
        L_0x0cc5:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_finance_agreement is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0cd1:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_deposit_with_draw_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0d22
            com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBindingImpl r8 = new com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityDepositWithDrawBindingImpl.g
            r2 = 7
            r9 = 0
            java.lang.Object[] r10 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r2, r9, r0)
            r0 = 2
            r0 = r10[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = 3
            r0 = r10[r0]
            r3 = r0
            android.widget.EditText r3 = (android.widget.EditText) r3
            r0 = 6
            r0 = r10[r0]
            r4 = r0
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0 = 5
            r0 = r10[r0]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = 1
            r0 = r10[r0]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = 4
            r0 = r10[r0]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = r8
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r0 = -1
            r8.f = r0
            r0 = 0
            r0 = r10[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r9)
            r8.setRootTag(r12)
            r8.invalidateAll()
            return r8
        L_0x0d22:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_deposit_with_draw is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0d2e:
            r12 = r15
            java.lang.String r2 = "layout/finance_activity_credit_pay_home_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0db5
            com.huawei.ethiopia.finance.databinding.FinanceActivityCreditPayHomeBindingImpl r14 = new com.huawei.ethiopia.finance.databinding.FinanceActivityCreditPayHomeBindingImpl
            androidx.databinding.ViewDataBinding$IncludedLayouts r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityCreditPayHomeBindingImpl.m
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceActivityCreditPayHomeBindingImpl.n
            r3 = 12
            java.lang.Object[] r15 = androidx.databinding.ViewDataBinding.mapBindings(r1, r12, r3, r0, r2)
            r0 = 6
            r0 = r15[r0]
            r3 = r0
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r0 = 9
            r0 = r15[r0]
            r4 = r0
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r0 = 11
            r0 = r15[r0]
            r5 = r0
            android.widget.FrameLayout r5 = (android.widget.FrameLayout) r5
            r0 = 4
            r0 = r15[r0]
            r6 = r0
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            r0 = 7
            r0 = r15[r0]
            r7 = r0
            android.widget.LinearLayout r7 = (android.widget.LinearLayout) r7
            r0 = 3
            r0 = r15[r0]
            r8 = r0
            android.widget.LinearLayout r8 = (android.widget.LinearLayout) r8
            r0 = 2
            r0 = r15[r0]
            r9 = r0
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r9 = (com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding) r9
            r0 = 1
            r0 = r15[r0]
            r10 = r0
            com.huawei.ethiopia.finance.databinding.FinanceNoRelevantDataBinding r10 = (com.huawei.ethiopia.finance.databinding.FinanceNoRelevantDataBinding) r10
            r0 = 5
            r0 = r15[r0]
            r11 = r0
            android.widget.TextView r11 = (android.widget.TextView) r11
            r0 = 8
            r0 = r15[r0]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = 10
            r0 = r15[r0]
            r16 = r0
            androidx.viewpager2.widget.ViewPager2 r16 = (androidx.viewpager2.widget.ViewPager2) r16
            r0 = r14
            r1 = r23
            r2 = r24
            r12 = r13
            r13 = r16
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            r0 = -1
            r14.l = r0
            com.huawei.ethiopia.finance.databinding.FinanceFragmentLoanHomeUnactiveBinding r0 = r14.g
            r14.setContainedBinding(r0)
            r0 = 0
            r0 = r15[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r1 = 0
            r0.setTag(r1)
            com.huawei.ethiopia.finance.databinding.FinanceNoRelevantDataBinding r0 = r14.h
            r14.setContainedBinding(r0)
            r10 = r24
            r14.setRootTag(r10)
            r14.invalidateAll()
            return r14
        L_0x0db5:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_credit_pay_home is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0dc1:
            r13 = r4
            r10 = r15
            r4 = 1
            r14 = -1
            java.lang.String r2 = "layout/finance_activity_credit_contract_detail_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0dea
            com.huawei.ethiopia.finance.databinding.FinanceActivityCreditContractDetailBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceActivityCreditContractDetailBindingImpl
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r10, r4, r13, r13)
            r3 = 0
            r2 = r2[r3]
            com.huawei.common.widget.recyclerview.HFRecyclerView r2 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r2
            r0.<init>(r1, r10, r2)
            r0.b = r14
            com.huawei.common.widget.recyclerview.HFRecyclerView r1 = r0.a
            r1.setTag(r13)
            r0.setRootTag(r10)
            r0.invalidateAll()
            return r0
        L_0x0dea:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_credit_contract_detail is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0df6:
            r10 = r15
            java.lang.String r2 = "layout/finance_activity_apply_loan_product_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0e5b
            com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBindingImpl r11 = new com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceActivityApplyLoanProductBindingImpl.i
            r2 = 10
            r12 = 0
            java.lang.Object[] r13 = androidx.databinding.ViewDataBinding.mapBindings(r1, r10, r2, r12, r0)
            r0 = 9
            r0 = r13[r0]
            r3 = r0
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r0 = 2
            r0 = r13[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = 3
            r0 = r13[r0]
            r4 = r0
            android.widget.EditText r4 = (android.widget.EditText) r4
            r0 = 8
            r0 = r13[r0]
            r5 = r0
            com.huawei.common.widget.round.RoundLinearLayout r5 = (com.huawei.common.widget.round.RoundLinearLayout) r5
            r0 = 7
            r0 = r13[r0]
            r6 = r0
            com.huawei.common.widget.round.RoundRecyclerView r6 = (com.huawei.common.widget.round.RoundRecyclerView) r6
            r0 = 6
            r0 = r13[r0]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = 5
            r0 = r13[r0]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = 1
            r0 = r13[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 4
            r0 = r13[r0]
            r9 = r0
            android.widget.TextView r9 = (android.widget.TextView) r9
            r0 = r11
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r0 = -1
            r11.h = r0
            r0 = 0
            r0 = r13[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0.setTag(r12)
            r11.setRootTag(r10)
            r11.invalidateAll()
            return r11
        L_0x0e5b:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_apply_loan_product is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0e67:
            r10 = r15
            java.lang.String r2 = "layout/finance_activity_active_saving_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0e9a
            com.huawei.ethiopia.finance.databinding.FinanceActivityActiveSavingBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceActivityActiveSavingBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceActivityActiveSavingBindingImpl.d
            r3 = 3
            r4 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r10, r3, r4, r2)
            r3 = 2
            r3 = r2[r3]
            com.huawei.common.widget.LoadingButton r3 = (com.huawei.common.widget.LoadingButton) r3
            r5 = 1
            r5 = r2[r5]
            androidx.recyclerview.widget.RecyclerView r5 = (androidx.recyclerview.widget.RecyclerView) r5
            r0.<init>(r1, r10, r3, r5)
            r5 = -1
            r0.c = r5
            r1 = 0
            r1 = r2[r1]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1.setTag(r4)
            r0.setRootTag(r10)
            r0.invalidateAll()
            return r0
        L_0x0e9a:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for finance_activity_active_saving is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0ea6:
            r10 = r15
            java.lang.String r2 = "layout/activity_loan_market_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0eb5
            com.huawei.ethiopia.finance.databinding.ActivityLoanMarketBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.ActivityLoanMarketBindingImpl
            r0.<init>(r10, r1)
            return r0
        L_0x0eb5:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for activity_loan_market is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0ec1:
            r13 = r4
            r10 = r15
            r4 = 1
            r14 = -1
            java.lang.String r2 = "layout/activity_loan_category_market_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0ef1
            com.huawei.ethiopia.finance.databinding.ActivityLoanCategoryMarketBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.ActivityLoanCategoryMarketBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.ActivityLoanCategoryMarketBindingImpl.d
            r3 = 2
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r10, r3, r13, r2)
            r3 = 0
            r3 = r2[r3]
            com.huawei.common.widget.round.RoundConstraintLayout r3 = (com.huawei.common.widget.round.RoundConstraintLayout) r3
            r2 = r2[r4]
            androidx.recyclerview.widget.RecyclerView r2 = (androidx.recyclerview.widget.RecyclerView) r2
            r0.<init>(r1, r10, r3, r2)
            r0.c = r14
            com.huawei.common.widget.round.RoundConstraintLayout r1 = r0.a
            r1.setTag(r13)
            r0.setRootTag(r10)
            r0.invalidateAll()
            return r0
        L_0x0ef1:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for activity_loan_category_market is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0efd:
            r10 = r15
            java.lang.String r2 = "layout/activity_finance_repayment_confirmation_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0f0c
            com.huawei.ethiopia.finance.databinding.ActivityFinanceRepaymentConfirmationBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.ActivityFinanceRepaymentConfirmationBindingImpl
            r0.<init>(r10, r1)
            return r0
        L_0x0f0c:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for activity_finance_repayment_confirmation is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0f18:
            r10 = r15
            java.lang.String r2 = "layout/activity_finance_repayment_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0f5e
            com.huawei.ethiopia.finance.databinding.ActivityFinanceRepaymentBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.ActivityFinanceRepaymentBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.ActivityFinanceRepaymentBindingImpl.f
            r2 = 5
            r8 = 0
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r10, r2, r8, r0)
            r0 = 3
            r0 = r9[r0]
            r3 = r0
            com.huawei.common.widget.input.CommonInputView r3 = (com.huawei.common.widget.input.CommonInputView) r3
            r0 = 2
            r0 = r9[r0]
            r4 = r0
            com.huawei.digitalpayment.customer.viewlib.view.TypeSelectView r4 = (com.huawei.digitalpayment.customer.viewlib.view.TypeSelectView) r4
            r0 = 1
            r0 = r9[r0]
            r5 = r0
            com.huawei.digitalpayment.customer.viewlib.view.TypeSelectView r5 = (com.huawei.digitalpayment.customer.viewlib.view.TypeSelectView) r5
            r0 = 4
            r0 = r9[r0]
            r6 = r0
            com.huawei.common.widget.LoadingButton r6 = (com.huawei.common.widget.LoadingButton) r6
            r0 = r7
            r1 = r23
            r2 = r24
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r0 = -1
            r7.e = r0
            r0 = 0
            r0 = r9[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r8)
            r7.setRootTag(r10)
            r7.invalidateAll()
            return r7
        L_0x0f5e:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for activity_finance_repayment is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0f6a:
            r10 = r15
            java.lang.String r2 = "layout/activity_finance_market_guide_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0f79
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketGuideBindingImpl
            r0.<init>(r10, r1)
            return r0
        L_0x0f79:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for activity_finance_market_guide is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0f85:
            r10 = r15
            java.lang.String r2 = "layout/activity_finance_market_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0f94
            com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.ActivityFinanceMarketBindingImpl
            r0.<init>(r10, r1)
            return r0
        L_0x0f94:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for activity_finance_market is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        L_0x0fa0:
            r10 = r15
            java.lang.String r2 = "layout/activity_contract_detail_0"
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0faf
            com.huawei.ethiopia.finance.databinding.ActivityContractDetailBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.ActivityContractDetailBindingImpl
            r0.<init>(r10, r1)
            return r0
        L_0x0faf:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "The tag for activity_contract_detail is invalid. Received: "
            java.lang.String r0 = androidx.camera.view.l.a(r0, r2)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.DataBinderMapperImpl.a(androidx.databinding.DataBindingComponent, android.view.View, int, java.lang.Object):androidx.databinding.ViewDataBinding");
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(8);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    /* JADX WARNING: type inference failed for: r1v31, types: [com.huawei.ethiopia.finance.widget.FinanceDisplayView, android.view.View] */
    /* JADX WARNING: type inference failed for: r1v61, types: [com.huawei.ethiopia.finance.widget.FinanceDisplayView, android.view.View] */
    /* JADX WARNING: Code restructure failed: missing block: B:176:?, code lost:
        return r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:178:?, code lost:
        return r9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:179:?, code lost:
        return r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:180:?, code lost:
        return r6;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.databinding.ViewDataBinding getDataBinder(androidx.databinding.DataBindingComponent r34, android.view.View r35, int r36) {
        /*
            r33 = this;
            r1 = r34
            r15 = r35
            android.util.SparseIntArray r0 = a
            r2 = r36
            int r0 = r0.get(r2)
            r14 = 0
            if (r0 <= 0) goto L_0x001e
            java.lang.Object r2 = r35.getTag()
            if (r2 == 0) goto L_0x0afd
            int r3 = r0 + -1
            int r3 = r3 / 50
            if (r3 == 0) goto L_0x0af7
            r13 = 1
            if (r3 == r13) goto L_0x0021
        L_0x001e:
            r0 = r14
            goto L_0x0b05
        L_0x0021:
            r23 = 12
            r22 = 11
            r8 = 8
            r5 = 6
            r6 = 5
            r4 = 4
            r3 = 3
            r9 = 0
            r10 = -1
            r12 = 2
            r19 = 18
            r20 = 15
            r21 = 16
            r24 = 17
            r25 = 19
            r7 = 20
            switch(r0) {
                case 51: goto L_0x0a98;
                case 52: goto L_0x0a27;
                case 53: goto L_0x09d5;
                case 54: goto L_0x0922;
                case 55: goto L_0x0874;
                case 56: goto L_0x0826;
                case 57: goto L_0x07ec;
                case 58: goto L_0x07ba;
                case 59: goto L_0x0752;
                case 60: goto L_0x06f1;
                case 61: goto L_0x0692;
                case 62: goto L_0x0653;
                case 63: goto L_0x0601;
                case 64: goto L_0x059a;
                case 65: goto L_0x053c;
                case 66: goto L_0x050a;
                case 67: goto L_0x04d8;
                case 68: goto L_0x0484;
                case 69: goto L_0x043a;
                case 70: goto L_0x03d9;
                case 71: goto L_0x0391;
                case 72: goto L_0x035b;
                case 73: goto L_0x02c2;
                case 74: goto L_0x027f;
                case 75: goto L_0x0221;
                case 76: goto L_0x01df;
                case 77: goto L_0x01a8;
                case 78: goto L_0x0156;
                case 79: goto L_0x00c5;
                case 80: goto L_0x0079;
                case 81: goto L_0x0040;
                default: goto L_0x003e;
            }
        L_0x003e:
            goto L_0x0aea
        L_0x0040:
            java.lang.String r0 = "layout/finance_no_relevant_data_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x006d
            com.huawei.ethiopia.finance.databinding.FinanceNoRelevantDataBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceNoRelevantDataBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceNoRelevantDataBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r14, r2)
            r3 = r2[r13]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r12]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0.<init>(r1, r15, r9)
            r0.a = r10
            r1 = r2[r9]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
        L_0x006a:
            r14 = r0
            goto L_0x0aea
        L_0x006d:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_no_relevant_data is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0079:
            java.lang.String r0 = "layout/finance_loan_contract_detail_head_repayment_schedule_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x00b9
            com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadRepaymentScheduleBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadRepaymentScheduleBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadRepaymentScheduleBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r14, r2)
            r6 = r2[r6]
            com.huawei.common.widget.round.RoundTextView r6 = (com.huawei.common.widget.round.RoundTextView) r6
            r4 = r2[r4]
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r6 = r2[r12]
            android.view.View r6 = (android.view.View) r6
            r5 = r2[r5]
            android.view.View r5 = (android.view.View) r5
            r5 = 7
            r5 = r2[r5]
            androidx.recyclerview.widget.RecyclerView r5 = (androidx.recyclerview.widget.RecyclerView) r5
            r3 = r2[r3]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r13]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0.<init>(r15, r1, r5, r4)
            r0.c = r10
            r1 = r2[r9]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r1.setTag(r14)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x00b9:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_loan_contract_detail_head_repayment_schedule is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x00c5:
            java.lang.String r0 = "layout/finance_loan_contract_detail_head_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x014a
            com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceLoanContractDetailHeadBindingImpl.k
            r2 = 14
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r2, r14, r0)
            r0 = r16[r23]
            r19 = r0
            com.huawei.common.widget.LoadingButton r19 = (com.huawei.common.widget.LoadingButton) r19
            r0 = r16[r5]
            android.view.View r0 = (android.view.View) r0
            r0 = 7
            r0 = r16[r0]
            android.view.View r0 = (android.view.View) r0
            r0 = 13
            r0 = r16[r0]
            r5 = r0
            com.huawei.common.widget.round.RoundRecyclerView r5 = (com.huawei.common.widget.round.RoundRecyclerView) r5
            r0 = r16[r12]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r16[r3]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r16[r4]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r16[r6]
            r6 = r0
            com.huawei.common.widget.round.RoundTextView r6 = (com.huawei.common.widget.round.RoundTextView) r6
            r0 = r16[r13]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r16[r8]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = 9
            r0 = r16[r0]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = 10
            r0 = r16[r0]
            r18 = r0
            android.widget.TextView r18 = (android.widget.TextView) r18
            r0 = r16[r22]
            r20 = r0
            android.widget.TextView r20 = (android.widget.TextView) r20
            r0 = r7
            r1 = r34
            r2 = r35
            r3 = r19
            r4 = r5
            r5 = r12
            r12 = r7
            r7 = r13
            r13 = 0
            r9 = r17
            r14 = r10
            r10 = r18
            r11 = r20
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            r12.j = r14
            r0 = r16[r13]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r15 = r35
            r12.setRootTag(r15)
            r12.invalidateAll()
            r14 = r12
            goto L_0x0aea
        L_0x014a:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_loan_contract_detail_head is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0156:
            r7 = r10
            r10 = 0
            java.lang.String r0 = "layout/finance_loan_active_contracts_balance_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x019c
            com.huawei.ethiopia.finance.databinding.FinanceLoanActiveContractsBalanceBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceLoanActiveContractsBalanceBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceLoanActiveContractsBalanceBindingImpl.f
            r2 = 0
            java.lang.Object[] r11 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r6, r2, r0)
            r0 = r11[r12]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r11[r13]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r11[r4]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r11[r3]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r9
            r1 = r34
            r2 = r35
            r3 = r5
            r4 = r6
            r5 = r12
            r6 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r9.e = r7
            r0 = r11[r10]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r9.setRootTag(r15)
            r9.invalidateAll()
        L_0x0199:
            r14 = r9
            goto L_0x0aea
        L_0x019c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_loan_active_contracts_balance is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x01a8:
            r7 = r10
            r10 = 0
            java.lang.String r0 = "layout/finance_layout_service_banner_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x01d3
            com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceLayoutServiceBannerBindingImpl.c
            r3 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r12, r3, r2)
            r4 = r2[r13]
            com.huawei.common.widget.banner.CycleViewPager r4 = (com.huawei.common.widget.banner.CycleViewPager) r4
            r0.<init>(r1, r15, r4)
            r0.b = r7
            r1 = r2[r10]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1.setTag(r3)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x01d3:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_layout_service_banner is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x01df:
            r7 = r10
            r10 = 0
            java.lang.String r0 = "layout/finance_layout_query_error_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0215
            com.huawei.ethiopia.finance.databinding.FinanceLayoutQueryErrorBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceLayoutQueryErrorBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceLayoutQueryErrorBindingImpl.c
            r5 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r5, r2)
            r3 = r2[r3]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r3 = r2[r13]
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r3 = r2[r10]
            android.widget.LinearLayout r3 = (android.widget.LinearLayout) r3
            r2 = r2[r12]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0.<init>(r1, r15, r3)
            r0.b = r7
            android.widget.LinearLayout r1 = r0.a
            r2 = 0
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x0215:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_layout_query_error is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0221:
            java.lang.String r0 = "layout/finance_item_time_saving_product_detail_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0273
            com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingProductDetailBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingProductDetailBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingProductDetailBindingImpl.f
            r2 = 0
            java.lang.Object[] r8 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r2, r0)
            r0 = 7
            r0 = r8[r0]
            r9 = r0
            com.huawei.common.widget.LoadingButton r9 = (com.huawei.common.widget.LoadingButton) r9
            r0 = r8[r12]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = r8[r5]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r8[r3]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r8[r6]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r8[r4]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r8[r13]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r7
            r1 = r34
            r2 = r35
            r3 = r9
            r4 = r5
            r5 = r6
            r6 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r10
            r0 = 0
            r0 = r8[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r7.setRootTag(r15)
            r7.invalidateAll()
        L_0x0270:
            r14 = r7
            goto L_0x0aea
        L_0x0273:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_time_saving_product_detail is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x027f:
            java.lang.String r0 = "layout/finance_item_time_saving_all_balance_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x02b6
            com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingAllBalanceBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingAllBalanceBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceItemTimeSavingAllBalanceBindingImpl.d
            r5 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r6, r5, r2)
            r5 = r2[r13]
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r5 = r2[r12]
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r3 = r2[r3]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r4]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0.<init>(r1, r15, r5, r3)
            r0.c = r10
            r1 = 0
            r1 = r2[r1]
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            r2 = 0
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x02b6:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_time_saving_all_balance is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x02c2:
            java.lang.String r0 = "layout/finance_item_saving_time_product_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x034f
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingTimeProductBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceItemSavingTimeProductBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemSavingTimeProductBindingImpl.m
            r2 = 0
            r7 = 13
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r2, r0)
            r2 = r0[r12]
            r7 = r2
            com.huawei.common.widget.round.RoundTextView r7 = (com.huawei.common.widget.round.RoundTextView) r7
            r2 = r0[r4]
            r4 = r2
            androidx.core.widget.NestedScrollView r4 = (androidx.core.widget.NestedScrollView) r4
            r2 = r0[r23]
            r12 = r2
            android.widget.ImageView r12 = (android.widget.ImageView) r12
            r2 = 10
            r2 = r0[r2]
            r16 = r2
            android.widget.LinearLayout r16 = (android.widget.LinearLayout) r16
            r2 = r0[r6]
            r18 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r18 = (com.huawei.common.widget.round.RoundConstraintLayout) r18
            r2 = r0[r3]
            r19 = r2
            com.huawei.common.widget.round.RoundRecyclerView r19 = (com.huawei.common.widget.round.RoundRecyclerView) r19
            r2 = 0
            r2 = r0[r2]
            r14 = r2
            com.huawei.common.widget.round.RoundLinearLayout r14 = (com.huawei.common.widget.round.RoundLinearLayout) r14
            r2 = 7
            r2 = r0[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r5]
            r20 = r2
            android.widget.TextView r20 = (android.widget.TextView) r20
            r2 = 9
            r2 = r0[r2]
            r17 = r2
            android.widget.TextView r17 = (android.widget.TextView) r17
            r2 = r0[r8]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r22]
            r21 = r2
            android.widget.TextView r21 = (android.widget.TextView) r21
            r0 = r0[r13]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r9
            r1 = r34
            r2 = r35
            r3 = r7
            r5 = r12
            r6 = r16
            r7 = r18
            r8 = r19
            r12 = r9
            r9 = r14
            r14 = r10
            r10 = r20
            r11 = r17
            r28 = r12
            r12 = r21
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            r0 = r28
            r0.l = r14
            com.huawei.common.widget.round.RoundLinearLayout r1 = r0.g
            r2 = 0
            r1.setTag(r2)
            r15 = r35
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x034f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_saving_time_product is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x035b:
            java.lang.String r0 = "layout/finance_item_saving_product_transaction_title_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0385
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionTitleBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionTitleBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionTitleBindingImpl.c
            r3 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r12, r3, r2)
            r4 = r2[r13]
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r0.<init>(r1, r15, r4)
            r0.b = r10
            r1 = 0
            r1 = r2[r1]
            android.widget.LinearLayout r1 = (android.widget.LinearLayout) r1
            r1.setTag(r3)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x0385:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_saving_product_transaction_title is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0391:
            java.lang.String r0 = "layout/finance_item_saving_product_transaction_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x03cd
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionBindingImpl r6 = new com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductTransactionBindingImpl.e
            r2 = 0
            java.lang.Object[] r7 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r2, r0)
            r0 = r7[r3]
            r3 = r0
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0 = r7[r12]
            r4 = r0
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0 = r7[r13]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r6
            r1 = r34
            r2 = r35
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r10
            r0 = 0
            r0 = r7[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r6.setRootTag(r15)
            r6.invalidateAll()
        L_0x03ca:
            r14 = r6
            goto L_0x0aea
        L_0x03cd:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_saving_product_transaction is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x03d9:
            java.lang.String r0 = "layout/finance_item_saving_product_balance_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x042e
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBalanceBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBalanceBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBalanceBindingImpl.h
            r2 = 0
            r7 = 7
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r2, r0)
            r0 = r16[r13]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = r16[r12]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r16[r4]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r16[r3]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r16[r5]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = r16[r6]
            r18 = r0
            android.widget.TextView r18 = (android.widget.TextView) r18
            r0 = r9
            r1 = r34
            r2 = r35
            r3 = r7
            r4 = r8
            r5 = r12
            r6 = r13
            r7 = r17
            r8 = r18
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r9.g = r10
            r0 = 0
            r0 = r16[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r9.setRootTag(r15)
            r9.invalidateAll()
            goto L_0x0199
        L_0x042e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_saving_product_balance is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x043a:
            java.lang.String r0 = "layout/finance_item_saving_product_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0478
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBindingImpl r6 = new com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemSavingProductBindingImpl.e
            r2 = 0
            java.lang.Object[] r7 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r2, r0)
            r0 = r7[r13]
            r4 = r0
            com.huawei.common.widget.round.RoundConstraintLayout r4 = (com.huawei.common.widget.round.RoundConstraintLayout) r4
            r0 = r7[r3]
            r5 = r0
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r7[r12]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r6
            r1 = r34
            r2 = r35
            r3 = r4
            r4 = r5
            r5 = r8
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r10
            r0 = 0
            r0 = r7[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r6.setRootTag(r15)
            r6.invalidateAll()
            goto L_0x03ca
        L_0x0478:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_saving_product is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0484:
            java.lang.String r0 = "layout/finance_item_saving_can_active_product_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x04cc
            com.huawei.ethiopia.finance.databinding.FinanceItemSavingCanActiveProductBindingImpl r8 = new com.huawei.ethiopia.finance.databinding.FinanceItemSavingCanActiveProductBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemSavingCanActiveProductBindingImpl.g
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r6, r2, r0)
            r2 = r0[r13]
            r5 = r2
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r2 = r0[r4]
            r4 = r2
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r2 = 0
            r2 = r0[r2]
            r6 = r2
            com.huawei.common.widget.round.RoundLinearLayout r6 = (com.huawei.common.widget.round.RoundLinearLayout) r6
            r2 = r0[r3]
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = r0[r12]
            r9 = r0
            android.widget.TextView r9 = (android.widget.TextView) r9
            r0 = r8
            r1 = r34
            r2 = r35
            r3 = r5
            r5 = r6
            r6 = r7
            r7 = r9
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r8.f = r10
            com.huawei.common.widget.round.RoundLinearLayout r0 = r8.c
            r1 = 0
            r0.setTag(r1)
            r8.setRootTag(r15)
            r8.invalidateAll()
            r14 = r8
            goto L_0x0aea
        L_0x04cc:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_saving_can_active_product is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x04d8:
            java.lang.String r0 = "layout/finance_item_result_display_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x04fe
            com.huawei.ethiopia.finance.databinding.FinanceItemResultDisplayBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemResultDisplayBindingImpl
            r2 = 0
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r13, r2, r2)
            r4 = 0
            r3 = r3[r4]
            com.huawei.common.widget.DisplayView r3 = (com.huawei.common.widget.DisplayView) r3
            r0.<init>(r1, r15, r3)
            r0.b = r10
            com.huawei.common.widget.DisplayView r1 = r0.a
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x04fe:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_result_display is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x050a:
            java.lang.String r0 = "layout/finance_item_pre_apply_result_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0530
            com.huawei.ethiopia.finance.databinding.FinanceItemPreApplyResultBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemPreApplyResultBindingImpl
            r2 = 0
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r13, r2, r2)
            r4 = 0
            r3 = r3[r4]
            com.huawei.ethiopia.finance.widget.FinanceDisplayView r3 = (com.huawei.ethiopia.finance.widget.FinanceDisplayView) r3
            r0.<init>(r1, r15, r3)
            r0.b = r10
            com.huawei.ethiopia.finance.widget.FinanceDisplayView r1 = r0.a
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x0530:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_pre_apply_result is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x053c:
            java.lang.String r0 = "layout/finance_item_od_active_contract_balance_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x058e
            com.huawei.ethiopia.finance.databinding.FinanceItemOdActiveContractBalanceBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceItemOdActiveContractBalanceBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemOdActiveContractBalanceBindingImpl.g
            r2 = 0
            java.lang.Object[] r8 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r2, r0)
            r0 = r8[r6]
            android.view.View r0 = (android.view.View) r0
            r0 = r8[r13]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r8[r12]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r8[r4]
            r4 = r0
            android.widget.TextView r4 = (android.widget.TextView) r4
            r0 = r8[r3]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = 7
            r0 = r8[r0]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r8[r5]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r9
            r1 = r34
            r2 = r35
            r3 = r6
            r5 = r7
            r6 = r12
            r7 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r9.f = r10
            r0 = 0
            r0 = r8[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r9.setRootTag(r15)
            r9.invalidateAll()
            goto L_0x0199
        L_0x058e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_od_active_contract_balance is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x059a:
            java.lang.String r0 = "layout/finance_item_my_fixed_time_saving_detail_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x05f5
            com.huawei.ethiopia.finance.databinding.FinanceItemMyFixedTimeSavingDetailBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceItemMyFixedTimeSavingDetailBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemMyFixedTimeSavingDetailBindingImpl.f
            r2 = 0
            r9 = 10
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r9, r2, r0)
            r0 = r9[r13]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r9[r12]
            android.widget.ImageView r0 = (android.widget.ImageView) r0
            r0 = r9[r3]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r9[r4]
            r3 = r0
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0 = r9[r6]
            r4 = r0
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r0 = 9
            r0 = r9[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r9[r8]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = 7
            r0 = r9[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r9[r5]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r7
            r1 = r34
            r2 = r35
            r5 = r6
            r6 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r10
            r0 = 0
            r0 = r9[r0]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r7.setRootTag(r15)
            r7.invalidateAll()
            goto L_0x0270
        L_0x05f5:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_my_fixed_time_saving_detail is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0601:
            java.lang.String r0 = "layout/finance_item_my_closed_saving_time_product_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0647
            com.huawei.ethiopia.finance.databinding.FinanceItemMyClosedSavingTimeProductBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemMyClosedSavingTimeProductBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceItemMyClosedSavingTimeProductBindingImpl.c
            r7 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r7, r2)
            r7 = 0
            r7 = r2[r7]
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            r8 = 7
            r8 = r2[r8]
            android.widget.TextView r8 = (android.widget.TextView) r8
            r5 = r2[r5]
            android.widget.TextView r5 = (android.widget.TextView) r5
            r5 = r2[r13]
            android.widget.TextView r5 = (android.widget.TextView) r5
            r3 = r2[r3]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r12]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r6]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r2 = r2[r4]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0.<init>(r1, r15, r7)
            r0.b = r10
            com.huawei.common.widget.round.RoundLinearLayout r1 = r0.a
            r2 = 0
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x0647:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_my_closed_saving_time_product is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0653:
            java.lang.String r0 = "layout/finance_item_market_product_title_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0686
            com.huawei.ethiopia.finance.databinding.FinanceItemMarketProductTitleBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemMarketProductTitleBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceItemMarketProductTitleBindingImpl.b
            r5 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r4, r5, r2)
            r3 = r2[r3]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r12]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = r2[r13]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r3 = 0
            r0.<init>(r1, r15, r3)
            r0.a = r10
            r1 = r2[r3]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r2 = 0
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x0686:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_market_product_title is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0692:
            java.lang.String r0 = "layout/finance_item_locked_saving_contract_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x06e5
            com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingContractBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingContractBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingContractBindingImpl.f
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r2, r0)
            r2 = 7
            r2 = r0[r2]
            com.huawei.common.widget.round.RoundTextView r2 = (com.huawei.common.widget.round.RoundTextView) r2
            r2 = 0
            r2 = r0[r2]
            r8 = r2
            com.huawei.common.widget.round.RoundLinearLayout r8 = (com.huawei.common.widget.round.RoundLinearLayout) r8
            r2 = r0[r5]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r6]
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            r2 = r0[r12]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r13]
            r6 = r2
            android.widget.TextView r6 = (android.widget.TextView) r6
            r2 = r0[r4]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0 = r0[r3]
            r9 = r0
            android.widget.TextView r9 = (android.widget.TextView) r9
            r0 = r7
            r1 = r34
            r2 = r35
            r3 = r8
            r4 = r5
            r5 = r6
            r6 = r9
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r10
            com.huawei.common.widget.round.RoundLinearLayout r0 = r7.a
            r1 = 0
            r0.setTag(r1)
            r7.setRootTag(r15)
            r7.invalidateAll()
            goto L_0x0270
        L_0x06e5:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_locked_saving_contract is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x06f1:
            java.lang.String r0 = "layout/finance_item_locked_saving_account_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0746
            com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingAccountBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingAccountBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLockedSavingAccountBindingImpl.g
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r2, r0)
            r2 = 0
            r2 = r0[r2]
            r7 = r2
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            r2 = 7
            r2 = r0[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r5]
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            r2 = r0[r13]
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            r2 = r0[r3]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r12]
            r12 = r2
            android.widget.TextView r12 = (android.widget.TextView) r12
            r2 = r0[r6]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0 = r0[r4]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r9
            r1 = r34
            r2 = r35
            r3 = r7
            r4 = r5
            r5 = r8
            r6 = r12
            r7 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r9.f = r10
            com.huawei.common.widget.round.RoundLinearLayout r0 = r9.a
            r1 = 0
            r0.setTag(r1)
            r9.setRootTag(r15)
            r9.invalidateAll()
            goto L_0x0199
        L_0x0746:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_locked_saving_account is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0752:
            java.lang.String r0 = "layout/finance_item_locked_close_saving_account_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x07ae
            com.huawei.ethiopia.finance.databinding.FinanceItemLockedCloseSavingAccountBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceItemLockedCloseSavingAccountBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLockedCloseSavingAccountBindingImpl.h
            r2 = 0
            r7 = 9
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r2, r0)
            r2 = 0
            r2 = r0[r2]
            r7 = r2
            com.huawei.common.widget.round.RoundLinearLayout r7 = (com.huawei.common.widget.round.RoundLinearLayout) r7
            r2 = r0[r8]
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            r2 = 7
            r2 = r0[r2]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r5]
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            r2 = r0[r13]
            r13 = r2
            android.widget.TextView r13 = (android.widget.TextView) r13
            r2 = r0[r3]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r2 = r0[r12]
            r12 = r2
            android.widget.TextView r12 = (android.widget.TextView) r12
            r2 = r0[r6]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0 = r0[r4]
            r14 = r0
            android.widget.TextView r14 = (android.widget.TextView) r14
            r0 = r9
            r1 = r34
            r2 = r35
            r3 = r7
            r4 = r8
            r6 = r13
            r7 = r12
            r8 = r14
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r9.g = r10
            com.huawei.common.widget.round.RoundLinearLayout r0 = r9.a
            r1 = 0
            r0.setTag(r1)
            r9.setRootTag(r15)
            r9.invalidateAll()
            goto L_0x0199
        L_0x07ae:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_locked_close_saving_account is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x07ba:
            java.lang.String r0 = "layout/finance_item_loan_restructure_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x07e0
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanRestructureBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanRestructureBindingImpl
            r2 = 0
            java.lang.Object[] r3 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r13, r2, r2)
            r4 = 0
            r3 = r3[r4]
            com.huawei.ethiopia.finance.widget.FinanceDisplayView r3 = (com.huawei.ethiopia.finance.widget.FinanceDisplayView) r3
            r0.<init>(r1, r15, r3)
            r0.b = r10
            com.huawei.ethiopia.finance.widget.FinanceDisplayView r1 = r0.a
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x07e0:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_restructure is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x07ec:
            java.lang.String r0 = "layout/finance_item_loan_product_group_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x081a
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductGroupBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductGroupBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductGroupBindingImpl.d
            r4 = 0
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r3, r4, r2)
            r3 = r2[r12]
            androidx.recyclerview.widget.RecyclerView r3 = (androidx.recyclerview.widget.RecyclerView) r3
            r5 = r2[r13]
            com.huawei.common.widget.round.RoundTextView r5 = (com.huawei.common.widget.round.RoundTextView) r5
            r0.<init>(r15, r1, r3, r5)
            r0.c = r10
            r1 = 0
            r1 = r2[r1]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r4)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x081a:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_product_group is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0826:
            java.lang.String r0 = "layout/finance_item_loan_product_detail_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0868
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductDetailBindingImpl r0 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductDetailBindingImpl
            android.util.SparseIntArray r2 = com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductDetailBindingImpl.c
            r7 = 0
            r8 = 7
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r8, r7, r2)
            r7 = 0
            r7 = r2[r7]
            android.widget.LinearLayout r7 = (android.widget.LinearLayout) r7
            r8 = r2[r12]
            android.widget.TextView r8 = (android.widget.TextView) r8
            r8 = r2[r13]
            android.widget.TextView r8 = (android.widget.TextView) r8
            r5 = r2[r5]
            android.widget.TextView r5 = (android.widget.TextView) r5
            r5 = r2[r6]
            android.widget.TextView r5 = (android.widget.TextView) r5
            r4 = r2[r4]
            android.widget.TextView r4 = (android.widget.TextView) r4
            r2 = r2[r3]
            android.widget.TextView r2 = (android.widget.TextView) r2
            r0.<init>(r1, r15, r7)
            r0.b = r10
            android.widget.LinearLayout r1 = r0.a
            r2 = 0
            r1.setTag(r2)
            r0.setRootTag(r15)
            r0.invalidateAll()
            goto L_0x006a
        L_0x0868:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_product_detail is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0874:
            r9 = 10
            r16 = 14
            r17 = 9
            r18 = 7
            java.lang.String r0 = "layout/finance_item_loan_product_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0916
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductBindingImpl r2 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductBindingImpl.v
            r14 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r15, r7, r14, r0)
            r3 = r0[r3]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r6 = r0[r6]
            android.widget.HorizontalScrollView r6 = (android.widget.HorizontalScrollView) r6
            r7 = 4
            r4 = r6
            r5 = r0[r5]
            com.huawei.common.widget.round.RoundConstraintLayout r5 = (com.huawei.common.widget.round.RoundConstraintLayout) r5
            r6 = r0[r25]
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            r24 = r0[r24]
            android.widget.LinearLayout r24 = (android.widget.LinearLayout) r24
            r8 = 4
            r7 = r24
            r8 = r0[r8]
            com.huawei.common.widget.round.RoundRecyclerView r8 = (com.huawei.common.widget.round.RoundRecyclerView) r8
            r24 = 0
            r24 = r0[r24]
            com.huawei.common.widget.round.RoundLinearLayout r24 = (com.huawei.common.widget.round.RoundLinearLayout) r24
            r26 = 10
            r9 = r24
            r21 = r0[r21]
            android.widget.TextView r21 = (android.widget.TextView) r21
            r10 = r21
            r11 = r0[r20]
            android.widget.TextView r11 = (android.widget.TextView) r11
            r27 = 14
            r12 = r0[r12]
            android.widget.TextView r12 = (android.widget.TextView) r12
            r28 = 13
            r15 = 8
            r15 = r0[r15]
            android.widget.TextView r15 = (android.widget.TextView) r15
            r29 = 1
            r13 = r15
            r15 = r0[r18]
            android.widget.TextView r15 = (android.widget.TextView) r15
            r14 = r15
            r15 = r0[r26]
            android.widget.TextView r15 = (android.widget.TextView) r15
            r16 = r0[r17]
            android.widget.TextView r16 = (android.widget.TextView) r16
            r17 = r0[r27]
            android.widget.TextView r17 = (android.widget.TextView) r17
            r18 = r0[r28]
            android.widget.TextView r18 = (android.widget.TextView) r18
            r19 = r0[r19]
            android.widget.TextView r19 = (android.widget.TextView) r19
            r20 = r0[r29]
            android.widget.TextView r20 = (android.widget.TextView) r20
            r21 = r0[r23]
            android.widget.TextView r21 = (android.widget.TextView) r21
            r0 = r0[r22]
            r22 = r0
            android.widget.TextView r22 = (android.widget.TextView) r22
            r0 = r2
            r1 = r34
            r31 = r2
            r2 = r35
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22)
            r0 = r31
            r10 = -1
            r0.u = r10
            com.huawei.common.widget.round.RoundLinearLayout r1 = r0.g
            r13 = 0
            r1.setTag(r13)
            r9 = r35
            r0.setRootTag(r9)
            r0.invalidateAll()
            goto L_0x006a
        L_0x0916:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_product is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0922:
            r13 = r14
            r9 = r15
            r8 = 4
            r15 = 8
            r17 = 9
            r18 = 7
            r26 = 10
            r27 = 14
            r28 = 13
            r29 = 1
            java.lang.String r0 = "layout/finance_item_loan_market_product_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x09c9
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanMarketProductBindingImpl r2 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanMarketProductBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLoanMarketProductBindingImpl.w
            r4 = 21
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r9, r4, r13, r0)
            r4 = r0[r8]
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r16 = 3
            r3 = r4
            r4 = r0[r5]
            android.widget.HorizontalScrollView r4 = (android.widget.HorizontalScrollView) r4
            r5 = r0[r18]
            com.huawei.common.widget.round.RoundConstraintLayout r5 = (com.huawei.common.widget.round.RoundConstraintLayout) r5
            r8 = r0[r29]
            android.widget.ImageView r8 = (android.widget.ImageView) r8
            r30 = 5
            r6 = r8
            r7 = r0[r7]
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            r8 = r0[r19]
            android.widget.LinearLayout r8 = (android.widget.LinearLayout) r8
            r18 = r0[r30]
            com.huawei.common.widget.round.RoundRecyclerView r18 = (com.huawei.common.widget.round.RoundRecyclerView) r18
            r9 = r18
            r14 = 0
            r14 = r0[r14]
            com.huawei.common.widget.round.RoundLinearLayout r14 = (com.huawei.common.widget.round.RoundLinearLayout) r14
            r10 = r14
            r11 = r0[r24]
            android.widget.TextView r11 = (android.widget.TextView) r11
            r14 = r0[r21]
            android.widget.TextView r14 = (android.widget.TextView) r14
            r21 = 2
            r12 = r14
            r14 = r0[r16]
            android.widget.TextView r14 = (android.widget.TextView) r14
            r13 = r14
            r14 = r0[r17]
            android.widget.TextView r14 = (android.widget.TextView) r14
            r15 = r0[r15]
            android.widget.TextView r15 = (android.widget.TextView) r15
            r16 = r0[r22]
            android.widget.TextView r16 = (android.widget.TextView) r16
            r17 = r0[r26]
            android.widget.TextView r17 = (android.widget.TextView) r17
            r18 = r0[r20]
            android.widget.TextView r18 = (android.widget.TextView) r18
            r19 = r0[r27]
            android.widget.TextView r19 = (android.widget.TextView) r19
            r20 = r0[r25]
            android.widget.TextView r20 = (android.widget.TextView) r20
            r21 = r0[r21]
            android.widget.TextView r21 = (android.widget.TextView) r21
            r22 = r0[r28]
            android.widget.TextView r22 = (android.widget.TextView) r22
            r0 = r0[r23]
            r23 = r0
            android.widget.TextView r23 = (android.widget.TextView) r23
            r0 = r2
            r1 = r34
            r32 = r2
            r2 = r35
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23)
            r0 = r32
            r11 = -1
            r0.v = r11
            com.huawei.common.widget.round.RoundLinearLayout r1 = r0.h
            r13 = 0
            r1.setTag(r13)
            r10 = r35
            r0.setRootTag(r10)
            r0.invalidateAll()
            goto L_0x006a
        L_0x09c9:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_market_product is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x09d5:
            r11 = r10
            r13 = r14
            r10 = r15
            r8 = 4
            r16 = 3
            r21 = 2
            r29 = 1
            java.lang.String r0 = "layout/finance_item_loan_contract_transaction_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0a1b
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanContractTransactionBindingImpl r7 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanContractTransactionBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLoanContractTransactionBindingImpl.f
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r10, r8, r13, r0)
            r2 = 0
            r2 = r0[r2]
            r3 = r2
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r2 = r0[r16]
            r4 = r2
            android.widget.TextView r4 = (android.widget.TextView) r4
            r2 = r0[r21]
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0 = r0[r29]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r7
            r1 = r34
            r2 = r35
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r11
            androidx.constraintlayout.widget.ConstraintLayout r0 = r7.a
            r0.setTag(r13)
            r7.setRootTag(r10)
            r7.invalidateAll()
            goto L_0x0270
        L_0x0a1b:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_contract_transaction is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0a27:
            r11 = r10
            r13 = r14
            r10 = r15
            r8 = 4
            r15 = 8
            r16 = 3
            r18 = 7
            r21 = 2
            r29 = 1
            r30 = 5
            java.lang.String r0 = "layout/finance_item_loan_contacts_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0a8c
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactsBindingImpl r9 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactsBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactsBindingImpl.j
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r10, r15, r13, r0)
            r2 = r0[r5]
            r3 = r2
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r2 = r0[r18]
            r4 = r2
            com.huawei.common.widget.round.RoundTextView r4 = (com.huawei.common.widget.round.RoundTextView) r4
            r2 = 0
            r2 = r0[r2]
            r5 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r5 = (com.huawei.common.widget.round.RoundConstraintLayout) r5
            r2 = r0[r29]
            r6 = r2
            android.widget.TextView r6 = (android.widget.TextView) r6
            r2 = r0[r8]
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            r2 = r0[r16]
            r8 = r2
            android.widget.TextView r8 = (android.widget.TextView) r8
            r2 = r0[r21]
            r14 = r2
            android.widget.TextView r14 = (android.widget.TextView) r14
            r0 = r0[r30]
            r15 = r0
            com.huawei.common.widget.round.RoundTextView r15 = (com.huawei.common.widget.round.RoundTextView) r15
            r0 = r9
            r1 = r34
            r2 = r35
            r13 = r9
            r9 = r14
            r14 = r10
            r10 = r15
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
            r13.i = r11
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r13.c
            r1 = 0
            r0.setTag(r1)
            r13.setRootTag(r14)
            r13.invalidateAll()
            r14 = r13
            goto L_0x0aea
        L_0x0a8c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_contacts is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0a98:
            r11 = r10
            r9 = r15
            r8 = 4
            r16 = 3
            r21 = 2
            r29 = 1
            r30 = 5
            java.lang.String r0 = "layout/finance_item_loan_contact_schedule_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0aeb
            com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactScheduleBindingImpl r10 = new com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactScheduleBindingImpl
            android.util.SparseIntArray r0 = com.huawei.ethiopia.finance.databinding.FinanceItemLoanContactScheduleBindingImpl.h
            r2 = 0
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r9, r5, r2, r0)
            r2 = r0[r30]
            r3 = r2
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r2 = 0
            r2 = r0[r2]
            r4 = r2
            com.huawei.common.widget.round.RoundConstraintLayout r4 = (com.huawei.common.widget.round.RoundConstraintLayout) r4
            r2 = r0[r29]
            r5 = r2
            android.widget.TextView r5 = (android.widget.TextView) r5
            r2 = r0[r8]
            r6 = r2
            android.widget.TextView r6 = (android.widget.TextView) r6
            r2 = r0[r16]
            r7 = r2
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = r0[r21]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r10
            r1 = r34
            r2 = r35
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r10.g = r11
            com.huawei.common.widget.round.RoundConstraintLayout r0 = r10.b
            r1 = 0
            r0.setTag(r1)
            r10.setRootTag(r9)
            r10.invalidateAll()
            r14 = r10
        L_0x0aea:
            return r14
        L_0x0aeb:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for finance_item_loan_contact_schedule is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0af7:
            r9 = r15
            androidx.databinding.ViewDataBinding r0 = a(r1, r9, r0, r2)
            return r0
        L_0x0afd:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "view must have a tag"
            r0.<init>(r1)
            throw r0
        L_0x0b05:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.finance.DataBinderMapperImpl.getDataBinder(androidx.databinding.DataBindingComponent, android.view.View, int):androidx.databinding.ViewDataBinding");
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
