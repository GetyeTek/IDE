package com.huawei.ethiopia.finance.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.finance.R$id;

public class FinanceActivityTransactionResultBindingImpl extends FinanceActivityTransactionResultBinding {
    @Nullable
    public static final SparseIntArray i;
    public long h;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        i = sparseIntArray;
        sparseIntArray.put(R$id.iv_success, 1);
        sparseIntArray.put(R$id.tv_result, 2);
        sparseIntArray.put(R$id.tv_title, 3);
        sparseIntArray.put(R$id.tvAmount, 4);
        sparseIntArray.put(R$id.tvUnit, 5);
        sparseIntArray.put(R$id.line, 6);
        sparseIntArray.put(R$id.recycler_view, 7);
        sparseIntArray.put(R$id.btn_finish, 8);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.h = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.h != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.h = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i2, Object obj, int i3) {
        return false;
    }

    public final boolean setVariable(int i2, @Nullable Object obj) {
        return true;
    }
}
