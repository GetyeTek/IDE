package com.huawei.ethiopia.finance.loan.activity;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import com.huawei.ethiopia.finance.resp.RolloverPreValidationResp;

public class ManualRolloverActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.ethiopia.finance.loan.activity.ManualRolloverActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (ManualRolloverActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.bankCode;
        } else {
            str = r4.getIntent().getExtras().getString("bankCode", r4.bankCode);
        }
        r4.bankCode = str;
        r4.isInstall = r4.getIntent().getBooleanExtra("isInstall", r4.isInstall);
        r4.rolloverPreValidation = (RolloverPreValidationResp) r4.getIntent().getSerializableExtra("rolloverPreValidation");
    }
}
