package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;

public class RepaymentSchedule implements Serializable {
    private String endDate;
    private String periodId;
    private String totalScheduleAmount;

    public String getEndDate() {
        return this.endDate;
    }

    public String getPeriodId() {
        return this.periodId;
    }

    public String getTotalScheduleAmount() {
        return this.totalScheduleAmount;
    }

    public void setEndDate(String str) {
        this.endDate = str;
    }

    public void setPeriodId(String str) {
        this.periodId = str;
    }

    public void setTotalScheduleAmount(String str) {
        this.totalScheduleAmount = str;
    }
}
