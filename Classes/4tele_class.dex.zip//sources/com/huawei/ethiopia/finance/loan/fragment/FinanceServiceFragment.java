package com.huawei.ethiopia.finance.loan.fragment;

import F3.a;
import O9.c;
import Y4.k;
import Y4.l;
import Y4.m;
import Y4.n;
import Y4.o;
import Y4.p;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import com.blankj.utilcode.util.s;
import com.blankj.utilcode.util.v;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.ethiopia.finance.R$color;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$mipmap;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceFragmentServiceBinding;
import com.huawei.ethiopia.finance.loan.adapter.SimpleFragmentStateAdapter;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceServiceViewModel;
import com.huawei.ethiopia.finance.od.activity.CreditPayHomeFragment;
import com.huawei.ethiopia.finance.resp.FinanceMenu;
import com.huawei.ethiopia.finance.resp.FinanceMenuListResp;
import com.huawei.ethiopia.finance.saving.activity.SavingFragment;
import java.util.ArrayList;
import java.util.List;
import o0.b;
import p5.g;
import p5.i;
import p5.j;

public class FinanceServiceFragment extends Fragment {
    public FinanceFragmentServiceBinding a;
    public String b;
    public FinanceMenuListResp c = null;
    public FinanceServiceViewModel d;
    public List<FinanceMenu> e;
    public String f;
    public SimpleFragmentStateAdapter g;
    public ApplyLoanFragment h;
    public SavingFragment i;
    public CreditPayHomeFragment j;

    public static FinanceServiceFragment y0(String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putString("bankCode", str);
        bundle.putString("IS_SELECT_OVERDRAFT", str2);
        FinanceServiceFragment financeServiceFragment = new FinanceServiceFragment();
        financeServiceFragment.setArguments(bundle);
        return financeServiceFragment;
    }

    public final void A0() {
        String string = getString(R$string.max_mela_limit);
        String string2 = getString(R$string.sanduq_balance);
        String string3 = getString(R$string.avaliable_mela_limit);
        FinanceMenuListResp financeMenuListResp = this.c;
        if (!(financeMenuListResp == null || financeMenuListResp.getFinanceServiceUIConfig() == null || TextUtils.isEmpty(this.c.getFinanceServiceUIConfig().getBalanceTitle()))) {
            string2 = this.c.getFinanceServiceUIConfig().getBalanceTitle();
        }
        FinanceMenuListResp financeMenuListResp2 = this.c;
        if (!(financeMenuListResp2 == null || financeMenuListResp2.getFinanceServiceUIConfig() == null || TextUtils.isEmpty(this.c.getFinanceServiceUIConfig().getMaxLimitTitle()))) {
            string = this.c.getFinanceServiceUIConfig().getMaxLimitTitle();
        }
        FinanceMenuListResp financeMenuListResp3 = this.c;
        if (!(financeMenuListResp3 == null || financeMenuListResp3.getFinanceServiceUIConfig() == null || TextUtils.isEmpty(this.c.getFinanceServiceUIConfig().getAvaliableLimitTitle()))) {
            string3 = this.c.getFinanceServiceUIConfig().getAvaliableLimitTitle();
        }
        FinanceFragmentServiceBinding financeFragmentServiceBinding = this.a;
        B0("KEY_SAVING_BALANCE", string2, financeFragmentServiceBinding.m, financeFragmentServiceBinding.n);
        FinanceFragmentServiceBinding financeFragmentServiceBinding2 = this.a;
        B0("KEY_LOAN_MAX_LIMIT", string, financeFragmentServiceBinding2.j, financeFragmentServiceBinding2.k);
        FinanceFragmentServiceBinding financeFragmentServiceBinding3 = this.a;
        B0("KEY_AVAILABLE_MELA_LIMIT", string3, financeFragmentServiceBinding3.g, financeFragmentServiceBinding3.h);
    }

    /* JADX WARNING: type inference failed for: r9v1, types: [android.view.View$OnClickListener, java.lang.Object] */
    public final void B0(String str, String str2, TextView textView, TextView textView2) {
        int i2;
        if (x0(str)) {
            i2 = R$mipmap.homev6_icon_eyes_close;
            textView2.setText("******");
        } else {
            i2 = R$mipmap.homev6_icon_eyes_open;
            s a2 = s.a("");
            textView2.setText(a2.a.getString(this.b + "_" + g.k() + "_" + str, "--"));
        }
        j.a(textView, str2, i2, new k(this, str, str2, textView, textView2), new Object());
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        FinanceFragmentServiceBinding inflate = DataBindingUtil.inflate(layoutInflater, R$layout.finance_fragment_service, viewGroup, false);
        this.a = inflate;
        return inflate.getRoot();
    }

    public final void onResume() {
        FinanceServiceFragment.super.onResume();
        A0();
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        String str;
        String str2;
        FinanceServiceFragment.super.onViewCreated(view, bundle);
        if (getArguments() != null) {
            this.b = getArguments().getString("bankCode");
            if (getArguments().getSerializable("financeresp") != null) {
                this.c = (FinanceMenuListResp) getArguments().getSerializable("financeresp");
            }
            FinanceMenuListResp financeMenuListResp = this.c;
            if (financeMenuListResp != null) {
                this.f = financeMenuListResp.getFundsLenderId();
                this.e = this.c.getMenuItems();
            }
        }
        String y = b.c(AppService.class).y();
        String str3 = "";
        if ("am".equals(y) || "ti".equals(y)) {
            FinanceMenuListResp financeMenuListResp2 = this.c;
            if (financeMenuListResp2 == null || financeMenuListResp2.getFinanceServiceUIConfig() == null || this.c.getFinanceServiceUIConfig().getLoan() == null) {
                str = str3;
            } else {
                str = this.c.getFinanceServiceUIConfig().getLoan().getLoanIcon();
            }
            c.c(this.a.e, str, R$mipmap.finance_icon_mela_logo2);
            FinanceMenuListResp financeMenuListResp3 = this.c;
            if (!(financeMenuListResp3 == null || financeMenuListResp3.getFinanceServiceUIConfig() == null || this.c.getFinanceServiceUIConfig().getSaving() == null)) {
                str3 = this.c.getFinanceServiceUIConfig().getSaving().getSavingIcon();
            }
            c.c(this.a.f, str3, R$mipmap.finance_icon_sanduq_logo2);
            this.a.d.setImageResource(R$mipmap.finance_icon_endekise_logo2);
        } else {
            FinanceMenuListResp financeMenuListResp4 = this.c;
            if (financeMenuListResp4 == null || financeMenuListResp4.getFinanceServiceUIConfig() == null || this.c.getFinanceServiceUIConfig().getLoan() == null) {
                str2 = str3;
            } else {
                str2 = this.c.getFinanceServiceUIConfig().getLoan().getLoanIcon();
            }
            c.c(this.a.e, str2, R$mipmap.finance_icon_mela_logo);
            FinanceMenuListResp financeMenuListResp5 = this.c;
            if (!(financeMenuListResp5 == null || financeMenuListResp5.getFinanceServiceUIConfig() == null || this.c.getFinanceServiceUIConfig().getSaving() == null)) {
                str3 = this.c.getFinanceServiceUIConfig().getSaving().getSavingIcon();
            }
            c.c(this.a.f, str3, R$mipmap.finance_icon_sanduq_logo);
            this.a.d.setImageResource(R$mipmap.finance_icon_endekise_logo);
        }
        int f2 = g.f(requireContext(), this.c, this.b);
        this.a.l.setTextColor(f2);
        this.a.e.getBaseFilletView().e(f2);
        this.a.f.getBaseFilletView().e(f2);
        this.a.d.getBaseFilletView().e(f2);
        this.d = new ViewModelProvider(this).get(FinanceServiceViewModel.class);
        if (this.g != null) {
            z0();
        } else {
            this.g = new FragmentStateAdapter(requireActivity());
            ArrayList arrayList = new ArrayList();
            this.g.a(arrayList);
            List<FinanceMenu> list = this.e;
            if (list != null) {
                for (FinanceMenu next : list) {
                    if (TextUtils.equals(next.getId(), "finance_loan")) {
                        String str4 = this.f;
                        FinanceMenu w0 = w0("finance_loan");
                        String str5 = this.b;
                        Bundle bundle2 = new Bundle();
                        bundle2.putString("fundsLenderId", str4);
                        bundle2.putSerializable("financeMenu", w0);
                        bundle2.putString("bankCode", str5);
                        ApplyLoanFragment applyLoanFragment = new ApplyLoanFragment();
                        applyLoanFragment.setArguments(bundle2);
                        this.h = applyLoanFragment;
                        arrayList.add(applyLoanFragment);
                        this.a.a.setVisibility(0);
                    }
                    if (TextUtils.equals(next.getId(), "finance_saving")) {
                        String str6 = this.f;
                        FinanceMenu w02 = w0("finance_saving");
                        String str7 = this.b;
                        Bundle bundle3 = new Bundle();
                        bundle3.putString("fundsLenderId", str6);
                        bundle3.putSerializable("financeMenu", w02);
                        bundle3.putString("bankCode", str7);
                        SavingFragment savingFragment = new SavingFragment();
                        savingFragment.setArguments(bundle3);
                        this.i = savingFragment;
                        arrayList.add(savingFragment);
                        this.a.c.setVisibility(0);
                    }
                    if (TextUtils.equals(next.getId(), "finance_overdraft")) {
                        String str8 = this.f;
                        FinanceMenu w03 = w0("finance_overdraft");
                        String str9 = this.b;
                        Bundle bundle4 = new Bundle();
                        bundle4.putString("fundsLenderId", str8);
                        bundle4.putSerializable("financeMenu", w03);
                        bundle4.putString("bankCode", str9);
                        CreditPayHomeFragment creditPayHomeFragment = new CreditPayHomeFragment();
                        creditPayHomeFragment.setArguments(bundle4);
                        this.j = creditPayHomeFragment;
                        arrayList.add(creditPayHomeFragment);
                        this.a.b.setVisibility(0);
                    }
                }
                this.a.p.setAdapter(this.g);
                this.a.p.registerOnPageChangeCallback(new p(this));
                this.a.e.setOnClickListener(new J6.c(this, 1));
                this.a.f.setOnClickListener(new a(this, 3));
                this.a.d.setOnClickListener(new m(this, 0));
                if (TextUtils.equals("true", getArguments().getString("IS_SELECT_OVERDRAFT"))) {
                    v0(2);
                } else {
                    v0(i.e.d);
                }
            }
        }
        this.a.j.postDelayed(new l(this, 0), 1000);
        this.d.a.observe(getViewLifecycleOwner(), new n(this, 0));
        this.d.f.observe(getViewLifecycleOwner(), new o(this, 0));
        A0();
    }

    public final void v0(int i2) {
        int i3;
        int i4;
        int i5;
        int i7;
        int i8;
        int i9 = 0;
        this.a.p.setCurrentItem(i2, false);
        d2.a baseFilletView = this.a.e.getBaseFilletView();
        if (i2 == 0) {
            i3 = v.a(2.0f);
        } else {
            i3 = 0;
        }
        baseFilletView.f(i3);
        d2.a baseFilletView2 = this.a.f.getBaseFilletView();
        if (i2 == 1) {
            i4 = v.a(2.0f);
        } else {
            i4 = 0;
        }
        baseFilletView2.f(i4);
        d2.a baseFilletView3 = this.a.d.getBaseFilletView();
        if (i2 == 2) {
            i5 = v.a(2.0f);
        } else {
            i5 = 0;
        }
        baseFilletView3.f(i5);
        TextView textView = this.a.l;
        if (i2 == 0) {
            i7 = 1;
        } else {
            i7 = 0;
        }
        textView.setTypeface((Typeface) null, i7);
        TextView textView2 = this.a.o;
        if (i2 == 1) {
            i8 = 1;
        } else {
            i8 = 0;
        }
        textView2.setTypeface((Typeface) null, i8);
        TextView textView3 = this.a.i;
        if (i2 == 2) {
            i9 = 1;
        }
        textView3.setTypeface((Typeface) null, i9);
        if (i2 == 0) {
            this.a.l.setTextColor(g.f(requireContext(), this.c, this.b));
            TextView textView4 = this.a.o;
            Context requireContext = requireContext();
            int i10 = R$color.colorTextLevel2;
            textView4.setTextColor(ContextCompat.getColor(requireContext, i10));
            this.a.i.setTextColor(ContextCompat.getColor(requireContext(), i10));
        } else if (i2 == 1) {
            TextView textView5 = this.a.l;
            Context requireContext2 = requireContext();
            int i11 = R$color.colorTextLevel2;
            textView5.setTextColor(ContextCompat.getColor(requireContext2, i11));
            this.a.o.setTextColor(g.f(requireContext(), this.c, this.b));
            this.a.i.setTextColor(ContextCompat.getColor(requireContext(), i11));
        } else if (i2 == 2) {
            TextView textView6 = this.a.l;
            Context requireContext3 = requireContext();
            int i12 = R$color.colorTextLevel2;
            textView6.setTextColor(ContextCompat.getColor(requireContext3, i12));
            this.a.o.setTextColor(ContextCompat.getColor(requireContext(), i12));
            this.a.i.setTextColor(g.f(requireContext(), this.c, this.b));
        }
    }

    public final FinanceMenu w0(String str) {
        List<FinanceMenu> list = this.e;
        if (list == null || list.isEmpty()) {
            return null;
        }
        for (FinanceMenu next : this.e) {
            if (TextUtils.equals(str, next.getId())) {
                return next;
            }
        }
        return null;
    }

    public final boolean x0(String str) {
        s a2 = s.a("finance_sp_name_no_cache");
        return a2.a.getBoolean(F0.o.a(new StringBuilder(), this.b, "_hideBalance_", str), true);
    }

    public final void z0() {
        int i2 = i.e.d;
        if (i2 == 0) {
            ApplyLoanFragment applyLoanFragment = this.h;
            if (applyLoanFragment != null) {
                applyLoanFragment.f.a("finance_loan");
            }
        } else if (i2 == 1) {
            SavingFragment savingFragment = this.i;
            if (savingFragment != null) {
                savingFragment.d.b("finance_saving", savingFragment.e);
            }
        } else {
            CreditPayHomeFragment creditPayHomeFragment = this.j;
            if (creditPayHomeFragment != null) {
                creditPayHomeFragment.c.b("finance_saving", creditPayHomeFragment.d);
            }
        }
    }
}
