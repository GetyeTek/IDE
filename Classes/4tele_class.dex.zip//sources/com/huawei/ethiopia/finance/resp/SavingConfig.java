package com.huawei.ethiopia.finance.resp;

import java.io.Serializable;

public class SavingConfig implements Serializable {
    private String mySavingIcon;
    private String mySavingTxt;
    private String savingActivateTitle;
    private String savingAgreeTxt;
    private String savingIcon;
    private String savingLable;
    private String savingProductsTitle;

    public String getMySavingIcon() {
        return this.mySavingIcon;
    }

    public String getMySavingTxt() {
        return this.mySavingTxt;
    }

    public String getSavingActivateTitle() {
        return this.savingActivateTitle;
    }

    public String getSavingAgreeTxt() {
        return this.savingAgreeTxt;
    }

    public String getSavingIcon() {
        return this.savingIcon;
    }

    public String getSavingLable() {
        return this.savingLable;
    }

    public String getSavingProductsTitle() {
        return this.savingProductsTitle;
    }

    public void setMySavingIcon(String str) {
        this.mySavingIcon = str;
    }

    public void setMySavingTxt(String str) {
        this.mySavingTxt = str;
    }

    public void setSavingActivateTitle(String str) {
        this.savingActivateTitle = str;
    }

    public void setSavingAgreeTxt(String str) {
        this.savingAgreeTxt = str;
    }

    public void setSavingIcon(String str) {
        this.savingIcon = str;
    }

    public void setSavingLable(String str) {
        this.savingLable = str;
    }

    public void setSavingProductsTitle(String str) {
        this.savingProductsTitle = str;
    }
}
