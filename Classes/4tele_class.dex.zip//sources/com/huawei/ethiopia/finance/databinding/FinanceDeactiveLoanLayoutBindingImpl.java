package com.huawei.ethiopia.finance.databinding;

import androidx.annotation.Nullable;

public class FinanceDeactiveLoanLayoutBindingImpl extends FinanceDeactiveLoanLayoutBinding {
    public long a;

    public final void executeBindings() {
        synchronized (this) {
            this.a = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.a != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.a = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
