package com.huawei.ethiopia.finance.loan.activity;

import L3.a;
import O9.c;
import Y4.d;
import a5.l;
import android.content.Intent;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.ActivityManualRolloverBinding;
import com.huawei.ethiopia.finance.loan.adapter.LoanValidationAdapter;
import com.huawei.ethiopia.finance.loan.repository.ApplyNewNplRepository;
import com.huawei.ethiopia.finance.loan.viewmodel.LoanRestructureViewModel;
import com.huawei.ethiopia.finance.resp.PreNewNplValidationResp;
import com.huawei.http.b;
import java.nio.charset.StandardCharsets;

@Route(path = "/finance/loanRestructure")
public class LoanRestructureActivity extends BaseActivity {
    public static final /* synthetic */ int f = 0;
    public ActivityManualRolloverBinding d;
    public LoanRestructureViewModel e;
    @Autowired(name = "DATA")
    PreNewNplValidationResp preValidationResp;

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.ethiopia.finance.loan.activity.LoanRestructureActivity, android.app.Activity] */
    public final ViewBinding C0() {
        ActivityManualRolloverBinding a = ActivityManualRolloverBinding.a(getLayoutInflater());
        this.d = a;
        return a;
    }

    public final void D0() {
        LoanRestructureViewModel loanRestructureViewModel = new ViewModelProvider(this).get(LoanRestructureViewModel.class);
        this.e = loanRestructureViewModel;
        loanRestructureViewModel.a.observe(this, new d(this, 1));
    }

    /* JADX WARNING: type inference failed for: r1v3, types: [android.view.View$OnClickListener, com.huawei.ethiopia.finance.loan.activity.u] */
    /* JADX WARNING: type inference failed for: r1v11, types: [android.view.View$OnClickListener, com.huawei.ethiopia.finance.loan.activity.v] */
    public final void G0() {
        f.g(getWindow());
        f.f(this, false);
        this.d.g.setText(R$string.finance_loan_restructure);
        this.d.b.setText(getString(R$string.designstandard_next));
        this.d.c.setOnClickListener(new u(this));
        PreNewNplValidationResp preNewNplValidationResp = this.preValidationResp;
        if (preNewNplValidationResp != null) {
            c.c(this.d.d, preNewNplValidationResp.getBankIcon(), -1);
            this.d.f.setText(R$string.finance_loan_restructure_sub_title);
            this.d.e.setLayoutManager(new LinearLayoutManager(this));
            LoanValidationAdapter loanValidationAdapter = new LoanValidationAdapter(this);
            loanValidationAdapter.e(this.preValidationResp);
            this.d.e.setAdapter(loanValidationAdapter);
            this.d.b.setOnClickListener(new v(this));
        }
    }

    public final boolean H0() {
        return false;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [com.huawei.http.b, com.huawei.ethiopia.finance.loan.repository.ApplyNewNplRepository] */
    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        LoanRestructureActivity.super.onActivityResult(i, i2, intent);
        if (intent != null && i == 101 && i2 == -1 && this.preValidationResp != null) {
            String str = new String(intent.getByteArrayExtra("pin"), StandardCharsets.UTF_8);
            LoanRestructureViewModel loanRestructureViewModel = this.e;
            String contractID = this.preValidationResp.getContractID();
            ApplyNewNplRepository applyNewNplRepository = loanRestructureViewModel.b;
            if (applyNewNplRepository != null) {
                applyNewNplRepository.cancel();
            }
            loanRestructureViewModel.a.setValue(V7.c.c());
            ? bVar = new b();
            bVar.addParams("contractID", contractID);
            bVar.addParams("initiatorPin", a.g(str));
            loanRestructureViewModel.b = bVar;
            bVar.sendRequest(new l(loanRestructureViewModel, 0));
        }
    }
}
