package com.huawei.ethiopia.maplib.viewmodel;

import V7.c;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.huawei.ethiopia.maplib.model.AddressInfo;
import java.util.ArrayList;
import java.util.List;

public class MapSearchViewModel extends ViewModel {
    public final MutableLiveData<c<List<AddressInfo>>> a = new MutableLiveData<>();
    public final ArrayList b = new ArrayList();
    public PlacesClient c = null;
    public AutocompleteSessionToken d;
}
