package com.huawei.ethiopia.maplib;

public final class R$array {
    public static final int WheelArrayDefault = 2130903040;
    public static final int WheelArrayWeek = 2130903041;
    public static final int assume_strong_biometrics_models = 2130903042;
    public static final int crypto_fingerprint_fallback_prefixes = 2130903048;
    public static final int crypto_fingerprint_fallback_vendors = 2130903049;
    public static final int delay_showing_prompt_models = 2130903050;
    public static final int hide_fingerprint_instantly_prefixes = 2130903054;

    private R$array() {
    }
}
