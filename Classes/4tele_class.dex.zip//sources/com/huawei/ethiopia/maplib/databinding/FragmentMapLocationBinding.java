package com.huawei.ethiopia.maplib.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundConstraintLayout;

public final class FragmentMapLocationBinding implements ViewBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final LoadingButton c;
    @NonNull
    public final RoundConstraintLayout d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public FragmentMapLocationBinding(@NonNull ConstraintLayout constraintLayout, @NonNull ImageView imageView, @NonNull LoadingButton loadingButton, @NonNull RoundConstraintLayout roundConstraintLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.a = constraintLayout;
        this.b = imageView;
        this.c = loadingButton;
        this.d = roundConstraintLayout;
        this.e = textView;
        this.f = textView2;
    }

    @NonNull
    public final View getRoot() {
        return this.a;
    }
}
