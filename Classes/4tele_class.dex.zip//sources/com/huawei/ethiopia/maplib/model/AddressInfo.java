package com.huawei.ethiopia.maplib.model;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import com.google.android.gms.maps.model.LatLng;

public class AddressInfo implements Parcelable {
    public static final Parcelable.Creator<AddressInfo> CREATOR = new Object();
    private String fullText;
    private LatLng latLng;
    private String placeId;
    private String primaryText;
    private String secondText;

    public class a implements Parcelable.Creator<AddressInfo> {
        public final Object createFromParcel(Parcel parcel) {
            return new AddressInfo(parcel);
        }

        public final Object[] newArray(int i) {
            return new AddressInfo[i];
        }
    }

    public AddressInfo(Parcel parcel) {
        this.primaryText = parcel.readString();
        this.secondText = parcel.readString();
        this.fullText = parcel.readString();
        this.latLng = parcel.readParcelable(LatLng.class.getClassLoader());
        this.placeId = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public String getFullText() {
        return this.fullText;
    }

    public LatLng getLatLng() {
        return this.latLng;
    }

    public String getPlaceId() {
        return this.placeId;
    }

    public String getPrimaryText() {
        return this.primaryText;
    }

    public String getSecondText() {
        return this.secondText;
    }

    public void setFullText(String str) {
        this.fullText = str;
    }

    public void setLatLng(LatLng latLng2) {
        this.latLng = latLng2;
    }

    public void setPlaceId(String str) {
        this.placeId = str;
    }

    public void setPrimaryText(String str) {
        this.primaryText = str;
    }

    public void setSecondText(String str) {
        this.secondText = str;
    }

    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(this.primaryText);
        parcel.writeString(this.secondText);
        parcel.writeString(this.fullText);
        parcel.writeParcelable(this.latLng, i);
        parcel.writeString(this.placeId);
    }

    public AddressInfo() {
    }

    public AddressInfo(String str, String str2, String str3, String str4) {
        this.primaryText = str;
        this.secondText = str2;
        this.fullText = str3;
        this.placeId = str4;
    }
}
