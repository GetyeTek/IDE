package com.huawei.ethiopia.maplib;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.ethiopia.maplib.databinding.ActivityLocationSearchBinding;
import com.huawei.ethiopia.maplib.databinding.ActivityLocationSearchBindingImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(2);
            a = hashMap;
            hashMap.put("layout/activity_location_search_0", Integer.valueOf(R$layout.activity_location_search));
            hashMap.put("layout/activity_register_map_location_0", Integer.valueOf(R$layout.activity_register_map_location));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(2);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_location_search, 1);
        sparseIntArray.put(R$layout.activity_register_map_location, 2);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(7);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        DataBindingComponent dataBindingComponent2 = dataBindingComponent;
        View view2 = view;
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new RuntimeException("view must have a tag");
            } else if (i2 != 1) {
                if (i2 == 2) {
                    if ("layout/activity_register_map_location_0".equals(tag)) {
                        Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 1, (ViewDataBinding.IncludedLayouts) null, (SparseIntArray) null);
                        ViewDataBinding viewDataBinding = new ViewDataBinding(dataBindingComponent2, view2, 0);
                        viewDataBinding.a = -1;
                        ((LinearLayout) mapBindings[0]).setTag((Object) null);
                        viewDataBinding.setRootTag(view2);
                        viewDataBinding.invalidateAll();
                        return viewDataBinding;
                    }
                    throw new IllegalArgumentException(l.a(tag, "The tag for activity_register_map_location is invalid. Received: "));
                }
            } else if ("layout/activity_location_search_0".equals(tag)) {
                Object[] mapBindings2 = ViewDataBinding.mapBindings(dataBindingComponent2, view2, 8, (ViewDataBinding.IncludedLayouts) null, ActivityLocationSearchBindingImpl.f);
                ImageView imageView = (ImageView) mapBindings2[7];
                ConstraintLayout constraintLayout = (ConstraintLayout) mapBindings2[6];
                ImageView imageView2 = (ImageView) mapBindings2[2];
                ActivityLocationSearchBinding activityLocationSearchBinding = new ActivityLocationSearchBinding(dataBindingComponent, view, (EditText) mapBindings2[3], (ImageView) mapBindings2[4], (RecyclerView) mapBindings2[5], (ImageView) mapBindings2[1]);
                activityLocationSearchBinding.e = -1;
                ((LinearLayout) mapBindings2[0]).setTag((Object) null);
                activityLocationSearchBinding.setRootTag(view2);
                activityLocationSearchBinding.invalidateAll();
                return activityLocationSearchBinding;
            } else {
                throw new IllegalArgumentException(l.a(tag, "The tag for activity_location_search is invalid. Received: "));
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
