package com.huawei.ethiopia.maplib.adapter;

import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.huawei.ethiopia.maplib.R$id;
import com.huawei.ethiopia.maplib.model.AddressInfo;
import java.util.Arrays;
import r5.C0108a;

public class AddressAdapter extends BaseQuickAdapter<AddressInfo, BaseViewHolder> {
    public static final /* synthetic */ int c = 0;
    public PlacesClient a;
    public AutocompleteSessionToken b;

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        AddressInfo addressInfo = (AddressInfo) obj;
        baseViewHolder.setText(R$id.tv_address, addressInfo.getPrimaryText());
        this.a.fetchPlace(FetchPlaceRequest.builder(addressInfo.getPlaceId(), Arrays.asList(new Place.Field[]{Place.Field.LAT_LNG, Place.Field.NAME})).setSessionToken(this.b).build()).addOnSuccessListener(new C0108a(addressInfo, baseViewHolder));
    }
}
