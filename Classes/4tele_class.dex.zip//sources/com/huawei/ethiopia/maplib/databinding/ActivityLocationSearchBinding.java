package com.huawei.ethiopia.maplib.databinding;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public abstract class ActivityLocationSearchBinding extends ViewDataBinding {
    @NonNull
    public final EditText a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final RecyclerView c;
    @NonNull
    public final ImageView d;

    public ActivityLocationSearchBinding(DataBindingComponent dataBindingComponent, View view, EditText editText, ImageView imageView, RecyclerView recyclerView, ImageView imageView2) {
        super(dataBindingComponent, view, 0);
        this.a = editText;
        this.b = imageView;
        this.c = recyclerView;
        this.d = imageView2;
    }
}
