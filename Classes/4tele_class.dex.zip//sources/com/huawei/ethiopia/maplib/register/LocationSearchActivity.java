package com.huawei.ethiopia.maplib.register;

import D6.g;
import D6.k;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.blankj.utilcode.util.v;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.huawei.common.widget.recyclerview.RecycleViewDivider;
import com.huawei.ethiopia.maplib.R$color;
import com.huawei.ethiopia.maplib.R$layout;
import com.huawei.ethiopia.maplib.R$string;
import com.huawei.ethiopia.maplib.adapter.AddressAdapter;
import com.huawei.ethiopia.maplib.databinding.ActivityLocationSearchBinding;
import com.huawei.ethiopia.maplib.viewmodel.MapSearchViewModel;
import com.huawei.payment.mvvm.DataBindingActivity;
import t5.C0110a;
import t5.b;

public class LocationSearchActivity extends DataBindingActivity<ActivityLocationSearchBinding, MapSearchViewModel> {
    public static final /* synthetic */ int e = 0;
    public AddressAdapter d;

    public final int C0() {
        return R$layout.activity_location_search;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.ethiopia.maplib.register.LocationSearchActivity, android.content.Context, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        LocationSearchActivity.super.onCreate(bundle);
        Places.initialize(getApplicationContext(), getString(R$string.google_maps_key));
        this.b.c.setLayoutManager(new LinearLayoutManager(this));
        this.b.c.addItemDecoration(new RecycleViewDivider(ContextCompat.getColor(this, R$color.colorDividerLight), v.a(1.0f)));
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_address);
        baseQuickAdapter.a = null;
        baseQuickAdapter.a = Places.createClient(this);
        baseQuickAdapter.b = AutocompleteSessionToken.newInstance();
        this.d = baseQuickAdapter;
        this.b.c.setAdapter(baseQuickAdapter);
        this.b.a.addTextChangedListener(new b(this));
        this.b.b.setOnClickListener(new g(this, 8));
        this.d.setOnItemClickListener(new C0110a(this, 0));
        this.b.d.setOnClickListener(new k(this, 5));
        this.c.a.observe(this, new C4.b(this, 3));
    }
}
