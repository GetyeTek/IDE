package com.huawei.ethiopia.maplib.choose;

import R1.a;
import V1.h;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import org.json.JSONException;
import org.json.JSONObject;

public class ChooseLocationFragment extends Fragment {
    public a<JSONObject> a;

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        ChooseLocationFragment.super.onActivityResult(i, i2, intent);
        if (i == 100 && intent != null && i2 == -1) {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("lat", intent.getStringExtra("lat"));
                jSONObject.put("lng", intent.getStringExtra("lng"));
                a<JSONObject> aVar = this.a;
                if (aVar != null) {
                    aVar.onSuccess(jSONObject);
                }
            } catch (JSONException e) {
                e.getMessage();
                h.b();
            }
        }
    }

    public final void onCreate(@Nullable Bundle bundle) {
        ChooseLocationFragment.super.onCreate(bundle);
        setRetainInstance(true);
    }
}
