package com.huawei.ethiopia.maplib.choose;

import A6.d;
import C6.c;
import V1.h;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.q;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.dialog.TipsDialog;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.ethiopia.maplib.R$id;
import com.huawei.ethiopia.maplib.R$layout;
import com.huawei.ethiopia.maplib.R$mipmap;
import com.huawei.ethiopia.maplib.R$string;
import com.huawei.ethiopia.maplib.databinding.ActivityChooseLocationBinding;
import java.util.ArrayList;
import java.util.Locale;

public class ChooseLocationActivity extends BaseTitleActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener, Runnable {
    public static final /* synthetic */ int u = 0;
    public final LatLng i = new LatLng(28.22779569381056d, 112.93827630579472d);
    public ActivityChooseLocationBinding j;
    public FusedLocationProviderClient k;
    public Marker l;
    public Marker m;
    public GoogleMap n;
    public LatLng o;
    public int p = 0;
    public double q;
    public double r;
    public boolean s = true;
    public TipsDialog t;

    public class a implements q.a {
        public a() {
        }

        public final void a(@NonNull ArrayList arrayList) {
            int i = ChooseLocationActivity.u;
            ChooseLocationActivity chooseLocationActivity = ChooseLocationActivity.this;
            chooseLocationActivity.Y0();
            chooseLocationActivity.W0();
        }

        /* JADX WARNING: type inference failed for: r3v0, types: [android.view.View$OnClickListener, java.lang.Object] */
        public final void b(@NonNull ArrayList arrayList) {
            int i = ChooseLocationActivity.u;
            FragmentActivity fragmentActivity = ChooseLocationActivity.this;
            fragmentActivity.Y0();
            String string = fragmentActivity.getString(R$string.please_enable_location_permission_in_settings);
            if (fragmentActivity.t == null) {
                String string2 = fragmentActivity.getString(R$string.cancel);
                String string3 = fragmentActivity.getString(R$string.app_allow);
                ? obj = new Object();
                A6.b bVar = new A6.b(fragmentActivity, 6);
                BaseDialog baseDialog = new BaseDialog();
                baseDialog.g = null;
                baseDialog.h = string;
                baseDialog.i = string2;
                baseDialog.j = string3;
                baseDialog.k = bVar;
                baseDialog.l = obj;
                fragmentActivity.t = baseDialog;
            }
            TipsDialog tipsDialog = fragmentActivity.t;
            if (!tipsDialog.a) {
                tipsDialog.show(fragmentActivity.getSupportFragmentManager(), "tipsDialog");
            }
        }
    }

    public class b implements OnCompleteListener<Location> {
        public b() {
        }

        public final void onComplete(@NonNull Task<Location> task) {
            Location location;
            boolean isSuccessful = task.isSuccessful();
            ChooseLocationActivity chooseLocationActivity = ChooseLocationActivity.this;
            if (!isSuccessful || (location = (Location) task.getResult()) == null) {
                task.getException();
                if (chooseLocationActivity.p < 5) {
                    A.h(chooseLocationActivity, 2000);
                } else {
                    chooseLocationActivity.n.moveCamera(CameraUpdateFactory.newLatLngZoom(chooseLocationActivity.i, 15.0f));
                }
            } else {
                LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                chooseLocationActivity.o = latLng;
                chooseLocationActivity.Z0();
                chooseLocationActivity.U0(latLng);
                chooseLocationActivity.n.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
            }
        }
    }

    public final void D0() {
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [android.content.Context, com.google.android.gms.maps.OnMapReadyCallback, com.huawei.ethiopia.maplib.choose.ChooseLocationActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void G0() {
        ChooseLocationActivity.super.G0();
        f.e(this, 0, false);
        N0(getString(R$string.maplib_choose_location));
        String stringExtra = getIntent().getStringExtra("initLat");
        String stringExtra2 = getIntent().getStringExtra("initLng");
        this.q = Double.MIN_VALUE;
        this.r = Double.MIN_VALUE;
        try {
            this.q = Double.parseDouble(stringExtra);
            this.r = Double.parseDouble(stringExtra2);
        } catch (Exception unused) {
            this.s = false;
        }
        this.j.c.setOnClickListener(new C6.b(this, 4));
        this.j.b.setOnClickListener(new c(this, 4));
        SupportMapFragment newInstance = SupportMapFragment.newInstance();
        getSupportFragmentManager().beginTransaction().add(R$id.map_container, newInstance).commit();
        newInstance.getMapAsync(this);
        this.k = LocationServices.getFusedLocationProviderClient(this);
        if (!((LocationManager) getSystemService("location")).isProviderEnabled("gps")) {
            X0(getString(R$string.please_enable_location_permission_in_settings));
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [com.huawei.ethiopia.maplib.choose.ChooseLocationActivity, android.app.Activity] */
    public final ViewBinding K0() {
        ConstraintLayout inflate = getLayoutInflater().inflate(R$layout.activity_choose_location, (ViewGroup) null, false);
        int i2 = R$id.iv_location;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(inflate, i2);
        if (imageView != null) {
            i2 = R$id.map_container;
            if (((FrameLayout) ViewBindings.findChildViewById(inflate, i2)) != null) {
                i2 = R$id.tv_confirm;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(inflate, i2);
                if (imageView2 != null) {
                    i2 = R$id.tv_lat_lng;
                    if (((TextView) ViewBindings.findChildViewById(inflate, i2)) != null) {
                        i2 = R$id.tv_lat_lng_value;
                        TextView textView = (TextView) ViewBindings.findChildViewById(inflate, i2);
                        if (textView != null) {
                            ActivityChooseLocationBinding activityChooseLocationBinding = new ActivityChooseLocationBinding(inflate, imageView, imageView2, textView);
                            this.j = activityChooseLocationBinding;
                            return activityChooseLocationBinding;
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i2)));
    }

    public final boolean L0() {
        return false;
    }

    public final void U0(LatLng latLng) {
        if (this.m == null) {
            this.m = this.n.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.fromResource(R$mipmap.map_my_location)).title(""));
        }
        Marker marker = this.m;
        if (marker != null) {
            marker.setPosition(latLng);
        }
        try {
            this.n.setMyLocationEnabled(false);
        } catch (SecurityException e) {
            e.getMessage();
            h.b();
        }
    }

    public final void V0() {
        q e = q.e(new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"});
        e.c = new a();
        e.f();
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.ethiopia.maplib.choose.ChooseLocationActivity, android.app.Activity] */
    public final void W0() {
        try {
            this.k.getLastLocation().addOnCompleteListener(this, new b());
        } catch (SecurityException e) {
            e.getMessage();
        }
        this.p++;
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.content.Context, com.huawei.ethiopia.maplib.choose.ChooseLocationActivity, java.lang.Object, androidx.fragment.app.FragmentActivity] */
    public final void X0(String str) {
        if (this.t == null) {
            String string = getString(R$string.cancel);
            String string2 = getString(R$string.app_allow);
            A6.c cVar = new A6.c(this, 5);
            d dVar = new d(this, 3);
            BaseDialog baseDialog = new BaseDialog();
            baseDialog.g = null;
            baseDialog.h = str;
            baseDialog.i = string;
            baseDialog.j = string2;
            baseDialog.k = dVar;
            baseDialog.l = cVar;
            this.t = baseDialog;
        }
        TipsDialog tipsDialog = this.t;
        if (!tipsDialog.a) {
            tipsDialog.show(getSupportFragmentManager(), "tipsDialog");
        }
    }

    public final void Y0() {
        if (this.n != null) {
            try {
                if (q.c(new String[]{"android.permission.ACCESS_FINE_LOCATION"})) {
                    this.n.setMyLocationEnabled(true);
                } else {
                    this.n.setMyLocationEnabled(false);
                }
                this.n.getUiSettings().setMyLocationButtonEnabled(false);
            } catch (SecurityException e) {
                e.getMessage();
                h.b();
            }
        }
    }

    public final void Z0() {
        this.j.d.setText(String.format(Locale.ENGLISH, "%.6f & %.6f", new Object[]{Double.valueOf(this.o.latitude), Double.valueOf(this.o.longitude)}));
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        ChooseLocationActivity.super.onActivityResult(i2, i3, intent);
        if (i2 == 110 && i3 == -1) {
            Y0();
            W0();
        }
    }

    public final void onDestroy() {
        ChooseLocationActivity.super.onDestroy();
        A.a.removeCallbacks(this);
    }

    public final void onMapClick(@NonNull LatLng latLng) {
        if (this.l == null) {
            this.l = this.n.addMarker(new MarkerOptions().position(latLng).title(latLng.toString()));
        }
        Marker marker = this.l;
        if (marker != null) {
            marker.setPosition(latLng);
        }
        this.o = latLng;
        Z0();
    }

    public final void onMapReady(@NonNull GoogleMap googleMap) {
        this.n = googleMap;
        googleMap.setOnMapClickListener(this);
        if (!this.s) {
            V0();
        } else {
            LatLng latLng = new LatLng(this.q, this.r);
            this.n.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(this.q, this.r), 15.0f));
            U0(latLng);
        }
        Y0();
    }

    public final void run() {
        V0();
    }
}
