package com.huawei.ethiopia.maplib.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.ethiopia.maplib.R$id;

public class ActivityLocationSearchBindingImpl extends ActivityLocationSearchBinding {
    @Nullable
    public static final SparseIntArray f;
    public long e;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f = sparseIntArray;
        sparseIntArray.put(R$id.searchback, 1);
        sparseIntArray.put(R$id.searchfind, 2);
        sparseIntArray.put(R$id.edittext, 3);
        sparseIntArray.put(R$id.imageview, 4);
        sparseIntArray.put(R$id.listview, 5);
        sparseIntArray.put(R$id.noresultconstraint, 6);
        sparseIntArray.put(R$id.nodatabackground, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.e = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.e != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.e = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
