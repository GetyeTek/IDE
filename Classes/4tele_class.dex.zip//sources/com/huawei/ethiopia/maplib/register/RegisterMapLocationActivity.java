package com.huawei.ethiopia.maplib.register;

import androidx.lifecycle.ViewModel;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.ethiopia.maplib.R$layout;
import com.huawei.ethiopia.maplib.databinding.ActivityRegisterMapLocationBinding;
import com.huawei.payment.mvvm.DataBindingActivity;

@Route(path = "/maplib/mapLocation")
public class RegisterMapLocationActivity extends DataBindingActivity<ActivityRegisterMapLocationBinding, ViewModel> {
    public final int C0() {
        return R$layout.activity_register_map_location;
    }
}
