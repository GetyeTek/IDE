package com.huawei.ethiopia.maplib.register;

import V1.h;
import Y4.m;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.q;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.huawei.digitalpayment.customer.baselib.base.BaseFragment;
import com.huawei.ethiopia.maplib.R$id;
import com.huawei.ethiopia.maplib.databinding.FragmentMapLocationBinding;
import com.huawei.ethiopia.maplib.model.AddressInfo;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import t5.c;
import t5.d;

public class MapLocationFragment extends BaseFragment implements OnMapReadyCallback, Runnable {
    public FragmentMapLocationBinding c;
    public FusedLocationProviderClient d;
    public Marker e;
    public LatLng f;
    public int g = 0;
    public GoogleMap h;
    public final LatLng i = new LatLng(28.22779569381056d, 112.93827630579472d);
    public AddressInfo j;

    public class a implements GoogleMap.OnMarkerDragListener {
        public a() {
        }

        public final void onMarkerDrag(@NonNull Marker marker) {
        }

        public final void onMarkerDragEnd(@NonNull Marker marker) {
            LatLng position = marker.getPosition();
            MapLocationFragment mapLocationFragment = MapLocationFragment.this;
            mapLocationFragment.f = position;
            mapLocationFragment.h.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 15.0f));
            mapLocationFragment.A0();
        }

        public final void onMarkerDragStart(@NonNull Marker marker) {
        }
    }

    public static void y0(MapLocationFragment mapLocationFragment) {
        if (mapLocationFragment.h != null) {
            try {
                if (q.c(new String[]{"android.permission.ACCESS_FINE_LOCATION"})) {
                    mapLocationFragment.h.setMyLocationEnabled(true);
                } else {
                    mapLocationFragment.h.setMyLocationEnabled(false);
                }
                mapLocationFragment.h.getUiSettings().setMyLocationButtonEnabled(false);
            } catch (SecurityException e2) {
                e2.getMessage();
                h.b();
            }
        }
    }

    public final void A0() {
        String str;
        String str2;
        this.c.e.setText(String.format(Locale.ENGLISH, "%.6f,%.6f", new Object[]{Double.valueOf(this.f.latitude), Double.valueOf(this.f.longitude)}));
        Geocoder geocoder = new Geocoder(requireContext(), Locale.getDefault());
        try {
            LatLng latLng = this.f;
            List<Address> fromLocation = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
            if (!fromLocation.isEmpty()) {
                Address address = fromLocation.get(0);
                TextView textView = this.c.f;
                if (address.getMaxAddressLineIndex() > 1) {
                    str = address.getAddressLine(1);
                } else {
                    str = address.getAddressLine(0);
                }
                textView.setText(str);
                AddressInfo addressInfo = new AddressInfo();
                this.j = addressInfo;
                addressInfo.setLatLng(this.f);
                AddressInfo addressInfo2 = this.j;
                if (address.getMaxAddressLineIndex() > 1) {
                    str2 = address.getAddressLine(1);
                } else {
                    str2 = address.getAddressLine(0);
                }
                addressInfo2.setFullText(str2);
            }
        } catch (IOException e2) {
            e2.getMessage();
            h.b();
        }
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        MapLocationFragment.super.onActivityResult(i2, i3, intent);
        if (i2 == 1001 && i3 == -1 && intent != null) {
            AddressInfo addressInfo = (AddressInfo) intent.getParcelableExtra("addressInfo");
            this.j = addressInfo;
            LatLng latLng = addressInfo.getLatLng();
            this.f = latLng;
            AddressInfo addressInfo2 = this.j;
            this.c.e.setText(String.format(Locale.ENGLISH, "%.6f,%.6f", new Object[]{Double.valueOf(latLng.latitude), Double.valueOf(this.f.longitude)}));
            this.c.f.setText(addressInfo2.getFullText());
            Marker marker = this.e;
            if (marker != null) {
                marker.setPosition(this.f);
            }
            this.h.animateCamera(CameraUpdateFactory.newLatLngZoom(this.f, 15.0f));
        }
    }

    public final void onDestroy() {
        MapLocationFragment.super.onDestroy();
        A.a.removeCallbacks(this);
    }

    public final void onMapReady(@NonNull GoogleMap googleMap) {
        this.h = googleMap;
        q e2 = q.e(new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"});
        e2.c = new c(this);
        e2.f();
        this.h.setOnMarkerDragListener(new a());
        this.h.setOnMapClickListener(new F3.c(this));
    }

    public final void run() {
        q e2 = q.e(new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"});
        e2.c = new c(this);
        e2.f();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0035, code lost:
        r0 = com.huawei.ethiopia.maplib.R$id.lb_next;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x004a, code lost:
        r0 = com.huawei.ethiopia.maplib.R$id.rl_address_value;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.viewbinding.ViewBinding v0(android.view.LayoutInflater r10) {
        /*
            r9 = this;
            com.huawei.ethiopia.maplib.databinding.FragmentMapLocationBinding r0 = r9.c
            if (r0 != 0) goto L_0x0095
            int r0 = com.huawei.ethiopia.maplib.R$layout.fragment_map_location
            r1 = 0
            r2 = 0
            android.view.View r10 = r10.inflate(r0, r2, r1)
            int r0 = com.huawei.ethiopia.maplib.R$id.fl_map_container
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            android.widget.FrameLayout r1 = (android.widget.FrameLayout) r1
            if (r1 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.iv_google_map_location
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r4 = r1
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            if (r4 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.iv_map_location
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            if (r1 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.iv_turn_right
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            if (r1 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.lb_next
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r5 = r1
            com.huawei.common.widget.LoadingButton r5 = (com.huawei.common.widget.LoadingButton) r5
            if (r5 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.line
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            com.huawei.common.widget.round.RoundTextView r1 = (com.huawei.common.widget.round.RoundTextView) r1
            if (r1 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.rl_address_value
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r6 = r1
            com.huawei.common.widget.round.RoundConstraintLayout r6 = (com.huawei.common.widget.round.RoundConstraintLayout) r6
            if (r6 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.rl_confirm_container
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            com.huawei.common.widget.round.RoundConstraintLayout r1 = (com.huawei.common.widget.round.RoundConstraintLayout) r1
            if (r1 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.tv_lati_long_value
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r7 = r1
            android.widget.TextView r7 = (android.widget.TextView) r7
            if (r7 == 0) goto L_0x0081
            int r0 = com.huawei.ethiopia.maplib.R$id.tv_location_address
            android.view.View r1 = androidx.viewbinding.ViewBindings.findChildViewById(r10, r0)
            r8 = r1
            android.widget.TextView r8 = (android.widget.TextView) r8
            if (r8 == 0) goto L_0x0081
            com.huawei.ethiopia.maplib.databinding.FragmentMapLocationBinding r0 = new com.huawei.ethiopia.maplib.databinding.FragmentMapLocationBinding
            r3 = r10
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            r2 = r0
            r2.<init>(r3, r4, r5, r6, r7, r8)
            r9.c = r0
            goto L_0x0095
        L_0x0081:
            android.content.res.Resources r10 = r10.getResources()
            java.lang.String r10 = r10.getResourceName(r0)
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "Missing required view with ID: "
            java.lang.String r10 = r1.concat(r10)
            r0.<init>(r10)
            throw r0
        L_0x0095:
            com.huawei.ethiopia.maplib.databinding.FragmentMapLocationBinding r10 = r9.c
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.ethiopia.maplib.register.MapLocationFragment.v0(android.view.LayoutInflater):androidx.viewbinding.ViewBinding");
    }

    public final void w0() {
    }

    public final void x0(View view) {
        SupportMapFragment newInstance = SupportMapFragment.newInstance();
        getChildFragmentManager().beginTransaction().add(R$id.fl_map_container, newInstance).commit();
        newInstance.getMapAsync(this);
        this.d = LocationServices.getFusedLocationProviderClient(requireActivity());
        this.c.d.setOnClickListener(new J6.c(this, 6));
        this.c.c.setOnClickListener(new F3.a(this, 10));
        this.c.b.setOnClickListener(new m(this, 7));
    }

    public final void z0() {
        try {
            this.d.getLastLocation().addOnCompleteListener(requireActivity(), new d(this));
        } catch (SecurityException e2) {
            e2.getMessage();
        }
        this.g++;
    }
}
