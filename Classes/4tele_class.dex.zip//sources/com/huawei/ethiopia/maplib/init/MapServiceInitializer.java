package com.huawei.ethiopia.maplib.init;

import T4.b;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.startup.Initializer;
import java.util.ArrayList;
import java.util.List;

public class MapServiceInitializer implements Initializer<b> {
    /* JADX WARNING: type inference failed for: r0v0, types: [T4.a, java.lang.Object] */
    @NonNull
    public final Object create(@NonNull Context context) {
        b bVar = b.a.a;
        bVar.a = new Object();
        return bVar;
    }

    @NonNull
    public final List<Class<? extends Initializer<?>>> dependencies() {
        return new ArrayList();
    }
}
