package com.huawei.ethiopia.maplib.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class ActivityRegisterMapLocationBinding extends ViewDataBinding {
}
