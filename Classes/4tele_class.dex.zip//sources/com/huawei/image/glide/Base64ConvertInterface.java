package com.huawei.image.glide;

import com.alibaba.android.arouter.facade.template.IProvider;

public interface Base64ConvertInterface extends IProvider {
    String docIdToBase64(Base64Mode base64Mode);

    void onCancel();
}
