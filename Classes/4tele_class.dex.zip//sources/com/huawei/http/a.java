package com.huawei.http;

import com.google.gson.JsonObject;
import ic.o;
import ic.s;
import java.util.Map;
import x9.h;

public interface a {
    @o("{path}")
    h<JsonObject> fetchData(@s(encoded = true, value = "path") String str, @ic.a Map<String, Object> map);
}
