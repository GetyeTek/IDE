package com.huawei.http;

import V1.h;
import androidx.annotation.UiThread;
import com.blankj.utilcode.util.A;
import com.blankj.utilcode.util.k;
import com.blankj.utilcode.util.s;
import com.google.gson.JsonObject;
import com.huawei.astp.macle.ui.e;
import com.huawei.common.exception.BaseException;
import io.reactivex.rxjava3.internal.operators.observable.d;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import x9.j;

public abstract class b<Response, TransferResponse> {
    private static boolean DEBUG = false;
    private static final a SERVICE = ((a) e.c(RetrofitProviderService.class).providerRetrofit().b(a.class));
    public static final String SP_NAME = "sp_api_cache";
    protected final String TAG = getClass().getSimpleName();
    private R1.a<TransferResponse> callback;
    private boolean finished;
    private final Map<String, Object> params = new HashMap();
    private Type responseClass;
    private D9.a<TransferResponse> subscribe;
    private Type transferResponseClass;

    public class a extends A.b<TransferResponse> {
        public final /* synthetic */ R1.a d;

        public a(R1.a aVar) {
            this.d = aVar;
        }

        public final TransferResponse a() {
            return b.this.loadFromLocal();
        }

        public final void f(TransferResponse transferresponse) {
            b bVar = b.this;
            Objects.toString(transferresponse);
            h.b();
            R1.a aVar = this.d;
            if (!(transferresponse == null || aVar == null)) {
                aVar.onSuccess(transferresponse);
            }
            if (bVar.shouldFetch(transferresponse)) {
                bVar.fetchFromRemote();
            } else if (aVar != null) {
                aVar.onComplete();
            }
        }
    }

    /* renamed from: com.huawei.http.b$b  reason: collision with other inner class name */
    public class C0007b extends D9.a<TransferResponse> {
        public C0007b() {
        }

        public final void onComplete() {
            b.this.onComplete();
        }

        public final void onError(Throwable th) {
            b.this.onError(th);
        }

        public final void onNext(TransferResponse transferresponse) {
            b.this.onNext(transferresponse);
        }
    }

    public b() {
        initGenericClass();
    }

    public static void clearApiCache(String str) {
        s.a(SP_NAME).d(str);
    }

    /* access modifiers changed from: private */
    public void fetchFromRemote() {
        h.b();
        x9.h b = sendRequestInner().b(io_main());
        C0007b bVar = new C0007b();
        b.a(bVar);
        this.subscribe = bVar;
    }

    private Response getMockResponse() {
        if (!DEBUG) {
            return null;
        }
        try {
            String apiPath = getApiPath();
            return k.b(V1.b.b("mock/" + apiPath + ".json"), this.responseClass);
        } catch (Exception e) {
            e.getMessage();
            h.b();
            return null;
        }
    }

    private void initGenericClass() {
        Type[] actualTypeArguments = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments();
        if (actualTypeArguments.length == 2) {
            this.responseClass = actualTypeArguments[0];
            this.transferResponseClass = actualTypeArguments[1];
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [x9.k<T, T>, java.lang.Object] */
    private static <T> x9.k<T, T> io_main() {
        return new Object();
    }

    /* access modifiers changed from: private */
    public static j lambda$io_main$3(x9.h hVar) {
        return hVar.g(F9.a.b).e(w9.b.a());
    }

    /* access modifiers changed from: private */
    public /* synthetic */ j lambda$sendRequestInner$1(JsonObject jsonObject) throws Throwable {
        return x9.h.d(k.b(jsonObject.toString(), this.responseClass));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ j lambda$sendRequestInner$2(Object obj) throws Throwable {
        Object convert = convert(obj);
        saveToLocal(convert);
        return x9.h.d(convert);
    }

    private x9.h<TransferResponse> sendRequestInner() {
        return getService().fetchData(getApiPath(), this.params).c(new androidx.camera.view.e(this)).c(new com.google.android.material.navigation.b(this));
    }

    public static void setDEBUG(boolean z) {
        DEBUG = z;
    }

    public void addParams(String str, Object obj) {
        if (!isEmpty(str)) {
            this.params.put(str, obj);
        }
    }

    public void cancel() {
        D9.a<TransferResponse> aVar = this.subscribe;
        if (aVar != null && !aVar.isDisposed()) {
            this.subscribe.dispose();
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [Response, TransferResponse] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public TransferResponse convert(Response r3) {
        /*
            r2 = this;
            java.lang.reflect.Type r0 = r2.responseClass
            java.lang.reflect.Type r1 = r2.transferResponseClass
            if (r0 != r1) goto L_0x0007
            return r3
        L_0x0007:
            r3 = 0
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.http.b.convert(java.lang.Object):java.lang.Object");
    }

    public String getApiKey() {
        return getApiPath();
    }

    public abstract String getApiPath();

    public a getService() {
        return SERVICE;
    }

    public boolean isCache() {
        return false;
    }

    public boolean isEmpty(Object obj) {
        if (obj == null) {
            return true;
        }
        if (!(obj instanceof String) || ((String) obj).length() != 0) {
            return false;
        }
        return true;
    }

    @UiThread
    public TransferResponse loadFromLocal() {
        if (!isCache()) {
            return null;
        }
        try {
            return k.b(s.a(SP_NAME).b(getApiKey()), this.transferResponseClass);
        } catch (Exception e) {
            e.getMessage();
            h.b();
            return null;
        }
    }

    public void onComplete() {
        h.b();
        this.finished = true;
        R1.a<TransferResponse> aVar = this.callback;
        if (aVar != null) {
            aVar.onComplete();
        }
    }

    public void onError(Throwable th) {
        BaseException baseException;
        th.getMessage();
        h.b();
        Object mockResponse = getMockResponse();
        if (mockResponse != null) {
            V1.k.b(1, getApiPath() + " api is Mock data");
            Object convert = convert(mockResponse);
            saveToLocal(convert);
            R1.a<TransferResponse> aVar = this.callback;
            if (aVar != null) {
                aVar.onSuccess(convert);
                return;
            }
            return;
        }
        if (th instanceof BaseException) {
            baseException = (BaseException) th;
        } else {
            baseException = new BaseException(th.getMessage());
        }
        R1.a<TransferResponse> aVar2 = this.callback;
        if (aVar2 != null) {
            aVar2.onError(baseException);
        }
    }

    public void onNext(TransferResponse transferresponse) {
        h.b();
        R1.a<TransferResponse> aVar = this.callback;
        if (aVar != null) {
            aVar.onSuccess(transferresponse);
        }
    }

    @UiThread
    public void saveToLocal(TransferResponse transferresponse) {
        if (isCache() && transferresponse != null) {
            s.a(SP_NAME).c(getApiKey(), k.d(transferresponse));
        }
    }

    public y9.b sendRequest(R1.a<TransferResponse> aVar) {
        this.callback = aVar;
        A.b(A.f(-2, 10), new a(aVar), 0, (TimeUnit) null);
        return this.subscribe;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.google.android.gms.internal.measurement.b, java.lang.Object] */
    public TransferResponse sendSyncRequest() {
        x9.h sendRequestInner = sendRequestInner();
        ? obj = new Object();
        sendRequestInner.getClass();
        d dVar = new d(sendRequestInner, obj);
        CountDownLatch countDownLatch = new CountDownLatch(1);
        dVar.a(countDownLatch);
        if (countDownLatch.getCount() != 0) {
            try {
                countDownLatch.await();
            } catch (InterruptedException e) {
                countDownLatch.dispose();
                throw io.reactivex.rxjava3.internal.util.a.b(e);
            }
        }
        Throwable th = countDownLatch.b;
        if (th == null) {
            TransferResponse transferresponse = countDownLatch.a;
            if (transferresponse != null) {
                return transferresponse;
            }
            throw new NoSuchElementException();
        }
        throw io.reactivex.rxjava3.internal.util.a.b(th);
    }

    public boolean shouldFetch(TransferResponse transferresponse) {
        return true;
    }

    public void addParams(Map<String, Object> map) {
        if (map != null && !map.isEmpty()) {
            this.params.putAll(map);
        }
    }

    public void clearApiCache() {
        clearApiCache(getApiKey());
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void lambda$sendSyncRequest$0(Throwable th) throws Throwable {
        throw th;
    }
}
