package com.huawei.http;

import com.alibaba.android.arouter.facade.template.IProvider;
import fc.B;

public interface RetrofitProviderService extends IProvider {
    B providerRetrofit();
}
