package X5;

import com.google.gson.Gson;
import com.huawei.customer.digitalpayment.miniapp.macle.MacleDispatcherActivity;
import com.huawei.customer.digitalpayment.miniapp.macle.maclemanager.entity.MacleAppInfo;
import com.huawei.kbz.chat.contact.view_model.ChatHistorySearchViewModel;
import com.shinemo.chat.CYCallback;
import fc.A;
import fc.d;
import java.util.List;
import okhttp3.ResponseBody;
import org.json.JSONObject;

public final class b implements CYCallback, d {
    public final /* synthetic */ Object a;

    public /* synthetic */ b(Object obj) {
        this.a = obj;
    }

    public void a(fc.b bVar, A a2) {
        MacleDispatcherActivity.a aVar = (MacleDispatcherActivity.a) this.a;
        Object obj = a2.b;
        if (obj != null) {
            try {
                aVar.b((MacleAppInfo) new Gson().fromJson(new JSONObject(((ResponseBody) obj).string()).optJSONObject("data").toString(), MacleAppInfo.class));
            } catch (Exception unused) {
                aVar.a((String) null);
            }
        }
    }

    public void b(fc.b bVar, Throwable th) {
        ((MacleDispatcherActivity.a) this.a).a(th.toString());
    }

    public void onSuccess(Object obj) {
        ChatHistorySearchViewModel.a((ChatHistorySearchViewModel) this.a, (List) obj);
    }

    public void onFail(int i, String str) {
    }
}
