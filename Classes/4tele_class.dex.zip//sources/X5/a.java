package X5;

import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.homev6.search.SearchActivity;
import com.huawei.digitalpayment.customer.login_module.resetpin.ResetPinOtpActivity;
import com.huawei.kbz.chat.contact.view_model.ChatHistorySearchViewModel;
import com.shinemo.chat.CYCallback;
import java.util.List;

public final class a implements CYCallback, R1.a {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public void a() {
        SearchActivity searchActivity = (SearchActivity) this.b;
        if (searchActivity.i.size() > 10) {
            List list = searchActivity.i;
            searchActivity.i = list.subList(list.size() - 10, searchActivity.i.size());
        }
    }

    public /* synthetic */ void onComplete() {
    }

    public /* synthetic */ void onError(BaseException baseException) {
    }

    public /* synthetic */ void onLoading(Object obj) {
    }

    public void onSuccess(Object obj) {
        switch (this.a) {
            case 0:
                ChatHistorySearchViewModel.a((ChatHistorySearchViewModel) this.b, (List) obj);
                return;
            default:
                ResetPinOtpActivity resetPinOtpActivity = (ResetPinOtpActivity) this.b;
                resetPinOtpActivity.j.c.getEditText().setText((String) obj);
                resetPinOtpActivity.j.e.performClick();
                return;
        }
    }

    public void onFail(int i, String str) {
    }
}
