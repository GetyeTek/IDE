package o5;

import R1.a;
import V7.c;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.saving.viewmodel.ActiveSavingViewModel;
import com.huawei.http.BaseResp;

/* renamed from: o5.a  reason: case insensitive filesystem */
public final class C0104a implements a<BaseResp> {
    public final /* synthetic */ ActiveSavingViewModel a;

    public C0104a(ActiveSavingViewModel activeSavingViewModel) {
        this.a = activeSavingViewModel;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final void onError(BaseException baseException) {
        this.a.b.setValue(c.a(baseException));
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        this.a.b.setValue(c.e((BaseResp) obj));
    }
}
