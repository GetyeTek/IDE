package o5;

import R1.a;
import V7.c;
import android.text.TextUtils;
import com.huawei.common.exception.BaseException;
import com.huawei.ethiopia.finance.resp.FinanceProductInfo;
import com.huawei.ethiopia.finance.resp.FinanceProductListResp;
import com.huawei.ethiopia.finance.saving.viewmodel.LockedSavingProductDetailViewModel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class b implements a<FinanceProductListResp> {
    public final /* synthetic */ String a;
    public final /* synthetic */ LockedSavingProductDetailViewModel b;

    public b(LockedSavingProductDetailViewModel lockedSavingProductDetailViewModel, String str) {
        this.b = lockedSavingProductDetailViewModel;
        this.a = str;
    }

    public final /* synthetic */ void onComplete() {
    }

    public final void onError(BaseException baseException) {
        this.b.a.setValue(c.a(baseException));
    }

    public final /* synthetic */ void onLoading(Object obj) {
    }

    public final void onSuccess(Object obj) {
        FinanceProductListResp financeProductListResp = (FinanceProductListResp) obj;
        LockedSavingProductDetailViewModel lockedSavingProductDetailViewModel = this.b;
        if (financeProductListResp == null) {
            lockedSavingProductDetailViewModel.a.setValue(c.e(Collections.emptyList()));
            return;
        }
        List<FinanceProductInfo> productList = financeProductListResp.getProductList();
        lockedSavingProductDetailViewModel.getClass();
        ArrayList arrayList = new ArrayList();
        for (FinanceProductInfo next : productList) {
            if (TextUtils.equals(this.a, next.getProductId())) {
                arrayList.add(next);
            }
        }
        lockedSavingProductDetailViewModel.a.setValue(c.e(arrayList));
    }
}
