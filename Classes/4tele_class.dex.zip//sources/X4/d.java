package X4;

import V7.c;
import Y4.g;
import android.view.View;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanProductAdapter;
import com.huawei.ethiopia.finance.loan.fragment.ApplyLoanFragment;
import com.huawei.ethiopia.finance.loan.repository.QueryProductDetailRepository;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import w5.C0112a;

public final /* synthetic */ class d implements View.OnClickListener {
    public final /* synthetic */ FinanceLoanProductAdapter a;
    public final /* synthetic */ ProductInfo b;

    public /* synthetic */ d(FinanceLoanProductAdapter financeLoanProductAdapter, ProductInfo productInfo) {
        this.a = financeLoanProductAdapter;
        this.b = productInfo;
    }

    public final void onClick(View view) {
        g gVar = this.a.b;
        if (gVar != null) {
            ProductInfo productInfo = this.b;
            ApplyLoanFragment applyLoanFragment = (ApplyLoanFragment) gVar.a;
            FinanceApplyLoanViewModel financeApplyLoanViewModel = applyLoanFragment.a;
            financeApplyLoanViewModel.e.setValue(c.c());
            new QueryProductDetailRepository(productInfo.getProductId()).sendRequest(new a5.c(financeApplyLoanViewModel, productInfo));
            String c = p5.g.c(applyLoanFragment.j);
            C0112a.a("mela_" + c + "_productID_apply_v1");
        }
    }
}
