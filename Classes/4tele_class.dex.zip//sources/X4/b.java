package X4;

import Y4.e;
import android.view.View;
import androidx.camera.core.ImageProcessor;
import androidx.camera.core.processing.InternalImageProcessor;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemChildClickListener;
import com.google.android.gms.common.util.CollectionUtils;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.loan.activity.d;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanContractsAdapter;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanProductAdapter;
import com.huawei.ethiopia.finance.loan.fragment.ApplyLoanFragment;
import com.huawei.ethiopia.finance.loan.repository.RolloverPreValidationRepository;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel;
import com.huawei.ethiopia.finance.resp.AppRepaymentSchedule;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import com.huawei.facerecognition.FaceManager;
import f2.c;
import p5.g;

public final /* synthetic */ class b implements OnItemChildClickListener, CallbackToFutureAdapter.Resolver {
    public final /* synthetic */ Object a;
    public final /* synthetic */ Object b;

    public /* synthetic */ b(Object obj, Object obj2) {
        this.a = obj;
        this.b = obj2;
    }

    public Object attachCompleter(CallbackToFutureAdapter.Completer completer) {
        return InternalImageProcessor.a((InternalImageProcessor) this.a, (ImageProcessor.Request) this.b, completer);
    }

    public void onItemChildClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        String str;
        int i2 = FinanceLoanProductAdapter.i;
        FinanceLoanProductAdapter financeLoanProductAdapter = (FinanceLoanProductAdapter) this.a;
        int id = view.getId();
        int i3 = R$id.btn_repay;
        FinanceLoanContractsAdapter financeLoanContractsAdapter = (FinanceLoanContractsAdapter) this.b;
        if (id == i3) {
            LoanContractsInfo loanContractsInfo = (LoanContractsInfo) financeLoanContractsAdapter.getData().get(i);
            e eVar = financeLoanProductAdapter.e;
            if (eVar != null) {
                ApplyLoanFragment applyLoanFragment = (ApplyLoanFragment) eVar.a;
                ReportViewModel reportViewModel = c.b;
                c.a.a.c("click_Lv2FinancePg_Lv2Prod_repay", new String[]{applyLoanFragment.j, loanContractsInfo.getProductId(), loanContractsInfo.getProductName()});
                g.p(applyLoanFragment.requireActivity(), loanContractsInfo.getContractId(), loanContractsInfo, FaceManager.FACE_ERROR_VENDOR_BASE, applyLoanFragment.j);
            }
        }
        if (view.getId() == R$id.btn_extend) {
            LoanContractsInfo loanContractsInfo2 = (LoanContractsInfo) financeLoanContractsAdapter.getData().get(i);
            e eVar2 = financeLoanProductAdapter.f;
            if (eVar2 != null) {
                ApplyLoanFragment applyLoanFragment2 = (ApplyLoanFragment) eVar2.a;
                if (loanContractsInfo2 != null && !CollectionUtils.isEmpty(loanContractsInfo2.getRepaymentSchedules())) {
                    if (applyLoanFragment2.getActivity() instanceof d) {
                        str = applyLoanFragment2.getActivity().i();
                    } else {
                        str = null;
                    }
                    String str2 = str;
                    AppRepaymentSchedule appRepaymentSchedule = loanContractsInfo2.getRepaymentSchedules().get(0);
                    if (appRepaymentSchedule == null) {
                        return;
                    }
                    if (loanContractsInfo2.isAllowRollover()) {
                        FinanceApplyLoanViewModel financeApplyLoanViewModel = applyLoanFragment2.a;
                        String contractId = loanContractsInfo2.getContractId();
                        String statementId = appRepaymentSchedule.getStatementId();
                        String productNameI18n = loanContractsInfo2.getProductNameI18n();
                        financeApplyLoanViewModel.f.setValue(V7.c.c());
                        new RolloverPreValidationRepository(contractId, statementId).sendRequest(new a5.d(financeApplyLoanViewModel, contractId, statementId, str2, productNameI18n));
                    } else if (loanContractsInfo2.isAllowIntall()) {
                        FinanceApplyLoanViewModel financeApplyLoanViewModel2 = applyLoanFragment2.a;
                        String contractId2 = loanContractsInfo2.getContractId();
                        String productNameI18n2 = loanContractsInfo2.getProductNameI18n();
                        financeApplyLoanViewModel2.g.setValue(V7.c.c());
                        com.huawei.http.b bVar = new com.huawei.http.b();
                        bVar.addParams("contractID", contractId2);
                        bVar.sendRequest(new a5.e(financeApplyLoanViewModel2, contractId2, str2, productNameI18n2));
                    }
                }
            }
        }
    }
}
