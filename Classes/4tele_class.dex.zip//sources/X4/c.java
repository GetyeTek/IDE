package X4;

import Y4.f;
import a5.b;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.t;
import com.blankj.utilcode.util.v;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.ethiopia.finance.R$layout;
import com.huawei.ethiopia.finance.R$string;
import com.huawei.ethiopia.finance.databinding.FinanceItemLoanProductBinding;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanProductAdapter;
import com.huawei.ethiopia.finance.loan.fragment.ApplyLoanFragment;
import com.huawei.ethiopia.finance.loan.repository.QueryProductDetailRepository;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceApplyLoanViewModel;
import com.huawei.ethiopia.finance.resp.ProductInfo;
import w5.C0112a;

public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ FinanceLoanProductAdapter a;
    public final /* synthetic */ ProductInfo b;
    public final /* synthetic */ int c;
    public final /* synthetic */ FinanceItemLoanProductBinding d;

    public /* synthetic */ c(FinanceLoanProductAdapter financeLoanProductAdapter, ProductInfo productInfo, int i, FinanceItemLoanProductBinding financeItemLoanProductBinding) {
        this.a = financeLoanProductAdapter;
        this.b = productInfo;
        this.c = i;
        this.d = financeItemLoanProductBinding;
    }

    public final void onClick(View view) {
        int i = FinanceLoanProductAdapter.i;
        FinanceLoanProductAdapter financeLoanProductAdapter = this.a;
        ProductInfo productInfo = this.b;
        boolean isShow = productInfo.isShow();
        productInfo.setShow(!isShow);
        int i2 = financeLoanProductAdapter.c;
        FinanceItemLoanProductBinding financeItemLoanProductBinding = this.d;
        if (i2 <= 0) {
            ViewGroup viewGroup = (ViewGroup) financeItemLoanProductBinding.getRoot();
            View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R$layout.finance_item_loan_product_detail, viewGroup, false);
            inflate.measure(View.MeasureSpec.makeMeasureSpec(viewGroup.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(t.a(), Integer.MIN_VALUE));
            inflate.layout(0, 0, viewGroup.getWidth(), t.a());
            financeLoanProductAdapter.c = inflate.getMeasuredHeight();
        }
        boolean isShow2 = productInfo.isShow();
        RoundRecyclerView roundRecyclerView = financeItemLoanProductBinding.f;
        HorizontalScrollView horizontalScrollView = financeItemLoanProductBinding.b;
        ImageView imageView = financeItemLoanProductBinding.d;
        TextView textView = financeItemLoanProductBinding.q;
        int i3 = this.c;
        if (isShow2) {
            textView.setText(J.a().getString(R$string.less));
            p5.c.b(imageView, 180.0f);
            p5.c.a(financeLoanProductAdapter.c, horizontalScrollView);
            p5.c.a(v.a(62.0f) * i3, roundRecyclerView);
        } else {
            textView.setText(J.a().getString(R$string.more));
            p5.c.b(imageView, 0.0f);
            p5.c.a(1, horizontalScrollView);
            p5.c.a(v.a(62.0f) * Math.min(2, i3), roundRecyclerView);
        }
        f fVar = financeLoanProductAdapter.a;
        if (fVar != null && !isShow) {
            ApplyLoanFragment applyLoanFragment = (ApplyLoanFragment) fVar.a;
            String str = applyLoanFragment.j;
            C0112a.a("mela_" + str + "_productID_more_v1");
            if (productInfo.getProductDetailInfo() == null) {
                FinanceApplyLoanViewModel financeApplyLoanViewModel = applyLoanFragment.a;
                financeApplyLoanViewModel.getClass();
                new QueryProductDetailRepository(productInfo.getProductId()).sendRequest(new b(financeApplyLoanViewModel, productInfo));
            }
        }
    }
}
