package X4;

import Y4.q;
import a5.h;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemChildClickListener;
import com.google.android.gms.common.util.CollectionUtils;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.ethiopia.finance.R$id;
import com.huawei.ethiopia.finance.loan.activity.d;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanContactsAdapter;
import com.huawei.ethiopia.finance.loan.adapter.FinanceLoanGroupAdapter;
import com.huawei.ethiopia.finance.loan.fragment.LoanContractsFragment;
import com.huawei.ethiopia.finance.loan.repository.RolloverPreValidationRepository;
import com.huawei.ethiopia.finance.loan.viewmodel.FinanceMyTelebirrTelaViewModel;
import com.huawei.ethiopia.finance.resp.AppRepaymentSchedule;
import com.huawei.ethiopia.finance.resp.LoanContractsInfo;
import f2.c;
import java.util.Map;
import o0.b;
import p5.g;

public final /* synthetic */ class a implements OnItemChildClickListener {
    public final /* synthetic */ FinanceLoanGroupAdapter a;
    public final /* synthetic */ FinanceLoanContactsAdapter b;

    public /* synthetic */ a(FinanceLoanGroupAdapter financeLoanGroupAdapter, FinanceLoanContactsAdapter financeLoanContactsAdapter) {
        this.a = financeLoanGroupAdapter;
        this.b = financeLoanContactsAdapter;
    }

    public final void onItemChildClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        String str;
        q qVar;
        int i2 = FinanceLoanGroupAdapter.d;
        FinanceLoanGroupAdapter financeLoanGroupAdapter = this.a;
        LoanContractsInfo loanContractsInfo = (LoanContractsInfo) this.b.getData().get(i);
        String contractId = loanContractsInfo.getContractId();
        int id = view.getId();
        int i3 = R$id.view;
        d dVar = financeLoanGroupAdapter.a;
        String str2 = null;
        if (id == i3 || (view.getId() == R$id.tvDate && loanContractsInfo.isActive())) {
            ReportViewModel reportViewModel = c.b;
            c.a.a.c("click_Lv3MyLoanPg_Lv2Prod_view", new String[]{financeLoanGroupAdapter.b, loanContractsInfo.getProductId(), loanContractsInfo.getProductName()});
            Bundle bundle = new Bundle(4);
            bundle.putSerializable("contractsInfo", loanContractsInfo);
            bundle.putString("bankCode", financeLoanGroupAdapter.b);
            if (dVar instanceof d) {
                str = dVar.i();
            } else {
                str = null;
            }
            bundle.putString("bankIcon", str);
            b.d((Activity) null, "/finance/loanContractDetail", bundle, (Map) null);
        } else if (view.getId() == R$id.btn_repay) {
            ReportViewModel reportViewModel2 = c.b;
            c.a.a.c("click_Lv3MyLoanPg_Lv2Product_repay", new String[]{financeLoanGroupAdapter.b, loanContractsInfo.getProductId(), loanContractsInfo.getProductName()});
            g.p(dVar, contractId, loanContractsInfo, 1111, financeLoanGroupAdapter.b);
        } else if (view.getId() == R$id.btn_extend && (qVar = financeLoanGroupAdapter.c) != null) {
            LoanContractsFragment loanContractsFragment = (LoanContractsFragment) qVar.a;
            if (!CollectionUtils.isEmpty(loanContractsInfo.getRepaymentSchedules())) {
                if (loanContractsFragment.getActivity() instanceof d) {
                    str2 = loanContractsFragment.getActivity().i();
                }
                String str3 = str2;
                AppRepaymentSchedule appRepaymentSchedule = loanContractsInfo.getRepaymentSchedules().get(0);
                if (appRepaymentSchedule != null) {
                    FinanceMyTelebirrTelaViewModel financeMyTelebirrTelaViewModel = loanContractsFragment.d;
                    String contractId2 = loanContractsInfo.getContractId();
                    String statementId = appRepaymentSchedule.getStatementId();
                    String productNameI18n = loanContractsInfo.getProductNameI18n();
                    financeMyTelebirrTelaViewModel.c.setValue(V7.c.c());
                    new RolloverPreValidationRepository(contractId2, statementId).sendRequest(new h(financeMyTelebirrTelaViewModel, contractId2, statementId, str3, productNameI18n));
                }
            }
        }
    }
}
