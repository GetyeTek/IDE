package O5;

import com.shinemo.chat.message.CYOfficialEssayVo;

public final class a {
    public String a;
    public String b;
    public String c;
    public String d;

    public a(CYOfficialEssayVo cYOfficialEssayVo, String str) {
        this.a = cYOfficialEssayVo.getTitle();
        this.b = str;
        this.c = cYOfficialEssayVo.getOpenUrl();
        this.d = cYOfficialEssayVo.getIntroduction();
    }
}
