package a6;

import a6.C0025b;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.blankj.utilcode.util.v;
import com.huawei.kbz.chat.R$drawable;
import java.util.ArrayList;

/* renamed from: a6.a  reason: case insensitive filesystem */
public final class C0024a extends BaseAdapter {
    public final Context a;
    public final int b;
    public final float c;
    public final float d;

    public C0024a(Context context, int i, int i2, int i3) {
        this.a = context;
        this.b = i3;
        float a2 = (((float) (i2 - v.a(111.0f))) * 1.0f) / 3.0f;
        this.c = a2;
        this.d = Math.min(((((float) i) * 1.0f) / 7.0f) * 0.6f, a2 * 0.6f);
    }

    public final int getCount() {
        return Math.min((C0025b.a.size() - this.b) + 1, 21);
    }

    public final Object getItem(int i) {
        return null;
    }

    public final long getItemId(int i) {
        return (long) (this.b + i);
    }

    public final View getView(int i, View view, ViewGroup viewGroup) {
        String str;
        Context context = this.a;
        RelativeLayout relativeLayout = new RelativeLayout(context);
        relativeLayout.setLayoutParams(new AbsListView.LayoutParams(-1, (int) this.c));
        ImageView imageView = new ImageView(context);
        ArrayList arrayList = C0025b.a;
        int size = arrayList.size();
        int i2 = this.b + i;
        if (i == 20 || i2 == size) {
            imageView.setBackgroundResource(R$drawable.ic_emoji_del);
        } else if (i2 < size) {
            BitmapDrawable bitmapDrawable = null;
            if (i2 < 0 || i2 >= arrayList.size()) {
                str = null;
            } else {
                str = ((C0025b.C0005b) arrayList.get(i2)).a;
            }
            if (!TextUtils.isEmpty(str)) {
                bitmapDrawable = C0025b.a(context, Integer.decode(str).intValue());
            }
            imageView.setBackground(bitmapDrawable);
        }
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(14);
        int i3 = (int) this.d;
        layoutParams.width = i3;
        layoutParams.height = i3;
        imageView.setLayoutParams(layoutParams);
        relativeLayout.setGravity(17);
        relativeLayout.addView(imageView);
        return relativeLayout;
    }
}
