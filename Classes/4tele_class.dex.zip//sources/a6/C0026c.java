package a6;

import androidx.viewpager.widget.ViewPager;
import com.huawei.kbz.chat.emoji.EmotionLayout;

/* renamed from: a6.c  reason: case insensitive filesystem */
public final class C0026c implements ViewPager.OnPageChangeListener {
    public final /* synthetic */ EmotionLayout a;

    public C0026c(EmotionLayout emotionLayout) {
        this.a = emotionLayout;
    }

    public final void onPageScrolled(int i, float f, int i2) {
        this.a.setCurPageCommon(i);
    }

    public final void onPageScrollStateChanged(int i) {
    }

    public final void onPageSelected(int i) {
    }
}
