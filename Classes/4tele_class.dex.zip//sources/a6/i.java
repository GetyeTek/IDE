package a6;

public interface i {
    void a(String str);

    void b(String str);
}
