package a6;

import java.util.Objects;

public final class n {
    public final String a;
    public final String b;

    public n(String str, String str2) {
        this.a = str2;
        this.b = str;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        if (!nVar.b.equals(this.b)) {
            return false;
        }
        if (nVar.a.equals(this.a)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(new Object[]{this.a, this.b});
    }
}
