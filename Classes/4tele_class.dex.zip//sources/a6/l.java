package a6;

import android.content.Context;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.blankj.utilcode.util.v;

public final class l extends BaseAdapter {
    public final Context a;
    public final m b;
    public final int c;
    public final float d;
    public final float e;

    public class a {
        public ImageView a;
    }

    public l(Context context, m mVar, int i, int i2, int i3) {
        this.a = context;
        this.b = mVar;
        this.c = i3;
        float a2 = (((float) (i2 - v.a(111.0f))) * 1.0f) / 2.0f;
        this.d = a2;
        this.e = Math.min(((((float) i) * 1.0f) / 4.0f) * 0.8f, a2 * 0.8f);
    }

    public final int getCount() {
        return Math.min(this.b.c.size() - this.c, 8);
    }

    public final Object getItem(int i) {
        return this.b.c.get(this.c + i);
    }

    public final long getItemId(int i) {
        return (long) (this.c + i);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v6, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v1, resolved type: a6.l$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v5, resolved type: android.widget.RelativeLayout} */
    /* JADX WARNING: type inference failed for: r1v7, types: [a6.l$a, java.lang.Object] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View getView(int r4, android.view.View r5, android.view.ViewGroup r6) {
        /*
            r3 = this;
            android.content.Context r6 = r3.a
            if (r5 != 0) goto L_0x0042
            android.widget.RelativeLayout r5 = new android.widget.RelativeLayout
            r5.<init>(r6)
            android.widget.AbsListView$LayoutParams r0 = new android.widget.AbsListView$LayoutParams
            float r1 = r3.d
            int r1 = (int) r1
            r2 = -1
            r0.<init>(r2, r1)
            r5.setLayoutParams(r0)
            android.widget.ImageView r0 = new android.widget.ImageView
            r0.<init>(r6)
            int r1 = com.huawei.kbz.chat.R$drawable.ic_tab_emoji
            r0.setImageResource(r1)
            android.widget.RelativeLayout$LayoutParams r1 = new android.widget.RelativeLayout$LayoutParams
            r2 = -2
            r1.<init>(r2, r2)
            float r2 = r3.e
            int r2 = (int) r2
            r1.width = r2
            r1.height = r2
            r2 = 13
            r1.addRule(r2)
            r0.setLayoutParams(r1)
            r5.addView(r0)
            a6.l$a r1 = new a6.l$a
            r1.<init>()
            r1.a = r0
            r5.setTag(r1)
            goto L_0x0049
        L_0x0042:
            java.lang.Object r0 = r5.getTag()
            r1 = r0
            a6.l$a r1 = (a6.l.a) r1
        L_0x0049:
            int r0 = r3.c
            int r0 = r0 + r4
            a6.m r4 = r3.b
            java.util.ArrayList r2 = r4.c
            int r2 = r2.size()
            if (r0 < r2) goto L_0x0057
            return r5
        L_0x0057:
            java.util.ArrayList r4 = r4.c
            java.lang.Object r4 = r4.get(r0)
            a6.n r4 = (a6.n) r4
            if (r4 != 0) goto L_0x0062
            return r5
        L_0x0062:
            a6.p r0 = a6.p.d()
            java.lang.String r2 = r4.b
            java.lang.String r4 = r4.a
            r0.getClass()
            java.lang.String r4 = a6.p.b(r2, r4)
            java.lang.String r0 = "file://"
            java.lang.String r4 = V2.b.a(r0, r4)
            F0.a r0 = a6.j.c
            if (r0 == 0) goto L_0x0081
            android.widget.ImageView r0 = r1.a
            F0.a.a(r6, r0, r4)
            return r5
        L_0x0081:
            java.lang.RuntimeException r4 = new java.lang.RuntimeException
            java.lang.String r5 = "you should use setImageLoader() in your App onCreate()"
            r4.<init>(r5)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: a6.l.getView(int, android.view.View, android.view.ViewGroup):android.view.View");
    }
}
