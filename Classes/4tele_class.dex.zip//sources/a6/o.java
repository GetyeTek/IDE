package a6;

import java.util.Comparator;

public final /* synthetic */ class o implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return ((m) obj).b - ((m) obj2).b;
    }
}
