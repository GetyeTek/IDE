package a6;

import android.view.View;

/* renamed from: a6.d  reason: case insensitive filesystem */
public final class C0027d implements View.OnClickListener {
    public final void onClick(View view) {
    }
}
