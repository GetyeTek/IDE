package a6;

import F0.o;
import androidx.annotation.Nullable;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public final class p {
    public static volatile p c;
    public final ArrayList a = new ArrayList();
    public final HashMap b = new HashMap();

    /* JADX WARNING: type inference failed for: r0v4, types: [java.lang.Object, java.util.Comparator] */
    /* JADX WARNING: type inference failed for: r5v1, types: [a6.m, java.lang.Object] */
    public p() {
        File file = new File(j.b);
        if (file.exists()) {
            File[] listFiles = file.listFiles();
            int i = 0;
            while (true) {
                int length = listFiles.length;
                ArrayList arrayList = this.a;
                if (i < length) {
                    File file2 = listFiles[i];
                    if (file2.isDirectory()) {
                        String name = file2.getName();
                        ? obj = new Object();
                        obj.b = i;
                        obj.a = name;
                        ArrayList arrayList2 = new ArrayList();
                        File file3 = new File(j.b, name);
                        if (file3.exists()) {
                            for (File name2 : file3.listFiles()) {
                                arrayList2.add(new n(name, name2.getName()));
                            }
                        }
                        if (arrayList2.size() % 8 != 0) {
                            int size = 8 - (arrayList2.size() - ((arrayList2.size() / 8) * 8));
                            for (int i2 = 0; i2 < size; i2++) {
                                arrayList2.add(new n("", ""));
                            }
                        }
                        obj.c = arrayList2;
                        arrayList.add(obj);
                        this.b.put(name, obj);
                    }
                    i++;
                } else {
                    Collections.sort(arrayList, new Object());
                    return;
                }
            }
        }
    }

    @Nullable
    public static String b(String str, String str2) {
        m a2 = d().a(str);
        if (a2 == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(j.b);
        String str3 = File.separator;
        sb.append(str3);
        return o.a(sb, a2.a, str3, str2);
    }

    public static p d() {
        if (c == null) {
            synchronized (p.class) {
                try {
                    if (c == null) {
                        c = new p();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return c;
    }

    public final synchronized m a(String str) {
        return (m) this.b.get(str);
    }

    public final synchronized ArrayList c() {
        return this.a;
    }
}
