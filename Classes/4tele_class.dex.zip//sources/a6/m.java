package a6;

import java.io.File;
import java.util.ArrayList;

public final class m {
    public String a;
    public int b;
    public transient ArrayList c;

    public final String a() {
        File[] listFiles = new File(j.b).listFiles();
        int length = listFiles.length;
        int i = 0;
        while (i < length) {
            File file = listFiles[i];
            if (!file.isFile() || !file.getName().startsWith(this.a)) {
                i++;
            } else {
                return "file://" + file.getAbsolutePath();
            }
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof m)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        return ((m) obj).a.equals(this.a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}
