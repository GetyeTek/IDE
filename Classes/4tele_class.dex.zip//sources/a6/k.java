package a6;

import android.content.Context;
import android.text.SpannableString;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.regex.Pattern;

public final class k {
    public static final /* synthetic */ int a = 0;

    static {
        Pattern.compile("<a.*?>.*?</a>");
    }

    public static void a(Context context, View view, String str) {
        SpannableString b = b(context, str);
        if (view instanceof TextView) {
            ((TextView) view).setText(b);
        } else if (view instanceof EditText) {
            ((EditText) view).setText(b);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v5, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v14, resolved type: char} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v15, resolved type: char} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.text.SpannableString b(android.content.Context r8, java.lang.String r9) {
        /*
            boolean r0 = android.text.TextUtils.isEmpty(r9)
            if (r0 == 0) goto L_0x0008
            java.lang.String r9 = ""
        L_0x0008:
            char[] r0 = r9.toCharArray()
            android.text.SpannableStringBuilder r1 = new android.text.SpannableStringBuilder
            r1.<init>(r9)
            r9 = 0
            r2 = 0
        L_0x0013:
            int r3 = r0.length
            if (r2 >= r3) goto L_0x0081
            char r3 = r0[r2]
            boolean r3 = java.lang.Character.isHighSurrogate(r3)
            if (r3 == 0) goto L_0x001f
            goto L_0x007e
        L_0x001f:
            char r3 = r0[r2]
            boolean r3 = java.lang.Character.isLowSurrogate(r3)
            if (r3 == 0) goto L_0x003f
            if (r2 <= 0) goto L_0x007e
            int r3 = r2 + -1
            char r4 = r0[r3]
            char r5 = r0[r2]
            boolean r4 = java.lang.Character.isSurrogatePair(r4, r5)
            if (r4 == 0) goto L_0x007e
            char r3 = r0[r3]
            char r4 = r0[r2]
            int r3 = java.lang.Character.toCodePoint(r3, r4)
            r4 = 1
            goto L_0x0042
        L_0x003f:
            char r3 = r0[r2]
            r4 = 0
        L_0x0042:
            java.util.HashMap r5 = a6.C0025b.b
            java.lang.Integer r6 = java.lang.Integer.valueOf(r3)
            boolean r5 = r5.containsKey(r6)
            if (r5 == 0) goto L_0x007e
            android.graphics.drawable.BitmapDrawable r3 = a6.C0025b.a(r8, r3)
            if (r3 == 0) goto L_0x006a
            int r5 = r3.getIntrinsicWidth()
            float r5 = (float) r5
            r6 = 1058642330(0x3f19999a, float:0.6)
            float r5 = r5 * r6
            int r5 = (int) r5
            int r7 = r3.getIntrinsicHeight()
            float r7 = (float) r7
            float r7 = r7 * r6
            int r6 = (int) r7
            r3.setBounds(r9, r9, r5, r6)
        L_0x006a:
            if (r3 == 0) goto L_0x007e
            android.text.style.ImageSpan r5 = new android.text.style.ImageSpan
            r5.<init>(r3, r9)
            if (r4 == 0) goto L_0x0076
            int r3 = r2 + -1
            goto L_0x0077
        L_0x0076:
            r3 = r2
        L_0x0077:
            int r4 = r2 + 1
            r6 = 33
            r1.setSpan(r5, r3, r4, r6)
        L_0x007e:
            int r2 = r2 + 1
            goto L_0x0013
        L_0x0081:
            android.text.SpannableString r8 = android.text.SpannableString.valueOf(r1)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: a6.k.b(android.content.Context, java.lang.String):android.text.SpannableString");
    }
}
