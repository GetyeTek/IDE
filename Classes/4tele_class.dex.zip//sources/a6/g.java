package a6;

import android.graphics.drawable.Drawable;
import android.view.View;

public final class g {
    public final String a;
    public final Drawable b;
    public final View.OnClickListener c;

    public g(Drawable drawable, String str, View.OnClickListener onClickListener) {
        this.a = str;
        this.b = drawable;
        this.c = onClickListener;
    }
}
