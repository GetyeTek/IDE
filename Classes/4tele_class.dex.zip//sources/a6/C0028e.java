package a6;

import android.view.View;

/* renamed from: a6.e  reason: case insensitive filesystem */
public final class C0028e implements View.OnClickListener {
    public final void onClick(View view) {
    }
}
