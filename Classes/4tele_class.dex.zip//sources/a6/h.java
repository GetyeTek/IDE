package a6;

public interface h {
}
