package a6;

import F0.a;
import S5.f;
import V1.h;
import android.content.Context;
import android.content.res.AssetManager;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public final class j {
    public static Context a;
    public static String b;
    public static a c;

    public static void a(String str) {
        AssetManager assets = a.getResources().getAssets();
        ArrayList arrayList = new ArrayList();
        try {
            for (String str2 : assets.list(str)) {
                if (!new File(b, str2).exists()) {
                    arrayList.add(str2);
                }
            }
            if (arrayList.size() > 0) {
                new Thread(new f(arrayList, str, 1)).start();
            }
        } catch (IOException e) {
            e.getMessage();
            h.b();
        }
    }
}
