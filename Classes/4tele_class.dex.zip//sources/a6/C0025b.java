package a6;

import F0.o;
import V1.h;
import W2.l;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;
import android.util.Xml;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/* renamed from: a6.b  reason: case insensitive filesystem */
public final class C0025b {
    public static final ArrayList a = new ArrayList();
    public static final HashMap b = new HashMap();
    public static final a c = new LruCache(1024);

    /* renamed from: a6.b$a */
    public class a extends LruCache<String, Bitmap> {
        public final void entryRemoved(boolean z, Object obj, Object obj2, Object obj3) {
            String str = (String) obj;
            Bitmap bitmap = (Bitmap) obj2;
            if (bitmap != ((Bitmap) obj3)) {
                bitmap.recycle();
            }
        }
    }

    /* renamed from: a6.b$b  reason: collision with other inner class name */
    public static class C0005b {
        public final String a;
        public final String b;

        public C0005b(String str, String str2) {
            this.a = str;
            this.b = str2;
        }
    }

    /* renamed from: a6.b$c */
    public static class c extends DefaultHandler {
        public String a;

        public final void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
            if (str2.equals("Catalog")) {
                this.a = attributes.getValue(str, "Title");
            } else if (str2.equals("Emoticon")) {
                String value = attributes.getValue(str, "Tag");
                C0005b bVar = new C0005b(value, o.a(new StringBuilder("emoji/"), this.a, "/", attributes.getValue(str, "File")));
                C0025b.b.put(Integer.decode(value), bVar);
                if (this.a.equals("default")) {
                    C0025b.a.add(bVar);
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler, a6.b$c] */
    /* JADX WARNING: type inference failed for: r0v2, types: [a6.b$a, android.util.LruCache] */
    static {
        Context context = j.a;
        ? defaultHandler = new DefaultHandler();
        defaultHandler.a = "";
        InputStream inputStream = null;
        try {
            inputStream = context.getAssets().open("emoji/emoji.xml");
            Xml.parse(inputStream, Xml.Encoding.UTF_8, defaultHandler);
        } catch (IOException e) {
            e.getMessage();
            h.b();
        } catch (SAXException e2) {
            e2.getMessage();
            h.b();
        } finally {
            l.b(new Closeable[]{inputStream});
        }
        ArrayList arrayList = a;
        if (arrayList.size() % 20 != 0) {
            int size = 20 - (arrayList.size() - ((arrayList.size() / 20) * 20));
            for (int i = 0; i < size; i++) {
                arrayList.add(new C0005b("", ""));
            }
        }
        Pattern.compile("\\[[^\\[]{1,10}\\]");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v6, resolved type: java.io.Closeable[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v4, resolved type: android.graphics.Bitmap} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v8, resolved type: java.io.Closeable[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v5, resolved type: android.graphics.Bitmap} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v10, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v11, resolved type: android.graphics.Bitmap} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final android.graphics.drawable.BitmapDrawable a(android.content.Context r7, int r8) {
        /*
            r0 = 0
            r1 = 1
            java.util.HashMap r2 = b
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)
            java.lang.Object r8 = r2.get(r8)
            a6.b$b r8 = (a6.C0025b.C0005b) r8
            r2 = 0
            if (r8 == 0) goto L_0x008e
            java.lang.String r3 = r8.a
            boolean r3 = android.text.TextUtils.isEmpty(r3)
            if (r3 == 0) goto L_0x001b
            goto L_0x008e
        L_0x001b:
            a6.b$a r3 = c
            java.lang.String r8 = r8.b
            java.lang.Object r4 = r3.get(r8)
            android.graphics.Bitmap r4 = (android.graphics.Bitmap) r4
            if (r4 != 0) goto L_0x0084
            android.content.res.Resources r4 = r7.getResources()     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            android.graphics.BitmapFactory$Options r5 = new android.graphics.BitmapFactory$Options     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            r5.<init>()     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            r6 = 240(0xf0, float:3.36E-43)
            r5.inDensity = r6     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            android.util.DisplayMetrics r6 = r4.getDisplayMetrics()     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            int r6 = r6.densityDpi     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            r5.inScreenDensity = r6     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            android.util.DisplayMetrics r4 = r4.getDisplayMetrics()     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            int r4 = r4.densityDpi     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            r5.inTargetDensity = r4     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            android.content.res.AssetManager r4 = r7.getAssets()     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            java.io.InputStream r4 = r4.open(r8)     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            android.graphics.Rect r6 = new android.graphics.Rect     // Catch:{ IOException -> 0x005e }
            r6.<init>()     // Catch:{ IOException -> 0x005e }
            android.graphics.Bitmap r5 = android.graphics.BitmapFactory.decodeStream(r4, r6, r5)     // Catch:{ IOException -> 0x005e }
            if (r5 == 0) goto L_0x0060
            r3.put(r8, r5)     // Catch:{ IOException -> 0x005e }
            goto L_0x0060
        L_0x005b:
            r7 = move-exception
            r2 = r4
            goto L_0x007c
        L_0x005e:
            r8 = move-exception
            goto L_0x006d
        L_0x0060:
            java.io.Closeable[] r8 = new java.io.Closeable[r1]
            r8[r0] = r4
            W2.l.b(r8)
            r2 = r5
            goto L_0x007a
        L_0x0069:
            r7 = move-exception
            goto L_0x007c
        L_0x006b:
            r8 = move-exception
            r4 = r2
        L_0x006d:
            r8.getMessage()     // Catch:{ all -> 0x005b }
            V1.h.b()     // Catch:{ all -> 0x005b }
            java.io.Closeable[] r8 = new java.io.Closeable[r1]
            r8[r0] = r4
            W2.l.b(r8)
        L_0x007a:
            r4 = r2
            goto L_0x0084
        L_0x007c:
            java.io.Closeable[] r8 = new java.io.Closeable[r1]
            r8[r0] = r2
            W2.l.b(r8)
            throw r7
        L_0x0084:
            android.graphics.drawable.BitmapDrawable r8 = new android.graphics.drawable.BitmapDrawable
            android.content.res.Resources r7 = r7.getResources()
            r8.<init>(r7, r4)
            return r8
        L_0x008e:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a6.C0025b.a(android.content.Context, int):android.graphics.drawable.BitmapDrawable");
    }
}
