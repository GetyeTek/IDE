package a6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.huawei.kbz.chat.R$id;
import com.huawei.kbz.chat.R$layout;
import java.util.ArrayList;

public final class f extends BaseAdapter {
    public ArrayList<g> a;
    public Context b;

    public final int getCount() {
        return this.a.size();
    }

    public final Object getItem(int i) {
        return null;
    }

    public final long getItemId(int i) {
        return (long) i;
    }

    public final View getView(int i, View view, ViewGroup viewGroup) {
        View inflate = LayoutInflater.from(this.b).inflate(R$layout.extension_function_item_layout, viewGroup, false);
        ArrayList<g> arrayList = this.a;
        ((ImageView) inflate.findViewById(R$id.function_icon)).setImageDrawable(arrayList.get(i).b);
        ((TextView) inflate.findViewById(R$id.function_title)).setText(arrayList.get(i).a);
        inflate.setOnClickListener(arrayList.get(i).c);
        return inflate;
    }
}
