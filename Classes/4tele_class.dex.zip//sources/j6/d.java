package j6;

import android.content.ContentValues;
import java.io.File;

public final class d {
    public static ContentValues a(File file, long j) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", file.getName());
        contentValues.put("_display_name", file.getName());
        contentValues.put("mime_type", "video/mp4");
        contentValues.put("datetaken", Long.valueOf(j));
        contentValues.put("date_modified", Long.valueOf(j));
        contentValues.put("date_added", Long.valueOf(j));
        contentValues.put("_data", file.getAbsolutePath());
        contentValues.put("_size", Long.valueOf(file.length()));
        return contentValues;
    }

    /* JADX WARNING: type inference failed for: r5v5, types: [java.lang.Object, android.media.MediaScannerConnection$OnScanCompletedListener] */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0093 A[SYNTHETIC, Splitter:B:33:0x0093] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x009b A[Catch:{ IOException -> 0x0097 }] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00aa A[SYNTHETIC, Splitter:B:43:0x00aa] */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00b2 A[Catch:{ IOException -> 0x00ae }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean b(android.content.Context r9, java.lang.String r10) {
        /*
            V1.h.b()
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 1
            r2 = 0
            r3 = 0
            r4 = 29
            if (r0 >= r4) goto L_0x00bd
            java.lang.String r0 = android.os.Environment.DIRECTORY_DCIM
            java.io.File r0 = android.os.Environment.getExternalStoragePublicDirectory(r0)
            java.io.File r4 = new java.io.File
            r4.<init>(r10)
            java.io.File r10 = new java.io.File
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r6 = r9.getPackageName()
            r5.append(r6)
            java.lang.String r6 = java.io.File.separator
            r5.append(r6)
            java.lang.String r6 = r4.getName()
            r5.append(r6)
            java.lang.String r5 = r5.toString()
            r10.<init>(r0, r5)
            java.io.FileInputStream r0 = new java.io.FileInputStream     // Catch:{ Exception -> 0x0089, all -> 0x0086 }
            r0.<init>(r4)     // Catch:{ Exception -> 0x0089, all -> 0x0086 }
            java.io.BufferedOutputStream r4 = new java.io.BufferedOutputStream     // Catch:{ Exception -> 0x0083, all -> 0x0080 }
            java.io.FileOutputStream r5 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0083, all -> 0x0080 }
            r5.<init>(r10)     // Catch:{ Exception -> 0x0083, all -> 0x0080 }
            r4.<init>(r5)     // Catch:{ Exception -> 0x0083, all -> 0x0080 }
            r2 = 1024(0x400, float:1.435E-42)
            byte[] r2 = new byte[r2]     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
        L_0x004b:
            int r5 = r0.read(r2)     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            if (r5 <= 0) goto L_0x005b
            r4.write(r2, r3, r5)     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            goto L_0x004b
        L_0x0055:
            r9 = move-exception
        L_0x0056:
            r2 = r0
            goto L_0x00a8
        L_0x0058:
            r9 = move-exception
        L_0x0059:
            r2 = r0
            goto L_0x008b
        L_0x005b:
            java.lang.String r10 = r10.getAbsolutePath()     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            java.lang.String[] r10 = new java.lang.String[]{r10}     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            java.lang.String r2 = "video/*"
            java.lang.String[] r2 = new java.lang.String[]{r2}     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            j6.c r5 = new j6.c     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            r5.<init>()     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            android.media.MediaScannerConnection.scanFile(r9, r10, r2, r5)     // Catch:{ Exception -> 0x0058, all -> 0x0055 }
            r0.close()     // Catch:{ IOException -> 0x0078 }
            r4.close()     // Catch:{ IOException -> 0x0078 }
            goto L_0x00a6
        L_0x0078:
            r9 = move-exception
            r9.getMessage()
            V1.h.b()
            goto L_0x00a6
        L_0x0080:
            r9 = move-exception
            r4 = r2
            goto L_0x0056
        L_0x0083:
            r9 = move-exception
            r4 = r2
            goto L_0x0059
        L_0x0086:
            r9 = move-exception
            r4 = r2
            goto L_0x00a8
        L_0x0089:
            r9 = move-exception
            r4 = r2
        L_0x008b:
            r9.getMessage()     // Catch:{ all -> 0x00a7 }
            V1.h.b()     // Catch:{ all -> 0x00a7 }
            if (r2 == 0) goto L_0x0099
            r2.close()     // Catch:{ IOException -> 0x0097 }
            goto L_0x0099
        L_0x0097:
            r9 = move-exception
            goto L_0x009f
        L_0x0099:
            if (r4 == 0) goto L_0x00a5
            r4.close()     // Catch:{ IOException -> 0x0097 }
            goto L_0x00a5
        L_0x009f:
            r9.getMessage()
            V1.h.b()
        L_0x00a5:
            r1 = 0
        L_0x00a6:
            return r1
        L_0x00a7:
            r9 = move-exception
        L_0x00a8:
            if (r2 == 0) goto L_0x00b0
            r2.close()     // Catch:{ IOException -> 0x00ae }
            goto L_0x00b0
        L_0x00ae:
            r10 = move-exception
            goto L_0x00b6
        L_0x00b0:
            if (r4 == 0) goto L_0x00bc
            r4.close()     // Catch:{ IOException -> 0x00ae }
            goto L_0x00bc
        L_0x00b6:
            r10.getMessage()
            V1.h.b()
        L_0x00bc:
            throw r9
        L_0x00bd:
            android.content.ContentResolver r5 = r9.getContentResolver()     // Catch:{ Exception -> 0x010a }
            java.io.File r6 = new java.io.File     // Catch:{ Exception -> 0x010a }
            r6.<init>(r10)     // Catch:{ Exception -> 0x010a }
            long r7 = java.lang.System.currentTimeMillis()     // Catch:{ Exception -> 0x010a }
            android.content.ContentValues r10 = a(r6, r7)     // Catch:{ Exception -> 0x010a }
            android.net.Uri r7 = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI     // Catch:{ Exception -> 0x010a }
            android.net.Uri r7 = r5.insert(r7, r10)     // Catch:{ Exception -> 0x010a }
            if (r0 < r4) goto L_0x00ec
            android.content.pm.ApplicationInfo r0 = r9.getApplicationInfo()     // Catch:{ Exception -> 0x010a }
            int r0 = r0.targetSdkVersion     // Catch:{ Exception -> 0x010a }
            if (r0 < r4) goto L_0x00ec
            java.io.OutputStream r0 = r5.openOutputStream(r7)     // Catch:{ Exception -> 0x010a }
            java.nio.file.Path r4 = r1.g.a(r6)     // Catch:{ Exception -> 0x010a }
            androidx.core.graphics.l.b(r4, r0)     // Catch:{ Exception -> 0x010a }
            r0.close()     // Catch:{ Exception -> 0x010a }
        L_0x00ec:
            r10.clear()     // Catch:{ Exception -> 0x010a }
            java.lang.String r0 = "is_pending"
            java.lang.Integer r4 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x010a }
            r10.put(r0, r4)     // Catch:{ Exception -> 0x010a }
            android.content.ContentResolver r0 = r9.getContentResolver()     // Catch:{ Exception -> 0x010a }
            r0.update(r7, r10, r2, r2)     // Catch:{ Exception -> 0x010a }
            android.content.Intent r10 = new android.content.Intent     // Catch:{ Exception -> 0x010a }
            java.lang.String r0 = "android.intent.action.MEDIA_SCANNER_SCAN_FILE"
            r10.<init>(r0, r7)     // Catch:{ Exception -> 0x010a }
            r9.sendBroadcast(r10)     // Catch:{ Exception -> 0x010a }
            goto L_0x0112
        L_0x010a:
            r9 = move-exception
            r9.getMessage()
            V1.h.b()
            r1 = 0
        L_0x0112:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: j6.d.b(android.content.Context, java.lang.String):boolean");
    }
}
