package j6;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.I;
import com.huawei.kbz.constant.FileTypeEnum;
import java.io.File;

public final class a {
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0061 A[SYNTHETIC, Splitter:B:24:0x0061] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x006f A[SYNTHETIC, Splitter:B:30:0x006f] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.io.File a(android.net.Uri r7, androidx.fragment.app.FragmentActivity r8) {
        /*
            java.lang.String r0 = ""
            r1 = 0
            java.lang.String r8 = c(r7, r8)     // Catch:{ FileNotFoundException -> 0x0057, all -> 0x0055 }
            android.app.Application r2 = com.blankj.utilcode.util.J.a()     // Catch:{ FileNotFoundException -> 0x0057, all -> 0x0055 }
            android.content.ContentResolver r2 = r2.getContentResolver()     // Catch:{ FileNotFoundException -> 0x0057, all -> 0x0055 }
            java.io.InputStream r7 = r2.openInputStream(r7)     // Catch:{ FileNotFoundException -> 0x0057, all -> 0x0055 }
            java.io.File r2 = new java.io.File     // Catch:{ FileNotFoundException -> 0x0034 }
            android.app.Application r3 = com.blankj.utilcode.util.J.a()     // Catch:{ FileNotFoundException -> 0x0034 }
            java.io.File r3 = r3.getCacheDir()     // Catch:{ FileNotFoundException -> 0x0034 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0034 }
            r4.<init>(r0)     // Catch:{ FileNotFoundException -> 0x0034 }
            boolean r0 = android.text.TextUtils.isEmpty(r8)     // Catch:{ FileNotFoundException -> 0x0034 }
            if (r0 == 0) goto L_0x0036
            long r5 = java.lang.System.currentTimeMillis()     // Catch:{ FileNotFoundException -> 0x0034 }
            java.lang.Long r8 = java.lang.Long.valueOf(r5)     // Catch:{ FileNotFoundException -> 0x0034 }
            goto L_0x0036
        L_0x0031:
            r8 = move-exception
            r1 = r7
            goto L_0x006d
        L_0x0034:
            r8 = move-exception
            goto L_0x0059
        L_0x0036:
            r4.append(r8)     // Catch:{ FileNotFoundException -> 0x0034 }
            java.lang.String r8 = r4.toString()     // Catch:{ FileNotFoundException -> 0x0034 }
            r2.<init>(r3, r8)     // Catch:{ FileNotFoundException -> 0x0034 }
            java.lang.String r8 = r2.getAbsolutePath()     // Catch:{ FileNotFoundException -> 0x0034 }
            com.blankj.utilcode.util.i.a(r7, r8)     // Catch:{ FileNotFoundException -> 0x0034 }
            if (r7 == 0) goto L_0x0054
            r7.close()     // Catch:{ IOException -> 0x004d }
            goto L_0x0054
        L_0x004d:
            r7 = move-exception
            r7.getMessage()
            V1.h.b()
        L_0x0054:
            return r2
        L_0x0055:
            r8 = move-exception
            goto L_0x006d
        L_0x0057:
            r8 = move-exception
            r7 = r1
        L_0x0059:
            r8.getMessage()     // Catch:{ all -> 0x0031 }
            V1.h.b()     // Catch:{ all -> 0x0031 }
            if (r7 == 0) goto L_0x006c
            r7.close()     // Catch:{ IOException -> 0x0065 }
            goto L_0x006c
        L_0x0065:
            r7 = move-exception
            r7.getMessage()
            V1.h.b()
        L_0x006c:
            return r1
        L_0x006d:
            if (r1 == 0) goto L_0x007a
            r1.close()     // Catch:{ IOException -> 0x0073 }
            goto L_0x007a
        L_0x0073:
            r7 = move-exception
            r7.getMessage()
            V1.h.b()
        L_0x007a:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: j6.a.a(android.net.Uri, androidx.fragment.app.FragmentActivity):java.io.File");
    }

    public static String b(String str) {
        Uri parse;
        if (TextUtils.isEmpty(str) || (parse = Uri.parse(str)) == null) {
            return "";
        }
        String queryParameter = parse.getQueryParameter("filename");
        return e("/telebirr/document/") + "/" + queryParameter;
    }

    @SuppressLint({"Range"})
    public static String c(Uri uri, FragmentActivity fragmentActivity) {
        String str = null;
        if (uri.getScheme().equals("content")) {
            Cursor query = fragmentActivity.getContentResolver().query(uri, (String[]) null, (String) null, (String[]) null, (String) null);
            if (query != null) {
                try {
                    if (query.moveToFirst()) {
                        str = query.getString(query.getColumnIndex("_display_name"));
                    }
                } catch (Throwable th) {
                    query.close();
                    throw th;
                }
            }
            query.close();
        }
        if (str != null) {
            return str;
        }
        String path = uri.getPath();
        int lastIndexOf = path.lastIndexOf(47);
        if (lastIndexOf != -1) {
            return path.substring(lastIndexOf + 1);
        }
        return path;
    }

    public static String d(Uri uri, FragmentActivity fragmentActivity) {
        String type = fragmentActivity.getContentResolver().getType(uri);
        if (TextUtils.isEmpty(type)) {
            return FileTypeEnum.DATA_TYPE_ALL.getDataType();
        }
        return type;
    }

    public static File e(String str) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + str);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static boolean f(Uri uri, FragmentActivity fragmentActivity) {
        String d = d(uri, fragmentActivity);
        if (TextUtils.isEmpty(d)) {
            return false;
        }
        if (d.startsWith("image")) {
            return true;
        }
        File c = I.c(uri);
        if (c == null) {
            return false;
        }
        String path = c.getPath();
        if (path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".png")) {
            return true;
        }
        return false;
    }

    public static boolean g(Uri uri, FragmentActivity fragmentActivity) {
        String d = d(uri, fragmentActivity);
        if (TextUtils.isEmpty(d)) {
            return false;
        }
        if (d.startsWith("video")) {
            return true;
        }
        File c = I.c(uri);
        if (c == null) {
            return false;
        }
        String path = c.getPath();
        if (path.endsWith(".mp4") || path.endsWith(".MP4")) {
            return true;
        }
        return false;
    }
}
