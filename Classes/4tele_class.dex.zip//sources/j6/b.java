package j6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.huawei.kbz.chat.R$id;
import com.huawei.kbz.chat.R$layout;

public final class b {
    public static int a(Context context, String str) {
        View inflate = LayoutInflater.from(context).inflate(R$layout.quote_base_layout, (ViewGroup) null, false);
        ((TextView) inflate.findViewById(R$id.tv_quote_content)).setText(str);
        inflate.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
        return inflate.getMeasuredWidth();
    }

    public static int b(Context context, String str) {
        View inflate = LayoutInflater.from(context).inflate(R$layout.conversation_item_text_send, (ViewGroup) null, false);
        ((TextView) inflate.findViewById(R$id.contentTextView)).setText(str);
        ((TextView) inflate.findViewById(R$id.timeTextView)).setText("00:00");
        inflate.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
        return inflate.getMeasuredWidth();
    }
}
