package j6;

import V1.h;
import android.media.MediaScannerConnection;
import android.net.Uri;
import java.util.Objects;

public final /* synthetic */ class c implements MediaScannerConnection.OnScanCompletedListener {
    public final void onScanCompleted(String str, Uri uri) {
        Objects.toString(uri);
        h.b();
    }
}
