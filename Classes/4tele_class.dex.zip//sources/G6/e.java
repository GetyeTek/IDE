package G6;

import android.view.View;
import com.google.android.material.bottomappbar.BottomAppBar;
import com.huawei.kbz.view.SafeKeyBoardEditText;
import com.shinemo.base.util.ChatManagerImpl;
import com.shinemo.chat.CYCallback;

public final /* synthetic */ class e implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ e(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void run() {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = SafeKeyBoardEditText.h;
                ((SafeKeyBoardEditText) obj).a();
                return;
            case 1:
                BottomAppBar.a((View) obj);
                return;
            default:
                ChatManagerImpl.u((CYCallback) obj);
                return;
        }
    }
}
