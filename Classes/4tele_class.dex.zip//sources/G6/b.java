package G6;

import android.view.View;
import android.widget.PopupWindow;
import com.huawei.kbz.view.DigitalKeyBoardEditText;

public final /* synthetic */ class b implements PopupWindow.OnDismissListener {
    public final /* synthetic */ DigitalKeyBoardEditText a;

    public /* synthetic */ b(DigitalKeyBoardEditText digitalKeyBoardEditText) {
        this.a = digitalKeyBoardEditText;
    }

    public final void onDismiss() {
        View view;
        DigitalKeyBoardEditText digitalKeyBoardEditText = this.a;
        int i = digitalKeyBoardEditText.f;
        if (i > 0 && (view = digitalKeyBoardEditText.b) != null) {
            view.scrollBy(0, -i);
        }
    }
}
