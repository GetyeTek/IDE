package G6;

import I8.a;
import androidx.camera.video.internal.audio.AudioSource;
import com.huawei.astp.macle.ui.MaBaseActivity;
import com.huawei.kbz.view.DigitalKeyBoardEditText;
import com.shinemo.base.util.ChatManagerImpl;
import com.shinemo.chat.CYCallback;

public final /* synthetic */ class a implements Runnable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ a(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void run() {
        Object obj = this.b;
        switch (this.a) {
            case 0:
                int i = DigitalKeyBoardEditText.j;
                ((DigitalKeyBoardEditText) obj).a();
                return;
            case 1:
                I8.a aVar = ((a.b) obj).a;
                aVar.b = false;
                aVar.a();
                return;
            case 2:
                AudioSource.l((AudioSource) obj);
                return;
            case 3:
                MaBaseActivity.P0((MaBaseActivity) obj);
                return;
            default:
                ChatManagerImpl.e((CYCallback) obj);
                return;
        }
    }
}
