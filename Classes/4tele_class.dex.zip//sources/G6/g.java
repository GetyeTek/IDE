package G6;

import D6.i;
import android.os.Vibrator;
import android.view.View;
import android.widget.AdapterView;
import com.huawei.kbz.ui.common.PinPasswordDialogFragment;
import com.huawei.kbz.view.VirtualKeyboardViewNew;

public final /* synthetic */ class g implements AdapterView.OnItemClickListener {
    public final /* synthetic */ VirtualKeyboardViewNew a;

    public /* synthetic */ g(VirtualKeyboardViewNew virtualKeyboardViewNew) {
        this.a = virtualKeyboardViewNew;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        VirtualKeyboardViewNew virtualKeyboardViewNew = this.a;
        ((Vibrator) virtualKeyboardViewNew.a.getSystemService("vibrator")).vibrate(30);
        if (i != 9 && i != 11) {
            int i2 = virtualKeyboardViewNew.e;
            if (i2 >= -1 && i2 < 5) {
                int i3 = i2 + 1;
                virtualKeyboardViewNew.e = i3;
                VirtualKeyboardViewNew.b bVar = virtualKeyboardViewNew.c;
                if (bVar != null) {
                    PinPasswordDialogFragment pinPasswordDialogFragment = ((i) bVar).a;
                    pinPasswordDialogFragment.b[i3].setText((String) virtualKeyboardViewNew.d.get(i).get("name"));
                    pinPasswordDialogFragment.c[i3].setSelected(true);
                }
            }
        } else if (i == 11) {
            int i4 = virtualKeyboardViewNew.e;
            if (i4 - 1 >= -1) {
                VirtualKeyboardViewNew.b bVar2 = virtualKeyboardViewNew.c;
                if (bVar2 != null) {
                    PinPasswordDialogFragment pinPasswordDialogFragment2 = ((i) bVar2).a;
                    pinPasswordDialogFragment2.b[i4].setText("");
                    pinPasswordDialogFragment2.c[i4].setSelected(false);
                }
                virtualKeyboardViewNew.e--;
            }
        }
    }
}
