package G6;

import android.text.InputFilter;
import android.text.Spanned;
import com.huawei.kbz.view.HintEditText;
import java.lang.Character;

public final /* synthetic */ class c implements InputFilter {
    public final CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        int i5 = HintEditText.b;
        while (i < i2) {
            Character.UnicodeBlock of = Character.UnicodeBlock.of(charSequence.charAt(i));
            if (of == Character.UnicodeBlock.MYANMAR || of == Character.UnicodeBlock.MYANMAR_EXTENDED_A) {
                return "";
            }
            i++;
        }
        return null;
    }
}
