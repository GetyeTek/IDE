package G6;

import D2.a;
import D6.e;
import E0.c;
import V1.f;
import V1.k;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.WindowInsetsCompat;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.google.android.material.search.SearchView;
import com.huawei.digitalpayment.customer.bean.homeconfig.Customer;
import com.huawei.digitalpayment.customer.homev6.model.HomeFunction;
import com.huawei.module_cash.R;
import com.huawei.module_cash.deposit.activity.DepositCashAgentActivity;
import java.util.List;

public final /* synthetic */ class d implements e, a, OnApplyWindowInsetsListener, OnItemClickListener {
    public final /* synthetic */ Object a;

    public /* synthetic */ d(Object obj) {
        this.a = obj;
    }

    public void c(boolean z) {
        int i = DepositCashAgentActivity.q;
        DepositCashAgentActivity depositCashAgentActivity = (DepositCashAgentActivity) this.a;
        if (z) {
            ViewGroup viewGroup = (ViewGroup) depositCashAgentActivity.findViewById(R.id.base_container);
            View inflate = LayoutInflater.from(depositCashAgentActivity).inflate(R.layout.layout_download_deposit_cash_qr_code, viewGroup, false);
            ((ImageView) inflate.findViewById(R.id.iv_qrcode)).setImageBitmap(depositCashAgentActivity.o);
            View findViewById = inflate.findViewById(R.id.ll_amount);
            if (!TextUtils.isEmpty(depositCashAgentActivity.i.d.getText())) {
                findViewById.setVisibility(0);
                ((TextView) inflate.findViewById(R.id.tv_amount)).setText(depositCashAgentActivity.i.d.getText());
                ((TextView) inflate.findViewById(R.id.tv_amount_unit)).setText(depositCashAgentActivity.i.e.getText());
            } else {
                findViewById.setVisibility(8);
            }
            TextView textView = (TextView) inflate.findViewById(R.id.tv_phone_number);
            Customer f = c.f();
            if (f != null) {
                String nickName = f.getNickName();
                String msisdn = f.getMsisdn();
                textView.setText(nickName + " (+" + msisdn + ")");
            }
            if (f.b(depositCashAgentActivity, f.a(inflate, viewGroup.getWidth(), viewGroup.getHeight()))) {
                k.b(1, depositCashAgentActivity.getString(R.string.app_qr_code_saved_successfully));
            } else {
                k.b(1, depositCashAgentActivity.getString(R.string.qrcode_saved_qr_code_fail));
            }
        } else {
            depositCashAgentActivity.getClass();
            com.blankj.utilcode.util.e.b();
            k.b(1, depositCashAgentActivity.getString(R.string.designstandard_write_permission_required_to_save_qr_code));
        }
    }

    public WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
        return SearchView.h((SearchView) this.a, view, windowInsetsCompat);
    }

    public void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        C3.e.b((HomeFunction) ((List) this.a).get(i));
    }
}
