package G6;

import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import com.huawei.kbz.view.SafeKeyBoardEditText;
import com.huawei.module_cash.deposit.activity.DepositCashAgentActivity;

public final /* synthetic */ class f implements PopupWindow.OnDismissListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ KeyEvent.Callback b;

    public /* synthetic */ f(KeyEvent.Callback callback, int i) {
        this.a = i;
        this.b = callback;
    }

    public final void onDismiss() {
        View view;
        DepositCashAgentActivity depositCashAgentActivity = this.b;
        switch (this.a) {
            case 0:
                SafeKeyBoardEditText safeKeyBoardEditText = (SafeKeyBoardEditText) depositCashAgentActivity;
                int i = safeKeyBoardEditText.f;
                if (i > 0 && (view = safeKeyBoardEditText.b) != null) {
                    view.scrollBy(0, -i);
                    return;
                }
                return;
            default:
                int i2 = DepositCashAgentActivity.q;
                DepositCashAgentActivity depositCashAgentActivity2 = depositCashAgentActivity;
                WindowManager.LayoutParams attributes = depositCashAgentActivity2.getWindow().getAttributes();
                attributes.alpha = 1.0f;
                depositCashAgentActivity2.getWindow().setAttributes(attributes);
                return;
        }
    }
}
