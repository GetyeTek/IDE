package android.support.v7.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.z;

class B extends BroadcastReceiver {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z.e f961a;

    B(z.e eVar) {
        this.f961a = eVar;
    }

    public void onReceive(Context context, Intent intent) {
        this.f961a.b();
    }
}
