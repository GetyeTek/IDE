package android.support.v7.app;

import android.view.View;

/* renamed from: android.support.v7.app.e  reason: case insensitive filesystem */
class C0122e implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ AlertController f1007a;

    C0122e(AlertController alertController) {
        this.f1007a = alertController;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0020, code lost:
        r3 = r0.y;
     */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x002c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onClick(android.view.View r3) {
        /*
            r2 = this;
            android.support.v7.app.AlertController r0 = r2.f1007a
            android.widget.Button r1 = r0.o
            if (r3 != r1) goto L_0x000f
            android.os.Message r0 = r0.q
            if (r0 == 0) goto L_0x000f
        L_0x000a:
            android.os.Message r3 = android.os.Message.obtain(r0)
            goto L_0x002a
        L_0x000f:
            android.support.v7.app.AlertController r0 = r2.f1007a
            android.widget.Button r1 = r0.s
            if (r3 != r1) goto L_0x001a
            android.os.Message r0 = r0.u
            if (r0 == 0) goto L_0x001a
            goto L_0x000a
        L_0x001a:
            android.support.v7.app.AlertController r0 = r2.f1007a
            android.widget.Button r1 = r0.w
            if (r3 != r1) goto L_0x0029
            android.os.Message r3 = r0.y
            if (r3 == 0) goto L_0x0029
            android.os.Message r3 = android.os.Message.obtain(r3)
            goto L_0x002a
        L_0x0029:
            r3 = 0
        L_0x002a:
            if (r3 == 0) goto L_0x002f
            r3.sendToTarget()
        L_0x002f:
            android.support.v7.app.AlertController r3 = r2.f1007a
            android.os.Handler r0 = r3.R
            r1 = 1
            android.support.v7.app.D r3 = r3.f950b
            android.os.Message r3 = r0.obtainMessage(r1, r3)
            r3.sendToTarget()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.C0122e.onClick(android.view.View):void");
    }
}
