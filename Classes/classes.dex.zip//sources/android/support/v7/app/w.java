package android.support.v7.app;

import android.support.v4.view.K;
import android.support.v4.view.L;
import android.view.View;

class w extends L {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ x f1039a;

    w(x xVar) {
        this.f1039a = xVar;
    }

    public void b(View view) {
        this.f1039a.f1040a.q.setAlpha(1.0f);
        this.f1039a.f1040a.t.a((K) null);
        this.f1039a.f1040a.t = null;
    }

    public void c(View view) {
        this.f1039a.f1040a.q.setVisibility(0);
    }
}
