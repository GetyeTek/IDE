package android.support.v7.app;

import a.b.g.a.a;
import a.b.g.e.b;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.view.C0111h;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;

public class D extends Dialog implements p {

    /* renamed from: a  reason: collision with root package name */
    private q f963a;

    /* renamed from: b  reason: collision with root package name */
    private final C0111h.a f964b = new C(this);

    public D(Context context, int i) {
        super(context, a(context, i));
        a().a((Bundle) null);
        a().a();
    }

    private static int a(Context context, int i) {
        if (i != 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(a.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    public b a(b.a aVar) {
        return null;
    }

    public q a() {
        if (this.f963a == null) {
            this.f963a = q.a((Dialog) this, (p) this);
        }
        return this.f963a;
    }

    public void a(b bVar) {
    }

    public boolean a(int i) {
        return a().b(i);
    }

    /* access modifiers changed from: package-private */
    public boolean a(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        a().a(view, layoutParams);
    }

    public void b(b bVar) {
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return C0111h.a(this.f964b, getWindow().getDecorView(), this, keyEvent);
    }

    public <T extends View> T findViewById(int i) {
        return a().a(i);
    }

    public void invalidateOptionsMenu() {
        a().g();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        a().f();
        super.onCreate(bundle);
        a().a(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        a().k();
    }

    public void setContentView(int i) {
        a().c(i);
    }

    public void setContentView(View view) {
        a().a(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        a().b(view, layoutParams);
    }

    public void setTitle(int i) {
        super.setTitle(i);
        a().a((CharSequence) getContext().getString(i));
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        a().a(charSequence);
    }
}
