package android.support.v7.app;

import android.view.View;

class L extends android.support.v4.view.L {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ N f987a;

    L(N n) {
        this.f987a = n;
    }

    public void b(View view) {
        N n = this.f987a;
        n.B = null;
        n.h.requestLayout();
    }
}
