package android.support.v7.app;

import android.view.View;

/* renamed from: android.support.v7.app.g  reason: case insensitive filesystem */
class C0124g implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ View f1011a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ View f1012b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ AlertController f1013c;

    C0124g(AlertController alertController, View view, View view2) {
        this.f1013c = alertController;
        this.f1011a = view;
        this.f1012b = view2;
    }

    public void run() {
        AlertController.a(this.f1013c.A, this.f1011a, this.f1012b);
    }
}
