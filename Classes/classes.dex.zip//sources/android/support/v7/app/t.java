package android.support.v7.app;

import android.support.v4.view.N;
import android.support.v4.view.s;
import android.support.v4.view.y;
import android.view.View;

class t implements s {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z f1036a;

    t(z zVar) {
        this.f1036a = zVar;
    }

    public N a(View view, N n) {
        int e = n.e();
        int i = this.f1036a.i(e);
        if (e != i) {
            n = n.a(n.c(), i, n.d(), n.b());
        }
        return y.b(view, n);
    }
}
