package android.support.v7.app;

import android.view.View;

/* renamed from: android.support.v7.app.b  reason: case insensitive filesystem */
class C0119b implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0120c f994a;

    C0119b(C0120c cVar) {
        this.f994a = cVar;
    }

    public void onClick(View view) {
        C0120c cVar = this.f994a;
        if (cVar.f) {
            cVar.d();
            return;
        }
        View.OnClickListener onClickListener = cVar.j;
        if (onClickListener != null) {
            onClickListener.onClick(view);
        }
    }
}
