package android.support.v7.app;

import android.content.Context;
import android.database.Cursor;
import android.support.v7.app.AlertController;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;

/* renamed from: android.support.v7.app.k  reason: case insensitive filesystem */
class C0128k extends CursorAdapter {

    /* renamed from: a  reason: collision with root package name */
    private final int f1022a;

    /* renamed from: b  reason: collision with root package name */
    private final int f1023b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ AlertController.RecycleListView f1024c;
    final /* synthetic */ AlertController d;
    final /* synthetic */ AlertController.a e;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0128k(AlertController.a aVar, Context context, Cursor cursor, boolean z, AlertController.RecycleListView recycleListView, AlertController alertController) {
        super(context, cursor, z);
        this.e = aVar;
        this.f1024c = recycleListView;
        this.d = alertController;
        Cursor cursor2 = getCursor();
        this.f1022a = cursor2.getColumnIndexOrThrow(this.e.L);
        this.f1023b = cursor2.getColumnIndexOrThrow(this.e.M);
    }

    public void bindView(View view, Context context, Cursor cursor) {
        ((CheckedTextView) view.findViewById(16908308)).setText(cursor.getString(this.f1022a));
        AlertController.RecycleListView recycleListView = this.f1024c;
        int position = cursor.getPosition();
        boolean z = true;
        if (cursor.getInt(this.f1023b) != 1) {
            z = false;
        }
        recycleListView.setItemChecked(position, z);
    }

    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.e.f955b.inflate(this.d.M, viewGroup, false);
    }
}
