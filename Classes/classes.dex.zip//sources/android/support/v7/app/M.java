package android.support.v7.app;

import android.view.View;

class M implements android.support.v4.view.M {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ N f988a;

    M(N n) {
        this.f988a = n;
    }

    public void a(View view) {
        ((View) this.f988a.h.getParent()).invalidate();
    }
}
