package android.support.v7.app;

import android.support.v7.app.AlertController;
import android.view.View;
import android.widget.AdapterView;

/* renamed from: android.support.v7.app.l  reason: case insensitive filesystem */
class C0129l implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ AlertController f1025a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ AlertController.a f1026b;

    C0129l(AlertController.a aVar, AlertController alertController) {
        this.f1026b = aVar;
        this.f1025a = alertController;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.f1026b.x.onClick(this.f1025a.f950b, i);
        if (!this.f1026b.H) {
            this.f1025a.f950b.dismiss();
        }
    }
}
