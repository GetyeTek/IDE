package android.support.v7.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.content.k;
import android.util.Log;
import java.util.Calendar;

class J {

    /* renamed from: a  reason: collision with root package name */
    private static J f980a;

    /* renamed from: b  reason: collision with root package name */
    private final Context f981b;

    /* renamed from: c  reason: collision with root package name */
    private final LocationManager f982c;
    private final a d = new a();

    private static class a {

        /* renamed from: a  reason: collision with root package name */
        boolean f983a;

        /* renamed from: b  reason: collision with root package name */
        long f984b;

        /* renamed from: c  reason: collision with root package name */
        long f985c;
        long d;
        long e;
        long f;

        a() {
        }
    }

    J(Context context, LocationManager locationManager) {
        this.f981b = context;
        this.f982c = locationManager;
    }

    private Location a(String str) {
        try {
            if (this.f982c.isProviderEnabled(str)) {
                return this.f982c.getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e) {
            Log.d("TwilightManager", "Failed to get last known location", e);
            return null;
        }
    }

    static J a(Context context) {
        if (f980a == null) {
            Context applicationContext = context.getApplicationContext();
            f980a = new J(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
        }
        return f980a;
    }

    private void a(Location location) {
        long j;
        a aVar = this.d;
        long currentTimeMillis = System.currentTimeMillis();
        I a2 = I.a();
        I i = a2;
        i.a(currentTimeMillis - 86400000, location.getLatitude(), location.getLongitude());
        long j2 = a2.f978b;
        i.a(currentTimeMillis, location.getLatitude(), location.getLongitude());
        boolean z = a2.d == 1;
        long j3 = a2.f979c;
        long j4 = j2;
        long j5 = a2.f978b;
        long j6 = j3;
        boolean z2 = z;
        a2.a(86400000 + currentTimeMillis, location.getLatitude(), location.getLongitude());
        long j7 = a2.f979c;
        if (j6 == -1 || j5 == -1) {
            j = 43200000 + currentTimeMillis;
        } else {
            j = (currentTimeMillis > j5 ? 0 + j7 : currentTimeMillis > j6 ? 0 + j5 : 0 + j6) + 60000;
        }
        aVar.f983a = z2;
        aVar.f984b = j4;
        aVar.f985c = j6;
        aVar.d = j5;
        aVar.e = j7;
        aVar.f = j;
    }

    @SuppressLint({"MissingPermission"})
    private Location b() {
        Location location = null;
        Location a2 = k.a(this.f981b, "android.permission.ACCESS_COARSE_LOCATION") == 0 ? a("network") : null;
        if (k.a(this.f981b, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            location = a("gps");
        }
        return (location == null || a2 == null) ? location != null ? location : a2 : location.getTime() > a2.getTime() ? location : a2;
    }

    private boolean c() {
        return this.d.f > System.currentTimeMillis();
    }

    /* access modifiers changed from: package-private */
    public boolean a() {
        a aVar = this.d;
        if (c()) {
            return aVar.f983a;
        }
        Location b2 = b();
        if (b2 != null) {
            a(b2);
            return aVar.f983a;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        int i = Calendar.getInstance().get(11);
        return i < 6 || i >= 22;
    }
}
