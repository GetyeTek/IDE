package android.support.v7.app;

import a.b.g.a.j;
import a.b.g.e.b;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: android.support.v7.app.a  reason: case insensitive filesystem */
public abstract class C0118a {

    /* renamed from: android.support.v7.app.a$a  reason: collision with other inner class name */
    public static class C0021a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a  reason: collision with root package name */
        public int f993a;

        public C0021a(int i, int i2) {
            super(i, i2);
            this.f993a = 0;
            this.f993a = 8388627;
        }

        public C0021a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f993a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.ActionBarLayout);
            this.f993a = obtainStyledAttributes.getInt(j.ActionBarLayout_android_layout_gravity, 0);
            obtainStyledAttributes.recycle();
        }

        public C0021a(C0021a aVar) {
            super(aVar);
            this.f993a = 0;
            this.f993a = aVar.f993a;
        }

        public C0021a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f993a = 0;
        }
    }

    /* renamed from: android.support.v7.app.a$b */
    public interface b {
        void onMenuVisibilityChanged(boolean z);
    }

    @Deprecated
    /* renamed from: android.support.v7.app.a$c */
    public static abstract class c {
        public abstract CharSequence a();

        public abstract View b();

        public abstract Drawable c();

        public abstract CharSequence d();

        public abstract void e();
    }

    public a.b.g.e.b a(b.a aVar) {
        return null;
    }

    public void a(Configuration configuration) {
    }

    public abstract void a(Drawable drawable);

    public abstract void a(View view);

    public abstract void a(CharSequence charSequence);

    public abstract boolean a(int i, KeyEvent keyEvent);

    public boolean a(KeyEvent keyEvent) {
        return false;
    }

    public abstract void b(int i);

    public abstract void b(Drawable drawable);

    public abstract void b(CharSequence charSequence);

    public abstract void b(boolean z);

    public abstract void c(int i);

    public abstract void c(boolean z);

    public abstract void d(boolean z);

    public abstract void e(boolean z);

    public boolean e() {
        return false;
    }

    public abstract void f(boolean z);

    public abstract boolean f();

    public abstract View g();

    public abstract void g(boolean z);

    public abstract int h();

    public abstract void h(boolean z);

    public abstract int i();

    public abstract Context j();

    public abstract void k();

    public boolean l() {
        return false;
    }

    public abstract boolean m();

    /* access modifiers changed from: package-private */
    public void n() {
    }

    public boolean o() {
        return false;
    }

    public abstract void p();
}
