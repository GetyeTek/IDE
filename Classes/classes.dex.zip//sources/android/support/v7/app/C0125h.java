package android.support.v7.app;

import android.view.View;
import android.widget.AbsListView;

/* renamed from: android.support.v7.app.h  reason: case insensitive filesystem */
class C0125h implements AbsListView.OnScrollListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ View f1014a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ View f1015b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ AlertController f1016c;

    C0125h(AlertController alertController, View view, View view2) {
        this.f1016c = alertController;
        this.f1014a = view;
        this.f1015b = view2;
    }

    public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        AlertController.a(absListView, this.f1014a, this.f1015b);
    }

    public void onScrollStateChanged(AbsListView absListView, int i) {
    }
}
