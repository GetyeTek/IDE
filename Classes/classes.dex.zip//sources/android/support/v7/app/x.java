package android.support.v7.app;

import android.support.v4.view.J;
import android.support.v4.view.K;
import android.support.v4.view.y;

class x implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z f1040a;

    x(z zVar) {
        this.f1040a = zVar;
    }

    public void run() {
        z zVar = this.f1040a;
        zVar.r.showAtLocation(zVar.q, 55, 0, 0);
        this.f1040a.m();
        if (this.f1040a.t()) {
            this.f1040a.q.setAlpha(0.0f);
            z zVar2 = this.f1040a;
            J a2 = y.a(zVar2.q);
            a2.a(1.0f);
            zVar2.t = a2;
            this.f1040a.t.a((K) new w(this));
            return;
        }
        this.f1040a.q.setAlpha(1.0f);
        this.f1040a.q.setVisibility(0);
    }
}
