package android.support.v7.app;

import android.content.Context;
import android.support.v7.app.AlertController;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

/* renamed from: android.support.v7.app.j  reason: case insensitive filesystem */
class C0127j extends ArrayAdapter<CharSequence> {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ AlertController.RecycleListView f1020a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ AlertController.a f1021b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0127j(AlertController.a aVar, Context context, int i, int i2, CharSequence[] charSequenceArr, AlertController.RecycleListView recycleListView) {
        super(context, i, i2, charSequenceArr);
        this.f1021b = aVar;
        this.f1020a = recycleListView;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View view2 = super.getView(i, view, viewGroup);
        boolean[] zArr = this.f1021b.F;
        if (zArr != null && zArr[i]) {
            this.f1020a.setItemChecked(i, true);
        }
        return view2;
    }
}
