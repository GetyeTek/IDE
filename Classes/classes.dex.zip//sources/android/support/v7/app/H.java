package android.support.v7.app;

import a.b.g.e.j;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.v4.view.y;
import android.support.v7.app.C0118a;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.v;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.X;
import android.support.v7.widget.vb;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import java.util.ArrayList;

class H extends C0118a {

    /* renamed from: a  reason: collision with root package name */
    X f970a;

    /* renamed from: b  reason: collision with root package name */
    boolean f971b;

    /* renamed from: c  reason: collision with root package name */
    Window.Callback f972c;
    private boolean d;
    private boolean e;
    private ArrayList<C0118a.b> f = new ArrayList<>();
    private final Runnable g = new F(this);
    private final Toolbar.c h = new G(this);

    private final class a implements v.a {

        /* renamed from: a  reason: collision with root package name */
        private boolean f973a;

        a() {
        }

        public void a(l lVar, boolean z) {
            if (!this.f973a) {
                this.f973a = true;
                H.this.f970a.g();
                Window.Callback callback = H.this.f972c;
                if (callback != null) {
                    callback.onPanelClosed(108, lVar);
                }
                this.f973a = false;
            }
        }

        public boolean a(l lVar) {
            Window.Callback callback = H.this.f972c;
            if (callback == null) {
                return false;
            }
            callback.onMenuOpened(108, lVar);
            return true;
        }
    }

    private final class b implements l.a {
        b() {
        }

        public void a(l lVar) {
            H h = H.this;
            if (h.f972c == null) {
                return;
            }
            if (h.f970a.a()) {
                H.this.f972c.onPanelClosed(108, lVar);
            } else if (H.this.f972c.onPreparePanel(0, (View) null, lVar)) {
                H.this.f972c.onMenuOpened(108, lVar);
            }
        }

        public boolean a(l lVar, MenuItem menuItem) {
            return false;
        }
    }

    private class c extends j {
        public c(Window.Callback callback) {
            super(callback);
        }

        public View onCreatePanelView(int i) {
            return i == 0 ? new View(H.this.f970a.o()) : super.onCreatePanelView(i);
        }

        public boolean onPreparePanel(int i, View view, Menu menu) {
            boolean onPreparePanel = super.onPreparePanel(i, view, menu);
            if (onPreparePanel) {
                H h = H.this;
                if (!h.f971b) {
                    h.f970a.b();
                    H.this.f971b = true;
                }
            }
            return onPreparePanel;
        }
    }

    H(Toolbar toolbar, CharSequence charSequence, Window.Callback callback) {
        this.f970a = new vb(toolbar, false);
        this.f972c = new c(callback);
        this.f970a.setWindowCallback(this.f972c);
        toolbar.setOnMenuItemClickListener(this.h);
        this.f970a.setWindowTitle(charSequence);
    }

    private Menu s() {
        if (!this.d) {
            this.f970a.a((v.a) new a(), (l.a) new b());
            this.d = true;
        }
        return this.f970a.l();
    }

    public void a(int i, int i2) {
        this.f970a.a((i & i2) | ((i2 ^ -1) & this.f970a.p()));
    }

    public void a(Configuration configuration) {
        super.a(configuration);
    }

    public void a(Drawable drawable) {
        this.f970a.a(drawable);
    }

    public void a(View view) {
        a(view, new C0118a.C0021a(-2, -2));
    }

    public void a(View view, C0118a.C0021a aVar) {
        if (view != null) {
            view.setLayoutParams(aVar);
        }
        this.f970a.a(view);
    }

    public void a(CharSequence charSequence) {
        this.f970a.setTitle(charSequence);
    }

    public boolean a(int i, KeyEvent keyEvent) {
        Menu s = s();
        if (s == null) {
            return false;
        }
        boolean z = true;
        if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() == 1) {
            z = false;
        }
        s.setQwertyMode(z);
        return s.performShortcut(i, keyEvent, 0);
    }

    public boolean a(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1) {
            o();
        }
        return true;
    }

    public void b(int i) {
        this.f970a.c(i);
    }

    public void b(Drawable drawable) {
        this.f970a.b(drawable);
    }

    public void b(CharSequence charSequence) {
        this.f970a.setWindowTitle(charSequence);
    }

    public void b(boolean z) {
        if (z != this.e) {
            this.e = z;
            int size = this.f.size();
            for (int i = 0; i < size; i++) {
                this.f.get(i).onMenuVisibilityChanged(z);
            }
        }
    }

    public void c(int i) {
        this.f970a.setIcon(i);
    }

    public void c(boolean z) {
    }

    public void d(boolean z) {
        a(z ? 4 : 0, 4);
    }

    public void e(boolean z) {
        a(z ? 16 : 0, 16);
    }

    public boolean e() {
        return this.f970a.e();
    }

    public void f(boolean z) {
        a(z ? 8 : 0, 8);
    }

    public boolean f() {
        if (!this.f970a.k()) {
            return false;
        }
        this.f970a.collapseActionView();
        return true;
    }

    public View g() {
        return this.f970a.h();
    }

    public void g(boolean z) {
    }

    public int h() {
        return this.f970a.p();
    }

    public void h(boolean z) {
    }

    public int i() {
        return this.f970a.i();
    }

    public Context j() {
        return this.f970a.o();
    }

    public void k() {
        this.f970a.setVisibility(8);
    }

    public boolean l() {
        this.f970a.n().removeCallbacks(this.g);
        y.a((View) this.f970a.n(), this.g);
        return true;
    }

    public boolean m() {
        return this.f970a.j() == 0;
    }

    /* access modifiers changed from: package-private */
    public void n() {
        this.f970a.n().removeCallbacks(this.g);
    }

    public boolean o() {
        return this.f970a.f();
    }

    public void p() {
        this.f970a.setVisibility(0);
    }

    public Window.Callback q() {
        return this.f972c;
    }

    /* access modifiers changed from: package-private */
    public void r() {
        Menu s = s();
        l lVar = s instanceof l ? (l) s : null;
        if (lVar != null) {
            lVar.s();
        }
        try {
            s.clear();
            if (!this.f972c.onCreatePanelMenu(0, s) || !this.f972c.onPreparePanel(0, (View) null, s)) {
                s.clear();
            }
        } finally {
            if (lVar != null) {
                lVar.r();
            }
        }
    }
}
