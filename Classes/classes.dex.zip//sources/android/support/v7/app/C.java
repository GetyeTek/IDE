package android.support.v7.app;

import android.support.v4.view.C0111h;
import android.view.KeyEvent;

class C implements C0111h.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ D f962a;

    C(D d) {
        this.f962a = d;
    }

    public boolean a(KeyEvent keyEvent) {
        return this.f962a.a(keyEvent);
    }
}
