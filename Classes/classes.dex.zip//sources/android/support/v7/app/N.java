package android.support.v7.app;

import a.b.g.a.f;
import a.b.g.a.j;
import a.b.g.e.b;
import a.b.g.e.g;
import a.b.g.e.i;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.v4.view.J;
import android.support.v4.view.K;
import android.support.v4.view.M;
import android.support.v4.view.y;
import android.support.v7.app.C0118a;
import android.support.v7.view.menu.l;
import android.support.v7.widget.ActionBarContainer;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.ActionBarOverlayLayout;
import android.support.v7.widget.Sa;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.X;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class N extends C0118a implements ActionBarOverlayLayout.a {

    /* renamed from: a  reason: collision with root package name */
    private static final Interpolator f989a = new AccelerateInterpolator();

    /* renamed from: b  reason: collision with root package name */
    private static final Interpolator f990b = new DecelerateInterpolator();
    private boolean A = true;
    i B;
    private boolean C;
    boolean D;
    final K E = new K(this);
    final K F = new L(this);
    final M G = new M(this);

    /* renamed from: c  reason: collision with root package name */
    Context f991c;
    private Context d;
    private Activity e;
    private Dialog f;
    ActionBarOverlayLayout g;
    ActionBarContainer h;
    X i;
    ActionBarContextView j;
    View k;
    Sa l;
    private ArrayList<Object> m = new ArrayList<>();
    private int n = -1;
    private boolean o;
    a p;
    b q;
    b.a r;
    private boolean s;
    private ArrayList<C0118a.b> t = new ArrayList<>();
    private boolean u;
    private int v = 0;
    boolean w = true;
    boolean x;
    boolean y;
    private boolean z;

    public class a extends b implements l.a {

        /* renamed from: c  reason: collision with root package name */
        private final Context f992c;
        private final l d;
        private b.a e;
        private WeakReference<View> f;

        public a(Context context, b.a aVar) {
            this.f992c = context;
            this.e = aVar;
            l lVar = new l(context);
            lVar.c(1);
            this.d = lVar;
            this.d.a((l.a) this);
        }

        public void a() {
            N n = N.this;
            if (n.p == this) {
                if (!N.a(n.x, n.y, false)) {
                    N n2 = N.this;
                    n2.q = this;
                    n2.r = this.e;
                } else {
                    this.e.a(this);
                }
                this.e = null;
                N.this.i(false);
                N.this.j.a();
                N.this.i.n().sendAccessibilityEvent(32);
                N n3 = N.this;
                n3.g.setHideOnContentScrollEnabled(n3.D);
                N.this.p = null;
            }
        }

        public void a(int i) {
            a((CharSequence) N.this.f991c.getResources().getString(i));
        }

        public void a(l lVar) {
            if (this.e != null) {
                i();
                N.this.j.d();
            }
        }

        public void a(View view) {
            N.this.j.setCustomView(view);
            this.f = new WeakReference<>(view);
        }

        public void a(CharSequence charSequence) {
            N.this.j.setSubtitle(charSequence);
        }

        public void a(boolean z) {
            super.a(z);
            N.this.j.setTitleOptional(z);
        }

        public boolean a(l lVar, MenuItem menuItem) {
            b.a aVar = this.e;
            if (aVar != null) {
                return aVar.a((b) this, menuItem);
            }
            return false;
        }

        public View b() {
            WeakReference<View> weakReference = this.f;
            if (weakReference != null) {
                return (View) weakReference.get();
            }
            return null;
        }

        public void b(int i) {
            b((CharSequence) N.this.f991c.getResources().getString(i));
        }

        public void b(CharSequence charSequence) {
            N.this.j.setTitle(charSequence);
        }

        public Menu c() {
            return this.d;
        }

        public MenuInflater d() {
            return new g(this.f992c);
        }

        public CharSequence e() {
            return N.this.j.getSubtitle();
        }

        public CharSequence g() {
            return N.this.j.getTitle();
        }

        public void i() {
            if (N.this.p == this) {
                this.d.s();
                try {
                    this.e.b(this, this.d);
                } finally {
                    this.d.r();
                }
            }
        }

        public boolean j() {
            return N.this.j.b();
        }

        public boolean k() {
            this.d.s();
            try {
                return this.e.a((b) this, (Menu) this.d);
            } finally {
                this.d.r();
            }
        }
    }

    public N(Activity activity, boolean z2) {
        this.e = activity;
        View decorView = activity.getWindow().getDecorView();
        c(decorView);
        if (!z2) {
            this.k = decorView.findViewById(16908290);
        }
    }

    public N(Dialog dialog) {
        this.f = dialog;
        c(dialog.getWindow().getDecorView());
    }

    static boolean a(boolean z2, boolean z3, boolean z4) {
        if (z4) {
            return true;
        }
        return !z2 && !z3;
    }

    private X b(View view) {
        if (view instanceof X) {
            return (X) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Can't make a decor toolbar out of ");
        sb.append(view != null ? view.getClass().getSimpleName() : "null");
        throw new IllegalStateException(sb.toString());
    }

    private void c(View view) {
        this.g = (ActionBarOverlayLayout) view.findViewById(f.decor_content_parent);
        ActionBarOverlayLayout actionBarOverlayLayout = this.g;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        this.i = b(view.findViewById(f.action_bar));
        this.j = (ActionBarContextView) view.findViewById(f.action_context_bar);
        this.h = (ActionBarContainer) view.findViewById(f.action_bar_container);
        X x2 = this.i;
        if (x2 == null || this.j == null || this.h == null) {
            throw new IllegalStateException(N.class.getSimpleName() + " can only be used " + "with a compatible window decor layout");
        }
        this.f991c = x2.o();
        boolean z2 = (this.i.p() & 4) != 0;
        if (z2) {
            this.o = true;
        }
        a.b.g.e.a a2 = a.b.g.e.a.a(this.f991c);
        g(a2.a() || z2);
        m(a2.f());
        TypedArray obtainStyledAttributes = this.f991c.obtainStyledAttributes((AttributeSet) null, j.ActionBar, a.b.g.a.a.actionBarStyle, 0);
        if (obtainStyledAttributes.getBoolean(j.ActionBar_hideOnContentScroll, false)) {
            l(true);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(j.ActionBar_elevation, 0);
        if (dimensionPixelSize != 0) {
            a((float) dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    private void m(boolean z2) {
        this.u = z2;
        if (!this.u) {
            this.i.a((Sa) null);
            this.h.setTabContainer(this.l);
        } else {
            this.h.setTabContainer((Sa) null);
            this.i.a(this.l);
        }
        boolean z3 = true;
        boolean z4 = s() == 2;
        Sa sa = this.l;
        if (sa != null) {
            if (z4) {
                sa.setVisibility(0);
                ActionBarOverlayLayout actionBarOverlayLayout = this.g;
                if (actionBarOverlayLayout != null) {
                    y.C(actionBarOverlayLayout);
                }
            } else {
                sa.setVisibility(8);
            }
        }
        this.i.b(!this.u && z4);
        ActionBarOverlayLayout actionBarOverlayLayout2 = this.g;
        if (this.u || !z4) {
            z3 = false;
        }
        actionBarOverlayLayout2.setHasNonEmbeddedTabs(z3);
    }

    private void n(boolean z2) {
        if (a(this.x, this.y, this.z)) {
            if (!this.A) {
                this.A = true;
                k(z2);
            }
        } else if (this.A) {
            this.A = false;
            j(z2);
        }
    }

    private void t() {
        if (this.z) {
            this.z = false;
            ActionBarOverlayLayout actionBarOverlayLayout = this.g;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(false);
            }
            n(false);
        }
    }

    private boolean u() {
        return y.y(this.h);
    }

    private void v() {
        if (!this.z) {
            this.z = true;
            ActionBarOverlayLayout actionBarOverlayLayout = this.g;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(true);
            }
            n(false);
        }
    }

    public b a(b.a aVar) {
        a aVar2 = this.p;
        if (aVar2 != null) {
            aVar2.a();
        }
        this.g.setHideOnContentScrollEnabled(false);
        this.j.c();
        a aVar3 = new a(this.j.getContext(), aVar);
        if (!aVar3.k()) {
            return null;
        }
        this.p = aVar3;
        aVar3.i();
        this.j.a(aVar3);
        i(true);
        this.j.sendAccessibilityEvent(32);
        return aVar3;
    }

    public void a() {
        if (this.y) {
            this.y = false;
            n(true);
        }
    }

    public void a(float f2) {
        y.a((View) this.h, f2);
    }

    public void a(int i2) {
        this.v = i2;
    }

    public void a(int i2, int i3) {
        int p2 = this.i.p();
        if ((i3 & 4) != 0) {
            this.o = true;
        }
        this.i.a((i2 & i3) | ((i3 ^ -1) & p2));
    }

    public void a(Configuration configuration) {
        m(a.b.g.e.a.a(this.f991c).f());
    }

    public void a(Drawable drawable) {
        this.h.setPrimaryBackground(drawable);
    }

    public void a(View view) {
        this.i.a(view);
    }

    public void a(CharSequence charSequence) {
        this.i.setTitle(charSequence);
    }

    public void a(boolean z2) {
        this.w = z2;
    }

    public boolean a(int i2, KeyEvent keyEvent) {
        Menu c2;
        a aVar = this.p;
        if (aVar == null || (c2 = aVar.c()) == null) {
            return false;
        }
        boolean z2 = true;
        if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() == 1) {
            z2 = false;
        }
        c2.setQwertyMode(z2);
        return c2.performShortcut(i2, keyEvent, 0);
    }

    public void b() {
    }

    public void b(int i2) {
        this.i.c(i2);
    }

    public void b(Drawable drawable) {
        this.i.b(drawable);
    }

    public void b(CharSequence charSequence) {
        this.i.setWindowTitle(charSequence);
    }

    public void b(boolean z2) {
        if (z2 != this.s) {
            this.s = z2;
            int size = this.t.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.t.get(i2).onMenuVisibilityChanged(z2);
            }
        }
    }

    public void c() {
        if (!this.y) {
            this.y = true;
            n(true);
        }
    }

    public void c(int i2) {
        this.i.setIcon(i2);
    }

    public void c(boolean z2) {
        if (!this.o) {
            d(z2);
        }
    }

    public void d() {
        i iVar = this.B;
        if (iVar != null) {
            iVar.a();
            this.B = null;
        }
    }

    public void d(boolean z2) {
        a(z2 ? 4 : 0, 4);
    }

    public void e(boolean z2) {
        a(z2 ? 16 : 0, 16);
    }

    public void f(boolean z2) {
        a(z2 ? 8 : 0, 8);
    }

    public boolean f() {
        X x2 = this.i;
        if (x2 == null || !x2.k()) {
            return false;
        }
        this.i.collapseActionView();
        return true;
    }

    public View g() {
        return this.i.h();
    }

    public void g(boolean z2) {
        this.i.a(z2);
    }

    public int h() {
        return this.i.p();
    }

    public void h(boolean z2) {
        i iVar;
        this.C = z2;
        if (!z2 && (iVar = this.B) != null) {
            iVar.a();
        }
    }

    public int i() {
        return this.h.getHeight();
    }

    public void i(boolean z2) {
        J j2;
        J j3;
        if (z2) {
            v();
        } else {
            t();
        }
        if (u()) {
            if (z2) {
                j2 = this.i.a(4, 100);
                j3 = this.j.a(0, 200);
            } else {
                j3 = this.i.a(0, 200);
                j2 = this.j.a(8, 100);
            }
            i iVar = new i();
            iVar.a(j2, j3);
            iVar.c();
        } else if (z2) {
            this.i.setVisibility(4);
            this.j.setVisibility(0);
        } else {
            this.i.setVisibility(0);
            this.j.setVisibility(8);
        }
    }

    public Context j() {
        if (this.d == null) {
            TypedValue typedValue = new TypedValue();
            this.f991c.getTheme().resolveAttribute(a.b.g.a.a.actionBarWidgetTheme, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                this.d = new ContextThemeWrapper(this.f991c, i2);
            } else {
                this.d = this.f991c;
            }
        }
        return this.d;
    }

    public void j(boolean z2) {
        View view;
        i iVar = this.B;
        if (iVar != null) {
            iVar.a();
        }
        if (this.v != 0 || (!this.C && !z2)) {
            this.E.b((View) null);
            return;
        }
        this.h.setAlpha(1.0f);
        this.h.setTransitioning(true);
        i iVar2 = new i();
        float f2 = (float) (-this.h.getHeight());
        if (z2) {
            int[] iArr = {0, 0};
            this.h.getLocationInWindow(iArr);
            f2 -= (float) iArr[1];
        }
        J a2 = y.a(this.h);
        a2.b(f2);
        a2.a(this.G);
        iVar2.a(a2);
        if (this.w && (view = this.k) != null) {
            J a3 = y.a(view);
            a3.b(f2);
            iVar2.a(a3);
        }
        iVar2.a(f989a);
        iVar2.a(250);
        iVar2.a(this.E);
        this.B = iVar2;
        iVar2.c();
    }

    public void k() {
        if (!this.x) {
            this.x = true;
            n(false);
        }
    }

    public void k(boolean z2) {
        View view;
        View view2;
        i iVar = this.B;
        if (iVar != null) {
            iVar.a();
        }
        this.h.setVisibility(0);
        if (this.v != 0 || (!this.C && !z2)) {
            this.h.setAlpha(1.0f);
            this.h.setTranslationY(0.0f);
            if (this.w && (view = this.k) != null) {
                view.setTranslationY(0.0f);
            }
            this.F.b((View) null);
        } else {
            this.h.setTranslationY(0.0f);
            float f2 = (float) (-this.h.getHeight());
            if (z2) {
                int[] iArr = {0, 0};
                this.h.getLocationInWindow(iArr);
                f2 -= (float) iArr[1];
            }
            this.h.setTranslationY(f2);
            i iVar2 = new i();
            J a2 = y.a(this.h);
            a2.b(0.0f);
            a2.a(this.G);
            iVar2.a(a2);
            if (this.w && (view2 = this.k) != null) {
                view2.setTranslationY(f2);
                J a3 = y.a(this.k);
                a3.b(0.0f);
                iVar2.a(a3);
            }
            iVar2.a(f990b);
            iVar2.a(250);
            iVar2.a(this.F);
            this.B = iVar2;
            iVar2.c();
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.g;
        if (actionBarOverlayLayout != null) {
            y.C(actionBarOverlayLayout);
        }
    }

    public void l(boolean z2) {
        if (!z2 || this.g.i()) {
            this.D = z2;
            this.g.setHideOnContentScrollEnabled(z2);
            return;
        }
        throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
    }

    public boolean m() {
        int i2 = i();
        return this.A && (i2 == 0 || r() < i2);
    }

    public void p() {
        if (this.x) {
            this.x = false;
            n(false);
        }
    }

    /* access modifiers changed from: package-private */
    public void q() {
        b.a aVar = this.r;
        if (aVar != null) {
            aVar.a(this.q);
            this.q = null;
            this.r = null;
        }
    }

    public int r() {
        return this.g.getActionBarHideOffset();
    }

    public int s() {
        return this.i.m();
    }
}
