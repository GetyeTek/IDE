package android.support.v7.app;

import android.support.v4.view.L;
import android.support.v4.view.y;
import android.support.v7.widget.ActionBarOverlayLayout;
import android.view.View;

class K extends L {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ N f986a;

    K(N n) {
        this.f986a = n;
    }

    public void b(View view) {
        View view2;
        N n = this.f986a;
        if (n.w && (view2 = n.k) != null) {
            view2.setTranslationY(0.0f);
            this.f986a.h.setTranslationY(0.0f);
        }
        this.f986a.h.setVisibility(8);
        this.f986a.h.setTransitioning(false);
        N n2 = this.f986a;
        n2.B = null;
        n2.q();
        ActionBarOverlayLayout actionBarOverlayLayout = this.f986a.g;
        if (actionBarOverlayLayout != null) {
            y.C(actionBarOverlayLayout);
        }
    }
}
