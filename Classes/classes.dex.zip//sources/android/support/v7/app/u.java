package android.support.v7.app;

import android.graphics.Rect;
import android.support.v7.widget.C0168ma;

class u implements C0168ma.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z f1037a;

    u(z zVar) {
        this.f1037a = zVar;
    }

    public void a(Rect rect) {
        rect.top = this.f1037a.i(rect.top);
    }
}
