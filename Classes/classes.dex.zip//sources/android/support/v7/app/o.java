package android.support.v7.app;

import a.b.g.e.b;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.C0080b;
import android.support.v4.app.C0093o;
import android.support.v4.app.Z;
import android.support.v4.app.ea;
import android.support.v7.app.C0120c;
import android.support.v7.widget.Bb;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

public class o extends C0093o implements p, ea.a, C0120c.b {
    private q n;
    private int o = 0;
    private Resources p;

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0026, code lost:
        r2 = getWindow();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean a(int r2, android.view.KeyEvent r3) {
        /*
            r1 = this;
            int r2 = android.os.Build.VERSION.SDK_INT
            r0 = 26
            if (r2 >= r0) goto L_0x003e
            boolean r2 = r3.isCtrlPressed()
            if (r2 != 0) goto L_0x003e
            int r2 = r3.getMetaState()
            boolean r2 = android.view.KeyEvent.metaStateHasNoModifiers(r2)
            if (r2 != 0) goto L_0x003e
            int r2 = r3.getRepeatCount()
            if (r2 != 0) goto L_0x003e
            int r2 = r3.getKeyCode()
            boolean r2 = android.view.KeyEvent.isModifierKey(r2)
            if (r2 != 0) goto L_0x003e
            android.view.Window r2 = r1.getWindow()
            if (r2 == 0) goto L_0x003e
            android.view.View r0 = r2.getDecorView()
            if (r0 == 0) goto L_0x003e
            android.view.View r2 = r2.getDecorView()
            boolean r2 = r2.dispatchKeyShortcutEvent(r3)
            if (r2 == 0) goto L_0x003e
            r2 = 1
            return r2
        L_0x003e:
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.o.a(int, android.view.KeyEvent):boolean");
    }

    public void B() {
        C().g();
    }

    public q C() {
        if (this.n == null) {
            this.n = q.a((Activity) this, (p) this);
        }
        return this.n;
    }

    public C0118a D() {
        return C().e();
    }

    @Deprecated
    public void E() {
    }

    public boolean F() {
        Intent m = m();
        if (m == null) {
            return false;
        }
        if (b(m)) {
            ea a2 = ea.a((Context) this);
            a(a2);
            b(a2);
            a2.a();
            try {
                C0080b.a(this);
                return true;
            } catch (IllegalStateException unused) {
                finish();
                return true;
            }
        } else {
            a(m);
            return true;
        }
    }

    public b a(b.a aVar) {
        return null;
    }

    public void a(b bVar) {
    }

    public void a(Intent intent) {
        Z.a((Activity) this, intent);
    }

    public void a(ea eaVar) {
        eaVar.a((Activity) this);
    }

    public void a(Toolbar toolbar) {
        C().a(toolbar);
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        C().a(view, layoutParams);
    }

    public void b(b bVar) {
    }

    public void b(ea eaVar) {
    }

    public boolean b(Intent intent) {
        return Z.b((Activity) this, intent);
    }

    public void closeOptionsMenu() {
        C0118a D = D();
        if (!getWindow().hasFeature(0)) {
            return;
        }
        if (D == null || !D.e()) {
            super.closeOptionsMenu();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        C0118a D = D();
        if (keyCode != 82 || D == null || !D.a(keyEvent)) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    public C0120c.a f() {
        return C().c();
    }

    public <T extends View> T findViewById(int i) {
        return C().a(i);
    }

    public MenuInflater getMenuInflater() {
        return C().d();
    }

    public Resources getResources() {
        if (this.p == null && Bb.b()) {
            this.p = new Bb(this, super.getResources());
        }
        Resources resources = this.p;
        return resources == null ? super.getResources() : resources;
    }

    public void invalidateOptionsMenu() {
        C().g();
    }

    public Intent m() {
        return Z.a(this);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C().a(configuration);
        if (this.p != null) {
            this.p.updateConfiguration(configuration, super.getResources().getDisplayMetrics());
        }
    }

    public void onContentChanged() {
        E();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        int i;
        q C = C();
        C.f();
        C.a(bundle);
        if (C.a() && (i = this.o) != 0) {
            if (Build.VERSION.SDK_INT >= 23) {
                onApplyThemeResource(getTheme(), this.o, false);
            } else {
                setTheme(i);
            }
        }
        super.onCreate(bundle);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        C().h();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (a(i, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        C0118a D = D();
        if (menuItem.getItemId() != 16908332 || D == null || (D.h() & 4) == 0) {
            return false;
        }
        return F();
    }

    public boolean onMenuOpened(int i, Menu menu) {
        return super.onMenuOpened(i, menu);
    }

    public void onPanelClosed(int i, Menu menu) {
        super.onPanelClosed(i, menu);
    }

    /* access modifiers changed from: protected */
    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        C().b(bundle);
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        C().i();
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        C().c(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        C().j();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        C().k();
    }

    /* access modifiers changed from: protected */
    public void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        C().a(charSequence);
    }

    public void openOptionsMenu() {
        C0118a D = D();
        if (!getWindow().hasFeature(0)) {
            return;
        }
        if (D == null || !D.o()) {
            super.openOptionsMenu();
        }
    }

    public void setContentView(int i) {
        C().c(i);
    }

    public void setContentView(View view) {
        C().a(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        C().b(view, layoutParams);
    }

    public void setTheme(int i) {
        super.setTheme(i);
        this.o = i;
    }
}
