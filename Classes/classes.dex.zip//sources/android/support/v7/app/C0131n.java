package android.support.v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AlertController;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;

/* renamed from: android.support.v7.app.n  reason: case insensitive filesystem */
public class C0131n extends D implements DialogInterface {

    /* renamed from: c  reason: collision with root package name */
    final AlertController f1030c = new AlertController(getContext(), this, getWindow());

    /* renamed from: android.support.v7.app.n$a */
    public static class a {

        /* renamed from: a  reason: collision with root package name */
        private final AlertController.a f1031a;

        /* renamed from: b  reason: collision with root package name */
        private final int f1032b;

        public a(Context context) {
            this(context, C0131n.a(context, 0));
        }

        public a(Context context, int i) {
            this.f1031a = new AlertController.a(new ContextThemeWrapper(context, C0131n.a(context, i)));
            this.f1032b = i;
        }

        public a a(DialogInterface.OnKeyListener onKeyListener) {
            this.f1031a.u = onKeyListener;
            return this;
        }

        public a a(Drawable drawable) {
            this.f1031a.d = drawable;
            return this;
        }

        public a a(View view) {
            this.f1031a.g = view;
            return this;
        }

        public a a(ListAdapter listAdapter, DialogInterface.OnClickListener onClickListener) {
            AlertController.a aVar = this.f1031a;
            aVar.w = listAdapter;
            aVar.x = onClickListener;
            return this;
        }

        public a a(CharSequence charSequence) {
            this.f1031a.f = charSequence;
            return this;
        }

        public C0131n a() {
            C0131n nVar = new C0131n(this.f1031a.f954a, this.f1032b);
            this.f1031a.a(nVar.f1030c);
            nVar.setCancelable(this.f1031a.r);
            if (this.f1031a.r) {
                nVar.setCanceledOnTouchOutside(true);
            }
            nVar.setOnCancelListener(this.f1031a.s);
            nVar.setOnDismissListener(this.f1031a.t);
            DialogInterface.OnKeyListener onKeyListener = this.f1031a.u;
            if (onKeyListener != null) {
                nVar.setOnKeyListener(onKeyListener);
            }
            return nVar;
        }

        public Context b() {
            return this.f1031a.f954a;
        }
    }

    protected C0131n(Context context, int i) {
        super(context, a(context, i));
    }

    static int a(Context context, int i) {
        if (((i >>> 24) & 255) >= 1) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(a.b.g.a.a.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f1030c.a();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (this.f1030c.a(i, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (this.f1030c.b(i, keyEvent)) {
            return true;
        }
        return super.onKeyUp(i, keyEvent);
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f1030c.b(charSequence);
    }
}
