package android.support.v7.app;

class s implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z f1035a;

    s(z zVar) {
        this.f1035a = zVar;
    }

    public void run() {
        z zVar = this.f1035a;
        if ((zVar.P & 1) != 0) {
            zVar.e(0);
        }
        z zVar2 = this.f1035a;
        if ((zVar2.P & 4096) != 0) {
            zVar2.e(108);
        }
        z zVar3 = this.f1035a;
        zVar3.O = false;
        zVar3.P = 0;
    }
}
