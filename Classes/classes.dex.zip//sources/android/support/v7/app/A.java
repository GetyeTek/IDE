package android.support.v7.app;

import android.support.v4.view.K;
import android.support.v4.view.L;
import android.support.v4.view.y;
import android.support.v7.app.z;
import android.view.View;
import android.widget.PopupWindow;

class A extends L {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z.c f948a;

    A(z.c cVar) {
        this.f948a = cVar;
    }

    public void b(View view) {
        z.this.q.setVisibility(8);
        z zVar = z.this;
        PopupWindow popupWindow = zVar.r;
        if (popupWindow != null) {
            popupWindow.dismiss();
        } else if (zVar.q.getParent() instanceof View) {
            y.C((View) z.this.q.getParent());
        }
        z.this.q.removeAllViews();
        z.this.t.a((K) null);
        z.this.t = null;
    }
}
