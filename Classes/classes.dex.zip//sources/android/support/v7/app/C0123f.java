package android.support.v7.app;

import android.support.v4.widget.NestedScrollView;
import android.view.View;

/* renamed from: android.support.v7.app.f  reason: case insensitive filesystem */
class C0123f implements NestedScrollView.b {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ View f1008a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ View f1009b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ AlertController f1010c;

    C0123f(AlertController alertController, View view, View view2) {
        this.f1010c = alertController;
        this.f1008a = view;
        this.f1009b = view2;
    }

    public void a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4) {
        AlertController.a(nestedScrollView, this.f1008a, this.f1009b);
    }
}
