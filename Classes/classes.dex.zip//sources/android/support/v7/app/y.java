package android.support.v7.app;

import android.support.v4.view.K;
import android.support.v4.view.L;
import android.view.View;

class y extends L {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z f1041a;

    y(z zVar) {
        this.f1041a = zVar;
    }

    public void b(View view) {
        this.f1041a.q.setAlpha(1.0f);
        this.f1041a.t.a((K) null);
        this.f1041a.t = null;
    }

    public void c(View view) {
        this.f1041a.q.setVisibility(0);
        this.f1041a.q.sendAccessibilityEvent(32);
        if (this.f1041a.q.getParent() instanceof View) {
            android.support.v4.view.y.C((View) this.f1041a.q.getParent());
        }
    }
}
