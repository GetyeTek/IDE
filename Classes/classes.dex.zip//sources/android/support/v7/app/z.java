package android.support.v7.app;

import a.b.g.a.i;
import a.b.g.e.b;
import a.b.g.e.f;
import a.b.g.e.j;
import android.app.Activity;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Z;
import android.support.v4.view.C0111h;
import android.support.v4.view.C0112i;
import android.support.v4.view.J;
import android.support.v4.view.K;
import android.support.v4.view.s;
import android.support.v4.view.y;
import android.support.v7.app.C0120c;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.v;
import android.support.v7.view.menu.w;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.Bb;
import android.support.v7.widget.C0168ma;
import android.support.v7.widget.C0175q;
import android.support.v7.widget.ContentFrameLayout;
import android.support.v7.widget.Eb;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.W;
import android.support.v7.widget.ob;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

class z extends q implements l.a, LayoutInflater.Factory2 {

    /* renamed from: b  reason: collision with root package name */
    private static final boolean f1042b = (Build.VERSION.SDK_INT < 21);

    /* renamed from: c  reason: collision with root package name */
    private static final int[] f1043c = {16842836};
    private static boolean d = true;
    private boolean A;
    boolean B;
    boolean C;
    boolean D;
    boolean E;
    boolean F;
    private boolean G;
    private g[] H;
    private g I;
    private boolean J;
    boolean K;
    private int L = -100;
    private boolean M;
    private e N;
    boolean O;
    int P;
    private final Runnable Q = new s(this);
    private boolean R;
    private Rect S;
    private Rect T;
    private AppCompatViewInflater U;
    final Context e;
    final Window f;
    final Window.Callback g;
    final Window.Callback h;
    final p i;
    C0118a j;
    MenuInflater k;
    private CharSequence l;
    private W m;
    private b n;
    private h o;
    a.b.g.e.b p;
    ActionBarContextView q;
    PopupWindow r;
    Runnable s;
    J t = null;
    private boolean u = true;
    private boolean v;
    private ViewGroup w;
    private TextView x;
    private View y;
    private boolean z;

    private class a implements C0120c.a {
        a() {
        }

        public void a(int i) {
            C0118a e = z.this.e();
            if (e != null) {
                e.b(i);
            }
        }

        public void a(Drawable drawable, int i) {
            C0118a e = z.this.e();
            if (e != null) {
                e.b(drawable);
                e.b(i);
            }
        }

        public boolean a() {
            C0118a e = z.this.e();
            return (e == null || (e.h() & 4) == 0) ? false : true;
        }

        public Context b() {
            return z.this.n();
        }

        public Drawable c() {
            ob a2 = ob.a(b(), (AttributeSet) null, new int[]{a.b.g.a.a.homeAsUpIndicator});
            Drawable b2 = a2.b(0);
            a2.a();
            return b2;
        }
    }

    private final class b implements v.a {
        b() {
        }

        public void a(l lVar, boolean z) {
            z.this.b(lVar);
        }

        public boolean a(l lVar) {
            Window.Callback p = z.this.p();
            if (p == null) {
                return true;
            }
            p.onMenuOpened(108, lVar);
            return true;
        }
    }

    class c implements b.a {

        /* renamed from: a  reason: collision with root package name */
        private b.a f1046a;

        public c(b.a aVar) {
            this.f1046a = aVar;
        }

        public void a(a.b.g.e.b bVar) {
            this.f1046a.a(bVar);
            z zVar = z.this;
            if (zVar.r != null) {
                zVar.f.getDecorView().removeCallbacks(z.this.s);
            }
            z zVar2 = z.this;
            if (zVar2.q != null) {
                zVar2.m();
                z zVar3 = z.this;
                J a2 = y.a(zVar3.q);
                a2.a(0.0f);
                zVar3.t = a2;
                z.this.t.a((K) new A(this));
            }
            z zVar4 = z.this;
            p pVar = zVar4.i;
            if (pVar != null) {
                pVar.a(zVar4.p);
            }
            z.this.p = null;
        }

        public boolean a(a.b.g.e.b bVar, Menu menu) {
            return this.f1046a.a(bVar, menu);
        }

        public boolean a(a.b.g.e.b bVar, MenuItem menuItem) {
            return this.f1046a.a(bVar, menuItem);
        }

        public boolean b(a.b.g.e.b bVar, Menu menu) {
            return this.f1046a.b(bVar, menu);
        }
    }

    class d extends j {
        d(Window.Callback callback) {
            super(callback);
        }

        /* access modifiers changed from: package-private */
        public final ActionMode a(ActionMode.Callback callback) {
            f.a aVar = new f.a(z.this.e, callback);
            a.b.g.e.b a2 = z.this.a((b.a) aVar);
            if (a2 != null) {
                return aVar.b(a2);
            }
            return null;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return z.this.a(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || z.this.b(keyEvent.getKeyCode(), keyEvent);
        }

        public void onContentChanged() {
        }

        public boolean onCreatePanelMenu(int i, Menu menu) {
            if (i != 0 || (menu instanceof l)) {
                return super.onCreatePanelMenu(i, menu);
            }
            return false;
        }

        public boolean onMenuOpened(int i, Menu menu) {
            super.onMenuOpened(i, menu);
            z.this.g(i);
            return true;
        }

        public void onPanelClosed(int i, Menu menu) {
            super.onPanelClosed(i, menu);
            z.this.h(i);
        }

        public boolean onPreparePanel(int i, View view, Menu menu) {
            l lVar = menu instanceof l ? (l) menu : null;
            if (i == 0 && lVar == null) {
                return false;
            }
            if (lVar != null) {
                lVar.c(true);
            }
            boolean onPreparePanel = super.onPreparePanel(i, view, menu);
            if (lVar != null) {
                lVar.c(false);
            }
            return onPreparePanel;
        }

        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i) {
            l lVar;
            g a2 = z.this.a(0, true);
            if (a2 == null || (lVar = a2.j) == null) {
                super.onProvideKeyboardShortcuts(list, menu, i);
            } else {
                super.onProvideKeyboardShortcuts(list, lVar, i);
            }
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (Build.VERSION.SDK_INT >= 23) {
                return null;
            }
            return z.this.q() ? a(callback) : super.onWindowStartingActionMode(callback);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i) {
            return (!z.this.q() || i != 0) ? super.onWindowStartingActionMode(callback, i) : a(callback);
        }
    }

    final class e {

        /* renamed from: a  reason: collision with root package name */
        private J f1049a;

        /* renamed from: b  reason: collision with root package name */
        private boolean f1050b;

        /* renamed from: c  reason: collision with root package name */
        private BroadcastReceiver f1051c;
        private IntentFilter d;

        e(J j) {
            this.f1049a = j;
            this.f1050b = j.a();
        }

        /* access modifiers changed from: package-private */
        public void a() {
            BroadcastReceiver broadcastReceiver = this.f1051c;
            if (broadcastReceiver != null) {
                z.this.e.unregisterReceiver(broadcastReceiver);
                this.f1051c = null;
            }
        }

        /* access modifiers changed from: package-private */
        public void b() {
            boolean a2 = this.f1049a.a();
            if (a2 != this.f1050b) {
                this.f1050b = a2;
                z.this.a();
            }
        }

        /* access modifiers changed from: package-private */
        public int c() {
            this.f1050b = this.f1049a.a();
            return this.f1050b ? 2 : 1;
        }

        /* access modifiers changed from: package-private */
        public void d() {
            a();
            if (this.f1051c == null) {
                this.f1051c = new B(this);
            }
            if (this.d == null) {
                this.d = new IntentFilter();
                this.d.addAction("android.intent.action.TIME_SET");
                this.d.addAction("android.intent.action.TIMEZONE_CHANGED");
                this.d.addAction("android.intent.action.TIME_TICK");
            }
            z.this.e.registerReceiver(this.f1051c, this.d);
        }
    }

    private class f extends ContentFrameLayout {
        public f(Context context) {
            super(context);
        }

        private boolean a(int i2, int i3) {
            return i2 < -5 || i3 < -5 || i2 > getWidth() + 5 || i3 > getHeight() + 5;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return z.this.a(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() != 0 || !a((int) motionEvent.getX(), (int) motionEvent.getY())) {
                return super.onInterceptTouchEvent(motionEvent);
            }
            z.this.d(0);
            return true;
        }

        public void setBackgroundResource(int i2) {
            setBackgroundDrawable(a.b.g.b.a.a.b(getContext(), i2));
        }
    }

    protected static final class g {

        /* renamed from: a  reason: collision with root package name */
        int f1052a;

        /* renamed from: b  reason: collision with root package name */
        int f1053b;

        /* renamed from: c  reason: collision with root package name */
        int f1054c;
        int d;
        int e;
        int f;
        ViewGroup g;
        View h;
        View i;
        l j;
        android.support.v7.view.menu.j k;
        Context l;
        boolean m;
        boolean n;
        boolean o;
        public boolean p;
        boolean q = false;
        boolean r;
        Bundle s;

        g(int i2) {
            this.f1052a = i2;
        }

        /* access modifiers changed from: package-private */
        public w a(v.a aVar) {
            if (this.j == null) {
                return null;
            }
            if (this.k == null) {
                this.k = new android.support.v7.view.menu.j(this.l, a.b.g.a.g.abc_list_menu_item_layout);
                this.k.a(aVar);
                this.j.a((v) this.k);
            }
            return this.k.a(this.g);
        }

        /* access modifiers changed from: package-private */
        public void a(Context context) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme newTheme = context.getResources().newTheme();
            newTheme.setTo(context.getTheme());
            newTheme.resolveAttribute(a.b.g.a.a.actionBarPopupTheme, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                newTheme.applyStyle(i2, true);
            }
            newTheme.resolveAttribute(a.b.g.a.a.panelMenuListTheme, typedValue, true);
            int i3 = typedValue.resourceId;
            if (i3 == 0) {
                i3 = i.Theme_AppCompat_CompactMenu;
            }
            newTheme.applyStyle(i3, true);
            a.b.g.e.d dVar = new a.b.g.e.d(context, 0);
            dVar.getTheme().setTo(newTheme);
            this.l = dVar;
            TypedArray obtainStyledAttributes = dVar.obtainStyledAttributes(a.b.g.a.j.AppCompatTheme);
            this.f1053b = obtainStyledAttributes.getResourceId(a.b.g.a.j.AppCompatTheme_panelBackground, 0);
            this.f = obtainStyledAttributes.getResourceId(a.b.g.a.j.AppCompatTheme_android_windowAnimationStyle, 0);
            obtainStyledAttributes.recycle();
        }

        /* access modifiers changed from: package-private */
        public void a(l lVar) {
            android.support.v7.view.menu.j jVar;
            l lVar2 = this.j;
            if (lVar != lVar2) {
                if (lVar2 != null) {
                    lVar2.b((v) this.k);
                }
                this.j = lVar;
                if (lVar != null && (jVar = this.k) != null) {
                    lVar.a((v) jVar);
                }
            }
        }

        public boolean a() {
            if (this.h == null) {
                return false;
            }
            return this.i != null || this.k.c().getCount() > 0;
        }
    }

    private final class h implements v.a {
        h() {
        }

        public void a(l lVar, boolean z) {
            l m = lVar.m();
            boolean z2 = m != lVar;
            z zVar = z.this;
            if (z2) {
                lVar = m;
            }
            g a2 = zVar.a((Menu) lVar);
            if (a2 == null) {
                return;
            }
            if (z2) {
                z.this.a(a2.f1052a, a2, m);
                z.this.a(a2, true);
                return;
            }
            z.this.a(a2, z);
        }

        public boolean a(l lVar) {
            Window.Callback p;
            if (lVar != null) {
                return true;
            }
            z zVar = z.this;
            if (!zVar.B || (p = zVar.p()) == null || z.this.K) {
                return true;
            }
            p.onMenuOpened(108, lVar);
            return true;
        }
    }

    static {
        if (f1042b && !d) {
            Thread.setDefaultUncaughtExceptionHandler(new r(Thread.getDefaultUncaughtExceptionHandler()));
        }
    }

    z(Context context, Window window, p pVar) {
        this.e = context;
        this.f = window;
        this.i = pVar;
        this.g = this.f.getCallback();
        Window.Callback callback = this.g;
        if (!(callback instanceof d)) {
            this.h = new d(callback);
            this.f.setCallback(this.h);
            ob a2 = ob.a(context, (AttributeSet) null, f1043c);
            Drawable c2 = a2.c(0);
            if (c2 != null) {
                this.f.setBackgroundDrawable(c2);
            }
            a2.a();
            return;
        }
        throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }

    private boolean A() {
        if (this.M) {
            Context context = this.e;
            if (context instanceof Activity) {
                try {
                    return (context.getPackageManager().getActivityInfo(new ComponentName(this.e, this.e.getClass()), 0).configChanges & 512) == 0;
                } catch (PackageManager.NameNotFoundException e2) {
                    Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e2);
                    return true;
                }
            }
        }
        return false;
    }

    private void B() {
        if (this.v) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    private void a(g gVar, KeyEvent keyEvent) {
        int i2;
        ViewGroup.LayoutParams layoutParams;
        if (!gVar.o && !this.K) {
            if (gVar.f1052a == 0) {
                if ((this.e.getResources().getConfiguration().screenLayout & 15) == 4) {
                    return;
                }
            }
            Window.Callback p2 = p();
            if (p2 == null || p2.onMenuOpened(gVar.f1052a, gVar.j)) {
                WindowManager windowManager = (WindowManager) this.e.getSystemService("window");
                if (windowManager != null && b(gVar, keyEvent)) {
                    if (gVar.g == null || gVar.q) {
                        ViewGroup viewGroup = gVar.g;
                        if (viewGroup == null) {
                            if (!b(gVar) || gVar.g == null) {
                                return;
                            }
                        } else if (gVar.q && viewGroup.getChildCount() > 0) {
                            gVar.g.removeAllViews();
                        }
                        if (a(gVar) && gVar.a()) {
                            ViewGroup.LayoutParams layoutParams2 = gVar.h.getLayoutParams();
                            if (layoutParams2 == null) {
                                layoutParams2 = new ViewGroup.LayoutParams(-2, -2);
                            }
                            gVar.g.setBackgroundResource(gVar.f1053b);
                            ViewParent parent = gVar.h.getParent();
                            if (parent != null && (parent instanceof ViewGroup)) {
                                ((ViewGroup) parent).removeView(gVar.h);
                            }
                            gVar.g.addView(gVar.h, layoutParams2);
                            if (!gVar.h.hasFocus()) {
                                gVar.h.requestFocus();
                            }
                        } else {
                            return;
                        }
                    } else {
                        View view = gVar.i;
                        if (!(view == null || (layoutParams = view.getLayoutParams()) == null || layoutParams.width != -1)) {
                            i2 = -1;
                            gVar.n = false;
                            WindowManager.LayoutParams layoutParams3 = new WindowManager.LayoutParams(i2, -2, gVar.d, gVar.e, 1002, 8519680, -3);
                            layoutParams3.gravity = gVar.f1054c;
                            layoutParams3.windowAnimations = gVar.f;
                            windowManager.addView(gVar.g, layoutParams3);
                            gVar.o = true;
                            return;
                        }
                    }
                    i2 = -2;
                    gVar.n = false;
                    WindowManager.LayoutParams layoutParams32 = new WindowManager.LayoutParams(i2, -2, gVar.d, gVar.e, 1002, 8519680, -3);
                    layoutParams32.gravity = gVar.f1054c;
                    layoutParams32.windowAnimations = gVar.f;
                    windowManager.addView(gVar.g, layoutParams32);
                    gVar.o = true;
                    return;
                }
                return;
            }
            a(gVar, true);
        }
    }

    private void a(l lVar, boolean z2) {
        W w2 = this.m;
        if (w2 == null || !w2.c() || (ViewConfiguration.get(this.e).hasPermanentMenuKey() && !this.m.d())) {
            g a2 = a(0, true);
            a2.q = true;
            a(a2, false);
            a(a2, (KeyEvent) null);
            return;
        }
        Window.Callback p2 = p();
        if (this.m.a() && z2) {
            this.m.e();
            if (!this.K) {
                p2.onPanelClosed(108, a(0, true).j);
            }
        } else if (p2 != null && !this.K) {
            if (this.O && (this.P & 1) != 0) {
                this.f.getDecorView().removeCallbacks(this.Q);
                this.Q.run();
            }
            g a3 = a(0, true);
            l lVar2 = a3.j;
            if (lVar2 != null && !a3.r && p2.onPreparePanel(0, a3.i, lVar2)) {
                p2.onMenuOpened(108, a3.j);
                this.m.f();
            }
        }
    }

    private boolean a(g gVar) {
        View view = gVar.i;
        if (view != null) {
            gVar.h = view;
            return true;
        } else if (gVar.j == null) {
            return false;
        } else {
            if (this.o == null) {
                this.o = new h();
            }
            gVar.h = (View) gVar.a((v.a) this.o);
            return gVar.h != null;
        }
    }

    private boolean a(g gVar, int i2, KeyEvent keyEvent, int i3) {
        l lVar;
        boolean z2 = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((gVar.m || b(gVar, keyEvent)) && (lVar = gVar.j) != null) {
            z2 = lVar.performShortcut(i2, keyEvent, i3);
        }
        if (z2 && (i3 & 1) == 0 && this.m == null) {
            a(gVar, true);
        }
        return z2;
    }

    private boolean a(ViewParent viewParent) {
        if (viewParent == null) {
            return false;
        }
        View decorView = this.f.getDecorView();
        while (viewParent != null) {
            if (viewParent == decorView || !(viewParent instanceof View) || y.x((View) viewParent)) {
                return false;
            }
            viewParent = viewParent.getParent();
        }
        return true;
    }

    private boolean b(g gVar) {
        gVar.a(n());
        gVar.g = new f(gVar.l);
        gVar.f1054c = 81;
        return true;
    }

    private boolean b(g gVar, KeyEvent keyEvent) {
        W w2;
        W w3;
        W w4;
        if (this.K) {
            return false;
        }
        if (gVar.m) {
            return true;
        }
        g gVar2 = this.I;
        if (!(gVar2 == null || gVar2 == gVar)) {
            a(gVar2, false);
        }
        Window.Callback p2 = p();
        if (p2 != null) {
            gVar.i = p2.onCreatePanelView(gVar.f1052a);
        }
        int i2 = gVar.f1052a;
        boolean z2 = i2 == 0 || i2 == 108;
        if (z2 && (w4 = this.m) != null) {
            w4.b();
        }
        if (gVar.i == null && (!z2 || !(s() instanceof H))) {
            if (gVar.j == null || gVar.r) {
                if (gVar.j == null && (!c(gVar) || gVar.j == null)) {
                    return false;
                }
                if (z2 && this.m != null) {
                    if (this.n == null) {
                        this.n = new b();
                    }
                    this.m.a(gVar.j, this.n);
                }
                gVar.j.s();
                if (!p2.onCreatePanelMenu(gVar.f1052a, gVar.j)) {
                    gVar.a((l) null);
                    if (z2 && (w3 = this.m) != null) {
                        w3.a((Menu) null, this.n);
                    }
                    return false;
                }
                gVar.r = false;
            }
            gVar.j.s();
            Bundle bundle = gVar.s;
            if (bundle != null) {
                gVar.j.a(bundle);
                gVar.s = null;
            }
            if (!p2.onPreparePanel(0, gVar.i, gVar.j)) {
                if (z2 && (w2 = this.m) != null) {
                    w2.a((Menu) null, this.n);
                }
                gVar.j.r();
                return false;
            }
            gVar.p = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1;
            gVar.j.setQwertyMode(gVar.p);
            gVar.j.r();
        }
        gVar.m = true;
        gVar.n = false;
        this.I = gVar;
        return true;
    }

    private boolean c(g gVar) {
        Context context = this.e;
        int i2 = gVar.f1052a;
        if ((i2 == 0 || i2 == 108) && this.m != null) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme = context.getTheme();
            theme.resolveAttribute(a.b.g.a.a.actionBarTheme, typedValue, true);
            Resources.Theme theme2 = null;
            if (typedValue.resourceId != 0) {
                theme2 = context.getResources().newTheme();
                theme2.setTo(theme);
                theme2.applyStyle(typedValue.resourceId, true);
                theme2.resolveAttribute(a.b.g.a.a.actionBarWidgetTheme, typedValue, true);
            } else {
                theme.resolveAttribute(a.b.g.a.a.actionBarWidgetTheme, typedValue, true);
            }
            if (typedValue.resourceId != 0) {
                if (theme2 == null) {
                    theme2 = context.getResources().newTheme();
                    theme2.setTo(theme);
                }
                theme2.applyStyle(typedValue.resourceId, true);
            }
            if (theme2 != null) {
                a.b.g.e.d dVar = new a.b.g.e.d(context, 0);
                dVar.getTheme().setTo(theme2);
                context = dVar;
            }
        }
        l lVar = new l(context);
        lVar.a((l.a) this);
        gVar.a(lVar);
        return true;
    }

    private boolean d(int i2, KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() != 0) {
            return false;
        }
        g a2 = a(i2, true);
        if (!a2.o) {
            return b(a2, keyEvent);
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x006c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean e(int r4, android.view.KeyEvent r5) {
        /*
            r3 = this;
            a.b.g.e.b r0 = r3.p
            r1 = 0
            if (r0 == 0) goto L_0x0006
            return r1
        L_0x0006:
            r0 = 1
            android.support.v7.app.z$g r2 = r3.a((int) r4, (boolean) r0)
            if (r4 != 0) goto L_0x0043
            android.support.v7.widget.W r4 = r3.m
            if (r4 == 0) goto L_0x0043
            boolean r4 = r4.c()
            if (r4 == 0) goto L_0x0043
            android.content.Context r4 = r3.e
            android.view.ViewConfiguration r4 = android.view.ViewConfiguration.get(r4)
            boolean r4 = r4.hasPermanentMenuKey()
            if (r4 != 0) goto L_0x0043
            android.support.v7.widget.W r4 = r3.m
            boolean r4 = r4.a()
            if (r4 != 0) goto L_0x003c
            boolean r4 = r3.K
            if (r4 != 0) goto L_0x0063
            boolean r4 = r3.b((android.support.v7.app.z.g) r2, (android.view.KeyEvent) r5)
            if (r4 == 0) goto L_0x0063
            android.support.v7.widget.W r4 = r3.m
            boolean r4 = r4.f()
            goto L_0x006a
        L_0x003c:
            android.support.v7.widget.W r4 = r3.m
            boolean r4 = r4.e()
            goto L_0x006a
        L_0x0043:
            boolean r4 = r2.o
            if (r4 != 0) goto L_0x0065
            boolean r4 = r2.n
            if (r4 == 0) goto L_0x004c
            goto L_0x0065
        L_0x004c:
            boolean r4 = r2.m
            if (r4 == 0) goto L_0x0063
            boolean r4 = r2.r
            if (r4 == 0) goto L_0x005b
            r2.m = r1
            boolean r4 = r3.b((android.support.v7.app.z.g) r2, (android.view.KeyEvent) r5)
            goto L_0x005c
        L_0x005b:
            r4 = 1
        L_0x005c:
            if (r4 == 0) goto L_0x0063
            r3.a((android.support.v7.app.z.g) r2, (android.view.KeyEvent) r5)
            r4 = 1
            goto L_0x006a
        L_0x0063:
            r4 = 0
            goto L_0x006a
        L_0x0065:
            boolean r4 = r2.o
            r3.a((android.support.v7.app.z.g) r2, (boolean) r0)
        L_0x006a:
            if (r4 == 0) goto L_0x0083
            android.content.Context r5 = r3.e
            java.lang.String r0 = "audio"
            java.lang.Object r5 = r5.getSystemService(r0)
            android.media.AudioManager r5 = (android.media.AudioManager) r5
            if (r5 == 0) goto L_0x007c
            r5.playSoundEffect(r1)
            goto L_0x0083
        L_0x007c:
            java.lang.String r5 = "AppCompatDelegate"
            java.lang.String r0 = "Couldn't get audio manager"
            android.util.Log.w(r5, r0)
        L_0x0083:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.z.e(int, android.view.KeyEvent):boolean");
    }

    private void j(int i2) {
        this.P = (1 << i2) | this.P;
        if (!this.O) {
            y.a(this.f.getDecorView(), this.Q);
            this.O = true;
        }
    }

    private int k(int i2) {
        if (i2 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            return 108;
        } else if (i2 != 9) {
            return i2;
        } else {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            return 109;
        }
    }

    private boolean l(int i2) {
        Resources resources = this.e.getResources();
        Configuration configuration = resources.getConfiguration();
        int i3 = configuration.uiMode & 48;
        int i4 = i2 == 2 ? 32 : 16;
        if (i3 == i4) {
            return false;
        }
        if (A()) {
            ((Activity) this.e).recreate();
            return true;
        }
        Configuration configuration2 = new Configuration(configuration);
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        configuration2.uiMode = i4 | (configuration2.uiMode & -49);
        resources.updateConfiguration(configuration2, displayMetrics);
        if (Build.VERSION.SDK_INT >= 26) {
            return true;
        }
        E.a(resources);
        return true;
    }

    private void u() {
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) this.w.findViewById(16908290);
        View decorView = this.f.getDecorView();
        contentFrameLayout.a(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        TypedArray obtainStyledAttributes = this.e.obtainStyledAttributes(a.b.g.a.j.AppCompatTheme);
        obtainStyledAttributes.getValue(a.b.g.a.j.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
        obtainStyledAttributes.getValue(a.b.g.a.j.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
        if (obtainStyledAttributes.hasValue(a.b.g.a.j.AppCompatTheme_windowFixedWidthMajor)) {
            obtainStyledAttributes.getValue(a.b.g.a.j.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor());
        }
        if (obtainStyledAttributes.hasValue(a.b.g.a.j.AppCompatTheme_windowFixedWidthMinor)) {
            obtainStyledAttributes.getValue(a.b.g.a.j.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor());
        }
        if (obtainStyledAttributes.hasValue(a.b.g.a.j.AppCompatTheme_windowFixedHeightMajor)) {
            obtainStyledAttributes.getValue(a.b.g.a.j.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor());
        }
        if (obtainStyledAttributes.hasValue(a.b.g.a.j.AppCompatTheme_windowFixedHeightMinor)) {
            obtainStyledAttributes.getValue(a.b.g.a.j.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor());
        }
        obtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }

    private ViewGroup v() {
        ViewGroup viewGroup;
        TypedArray obtainStyledAttributes = this.e.obtainStyledAttributes(a.b.g.a.j.AppCompatTheme);
        if (obtainStyledAttributes.hasValue(a.b.g.a.j.AppCompatTheme_windowActionBar)) {
            if (obtainStyledAttributes.getBoolean(a.b.g.a.j.AppCompatTheme_windowNoTitle, false)) {
                b(1);
            } else if (obtainStyledAttributes.getBoolean(a.b.g.a.j.AppCompatTheme_windowActionBar, false)) {
                b(108);
            }
            if (obtainStyledAttributes.getBoolean(a.b.g.a.j.AppCompatTheme_windowActionBarOverlay, false)) {
                b(109);
            }
            if (obtainStyledAttributes.getBoolean(a.b.g.a.j.AppCompatTheme_windowActionModeOverlay, false)) {
                b(10);
            }
            this.E = obtainStyledAttributes.getBoolean(a.b.g.a.j.AppCompatTheme_android_windowIsFloating, false);
            obtainStyledAttributes.recycle();
            this.f.getDecorView();
            LayoutInflater from = LayoutInflater.from(this.e);
            if (this.F) {
                viewGroup = (ViewGroup) from.inflate(this.D ? a.b.g.a.g.abc_screen_simple_overlay_action_mode : a.b.g.a.g.abc_screen_simple, (ViewGroup) null);
                if (Build.VERSION.SDK_INT >= 21) {
                    y.a((View) viewGroup, (s) new t(this));
                } else {
                    ((C0168ma) viewGroup).setOnFitSystemWindowsListener(new u(this));
                }
            } else if (this.E) {
                viewGroup = (ViewGroup) from.inflate(a.b.g.a.g.abc_dialog_title_material, (ViewGroup) null);
                this.C = false;
                this.B = false;
            } else if (this.B) {
                TypedValue typedValue = new TypedValue();
                this.e.getTheme().resolveAttribute(a.b.g.a.a.actionBarTheme, typedValue, true);
                int i2 = typedValue.resourceId;
                viewGroup = (ViewGroup) LayoutInflater.from(i2 != 0 ? new a.b.g.e.d(this.e, i2) : this.e).inflate(a.b.g.a.g.abc_screen_toolbar, (ViewGroup) null);
                this.m = (W) viewGroup.findViewById(a.b.g.a.f.decor_content_parent);
                this.m.setWindowCallback(p());
                if (this.C) {
                    this.m.a(109);
                }
                if (this.z) {
                    this.m.a(2);
                }
                if (this.A) {
                    this.m.a(5);
                }
            } else {
                viewGroup = null;
            }
            if (viewGroup != null) {
                if (this.m == null) {
                    this.x = (TextView) viewGroup.findViewById(a.b.g.a.f.title);
                }
                Eb.b(viewGroup);
                ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(a.b.g.a.f.action_bar_activity_content);
                ViewGroup viewGroup2 = (ViewGroup) this.f.findViewById(16908290);
                if (viewGroup2 != null) {
                    while (viewGroup2.getChildCount() > 0) {
                        View childAt = viewGroup2.getChildAt(0);
                        viewGroup2.removeViewAt(0);
                        contentFrameLayout.addView(childAt);
                    }
                    viewGroup2.setId(-1);
                    contentFrameLayout.setId(16908290);
                    if (viewGroup2 instanceof FrameLayout) {
                        ((FrameLayout) viewGroup2).setForeground((Drawable) null);
                    }
                }
                this.f.setContentView(viewGroup);
                contentFrameLayout.setAttachListener(new v(this));
                return viewGroup;
            }
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.B + ", windowActionBarOverlay: " + this.C + ", android:windowIsFloating: " + this.E + ", windowActionModeOverlay: " + this.D + ", windowNoTitle: " + this.F + " }");
        }
        obtainStyledAttributes.recycle();
        throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    }

    private void w() {
        if (this.N == null) {
            this.N = new e(J.a(this.e));
        }
    }

    private void x() {
        if (!this.v) {
            this.w = v();
            CharSequence o2 = o();
            if (!TextUtils.isEmpty(o2)) {
                W w2 = this.m;
                if (w2 != null) {
                    w2.setWindowTitle(o2);
                } else if (s() != null) {
                    s().b(o2);
                } else {
                    TextView textView = this.x;
                    if (textView != null) {
                        textView.setText(o2);
                    }
                }
            }
            u();
            a(this.w);
            this.v = true;
            g a2 = a(0, false);
            if (this.K) {
                return;
            }
            if (a2 == null || a2.j == null) {
                j(108);
            }
        }
    }

    private int y() {
        int i2 = this.L;
        return i2 != -100 ? i2 : q.b();
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x002e  */
    /* JADX WARNING: Removed duplicated region for block: B:16:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void z() {
        /*
            r3 = this;
            r3.x()
            boolean r0 = r3.B
            if (r0 == 0) goto L_0x0033
            android.support.v7.app.a r0 = r3.j
            if (r0 == 0) goto L_0x000c
            goto L_0x0033
        L_0x000c:
            android.view.Window$Callback r0 = r3.g
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L_0x001e
            android.support.v7.app.N r1 = new android.support.v7.app.N
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r2 = r3.C
            r1.<init>(r0, r2)
        L_0x001b:
            r3.j = r1
            goto L_0x002a
        L_0x001e:
            boolean r1 = r0 instanceof android.app.Dialog
            if (r1 == 0) goto L_0x002a
            android.support.v7.app.N r1 = new android.support.v7.app.N
            android.app.Dialog r0 = (android.app.Dialog) r0
            r1.<init>(r0)
            goto L_0x001b
        L_0x002a:
            android.support.v7.app.a r0 = r3.j
            if (r0 == 0) goto L_0x0033
            boolean r1 = r3.R
            r0.c((boolean) r1)
        L_0x0033:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.z.z():void");
    }

    public a.b.g.e.b a(b.a aVar) {
        p pVar;
        if (aVar != null) {
            a.b.g.e.b bVar = this.p;
            if (bVar != null) {
                bVar.a();
            }
            c cVar = new c(aVar);
            C0118a e2 = e();
            if (e2 != null) {
                this.p = e2.a((b.a) cVar);
                a.b.g.e.b bVar2 = this.p;
                if (!(bVar2 == null || (pVar = this.i) == null)) {
                    pVar.b(bVar2);
                }
            }
            if (this.p == null) {
                this.p = b((b.a) cVar);
            }
            return this.p;
        }
        throw new IllegalArgumentException("ActionMode callback can not be null.");
    }

    /* access modifiers changed from: protected */
    public g a(int i2, boolean z2) {
        g[] gVarArr = this.H;
        if (gVarArr == null || gVarArr.length <= i2) {
            g[] gVarArr2 = new g[(i2 + 1)];
            if (gVarArr != null) {
                System.arraycopy(gVarArr, 0, gVarArr2, 0, gVarArr.length);
            }
            this.H = gVarArr2;
            gVarArr = gVarArr2;
        }
        g gVar = gVarArr[i2];
        if (gVar != null) {
            return gVar;
        }
        g gVar2 = new g(i2);
        gVarArr[i2] = gVar2;
        return gVar2;
    }

    /* access modifiers changed from: package-private */
    public g a(Menu menu) {
        g[] gVarArr = this.H;
        int length = gVarArr != null ? gVarArr.length : 0;
        for (int i2 = 0; i2 < length; i2++) {
            g gVar = gVarArr[i2];
            if (gVar != null && gVar.j == menu) {
                return gVar;
            }
        }
        return null;
    }

    public <T extends View> T a(int i2) {
        x();
        return this.f.findViewById(i2);
    }

    public View a(View view, String str, Context context, AttributeSet attributeSet) {
        boolean z2;
        AppCompatViewInflater appCompatViewInflater;
        boolean z3 = false;
        if (this.U == null) {
            String string = this.e.obtainStyledAttributes(a.b.g.a.j.AppCompatTheme).getString(a.b.g.a.j.AppCompatTheme_viewInflaterClass);
            if (string == null || AppCompatViewInflater.class.getName().equals(string)) {
                appCompatViewInflater = new AppCompatViewInflater();
            } else {
                try {
                    this.U = (AppCompatViewInflater) Class.forName(string).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    appCompatViewInflater = new AppCompatViewInflater();
                }
            }
            this.U = appCompatViewInflater;
        }
        if (f1042b) {
            if (!(attributeSet instanceof XmlPullParser)) {
                z3 = a((ViewParent) view);
            } else if (((XmlPullParser) attributeSet).getDepth() > 1) {
                z3 = true;
            }
            z2 = z3;
        } else {
            z2 = false;
        }
        return this.U.createView(view, str, context, attributeSet, z2, f1042b, true, Bb.b());
    }

    /* access modifiers changed from: package-private */
    public void a(int i2, g gVar, Menu menu) {
        if (menu == null) {
            if (gVar == null && i2 >= 0) {
                g[] gVarArr = this.H;
                if (i2 < gVarArr.length) {
                    gVar = gVarArr[i2];
                }
            }
            if (gVar != null) {
                menu = gVar.j;
            }
        }
        if ((gVar == null || gVar.o) && !this.K) {
            this.g.onPanelClosed(i2, menu);
        }
    }

    public void a(Configuration configuration) {
        C0118a e2;
        if (this.B && this.v && (e2 = e()) != null) {
            e2.a(configuration);
        }
        C0175q.a().a(this.e);
        a();
    }

    public void a(Bundle bundle) {
        Window.Callback callback = this.g;
        if (callback instanceof Activity) {
            String str = null;
            try {
                str = Z.b((Activity) callback);
            } catch (IllegalArgumentException unused) {
            }
            if (str != null) {
                C0118a s2 = s();
                if (s2 == null) {
                    this.R = true;
                } else {
                    s2.c(true);
                }
            }
        }
        if (bundle != null && this.L == -100) {
            this.L = bundle.getInt("appcompat:local_night_mode", -100);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(g gVar, boolean z2) {
        ViewGroup viewGroup;
        W w2;
        if (!z2 || gVar.f1052a != 0 || (w2 = this.m) == null || !w2.a()) {
            WindowManager windowManager = (WindowManager) this.e.getSystemService("window");
            if (!(windowManager == null || !gVar.o || (viewGroup = gVar.g) == null)) {
                windowManager.removeView(viewGroup);
                if (z2) {
                    a(gVar.f1052a, gVar, (Menu) null);
                }
            }
            gVar.m = false;
            gVar.n = false;
            gVar.o = false;
            gVar.h = null;
            gVar.q = true;
            if (this.I == gVar) {
                this.I = null;
                return;
            }
            return;
        }
        b(gVar.j);
    }

    public void a(l lVar) {
        a(lVar, true);
    }

    public void a(Toolbar toolbar) {
        Window window;
        Window.Callback callback;
        if (this.g instanceof Activity) {
            C0118a e2 = e();
            if (!(e2 instanceof N)) {
                this.k = null;
                if (e2 != null) {
                    e2.n();
                }
                if (toolbar != null) {
                    H h2 = new H(toolbar, ((Activity) this.g).getTitle(), this.h);
                    this.j = h2;
                    window = this.f;
                    callback = h2.q();
                } else {
                    this.j = null;
                    window = this.f;
                    callback = this.h;
                }
                window.setCallback(callback);
                g();
                return;
            }
            throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
        }
    }

    public void a(View view) {
        x();
        ViewGroup viewGroup = (ViewGroup) this.w.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.g.onContentChanged();
    }

    public void a(View view, ViewGroup.LayoutParams layoutParams) {
        x();
        ((ViewGroup) this.w.findViewById(16908290)).addView(view, layoutParams);
        this.g.onContentChanged();
    }

    /* access modifiers changed from: package-private */
    public void a(ViewGroup viewGroup) {
    }

    public final void a(CharSequence charSequence) {
        this.l = charSequence;
        W w2 = this.m;
        if (w2 != null) {
            w2.setWindowTitle(charSequence);
        } else if (s() != null) {
            s().b(charSequence);
        } else {
            TextView textView = this.x;
            if (textView != null) {
                textView.setText(charSequence);
            }
        }
    }

    public boolean a() {
        int y2 = y();
        int f2 = f(y2);
        boolean l2 = f2 != -1 ? l(f2) : false;
        if (y2 == 0) {
            w();
            this.N.d();
        }
        this.M = true;
        return l2;
    }

    /* access modifiers changed from: package-private */
    public boolean a(int i2, KeyEvent keyEvent) {
        boolean z2 = true;
        if (i2 == 4) {
            if ((keyEvent.getFlags() & 128) == 0) {
                z2 = false;
            }
            this.J = z2;
        } else if (i2 == 82) {
            d(0, keyEvent);
            return true;
        }
        return false;
    }

    public boolean a(l lVar, MenuItem menuItem) {
        g a2;
        Window.Callback p2 = p();
        if (p2 == null || this.K || (a2 = a((Menu) lVar.m())) == null) {
            return false;
        }
        return p2.onMenuItemSelected(a2.f1052a, menuItem);
    }

    /* access modifiers changed from: package-private */
    public boolean a(KeyEvent keyEvent) {
        View decorView;
        Window.Callback callback = this.g;
        boolean z2 = true;
        if (((callback instanceof C0111h.a) || (callback instanceof D)) && (decorView = this.f.getDecorView()) != null && C0111h.a(decorView, keyEvent)) {
            return true;
        }
        if (keyEvent.getKeyCode() == 82 && this.g.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyEvent.getAction() != 0) {
            z2 = false;
        }
        return z2 ? a(keyCode, keyEvent) : c(keyCode, keyEvent);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0029  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public a.b.g.e.b b(a.b.g.e.b.a r8) {
        /*
            r7 = this;
            r7.m()
            a.b.g.e.b r0 = r7.p
            if (r0 == 0) goto L_0x000a
            r0.a()
        L_0x000a:
            boolean r0 = r8 instanceof android.support.v7.app.z.c
            if (r0 != 0) goto L_0x0014
            android.support.v7.app.z$c r0 = new android.support.v7.app.z$c
            r0.<init>(r8)
            r8 = r0
        L_0x0014:
            android.support.v7.app.p r0 = r7.i
            r1 = 0
            if (r0 == 0) goto L_0x0022
            boolean r2 = r7.K
            if (r2 != 0) goto L_0x0022
            a.b.g.e.b r0 = r0.a((a.b.g.e.b.a) r8)     // Catch:{ AbstractMethodError -> 0x0022 }
            goto L_0x0023
        L_0x0022:
            r0 = r1
        L_0x0023:
            if (r0 == 0) goto L_0x0029
            r7.p = r0
            goto L_0x0165
        L_0x0029:
            android.support.v7.widget.ActionBarContextView r0 = r7.q
            r2 = 0
            r3 = 1
            if (r0 != 0) goto L_0x00d6
            boolean r0 = r7.E
            if (r0 == 0) goto L_0x00b7
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.Context r4 = r7.e
            android.content.res.Resources$Theme r4 = r4.getTheme()
            int r5 = a.b.g.a.a.actionBarTheme
            r4.resolveAttribute(r5, r0, r3)
            int r5 = r0.resourceId
            if (r5 == 0) goto L_0x0068
            android.content.Context r5 = r7.e
            android.content.res.Resources r5 = r5.getResources()
            android.content.res.Resources$Theme r5 = r5.newTheme()
            r5.setTo(r4)
            int r4 = r0.resourceId
            r5.applyStyle(r4, r3)
            a.b.g.e.d r4 = new a.b.g.e.d
            android.content.Context r6 = r7.e
            r4.<init>((android.content.Context) r6, (int) r2)
            android.content.res.Resources$Theme r6 = r4.getTheme()
            r6.setTo(r5)
            goto L_0x006a
        L_0x0068:
            android.content.Context r4 = r7.e
        L_0x006a:
            android.support.v7.widget.ActionBarContextView r5 = new android.support.v7.widget.ActionBarContextView
            r5.<init>(r4)
            r7.q = r5
            android.widget.PopupWindow r5 = new android.widget.PopupWindow
            int r6 = a.b.g.a.a.actionModePopupWindowStyle
            r5.<init>(r4, r1, r6)
            r7.r = r5
            android.widget.PopupWindow r5 = r7.r
            r6 = 2
            android.support.v4.widget.o.a((android.widget.PopupWindow) r5, (int) r6)
            android.widget.PopupWindow r5 = r7.r
            android.support.v7.widget.ActionBarContextView r6 = r7.q
            r5.setContentView(r6)
            android.widget.PopupWindow r5 = r7.r
            r6 = -1
            r5.setWidth(r6)
            android.content.res.Resources$Theme r5 = r4.getTheme()
            int r6 = a.b.g.a.a.actionBarSize
            r5.resolveAttribute(r6, r0, r3)
            int r0 = r0.data
            android.content.res.Resources r4 = r4.getResources()
            android.util.DisplayMetrics r4 = r4.getDisplayMetrics()
            int r0 = android.util.TypedValue.complexToDimensionPixelSize(r0, r4)
            android.support.v7.widget.ActionBarContextView r4 = r7.q
            r4.setContentHeight(r0)
            android.widget.PopupWindow r0 = r7.r
            r4 = -2
            r0.setHeight(r4)
            android.support.v7.app.x r0 = new android.support.v7.app.x
            r0.<init>(r7)
            r7.s = r0
            goto L_0x00d6
        L_0x00b7:
            android.view.ViewGroup r0 = r7.w
            int r4 = a.b.g.a.f.action_mode_bar_stub
            android.view.View r0 = r0.findViewById(r4)
            android.support.v7.widget.ViewStubCompat r0 = (android.support.v7.widget.ViewStubCompat) r0
            if (r0 == 0) goto L_0x00d6
            android.content.Context r4 = r7.n()
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            r0.setLayoutInflater(r4)
            android.view.View r0 = r0.a()
            android.support.v7.widget.ActionBarContextView r0 = (android.support.v7.widget.ActionBarContextView) r0
            r7.q = r0
        L_0x00d6:
            android.support.v7.widget.ActionBarContextView r0 = r7.q
            if (r0 == 0) goto L_0x0165
            r7.m()
            android.support.v7.widget.ActionBarContextView r0 = r7.q
            r0.c()
            a.b.g.e.e r0 = new a.b.g.e.e
            android.support.v7.widget.ActionBarContextView r4 = r7.q
            android.content.Context r4 = r4.getContext()
            android.support.v7.widget.ActionBarContextView r5 = r7.q
            android.widget.PopupWindow r6 = r7.r
            if (r6 != 0) goto L_0x00f1
            goto L_0x00f2
        L_0x00f1:
            r3 = 0
        L_0x00f2:
            r0.<init>(r4, r5, r8, r3)
            android.view.Menu r3 = r0.c()
            boolean r8 = r8.a((a.b.g.e.b) r0, (android.view.Menu) r3)
            if (r8 == 0) goto L_0x0163
            r0.i()
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            r8.a(r0)
            r7.p = r0
            boolean r8 = r7.t()
            r0 = 1065353216(0x3f800000, float:1.0)
            if (r8 == 0) goto L_0x012d
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            r1 = 0
            r8.setAlpha(r1)
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            android.support.v4.view.J r8 = android.support.v4.view.y.a(r8)
            r8.a((float) r0)
            r7.t = r8
            android.support.v4.view.J r8 = r7.t
            android.support.v7.app.y r0 = new android.support.v7.app.y
            r0.<init>(r7)
            r8.a((android.support.v4.view.K) r0)
            goto L_0x0153
        L_0x012d:
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            r8.setAlpha(r0)
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            r8.setVisibility(r2)
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            r0 = 32
            r8.sendAccessibilityEvent(r0)
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            android.view.ViewParent r8 = r8.getParent()
            boolean r8 = r8 instanceof android.view.View
            if (r8 == 0) goto L_0x0153
            android.support.v7.widget.ActionBarContextView r8 = r7.q
            android.view.ViewParent r8 = r8.getParent()
            android.view.View r8 = (android.view.View) r8
            android.support.v4.view.y.C(r8)
        L_0x0153:
            android.widget.PopupWindow r8 = r7.r
            if (r8 == 0) goto L_0x0165
            android.view.Window r8 = r7.f
            android.view.View r8 = r8.getDecorView()
            java.lang.Runnable r0 = r7.s
            r8.post(r0)
            goto L_0x0165
        L_0x0163:
            r7.p = r1
        L_0x0165:
            a.b.g.e.b r8 = r7.p
            if (r8 == 0) goto L_0x0170
            android.support.v7.app.p r0 = r7.i
            if (r0 == 0) goto L_0x0170
            r0.b(r8)
        L_0x0170:
            a.b.g.e.b r8 = r7.p
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.z.b(a.b.g.e.b$a):a.b.g.e.b");
    }

    public void b(Bundle bundle) {
        x();
    }

    /* access modifiers changed from: package-private */
    public void b(l lVar) {
        if (!this.G) {
            this.G = true;
            this.m.g();
            Window.Callback p2 = p();
            if (p2 != null && !this.K) {
                p2.onPanelClosed(108, lVar);
            }
            this.G = false;
        }
    }

    public void b(View view, ViewGroup.LayoutParams layoutParams) {
        x();
        ViewGroup viewGroup = (ViewGroup) this.w.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.g.onContentChanged();
    }

    public boolean b(int i2) {
        int k2 = k(i2);
        if (this.F && k2 == 108) {
            return false;
        }
        if (this.B && k2 == 1) {
            this.B = false;
        }
        if (k2 == 1) {
            B();
            this.F = true;
            return true;
        } else if (k2 == 2) {
            B();
            this.z = true;
            return true;
        } else if (k2 == 5) {
            B();
            this.A = true;
            return true;
        } else if (k2 == 10) {
            B();
            this.D = true;
            return true;
        } else if (k2 == 108) {
            B();
            this.B = true;
            return true;
        } else if (k2 != 109) {
            return this.f.requestFeature(k2);
        } else {
            B();
            this.C = true;
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean b(int i2, KeyEvent keyEvent) {
        C0118a e2 = e();
        if (e2 != null && e2.a(i2, keyEvent)) {
            return true;
        }
        g gVar = this.I;
        if (gVar == null || !a(gVar, keyEvent.getKeyCode(), keyEvent, 1)) {
            if (this.I == null) {
                g a2 = a(0, true);
                b(a2, keyEvent);
                boolean a3 = a(a2, keyEvent.getKeyCode(), keyEvent, 1);
                a2.m = false;
                if (a3) {
                    return true;
                }
            }
            return false;
        }
        g gVar2 = this.I;
        if (gVar2 != null) {
            gVar2.n = true;
        }
        return true;
    }

    public final C0120c.a c() {
        return new a();
    }

    public void c(int i2) {
        x();
        ViewGroup viewGroup = (ViewGroup) this.w.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.e).inflate(i2, viewGroup);
        this.g.onContentChanged();
    }

    public void c(Bundle bundle) {
        int i2 = this.L;
        if (i2 != -100) {
            bundle.putInt("appcompat:local_night_mode", i2);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean c(int i2, KeyEvent keyEvent) {
        if (i2 == 4) {
            boolean z2 = this.J;
            this.J = false;
            g a2 = a(0, false);
            if (a2 != null && a2.o) {
                if (!z2) {
                    a(a2, true);
                }
                return true;
            } else if (r()) {
                return true;
            }
        } else if (i2 == 82) {
            e(0, keyEvent);
            return true;
        }
        return false;
    }

    public MenuInflater d() {
        if (this.k == null) {
            z();
            C0118a aVar = this.j;
            this.k = new a.b.g.e.g(aVar != null ? aVar.j() : this.e);
        }
        return this.k;
    }

    /* access modifiers changed from: package-private */
    public void d(int i2) {
        a(a(i2, true), true);
    }

    public C0118a e() {
        z();
        return this.j;
    }

    /* access modifiers changed from: package-private */
    public void e(int i2) {
        g a2;
        g a3 = a(i2, true);
        if (a3.j != null) {
            Bundle bundle = new Bundle();
            a3.j.c(bundle);
            if (bundle.size() > 0) {
                a3.s = bundle;
            }
            a3.j.s();
            a3.j.clear();
        }
        a3.r = true;
        a3.q = true;
        if ((i2 == 108 || i2 == 0) && this.m != null && (a2 = a(0, false)) != null) {
            a2.m = false;
            b(a2, (KeyEvent) null);
        }
    }

    /* access modifiers changed from: package-private */
    public int f(int i2) {
        if (i2 == -100) {
            return -1;
        }
        if (i2 != 0) {
            return i2;
        }
        if (Build.VERSION.SDK_INT >= 23 && ((UiModeManager) this.e.getSystemService(UiModeManager.class)).getNightMode() == 0) {
            return -1;
        }
        w();
        return this.N.c();
    }

    public void f() {
        LayoutInflater from = LayoutInflater.from(this.e);
        if (from.getFactory() == null) {
            C0112i.a(from, this);
        } else if (!(from.getFactory2() instanceof z)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    public void g() {
        C0118a e2 = e();
        if (e2 == null || !e2.l()) {
            j(0);
        }
    }

    /* access modifiers changed from: package-private */
    public void g(int i2) {
        C0118a e2;
        if (i2 == 108 && (e2 = e()) != null) {
            e2.b(true);
        }
    }

    public void h() {
        if (this.O) {
            this.f.getDecorView().removeCallbacks(this.Q);
        }
        this.K = true;
        C0118a aVar = this.j;
        if (aVar != null) {
            aVar.n();
        }
        e eVar = this.N;
        if (eVar != null) {
            eVar.a();
        }
    }

    /* access modifiers changed from: package-private */
    public void h(int i2) {
        if (i2 == 108) {
            C0118a e2 = e();
            if (e2 != null) {
                e2.b(false);
            }
        } else if (i2 == 0) {
            g a2 = a(i2, true);
            if (a2.o) {
                a(a2, false);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public int i(int i2) {
        boolean z2;
        boolean z3;
        boolean z4;
        ActionBarContextView actionBarContextView = this.q;
        int i3 = 0;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z2 = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.q.getLayoutParams();
            z2 = true;
            if (this.q.isShown()) {
                if (this.S == null) {
                    this.S = new Rect();
                    this.T = new Rect();
                }
                Rect rect = this.S;
                Rect rect2 = this.T;
                rect.set(0, i2, 0, 0);
                Eb.a(this.w, rect, rect2);
                if (marginLayoutParams.topMargin != (rect2.top == 0 ? i2 : 0)) {
                    marginLayoutParams.topMargin = i2;
                    View view = this.y;
                    if (view == null) {
                        this.y = new View(this.e);
                        this.y.setBackgroundColor(this.e.getResources().getColor(a.b.g.a.c.abc_input_method_navigation_guard));
                        this.w.addView(this.y, -1, new ViewGroup.LayoutParams(-1, i2));
                    } else {
                        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                        if (layoutParams.height != i2) {
                            layoutParams.height = i2;
                            this.y.setLayoutParams(layoutParams);
                        }
                    }
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (this.y == null) {
                    z2 = false;
                }
                if (!this.D && z2) {
                    i2 = 0;
                }
            } else {
                if (marginLayoutParams.topMargin != 0) {
                    marginLayoutParams.topMargin = 0;
                    z4 = true;
                } else {
                    z4 = false;
                }
                z2 = false;
            }
            if (z3) {
                this.q.setLayoutParams(marginLayoutParams);
            }
        }
        View view2 = this.y;
        if (view2 != null) {
            if (!z2) {
                i3 = 8;
            }
            view2.setVisibility(i3);
        }
        return i2;
    }

    public void i() {
        C0118a e2 = e();
        if (e2 != null) {
            e2.h(true);
        }
    }

    public void j() {
        a();
    }

    public void k() {
        C0118a e2 = e();
        if (e2 != null) {
            e2.h(false);
        }
        e eVar = this.N;
        if (eVar != null) {
            eVar.a();
        }
    }

    /* access modifiers changed from: package-private */
    public void l() {
        l lVar;
        W w2 = this.m;
        if (w2 != null) {
            w2.g();
        }
        if (this.r != null) {
            this.f.getDecorView().removeCallbacks(this.s);
            if (this.r.isShowing()) {
                try {
                    this.r.dismiss();
                } catch (IllegalArgumentException unused) {
                }
            }
            this.r = null;
        }
        m();
        g a2 = a(0, false);
        if (a2 != null && (lVar = a2.j) != null) {
            lVar.close();
        }
    }

    /* access modifiers changed from: package-private */
    public void m() {
        J j2 = this.t;
        if (j2 != null) {
            j2.a();
        }
    }

    /* access modifiers changed from: package-private */
    public final Context n() {
        C0118a e2 = e();
        Context j2 = e2 != null ? e2.j() : null;
        return j2 == null ? this.e : j2;
    }

    /* access modifiers changed from: package-private */
    public final CharSequence o() {
        Window.Callback callback = this.g;
        return callback instanceof Activity ? ((Activity) callback).getTitle() : this.l;
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return a(view, str, context, attributeSet);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }

    /* access modifiers changed from: package-private */
    public final Window.Callback p() {
        return this.f.getCallback();
    }

    public boolean q() {
        return this.u;
    }

    /* access modifiers changed from: package-private */
    public boolean r() {
        a.b.g.e.b bVar = this.p;
        if (bVar != null) {
            bVar.a();
            return true;
        }
        C0118a e2 = e();
        return e2 != null && e2.f();
    }

    /* access modifiers changed from: package-private */
    public final C0118a s() {
        return this.j;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r1.w;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean t() {
        /*
            r1 = this;
            boolean r0 = r1.v
            if (r0 == 0) goto L_0x0010
            android.view.ViewGroup r0 = r1.w
            if (r0 == 0) goto L_0x0010
            boolean r0 = android.support.v4.view.y.y(r0)
            if (r0 == 0) goto L_0x0010
            r0 = 1
            goto L_0x0011
        L_0x0010:
            r0 = 0
        L_0x0011:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.z.t():boolean");
    }
}
