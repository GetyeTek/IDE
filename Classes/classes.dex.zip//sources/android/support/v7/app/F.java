package android.support.v7.app;

class F implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ H f968a;

    F(H h) {
        this.f968a = h;
    }

    public void run() {
        this.f968a.r();
    }
}
