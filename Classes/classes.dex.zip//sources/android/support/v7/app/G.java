package android.support.v7.app;

import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

class G implements Toolbar.c {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ H f969a;

    G(H h) {
        this.f969a = h;
    }

    public boolean onMenuItemClick(MenuItem menuItem) {
        return this.f969a.f972c.onMenuItemSelected(0, menuItem);
    }
}
