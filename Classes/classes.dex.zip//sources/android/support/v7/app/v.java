package android.support.v7.app;

import android.support.v7.widget.ContentFrameLayout;

class v implements ContentFrameLayout.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ z f1038a;

    v(z zVar) {
        this.f1038a = zVar;
    }

    public void a() {
    }

    public void onDetachedFromWindow() {
        this.f1038a.l();
    }
}
