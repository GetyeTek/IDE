package android.support.v7.app;

import android.support.v7.app.AlertController;
import android.view.View;
import android.widget.AdapterView;

/* renamed from: android.support.v7.app.m  reason: case insensitive filesystem */
class C0130m implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ AlertController.RecycleListView f1027a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ AlertController f1028b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ AlertController.a f1029c;

    C0130m(AlertController.a aVar, AlertController.RecycleListView recycleListView, AlertController alertController) {
        this.f1029c = aVar;
        this.f1027a = recycleListView;
        this.f1028b = alertController;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        boolean[] zArr = this.f1029c.F;
        if (zArr != null) {
            zArr[i] = this.f1027a.isItemChecked(i);
        }
        this.f1029c.J.onClick(this.f1028b.f950b, i, this.f1027a.isItemChecked(i));
    }
}
