package android.support.v7.app;

import android.view.View;

/* renamed from: android.support.v7.app.i  reason: case insensitive filesystem */
class C0126i implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ View f1017a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ View f1018b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ AlertController f1019c;

    C0126i(AlertController alertController, View view, View view2) {
        this.f1019c = alertController;
        this.f1017a = view;
        this.f1018b = view2;
    }

    public void run() {
        AlertController.a(this.f1019c.g, this.f1017a, this.f1018b);
    }
}
