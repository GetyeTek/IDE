package android.support.v7.app;

import a.b.g.e.b;

public interface p {
    b a(b.a aVar);

    void a(b bVar);

    void b(b bVar);
}
