package android.support.v7.app;

import a.b.g.c.a.f;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.C0121d;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

/* renamed from: android.support.v7.app.c  reason: case insensitive filesystem */
public class C0120c implements DrawerLayout.c {

    /* renamed from: a  reason: collision with root package name */
    private final a f995a;

    /* renamed from: b  reason: collision with root package name */
    private final DrawerLayout f996b;

    /* renamed from: c  reason: collision with root package name */
    private f f997c;
    private boolean d;
    private Drawable e;
    boolean f;
    private boolean g;
    private final int h;
    private final int i;
    View.OnClickListener j;
    private boolean k;

    /* renamed from: android.support.v7.app.c$a */
    public interface a {
        void a(int i);

        void a(Drawable drawable, int i);

        boolean a();

        Context b();

        Drawable c();
    }

    /* renamed from: android.support.v7.app.c$b */
    public interface b {
        a f();
    }

    /* renamed from: android.support.v7.app.c$c  reason: collision with other inner class name */
    private static class C0022c implements a {

        /* renamed from: a  reason: collision with root package name */
        private final Activity f998a;

        /* renamed from: b  reason: collision with root package name */
        private C0121d.a f999b;

        C0022c(Activity activity) {
            this.f998a = activity;
        }

        public void a(int i) {
            if (Build.VERSION.SDK_INT >= 18) {
                ActionBar actionBar = this.f998a.getActionBar();
                if (actionBar != null) {
                    actionBar.setHomeActionContentDescription(i);
                    return;
                }
                return;
            }
            this.f999b = C0121d.a(this.f999b, this.f998a, i);
        }

        public void a(Drawable drawable, int i) {
            ActionBar actionBar = this.f998a.getActionBar();
            if (actionBar == null) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 18) {
                actionBar.setHomeAsUpIndicator(drawable);
                actionBar.setHomeActionContentDescription(i);
                return;
            }
            actionBar.setDisplayShowHomeEnabled(true);
            this.f999b = C0121d.a(this.f999b, this.f998a, drawable, i);
            actionBar.setDisplayShowHomeEnabled(false);
        }

        public boolean a() {
            ActionBar actionBar = this.f998a.getActionBar();
            return (actionBar == null || (actionBar.getDisplayOptions() & 4) == 0) ? false : true;
        }

        public Context b() {
            ActionBar actionBar = this.f998a.getActionBar();
            return actionBar != null ? actionBar.getThemedContext() : this.f998a;
        }

        public Drawable c() {
            if (Build.VERSION.SDK_INT < 18) {
                return C0121d.a(this.f998a);
            }
            TypedArray obtainStyledAttributes = b().obtainStyledAttributes((AttributeSet) null, new int[]{16843531}, 16843470, 0);
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            obtainStyledAttributes.recycle();
            return drawable;
        }
    }

    /* renamed from: android.support.v7.app.c$d */
    static class d implements a {

        /* renamed from: a  reason: collision with root package name */
        final Toolbar f1000a;

        /* renamed from: b  reason: collision with root package name */
        final Drawable f1001b;

        /* renamed from: c  reason: collision with root package name */
        final CharSequence f1002c;

        d(Toolbar toolbar) {
            this.f1000a = toolbar;
            this.f1001b = toolbar.getNavigationIcon();
            this.f1002c = toolbar.getNavigationContentDescription();
        }

        public void a(int i) {
            if (i == 0) {
                this.f1000a.setNavigationContentDescription(this.f1002c);
            } else {
                this.f1000a.setNavigationContentDescription(i);
            }
        }

        public void a(Drawable drawable, int i) {
            this.f1000a.setNavigationIcon(drawable);
            a(i);
        }

        public boolean a() {
            return true;
        }

        public Context b() {
            return this.f1000a.getContext();
        }

        public Drawable c() {
            return this.f1001b;
        }
    }

    public C0120c(Activity activity, DrawerLayout drawerLayout, int i2, int i3) {
        this(activity, (Toolbar) null, drawerLayout, (f) null, i2, i3);
    }

    C0120c(Activity activity, Toolbar toolbar, DrawerLayout drawerLayout, f fVar, int i2, int i3) {
        this.d = true;
        this.f = true;
        this.k = false;
        if (toolbar != null) {
            this.f995a = new d(toolbar);
            toolbar.setNavigationOnClickListener(new C0119b(this));
        } else if (activity instanceof b) {
            this.f995a = ((b) activity).f();
        } else {
            this.f995a = new C0022c(activity);
        }
        this.f996b = drawerLayout;
        this.h = i2;
        this.i = i3;
        if (fVar == null) {
            this.f997c = new f(this.f995a.b());
        } else {
            this.f997c = fVar;
        }
        this.e = a();
    }

    private void a(float f2) {
        f fVar;
        boolean z;
        if (f2 == 1.0f) {
            fVar = this.f997c;
            z = true;
        } else {
            if (f2 == 0.0f) {
                fVar = this.f997c;
                z = false;
            }
            this.f997c.c(f2);
        }
        fVar.b(z);
        this.f997c.c(f2);
    }

    /* access modifiers changed from: package-private */
    public Drawable a() {
        return this.f995a.c();
    }

    public void a(int i2) {
    }

    public void a(Drawable drawable) {
        if (drawable == null) {
            this.e = a();
            this.g = false;
        } else {
            this.e = drawable;
            this.g = true;
        }
        if (!this.f) {
            a(this.e, 0);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(Drawable drawable, int i2) {
        if (!this.k && !this.f995a.a()) {
            Log.w("ActionBarDrawerToggle", "DrawerToggle may not show up because NavigationIcon is not visible. You may need to call actionbar.setDisplayHomeAsUpEnabled(true);");
            this.k = true;
        }
        this.f995a.a(drawable, i2);
    }

    public void a(View view) {
        a(1.0f);
        if (this.f) {
            b(this.i);
        }
    }

    public void a(View view, float f2) {
        if (this.d) {
            a(Math.min(1.0f, Math.max(0.0f, f2)));
        } else {
            a(0.0f);
        }
    }

    public void a(boolean z) {
        int i2;
        Drawable drawable;
        if (z != this.f) {
            if (z) {
                drawable = this.f997c;
                i2 = this.f996b.f(8388611) ? this.i : this.h;
            } else {
                drawable = this.e;
                i2 = 0;
            }
            a(drawable, i2);
            this.f = z;
        }
    }

    /* access modifiers changed from: package-private */
    public void b(int i2) {
        this.f995a.a(i2);
    }

    public void b(View view) {
        a(0.0f);
        if (this.f) {
            b(this.h);
        }
    }

    public boolean b() {
        return this.f;
    }

    public void c() {
        a(this.f996b.f(8388611) ? 1.0f : 0.0f);
        if (this.f) {
            a((Drawable) this.f997c, this.f996b.f(8388611) ? this.i : this.h);
        }
    }

    /* access modifiers changed from: package-private */
    public void d() {
        int c2 = this.f996b.c(8388611);
        if (this.f996b.g(8388611) && c2 != 2) {
            this.f996b.a(8388611);
        } else if (c2 != 1) {
            this.f996b.h(8388611);
        }
    }
}
