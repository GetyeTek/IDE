package android.support.v7.widget;

import android.view.View;

class Wa implements View.OnFocusChangeListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1300a;

    Wa(SearchView searchView) {
        this.f1300a = searchView;
    }

    public void onFocusChange(View view, boolean z) {
        SearchView searchView = this.f1300a;
        View.OnFocusChangeListener onFocusChangeListener = searchView.N;
        if (onFocusChangeListener != null) {
            onFocusChangeListener.onFocusChange(searchView, z);
        }
    }
}
