package android.support.v7.widget;

import android.support.v7.widget.E;
import android.view.ViewTreeObserver;
import android.widget.PopupWindow;

class H implements PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f1164a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ E.b f1165b;

    H(E.b bVar, ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
        this.f1165b = bVar;
        this.f1164a = onGlobalLayoutListener;
    }

    public void onDismiss() {
        ViewTreeObserver viewTreeObserver = E.this.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f1164a);
        }
    }
}
