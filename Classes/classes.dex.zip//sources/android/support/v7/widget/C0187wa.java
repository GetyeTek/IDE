package android.support.v7.widget;

import android.support.v7.view.menu.l;
import android.view.MenuItem;

/* renamed from: android.support.v7.widget.wa  reason: case insensitive filesystem */
public interface C0187wa {
    void a(l lVar, MenuItem menuItem);

    void b(l lVar, MenuItem menuItem);
}
