package android.support.v7.widget;

import android.view.View;
import android.widget.AdapterView;

/* renamed from: android.support.v7.widget.ua  reason: case insensitive filesystem */
class C0183ua implements AdapterView.OnItemSelectedListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0185va f1443a;

    C0183ua(C0185va vaVar) {
        this.f1443a = vaVar;
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        C0160ia iaVar;
        if (i != -1 && (iaVar = this.f1443a.f) != null) {
            iaVar.setListSelectionHidden(false);
        }
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
