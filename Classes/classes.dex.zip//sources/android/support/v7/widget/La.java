package android.support.v7.widget;

import android.os.Bundle;
import android.support.v4.view.C0107d;
import android.support.v4.view.a.c;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

public class La extends C0107d {

    /* renamed from: c  reason: collision with root package name */
    final RecyclerView f1180c;
    final C0107d d = new a(this);

    public static class a extends C0107d {

        /* renamed from: c  reason: collision with root package name */
        final La f1181c;

        public a(La la) {
            this.f1181c = la;
        }

        public void a(View view, c cVar) {
            super.a(view, cVar);
            if (!this.f1181c.c() && this.f1181c.f1180c.getLayoutManager() != null) {
                this.f1181c.f1180c.getLayoutManager().a(view, cVar);
            }
        }

        public boolean a(View view, int i, Bundle bundle) {
            if (super.a(view, i, bundle)) {
                return true;
            }
            if (this.f1181c.c() || this.f1181c.f1180c.getLayoutManager() == null) {
                return false;
            }
            return this.f1181c.f1180c.getLayoutManager().a(view, i, bundle);
        }
    }

    public La(RecyclerView recyclerView) {
        this.f1180c = recyclerView;
    }

    public void a(View view, c cVar) {
        super.a(view, cVar);
        cVar.a((CharSequence) RecyclerView.class.getName());
        if (!c() && this.f1180c.getLayoutManager() != null) {
            this.f1180c.getLayoutManager().a(cVar);
        }
    }

    public boolean a(View view, int i, Bundle bundle) {
        if (super.a(view, i, bundle)) {
            return true;
        }
        if (c() || this.f1180c.getLayoutManager() == null) {
            return false;
        }
        return this.f1180c.getLayoutManager().a(i, bundle);
    }

    public C0107d b() {
        return this.d;
    }

    public void b(View view, AccessibilityEvent accessibilityEvent) {
        super.b(view, accessibilityEvent);
        accessibilityEvent.setClassName(RecyclerView.class.getName());
        if ((view instanceof RecyclerView) && !c()) {
            RecyclerView recyclerView = (RecyclerView) view;
            if (recyclerView.getLayoutManager() != null) {
                recyclerView.getLayoutManager().a(accessibilityEvent);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean c() {
        return this.f1180c.j();
    }
}
