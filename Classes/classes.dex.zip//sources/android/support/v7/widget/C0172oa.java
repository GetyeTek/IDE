package android.support.v7.widget;

import android.support.v7.widget.C0174pa;
import java.util.Comparator;

/* renamed from: android.support.v7.widget.oa  reason: case insensitive filesystem */
class C0172oa implements Comparator<C0174pa.b> {
    C0172oa() {
    }

    /* renamed from: a */
    public int compare(C0174pa.b bVar, C0174pa.b bVar2) {
        if ((bVar.d == null) != (bVar2.d == null)) {
            return bVar.d == null ? 1 : -1;
        }
        boolean z = bVar.f1416a;
        if (z != bVar2.f1416a) {
            return z ? -1 : 1;
        }
        int i = bVar2.f1417b - bVar.f1417b;
        if (i != 0) {
            return i;
        }
        int i2 = bVar.f1418c - bVar2.f1418c;
        if (i2 != 0) {
            return i2;
        }
        return 0;
    }
}
