package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: android.support.v7.widget.aa  reason: case insensitive filesystem */
class C0138aa implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ArrayList f1315a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ C0156ga f1316b;

    C0138aa(C0156ga gaVar, ArrayList arrayList) {
        this.f1316b = gaVar;
        this.f1315a = arrayList;
    }

    public void run() {
        Iterator it = this.f1315a.iterator();
        while (it.hasNext()) {
            this.f1316b.t((RecyclerView.x) it.next());
        }
        this.f1315a.clear();
        this.f1316b.m.remove(this.f1315a);
    }
}
