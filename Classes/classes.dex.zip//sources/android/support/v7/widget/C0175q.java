package android.support.v7.widget;

import a.b.d.a.k;
import a.b.f.g.h;
import a.b.f.g.i;
import a.b.f.g.q;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: android.support.v7.widget.q  reason: case insensitive filesystem */
public final class C0175q {

    /* renamed from: a  reason: collision with root package name */
    private static final PorterDuff.Mode f1420a = PorterDuff.Mode.SRC_IN;

    /* renamed from: b  reason: collision with root package name */
    private static C0175q f1421b;

    /* renamed from: c  reason: collision with root package name */
    private static final c f1422c = new c(6);
    private static final int[] d = {a.b.g.a.e.abc_textfield_search_default_mtrl_alpha, a.b.g.a.e.abc_textfield_default_mtrl_alpha, a.b.g.a.e.abc_ab_share_pack_mtrl_alpha};
    private static final int[] e = {a.b.g.a.e.abc_ic_commit_search_api_mtrl_alpha, a.b.g.a.e.abc_seekbar_tick_mark_material, a.b.g.a.e.abc_ic_menu_share_mtrl_alpha, a.b.g.a.e.abc_ic_menu_copy_mtrl_am_alpha, a.b.g.a.e.abc_ic_menu_cut_mtrl_alpha, a.b.g.a.e.abc_ic_menu_selectall_mtrl_alpha, a.b.g.a.e.abc_ic_menu_paste_mtrl_am_alpha};
    private static final int[] f = {a.b.g.a.e.abc_textfield_activated_mtrl_alpha, a.b.g.a.e.abc_textfield_search_activated_mtrl_alpha, a.b.g.a.e.abc_cab_background_top_mtrl_alpha, a.b.g.a.e.abc_text_cursor_material, a.b.g.a.e.abc_text_select_handle_left_mtrl_dark, a.b.g.a.e.abc_text_select_handle_middle_mtrl_dark, a.b.g.a.e.abc_text_select_handle_right_mtrl_dark, a.b.g.a.e.abc_text_select_handle_left_mtrl_light, a.b.g.a.e.abc_text_select_handle_middle_mtrl_light, a.b.g.a.e.abc_text_select_handle_right_mtrl_light};
    private static final int[] g = {a.b.g.a.e.abc_popup_background_mtrl_mult, a.b.g.a.e.abc_cab_background_internal_bg, a.b.g.a.e.abc_menu_hardkey_panel_mtrl_mult};
    private static final int[] h = {a.b.g.a.e.abc_tab_indicator_material, a.b.g.a.e.abc_textfield_search_material};
    private static final int[] i = {a.b.g.a.e.abc_btn_check_material, a.b.g.a.e.abc_btn_radio_material};
    private WeakHashMap<Context, q<ColorStateList>> j;
    private a.b.f.g.b<String, d> k;
    private q<String> l;
    private final WeakHashMap<Context, h<WeakReference<Drawable.ConstantState>>> m = new WeakHashMap<>(0);
    private TypedValue n;
    private boolean o;

    /* renamed from: android.support.v7.widget.q$a */
    static class a implements d {
        a() {
        }

        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return a.b.g.c.a.b.a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e);
                return null;
            }
        }
    }

    /* renamed from: android.support.v7.widget.q$b */
    private static class b implements d {
        b() {
        }

        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return a.b.d.a.d.a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e);
                return null;
            }
        }
    }

    /* renamed from: android.support.v7.widget.q$c */
    private static class c extends i<Integer, PorterDuffColorFilter> {
        public c(int i) {
            super(i);
        }

        private static int b(int i, PorterDuff.Mode mode) {
            return ((i + 31) * 31) + mode.hashCode();
        }

        /* access modifiers changed from: package-private */
        public PorterDuffColorFilter a(int i, PorterDuff.Mode mode) {
            return (PorterDuffColorFilter) b(Integer.valueOf(b(i, mode)));
        }

        /* access modifiers changed from: package-private */
        public PorterDuffColorFilter a(int i, PorterDuff.Mode mode, PorterDuffColorFilter porterDuffColorFilter) {
            return (PorterDuffColorFilter) a(Integer.valueOf(b(i, mode)), porterDuffColorFilter);
        }
    }

    /* renamed from: android.support.v7.widget.q$d */
    private interface d {
        Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    /* renamed from: android.support.v7.widget.q$e */
    private static class e implements d {
        e() {
        }

        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return k.createFromXmlInner(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e);
                return null;
            }
        }
    }

    private static long a(TypedValue typedValue) {
        return (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
    }

    static PorterDuff.Mode a(int i2) {
        if (i2 == a.b.g.a.e.abc_switch_thumb_material) {
            return PorterDuff.Mode.MULTIPLY;
        }
        return null;
    }

    public static synchronized PorterDuffColorFilter a(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter a2;
        synchronized (C0175q.class) {
            a2 = f1422c.a(i2, mode);
            if (a2 == null) {
                a2 = new PorterDuffColorFilter(i2, mode);
                f1422c.a(i2, mode, a2);
            }
        }
        return a2;
    }

    private static PorterDuffColorFilter a(ColorStateList colorStateList, PorterDuff.Mode mode, int[] iArr) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return a(colorStateList.getColorForState(iArr, 0), mode);
    }

    private Drawable a(Context context, int i2, boolean z, Drawable drawable) {
        LayerDrawable layerDrawable;
        Drawable findDrawableByLayerId;
        int i3;
        ColorStateList b2 = b(context, i2);
        if (b2 != null) {
            if (C0158ha.a(drawable)) {
                drawable = drawable.mutate();
            }
            Drawable h2 = android.support.v4.graphics.drawable.a.h(drawable);
            android.support.v4.graphics.drawable.a.a(h2, b2);
            PorterDuff.Mode a2 = a(i2);
            if (a2 == null) {
                return h2;
            }
            android.support.v4.graphics.drawable.a.a(h2, a2);
            return h2;
        }
        if (i2 == a.b.g.a.e.abc_seekbar_track_material) {
            layerDrawable = (LayerDrawable) drawable;
            a(layerDrawable.findDrawableByLayerId(16908288), jb.b(context, a.b.g.a.a.colorControlNormal), f1420a);
            findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908303);
            i3 = a.b.g.a.a.colorControlNormal;
        } else if (i2 == a.b.g.a.e.abc_ratingbar_material || i2 == a.b.g.a.e.abc_ratingbar_indicator_material || i2 == a.b.g.a.e.abc_ratingbar_small_material) {
            layerDrawable = (LayerDrawable) drawable;
            a(layerDrawable.findDrawableByLayerId(16908288), jb.a(context, a.b.g.a.a.colorControlNormal), f1420a);
            findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908303);
            i3 = a.b.g.a.a.colorControlActivated;
        } else if (a(context, i2, drawable) || !z) {
            return drawable;
        } else {
            return null;
        }
        a(findDrawableByLayerId, jb.b(context, i3), f1420a);
        a(layerDrawable.findDrawableByLayerId(16908301), jb.b(context, a.b.g.a.a.colorControlActivated), f1420a);
        return drawable;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002c, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized android.graphics.drawable.Drawable a(android.content.Context r4, long r5) {
        /*
            r3 = this;
            monitor-enter(r3)
            java.util.WeakHashMap<android.content.Context, a.b.f.g.h<java.lang.ref.WeakReference<android.graphics.drawable.Drawable$ConstantState>>> r0 = r3.m     // Catch:{ all -> 0x002d }
            java.lang.Object r0 = r0.get(r4)     // Catch:{ all -> 0x002d }
            a.b.f.g.h r0 = (a.b.f.g.h) r0     // Catch:{ all -> 0x002d }
            r1 = 0
            if (r0 != 0) goto L_0x000e
            monitor-exit(r3)
            return r1
        L_0x000e:
            java.lang.Object r2 = r0.b((long) r5)     // Catch:{ all -> 0x002d }
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x002b
            java.lang.Object r2 = r2.get()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable$ConstantState r2 = (android.graphics.drawable.Drawable.ConstantState) r2     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x0028
            android.content.res.Resources r4 = r4.getResources()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable r4 = r2.newDrawable(r4)     // Catch:{ all -> 0x002d }
            monitor-exit(r3)
            return r4
        L_0x0028:
            r0.a((long) r5)     // Catch:{ all -> 0x002d }
        L_0x002b:
            monitor-exit(r3)
            return r1
        L_0x002d:
            r4 = move-exception
            monitor-exit(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.C0175q.a(android.content.Context, long):android.graphics.drawable.Drawable");
    }

    public static synchronized C0175q a() {
        C0175q qVar;
        synchronized (C0175q.class) {
            if (f1421b == null) {
                f1421b = new C0175q();
                a(f1421b);
            }
            qVar = f1421b;
        }
        return qVar;
    }

    private void a(Context context, int i2, ColorStateList colorStateList) {
        if (this.j == null) {
            this.j = new WeakHashMap<>();
        }
        q qVar = this.j.get(context);
        if (qVar == null) {
            qVar = new q();
            this.j.put(context, qVar);
        }
        qVar.a(i2, colorStateList);
    }

    private static void a(Drawable drawable, int i2, PorterDuff.Mode mode) {
        if (C0158ha.a(drawable)) {
            drawable = drawable.mutate();
        }
        if (mode == null) {
            mode = f1420a;
        }
        drawable.setColorFilter(a(i2, mode));
    }

    static void a(Drawable drawable, mb mbVar, int[] iArr) {
        if (!C0158ha.a(drawable) || drawable.mutate() == drawable) {
            if (mbVar.d || mbVar.f1394c) {
                drawable.setColorFilter(a(mbVar.d ? mbVar.f1392a : null, mbVar.f1394c ? mbVar.f1393b : f1420a, iArr));
            } else {
                drawable.clearColorFilter();
            }
            if (Build.VERSION.SDK_INT <= 23) {
                drawable.invalidateSelf();
                return;
            }
            return;
        }
        Log.d("AppCompatDrawableManag", "Mutated drawable is not the same instance as the input.");
    }

    private static void a(C0175q qVar) {
        if (Build.VERSION.SDK_INT < 24) {
            qVar.a("vector", (d) new e());
            qVar.a("animated-vector", (d) new b());
            qVar.a("animated-selector", (d) new a());
        }
    }

    private void a(String str, d dVar) {
        if (this.k == null) {
            this.k = new a.b.f.g.b<>();
        }
        this.k.put(str, dVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0046  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0061 A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static boolean a(android.content.Context r6, int r7, android.graphics.drawable.Drawable r8) {
        /*
            android.graphics.PorterDuff$Mode r0 = f1420a
            int[] r1 = d
            boolean r1 = a((int[]) r1, (int) r7)
            r2 = 16842801(0x1010031, float:2.3693695E-38)
            r3 = -1
            r4 = 0
            r5 = 1
            if (r1 == 0) goto L_0x0015
            int r2 = a.b.g.a.a.colorControlNormal
        L_0x0012:
            r7 = 1
            r1 = -1
            goto L_0x0044
        L_0x0015:
            int[] r1 = f
            boolean r1 = a((int[]) r1, (int) r7)
            if (r1 == 0) goto L_0x0020
            int r2 = a.b.g.a.a.colorControlActivated
            goto L_0x0012
        L_0x0020:
            int[] r1 = g
            boolean r1 = a((int[]) r1, (int) r7)
            if (r1 == 0) goto L_0x002b
            android.graphics.PorterDuff$Mode r0 = android.graphics.PorterDuff.Mode.MULTIPLY
            goto L_0x0012
        L_0x002b:
            int r1 = a.b.g.a.e.abc_list_divider_mtrl_alpha
            if (r7 != r1) goto L_0x003c
            r2 = 16842800(0x1010030, float:2.3693693E-38)
            r7 = 1109603123(0x42233333, float:40.8)
            int r7 = java.lang.Math.round(r7)
            r1 = r7
            r7 = 1
            goto L_0x0044
        L_0x003c:
            int r1 = a.b.g.a.e.abc_dialog_material_background
            if (r7 != r1) goto L_0x0041
            goto L_0x0012
        L_0x0041:
            r7 = 0
            r1 = -1
            r2 = 0
        L_0x0044:
            if (r7 == 0) goto L_0x0061
            boolean r7 = android.support.v7.widget.C0158ha.a(r8)
            if (r7 == 0) goto L_0x0050
            android.graphics.drawable.Drawable r8 = r8.mutate()
        L_0x0050:
            int r6 = android.support.v7.widget.jb.b(r6, r2)
            android.graphics.PorterDuffColorFilter r6 = a((int) r6, (android.graphics.PorterDuff.Mode) r0)
            r8.setColorFilter(r6)
            if (r1 == r3) goto L_0x0060
            r8.setAlpha(r1)
        L_0x0060:
            return r5
        L_0x0061:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.C0175q.a(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
    }

    private synchronized boolean a(Context context, long j2, Drawable drawable) {
        boolean z;
        Drawable.ConstantState constantState = drawable.getConstantState();
        if (constantState != null) {
            h hVar = this.m.get(context);
            if (hVar == null) {
                hVar = new h();
                this.m.put(context, hVar);
            }
            hVar.c(j2, new WeakReference(constantState));
            z = true;
        } else {
            z = false;
        }
        return z;
    }

    private static boolean a(Drawable drawable) {
        return (drawable instanceof k) || "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName());
    }

    private static boolean a(int[] iArr, int i2) {
        for (int i3 : iArr) {
            if (i3 == i2) {
                return true;
            }
        }
        return false;
    }

    private void b(Context context) {
        if (!this.o) {
            this.o = true;
            Drawable a2 = a(context, a.b.g.a.e.abc_vector_test);
            if (a2 == null || !a(a2)) {
                this.o = false;
                throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
            }
        }
    }

    private ColorStateList c(Context context) {
        return c(context, 0);
    }

    private ColorStateList c(Context context, int i2) {
        int b2 = jb.b(context, a.b.g.a.a.colorControlHighlight);
        int a2 = jb.a(context, a.b.g.a.a.colorButtonNormal);
        return new ColorStateList(new int[][]{jb.f1372b, jb.e, jb.f1373c, jb.i}, new int[]{a2, a.b.f.a.a.a(b2, i2), a.b.f.a.a.a(b2, i2), i2});
    }

    private ColorStateList d(Context context) {
        return c(context, jb.b(context, a.b.g.a.a.colorAccent));
    }

    private Drawable d(Context context, int i2) {
        if (this.n == null) {
            this.n = new TypedValue();
        }
        TypedValue typedValue = this.n;
        context.getResources().getValue(i2, typedValue, true);
        long a2 = a(typedValue);
        Drawable a3 = a(context, a2);
        if (a3 != null) {
            return a3;
        }
        if (i2 == a.b.g.a.e.abc_cab_background_top_material) {
            a3 = new LayerDrawable(new Drawable[]{a(context, a.b.g.a.e.abc_cab_background_internal_bg), a(context, a.b.g.a.e.abc_cab_background_top_mtrl_alpha)});
        }
        if (a3 != null) {
            a3.setChangingConfigurations(typedValue.changingConfigurations);
            a(context, a2, a3);
        }
        return a3;
    }

    private ColorStateList e(Context context) {
        return c(context, jb.b(context, a.b.g.a.a.colorButtonNormal));
    }

    private ColorStateList e(Context context, int i2) {
        q qVar;
        WeakHashMap<Context, q<ColorStateList>> weakHashMap = this.j;
        if (weakHashMap == null || (qVar = weakHashMap.get(context)) == null) {
            return null;
        }
        return (ColorStateList) qVar.b(i2);
    }

    private ColorStateList f(Context context) {
        int[][] iArr = new int[3][];
        int[] iArr2 = new int[3];
        ColorStateList c2 = jb.c(context, a.b.g.a.a.colorSwitchThumbNormal);
        if (c2 == null || !c2.isStateful()) {
            iArr[0] = jb.f1372b;
            iArr2[0] = jb.a(context, a.b.g.a.a.colorSwitchThumbNormal);
            iArr[1] = jb.f;
            iArr2[1] = jb.b(context, a.b.g.a.a.colorControlActivated);
            iArr[2] = jb.i;
            iArr2[2] = jb.b(context, a.b.g.a.a.colorSwitchThumbNormal);
        } else {
            iArr[0] = jb.f1372b;
            iArr2[0] = c2.getColorForState(iArr[0], 0);
            iArr[1] = jb.f;
            iArr2[1] = jb.b(context, a.b.g.a.a.colorControlActivated);
            iArr[2] = jb.i;
            iArr2[2] = c2.getDefaultColor();
        }
        return new ColorStateList(iArr, iArr2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x0073 A[Catch:{ Exception -> 0x00a2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x009a A[Catch:{ Exception -> 0x00a2 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.graphics.drawable.Drawable f(android.content.Context r11, int r12) {
        /*
            r10 = this;
            a.b.f.g.b<java.lang.String, android.support.v7.widget.q$d> r0 = r10.k
            r1 = 0
            if (r0 == 0) goto L_0x00b2
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x00b2
            a.b.f.g.q<java.lang.String> r0 = r10.l
            java.lang.String r2 = "appcompat_skip_skip"
            if (r0 == 0) goto L_0x0028
            java.lang.Object r0 = r0.b(r12)
            java.lang.String r0 = (java.lang.String) r0
            boolean r3 = r2.equals(r0)
            if (r3 != 0) goto L_0x0027
            if (r0 == 0) goto L_0x002f
            a.b.f.g.b<java.lang.String, android.support.v7.widget.q$d> r3 = r10.k
            java.lang.Object r0 = r3.get(r0)
            if (r0 != 0) goto L_0x002f
        L_0x0027:
            return r1
        L_0x0028:
            a.b.f.g.q r0 = new a.b.f.g.q
            r0.<init>()
            r10.l = r0
        L_0x002f:
            android.util.TypedValue r0 = r10.n
            if (r0 != 0) goto L_0x003a
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            r10.n = r0
        L_0x003a:
            android.util.TypedValue r0 = r10.n
            android.content.res.Resources r1 = r11.getResources()
            r3 = 1
            r1.getValue(r12, r0, r3)
            long r4 = a((android.util.TypedValue) r0)
            android.graphics.drawable.Drawable r6 = r10.a((android.content.Context) r11, (long) r4)
            if (r6 == 0) goto L_0x004f
            return r6
        L_0x004f:
            java.lang.CharSequence r7 = r0.string
            if (r7 == 0) goto L_0x00aa
            java.lang.String r7 = r7.toString()
            java.lang.String r8 = ".xml"
            boolean r7 = r7.endsWith(r8)
            if (r7 == 0) goto L_0x00aa
            android.content.res.XmlResourceParser r1 = r1.getXml(r12)     // Catch:{ Exception -> 0x00a2 }
            android.util.AttributeSet r7 = android.util.Xml.asAttributeSet(r1)     // Catch:{ Exception -> 0x00a2 }
        L_0x0067:
            int r8 = r1.next()     // Catch:{ Exception -> 0x00a2 }
            r9 = 2
            if (r8 == r9) goto L_0x0071
            if (r8 == r3) goto L_0x0071
            goto L_0x0067
        L_0x0071:
            if (r8 != r9) goto L_0x009a
            java.lang.String r3 = r1.getName()     // Catch:{ Exception -> 0x00a2 }
            a.b.f.g.q<java.lang.String> r8 = r10.l     // Catch:{ Exception -> 0x00a2 }
            r8.a(r12, r3)     // Catch:{ Exception -> 0x00a2 }
            a.b.f.g.b<java.lang.String, android.support.v7.widget.q$d> r8 = r10.k     // Catch:{ Exception -> 0x00a2 }
            java.lang.Object r3 = r8.get(r3)     // Catch:{ Exception -> 0x00a2 }
            android.support.v7.widget.q$d r3 = (android.support.v7.widget.C0175q.d) r3     // Catch:{ Exception -> 0x00a2 }
            if (r3 == 0) goto L_0x008f
            android.content.res.Resources$Theme r8 = r11.getTheme()     // Catch:{ Exception -> 0x00a2 }
            android.graphics.drawable.Drawable r1 = r3.a(r11, r1, r7, r8)     // Catch:{ Exception -> 0x00a2 }
            r6 = r1
        L_0x008f:
            if (r6 == 0) goto L_0x00aa
            int r0 = r0.changingConfigurations     // Catch:{ Exception -> 0x00a2 }
            r6.setChangingConfigurations(r0)     // Catch:{ Exception -> 0x00a2 }
            r10.a((android.content.Context) r11, (long) r4, (android.graphics.drawable.Drawable) r6)     // Catch:{ Exception -> 0x00a2 }
            goto L_0x00aa
        L_0x009a:
            org.xmlpull.v1.XmlPullParserException r11 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ Exception -> 0x00a2 }
            java.lang.String r0 = "No start tag found"
            r11.<init>(r0)     // Catch:{ Exception -> 0x00a2 }
            throw r11     // Catch:{ Exception -> 0x00a2 }
        L_0x00a2:
            r11 = move-exception
            java.lang.String r0 = "AppCompatDrawableManag"
            java.lang.String r1 = "Exception while inflating drawable"
            android.util.Log.e(r0, r1, r11)
        L_0x00aa:
            if (r6 != 0) goto L_0x00b1
            a.b.f.g.q<java.lang.String> r11 = r10.l
            r11.a(r12, r2)
        L_0x00b1:
            return r6
        L_0x00b2:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.C0175q.f(android.content.Context, int):android.graphics.drawable.Drawable");
    }

    public synchronized Drawable a(Context context, int i2) {
        return a(context, i2, false);
    }

    /* access modifiers changed from: package-private */
    public synchronized Drawable a(Context context, int i2, boolean z) {
        Drawable f2;
        b(context);
        f2 = f(context, i2);
        if (f2 == null) {
            f2 = d(context, i2);
        }
        if (f2 == null) {
            f2 = android.support.v4.content.c.c(context, i2);
        }
        if (f2 != null) {
            f2 = a(context, i2, z, f2);
        }
        if (f2 != null) {
            C0158ha.b(f2);
        }
        return f2;
    }

    /* access modifiers changed from: package-private */
    public synchronized Drawable a(Context context, Bb bb, int i2) {
        Drawable f2 = f(context, i2);
        if (f2 == null) {
            f2 = bb.a(i2);
        }
        if (f2 == null) {
            return null;
        }
        return a(context, i2, false, f2);
    }

    public synchronized void a(Context context) {
        h hVar = this.m.get(context);
        if (hVar != null) {
            hVar.a();
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0078  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized android.content.res.ColorStateList b(android.content.Context r3, int r4) {
        /*
            r2 = this;
            monitor-enter(r2)
            android.content.res.ColorStateList r0 = r2.e(r3, r4)     // Catch:{ all -> 0x007d }
            if (r0 != 0) goto L_0x007b
            int r1 = a.b.g.a.e.abc_edit_text_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0013
            int r0 = a.b.g.a.c.abc_tint_edittext     // Catch:{ all -> 0x007d }
        L_0x000d:
            android.content.res.ColorStateList r0 = a.b.g.b.a.a.a(r3, r0)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0013:
            int r1 = a.b.g.a.e.abc_switch_track_mtrl_alpha     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x001a
            int r0 = a.b.g.a.c.abc_tint_switch_track     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x001a:
            int r1 = a.b.g.a.e.abc_switch_thumb_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0023
            android.content.res.ColorStateList r0 = r2.f(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0023:
            int r1 = a.b.g.a.e.abc_btn_default_mtrl_shape     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x002c
            android.content.res.ColorStateList r0 = r2.e(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x002c:
            int r1 = a.b.g.a.e.abc_btn_borderless_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0035
            android.content.res.ColorStateList r0 = r2.c(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0035:
            int r1 = a.b.g.a.e.abc_btn_colored_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x003e
            android.content.res.ColorStateList r0 = r2.d(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x003e:
            int r1 = a.b.g.a.e.abc_spinner_mtrl_am_alpha     // Catch:{ all -> 0x007d }
            if (r4 == r1) goto L_0x0073
            int r1 = a.b.g.a.e.abc_spinner_textfield_background_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0047
            goto L_0x0073
        L_0x0047:
            int[] r1 = e     // Catch:{ all -> 0x007d }
            boolean r1 = a((int[]) r1, (int) r4)     // Catch:{ all -> 0x007d }
            if (r1 == 0) goto L_0x0056
            int r0 = a.b.g.a.a.colorControlNormal     // Catch:{ all -> 0x007d }
            android.content.res.ColorStateList r0 = android.support.v7.widget.jb.c(r3, r0)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0056:
            int[] r1 = h     // Catch:{ all -> 0x007d }
            boolean r1 = a((int[]) r1, (int) r4)     // Catch:{ all -> 0x007d }
            if (r1 == 0) goto L_0x0061
            int r0 = a.b.g.a.c.abc_tint_default     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x0061:
            int[] r1 = i     // Catch:{ all -> 0x007d }
            boolean r1 = a((int[]) r1, (int) r4)     // Catch:{ all -> 0x007d }
            if (r1 == 0) goto L_0x006c
            int r0 = a.b.g.a.c.abc_tint_btn_checkable     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x006c:
            int r1 = a.b.g.a.e.abc_seekbar_thumb_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0076
            int r0 = a.b.g.a.c.abc_tint_seek_thumb     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x0073:
            int r0 = a.b.g.a.c.abc_tint_spinner     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x0076:
            if (r0 == 0) goto L_0x007b
            r2.a((android.content.Context) r3, (int) r4, (android.content.res.ColorStateList) r0)     // Catch:{ all -> 0x007d }
        L_0x007b:
            monitor-exit(r2)
            return r0
        L_0x007d:
            r3 = move-exception
            monitor-exit(r2)
            goto L_0x0081
        L_0x0080:
            throw r3
        L_0x0081:
            goto L_0x0080
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.C0175q.b(android.content.Context, int):android.content.res.ColorStateList");
    }
}
