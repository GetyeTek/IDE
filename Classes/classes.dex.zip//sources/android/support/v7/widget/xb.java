package android.support.v7.widget;

class xb implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ zb f1465a;

    xb(zb zbVar) {
        this.f1465a = zbVar;
    }

    public void run() {
        this.f1465a.a(false);
    }
}
