package android.support.v7.widget;

import android.support.v7.view.menu.z;
import android.support.v7.widget.E;
import android.view.View;

class D extends C0170na {
    final /* synthetic */ E.b j;
    final /* synthetic */ E k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    D(E e, View view, E.b bVar) {
        super(view);
        this.k = e;
        this.j = bVar;
    }

    public z a() {
        return this.j;
    }

    public boolean b() {
        if (this.k.g.d()) {
            return true;
        }
        this.k.g.c();
        return true;
    }
}
