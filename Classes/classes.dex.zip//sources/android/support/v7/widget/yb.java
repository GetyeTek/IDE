package android.support.v7.widget;

class yb implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ zb f1470a;

    yb(zb zbVar) {
        this.f1470a = zbVar;
    }

    public void run() {
        this.f1470a.a();
    }
}
