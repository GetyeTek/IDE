package android.support.v7.widget;

import a.b.g.a.g;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.C0108e;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.C0133b;
import android.support.v7.view.menu.D;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.u;
import android.support.v7.view.menu.v;
import android.support.v7.view.menu.w;
import android.support.v7.view.menu.z;
import android.support.v7.widget.ActionMenuView;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/* renamed from: android.support.v7.widget.g  reason: case insensitive filesystem */
class C0155g extends C0133b implements C0108e.a {
    a A;
    c B;
    private b C;
    final f D = new f();
    int E;
    d k;
    private Drawable l;
    private boolean m;
    private boolean n;
    private boolean o;
    private int p;
    private int q;
    private int r;
    private boolean s;
    private boolean t;
    private boolean u;
    private boolean v;
    private int w;
    private final SparseBooleanArray x = new SparseBooleanArray();
    private View y;
    e z;

    /* renamed from: android.support.v7.widget.g$a */
    private class a extends u {
        public a(Context context, D d, View view) {
            super(context, d, view, false, a.b.g.a.a.actionOverflowMenuStyle);
            if (!((p) d.getItem()).h()) {
                View view2 = C0155g.this.k;
                a(view2 == null ? (View) C0155g.this.i : view2);
            }
            a((v.a) C0155g.this.D);
        }

        /* access modifiers changed from: protected */
        public void d() {
            C0155g gVar = C0155g.this;
            gVar.A = null;
            gVar.E = 0;
            super.d();
        }
    }

    /* renamed from: android.support.v7.widget.g$b */
    private class b extends ActionMenuItemView.b {
        b() {
        }

        public z a() {
            a aVar = C0155g.this.A;
            if (aVar != null) {
                return aVar.b();
            }
            return null;
        }
    }

    /* renamed from: android.support.v7.widget.g$c */
    private class c implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private e f1343a;

        public c(e eVar) {
            this.f1343a = eVar;
        }

        public void run() {
            if (C0155g.this.f1071c != null) {
                C0155g.this.f1071c.a();
            }
            View view = (View) C0155g.this.i;
            if (!(view == null || view.getWindowToken() == null || !this.f1343a.f())) {
                C0155g.this.z = this.f1343a;
            }
            C0155g.this.B = null;
        }
    }

    /* renamed from: android.support.v7.widget.g$d */
    private class d extends C0184v implements ActionMenuView.a {

        /* renamed from: c  reason: collision with root package name */
        private final float[] f1345c = new float[2];

        public d(Context context) {
            super(context, (AttributeSet) null, a.b.g.a.a.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            wb.a(this, getContentDescription());
            setOnTouchListener(new C0157h(this, this, C0155g.this));
        }

        public boolean b() {
            return false;
        }

        public boolean c() {
            return false;
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            C0155g.this.j();
            return true;
        }

        /* access modifiers changed from: protected */
        public boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (!(drawable == null || background == null)) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                android.support.v4.graphics.drawable.a.a(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* renamed from: android.support.v7.widget.g$e */
    private class e extends u {
        public e(Context context, l lVar, View view, boolean z) {
            super(context, lVar, view, z, a.b.g.a.a.actionOverflowMenuStyle);
            a(8388613);
            a((v.a) C0155g.this.D);
        }

        /* access modifiers changed from: protected */
        public void d() {
            if (C0155g.this.f1071c != null) {
                C0155g.this.f1071c.close();
            }
            C0155g.this.z = null;
            super.d();
        }
    }

    /* renamed from: android.support.v7.widget.g$f */
    private class f implements v.a {
        f() {
        }

        public void a(l lVar, boolean z) {
            if (lVar instanceof D) {
                lVar.m().a(false);
            }
            v.a c2 = C0155g.this.c();
            if (c2 != null) {
                c2.a(lVar, z);
            }
        }

        public boolean a(l lVar) {
            if (lVar == null) {
                return false;
            }
            C0155g.this.E = ((D) lVar).getItem().getItemId();
            v.a c2 = C0155g.this.c();
            if (c2 != null) {
                return c2.a(lVar);
            }
            return false;
        }
    }

    /* renamed from: android.support.v7.widget.g$g  reason: collision with other inner class name */
    private static class C0024g implements Parcelable {
        public static final Parcelable.Creator<C0024g> CREATOR = new C0159i();

        /* renamed from: a  reason: collision with root package name */
        public int f1347a;

        C0024g() {
        }

        C0024g(Parcel parcel) {
            this.f1347a = parcel.readInt();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f1347a);
        }
    }

    public C0155g(Context context) {
        super(context, g.abc_action_menu_layout, g.abc_action_menu_item_layout);
    }

    private View a(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.i;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            if ((childAt instanceof w.a) && ((w.a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    public View a(p pVar, View view, ViewGroup viewGroup) {
        View actionView = pVar.getActionView();
        if (actionView == null || pVar.f()) {
            actionView = super.a(pVar, view, viewGroup);
        }
        actionView.setVisibility(pVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    public void a(Context context, l lVar) {
        super.a(context, lVar);
        Resources resources = context.getResources();
        a.b.g.e.a a2 = a.b.g.e.a.a(context);
        if (!this.o) {
            this.n = a2.g();
        }
        if (!this.u) {
            this.p = a2.b();
        }
        if (!this.s) {
            this.r = a2.c();
        }
        int i = this.p;
        if (this.n) {
            if (this.k == null) {
                this.k = new d(this.f1069a);
                if (this.m) {
                    this.k.setImageDrawable(this.l);
                    this.l = null;
                    this.m = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.k.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i -= this.k.getMeasuredWidth();
        } else {
            this.k = null;
        }
        this.q = i;
        this.w = (int) (resources.getDisplayMetrics().density * 56.0f);
        this.y = null;
    }

    public void a(Configuration configuration) {
        if (!this.s) {
            this.r = a.b.g.e.a.a(this.f1070b).c();
        }
        l lVar = this.f1071c;
        if (lVar != null) {
            lVar.b(true);
        }
    }

    public void a(Drawable drawable) {
        d dVar = this.k;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
            return;
        }
        this.m = true;
        this.l = drawable;
    }

    public void a(Parcelable parcelable) {
        int i;
        MenuItem findItem;
        if ((parcelable instanceof C0024g) && (i = ((C0024g) parcelable).f1347a) > 0 && (findItem = this.f1071c.findItem(i)) != null) {
            a((D) findItem.getSubMenu());
        }
    }

    public void a(l lVar, boolean z2) {
        d();
        super.a(lVar, z2);
    }

    public void a(p pVar, w.a aVar) {
        aVar.a(pVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.i);
        if (this.C == null) {
            this.C = new b();
        }
        actionMenuItemView.setPopupCallback(this.C);
    }

    public void a(ActionMenuView actionMenuView) {
        this.i = actionMenuView;
        actionMenuView.a(this.f1071c);
    }

    public void a(boolean z2) {
        w wVar;
        super.a(z2);
        ((View) this.i).requestLayout();
        l lVar = this.f1071c;
        boolean z3 = false;
        if (lVar != null) {
            ArrayList<p> c2 = lVar.c();
            int size = c2.size();
            for (int i = 0; i < size; i++) {
                C0108e a2 = c2.get(i).a();
                if (a2 != null) {
                    a2.a((C0108e.a) this);
                }
            }
        }
        l lVar2 = this.f1071c;
        ArrayList<p> j = lVar2 != null ? lVar2.j() : null;
        if (this.n && j != null) {
            int size2 = j.size();
            if (size2 == 1) {
                z3 = !j.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z3 = true;
            }
        }
        if (z3) {
            if (this.k == null) {
                this.k = new d(this.f1069a);
            }
            ViewGroup viewGroup = (ViewGroup) this.k.getParent();
            if (viewGroup != this.i) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.k);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.i;
                actionMenuView.addView(this.k, actionMenuView.c());
            }
        } else {
            d dVar = this.k;
            if (dVar != null && dVar.getParent() == (wVar = this.i)) {
                ((ViewGroup) wVar).removeView(this.k);
            }
        }
        ((ActionMenuView) this.i).setOverflowReserved(this.n);
    }

    public boolean a() {
        int i;
        ArrayList<p> arrayList;
        int i2;
        int i3;
        int i4;
        boolean z2;
        C0155g gVar = this;
        l lVar = gVar.f1071c;
        int i5 = 0;
        if (lVar != null) {
            arrayList = lVar.n();
            i = arrayList.size();
        } else {
            arrayList = null;
            i = 0;
        }
        int i6 = gVar.r;
        int i7 = gVar.q;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) gVar.i;
        int i8 = i6;
        boolean z3 = false;
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < i; i11++) {
            p pVar = arrayList.get(i11);
            if (pVar.k()) {
                i9++;
            } else if (pVar.j()) {
                i10++;
            } else {
                z3 = true;
            }
            if (gVar.v && pVar.isActionViewExpanded()) {
                i8 = 0;
            }
        }
        if (gVar.n && (z3 || i10 + i9 > i8)) {
            i8--;
        }
        int i12 = i8 - i9;
        SparseBooleanArray sparseBooleanArray = gVar.x;
        sparseBooleanArray.clear();
        if (gVar.t) {
            int i13 = gVar.w;
            i2 = i7 / i13;
            i3 = i13 + ((i7 % i13) / i2);
        } else {
            i3 = 0;
            i2 = 0;
        }
        int i14 = i7;
        int i15 = 0;
        int i16 = 0;
        while (i15 < i) {
            p pVar2 = arrayList.get(i15);
            if (pVar2.k()) {
                View a2 = gVar.a(pVar2, gVar.y, viewGroup);
                if (gVar.y == null) {
                    gVar.y = a2;
                }
                if (gVar.t) {
                    i2 -= ActionMenuView.a(a2, i3, i2, makeMeasureSpec, i5);
                } else {
                    a2.measure(makeMeasureSpec, makeMeasureSpec);
                }
                int measuredWidth = a2.getMeasuredWidth();
                i14 -= measuredWidth;
                if (i16 != 0) {
                    measuredWidth = i16;
                }
                int groupId = pVar2.getGroupId();
                if (groupId != 0) {
                    z2 = true;
                    sparseBooleanArray.put(groupId, true);
                } else {
                    z2 = true;
                }
                pVar2.d(z2);
                i4 = i;
                i16 = measuredWidth;
            } else if (pVar2.j()) {
                int groupId2 = pVar2.getGroupId();
                boolean z4 = sparseBooleanArray.get(groupId2);
                boolean z5 = (i12 > 0 || z4) && i14 > 0 && (!gVar.t || i2 > 0);
                if (z5) {
                    boolean z6 = z5;
                    View a3 = gVar.a(pVar2, gVar.y, viewGroup);
                    i4 = i;
                    if (gVar.y == null) {
                        gVar.y = a3;
                    }
                    if (gVar.t) {
                        int a4 = ActionMenuView.a(a3, i3, i2, makeMeasureSpec, 0);
                        i2 -= a4;
                        if (a4 == 0) {
                            z6 = false;
                        }
                    } else {
                        a3.measure(makeMeasureSpec, makeMeasureSpec);
                    }
                    int measuredWidth2 = a3.getMeasuredWidth();
                    i14 -= measuredWidth2;
                    if (i16 == 0) {
                        i16 = measuredWidth2;
                    }
                    z5 = z6 & (!gVar.t ? i14 + i16 > 0 : i14 >= 0);
                } else {
                    boolean z7 = z5;
                    i4 = i;
                }
                if (z5 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, true);
                } else if (z4) {
                    sparseBooleanArray.put(groupId2, false);
                    int i17 = 0;
                    while (i17 < i15) {
                        p pVar3 = arrayList.get(i17);
                        if (pVar3.getGroupId() == groupId2) {
                            if (pVar3.h()) {
                                i12++;
                            }
                            pVar3.d(false);
                        }
                        i17++;
                    }
                }
                if (z5) {
                    i12--;
                }
                pVar2.d(z5);
            } else {
                i4 = i;
                pVar2.d(false);
                i15++;
                i5 = 0;
                gVar = this;
                i = i4;
            }
            i15++;
            i5 = 0;
            gVar = this;
            i = i4;
        }
        return true;
    }

    public boolean a(int i, p pVar) {
        return pVar.h();
    }

    public boolean a(D d2) {
        boolean z2 = false;
        if (!d2.hasVisibleItems()) {
            return false;
        }
        D d3 = d2;
        while (d3.t() != this.f1071c) {
            d3 = (D) d3.t();
        }
        View a2 = a(d3.getItem());
        if (a2 == null) {
            return false;
        }
        this.E = d2.getItem().getItemId();
        int size = d2.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                break;
            }
            MenuItem item = d2.getItem(i);
            if (item.isVisible() && item.getIcon() != null) {
                z2 = true;
                break;
            }
            i++;
        }
        this.A = new a(this.f1070b, d2, a2);
        this.A.a(z2);
        this.A.e();
        super.a(d2);
        return true;
    }

    public boolean a(ViewGroup viewGroup, int i) {
        if (viewGroup.getChildAt(i) == this.k) {
            return false;
        }
        return super.a(viewGroup, i);
    }

    public Parcelable b() {
        C0024g gVar = new C0024g();
        gVar.f1347a = this.E;
        return gVar;
    }

    public w b(ViewGroup viewGroup) {
        w wVar = this.i;
        w b2 = super.b(viewGroup);
        if (wVar != b2) {
            ((ActionMenuView) b2).setPresenter(this);
        }
        return b2;
    }

    public void b(boolean z2) {
        this.v = z2;
    }

    public void c(boolean z2) {
        this.n = z2;
        this.o = true;
    }

    public boolean d() {
        return f() | g();
    }

    public Drawable e() {
        d dVar = this.k;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.m) {
            return this.l;
        }
        return null;
    }

    public boolean f() {
        w wVar;
        c cVar = this.B;
        if (cVar == null || (wVar = this.i) == null) {
            e eVar = this.z;
            if (eVar == null) {
                return false;
            }
            eVar.a();
            return true;
        }
        ((View) wVar).removeCallbacks(cVar);
        this.B = null;
        return true;
    }

    public boolean g() {
        a aVar = this.A;
        if (aVar == null) {
            return false;
        }
        aVar.a();
        return true;
    }

    public boolean h() {
        return this.B != null || i();
    }

    public boolean i() {
        e eVar = this.z;
        return eVar != null && eVar.c();
    }

    public boolean j() {
        l lVar;
        if (!this.n || i() || (lVar = this.f1071c) == null || this.i == null || this.B != null || lVar.j().isEmpty()) {
            return false;
        }
        this.B = new c(new e(this.f1070b, this.f1071c, this.k, true));
        ((View) this.i).post(this.B);
        super.a((D) null);
        return true;
    }
}
