package android.support.v7.widget;

import android.support.v7.widget.C0156ga;
import java.util.ArrayList;
import java.util.Iterator;

class Y implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ArrayList f1302a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ C0156ga f1303b;

    Y(C0156ga gaVar, ArrayList arrayList) {
        this.f1303b = gaVar;
        this.f1302a = arrayList;
    }

    public void run() {
        Iterator it = this.f1302a.iterator();
        while (it.hasNext()) {
            C0156ga.b bVar = (C0156ga.b) it.next();
            this.f1303b.b(bVar.f1351a, bVar.f1352b, bVar.f1353c, bVar.d, bVar.e);
        }
        this.f1302a.clear();
        this.f1303b.n.remove(this.f1302a);
    }
}
