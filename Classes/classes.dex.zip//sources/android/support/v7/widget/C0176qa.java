package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/* renamed from: android.support.v7.widget.qa  reason: case insensitive filesystem */
class C0176qa {

    /* renamed from: a  reason: collision with root package name */
    boolean f1423a = true;

    /* renamed from: b  reason: collision with root package name */
    int f1424b;

    /* renamed from: c  reason: collision with root package name */
    int f1425c;
    int d;
    int e;
    int f = 0;
    int g = 0;
    boolean h;
    boolean i;

    C0176qa() {
    }

    /* access modifiers changed from: package-private */
    public View a(RecyclerView.p pVar) {
        View d2 = pVar.d(this.f1425c);
        this.f1425c += this.d;
        return d2;
    }

    /* access modifiers changed from: package-private */
    public boolean a(RecyclerView.u uVar) {
        int i2 = this.f1425c;
        return i2 >= 0 && i2 < uVar.a();
    }

    public String toString() {
        return "LayoutState{mAvailable=" + this.f1424b + ", mCurrentPosition=" + this.f1425c + ", mItemDirection=" + this.d + ", mLayoutDirection=" + this.e + ", mStartLine=" + this.f + ", mEndLine=" + this.g + '}';
    }
}
