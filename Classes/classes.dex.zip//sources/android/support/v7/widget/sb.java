package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.Toolbar;

class sb implements Parcelable.ClassLoaderCreator<Toolbar.d> {
    sb() {
    }

    public Toolbar.d createFromParcel(Parcel parcel) {
        return new Toolbar.d(parcel, (ClassLoader) null);
    }

    public Toolbar.d createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new Toolbar.d(parcel, classLoader);
    }

    public Toolbar.d[] newArray(int i) {
        return new Toolbar.d[i];
    }
}
