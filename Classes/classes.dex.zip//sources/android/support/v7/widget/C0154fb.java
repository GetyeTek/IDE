package android.support.v7.widget;

/* renamed from: android.support.v7.widget.fb  reason: case insensitive filesystem */
class C0154fb implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ StaggeredGridLayoutManager f1341a;

    C0154fb(StaggeredGridLayoutManager staggeredGridLayoutManager) {
        this.f1341a = staggeredGridLayoutManager;
    }

    public void run() {
        this.f1341a.F();
    }
}
