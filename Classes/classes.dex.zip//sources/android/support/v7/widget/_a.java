package android.support.v7.widget;

import android.view.KeyEvent;
import android.widget.TextView;

class _a implements TextView.OnEditorActionListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1308a;

    _a(SearchView searchView) {
        this.f1308a = searchView;
    }

    public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        this.f1308a.g();
        return true;
    }
}
