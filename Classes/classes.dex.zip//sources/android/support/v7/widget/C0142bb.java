package android.support.v7.widget;

import android.view.View;
import android.widget.AdapterView;

/* renamed from: android.support.v7.widget.bb  reason: case insensitive filesystem */
class C0142bb implements AdapterView.OnItemSelectedListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1322a;

    C0142bb(SearchView searchView) {
        this.f1322a = searchView;
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        this.f1322a.d(i);
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
