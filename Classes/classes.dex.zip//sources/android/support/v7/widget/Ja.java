package android.support.v7.widget;

import android.support.v7.widget.Cb;
import android.support.v7.widget.RecyclerView;
import android.view.View;

class Ja implements Cb.b {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView.i f1173a;

    Ja(RecyclerView.i iVar) {
        this.f1173a = iVar;
    }

    public int a() {
        return this.f1173a.p();
    }

    public int a(View view) {
        return this.f1173a.j(view) - ((RecyclerView.j) view.getLayoutParams()).topMargin;
    }

    public View a(int i) {
        return this.f1173a.c(i);
    }

    public int b() {
        return this.f1173a.h() - this.f1173a.m();
    }

    public int b(View view) {
        return this.f1173a.e(view) + ((RecyclerView.j) view.getLayoutParams()).bottomMargin;
    }
}
