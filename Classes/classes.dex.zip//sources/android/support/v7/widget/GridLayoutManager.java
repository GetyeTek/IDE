package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.v4.view.a.c;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;

public class GridLayoutManager extends LinearLayoutManager {
    boolean H = false;
    int I = -1;
    int[] J;
    View[] K;
    final SparseIntArray L = new SparseIntArray();
    final SparseIntArray M = new SparseIntArray();
    c N = new a();
    final Rect O = new Rect();

    public static final class a extends c {
        public int a(int i) {
            return 1;
        }

        public int c(int i, int i2) {
            return i % i2;
        }
    }

    public static class b extends RecyclerView.j {
        int e = -1;
        int f = 0;

        public b(int i, int i2) {
            super(i, i2);
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public int e() {
            return this.e;
        }

        public int f() {
            return this.f;
        }
    }

    public static abstract class c {

        /* renamed from: a  reason: collision with root package name */
        final SparseIntArray f1162a = new SparseIntArray();

        /* renamed from: b  reason: collision with root package name */
        private boolean f1163b = false;

        public abstract int a(int i);

        /* access modifiers changed from: package-private */
        public int a(int i, int i2) {
            if (!this.f1163b) {
                return c(i, i2);
            }
            int i3 = this.f1162a.get(i, -1);
            if (i3 != -1) {
                return i3;
            }
            int c2 = c(i, i2);
            this.f1162a.put(i, c2);
            return c2;
        }

        public void a() {
            this.f1162a.clear();
        }

        public int b(int i, int i2) {
            int a2 = a(i);
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < i; i5++) {
                int a3 = a(i5);
                i3 += a3;
                if (i3 == i2) {
                    i4++;
                    i3 = 0;
                } else if (i3 > i2) {
                    i4++;
                    i3 = a3;
                }
            }
            return i3 + a2 > i2 ? i4 + 1 : i4;
        }

        public abstract int c(int i, int i2);
    }

    public GridLayoutManager(Context context, int i) {
        super(context);
        k(i);
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        k(RecyclerView.i.a(context, attributeSet, i, i2).f1227b);
    }

    private void N() {
        int e = e();
        for (int i = 0; i < e; i++) {
            b bVar = (b) c(i).getLayoutParams();
            int a2 = bVar.a();
            this.L.put(a2, bVar.f());
            this.M.put(a2, bVar.e());
        }
    }

    private void O() {
        this.L.clear();
        this.M.clear();
    }

    private void P() {
        View[] viewArr = this.K;
        if (viewArr == null || viewArr.length != this.I) {
            this.K = new View[this.I];
        }
    }

    private void Q() {
        int i;
        int i2;
        if (H() == 1) {
            i2 = q() - o();
            i = n();
        } else {
            i2 = h() - m();
            i = p();
        }
        l(i2 - i);
    }

    private int a(RecyclerView.p pVar, RecyclerView.u uVar, int i) {
        if (!uVar.d()) {
            return this.N.b(i, this.I);
        }
        int a2 = pVar.a(i);
        if (a2 != -1) {
            return this.N.b(a2, this.I);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
        return 0;
    }

    private void a(float f, int i) {
        l(Math.max(Math.round(f * ((float) this.I)), i));
    }

    private void a(RecyclerView.p pVar, RecyclerView.u uVar, int i, int i2, boolean z) {
        int i3;
        int i4;
        int i5 = 0;
        int i6 = -1;
        if (z) {
            i6 = i;
            i4 = 0;
            i3 = 1;
        } else {
            i4 = i - 1;
            i3 = -1;
        }
        while (i4 != i6) {
            View view = this.K[i4];
            b bVar = (b) view.getLayoutParams();
            bVar.f = c(pVar, uVar, l(view));
            bVar.e = i5;
            i5 += bVar.f;
            i4 += i3;
        }
    }

    private void a(View view, int i, int i2, boolean z) {
        RecyclerView.j jVar = (RecyclerView.j) view.getLayoutParams();
        if (z ? b(view, i, i2, jVar) : a(view, i, i2, jVar)) {
            view.measure(i, i2);
        }
    }

    static int[] a(int[] iArr, int i, int i2) {
        int i3;
        if (!(iArr != null && iArr.length == i + 1 && iArr[iArr.length - 1] == i2)) {
            iArr = new int[(i + 1)];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i2 / i;
        int i6 = i2 % i;
        int i7 = 0;
        for (int i8 = 1; i8 <= i; i8++) {
            i4 += i6;
            if (i4 <= 0 || i - i4 >= i6) {
                i3 = i5;
            } else {
                i3 = i5 + 1;
                i4 -= i;
            }
            i7 += i3;
            iArr[i8] = i7;
        }
        return iArr;
    }

    private int b(RecyclerView.p pVar, RecyclerView.u uVar, int i) {
        if (!uVar.d()) {
            return this.N.a(i, this.I);
        }
        int i2 = this.M.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int a2 = pVar.a(i);
        if (a2 != -1) {
            return this.N.a(a2, this.I);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 0;
    }

    private void b(RecyclerView.p pVar, RecyclerView.u uVar, LinearLayoutManager.a aVar, int i) {
        boolean z = i == 1;
        int b2 = b(pVar, uVar, aVar.f1183b);
        if (z) {
            while (b2 > 0) {
                int i2 = aVar.f1183b;
                if (i2 > 0) {
                    aVar.f1183b = i2 - 1;
                    b2 = b(pVar, uVar, aVar.f1183b);
                } else {
                    return;
                }
            }
            return;
        }
        int a2 = uVar.a() - 1;
        int i3 = aVar.f1183b;
        while (i3 < a2) {
            int i4 = i3 + 1;
            int b3 = b(pVar, uVar, i4);
            if (b3 <= b2) {
                break;
            }
            i3 = i4;
            b2 = b3;
        }
        aVar.f1183b = i3;
    }

    private void b(View view, int i, boolean z) {
        int i2;
        int i3;
        b bVar = (b) view.getLayoutParams();
        Rect rect = bVar.f1230b;
        int i4 = rect.top + rect.bottom + bVar.topMargin + bVar.bottomMargin;
        int i5 = rect.left + rect.right + bVar.leftMargin + bVar.rightMargin;
        int f = f(bVar.e, bVar.f);
        if (this.s == 1) {
            i2 = RecyclerView.i.a(f, i, i5, bVar.width, false);
            i3 = RecyclerView.i.a(this.u.g(), i(), i4, bVar.height, true);
        } else {
            int a2 = RecyclerView.i.a(f, i, i4, bVar.height, false);
            int a3 = RecyclerView.i.a(this.u.g(), r(), i5, bVar.width, true);
            i3 = a2;
            i2 = a3;
        }
        a(view, i2, i3, z);
    }

    private int c(RecyclerView.p pVar, RecyclerView.u uVar, int i) {
        if (!uVar.d()) {
            return this.N.a(i);
        }
        int i2 = this.L.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int a2 = pVar.a(i);
        if (a2 != -1) {
            return this.N.a(a2);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 1;
    }

    private void l(int i) {
        this.J = a(this.J, this.I, i);
    }

    public boolean C() {
        return this.D == null && !this.H;
    }

    public int a(int i, RecyclerView.p pVar, RecyclerView.u uVar) {
        Q();
        P();
        return super.a(i, pVar, uVar);
    }

    public int a(RecyclerView.p pVar, RecyclerView.u uVar) {
        if (this.s == 1) {
            return this.I;
        }
        if (uVar.a() < 1) {
            return 0;
        }
        return a(pVar, uVar, uVar.a() - 1) + 1;
    }

    public RecyclerView.j a(Context context, AttributeSet attributeSet) {
        return new b(context, attributeSet);
    }

    public RecyclerView.j a(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new b((ViewGroup.MarginLayoutParams) layoutParams) : new b(layoutParams);
    }

    /* access modifiers changed from: package-private */
    public View a(RecyclerView.p pVar, RecyclerView.u uVar, int i, int i2, int i3) {
        E();
        int f = this.u.f();
        int b2 = this.u.b();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View c2 = c(i);
            int l = l(c2);
            if (l >= 0 && l < i3 && b(pVar, uVar, l) == 0) {
                if (((RecyclerView.j) c2.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = c2;
                    }
                } else if (this.u.d(c2) < b2 && this.u.a(c2) >= f) {
                    return c2;
                } else {
                    if (view == null) {
                        view = c2;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00d7, code lost:
        if (r13 == (r2 > r8)) goto L_0x00cd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x00f7, code lost:
        if (r13 == r11) goto L_0x00b7;
     */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0105  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View a(android.view.View r24, int r25, android.support.v7.widget.RecyclerView.p r26, android.support.v7.widget.RecyclerView.u r27) {
        /*
            r23 = this;
            r0 = r23
            r1 = r26
            r2 = r27
            android.view.View r3 = r23.c((android.view.View) r24)
            r4 = 0
            if (r3 != 0) goto L_0x000e
            return r4
        L_0x000e:
            android.view.ViewGroup$LayoutParams r5 = r3.getLayoutParams()
            android.support.v7.widget.GridLayoutManager$b r5 = (android.support.v7.widget.GridLayoutManager.b) r5
            int r6 = r5.e
            int r5 = r5.f
            int r5 = r5 + r6
            android.view.View r7 = super.a((android.view.View) r24, (int) r25, (android.support.v7.widget.RecyclerView.p) r26, (android.support.v7.widget.RecyclerView.u) r27)
            if (r7 != 0) goto L_0x0020
            return r4
        L_0x0020:
            r7 = r25
            int r7 = r0.i((int) r7)
            r9 = 1
            if (r7 != r9) goto L_0x002b
            r7 = 1
            goto L_0x002c
        L_0x002b:
            r7 = 0
        L_0x002c:
            boolean r10 = r0.x
            if (r7 == r10) goto L_0x0032
            r7 = 1
            goto L_0x0033
        L_0x0032:
            r7 = 0
        L_0x0033:
            r10 = -1
            if (r7 == 0) goto L_0x003e
            int r7 = r23.e()
            int r7 = r7 - r9
            r11 = -1
            r12 = -1
            goto L_0x0045
        L_0x003e:
            int r7 = r23.e()
            r11 = r7
            r7 = 0
            r12 = 1
        L_0x0045:
            int r13 = r0.s
            if (r13 != r9) goto L_0x0051
            boolean r13 = r23.I()
            if (r13 == 0) goto L_0x0051
            r13 = 1
            goto L_0x0052
        L_0x0051:
            r13 = 0
        L_0x0052:
            int r14 = r0.a((android.support.v7.widget.RecyclerView.p) r1, (android.support.v7.widget.RecyclerView.u) r2, (int) r7)
            r10 = r4
            r8 = -1
            r15 = 0
            r16 = 0
            r17 = -1
        L_0x005d:
            if (r7 == r11) goto L_0x0147
            int r9 = r0.a((android.support.v7.widget.RecyclerView.p) r1, (android.support.v7.widget.RecyclerView.u) r2, (int) r7)
            android.view.View r1 = r0.c((int) r7)
            if (r1 != r3) goto L_0x006b
            goto L_0x0147
        L_0x006b:
            boolean r18 = r1.hasFocusable()
            if (r18 == 0) goto L_0x0085
            if (r9 == r14) goto L_0x0085
            if (r4 == 0) goto L_0x0077
            goto L_0x0147
        L_0x0077:
            r18 = r3
            r19 = r8
            r21 = r10
            r20 = r11
            r8 = r16
            r10 = r17
            goto L_0x0133
        L_0x0085:
            android.view.ViewGroup$LayoutParams r9 = r1.getLayoutParams()
            android.support.v7.widget.GridLayoutManager$b r9 = (android.support.v7.widget.GridLayoutManager.b) r9
            int r2 = r9.e
            r18 = r3
            int r3 = r9.f
            int r3 = r3 + r2
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x009d
            if (r2 != r6) goto L_0x009d
            if (r3 != r5) goto L_0x009d
            return r1
        L_0x009d:
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x00a5
            if (r4 == 0) goto L_0x00ad
        L_0x00a5:
            boolean r19 = r1.hasFocusable()
            if (r19 != 0) goto L_0x00b9
            if (r10 != 0) goto L_0x00b9
        L_0x00ad:
            r19 = r8
            r21 = r10
        L_0x00b1:
            r20 = r11
            r8 = r16
            r10 = r17
        L_0x00b7:
            r11 = 1
            goto L_0x0103
        L_0x00b9:
            int r19 = java.lang.Math.max(r2, r6)
            int r20 = java.lang.Math.min(r3, r5)
            r21 = r10
            int r10 = r20 - r19
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x00da
            if (r10 <= r15) goto L_0x00d0
        L_0x00cd:
            r19 = r8
            goto L_0x00b1
        L_0x00d0:
            if (r10 != r15) goto L_0x00fa
            if (r2 <= r8) goto L_0x00d6
            r10 = 1
            goto L_0x00d7
        L_0x00d6:
            r10 = 0
        L_0x00d7:
            if (r13 != r10) goto L_0x00fa
            goto L_0x00cd
        L_0x00da:
            if (r4 != 0) goto L_0x00fa
            r19 = r8
            r20 = r11
            r8 = 0
            r11 = 1
            boolean r22 = r0.a((android.view.View) r1, (boolean) r8, (boolean) r11)
            if (r22 == 0) goto L_0x00fe
            r8 = r16
            if (r10 <= r8) goto L_0x00ef
            r10 = r17
            goto L_0x0103
        L_0x00ef:
            if (r10 != r8) goto L_0x0100
            r10 = r17
            if (r2 <= r10) goto L_0x00f6
            goto L_0x00f7
        L_0x00f6:
            r11 = 0
        L_0x00f7:
            if (r13 != r11) goto L_0x0102
            goto L_0x00b7
        L_0x00fa:
            r19 = r8
            r20 = r11
        L_0x00fe:
            r8 = r16
        L_0x0100:
            r10 = r17
        L_0x0102:
            r11 = 0
        L_0x0103:
            if (r11 == 0) goto L_0x0133
            boolean r11 = r1.hasFocusable()
            if (r11 == 0) goto L_0x0120
            int r4 = r9.e
            int r3 = java.lang.Math.min(r3, r5)
            int r2 = java.lang.Math.max(r2, r6)
            int r3 = r3 - r2
            r15 = r3
            r16 = r8
            r17 = r10
            r10 = r21
            r8 = r4
            r4 = r1
            goto L_0x013b
        L_0x0120:
            int r8 = r9.e
            int r3 = java.lang.Math.min(r3, r5)
            int r2 = java.lang.Math.max(r2, r6)
            int r3 = r3 - r2
            r10 = r1
            r16 = r3
            r17 = r8
            r8 = r19
            goto L_0x013b
        L_0x0133:
            r16 = r8
            r17 = r10
            r8 = r19
            r10 = r21
        L_0x013b:
            int r7 = r7 + r12
            r1 = r26
            r2 = r27
            r3 = r18
            r11 = r20
            r9 = 1
            goto L_0x005d
        L_0x0147:
            r21 = r10
            if (r4 == 0) goto L_0x014c
            goto L_0x014e
        L_0x014c:
            r4 = r21
        L_0x014e:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.a(android.view.View, int, android.support.v7.widget.RecyclerView$p, android.support.v7.widget.RecyclerView$u):android.view.View");
    }

    public void a(Rect rect, int i, int i2) {
        int i3;
        int i4;
        if (this.J == null) {
            super.a(rect, i, i2);
        }
        int n = n() + o();
        int p = p() + m();
        if (this.s == 1) {
            i4 = RecyclerView.i.a(i2, rect.height() + p, k());
            int[] iArr = this.J;
            i3 = RecyclerView.i.a(i, iArr[iArr.length - 1] + n, l());
        } else {
            i3 = RecyclerView.i.a(i, rect.width() + n, l());
            int[] iArr2 = this.J;
            i4 = RecyclerView.i.a(i2, iArr2[iArr2.length - 1] + p, k());
        }
        c(i3, i4);
    }

    /* access modifiers changed from: package-private */
    public void a(RecyclerView.p pVar, RecyclerView.u uVar, LinearLayoutManager.a aVar, int i) {
        super.a(pVar, uVar, aVar, i);
        Q();
        if (uVar.a() > 0 && !uVar.d()) {
            b(pVar, uVar, aVar, i);
        }
        P();
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x0225 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:95:0x0223  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(android.support.v7.widget.RecyclerView.p r19, android.support.v7.widget.RecyclerView.u r20, android.support.v7.widget.LinearLayoutManager.c r21, android.support.v7.widget.LinearLayoutManager.b r22) {
        /*
            r18 = this;
            r6 = r18
            r1 = r19
            r2 = r20
            r7 = r21
            r8 = r22
            android.support.v7.widget.Ba r0 = r6.u
            int r9 = r0.e()
            r10 = 1073741824(0x40000000, float:2.0)
            r11 = 1
            if (r9 == r10) goto L_0x0017
            r13 = 1
            goto L_0x0018
        L_0x0017:
            r13 = 0
        L_0x0018:
            int r0 = r18.e()
            if (r0 <= 0) goto L_0x0026
            int[] r0 = r6.J
            int r3 = r6.I
            r0 = r0[r3]
            r14 = r0
            goto L_0x0027
        L_0x0026:
            r14 = 0
        L_0x0027:
            if (r13 == 0) goto L_0x002c
            r18.Q()
        L_0x002c:
            int r0 = r7.e
            if (r0 != r11) goto L_0x0032
            r15 = 1
            goto L_0x0033
        L_0x0032:
            r15 = 0
        L_0x0033:
            int r0 = r6.I
            if (r15 != 0) goto L_0x0044
            int r0 = r7.d
            int r0 = r6.b((android.support.v7.widget.RecyclerView.p) r1, (android.support.v7.widget.RecyclerView.u) r2, (int) r0)
            int r3 = r7.d
            int r3 = r6.c(r1, r2, r3)
            int r0 = r0 + r3
        L_0x0044:
            r4 = 0
            r5 = 0
        L_0x0046:
            int r3 = r6.I
            if (r5 >= r3) goto L_0x009f
            boolean r3 = r7.a((android.support.v7.widget.RecyclerView.u) r2)
            if (r3 == 0) goto L_0x009f
            if (r0 <= 0) goto L_0x009f
            int r3 = r7.d
            int r10 = r6.c(r1, r2, r3)
            int r12 = r6.I
            if (r10 > r12) goto L_0x0071
            int r0 = r0 - r10
            if (r0 >= 0) goto L_0x0060
            goto L_0x009f
        L_0x0060:
            android.view.View r3 = r7.a((android.support.v7.widget.RecyclerView.p) r1)
            if (r3 != 0) goto L_0x0067
            goto L_0x009f
        L_0x0067:
            int r4 = r4 + r10
            android.view.View[] r10 = r6.K
            r10[r5] = r3
            int r5 = r5 + 1
            r10 = 1073741824(0x40000000, float:2.0)
            goto L_0x0046
        L_0x0071:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Item at position "
            r1.append(r2)
            r1.append(r3)
            java.lang.String r2 = " requires "
            r1.append(r2)
            r1.append(r10)
            java.lang.String r2 = " spans but GridLayoutManager has only "
            r1.append(r2)
            int r2 = r6.I
            r1.append(r2)
            java.lang.String r2 = " spans."
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x009f:
            if (r5 != 0) goto L_0x00a4
            r8.f1186b = r11
            return
        L_0x00a4:
            r10 = 0
            r0 = r18
            r1 = r19
            r2 = r20
            r3 = r5
            r12 = r5
            r5 = r15
            r0.a((android.support.v7.widget.RecyclerView.p) r1, (android.support.v7.widget.RecyclerView.u) r2, (int) r3, (int) r4, (boolean) r5)
            r0 = 0
            r1 = 0
        L_0x00b3:
            if (r0 >= r12) goto L_0x0101
            android.view.View[] r2 = r6.K
            r2 = r2[r0]
            java.util.List<android.support.v7.widget.RecyclerView$x> r3 = r7.k
            if (r3 != 0) goto L_0x00c9
            if (r15 == 0) goto L_0x00c4
            r6.b((android.view.View) r2)
            r3 = 0
            goto L_0x00d3
        L_0x00c4:
            r3 = 0
            r6.b((android.view.View) r2, (int) r3)
            goto L_0x00d3
        L_0x00c9:
            r3 = 0
            if (r15 == 0) goto L_0x00d0
            r6.a((android.view.View) r2)
            goto L_0x00d3
        L_0x00d0:
            r6.a((android.view.View) r2, (int) r3)
        L_0x00d3:
            android.graphics.Rect r4 = r6.O
            r6.a((android.view.View) r2, (android.graphics.Rect) r4)
            r6.b((android.view.View) r2, (int) r9, (boolean) r3)
            android.support.v7.widget.Ba r3 = r6.u
            int r3 = r3.b((android.view.View) r2)
            if (r3 <= r1) goto L_0x00e4
            r1 = r3
        L_0x00e4:
            android.view.ViewGroup$LayoutParams r3 = r2.getLayoutParams()
            android.support.v7.widget.GridLayoutManager$b r3 = (android.support.v7.widget.GridLayoutManager.b) r3
            r4 = 1065353216(0x3f800000, float:1.0)
            android.support.v7.widget.Ba r5 = r6.u
            int r2 = r5.c(r2)
            float r2 = (float) r2
            float r2 = r2 * r4
            int r3 = r3.f
            float r3 = (float) r3
            float r2 = r2 / r3
            int r3 = (r2 > r10 ? 1 : (r2 == r10 ? 0 : -1))
            if (r3 <= 0) goto L_0x00fe
            r10 = r2
        L_0x00fe:
            int r0 = r0 + 1
            goto L_0x00b3
        L_0x0101:
            if (r13 == 0) goto L_0x011f
            r6.a((float) r10, (int) r14)
            r0 = 0
            r1 = 0
        L_0x0108:
            if (r0 >= r12) goto L_0x011f
            android.view.View[] r2 = r6.K
            r2 = r2[r0]
            r3 = 1073741824(0x40000000, float:2.0)
            r6.b((android.view.View) r2, (int) r3, (boolean) r11)
            android.support.v7.widget.Ba r3 = r6.u
            int r2 = r3.b((android.view.View) r2)
            if (r2 <= r1) goto L_0x011c
            r1 = r2
        L_0x011c:
            int r0 = r0 + 1
            goto L_0x0108
        L_0x011f:
            r0 = 0
        L_0x0120:
            if (r0 >= r12) goto L_0x0182
            android.view.View[] r2 = r6.K
            r2 = r2[r0]
            android.support.v7.widget.Ba r3 = r6.u
            int r3 = r3.b((android.view.View) r2)
            if (r3 == r1) goto L_0x017c
            android.view.ViewGroup$LayoutParams r3 = r2.getLayoutParams()
            android.support.v7.widget.GridLayoutManager$b r3 = (android.support.v7.widget.GridLayoutManager.b) r3
            android.graphics.Rect r4 = r3.f1230b
            int r5 = r4.top
            int r9 = r4.bottom
            int r5 = r5 + r9
            int r9 = r3.topMargin
            int r5 = r5 + r9
            int r9 = r3.bottomMargin
            int r5 = r5 + r9
            int r9 = r4.left
            int r4 = r4.right
            int r9 = r9 + r4
            int r4 = r3.leftMargin
            int r9 = r9 + r4
            int r4 = r3.rightMargin
            int r9 = r9 + r4
            int r4 = r3.e
            int r10 = r3.f
            int r4 = r6.f(r4, r10)
            int r10 = r6.s
            if (r10 != r11) goto L_0x0168
            int r3 = r3.width
            r10 = 1073741824(0x40000000, float:2.0)
            r13 = 0
            int r3 = android.support.v7.widget.RecyclerView.i.a((int) r4, (int) r10, (int) r9, (int) r3, (boolean) r13)
            int r4 = r1 - r5
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r10)
            goto L_0x0178
        L_0x0168:
            r10 = 1073741824(0x40000000, float:2.0)
            r13 = 0
            int r9 = r1 - r9
            int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r10)
            int r3 = r3.height
            int r4 = android.support.v7.widget.RecyclerView.i.a((int) r4, (int) r10, (int) r5, (int) r3, (boolean) r13)
            r3 = r9
        L_0x0178:
            r6.a((android.view.View) r2, (int) r3, (int) r4, (boolean) r11)
            goto L_0x017f
        L_0x017c:
            r10 = 1073741824(0x40000000, float:2.0)
            r13 = 0
        L_0x017f:
            int r0 = r0 + 1
            goto L_0x0120
        L_0x0182:
            r13 = 0
            r8.f1185a = r1
            int r0 = r6.s
            r2 = -1
            if (r0 != r11) goto L_0x019d
            int r0 = r7.f
            if (r0 != r2) goto L_0x0195
            int r0 = r7.f1189b
            int r1 = r0 - r1
            r3 = r0
            r2 = r1
            goto L_0x019a
        L_0x0195:
            int r0 = r7.f1189b
            int r1 = r1 + r0
            r2 = r0
            r3 = r1
        L_0x019a:
            r0 = 0
            r1 = 0
            goto L_0x01b2
        L_0x019d:
            int r0 = r7.f
            if (r0 != r2) goto L_0x01ad
            int r0 = r7.f1189b
            int r1 = r0 - r1
            r2 = 0
            r3 = 0
            r17 = r1
            r1 = r0
            r0 = r17
            goto L_0x01b2
        L_0x01ad:
            int r0 = r7.f1189b
            int r1 = r1 + r0
            r2 = 0
            r3 = 0
        L_0x01b2:
            if (r13 >= r12) goto L_0x0237
            android.view.View[] r4 = r6.K
            r7 = r4[r13]
            android.view.ViewGroup$LayoutParams r4 = r7.getLayoutParams()
            r9 = r4
            android.support.v7.widget.GridLayoutManager$b r9 = (android.support.v7.widget.GridLayoutManager.b) r9
            int r4 = r6.s
            if (r4 != r11) goto L_0x01f5
            boolean r0 = r18.I()
            if (r0 == 0) goto L_0x01e2
            int r0 = r18.n()
            int[] r1 = r6.J
            int r4 = r6.I
            int r5 = r9.e
            int r4 = r4 - r5
            r1 = r1[r4]
            int r0 = r0 + r1
            android.support.v7.widget.Ba r1 = r6.u
            int r1 = r1.c(r7)
            int r1 = r0 - r1
            r15 = r0
            r10 = r1
            goto L_0x0209
        L_0x01e2:
            int r0 = r18.n()
            int[] r1 = r6.J
            int r4 = r9.e
            r1 = r1[r4]
            int r0 = r0 + r1
            android.support.v7.widget.Ba r1 = r6.u
            int r1 = r1.c(r7)
            int r1 = r1 + r0
            goto L_0x0207
        L_0x01f5:
            int r2 = r18.p()
            int[] r3 = r6.J
            int r4 = r9.e
            r3 = r3[r4]
            int r2 = r2 + r3
            android.support.v7.widget.Ba r3 = r6.u
            int r3 = r3.c(r7)
            int r3 = r3 + r2
        L_0x0207:
            r10 = r0
            r15 = r1
        L_0x0209:
            r14 = r2
            r16 = r3
            r0 = r18
            r1 = r7
            r2 = r10
            r3 = r14
            r4 = r15
            r5 = r16
            r0.a((android.view.View) r1, (int) r2, (int) r3, (int) r4, (int) r5)
            boolean r0 = r9.c()
            if (r0 != 0) goto L_0x0223
            boolean r0 = r9.b()
            if (r0 == 0) goto L_0x0225
        L_0x0223:
            r8.f1187c = r11
        L_0x0225:
            boolean r0 = r8.d
            boolean r1 = r7.hasFocusable()
            r0 = r0 | r1
            r8.d = r0
            int r13 = r13 + 1
            r0 = r10
            r2 = r14
            r1 = r15
            r3 = r16
            goto L_0x01b2
        L_0x0237:
            android.view.View[] r0 = r6.K
            r1 = 0
            java.util.Arrays.fill(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.a(android.support.v7.widget.RecyclerView$p, android.support.v7.widget.RecyclerView$u, android.support.v7.widget.LinearLayoutManager$c, android.support.v7.widget.LinearLayoutManager$b):void");
    }

    public void a(RecyclerView.p pVar, RecyclerView.u uVar, View view, android.support.v4.view.a.c cVar) {
        boolean z;
        boolean z2;
        int i;
        int i2;
        int i3;
        int i4;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof b)) {
            super.a(view, cVar);
            return;
        }
        b bVar = (b) layoutParams;
        int a2 = a(pVar, uVar, bVar.a());
        if (this.s == 0) {
            int e = bVar.e();
            i3 = bVar.f();
            i = 1;
            z2 = this.I > 1 && bVar.f() == this.I;
            z = false;
            i4 = e;
            i2 = a2;
        } else {
            i3 = 1;
            i2 = bVar.e();
            i = bVar.f();
            z2 = this.I > 1 && bVar.f() == this.I;
            z = false;
            i4 = a2;
        }
        cVar.b((Object) c.C0018c.a(i4, i3, i2, i, z2, z));
    }

    /* access modifiers changed from: package-private */
    public void a(RecyclerView.u uVar, LinearLayoutManager.c cVar, RecyclerView.i.a aVar) {
        int i = this.I;
        for (int i2 = 0; i2 < this.I && cVar.a(uVar) && i > 0; i2++) {
            int i3 = cVar.d;
            aVar.a(i3, Math.max(0, cVar.g));
            i -= this.N.a(i3);
            cVar.d += cVar.e;
        }
    }

    public void a(RecyclerView recyclerView, int i, int i2) {
        this.N.a();
    }

    public void a(RecyclerView recyclerView, int i, int i2, int i3) {
        this.N.a();
    }

    public void a(RecyclerView recyclerView, int i, int i2, Object obj) {
        this.N.a();
    }

    public boolean a(RecyclerView.j jVar) {
        return jVar instanceof b;
    }

    public int b(int i, RecyclerView.p pVar, RecyclerView.u uVar) {
        Q();
        P();
        return super.b(i, pVar, uVar);
    }

    public int b(RecyclerView.p pVar, RecyclerView.u uVar) {
        if (this.s == 0) {
            return this.I;
        }
        if (uVar.a() < 1) {
            return 0;
        }
        return a(pVar, uVar, uVar.a() - 1) + 1;
    }

    public void b(RecyclerView recyclerView, int i, int i2) {
        this.N.a();
    }

    public void b(boolean z) {
        if (!z) {
            super.b(false);
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }

    public RecyclerView.j c() {
        return this.s == 0 ? new b(-2, -1) : new b(-1, -2);
    }

    public void d(RecyclerView recyclerView) {
        this.N.a();
    }

    public void e(RecyclerView.p pVar, RecyclerView.u uVar) {
        if (uVar.d()) {
            N();
        }
        super.e(pVar, uVar);
        O();
    }

    /* access modifiers changed from: package-private */
    public int f(int i, int i2) {
        if (this.s != 1 || !I()) {
            int[] iArr = this.J;
            return iArr[i2 + i] - iArr[i];
        }
        int[] iArr2 = this.J;
        int i3 = this.I;
        return iArr2[i3 - i] - iArr2[(i3 - i) - i2];
    }

    public void g(RecyclerView.u uVar) {
        super.g(uVar);
        this.H = false;
    }

    public void k(int i) {
        if (i != this.I) {
            this.H = true;
            if (i >= 1) {
                this.I = i;
                this.N.a();
                y();
                return;
            }
            throw new IllegalArgumentException("Span count should be at least 1. Provided " + i);
        }
    }
}
