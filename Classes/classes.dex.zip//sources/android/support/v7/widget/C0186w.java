package android.support.v7.widget;

import a.b.g.a.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.view.w;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;

/* renamed from: android.support.v7.widget.w  reason: case insensitive filesystem */
public class C0186w extends MultiAutoCompleteTextView implements w {

    /* renamed from: a  reason: collision with root package name */
    private static final int[] f1460a = {16843126};

    /* renamed from: b  reason: collision with root package name */
    private final C0165l f1461b;

    /* renamed from: c  reason: collision with root package name */
    private final J f1462c;

    public C0186w(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.autoCompleteTextViewStyle);
    }

    public C0186w(Context context, AttributeSet attributeSet, int i) {
        super(lb.a(context), attributeSet, i);
        ob a2 = ob.a(getContext(), attributeSet, f1460a, i, 0);
        if (a2.g(0)) {
            setDropDownBackgroundDrawable(a2.b(0));
        }
        a2.a();
        this.f1461b = new C0165l(this);
        this.f1461b.a(attributeSet, i);
        this.f1462c = new J(this);
        this.f1462c.a(attributeSet, i);
        this.f1462c.a();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0165l lVar = this.f1461b;
        if (lVar != null) {
            lVar.a();
        }
        J j = this.f1462c;
        if (j != null) {
            j.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0165l lVar = this.f1461b;
        if (lVar != null) {
            return lVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0165l lVar = this.f1461b;
        if (lVar != null) {
            return lVar.c();
        }
        return null;
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0178s.a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0165l lVar = this.f1461b;
        if (lVar != null) {
            lVar.a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0165l lVar = this.f1461b;
        if (lVar != null) {
            lVar.a(i);
        }
    }

    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(a.b.g.b.a.a.b(getContext(), i));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0165l lVar = this.f1461b;
        if (lVar != null) {
            lVar.b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0165l lVar = this.f1461b;
        if (lVar != null) {
            lVar.a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        J j = this.f1462c;
        if (j != null) {
            j.a(context, i);
        }
    }
}
