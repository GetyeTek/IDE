package android.support.v7.widget;

import a.b.g.a.a;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.SeekBar;

public class B extends SeekBar {

    /* renamed from: a  reason: collision with root package name */
    private final C f1125a;

    public B(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.seekBarStyle);
    }

    public B(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1125a = new C(this);
        this.f1125a.a(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        this.f1125a.b();
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        this.f1125a.c();
    }

    /* access modifiers changed from: protected */
    public synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f1125a.a(canvas);
    }
}
