package android.support.v7.widget;

import a.b.f.f.b;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.w;
import android.support.v4.widget.b;
import android.support.v4.widget.r;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class K extends TextView implements w, b {

    /* renamed from: a  reason: collision with root package name */
    private final C0165l f1174a;

    /* renamed from: b  reason: collision with root package name */
    private final J f1175b;

    /* renamed from: c  reason: collision with root package name */
    private Future<a.b.f.f.b> f1176c;

    public K(Context context) {
        this(context, (AttributeSet) null);
    }

    public K(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public K(Context context, AttributeSet attributeSet, int i) {
        super(lb.a(context), attributeSet, i);
        this.f1174a = new C0165l(this);
        this.f1174a.a(attributeSet, i);
        this.f1175b = new J(this);
        this.f1175b.a(attributeSet, i);
        this.f1175b.a();
    }

    private void d() {
        Future<a.b.f.f.b> future = this.f1176c;
        if (future != null) {
            try {
                this.f1176c = null;
                r.a((TextView) this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0165l lVar = this.f1174a;
        if (lVar != null) {
            lVar.a();
        }
        J j = this.f1175b;
        if (j != null) {
            j.a();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (b.f919a) {
            return super.getAutoSizeMaxTextSize();
        }
        J j = this.f1175b;
        if (j != null) {
            return j.c();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (b.f919a) {
            return super.getAutoSizeMinTextSize();
        }
        J j = this.f1175b;
        if (j != null) {
            return j.d();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (b.f919a) {
            return super.getAutoSizeStepGranularity();
        }
        J j = this.f1175b;
        if (j != null) {
            return j.e();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (b.f919a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        J j = this.f1175b;
        return j != null ? j.f() : new int[0];
    }

    public int getAutoSizeTextType() {
        if (b.f919a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        J j = this.f1175b;
        if (j != null) {
            return j.g();
        }
        return 0;
    }

    public int getFirstBaselineToTopHeight() {
        return r.b(this);
    }

    public int getLastBaselineToBottomHeight() {
        return r.c(this);
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0165l lVar = this.f1174a;
        if (lVar != null) {
            return lVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0165l lVar = this.f1174a;
        if (lVar != null) {
            return lVar.c();
        }
        return null;
    }

    public CharSequence getText() {
        d();
        return super.getText();
    }

    public b.a getTextMetricsParamsCompat() {
        return r.e(this);
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0178s.a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        J j = this.f1175b;
        if (j != null) {
            j.a(z, i, i2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        d();
        super.onMeasure(i, i2);
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        J j = this.f1175b;
        if (j != null && !android.support.v4.widget.b.f919a && j.h()) {
            this.f1175b.b();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (android.support.v4.widget.b.f919a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        J j = this.f1175b;
        if (j != null) {
            j.a(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (android.support.v4.widget.b.f919a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        J j = this.f1175b;
        if (j != null) {
            j.a(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (android.support.v4.widget.b.f919a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        J j = this.f1175b;
        if (j != null) {
            j.a(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0165l lVar = this.f1174a;
        if (lVar != null) {
            lVar.a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0165l lVar = this.f1174a;
        if (lVar != null) {
            lVar.a(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(r.a((TextView) this, callback));
    }

    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i);
        } else {
            r.a((TextView) this, i);
        }
    }

    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i);
        } else {
            r.b(this, i);
        }
    }

    public void setLineHeight(int i) {
        r.c(this, i);
    }

    public void setPrecomputedText(a.b.f.f.b bVar) {
        r.a((TextView) this, bVar);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0165l lVar = this.f1174a;
        if (lVar != null) {
            lVar.b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0165l lVar = this.f1174a;
        if (lVar != null) {
            lVar.a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        J j = this.f1175b;
        if (j != null) {
            j.a(context, i);
        }
    }

    public void setTextFuture(Future<a.b.f.f.b> future) {
        this.f1176c = future;
        requestLayout();
    }

    public void setTextMetricsParamsCompat(b.a aVar) {
        r.a((TextView) this, aVar);
    }

    public void setTextSize(int i, float f) {
        if (android.support.v4.widget.b.f919a) {
            super.setTextSize(i, f);
            return;
        }
        J j = this.f1175b;
        if (j != null) {
            j.a(i, f);
        }
    }
}
