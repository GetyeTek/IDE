package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.LinearLayoutManager;

/* renamed from: android.support.v7.widget.sa  reason: case insensitive filesystem */
class C0179sa implements Parcelable.Creator<LinearLayoutManager.d> {
    C0179sa() {
    }

    public LinearLayoutManager.d createFromParcel(Parcel parcel) {
        return new LinearLayoutManager.d(parcel);
    }

    public LinearLayoutManager.d[] newArray(int i) {
        return new LinearLayoutManager.d[i];
    }
}
