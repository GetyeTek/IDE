package android.support.v7.widget;

import android.support.v7.widget.E;
import android.view.View;
import android.widget.AdapterView;

class F implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ E f1155a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ E.b f1156b;

    F(E.b bVar, E e) {
        this.f1156b = bVar;
        this.f1155a = e;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        E.this.setSelection(i);
        if (E.this.getOnItemClickListener() != null) {
            E.b bVar = this.f1156b;
            E.this.performItemClick(view, i, bVar.L.getItemId(i));
        }
        this.f1156b.dismiss();
    }
}
