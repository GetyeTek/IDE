package android.support.v7.widget;

import android.content.res.ColorStateList;

class P implements U {
    P() {
    }

    private Na j(T t) {
        return (Na) t.c();
    }

    public float a(T t) {
        return f(t) * 2.0f;
    }

    public void a() {
    }

    public void a(T t, float f) {
        t.d().setElevation(f);
    }

    public void a(T t, ColorStateList colorStateList) {
        j(t).a(colorStateList);
    }

    public void b(T t) {
        b(t, c(t));
    }

    public void b(T t, float f) {
        j(t).a(f, t.b(), t.a());
        i(t);
    }

    public float c(T t) {
        return j(t).b();
    }

    public void c(T t, float f) {
        j(t).a(f);
    }

    public float d(T t) {
        return t.d().getElevation();
    }

    public ColorStateList e(T t) {
        return j(t).a();
    }

    public float f(T t) {
        return j(t).c();
    }

    public float g(T t) {
        return f(t) * 2.0f;
    }

    public void h(T t) {
        b(t, c(t));
    }

    public void i(T t) {
        if (!t.b()) {
            t.a(0, 0, 0, 0);
            return;
        }
        float c2 = c(t);
        float f = f(t);
        int ceil = (int) Math.ceil((double) Oa.a(c2, f, t.a()));
        int ceil2 = (int) Math.ceil((double) Oa.b(c2, f, t.a()));
        t.a(ceil, ceil2, ceil, ceil2);
    }
}
