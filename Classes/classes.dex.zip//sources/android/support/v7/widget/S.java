package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;

class S implements U {

    /* renamed from: a  reason: collision with root package name */
    final RectF f1251a = new RectF();

    S() {
    }

    private Oa j(T t) {
        return (Oa) t.c();
    }

    public float a(T t) {
        return j(t).d();
    }

    public void a() {
        Oa.f1203b = new Q(this);
    }

    public void a(T t, float f) {
        j(t).c(f);
    }

    public void a(T t, ColorStateList colorStateList) {
        j(t).a(colorStateList);
    }

    public void b(T t) {
        j(t).a(t.a());
        i(t);
    }

    public void b(T t, float f) {
        j(t).b(f);
        i(t);
    }

    public float c(T t) {
        return j(t).c();
    }

    public void c(T t, float f) {
        j(t).a(f);
        i(t);
    }

    public float d(T t) {
        return j(t).f();
    }

    public ColorStateList e(T t) {
        return j(t).a();
    }

    public float f(T t) {
        return j(t).b();
    }

    public float g(T t) {
        return j(t).e();
    }

    public void h(T t) {
    }

    public void i(T t) {
        Rect rect = new Rect();
        j(t).a(rect);
        t.a((int) Math.ceil((double) g(t)), (int) Math.ceil((double) a(t)));
        t.a(rect.left, rect.top, rect.right, rect.bottom);
    }
}
