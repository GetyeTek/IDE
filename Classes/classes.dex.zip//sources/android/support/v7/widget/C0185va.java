package android.support.v7.widget;

import a.b.g.a.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v4.view.y;
import android.support.v4.widget.o;
import android.support.v7.view.menu.z;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* renamed from: android.support.v7.widget.va  reason: case insensitive filesystem */
public class C0185va implements z {

    /* renamed from: a  reason: collision with root package name */
    private static Method f1449a;

    /* renamed from: b  reason: collision with root package name */
    private static Method f1450b;

    /* renamed from: c  reason: collision with root package name */
    private static Method f1451c;
    final e A;
    private final d B;
    private final c C;
    private final a D;
    private Runnable E;
    final Handler F;
    private final Rect G;
    private Rect H;
    private boolean I;
    PopupWindow J;
    private Context d;
    private ListAdapter e;
    C0160ia f;
    private int g;
    private int h;
    private int i;
    private int j;
    private int k;
    private boolean l;
    private boolean m;
    private boolean n;
    private boolean o;
    private int p;
    private boolean q;
    private boolean r;
    int s;
    private View t;
    private int u;
    private DataSetObserver v;
    private View w;
    private Drawable x;
    private AdapterView.OnItemClickListener y;
    private AdapterView.OnItemSelectedListener z;

    /* renamed from: android.support.v7.widget.va$a */
    private class a implements Runnable {
        a() {
        }

        public void run() {
            C0185va.this.a();
        }
    }

    /* renamed from: android.support.v7.widget.va$b */
    private class b extends DataSetObserver {
        b() {
        }

        public void onChanged() {
            if (C0185va.this.d()) {
                C0185va.this.c();
            }
        }

        public void onInvalidated() {
            C0185va.this.dismiss();
        }
    }

    /* renamed from: android.support.v7.widget.va$c */
    private class c implements AbsListView.OnScrollListener {
        c() {
        }

        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        }

        public void onScrollStateChanged(AbsListView absListView, int i) {
            if (i == 1 && !C0185va.this.j() && C0185va.this.J.getContentView() != null) {
                C0185va vaVar = C0185va.this;
                vaVar.F.removeCallbacks(vaVar.A);
                C0185va.this.A.run();
            }
        }
    }

    /* renamed from: android.support.v7.widget.va$d */
    private class d implements View.OnTouchListener {
        d() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = C0185va.this.J) != null && popupWindow.isShowing() && x >= 0 && x < C0185va.this.J.getWidth() && y >= 0 && y < C0185va.this.J.getHeight()) {
                C0185va vaVar = C0185va.this;
                vaVar.F.postDelayed(vaVar.A, 250);
                return false;
            } else if (action != 1) {
                return false;
            } else {
                C0185va vaVar2 = C0185va.this;
                vaVar2.F.removeCallbacks(vaVar2.A);
                return false;
            }
        }
    }

    /* renamed from: android.support.v7.widget.va$e */
    private class e implements Runnable {
        e() {
        }

        public void run() {
            C0160ia iaVar = C0185va.this.f;
            if (iaVar != null && y.x(iaVar) && C0185va.this.f.getCount() > C0185va.this.f.getChildCount()) {
                int childCount = C0185va.this.f.getChildCount();
                C0185va vaVar = C0185va.this;
                if (childCount <= vaVar.s) {
                    vaVar.J.setInputMethodMode(2);
                    C0185va.this.c();
                }
            }
        }
    }

    static {
        Class<PopupWindow> cls = PopupWindow.class;
        try {
            f1449a = cls.getDeclaredMethod("setClipToScreenEnabled", new Class[]{Boolean.TYPE});
        } catch (NoSuchMethodException unused) {
            Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
        }
        try {
            f1450b = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[]{View.class, Integer.TYPE, Boolean.TYPE});
        } catch (NoSuchMethodException unused2) {
            Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
        }
        try {
            f1451c = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[]{Rect.class});
        } catch (NoSuchMethodException unused3) {
            Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
        }
    }

    public C0185va(Context context) {
        this(context, (AttributeSet) null, a.b.g.a.a.listPopupWindowStyle);
    }

    public C0185va(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public C0185va(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.g = -2;
        this.h = -2;
        this.k = 1002;
        this.m = true;
        this.p = 0;
        this.q = false;
        this.r = false;
        this.s = Integer.MAX_VALUE;
        this.u = 0;
        this.A = new e();
        this.B = new d();
        this.C = new c();
        this.D = new a();
        this.G = new Rect();
        this.d = context;
        this.F = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.ListPopupWindow, i2, i3);
        this.i = obtainStyledAttributes.getDimensionPixelOffset(j.ListPopupWindow_android_dropDownHorizontalOffset, 0);
        this.j = obtainStyledAttributes.getDimensionPixelOffset(j.ListPopupWindow_android_dropDownVerticalOffset, 0);
        if (this.j != 0) {
            this.l = true;
        }
        obtainStyledAttributes.recycle();
        this.J = new C0188x(context, attributeSet, i2, i3);
        this.J.setInputMethodMode(1);
    }

    private int a(View view, int i2, boolean z2) {
        Method method = f1450b;
        if (method != null) {
            try {
                return ((Integer) method.invoke(this.J, new Object[]{view, Integer.valueOf(i2), Boolean.valueOf(z2)})).intValue();
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
            }
        }
        return this.J.getMaxAvailableHeight(view, i2);
    }

    private void c(boolean z2) {
        Method method = f1449a;
        if (method != null) {
            try {
                method.invoke(this.J, new Object[]{Boolean.valueOf(z2)});
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v24, resolved type: android.support.v7.widget.ia} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v25, resolved type: android.support.v7.widget.ia} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: android.widget.LinearLayout} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v30, resolved type: android.support.v7.widget.ia} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0154  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int l() {
        /*
            r12 = this;
            android.support.v7.widget.ia r0 = r12.f
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = -1
            r3 = 1
            r4 = 0
            if (r0 != 0) goto L_0x00c1
            android.content.Context r0 = r12.d
            android.support.v7.widget.ta r5 = new android.support.v7.widget.ta
            r5.<init>(r12)
            r12.E = r5
            boolean r5 = r12.I
            r5 = r5 ^ r3
            android.support.v7.widget.ia r5 = r12.a(r0, r5)
            r12.f = r5
            android.graphics.drawable.Drawable r5 = r12.x
            if (r5 == 0) goto L_0x0024
            android.support.v7.widget.ia r6 = r12.f
            r6.setSelector(r5)
        L_0x0024:
            android.support.v7.widget.ia r5 = r12.f
            android.widget.ListAdapter r6 = r12.e
            r5.setAdapter(r6)
            android.support.v7.widget.ia r5 = r12.f
            android.widget.AdapterView$OnItemClickListener r6 = r12.y
            r5.setOnItemClickListener(r6)
            android.support.v7.widget.ia r5 = r12.f
            r5.setFocusable(r3)
            android.support.v7.widget.ia r5 = r12.f
            r5.setFocusableInTouchMode(r3)
            android.support.v7.widget.ia r5 = r12.f
            android.support.v7.widget.ua r6 = new android.support.v7.widget.ua
            r6.<init>(r12)
            r5.setOnItemSelectedListener(r6)
            android.support.v7.widget.ia r5 = r12.f
            android.support.v7.widget.va$c r6 = r12.C
            r5.setOnScrollListener(r6)
            android.widget.AdapterView$OnItemSelectedListener r5 = r12.z
            if (r5 == 0) goto L_0x0056
            android.support.v7.widget.ia r6 = r12.f
            r6.setOnItemSelectedListener(r5)
        L_0x0056:
            android.support.v7.widget.ia r5 = r12.f
            android.view.View r6 = r12.t
            if (r6 == 0) goto L_0x00ba
            android.widget.LinearLayout r7 = new android.widget.LinearLayout
            r7.<init>(r0)
            r7.setOrientation(r3)
            android.widget.LinearLayout$LayoutParams r0 = new android.widget.LinearLayout$LayoutParams
            r8 = 1065353216(0x3f800000, float:1.0)
            r0.<init>(r2, r4, r8)
            int r8 = r12.u
            if (r8 == 0) goto L_0x0091
            if (r8 == r3) goto L_0x008a
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r5 = "Invalid hint position "
            r0.append(r5)
            int r5 = r12.u
            r0.append(r5)
            java.lang.String r0 = r0.toString()
            java.lang.String r5 = "ListPopupWindow"
            android.util.Log.e(r5, r0)
            goto L_0x0097
        L_0x008a:
            r7.addView(r5, r0)
            r7.addView(r6)
            goto L_0x0097
        L_0x0091:
            r7.addView(r6)
            r7.addView(r5, r0)
        L_0x0097:
            int r0 = r12.h
            if (r0 < 0) goto L_0x009e
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x00a0
        L_0x009e:
            r0 = 0
            r5 = 0
        L_0x00a0:
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r5)
            r6.measure(r0, r4)
            android.view.ViewGroup$LayoutParams r0 = r6.getLayoutParams()
            android.widget.LinearLayout$LayoutParams r0 = (android.widget.LinearLayout.LayoutParams) r0
            int r5 = r6.getMeasuredHeight()
            int r6 = r0.topMargin
            int r5 = r5 + r6
            int r0 = r0.bottomMargin
            int r5 = r5 + r0
            r0 = r5
            r5 = r7
            goto L_0x00bb
        L_0x00ba:
            r0 = 0
        L_0x00bb:
            android.widget.PopupWindow r6 = r12.J
            r6.setContentView(r5)
            goto L_0x00df
        L_0x00c1:
            android.widget.PopupWindow r0 = r12.J
            android.view.View r0 = r0.getContentView()
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            android.view.View r0 = r12.t
            if (r0 == 0) goto L_0x00de
            android.view.ViewGroup$LayoutParams r5 = r0.getLayoutParams()
            android.widget.LinearLayout$LayoutParams r5 = (android.widget.LinearLayout.LayoutParams) r5
            int r0 = r0.getMeasuredHeight()
            int r6 = r5.topMargin
            int r0 = r0 + r6
            int r5 = r5.bottomMargin
            int r0 = r0 + r5
            goto L_0x00df
        L_0x00de:
            r0 = 0
        L_0x00df:
            android.widget.PopupWindow r5 = r12.J
            android.graphics.drawable.Drawable r5 = r5.getBackground()
            if (r5 == 0) goto L_0x00fb
            android.graphics.Rect r6 = r12.G
            r5.getPadding(r6)
            android.graphics.Rect r5 = r12.G
            int r6 = r5.top
            int r5 = r5.bottom
            int r5 = r5 + r6
            boolean r7 = r12.l
            if (r7 != 0) goto L_0x0101
            int r6 = -r6
            r12.j = r6
            goto L_0x0101
        L_0x00fb:
            android.graphics.Rect r5 = r12.G
            r5.setEmpty()
            r5 = 0
        L_0x0101:
            android.widget.PopupWindow r6 = r12.J
            int r6 = r6.getInputMethodMode()
            r7 = 2
            if (r6 != r7) goto L_0x010b
            goto L_0x010c
        L_0x010b:
            r3 = 0
        L_0x010c:
            android.view.View r4 = r12.b()
            int r6 = r12.j
            int r3 = r12.a(r4, r6, r3)
            boolean r4 = r12.q
            if (r4 != 0) goto L_0x0165
            int r4 = r12.g
            if (r4 != r2) goto L_0x011f
            goto L_0x0165
        L_0x011f:
            int r4 = r12.h
            r6 = -2
            if (r4 == r6) goto L_0x012e
            r1 = 1073741824(0x40000000, float:2.0)
            if (r4 == r2) goto L_0x012e
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r1)
        L_0x012c:
            r7 = r1
            goto L_0x0147
        L_0x012e:
            android.content.Context r2 = r12.d
            android.content.res.Resources r2 = r2.getResources()
            android.util.DisplayMetrics r2 = r2.getDisplayMetrics()
            int r2 = r2.widthPixels
            android.graphics.Rect r4 = r12.G
            int r6 = r4.left
            int r4 = r4.right
            int r6 = r6 + r4
            int r2 = r2 - r6
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r1)
            goto L_0x012c
        L_0x0147:
            android.support.v7.widget.ia r6 = r12.f
            r8 = 0
            r9 = -1
            int r10 = r3 - r0
            r11 = -1
            int r1 = r6.a(r7, r8, r9, r10, r11)
            if (r1 <= 0) goto L_0x0163
            android.support.v7.widget.ia r2 = r12.f
            int r2 = r2.getPaddingTop()
            android.support.v7.widget.ia r3 = r12.f
            int r3 = r3.getPaddingBottom()
            int r2 = r2 + r3
            int r5 = r5 + r2
            int r0 = r0 + r5
        L_0x0163:
            int r1 = r1 + r0
            return r1
        L_0x0165:
            int r3 = r3 + r5
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.C0185va.l():int");
    }

    private void m() {
        View view = this.t;
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.t);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public C0160ia a(Context context, boolean z2) {
        return new C0160ia(context, z2);
    }

    public void a() {
        C0160ia iaVar = this.f;
        if (iaVar != null) {
            iaVar.setListSelectionHidden(true);
            iaVar.requestLayout();
        }
    }

    public void a(int i2) {
        this.J.setAnimationStyle(i2);
    }

    public void a(Rect rect) {
        this.H = rect;
    }

    public void a(Drawable drawable) {
        this.J.setBackgroundDrawable(drawable);
    }

    public void a(View view) {
        this.w = view;
    }

    public void a(AdapterView.OnItemClickListener onItemClickListener) {
        this.y = onItemClickListener;
    }

    public void a(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.v;
        if (dataSetObserver == null) {
            this.v = new b();
        } else {
            ListAdapter listAdapter2 = this.e;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.e = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.v);
        }
        C0160ia iaVar = this.f;
        if (iaVar != null) {
            iaVar.setAdapter(this.e);
        }
    }

    public void a(PopupWindow.OnDismissListener onDismissListener) {
        this.J.setOnDismissListener(onDismissListener);
    }

    public void a(boolean z2) {
        this.I = z2;
        this.J.setFocusable(z2);
    }

    public View b() {
        return this.w;
    }

    public void b(int i2) {
        Drawable background = this.J.getBackground();
        if (background != null) {
            background.getPadding(this.G);
            Rect rect = this.G;
            this.h = rect.left + rect.right + i2;
            return;
        }
        j(i2);
    }

    public void b(boolean z2) {
        this.o = true;
        this.n = z2;
    }

    public void c() {
        int l2 = l();
        boolean j2 = j();
        o.a(this.J, this.k);
        boolean z2 = true;
        if (!this.J.isShowing()) {
            int i2 = this.h;
            if (i2 == -1) {
                i2 = -1;
            } else if (i2 == -2) {
                i2 = b().getWidth();
            }
            int i3 = this.g;
            if (i3 == -1) {
                l2 = -1;
            } else if (i3 != -2) {
                l2 = i3;
            }
            this.J.setWidth(i2);
            this.J.setHeight(l2);
            c(true);
            this.J.setOutsideTouchable(!this.r && !this.q);
            this.J.setTouchInterceptor(this.B);
            if (this.o) {
                o.a(this.J, this.n);
            }
            Method method = f1451c;
            if (method != null) {
                try {
                    method.invoke(this.J, new Object[]{this.H});
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
            o.a(this.J, b(), this.i, this.j, this.p);
            this.f.setSelection(-1);
            if (!this.I || this.f.isInTouchMode()) {
                a();
            }
            if (!this.I) {
                this.F.post(this.D);
            }
        } else if (y.x(b())) {
            int i4 = this.h;
            if (i4 == -1) {
                i4 = -1;
            } else if (i4 == -2) {
                i4 = b().getWidth();
            }
            int i5 = this.g;
            if (i5 == -1) {
                if (!j2) {
                    l2 = -1;
                }
                if (j2) {
                    this.J.setWidth(this.h == -1 ? -1 : 0);
                    this.J.setHeight(0);
                } else {
                    this.J.setWidth(this.h == -1 ? -1 : 0);
                    this.J.setHeight(-1);
                }
            } else if (i5 != -2) {
                l2 = i5;
            }
            PopupWindow popupWindow = this.J;
            if (this.r || this.q) {
                z2 = false;
            }
            popupWindow.setOutsideTouchable(z2);
            this.J.update(b(), this.i, this.j, i4 < 0 ? -1 : i4, l2 < 0 ? -1 : l2);
        }
    }

    public void c(int i2) {
        this.p = i2;
    }

    public void d(int i2) {
        if (i2 >= 0 || -2 == i2 || -1 == i2) {
            this.g = i2;
            return;
        }
        throw new IllegalArgumentException("Invalid height. Must be a positive value, MATCH_PARENT, or WRAP_CONTENT.");
    }

    public boolean d() {
        return this.J.isShowing();
    }

    public void dismiss() {
        this.J.dismiss();
        m();
        this.J.setContentView((View) null);
        this.f = null;
        this.F.removeCallbacks(this.A);
    }

    public ListView e() {
        return this.f;
    }

    public void e(int i2) {
        this.i = i2;
    }

    public Drawable f() {
        return this.J.getBackground();
    }

    public void f(int i2) {
        this.J.setInputMethodMode(i2);
    }

    public int g() {
        return this.i;
    }

    public void g(int i2) {
        this.u = i2;
    }

    public int h() {
        if (!this.l) {
            return 0;
        }
        return this.j;
    }

    public void h(int i2) {
        C0160ia iaVar = this.f;
        if (d() && iaVar != null) {
            iaVar.setListSelectionHidden(false);
            iaVar.setSelection(i2);
            if (iaVar.getChoiceMode() != 0) {
                iaVar.setItemChecked(i2, true);
            }
        }
    }

    public int i() {
        return this.h;
    }

    public void i(int i2) {
        this.j = i2;
        this.l = true;
    }

    public void j(int i2) {
        this.h = i2;
    }

    public boolean j() {
        return this.J.getInputMethodMode() == 2;
    }

    public boolean k() {
        return this.I;
    }
}
