package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.widget.FrameLayout;

public class M extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    private static final int[] f1194a = {16842801};

    /* renamed from: b  reason: collision with root package name */
    private static final U f1195b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f1196c;
    private boolean d;
    int e;
    int f;
    final Rect g;
    private final T h;

    static {
        int i = Build.VERSION.SDK_INT;
        f1195b = i >= 21 ? new P() : i >= 17 ? new O() : new S();
        f1195b.a();
    }

    public ColorStateList getCardBackgroundColor() {
        return f1195b.e(this.h);
    }

    public float getCardElevation() {
        return f1195b.d(this.h);
    }

    public int getContentPaddingBottom() {
        return this.g.bottom;
    }

    public int getContentPaddingLeft() {
        return this.g.left;
    }

    public int getContentPaddingRight() {
        return this.g.right;
    }

    public int getContentPaddingTop() {
        return this.g.top;
    }

    public float getMaxCardElevation() {
        return f1195b.c(this.h);
    }

    public boolean getPreventCornerOverlap() {
        return this.d;
    }

    public float getRadius() {
        return f1195b.f(this.h);
    }

    public boolean getUseCompatPadding() {
        return this.f1196c;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        if (!(f1195b instanceof P)) {
            int mode = View.MeasureSpec.getMode(i);
            if (mode == Integer.MIN_VALUE || mode == 1073741824) {
                i = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) f1195b.g(this.h)), View.MeasureSpec.getSize(i)), mode);
            }
            int mode2 = View.MeasureSpec.getMode(i2);
            if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
                i2 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) f1195b.a(this.h)), View.MeasureSpec.getSize(i2)), mode2);
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCardBackgroundColor(int i) {
        f1195b.a(this.h, ColorStateList.valueOf(i));
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        f1195b.a(this.h, colorStateList);
    }

    public void setCardElevation(float f2) {
        f1195b.a(this.h, f2);
    }

    public void setMaxCardElevation(float f2) {
        f1195b.b(this.h, f2);
    }

    public void setMinimumHeight(int i) {
        this.f = i;
        super.setMinimumHeight(i);
    }

    public void setMinimumWidth(int i) {
        this.e = i;
        super.setMinimumWidth(i);
    }

    public void setPadding(int i, int i2, int i3, int i4) {
    }

    public void setPaddingRelative(int i, int i2, int i3, int i4) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.d) {
            this.d = z;
            f1195b.b(this.h);
        }
    }

    public void setRadius(float f2) {
        f1195b.c(this.h, f2);
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f1196c != z) {
            this.f1196c = z;
            f1195b.h(this.h);
        }
    }
}
