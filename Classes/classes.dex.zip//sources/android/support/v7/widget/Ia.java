package android.support.v7.widget;

import android.support.v7.widget.Cb;
import android.support.v7.widget.RecyclerView;
import android.view.View;

class Ia implements Cb.b {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView.i f1169a;

    Ia(RecyclerView.i iVar) {
        this.f1169a = iVar;
    }

    public int a() {
        return this.f1169a.n();
    }

    public int a(View view) {
        return this.f1169a.f(view) - ((RecyclerView.j) view.getLayoutParams()).leftMargin;
    }

    public View a(int i) {
        return this.f1169a.c(i);
    }

    public int b() {
        return this.f1169a.q() - this.f1169a.o();
    }

    public int b(View view) {
        return this.f1169a.i(view) + ((RecyclerView.j) view.getLayoutParams()).rightMargin;
    }
}
