package android.support.v7.widget;

import android.view.View;

/* renamed from: android.support.v7.widget.ta  reason: case insensitive filesystem */
class C0181ta implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0185va f1437a;

    C0181ta(C0185va vaVar) {
        this.f1437a = vaVar;
    }

    public void run() {
        View b2 = this.f1437a.b();
        if (b2 != null && b2.getWindowToken() != null) {
            this.f1437a.c();
        }
    }
}
