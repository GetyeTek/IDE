package android.support.v7.widget;

/* renamed from: android.support.v7.widget.ja  reason: case insensitive filesystem */
class C0162ja implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0166la f1370a;

    C0162ja(C0166la laVar) {
        this.f1370a = laVar;
    }

    public void run() {
        this.f1370a.a(500);
    }
}
