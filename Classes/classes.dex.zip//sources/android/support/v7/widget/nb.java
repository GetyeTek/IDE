package android.support.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

class nb extends Ma {

    /* renamed from: b  reason: collision with root package name */
    private final WeakReference<Context> f1401b;

    public nb(Context context, Resources resources) {
        super(resources);
        this.f1401b = new WeakReference<>(context);
    }

    public Drawable getDrawable(int i) {
        Drawable drawable = super.getDrawable(i);
        Context context = (Context) this.f1401b.get();
        if (!(drawable == null || context == null)) {
            C0175q.a();
            C0175q.a(context, i, drawable);
        }
        return drawable;
    }
}
