package android.support.v7.widget;

import android.support.v7.widget.ActionMenuView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

class pb implements ActionMenuView.e {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ Toolbar f1419a;

    pb(Toolbar toolbar) {
        this.f1419a = toolbar;
    }

    public boolean onMenuItemClick(MenuItem menuItem) {
        Toolbar.c cVar = this.f1419a.G;
        if (cVar != null) {
            return cVar.onMenuItemClick(menuItem);
        }
        return false;
    }
}
