package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.SearchView;

/* renamed from: android.support.v7.widget.cb  reason: case insensitive filesystem */
class C0145cb implements Parcelable.ClassLoaderCreator<SearchView.e> {
    C0145cb() {
    }

    public SearchView.e createFromParcel(Parcel parcel) {
        return new SearchView.e(parcel, (ClassLoader) null);
    }

    public SearchView.e createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new SearchView.e(parcel, classLoader);
    }

    public SearchView.e[] newArray(int i) {
        return new SearchView.e[i];
    }
}
