package android.support.v7.widget;

import a.b.g.b.a.a;
import android.content.Context;
import android.support.v4.widget.r;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.o  reason: case insensitive filesystem */
public class C0171o extends CheckedTextView {

    /* renamed from: a  reason: collision with root package name */
    private static final int[] f1402a = {16843016};

    /* renamed from: b  reason: collision with root package name */
    private final J f1403b;

    public C0171o(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16843720);
    }

    public C0171o(Context context, AttributeSet attributeSet, int i) {
        super(lb.a(context), attributeSet, i);
        this.f1403b = new J(this);
        this.f1403b.a(attributeSet, i);
        this.f1403b.a();
        ob a2 = ob.a(getContext(), attributeSet, f1402a, i, 0);
        setCheckMarkDrawable(a2.b(0));
        a2.a();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        J j = this.f1403b;
        if (j != null) {
            j.a();
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0178s.a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(a.b(getContext(), i));
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(r.a((TextView) this, callback));
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        J j = this.f1403b;
        if (j != null) {
            j.a(context, i);
        }
    }
}
