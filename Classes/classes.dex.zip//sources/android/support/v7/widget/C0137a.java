package android.support.v7.widget;

import a.b.g.a.a;
import a.b.g.a.j;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.support.v4.view.J;
import android.support.v4.view.K;
import android.support.v4.view.y;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: android.support.v7.widget.a  reason: case insensitive filesystem */
abstract class C0137a extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    protected final C0023a f1309a;

    /* renamed from: b  reason: collision with root package name */
    protected final Context f1310b;

    /* renamed from: c  reason: collision with root package name */
    protected ActionMenuView f1311c;
    protected C0155g d;
    protected int e;
    protected J f;
    private boolean g;
    private boolean h;

    /* renamed from: android.support.v7.widget.a$a  reason: collision with other inner class name */
    protected class C0023a implements K {

        /* renamed from: a  reason: collision with root package name */
        private boolean f1312a = false;

        /* renamed from: b  reason: collision with root package name */
        int f1313b;

        protected C0023a() {
        }

        public C0023a a(J j, int i) {
            C0137a.this.f = j;
            this.f1313b = i;
            return this;
        }

        public void a(View view) {
            this.f1312a = true;
        }

        public void b(View view) {
            if (!this.f1312a) {
                C0137a aVar = C0137a.this;
                aVar.f = null;
                C0137a.super.setVisibility(this.f1313b);
            }
        }

        public void c(View view) {
            C0137a.super.setVisibility(0);
            this.f1312a = false;
        }
    }

    C0137a(Context context) {
        this(context, (AttributeSet) null);
    }

    C0137a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    C0137a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        int i2;
        this.f1309a = new C0023a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(a.actionBarPopupTheme, typedValue, true) || (i2 = typedValue.resourceId) == 0) {
            this.f1310b = context;
        } else {
            this.f1310b = new ContextThemeWrapper(context, i2);
        }
    }

    protected static int a(int i, int i2, boolean z) {
        return z ? i - i2 : i + i2;
    }

    /* access modifiers changed from: protected */
    public int a(View view, int i, int i2, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i2);
        return Math.max(0, (i - view.getMeasuredWidth()) - i3);
    }

    /* access modifiers changed from: protected */
    public int a(View view, int i, int i2, int i3, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = i2 + ((i3 - measuredHeight) / 2);
        if (z) {
            view.layout(i - measuredWidth, i4, i, measuredHeight + i4);
        } else {
            view.layout(i, i4, i + measuredWidth, measuredHeight + i4);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    public J a(int i, long j) {
        J j2 = this.f;
        if (j2 != null) {
            j2.a();
        }
        if (i == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            J a2 = y.a(this);
            a2.a(1.0f);
            a2.a(j);
            C0023a aVar = this.f1309a;
            aVar.a(a2, i);
            a2.a((K) aVar);
            return a2;
        }
        J a3 = y.a(this);
        a3.a(0.0f);
        a3.a(j);
        C0023a aVar2 = this.f1309a;
        aVar2.a(a3, i);
        a3.a((K) aVar2);
        return a3;
    }

    public int getAnimatedVisibility() {
        return this.f != null ? this.f1309a.f1313b : getVisibility();
    }

    public int getContentHeight() {
        return this.e;
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes((AttributeSet) null, j.ActionBar, a.actionBarStyle, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(j.ActionBar_height, 0));
        obtainStyledAttributes.recycle();
        C0155g gVar = this.d;
        if (gVar != null) {
            gVar.a(configuration);
        }
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.h = false;
        }
        if (!this.h) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.h = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.h = false;
        }
        return true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.g = false;
        }
        if (!this.g) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.g = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.g = false;
        }
        return true;
    }

    public abstract void setContentHeight(int i);

    public void setVisibility(int i) {
        if (i != getVisibility()) {
            J j = this.f;
            if (j != null) {
                j.a();
            }
            super.setVisibility(i);
        }
    }
}
