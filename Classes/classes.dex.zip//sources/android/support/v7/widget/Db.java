package android.support.v7.widget;

import a.b.f.g.h;
import a.b.f.g.l;
import a.b.f.g.m;
import android.support.v7.widget.RecyclerView;

class Db {

    /* renamed from: a  reason: collision with root package name */
    final a.b.f.g.b<RecyclerView.x, a> f1144a = new a.b.f.g.b<>();

    /* renamed from: b  reason: collision with root package name */
    final h<RecyclerView.x> f1145b = new h<>();

    static class a {

        /* renamed from: a  reason: collision with root package name */
        static l<a> f1146a = new m(20);

        /* renamed from: b  reason: collision with root package name */
        int f1147b;

        /* renamed from: c  reason: collision with root package name */
        RecyclerView.f.c f1148c;
        RecyclerView.f.c d;

        private a() {
        }

        static void a() {
            do {
            } while (f1146a.a() != null);
        }

        static void a(a aVar) {
            aVar.f1147b = 0;
            aVar.f1148c = null;
            aVar.d = null;
            f1146a.a(aVar);
        }

        static a b() {
            a a2 = f1146a.a();
            return a2 == null ? new a() : a2;
        }
    }

    interface b {
        void a(RecyclerView.x xVar);

        void a(RecyclerView.x xVar, RecyclerView.f.c cVar, RecyclerView.f.c cVar2);

        void b(RecyclerView.x xVar, RecyclerView.f.c cVar, RecyclerView.f.c cVar2);

        void c(RecyclerView.x xVar, RecyclerView.f.c cVar, RecyclerView.f.c cVar2);
    }

    Db() {
    }

    private RecyclerView.f.c a(RecyclerView.x xVar, int i) {
        a d;
        RecyclerView.f.c cVar;
        int a2 = this.f1144a.a((Object) xVar);
        if (a2 >= 0 && (d = this.f1144a.d(a2)) != null) {
            int i2 = d.f1147b;
            if ((i2 & i) != 0) {
                d.f1147b = (i ^ -1) & i2;
                if (i == 4) {
                    cVar = d.f1148c;
                } else if (i == 8) {
                    cVar = d.d;
                } else {
                    throw new IllegalArgumentException("Must provide flag PRE or POST");
                }
                if ((d.f1147b & 12) == 0) {
                    this.f1144a.c(a2);
                    a.a(d);
                }
                return cVar;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public RecyclerView.x a(long j) {
        return this.f1145b.b(j);
    }

    /* access modifiers changed from: package-private */
    public void a() {
        this.f1144a.clear();
        this.f1145b.a();
    }

    /* access modifiers changed from: package-private */
    public void a(long j, RecyclerView.x xVar) {
        this.f1145b.c(j, xVar);
    }

    /* access modifiers changed from: package-private */
    public void a(b bVar) {
        RecyclerView.f.c cVar;
        RecyclerView.f.c cVar2;
        for (int size = this.f1144a.size() - 1; size >= 0; size--) {
            RecyclerView.x b2 = this.f1144a.b(size);
            a c2 = this.f1144a.c(size);
            int i = c2.f1147b;
            if ((i & 3) != 3) {
                if ((i & 1) != 0) {
                    cVar = c2.f1148c;
                    if (cVar != null) {
                        cVar2 = c2.d;
                    }
                } else {
                    if ((i & 14) != 14) {
                        if ((i & 12) == 12) {
                            bVar.c(b2, c2.f1148c, c2.d);
                        } else if ((i & 4) != 0) {
                            cVar = c2.f1148c;
                            cVar2 = null;
                        } else if ((i & 8) == 0) {
                        }
                        a.a(c2);
                    }
                    bVar.b(b2, c2.f1148c, c2.d);
                    a.a(c2);
                }
                bVar.a(b2, cVar, cVar2);
                a.a(c2);
            }
            bVar.a(b2);
            a.a(c2);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(RecyclerView.x xVar) {
        a aVar = this.f1144a.get(xVar);
        if (aVar == null) {
            aVar = a.b();
            this.f1144a.put(xVar, aVar);
        }
        aVar.f1147b |= 1;
    }

    /* access modifiers changed from: package-private */
    public void a(RecyclerView.x xVar, RecyclerView.f.c cVar) {
        a aVar = this.f1144a.get(xVar);
        if (aVar == null) {
            aVar = a.b();
            this.f1144a.put(xVar, aVar);
        }
        aVar.f1147b |= 2;
        aVar.f1148c = cVar;
    }

    /* access modifiers changed from: package-private */
    public void b() {
        a.a();
    }

    /* access modifiers changed from: package-private */
    public void b(RecyclerView.x xVar, RecyclerView.f.c cVar) {
        a aVar = this.f1144a.get(xVar);
        if (aVar == null) {
            aVar = a.b();
            this.f1144a.put(xVar, aVar);
        }
        aVar.d = cVar;
        aVar.f1147b |= 8;
    }

    /* access modifiers changed from: package-private */
    public boolean b(RecyclerView.x xVar) {
        a aVar = this.f1144a.get(xVar);
        return (aVar == null || (aVar.f1147b & 1) == 0) ? false : true;
    }

    /* access modifiers changed from: package-private */
    public void c(RecyclerView.x xVar, RecyclerView.f.c cVar) {
        a aVar = this.f1144a.get(xVar);
        if (aVar == null) {
            aVar = a.b();
            this.f1144a.put(xVar, aVar);
        }
        aVar.f1148c = cVar;
        aVar.f1147b |= 4;
    }

    /* access modifiers changed from: package-private */
    public boolean c(RecyclerView.x xVar) {
        a aVar = this.f1144a.get(xVar);
        return (aVar == null || (aVar.f1147b & 4) == 0) ? false : true;
    }

    public void d(RecyclerView.x xVar) {
        g(xVar);
    }

    /* access modifiers changed from: package-private */
    public RecyclerView.f.c e(RecyclerView.x xVar) {
        return a(xVar, 8);
    }

    /* access modifiers changed from: package-private */
    public RecyclerView.f.c f(RecyclerView.x xVar) {
        return a(xVar, 4);
    }

    /* access modifiers changed from: package-private */
    public void g(RecyclerView.x xVar) {
        a aVar = this.f1144a.get(xVar);
        if (aVar != null) {
            aVar.f1147b &= -2;
        }
    }

    /* access modifiers changed from: package-private */
    public void h(RecyclerView.x xVar) {
        int b2 = this.f1145b.b() - 1;
        while (true) {
            if (b2 < 0) {
                break;
            } else if (xVar == this.f1145b.c(b2)) {
                this.f1145b.b(b2);
                break;
            } else {
                b2--;
            }
        }
        a remove = this.f1144a.remove(xVar);
        if (remove != null) {
            a.a(remove);
        }
    }
}
