package android.support.v7.widget;

import a.b.f.d.f;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

/* renamed from: android.support.v7.widget.pa  reason: case insensitive filesystem */
final class C0174pa implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    static final ThreadLocal<C0174pa> f1410a = new ThreadLocal<>();

    /* renamed from: b  reason: collision with root package name */
    static Comparator<b> f1411b = new C0172oa();

    /* renamed from: c  reason: collision with root package name */
    ArrayList<RecyclerView> f1412c = new ArrayList<>();
    long d;
    long e;
    private ArrayList<b> f = new ArrayList<>();

    /* renamed from: android.support.v7.widget.pa$a */
    static class a implements RecyclerView.i.a {

        /* renamed from: a  reason: collision with root package name */
        int f1413a;

        /* renamed from: b  reason: collision with root package name */
        int f1414b;

        /* renamed from: c  reason: collision with root package name */
        int[] f1415c;
        int d;

        a() {
        }

        /* access modifiers changed from: package-private */
        public void a() {
            int[] iArr = this.f1415c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.d = 0;
        }

        public void a(int i, int i2) {
            if (i < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            } else if (i2 >= 0) {
                int i3 = this.d * 2;
                int[] iArr = this.f1415c;
                if (iArr == null) {
                    this.f1415c = new int[4];
                    Arrays.fill(this.f1415c, -1);
                } else if (i3 >= iArr.length) {
                    this.f1415c = new int[(i3 * 2)];
                    System.arraycopy(iArr, 0, this.f1415c, 0, iArr.length);
                }
                int[] iArr2 = this.f1415c;
                iArr2[i3] = i;
                iArr2[i3 + 1] = i2;
                this.d++;
            } else {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            }
        }

        /* access modifiers changed from: package-private */
        public void a(RecyclerView recyclerView, boolean z) {
            this.d = 0;
            int[] iArr = this.f1415c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            RecyclerView.i iVar = recyclerView.w;
            if (recyclerView.v != null && iVar != null && iVar.v()) {
                if (z) {
                    if (!recyclerView.n.c()) {
                        iVar.a(recyclerView.v.a(), (RecyclerView.i.a) this);
                    }
                } else if (!recyclerView.j()) {
                    iVar.a(this.f1413a, this.f1414b, recyclerView.ra, (RecyclerView.i.a) this);
                }
                int i = this.d;
                if (i > iVar.m) {
                    iVar.m = i;
                    iVar.n = z;
                    recyclerView.l.j();
                }
            }
        }

        /* access modifiers changed from: package-private */
        public boolean a(int i) {
            if (this.f1415c != null) {
                int i2 = this.d * 2;
                for (int i3 = 0; i3 < i2; i3 += 2) {
                    if (this.f1415c[i3] == i) {
                        return true;
                    }
                }
            }
            return false;
        }

        /* access modifiers changed from: package-private */
        public void b(int i, int i2) {
            this.f1413a = i;
            this.f1414b = i2;
        }
    }

    /* renamed from: android.support.v7.widget.pa$b */
    static class b {

        /* renamed from: a  reason: collision with root package name */
        public boolean f1416a;

        /* renamed from: b  reason: collision with root package name */
        public int f1417b;

        /* renamed from: c  reason: collision with root package name */
        public int f1418c;
        public RecyclerView d;
        public int e;

        b() {
        }

        public void a() {
            this.f1416a = false;
            this.f1417b = 0;
            this.f1418c = 0;
            this.d = null;
            this.e = 0;
        }
    }

    C0174pa() {
    }

    private RecyclerView.x a(RecyclerView recyclerView, int i, long j) {
        if (a(recyclerView, i)) {
            return null;
        }
        RecyclerView.p pVar = recyclerView.l;
        try {
            recyclerView.q();
            RecyclerView.x a2 = pVar.a(i, false, j);
            if (a2 != null) {
                if (!a2.m() || a2.n()) {
                    pVar.a(a2, false);
                } else {
                    pVar.b(a2.f1249b);
                }
            }
            return a2;
        } finally {
            recyclerView.a(false);
        }
    }

    private void a() {
        b bVar;
        int size = this.f1412c.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            RecyclerView recyclerView = this.f1412c.get(i2);
            if (recyclerView.getWindowVisibility() == 0) {
                recyclerView.qa.a(recyclerView, false);
                i += recyclerView.qa.d;
            }
        }
        this.f.ensureCapacity(i);
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            RecyclerView recyclerView2 = this.f1412c.get(i4);
            if (recyclerView2.getWindowVisibility() == 0) {
                a aVar = recyclerView2.qa;
                int abs = Math.abs(aVar.f1413a) + Math.abs(aVar.f1414b);
                int i5 = i3;
                for (int i6 = 0; i6 < aVar.d * 2; i6 += 2) {
                    if (i5 >= this.f.size()) {
                        bVar = new b();
                        this.f.add(bVar);
                    } else {
                        bVar = this.f.get(i5);
                    }
                    int i7 = aVar.f1415c[i6 + 1];
                    bVar.f1416a = i7 <= abs;
                    bVar.f1417b = abs;
                    bVar.f1418c = i7;
                    bVar.d = recyclerView2;
                    bVar.e = aVar.f1415c[i6];
                    i5++;
                }
                i3 = i5;
            }
        }
        Collections.sort(this.f, f1411b);
    }

    private void a(RecyclerView recyclerView, long j) {
        if (recyclerView != null) {
            if (recyclerView.N && recyclerView.o.b() != 0) {
                recyclerView.t();
            }
            a aVar = recyclerView.qa;
            aVar.a(recyclerView, true);
            if (aVar.d != 0) {
                try {
                    f.a("RV Nested Prefetch");
                    recyclerView.ra.a(recyclerView.v);
                    for (int i = 0; i < aVar.d * 2; i += 2) {
                        a(recyclerView, aVar.f1415c[i], j);
                    }
                } finally {
                    f.a();
                }
            }
        }
    }

    private void a(b bVar, long j) {
        RecyclerView.x a2 = a(bVar.d, bVar.e, bVar.f1416a ? Long.MAX_VALUE : j);
        if (a2 != null && a2.f1250c != null && a2.m() && !a2.n()) {
            a((RecyclerView) a2.f1250c.get(), j);
        }
    }

    static boolean a(RecyclerView recyclerView, int i) {
        int b2 = recyclerView.o.b();
        for (int i2 = 0; i2 < b2; i2++) {
            RecyclerView.x g = RecyclerView.g(recyclerView.o.d(i2));
            if (g.d == i && !g.n()) {
                return true;
            }
        }
        return false;
    }

    private void b(long j) {
        int i = 0;
        while (i < this.f.size()) {
            b bVar = this.f.get(i);
            if (bVar.d != null) {
                a(bVar, j);
                bVar.a();
                i++;
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void a(long j) {
        a();
        b(j);
    }

    public void a(RecyclerView recyclerView) {
        this.f1412c.add(recyclerView);
    }

    /* access modifiers changed from: package-private */
    public void a(RecyclerView recyclerView, int i, int i2) {
        if (recyclerView.isAttachedToWindow() && this.d == 0) {
            this.d = recyclerView.getNanoTime();
            recyclerView.post(this);
        }
        recyclerView.qa.b(i, i2);
    }

    public void b(RecyclerView recyclerView) {
        this.f1412c.remove(recyclerView);
    }

    public void run() {
        try {
            f.a("RV Prefetch");
            if (!this.f1412c.isEmpty()) {
                int size = this.f1412c.size();
                long j = 0;
                for (int i = 0; i < size; i++) {
                    RecyclerView recyclerView = this.f1412c.get(i);
                    if (recyclerView.getWindowVisibility() == 0) {
                        j = Math.max(recyclerView.getDrawingTime(), j);
                    }
                }
                if (j != 0) {
                    a(TimeUnit.MILLISECONDS.toNanos(j) + this.e);
                    this.d = 0;
                    f.a();
                }
            }
        } finally {
            this.d = 0;
            f.a();
        }
    }
}
