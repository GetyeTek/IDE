package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;

class Ka implements Parcelable.ClassLoaderCreator<RecyclerView.s> {
    Ka() {
    }

    public RecyclerView.s createFromParcel(Parcel parcel) {
        return new RecyclerView.s(parcel, (ClassLoader) null);
    }

    public RecyclerView.s createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new RecyclerView.s(parcel, classLoader);
    }

    public RecyclerView.s[] newArray(int i) {
        return new RecyclerView.s[i];
    }
}
