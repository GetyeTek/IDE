package android.support.v7.widget;

class Ua implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1290a;

    Ua(SearchView searchView) {
        this.f1290a = searchView;
    }

    public void run() {
        this.f1290a.j();
    }
}
