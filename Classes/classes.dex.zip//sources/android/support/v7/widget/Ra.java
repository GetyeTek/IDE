package android.support.v7.widget;

import android.view.View;

class Ra implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ View f1209a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ Sa f1210b;

    Ra(Sa sa, View view) {
        this.f1210b = sa;
        this.f1209a = view;
    }

    public void run() {
        this.f1210b.smoothScrollTo(this.f1209a.getLeft() - ((this.f1210b.getWidth() - this.f1209a.getWidth()) / 2), 0);
        this.f1210b.f1253b = null;
    }
}
