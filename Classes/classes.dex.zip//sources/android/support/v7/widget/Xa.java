package android.support.v7.widget;

import android.view.View;

class Xa implements View.OnLayoutChangeListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1301a;

    Xa(SearchView searchView) {
        this.f1301a = searchView;
    }

    public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        this.f1301a.b();
    }
}
