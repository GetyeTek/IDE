package android.support.v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: android.support.v7.widget.ca  reason: case insensitive filesystem */
class C0144ca extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView.x f1325a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ View f1326b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ ViewPropertyAnimator f1327c;
    final /* synthetic */ C0156ga d;

    C0144ca(C0156ga gaVar, RecyclerView.x xVar, View view, ViewPropertyAnimator viewPropertyAnimator) {
        this.d = gaVar;
        this.f1325a = xVar;
        this.f1326b = view;
        this.f1327c = viewPropertyAnimator;
    }

    public void onAnimationCancel(Animator animator) {
        this.f1326b.setAlpha(1.0f);
    }

    public void onAnimationEnd(Animator animator) {
        this.f1327c.setListener((Animator.AnimatorListener) null);
        this.d.h(this.f1325a);
        this.d.p.remove(this.f1325a);
        this.d.j();
    }

    public void onAnimationStart(Animator animator) {
        this.d.i(this.f1325a);
    }
}
