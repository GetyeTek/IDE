package android.support.v7.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.v7.widget.Oa;

class N implements Oa.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ O f1198a;

    N(O o) {
        this.f1198a = o;
    }

    public void a(Canvas canvas, RectF rectF, float f, Paint paint) {
        canvas.drawRoundRect(rectF, f, f, paint);
    }
}
