package android.support.v7.widget;

/* renamed from: android.support.v7.widget.f  reason: case insensitive filesystem */
class C0152f implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ActionBarOverlayLayout f1337a;

    C0152f(ActionBarOverlayLayout actionBarOverlayLayout) {
        this.f1337a = actionBarOverlayLayout;
    }

    public void run() {
        this.f1337a.h();
        ActionBarOverlayLayout actionBarOverlayLayout = this.f1337a;
        actionBarOverlayLayout.x = actionBarOverlayLayout.e.animate().translationY((float) (-this.f1337a.e.getHeight())).setListener(this.f1337a.y);
    }
}
