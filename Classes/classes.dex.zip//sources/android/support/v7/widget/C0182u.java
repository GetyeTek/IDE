package android.support.v7.widget;

import a.b.g.a.j;
import a.b.g.b.a.a;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.support.v4.widget.k;
import android.util.AttributeSet;
import android.widget.ImageView;

/* renamed from: android.support.v7.widget.u  reason: case insensitive filesystem */
public class C0182u {

    /* renamed from: a  reason: collision with root package name */
    private final ImageView f1440a;

    /* renamed from: b  reason: collision with root package name */
    private mb f1441b;

    /* renamed from: c  reason: collision with root package name */
    private mb f1442c;
    private mb d;

    public C0182u(ImageView imageView) {
        this.f1440a = imageView;
    }

    private boolean a(Drawable drawable) {
        if (this.d == null) {
            this.d = new mb();
        }
        mb mbVar = this.d;
        mbVar.a();
        ColorStateList a2 = k.a(this.f1440a);
        if (a2 != null) {
            mbVar.d = true;
            mbVar.f1392a = a2;
        }
        PorterDuff.Mode b2 = k.b(this.f1440a);
        if (b2 != null) {
            mbVar.f1394c = true;
            mbVar.f1393b = b2;
        }
        if (!mbVar.d && !mbVar.f1394c) {
            return false;
        }
        C0175q.a(drawable, mbVar, this.f1440a.getDrawableState());
        return true;
    }

    private boolean e() {
        int i = Build.VERSION.SDK_INT;
        return i > 21 ? this.f1441b != null : i == 21;
    }

    /* access modifiers changed from: package-private */
    public void a() {
        Drawable drawable = this.f1440a.getDrawable();
        if (drawable != null) {
            C0158ha.b(drawable);
        }
        if (drawable == null) {
            return;
        }
        if (!e() || !a(drawable)) {
            mb mbVar = this.f1442c;
            if (mbVar != null) {
                C0175q.a(drawable, mbVar, this.f1440a.getDrawableState());
                return;
            }
            mb mbVar2 = this.f1441b;
            if (mbVar2 != null) {
                C0175q.a(drawable, mbVar2, this.f1440a.getDrawableState());
            }
        }
    }

    public void a(int i) {
        if (i != 0) {
            Drawable b2 = a.b(this.f1440a.getContext(), i);
            if (b2 != null) {
                C0158ha.b(b2);
            }
            this.f1440a.setImageDrawable(b2);
        } else {
            this.f1440a.setImageDrawable((Drawable) null);
        }
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(ColorStateList colorStateList) {
        if (this.f1442c == null) {
            this.f1442c = new mb();
        }
        mb mbVar = this.f1442c;
        mbVar.f1392a = colorStateList;
        mbVar.d = true;
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(PorterDuff.Mode mode) {
        if (this.f1442c == null) {
            this.f1442c = new mb();
        }
        mb mbVar = this.f1442c;
        mbVar.f1393b = mode;
        mbVar.f1394c = true;
        a();
    }

    public void a(AttributeSet attributeSet, int i) {
        int g;
        ob a2 = ob.a(this.f1440a.getContext(), attributeSet, j.AppCompatImageView, i, 0);
        try {
            Drawable drawable = this.f1440a.getDrawable();
            if (!(drawable != null || (g = a2.g(j.AppCompatImageView_srcCompat, -1)) == -1 || (drawable = a.b(this.f1440a.getContext(), g)) == null)) {
                this.f1440a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                C0158ha.b(drawable);
            }
            if (a2.g(j.AppCompatImageView_tint)) {
                k.a(this.f1440a, a2.a(j.AppCompatImageView_tint));
            }
            if (a2.g(j.AppCompatImageView_tintMode)) {
                k.a(this.f1440a, C0158ha.a(a2.d(j.AppCompatImageView_tintMode, -1), (PorterDuff.Mode) null));
            }
        } finally {
            a2.a();
        }
    }

    /* access modifiers changed from: package-private */
    public ColorStateList b() {
        mb mbVar = this.f1442c;
        if (mbVar != null) {
            return mbVar.f1392a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public PorterDuff.Mode c() {
        mb mbVar = this.f1442c;
        if (mbVar != null) {
            return mbVar.f1393b;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public boolean d() {
        return Build.VERSION.SDK_INT < 21 || !(this.f1440a.getBackground() instanceof RippleDrawable);
    }
}
