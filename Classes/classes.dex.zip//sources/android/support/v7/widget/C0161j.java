package android.support.v7.widget;

import a.b.f.g.l;
import a.b.f.g.m;
import android.support.v7.widget.C0191ya;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v7.widget.j  reason: case insensitive filesystem */
class C0161j implements C0191ya.a {

    /* renamed from: a  reason: collision with root package name */
    private l<b> f1364a;

    /* renamed from: b  reason: collision with root package name */
    final ArrayList<b> f1365b;

    /* renamed from: c  reason: collision with root package name */
    final ArrayList<b> f1366c;
    final a d;
    Runnable e;
    final boolean f;
    final C0191ya g;
    private int h;

    /* renamed from: android.support.v7.widget.j$a */
    interface a {
        RecyclerView.x a(int i);

        void a(int i, int i2);

        void a(int i, int i2, Object obj);

        void a(b bVar);

        void b(int i, int i2);

        void b(b bVar);

        void c(int i, int i2);

        void d(int i, int i2);
    }

    /* renamed from: android.support.v7.widget.j$b */
    static class b {

        /* renamed from: a  reason: collision with root package name */
        int f1367a;

        /* renamed from: b  reason: collision with root package name */
        int f1368b;

        /* renamed from: c  reason: collision with root package name */
        Object f1369c;
        int d;

        b(int i, int i2, int i3, Object obj) {
            this.f1367a = i;
            this.f1368b = i2;
            this.d = i3;
            this.f1369c = obj;
        }

        /* access modifiers changed from: package-private */
        public String a() {
            int i = this.f1367a;
            return i != 1 ? i != 2 ? i != 4 ? i != 8 ? "??" : "mv" : "up" : "rm" : "add";
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || b.class != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            int i = this.f1367a;
            if (i != bVar.f1367a) {
                return false;
            }
            if (i == 8 && Math.abs(this.d - this.f1368b) == 1 && this.d == bVar.f1368b && this.f1368b == bVar.d) {
                return true;
            }
            if (this.d != bVar.d || this.f1368b != bVar.f1368b) {
                return false;
            }
            Object obj2 = this.f1369c;
            if (obj2 != null) {
                if (!obj2.equals(bVar.f1369c)) {
                    return false;
                }
            } else if (bVar.f1369c != null) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (((this.f1367a * 31) + this.f1368b) * 31) + this.d;
        }

        public String toString() {
            return Integer.toHexString(System.identityHashCode(this)) + "[" + a() + ",s:" + this.f1368b + "c:" + this.d + ",p:" + this.f1369c + "]";
        }
    }

    C0161j(a aVar) {
        this(aVar, false);
    }

    C0161j(a aVar, boolean z) {
        this.f1364a = new m(30);
        this.f1365b = new ArrayList<>();
        this.f1366c = new ArrayList<>();
        this.h = 0;
        this.d = aVar;
        this.f = z;
        this.g = new C0191ya(this);
    }

    private int b(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        for (int size = this.f1366c.size() - 1; size >= 0; size--) {
            b bVar = this.f1366c.get(size);
            int i7 = bVar.f1367a;
            if (i7 == 8) {
                int i8 = bVar.f1368b;
                int i9 = bVar.d;
                if (i8 >= i9) {
                    int i10 = i9;
                    i9 = i8;
                    i8 = i10;
                }
                if (i < i8 || i > i9) {
                    int i11 = bVar.f1368b;
                    if (i < i11) {
                        if (i2 == 1) {
                            bVar.f1368b = i11 + 1;
                            i4 = bVar.d + 1;
                        } else if (i2 == 2) {
                            bVar.f1368b = i11 - 1;
                            i4 = bVar.d - 1;
                        }
                        bVar.d = i4;
                    }
                } else {
                    int i12 = bVar.f1368b;
                    if (i8 == i12) {
                        if (i2 == 1) {
                            i6 = bVar.d + 1;
                        } else {
                            if (i2 == 2) {
                                i6 = bVar.d - 1;
                            }
                            i++;
                        }
                        bVar.d = i6;
                        i++;
                    } else {
                        if (i2 == 1) {
                            i5 = i12 + 1;
                        } else {
                            if (i2 == 2) {
                                i5 = i12 - 1;
                            }
                            i--;
                        }
                        bVar.f1368b = i5;
                        i--;
                    }
                }
            } else {
                int i13 = bVar.f1368b;
                if (i13 > i) {
                    if (i2 == 1) {
                        i3 = i13 + 1;
                    } else if (i2 == 2) {
                        i3 = i13 - 1;
                    }
                    bVar.f1368b = i3;
                } else if (i7 == 1) {
                    i -= bVar.d;
                } else if (i7 == 2) {
                    i += bVar.d;
                }
            }
        }
        for (int size2 = this.f1366c.size() - 1; size2 >= 0; size2--) {
            b bVar2 = this.f1366c.get(size2);
            if (bVar2.f1367a == 8) {
                int i14 = bVar2.d;
                if (i14 != bVar2.f1368b && i14 >= 0) {
                }
            } else if (bVar2.d > 0) {
            }
            this.f1366c.remove(size2);
            a(bVar2);
        }
        return i;
    }

    private void b(b bVar) {
        g(bVar);
    }

    private void c(b bVar) {
        g(bVar);
    }

    private void d(b bVar) {
        char c2;
        boolean z;
        boolean z2;
        int i = bVar.f1368b;
        int i2 = bVar.d + i;
        int i3 = 0;
        char c3 = 65535;
        int i4 = i;
        while (i4 < i2) {
            if (this.d.a(i4) != null || d(i4)) {
                if (c3 == 0) {
                    f(a(2, i, i3, (Object) null));
                    z2 = true;
                } else {
                    z2 = false;
                }
                c2 = 1;
            } else {
                if (c3 == 1) {
                    g(a(2, i, i3, (Object) null));
                    z = true;
                } else {
                    z = false;
                }
                c2 = 0;
            }
            if (z) {
                i4 -= i3;
                i2 -= i3;
                i3 = 1;
            } else {
                i3++;
            }
            i4++;
            c3 = c2;
        }
        if (i3 != bVar.d) {
            a(bVar);
            bVar = a(2, i, i3, (Object) null);
        }
        if (c3 == 0) {
            f(bVar);
        } else {
            g(bVar);
        }
    }

    private boolean d(int i) {
        int size = this.f1366c.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.f1366c.get(i2);
            int i3 = bVar.f1367a;
            if (i3 == 8) {
                if (a(bVar.d, i2 + 1) == i) {
                    return true;
                }
            } else if (i3 == 1) {
                int i4 = bVar.f1368b;
                int i5 = bVar.d + i4;
                while (i4 < i5) {
                    if (a(i4, i2 + 1) == i) {
                        return true;
                    }
                    i4++;
                }
                continue;
            } else {
                continue;
            }
        }
        return false;
    }

    private void e(b bVar) {
        int i = bVar.f1368b;
        int i2 = bVar.d + i;
        int i3 = i;
        int i4 = 0;
        char c2 = 65535;
        while (i < i2) {
            if (this.d.a(i) != null || d(i)) {
                if (c2 == 0) {
                    f(a(4, i3, i4, bVar.f1369c));
                    i3 = i;
                    i4 = 0;
                }
                c2 = 1;
            } else {
                if (c2 == 1) {
                    g(a(4, i3, i4, bVar.f1369c));
                    i3 = i;
                    i4 = 0;
                }
                c2 = 0;
            }
            i4++;
            i++;
        }
        if (i4 != bVar.d) {
            Object obj = bVar.f1369c;
            a(bVar);
            bVar = a(4, i3, i4, obj);
        }
        if (c2 == 0) {
            f(bVar);
        } else {
            g(bVar);
        }
    }

    private void f(b bVar) {
        int i;
        int i2 = bVar.f1367a;
        if (i2 == 1 || i2 == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int b2 = b(bVar.f1368b, i2);
        int i3 = bVar.f1368b;
        int i4 = bVar.f1367a;
        if (i4 == 2) {
            i = 0;
        } else if (i4 == 4) {
            i = 1;
        } else {
            throw new IllegalArgumentException("op should be remove or update." + bVar);
        }
        int i5 = b2;
        int i6 = i3;
        int i7 = 1;
        for (int i8 = 1; i8 < bVar.d; i8++) {
            int b3 = b(bVar.f1368b + (i * i8), bVar.f1367a);
            int i9 = bVar.f1367a;
            if (i9 == 2 ? b3 == i5 : i9 == 4 && b3 == i5 + 1) {
                i7++;
            } else {
                b a2 = a(bVar.f1367a, i5, i7, bVar.f1369c);
                a(a2, i6);
                a(a2);
                if (bVar.f1367a == 4) {
                    i6 += i7;
                }
                i5 = b3;
                i7 = 1;
            }
        }
        Object obj = bVar.f1369c;
        a(bVar);
        if (i7 > 0) {
            b a3 = a(bVar.f1367a, i5, i7, obj);
            a(a3, i6);
            a(a3);
        }
    }

    private void g(b bVar) {
        this.f1366c.add(bVar);
        int i = bVar.f1367a;
        if (i == 1) {
            this.d.c(bVar.f1368b, bVar.d);
        } else if (i == 2) {
            this.d.b(bVar.f1368b, bVar.d);
        } else if (i == 4) {
            this.d.a(bVar.f1368b, bVar.d, bVar.f1369c);
        } else if (i == 8) {
            this.d.a(bVar.f1368b, bVar.d);
        } else {
            throw new IllegalArgumentException("Unknown update op type for " + bVar);
        }
    }

    public int a(int i) {
        int size = this.f1365b.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.f1365b.get(i2);
            int i3 = bVar.f1367a;
            if (i3 != 1) {
                if (i3 == 2) {
                    int i4 = bVar.f1368b;
                    if (i4 <= i) {
                        int i5 = bVar.d;
                        if (i4 + i5 > i) {
                            return -1;
                        }
                        i -= i5;
                    } else {
                        continue;
                    }
                } else if (i3 == 8) {
                    int i6 = bVar.f1368b;
                    if (i6 == i) {
                        i = bVar.d;
                    } else {
                        if (i6 < i) {
                            i--;
                        }
                        if (bVar.d <= i) {
                            i++;
                        }
                    }
                }
            } else if (bVar.f1368b <= i) {
                i += bVar.d;
            }
        }
        return i;
    }

    /* access modifiers changed from: package-private */
    public int a(int i, int i2) {
        int size = this.f1366c.size();
        while (i2 < size) {
            b bVar = this.f1366c.get(i2);
            int i3 = bVar.f1367a;
            if (i3 == 8) {
                int i4 = bVar.f1368b;
                if (i4 == i) {
                    i = bVar.d;
                } else {
                    if (i4 < i) {
                        i--;
                    }
                    if (bVar.d <= i) {
                        i++;
                    }
                }
            } else {
                int i5 = bVar.f1368b;
                if (i5 > i) {
                    continue;
                } else if (i3 == 2) {
                    int i6 = bVar.d;
                    if (i < i5 + i6) {
                        return -1;
                    }
                    i -= i6;
                } else if (i3 == 1) {
                    i += bVar.d;
                }
            }
            i2++;
        }
        return i;
    }

    public b a(int i, int i2, int i3, Object obj) {
        b a2 = this.f1364a.a();
        if (a2 == null) {
            return new b(i, i2, i3, obj);
        }
        a2.f1367a = i;
        a2.f1368b = i2;
        a2.d = i3;
        a2.f1369c = obj;
        return a2;
    }

    /* access modifiers changed from: package-private */
    public void a() {
        int size = this.f1366c.size();
        for (int i = 0; i < size; i++) {
            this.d.b(this.f1366c.get(i));
        }
        a((List<b>) this.f1366c);
        this.h = 0;
    }

    public void a(b bVar) {
        if (!this.f) {
            bVar.f1369c = null;
            this.f1364a.a(bVar);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(b bVar, int i) {
        this.d.a(bVar);
        int i2 = bVar.f1367a;
        if (i2 == 2) {
            this.d.d(i, bVar.d);
        } else if (i2 == 4) {
            this.d.a(i, bVar.d, bVar.f1369c);
        } else {
            throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
        }
    }

    /* access modifiers changed from: package-private */
    public void a(List<b> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            a(list.get(i));
        }
        list.clear();
    }

    /* access modifiers changed from: package-private */
    public int b(int i) {
        return a(i, 0);
    }

    /* access modifiers changed from: package-private */
    public void b() {
        a();
        int size = this.f1365b.size();
        for (int i = 0; i < size; i++) {
            b bVar = this.f1365b.get(i);
            int i2 = bVar.f1367a;
            if (i2 == 1) {
                this.d.b(bVar);
                this.d.c(bVar.f1368b, bVar.d);
            } else if (i2 == 2) {
                this.d.b(bVar);
                this.d.d(bVar.f1368b, bVar.d);
            } else if (i2 == 4) {
                this.d.b(bVar);
                this.d.a(bVar.f1368b, bVar.d, bVar.f1369c);
            } else if (i2 == 8) {
                this.d.b(bVar);
                this.d.a(bVar.f1368b, bVar.d);
            }
            Runnable runnable = this.e;
            if (runnable != null) {
                runnable.run();
            }
        }
        a((List<b>) this.f1365b);
        this.h = 0;
    }

    /* access modifiers changed from: package-private */
    public boolean c() {
        return this.f1365b.size() > 0;
    }

    /* access modifiers changed from: package-private */
    public boolean c(int i) {
        return (i & this.h) != 0;
    }

    /* access modifiers changed from: package-private */
    public boolean d() {
        return !this.f1366c.isEmpty() && !this.f1365b.isEmpty();
    }

    /* access modifiers changed from: package-private */
    public void e() {
        this.g.a(this.f1365b);
        int size = this.f1365b.size();
        for (int i = 0; i < size; i++) {
            b bVar = this.f1365b.get(i);
            int i2 = bVar.f1367a;
            if (i2 == 1) {
                b(bVar);
            } else if (i2 == 2) {
                d(bVar);
            } else if (i2 == 4) {
                e(bVar);
            } else if (i2 == 8) {
                c(bVar);
            }
            Runnable runnable = this.e;
            if (runnable != null) {
                runnable.run();
            }
        }
        this.f1365b.clear();
    }

    /* access modifiers changed from: package-private */
    public void f() {
        a((List<b>) this.f1365b);
        a((List<b>) this.f1366c);
        this.h = 0;
    }
}
