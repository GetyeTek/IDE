package android.support.v7.widget;

import a.b.g.a.j;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.a;
import android.support.v4.widget.c;
import android.util.AttributeSet;
import android.widget.CompoundButton;

/* renamed from: android.support.v7.widget.p  reason: case insensitive filesystem */
class C0173p {

    /* renamed from: a  reason: collision with root package name */
    private final CompoundButton f1407a;

    /* renamed from: b  reason: collision with root package name */
    private ColorStateList f1408b = null;

    /* renamed from: c  reason: collision with root package name */
    private PorterDuff.Mode f1409c = null;
    private boolean d = false;
    private boolean e = false;
    private boolean f;

    C0173p(CompoundButton compoundButton) {
        this.f1407a = compoundButton;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = android.support.v4.widget.c.a(r2.f1407a);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int a(int r3) {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 17
            if (r0 >= r1) goto L_0x0013
            android.widget.CompoundButton r0 = r2.f1407a
            android.graphics.drawable.Drawable r0 = android.support.v4.widget.c.a(r0)
            if (r0 == 0) goto L_0x0013
            int r0 = r0.getIntrinsicWidth()
            int r3 = r3 + r0
        L_0x0013:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.C0173p.a(int):int");
    }

    /* access modifiers changed from: package-private */
    public void a() {
        Drawable a2 = c.a(this.f1407a);
        if (a2 == null) {
            return;
        }
        if (this.d || this.e) {
            Drawable mutate = a.h(a2).mutate();
            if (this.d) {
                a.a(mutate, this.f1408b);
            }
            if (this.e) {
                a.a(mutate, this.f1409c);
            }
            if (mutate.isStateful()) {
                mutate.setState(this.f1407a.getDrawableState());
            }
            this.f1407a.setButtonDrawable(mutate);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(ColorStateList colorStateList) {
        this.f1408b = colorStateList;
        this.d = true;
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(PorterDuff.Mode mode) {
        this.f1409c = mode;
        this.e = true;
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(AttributeSet attributeSet, int i) {
        int resourceId;
        TypedArray obtainStyledAttributes = this.f1407a.getContext().obtainStyledAttributes(attributeSet, j.CompoundButton, i, 0);
        try {
            if (obtainStyledAttributes.hasValue(j.CompoundButton_android_button) && (resourceId = obtainStyledAttributes.getResourceId(j.CompoundButton_android_button, 0)) != 0) {
                this.f1407a.setButtonDrawable(a.b.g.b.a.a.b(this.f1407a.getContext(), resourceId));
            }
            if (obtainStyledAttributes.hasValue(j.CompoundButton_buttonTint)) {
                c.a(this.f1407a, obtainStyledAttributes.getColorStateList(j.CompoundButton_buttonTint));
            }
            if (obtainStyledAttributes.hasValue(j.CompoundButton_buttonTintMode)) {
                c.a(this.f1407a, C0158ha.a(obtainStyledAttributes.getInt(j.CompoundButton_buttonTintMode, -1), (PorterDuff.Mode) null));
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    /* access modifiers changed from: package-private */
    public ColorStateList b() {
        return this.f1408b;
    }

    /* access modifiers changed from: package-private */
    public PorterDuff.Mode c() {
        return this.f1409c;
    }

    /* access modifiers changed from: package-private */
    public void d() {
        if (this.f) {
            this.f = false;
            return;
        }
        this.f = true;
        a();
    }
}
