package android.support.v7.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Build;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class lb extends ContextWrapper {

    /* renamed from: a  reason: collision with root package name */
    private static final Object f1387a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private static ArrayList<WeakReference<lb>> f1388b;

    /* renamed from: c  reason: collision with root package name */
    private final Resources f1389c;
    private final Resources.Theme d;

    private lb(Context context) {
        super(context);
        if (Bb.b()) {
            this.f1389c = new Bb(this, context.getResources());
            this.d = this.f1389c.newTheme();
            this.d.setTo(context.getTheme());
            return;
        }
        this.f1389c = new nb(this, context.getResources());
        this.d = null;
    }

    public static Context a(Context context) {
        if (!b(context)) {
            return context;
        }
        synchronized (f1387a) {
            if (f1388b == null) {
                f1388b = new ArrayList<>();
            } else {
                for (int size = f1388b.size() - 1; size >= 0; size--) {
                    WeakReference weakReference = f1388b.get(size);
                    if (weakReference == null || weakReference.get() == null) {
                        f1388b.remove(size);
                    }
                }
                for (int size2 = f1388b.size() - 1; size2 >= 0; size2--) {
                    WeakReference weakReference2 = f1388b.get(size2);
                    lb lbVar = weakReference2 != null ? (lb) weakReference2.get() : null;
                    if (lbVar != null && lbVar.getBaseContext() == context) {
                        return lbVar;
                    }
                }
            }
            lb lbVar2 = new lb(context);
            f1388b.add(new WeakReference(lbVar2));
            return lbVar2;
        }
    }

    private static boolean b(Context context) {
        if ((context instanceof lb) || (context.getResources() instanceof nb) || (context.getResources() instanceof Bb)) {
            return false;
        }
        return Build.VERSION.SDK_INT < 21 || Bb.b();
    }

    public AssetManager getAssets() {
        return this.f1389c.getAssets();
    }

    public Resources getResources() {
        return this.f1389c;
    }

    public Resources.Theme getTheme() {
        Resources.Theme theme = this.d;
        return theme == null ? super.getTheme() : theme;
    }

    public void setTheme(int i) {
        Resources.Theme theme = this.d;
        if (theme == null) {
            super.setTheme(i);
        } else {
            theme.applyStyle(i, true);
        }
    }
}
