package android.support.v7.widget;

import android.os.Build;
import android.view.View;

public class wb {
    public static void a(View view, CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 26) {
            view.setTooltipText(charSequence);
        } else {
            zb.a(view, charSequence);
        }
    }
}
