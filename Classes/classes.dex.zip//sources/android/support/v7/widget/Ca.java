package android.support.v7.widget;

class Ca implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView f1134a;

    Ca(RecyclerView recyclerView) {
        this.f1134a = recyclerView;
    }

    public void run() {
        RecyclerView recyclerView = this.f1134a;
        if (recyclerView.E && !recyclerView.isLayoutRequested()) {
            RecyclerView recyclerView2 = this.f1134a;
            if (!recyclerView2.B) {
                recyclerView2.requestLayout();
            } else if (recyclerView2.H) {
                recyclerView2.G = true;
            } else {
                recyclerView2.b();
            }
        }
    }
}
