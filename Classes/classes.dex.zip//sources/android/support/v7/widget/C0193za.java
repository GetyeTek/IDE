package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/* renamed from: android.support.v7.widget.za  reason: case insensitive filesystem */
class C0193za extends Ba {
    C0193za(RecyclerView.i iVar) {
        super(iVar, (C0193za) null);
    }

    public int a() {
        return this.f1126a.q();
    }

    public int a(View view) {
        return this.f1126a.i(view) + ((RecyclerView.j) view.getLayoutParams()).rightMargin;
    }

    public void a(int i) {
        this.f1126a.d(i);
    }

    public int b() {
        return this.f1126a.q() - this.f1126a.o();
    }

    public int b(View view) {
        RecyclerView.j jVar = (RecyclerView.j) view.getLayoutParams();
        return this.f1126a.h(view) + jVar.leftMargin + jVar.rightMargin;
    }

    public int c() {
        return this.f1126a.o();
    }

    public int c(View view) {
        RecyclerView.j jVar = (RecyclerView.j) view.getLayoutParams();
        return this.f1126a.g(view) + jVar.topMargin + jVar.bottomMargin;
    }

    public int d() {
        return this.f1126a.r();
    }

    public int d(View view) {
        return this.f1126a.f(view) - ((RecyclerView.j) view.getLayoutParams()).leftMargin;
    }

    public int e() {
        return this.f1126a.i();
    }

    public int e(View view) {
        this.f1126a.a(view, true, this.f1128c);
        return this.f1128c.right;
    }

    public int f() {
        return this.f1126a.n();
    }

    public int f(View view) {
        this.f1126a.a(view, true, this.f1128c);
        return this.f1128c.left;
    }

    public int g() {
        return (this.f1126a.q() - this.f1126a.n()) - this.f1126a.o();
    }
}
