package android.support.v7.widget;

import android.graphics.Rect;

/* renamed from: android.support.v7.widget.ma  reason: case insensitive filesystem */
public interface C0168ma {

    /* renamed from: android.support.v7.widget.ma$a */
    public interface a {
        void a(Rect rect);
    }

    void setOnFitSystemWindowsListener(a aVar);
}
