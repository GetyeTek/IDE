package android.support.v7.widget;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public abstract class Ba {

    /* renamed from: a  reason: collision with root package name */
    protected final RecyclerView.i f1126a;

    /* renamed from: b  reason: collision with root package name */
    private int f1127b;

    /* renamed from: c  reason: collision with root package name */
    final Rect f1128c;

    private Ba(RecyclerView.i iVar) {
        this.f1127b = Integer.MIN_VALUE;
        this.f1128c = new Rect();
        this.f1126a = iVar;
    }

    /* synthetic */ Ba(RecyclerView.i iVar, C0193za zaVar) {
        this(iVar);
    }

    public static Ba a(RecyclerView.i iVar) {
        return new C0193za(iVar);
    }

    public static Ba a(RecyclerView.i iVar, int i) {
        if (i == 0) {
            return a(iVar);
        }
        if (i == 1) {
            return b(iVar);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    public static Ba b(RecyclerView.i iVar) {
        return new Aa(iVar);
    }

    public abstract int a();

    public abstract int a(View view);

    public abstract void a(int i);

    public abstract int b();

    public abstract int b(View view);

    public abstract int c();

    public abstract int c(View view);

    public abstract int d();

    public abstract int d(View view);

    public abstract int e();

    public abstract int e(View view);

    public abstract int f();

    public abstract int f(View view);

    public abstract int g();

    public int h() {
        if (Integer.MIN_VALUE == this.f1127b) {
            return 0;
        }
        return g() - this.f1127b;
    }

    public void i() {
        this.f1127b = g();
    }
}
