package android.support.v7.widget;

import android.support.v4.view.y;
import android.support.v4.view.z;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;

class zb implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: a  reason: collision with root package name */
    private static zb f1473a;

    /* renamed from: b  reason: collision with root package name */
    private static zb f1474b;

    /* renamed from: c  reason: collision with root package name */
    private final View f1475c;
    private final CharSequence d;
    private final int e;
    private final Runnable f = new xb(this);
    private final Runnable g = new yb(this);
    private int h;
    private int i;
    private Ab j;
    private boolean k;

    private zb(View view, CharSequence charSequence) {
        this.f1475c = view;
        this.d = charSequence;
        this.e = z.a(ViewConfiguration.get(this.f1475c.getContext()));
        c();
        this.f1475c.setOnLongClickListener(this);
        this.f1475c.setOnHoverListener(this);
    }

    private static void a(zb zbVar) {
        zb zbVar2 = f1473a;
        if (zbVar2 != null) {
            zbVar2.b();
        }
        f1473a = zbVar;
        zb zbVar3 = f1473a;
        if (zbVar3 != null) {
            zbVar3.d();
        }
    }

    public static void a(View view, CharSequence charSequence) {
        zb zbVar = f1473a;
        if (zbVar != null && zbVar.f1475c == view) {
            a((zb) null);
        }
        if (TextUtils.isEmpty(charSequence)) {
            zb zbVar2 = f1474b;
            if (zbVar2 != null && zbVar2.f1475c == view) {
                zbVar2.a();
            }
            view.setOnLongClickListener((View.OnLongClickListener) null);
            view.setLongClickable(false);
            view.setOnHoverListener((View.OnHoverListener) null);
            return;
        }
        new zb(view, charSequence);
    }

    private boolean a(MotionEvent motionEvent) {
        int x = (int) motionEvent.getX();
        int y = (int) motionEvent.getY();
        if (Math.abs(x - this.h) <= this.e && Math.abs(y - this.i) <= this.e) {
            return false;
        }
        this.h = x;
        this.i = y;
        return true;
    }

    private void b() {
        this.f1475c.removeCallbacks(this.f);
    }

    private void c() {
        this.h = Integer.MAX_VALUE;
        this.i = Integer.MAX_VALUE;
    }

    private void d() {
        this.f1475c.postDelayed(this.f, (long) ViewConfiguration.getLongPressTimeout());
    }

    /* access modifiers changed from: package-private */
    public void a() {
        if (f1474b == this) {
            f1474b = null;
            Ab ab = this.j;
            if (ab != null) {
                ab.a();
                this.j = null;
                c();
                this.f1475c.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1473a == this) {
            a((zb) null);
        }
        this.f1475c.removeCallbacks(this.g);
    }

    /* access modifiers changed from: package-private */
    public void a(boolean z) {
        long j2;
        if (y.x(this.f1475c)) {
            a((zb) null);
            zb zbVar = f1474b;
            if (zbVar != null) {
                zbVar.a();
            }
            f1474b = this;
            this.k = z;
            this.j = new Ab(this.f1475c.getContext());
            this.j.a(this.f1475c, this.h, this.i, this.k, this.d);
            this.f1475c.addOnAttachStateChangeListener(this);
            if (this.k) {
                j2 = 2500;
            } else {
                j2 = ((y.r(this.f1475c) & 1) == 1 ? 3000 : 15000) - ((long) ViewConfiguration.getLongPressTimeout());
            }
            this.f1475c.removeCallbacks(this.g);
            this.f1475c.postDelayed(this.g, j2);
        }
    }

    public boolean onHover(View view, MotionEvent motionEvent) {
        if (this.j != null && this.k) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f1475c.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                c();
                a();
            }
        } else if (this.f1475c.isEnabled() && this.j == null && a(motionEvent)) {
            a(this);
        }
        return false;
    }

    public boolean onLongClick(View view) {
        this.h = view.getWidth() / 2;
        this.i = view.getHeight() / 2;
        a(true);
        return true;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        a();
    }
}
