package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

class mb {

    /* renamed from: a  reason: collision with root package name */
    public ColorStateList f1392a;

    /* renamed from: b  reason: collision with root package name */
    public PorterDuff.Mode f1393b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1394c;
    public boolean d;

    mb() {
    }

    /* access modifiers changed from: package-private */
    public void a() {
        this.f1392a = null;
        this.d = false;
        this.f1393b = null;
        this.f1394c = false;
    }
}
