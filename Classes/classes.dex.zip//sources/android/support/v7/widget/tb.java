package android.support.v7.widget;

import android.support.v7.view.menu.C0132a;
import android.view.View;
import android.view.Window;

class tb implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final C0132a f1438a = new C0132a(this.f1439b.f1457a.getContext(), 0, 16908332, 0, 0, this.f1439b.i);

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ vb f1439b;

    tb(vb vbVar) {
        this.f1439b = vbVar;
    }

    public void onClick(View view) {
        vb vbVar = this.f1439b;
        Window.Callback callback = vbVar.l;
        if (callback != null && vbVar.m) {
            callback.onMenuItemSelected(0, this.f1438a);
        }
    }
}
