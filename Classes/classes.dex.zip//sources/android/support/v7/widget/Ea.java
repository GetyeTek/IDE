package android.support.v7.widget;

import android.view.animation.Interpolator;

class Ea implements Interpolator {
    Ea() {
    }

    public float getInterpolation(float f) {
        float f2 = f - 1.0f;
        return (f2 * f2 * f2 * f2 * f2) + 1.0f;
    }
}
