package android.support.v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: android.support.v7.widget.da  reason: case insensitive filesystem */
class C0147da extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView.x f1329a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ int f1330b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ View f1331c;
    final /* synthetic */ int d;
    final /* synthetic */ ViewPropertyAnimator e;
    final /* synthetic */ C0156ga f;

    C0147da(C0156ga gaVar, RecyclerView.x xVar, int i, View view, int i2, ViewPropertyAnimator viewPropertyAnimator) {
        this.f = gaVar;
        this.f1329a = xVar;
        this.f1330b = i;
        this.f1331c = view;
        this.d = i2;
        this.e = viewPropertyAnimator;
    }

    public void onAnimationCancel(Animator animator) {
        if (this.f1330b != 0) {
            this.f1331c.setTranslationX(0.0f);
        }
        if (this.d != 0) {
            this.f1331c.setTranslationY(0.0f);
        }
    }

    public void onAnimationEnd(Animator animator) {
        this.e.setListener((Animator.AnimatorListener) null);
        this.f.j(this.f1329a);
        this.f.q.remove(this.f1329a);
        this.f.j();
    }

    public void onAnimationStart(Animator animator) {
        this.f.k(this.f1329a);
    }
}
