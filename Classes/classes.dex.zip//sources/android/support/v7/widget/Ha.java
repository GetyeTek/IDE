package android.support.v7.widget;

import android.support.v7.widget.C0161j;
import android.support.v7.widget.RecyclerView;

class Ha implements C0161j.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView f1166a;

    Ha(RecyclerView recyclerView) {
        this.f1166a = recyclerView;
    }

    public RecyclerView.x a(int i) {
        RecyclerView.x a2 = this.f1166a.a(i, true);
        if (a2 != null && !this.f1166a.o.c(a2.f1249b)) {
            return a2;
        }
        return null;
    }

    public void a(int i, int i2) {
        this.f1166a.g(i, i2);
        this.f1166a.ua = true;
    }

    public void a(int i, int i2, Object obj) {
        this.f1166a.a(i, i2, obj);
        this.f1166a.va = true;
    }

    public void a(C0161j.b bVar) {
        c(bVar);
    }

    public void b(int i, int i2) {
        this.f1166a.a(i, i2, false);
        this.f1166a.ua = true;
    }

    public void b(C0161j.b bVar) {
        c(bVar);
    }

    public void c(int i, int i2) {
        this.f1166a.f(i, i2);
        this.f1166a.ua = true;
    }

    /* access modifiers changed from: package-private */
    public void c(C0161j.b bVar) {
        int i = bVar.f1367a;
        if (i == 1) {
            RecyclerView recyclerView = this.f1166a;
            recyclerView.w.a(recyclerView, bVar.f1368b, bVar.d);
        } else if (i == 2) {
            RecyclerView recyclerView2 = this.f1166a;
            recyclerView2.w.b(recyclerView2, bVar.f1368b, bVar.d);
        } else if (i == 4) {
            RecyclerView recyclerView3 = this.f1166a;
            recyclerView3.w.a(recyclerView3, bVar.f1368b, bVar.d, bVar.f1369c);
        } else if (i == 8) {
            RecyclerView recyclerView4 = this.f1166a;
            recyclerView4.w.a(recyclerView4, bVar.f1368b, bVar.d, 1);
        }
    }

    public void d(int i, int i2) {
        this.f1166a.a(i, i2, true);
        RecyclerView recyclerView = this.f1166a;
        recyclerView.ua = true;
        recyclerView.ra.d += i2;
    }
}
