package android.support.v7.widget;

import android.graphics.Typeface;
import android.support.v4.content.a.h;
import android.widget.TextView;
import java.lang.ref.WeakReference;

class I extends h.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ WeakReference f1167a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ J f1168b;

    I(J j, WeakReference weakReference) {
        this.f1168b = j;
        this.f1167a = weakReference;
    }

    public void a(int i) {
    }

    public void a(Typeface typeface) {
        this.f1168b.a((WeakReference<TextView>) this.f1167a, typeface);
    }
}
