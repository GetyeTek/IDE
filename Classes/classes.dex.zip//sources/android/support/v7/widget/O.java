package android.support.v7.widget;

class O extends S {
    O() {
    }

    public void a() {
        Oa.f1203b = new N(this);
    }
}
