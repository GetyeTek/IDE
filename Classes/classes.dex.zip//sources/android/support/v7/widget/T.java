package android.support.v7.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

interface T {
    void a(int i, int i2);

    void a(int i, int i2, int i3, int i4);

    boolean a();

    boolean b();

    Drawable c();

    View d();
}
