package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.StaggeredGridLayoutManager;

class gb implements Parcelable.Creator<StaggeredGridLayoutManager.c.a> {
    gb() {
    }

    public StaggeredGridLayoutManager.c.a createFromParcel(Parcel parcel) {
        return new StaggeredGridLayoutManager.c.a(parcel);
    }

    public StaggeredGridLayoutManager.c.a[] newArray(int i) {
        return new StaggeredGridLayoutManager.c.a[i];
    }
}
