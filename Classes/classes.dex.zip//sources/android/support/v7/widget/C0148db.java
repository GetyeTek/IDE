package android.support.v7.widget;

import android.support.v7.widget.SearchView;

/* renamed from: android.support.v7.widget.db  reason: case insensitive filesystem */
class C0148db implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView.SearchAutoComplete f1332a;

    C0148db(SearchView.SearchAutoComplete searchAutoComplete) {
        this.f1332a = searchAutoComplete;
    }

    public void run() {
        this.f1332a.b();
    }
}
