package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v4.view.w;
import android.support.v4.widget.t;
import android.util.AttributeSet;
import android.widget.ImageView;

/* renamed from: android.support.v7.widget.v  reason: case insensitive filesystem */
public class C0184v extends ImageView implements w, t {

    /* renamed from: a  reason: collision with root package name */
    private final C0165l f1447a;

    /* renamed from: b  reason: collision with root package name */
    private final C0182u f1448b;

    public C0184v(Context context) {
        this(context, (AttributeSet) null);
    }

    public C0184v(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0184v(Context context, AttributeSet attributeSet, int i) {
        super(lb.a(context), attributeSet, i);
        this.f1447a = new C0165l(this);
        this.f1447a.a(attributeSet, i);
        this.f1448b = new C0182u(this);
        this.f1448b.a(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0165l lVar = this.f1447a;
        if (lVar != null) {
            lVar.a();
        }
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            uVar.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0165l lVar = this.f1447a;
        if (lVar != null) {
            return lVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0165l lVar = this.f1447a;
        if (lVar != null) {
            return lVar.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            return uVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            return uVar.c();
        }
        return null;
    }

    public boolean hasOverlappingRendering() {
        return this.f1448b.d() && super.hasOverlappingRendering();
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0165l lVar = this.f1447a;
        if (lVar != null) {
            lVar.a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0165l lVar = this.f1447a;
        if (lVar != null) {
            lVar.a(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            uVar.a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            uVar.a();
        }
    }

    public void setImageResource(int i) {
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            uVar.a(i);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            uVar.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0165l lVar = this.f1447a;
        if (lVar != null) {
            lVar.b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0165l lVar = this.f1447a;
        if (lVar != null) {
            lVar.a(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            uVar.a(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0182u uVar = this.f1448b;
        if (uVar != null) {
            uVar.a(mode);
        }
    }
}
