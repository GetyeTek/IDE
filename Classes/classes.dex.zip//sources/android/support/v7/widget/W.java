package android.support.v7.widget;

import android.support.v7.view.menu.v;
import android.view.Menu;
import android.view.Window;

public interface W {
    void a(int i);

    void a(Menu menu, v.a aVar);

    boolean a();

    void b();

    boolean c();

    boolean d();

    boolean e();

    boolean f();

    void g();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
