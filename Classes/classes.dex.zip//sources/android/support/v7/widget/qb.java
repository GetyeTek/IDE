package android.support.v7.widget;

class qb implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ Toolbar f1426a;

    qb(Toolbar toolbar) {
        this.f1426a = toolbar;
    }

    public void run() {
        this.f1426a.k();
    }
}
