package android.support.v7.widget;

import a.b.g.a.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.view.w;
import android.support.v4.widget.b;
import android.support.v4.widget.r;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.m  reason: case insensitive filesystem */
public class C0167m extends Button implements w, b {

    /* renamed from: a  reason: collision with root package name */
    private final C0165l f1390a;

    /* renamed from: b  reason: collision with root package name */
    private final J f1391b;

    public C0167m(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.buttonStyle);
    }

    public C0167m(Context context, AttributeSet attributeSet, int i) {
        super(lb.a(context), attributeSet, i);
        this.f1390a = new C0165l(this);
        this.f1390a.a(attributeSet, i);
        this.f1391b = new J(this);
        this.f1391b.a(attributeSet, i);
        this.f1391b.a();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0165l lVar = this.f1390a;
        if (lVar != null) {
            lVar.a();
        }
        J j = this.f1391b;
        if (j != null) {
            j.a();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (b.f919a) {
            return super.getAutoSizeMaxTextSize();
        }
        J j = this.f1391b;
        if (j != null) {
            return j.c();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (b.f919a) {
            return super.getAutoSizeMinTextSize();
        }
        J j = this.f1391b;
        if (j != null) {
            return j.d();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (b.f919a) {
            return super.getAutoSizeStepGranularity();
        }
        J j = this.f1391b;
        if (j != null) {
            return j.e();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (b.f919a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        J j = this.f1391b;
        return j != null ? j.f() : new int[0];
    }

    public int getAutoSizeTextType() {
        if (b.f919a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        J j = this.f1391b;
        if (j != null) {
            return j.g();
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0165l lVar = this.f1390a;
        if (lVar != null) {
            return lVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0165l lVar = this.f1390a;
        if (lVar != null) {
            return lVar.c();
        }
        return null;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        J j = this.f1391b;
        if (j != null) {
            j.a(z, i, i2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        J j = this.f1391b;
        if (j != null && !b.f919a && j.h()) {
            this.f1391b.b();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (b.f919a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        J j = this.f1391b;
        if (j != null) {
            j.a(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (b.f919a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        J j = this.f1391b;
        if (j != null) {
            j.a(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (b.f919a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        J j = this.f1391b;
        if (j != null) {
            j.a(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0165l lVar = this.f1390a;
        if (lVar != null) {
            lVar.a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0165l lVar = this.f1390a;
        if (lVar != null) {
            lVar.a(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(r.a((TextView) this, callback));
    }

    public void setSupportAllCaps(boolean z) {
        J j = this.f1391b;
        if (j != null) {
            j.a(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0165l lVar = this.f1390a;
        if (lVar != null) {
            lVar.b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0165l lVar = this.f1390a;
        if (lVar != null) {
            lVar.a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        J j = this.f1391b;
        if (j != null) {
            j.a(context, i);
        }
    }

    public void setTextSize(int i, float f) {
        if (b.f919a) {
            super.setTextSize(i, f);
            return;
        }
        J j = this.f1391b;
        if (j != null) {
            j.a(i, f);
        }
    }
}
