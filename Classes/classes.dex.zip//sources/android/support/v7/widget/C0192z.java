package android.support.v7.widget;

import a.b.g.a.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.widget.s;
import android.util.AttributeSet;
import android.widget.RadioButton;

/* renamed from: android.support.v7.widget.z  reason: case insensitive filesystem */
public class C0192z extends RadioButton implements s {

    /* renamed from: a  reason: collision with root package name */
    private final C0173p f1471a;

    /* renamed from: b  reason: collision with root package name */
    private final J f1472b;

    public C0192z(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.radioButtonStyle);
    }

    public C0192z(Context context, AttributeSet attributeSet, int i) {
        super(lb.a(context), attributeSet, i);
        this.f1471a = new C0173p(this);
        this.f1471a.a(attributeSet, i);
        this.f1472b = new J(this);
        this.f1472b.a(attributeSet, i);
    }

    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        C0173p pVar = this.f1471a;
        return pVar != null ? pVar.a(compoundPaddingLeft) : compoundPaddingLeft;
    }

    public ColorStateList getSupportButtonTintList() {
        C0173p pVar = this.f1471a;
        if (pVar != null) {
            return pVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C0173p pVar = this.f1471a;
        if (pVar != null) {
            return pVar.c();
        }
        return null;
    }

    public void setButtonDrawable(int i) {
        setButtonDrawable(a.b.g.b.a.a.b(getContext(), i));
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0173p pVar = this.f1471a;
        if (pVar != null) {
            pVar.d();
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C0173p pVar = this.f1471a;
        if (pVar != null) {
            pVar.a(colorStateList);
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C0173p pVar = this.f1471a;
        if (pVar != null) {
            pVar.a(mode);
        }
    }
}
