package android.support.v7.widget;

import android.view.View;
import android.widget.AdapterView;

/* renamed from: android.support.v7.widget.ab  reason: case insensitive filesystem */
class C0139ab implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1317a;

    C0139ab(SearchView searchView) {
        this.f1317a = searchView;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.f1317a.a(i, 0, (String) null);
    }
}
