package android.support.v7.widget;

/* renamed from: android.support.v7.widget.e  reason: case insensitive filesystem */
class C0149e implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ActionBarOverlayLayout f1333a;

    C0149e(ActionBarOverlayLayout actionBarOverlayLayout) {
        this.f1333a = actionBarOverlayLayout;
    }

    public void run() {
        this.f1333a.h();
        ActionBarOverlayLayout actionBarOverlayLayout = this.f1333a;
        actionBarOverlayLayout.x = actionBarOverlayLayout.e.animate().translationY(0.0f).setListener(this.f1333a.y);
    }
}
