package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.v4.content.a.h;
import android.util.AttributeSet;
import android.util.TypedValue;

public class ob {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1404a;

    /* renamed from: b  reason: collision with root package name */
    private final TypedArray f1405b;

    /* renamed from: c  reason: collision with root package name */
    private TypedValue f1406c;

    private ob(Context context, TypedArray typedArray) {
        this.f1404a = context;
        this.f1405b = typedArray;
    }

    public static ob a(Context context, int i, int[] iArr) {
        return new ob(context, context.obtainStyledAttributes(i, iArr));
    }

    public static ob a(Context context, AttributeSet attributeSet, int[] iArr) {
        return new ob(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    public static ob a(Context context, AttributeSet attributeSet, int[] iArr, int i, int i2) {
        return new ob(context, context.obtainStyledAttributes(attributeSet, iArr, i, i2));
    }

    public float a(int i, float f) {
        return this.f1405b.getDimension(i, f);
    }

    public int a(int i, int i2) {
        return this.f1405b.getColor(i, i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0011, code lost:
        r0 = a.b.g.b.a.a.a(r2.f1404a, (r0 = r2.f1405b.getResourceId(r3, 0)));
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.content.res.ColorStateList a(int r3) {
        /*
            r2 = this;
            android.content.res.TypedArray r0 = r2.f1405b
            boolean r0 = r0.hasValue(r3)
            if (r0 == 0) goto L_0x001a
            android.content.res.TypedArray r0 = r2.f1405b
            r1 = 0
            int r0 = r0.getResourceId(r3, r1)
            if (r0 == 0) goto L_0x001a
            android.content.Context r1 = r2.f1404a
            android.content.res.ColorStateList r0 = a.b.g.b.a.a.a(r1, r0)
            if (r0 == 0) goto L_0x001a
            return r0
        L_0x001a:
            android.content.res.TypedArray r0 = r2.f1405b
            android.content.res.ColorStateList r3 = r0.getColorStateList(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ob.a(int):android.content.res.ColorStateList");
    }

    public Typeface a(int i, int i2, h.a aVar) {
        int resourceId = this.f1405b.getResourceId(i, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f1406c == null) {
            this.f1406c = new TypedValue();
        }
        return h.a(this.f1404a, resourceId, this.f1406c, i2, aVar);
    }

    public void a() {
        this.f1405b.recycle();
    }

    public boolean a(int i, boolean z) {
        return this.f1405b.getBoolean(i, z);
    }

    public float b(int i, float f) {
        return this.f1405b.getFloat(i, f);
    }

    public int b(int i, int i2) {
        return this.f1405b.getDimensionPixelOffset(i, i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r2.f1405b.getResourceId(r3, 0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.drawable.Drawable b(int r3) {
        /*
            r2 = this;
            android.content.res.TypedArray r0 = r2.f1405b
            boolean r0 = r0.hasValue(r3)
            if (r0 == 0) goto L_0x0018
            android.content.res.TypedArray r0 = r2.f1405b
            r1 = 0
            int r0 = r0.getResourceId(r3, r1)
            if (r0 == 0) goto L_0x0018
            android.content.Context r3 = r2.f1404a
            android.graphics.drawable.Drawable r3 = a.b.g.b.a.a.b(r3, r0)
            return r3
        L_0x0018:
            android.content.res.TypedArray r0 = r2.f1405b
            android.graphics.drawable.Drawable r3 = r0.getDrawable(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ob.b(int):android.graphics.drawable.Drawable");
    }

    public int c(int i, int i2) {
        return this.f1405b.getDimensionPixelSize(i, i2);
    }

    public Drawable c(int i) {
        int resourceId;
        if (!this.f1405b.hasValue(i) || (resourceId = this.f1405b.getResourceId(i, 0)) == 0) {
            return null;
        }
        return C0175q.a().a(this.f1404a, resourceId, true);
    }

    public int d(int i, int i2) {
        return this.f1405b.getInt(i, i2);
    }

    public String d(int i) {
        return this.f1405b.getString(i);
    }

    public int e(int i, int i2) {
        return this.f1405b.getInteger(i, i2);
    }

    public CharSequence e(int i) {
        return this.f1405b.getText(i);
    }

    public int f(int i, int i2) {
        return this.f1405b.getLayoutDimension(i, i2);
    }

    public CharSequence[] f(int i) {
        return this.f1405b.getTextArray(i);
    }

    public int g(int i, int i2) {
        return this.f1405b.getResourceId(i, i2);
    }

    public boolean g(int i) {
        return this.f1405b.hasValue(i);
    }
}
