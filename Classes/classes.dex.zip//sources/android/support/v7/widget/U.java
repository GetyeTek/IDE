package android.support.v7.widget;

import android.content.res.ColorStateList;

interface U {
    float a(T t);

    void a();

    void a(T t, float f);

    void a(T t, ColorStateList colorStateList);

    void b(T t);

    void b(T t, float f);

    float c(T t);

    void c(T t, float f);

    float d(T t);

    ColorStateList e(T t);

    float f(T t);

    float g(T t);

    void h(T t);
}
