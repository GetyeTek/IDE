package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.C0155g;

/* renamed from: android.support.v7.widget.i  reason: case insensitive filesystem */
class C0159i implements Parcelable.Creator<C0155g.C0024g> {
    C0159i() {
    }

    public C0155g.C0024g createFromParcel(Parcel parcel) {
        return new C0155g.C0024g(parcel);
    }

    public C0155g.C0024g[] newArray(int i) {
        return new C0155g.C0024g[i];
    }
}
