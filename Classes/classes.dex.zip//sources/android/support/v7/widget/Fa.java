package android.support.v7.widget;

import android.support.v7.widget.Db;
import android.support.v7.widget.RecyclerView;

class Fa implements Db.b {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView f1157a;

    Fa(RecyclerView recyclerView) {
        this.f1157a = recyclerView;
    }

    public void a(RecyclerView.x xVar) {
        RecyclerView recyclerView = this.f1157a;
        recyclerView.w.a(xVar.f1249b, recyclerView.l);
    }

    public void a(RecyclerView.x xVar, RecyclerView.f.c cVar, RecyclerView.f.c cVar2) {
        this.f1157a.l.c(xVar);
        this.f1157a.b(xVar, cVar, cVar2);
    }

    public void b(RecyclerView.x xVar, RecyclerView.f.c cVar, RecyclerView.f.c cVar2) {
        this.f1157a.a(xVar, cVar, cVar2);
    }

    public void c(RecyclerView.x xVar, RecyclerView.f.c cVar, RecyclerView.f.c cVar2) {
        xVar.a(false);
        RecyclerView recyclerView = this.f1157a;
        if (recyclerView.N) {
            if (!recyclerView.W.a(xVar, xVar, cVar, cVar2)) {
                return;
            }
        } else if (!recyclerView.W.c(xVar, cVar, cVar2)) {
            return;
        }
        this.f1157a.s();
    }
}
