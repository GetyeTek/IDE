package android.support.v7.widget;

import android.view.KeyEvent;
import android.view.View;

class Za implements View.OnKeyListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1307a;

    Za(SearchView searchView) {
        this.f1307a = searchView;
    }

    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        SearchView searchView = this.f1307a;
        if (searchView.ga == null) {
            return false;
        }
        if (searchView.q.isPopupShowing() && this.f1307a.q.getListSelection() != -1) {
            return this.f1307a.a(view, i, keyEvent);
        }
        if (this.f1307a.q.a() || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i != 66) {
            return false;
        }
        view.cancelLongPress();
        SearchView searchView2 = this.f1307a;
        searchView2.a(0, (String) null, searchView2.q.getText().toString());
        return true;
    }
}
