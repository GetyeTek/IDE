package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;
import android.view.View;

class Aa extends Ba {
    Aa(RecyclerView.i iVar) {
        super(iVar, (C0193za) null);
    }

    public int a() {
        return this.f1126a.h();
    }

    public int a(View view) {
        return this.f1126a.e(view) + ((RecyclerView.j) view.getLayoutParams()).bottomMargin;
    }

    public void a(int i) {
        this.f1126a.e(i);
    }

    public int b() {
        return this.f1126a.h() - this.f1126a.m();
    }

    public int b(View view) {
        RecyclerView.j jVar = (RecyclerView.j) view.getLayoutParams();
        return this.f1126a.g(view) + jVar.topMargin + jVar.bottomMargin;
    }

    public int c() {
        return this.f1126a.m();
    }

    public int c(View view) {
        RecyclerView.j jVar = (RecyclerView.j) view.getLayoutParams();
        return this.f1126a.h(view) + jVar.leftMargin + jVar.rightMargin;
    }

    public int d() {
        return this.f1126a.i();
    }

    public int d(View view) {
        return this.f1126a.j(view) - ((RecyclerView.j) view.getLayoutParams()).topMargin;
    }

    public int e() {
        return this.f1126a.r();
    }

    public int e(View view) {
        this.f1126a.a(view, true, this.f1128c);
        return this.f1128c.bottom;
    }

    public int f() {
        return this.f1126a.p();
    }

    public int f(View view) {
        this.f1126a.a(view, true, this.f1128c);
        return this.f1128c.top;
    }

    public int g() {
        return (this.f1126a.h() - this.f1126a.p()) - this.f1126a.m();
    }
}
