package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;

class Da implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView f1143a;

    Da(RecyclerView recyclerView) {
        this.f1143a = recyclerView;
    }

    public void run() {
        RecyclerView.f fVar = this.f1143a.W;
        if (fVar != null) {
            fVar.i();
        }
        this.f1143a.xa = false;
    }
}
