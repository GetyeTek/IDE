package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.V;
import android.view.View;
import android.view.ViewGroup;

class Ga implements V.b {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView f1161a;

    Ga(RecyclerView recyclerView) {
        this.f1161a = recyclerView;
    }

    public int a() {
        return this.f1161a.getChildCount();
    }

    public View a(int i) {
        return this.f1161a.getChildAt(i);
    }

    public void a(View view) {
        RecyclerView.x g = RecyclerView.g(view);
        if (g != null) {
            g.a(this.f1161a);
        }
    }

    public void a(View view, int i) {
        this.f1161a.addView(view, i);
        this.f1161a.a(view);
    }

    public void a(View view, int i, ViewGroup.LayoutParams layoutParams) {
        RecyclerView.x g = RecyclerView.g(view);
        if (g != null) {
            if (g.r() || g.x()) {
                g.d();
            } else {
                throw new IllegalArgumentException("Called attach on a child which is not detached: " + g + this.f1161a.i());
            }
        }
        this.f1161a.attachViewToParent(view, i, layoutParams);
    }

    public int b(View view) {
        return this.f1161a.indexOfChild(view);
    }

    public void b() {
        int a2 = a();
        for (int i = 0; i < a2; i++) {
            View a3 = a(i);
            this.f1161a.b(a3);
            a3.clearAnimation();
        }
        this.f1161a.removeAllViews();
    }

    public void b(int i) {
        RecyclerView.x g;
        View a2 = a(i);
        if (!(a2 == null || (g = RecyclerView.g(a2)) == null)) {
            if (!g.r() || g.x()) {
                g.a(256);
            } else {
                throw new IllegalArgumentException("called detach on an already detached child " + g + this.f1161a.i());
            }
        }
        this.f1161a.detachViewFromParent(i);
    }

    public RecyclerView.x c(View view) {
        return RecyclerView.g(view);
    }

    public void c(int i) {
        View childAt = this.f1161a.getChildAt(i);
        if (childAt != null) {
            this.f1161a.b(childAt);
            childAt.clearAnimation();
        }
        this.f1161a.removeViewAt(i);
    }

    public void d(View view) {
        RecyclerView.x g = RecyclerView.g(view);
        if (g != null) {
            g.b(this.f1161a);
        }
    }
}
