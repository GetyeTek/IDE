package android.support.v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.v7.widget.C0156ga;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: android.support.v7.widget.fa  reason: case insensitive filesystem */
class C0153fa extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0156ga.a f1338a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ViewPropertyAnimator f1339b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ View f1340c;
    final /* synthetic */ C0156ga d;

    C0153fa(C0156ga gaVar, C0156ga.a aVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.d = gaVar;
        this.f1338a = aVar;
        this.f1339b = viewPropertyAnimator;
        this.f1340c = view;
    }

    public void onAnimationEnd(Animator animator) {
        this.f1339b.setListener((Animator.AnimatorListener) null);
        this.f1340c.setAlpha(1.0f);
        this.f1340c.setTranslationX(0.0f);
        this.f1340c.setTranslationY(0.0f);
        this.d.a(this.f1338a.f1349b, false);
        this.d.s.remove(this.f1338a.f1349b);
        this.d.j();
    }

    public void onAnimationStart(Animator animator) {
        this.d.b(this.f1338a.f1349b, false);
    }
}
