package android.support.v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.v7.widget.C0156ga;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: android.support.v7.widget.ea  reason: case insensitive filesystem */
class C0150ea extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0156ga.a f1334a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ViewPropertyAnimator f1335b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ View f1336c;
    final /* synthetic */ C0156ga d;

    C0150ea(C0156ga gaVar, C0156ga.a aVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.d = gaVar;
        this.f1334a = aVar;
        this.f1335b = viewPropertyAnimator;
        this.f1336c = view;
    }

    public void onAnimationEnd(Animator animator) {
        this.f1335b.setListener((Animator.AnimatorListener) null);
        this.f1336c.setAlpha(1.0f);
        this.f1336c.setTranslationX(0.0f);
        this.f1336c.setTranslationY(0.0f);
        this.d.a(this.f1334a.f1348a, true);
        this.d.s.remove(this.f1334a.f1348a);
        this.d.j();
    }

    public void onAnimationStart(Animator animator) {
        this.d.b(this.f1334a.f1348a, true);
    }
}
