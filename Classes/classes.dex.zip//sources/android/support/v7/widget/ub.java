package android.support.v7.widget;

import android.support.v4.view.L;
import android.view.View;

class ub extends L {

    /* renamed from: a  reason: collision with root package name */
    private boolean f1444a = false;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ int f1445b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ vb f1446c;

    ub(vb vbVar, int i) {
        this.f1446c = vbVar;
        this.f1445b = i;
    }

    public void a(View view) {
        this.f1444a = true;
    }

    public void b(View view) {
        if (!this.f1444a) {
            this.f1446c.f1457a.setVisibility(this.f1445b);
        }
    }

    public void c(View view) {
        this.f1446c.f1457a.setVisibility(0);
    }
}
