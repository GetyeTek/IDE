package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.StaggeredGridLayoutManager;

class hb implements Parcelable.Creator<StaggeredGridLayoutManager.d> {
    hb() {
    }

    public StaggeredGridLayoutManager.d createFromParcel(Parcel parcel) {
        return new StaggeredGridLayoutManager.d(parcel);
    }

    public StaggeredGridLayoutManager.d[] newArray(int i) {
        return new StaggeredGridLayoutManager.d[i];
    }
}
