package android.support.v7.widget;

import a.b.g.e.b;
import android.view.View;

/* renamed from: android.support.v7.widget.c  reason: case insensitive filesystem */
class C0143c implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ b f1323a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ActionBarContextView f1324b;

    C0143c(ActionBarContextView actionBarContextView, b bVar) {
        this.f1324b = actionBarContextView;
        this.f1323a = bVar;
    }

    public void onClick(View view) {
        this.f1323a.a();
    }
}
