package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

class V {

    /* renamed from: a  reason: collision with root package name */
    final b f1291a;

    /* renamed from: b  reason: collision with root package name */
    final a f1292b = new a();

    /* renamed from: c  reason: collision with root package name */
    final List<View> f1293c = new ArrayList();

    static class a {

        /* renamed from: a  reason: collision with root package name */
        long f1294a = 0;

        /* renamed from: b  reason: collision with root package name */
        a f1295b;

        a() {
        }

        private void b() {
            if (this.f1295b == null) {
                this.f1295b = new a();
            }
        }

        /* access modifiers changed from: package-private */
        public void a() {
            this.f1294a = 0;
            a aVar = this.f1295b;
            if (aVar != null) {
                aVar.a();
            }
        }

        /* access modifiers changed from: package-private */
        public void a(int i) {
            if (i >= 64) {
                a aVar = this.f1295b;
                if (aVar != null) {
                    aVar.a(i - 64);
                    return;
                }
                return;
            }
            this.f1294a &= (1 << i) ^ -1;
        }

        /* access modifiers changed from: package-private */
        public void a(int i, boolean z) {
            if (i >= 64) {
                b();
                this.f1295b.a(i - 64, z);
                return;
            }
            boolean z2 = (this.f1294a & Long.MIN_VALUE) != 0;
            long j = (1 << i) - 1;
            long j2 = this.f1294a;
            this.f1294a = ((j2 & (j ^ -1)) << 1) | (j2 & j);
            if (z) {
                e(i);
            } else {
                a(i);
            }
            if (z2 || this.f1295b != null) {
                b();
                this.f1295b.a(0, z2);
            }
        }

        /* access modifiers changed from: package-private */
        public int b(int i) {
            a aVar = this.f1295b;
            return aVar == null ? i >= 64 ? Long.bitCount(this.f1294a) : Long.bitCount(this.f1294a & ((1 << i) - 1)) : i < 64 ? Long.bitCount(this.f1294a & ((1 << i) - 1)) : aVar.b(i - 64) + Long.bitCount(this.f1294a);
        }

        /* access modifiers changed from: package-private */
        public boolean c(int i) {
            if (i < 64) {
                return (this.f1294a & (1 << i)) != 0;
            }
            b();
            return this.f1295b.c(i - 64);
        }

        /* access modifiers changed from: package-private */
        public boolean d(int i) {
            if (i >= 64) {
                b();
                return this.f1295b.d(i - 64);
            }
            long j = 1 << i;
            boolean z = (this.f1294a & j) != 0;
            this.f1294a &= j ^ -1;
            long j2 = j - 1;
            long j3 = this.f1294a;
            this.f1294a = Long.rotateRight(j3 & (j2 ^ -1), 1) | (j3 & j2);
            a aVar = this.f1295b;
            if (aVar != null) {
                if (aVar.c(0)) {
                    e(63);
                }
                this.f1295b.d(0);
            }
            return z;
        }

        /* access modifiers changed from: package-private */
        public void e(int i) {
            if (i >= 64) {
                b();
                this.f1295b.e(i - 64);
                return;
            }
            this.f1294a |= 1 << i;
        }

        public String toString() {
            if (this.f1295b == null) {
                return Long.toBinaryString(this.f1294a);
            }
            return this.f1295b.toString() + "xx" + Long.toBinaryString(this.f1294a);
        }
    }

    interface b {
        int a();

        View a(int i);

        void a(View view);

        void a(View view, int i);

        void a(View view, int i, ViewGroup.LayoutParams layoutParams);

        int b(View view);

        void b();

        void b(int i);

        RecyclerView.x c(View view);

        void c(int i);

        void d(View view);
    }

    V(b bVar) {
        this.f1291a = bVar;
    }

    private int f(int i) {
        if (i < 0) {
            return -1;
        }
        int a2 = this.f1291a.a();
        int i2 = i;
        while (i2 < a2) {
            int b2 = i - (i2 - this.f1292b.b(i2));
            if (b2 == 0) {
                while (this.f1292b.c(i2)) {
                    i2++;
                }
                return i2;
            }
            i2 += b2;
        }
        return -1;
    }

    private void g(View view) {
        this.f1293c.add(view);
        this.f1291a.a(view);
    }

    private boolean h(View view) {
        if (!this.f1293c.remove(view)) {
            return false;
        }
        this.f1291a.d(view);
        return true;
    }

    /* access modifiers changed from: package-private */
    public int a() {
        return this.f1291a.a() - this.f1293c.size();
    }

    /* access modifiers changed from: package-private */
    public void a(int i) {
        int f = f(i);
        this.f1292b.d(f);
        this.f1291a.b(f);
    }

    /* access modifiers changed from: package-private */
    public void a(View view) {
        int b2 = this.f1291a.b(view);
        if (b2 >= 0) {
            this.f1292b.e(b2);
            g(view);
            return;
        }
        throw new IllegalArgumentException("view is not a child, cannot hide " + view);
    }

    /* access modifiers changed from: package-private */
    public void a(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        int a2 = i < 0 ? this.f1291a.a() : f(i);
        this.f1292b.a(a2, z);
        if (z) {
            g(view);
        }
        this.f1291a.a(view, a2, layoutParams);
    }

    /* access modifiers changed from: package-private */
    public void a(View view, int i, boolean z) {
        int a2 = i < 0 ? this.f1291a.a() : f(i);
        this.f1292b.a(a2, z);
        if (z) {
            g(view);
        }
        this.f1291a.a(view, a2);
    }

    /* access modifiers changed from: package-private */
    public void a(View view, boolean z) {
        a(view, -1, z);
    }

    /* access modifiers changed from: package-private */
    public int b() {
        return this.f1291a.a();
    }

    /* access modifiers changed from: package-private */
    public int b(View view) {
        int b2 = this.f1291a.b(view);
        if (b2 != -1 && !this.f1292b.c(b2)) {
            return b2 - this.f1292b.b(b2);
        }
        return -1;
    }

    /* access modifiers changed from: package-private */
    public View b(int i) {
        int size = this.f1293c.size();
        for (int i2 = 0; i2 < size; i2++) {
            View view = this.f1293c.get(i2);
            RecyclerView.x c2 = this.f1291a.c(view);
            if (c2.i() == i && !c2.n() && !c2.p()) {
                return view;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public View c(int i) {
        return this.f1291a.a(f(i));
    }

    /* access modifiers changed from: package-private */
    public void c() {
        this.f1292b.a();
        for (int size = this.f1293c.size() - 1; size >= 0; size--) {
            this.f1291a.d(this.f1293c.get(size));
            this.f1293c.remove(size);
        }
        this.f1291a.b();
    }

    /* access modifiers changed from: package-private */
    public boolean c(View view) {
        return this.f1293c.contains(view);
    }

    /* access modifiers changed from: package-private */
    public View d(int i) {
        return this.f1291a.a(i);
    }

    /* access modifiers changed from: package-private */
    public void d(View view) {
        int b2 = this.f1291a.b(view);
        if (b2 >= 0) {
            if (this.f1292b.d(b2)) {
                h(view);
            }
            this.f1291a.c(b2);
        }
    }

    /* access modifiers changed from: package-private */
    public void e(int i) {
        int f = f(i);
        View a2 = this.f1291a.a(f);
        if (a2 != null) {
            if (this.f1292b.d(f)) {
                h(a2);
            }
            this.f1291a.c(f);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean e(View view) {
        int b2 = this.f1291a.b(view);
        if (b2 == -1) {
            h(view);
            return true;
        } else if (!this.f1292b.c(b2)) {
            return false;
        } else {
            this.f1292b.d(b2);
            h(view);
            this.f1291a.c(b2);
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public void f(View view) {
        int b2 = this.f1291a.b(view);
        if (b2 < 0) {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        } else if (this.f1292b.c(b2)) {
            this.f1292b.a(b2);
            h(view);
        } else {
            throw new RuntimeException("trying to unhide a view that was not hidden" + view);
        }
    }

    public String toString() {
        return this.f1292b.toString() + ", hidden list:" + this.f1293c.size();
    }
}
