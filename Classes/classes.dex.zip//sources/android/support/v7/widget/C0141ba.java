package android.support.v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: android.support.v7.widget.ba  reason: case insensitive filesystem */
class C0141ba extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ RecyclerView.x f1319a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ViewPropertyAnimator f1320b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ View f1321c;
    final /* synthetic */ C0156ga d;

    C0141ba(C0156ga gaVar, RecyclerView.x xVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.d = gaVar;
        this.f1319a = xVar;
        this.f1320b = viewPropertyAnimator;
        this.f1321c = view;
    }

    public void onAnimationEnd(Animator animator) {
        this.f1320b.setListener((Animator.AnimatorListener) null);
        this.f1321c.setAlpha(1.0f);
        this.d.l(this.f1319a);
        this.d.r.remove(this.f1319a);
        this.d.j();
    }

    public void onAnimationStart(Animator animator) {
        this.d.m(this.f1319a);
    }
}
