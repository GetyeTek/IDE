package android.support.v7.widget;

import android.support.v7.view.menu.z;
import android.support.v7.widget.C0155g;
import android.view.View;

/* renamed from: android.support.v7.widget.h  reason: case insensitive filesystem */
class C0157h extends C0170na {
    final /* synthetic */ C0155g j;
    final /* synthetic */ C0155g.d k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0157h(C0155g.d dVar, View view, C0155g gVar) {
        super(view);
        this.k = dVar;
        this.j = gVar;
    }

    public z a() {
        C0155g.e eVar = C0155g.this.z;
        if (eVar == null) {
            return null;
        }
        return eVar.b();
    }

    public boolean b() {
        C0155g.this.j();
        return true;
    }

    public boolean c() {
        C0155g gVar = C0155g.this;
        if (gVar.B != null) {
            return false;
        }
        gVar.f();
        return true;
    }
}
