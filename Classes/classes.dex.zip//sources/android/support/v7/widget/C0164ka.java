package android.support.v7.widget;

import android.support.v7.widget.RecyclerView;

/* renamed from: android.support.v7.widget.ka  reason: case insensitive filesystem */
class C0164ka extends RecyclerView.n {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0166la f1377a;

    C0164ka(C0166la laVar) {
        this.f1377a = laVar;
    }

    public void a(RecyclerView recyclerView, int i, int i2) {
        this.f1377a.a(recyclerView.computeHorizontalScrollOffset(), recyclerView.computeVerticalScrollOffset());
    }
}
