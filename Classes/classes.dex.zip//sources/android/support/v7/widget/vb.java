package android.support.v7.widget;

import a.b.g.a.a;
import a.b.g.a.e;
import a.b.g.a.f;
import a.b.g.a.h;
import a.b.g.a.j;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.view.J;
import android.support.v4.view.K;
import android.support.v4.view.y;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.v;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

public class vb implements X {

    /* renamed from: a  reason: collision with root package name */
    Toolbar f1457a;

    /* renamed from: b  reason: collision with root package name */
    private int f1458b;

    /* renamed from: c  reason: collision with root package name */
    private View f1459c;
    private View d;
    private Drawable e;
    private Drawable f;
    private Drawable g;
    private boolean h;
    CharSequence i;
    private CharSequence j;
    private CharSequence k;
    Window.Callback l;
    boolean m;
    private C0155g n;
    private int o;
    private int p;
    private Drawable q;

    public vb(Toolbar toolbar, boolean z) {
        this(toolbar, z, h.abc_action_bar_up_description, e.abc_ic_ab_back_material);
    }

    public vb(Toolbar toolbar, boolean z, int i2, int i3) {
        Drawable drawable;
        this.o = 0;
        this.p = 0;
        this.f1457a = toolbar;
        this.i = toolbar.getTitle();
        this.j = toolbar.getSubtitle();
        this.h = this.i != null;
        this.g = toolbar.getNavigationIcon();
        ob a2 = ob.a(toolbar.getContext(), (AttributeSet) null, j.ActionBar, a.actionBarStyle, 0);
        this.q = a2.b(j.ActionBar_homeAsUpIndicator);
        if (z) {
            CharSequence e2 = a2.e(j.ActionBar_title);
            if (!TextUtils.isEmpty(e2)) {
                setTitle(e2);
            }
            CharSequence e3 = a2.e(j.ActionBar_subtitle);
            if (!TextUtils.isEmpty(e3)) {
                b(e3);
            }
            Drawable b2 = a2.b(j.ActionBar_logo);
            if (b2 != null) {
                c(b2);
            }
            Drawable b3 = a2.b(j.ActionBar_icon);
            if (b3 != null) {
                setIcon(b3);
            }
            if (this.g == null && (drawable = this.q) != null) {
                b(drawable);
            }
            a(a2.d(j.ActionBar_displayOptions, 0));
            int g2 = a2.g(j.ActionBar_customNavigationLayout, 0);
            if (g2 != 0) {
                a(LayoutInflater.from(this.f1457a.getContext()).inflate(g2, this.f1457a, false));
                a(this.f1458b | 16);
            }
            int f2 = a2.f(j.ActionBar_height, 0);
            if (f2 > 0) {
                ViewGroup.LayoutParams layoutParams = this.f1457a.getLayoutParams();
                layoutParams.height = f2;
                this.f1457a.setLayoutParams(layoutParams);
            }
            int b4 = a2.b(j.ActionBar_contentInsetStart, -1);
            int b5 = a2.b(j.ActionBar_contentInsetEnd, -1);
            if (b4 >= 0 || b5 >= 0) {
                this.f1457a.b(Math.max(b4, 0), Math.max(b5, 0));
            }
            int g3 = a2.g(j.ActionBar_titleTextStyle, 0);
            if (g3 != 0) {
                Toolbar toolbar2 = this.f1457a;
                toolbar2.b(toolbar2.getContext(), g3);
            }
            int g4 = a2.g(j.ActionBar_subtitleTextStyle, 0);
            if (g4 != 0) {
                Toolbar toolbar3 = this.f1457a;
                toolbar3.a(toolbar3.getContext(), g4);
            }
            int g5 = a2.g(j.ActionBar_popupTheme, 0);
            if (g5 != 0) {
                this.f1457a.setPopupTheme(g5);
            }
        } else {
            this.f1458b = s();
        }
        a2.a();
        d(i2);
        this.k = this.f1457a.getNavigationContentDescription();
        this.f1457a.setNavigationOnClickListener(new tb(this));
    }

    private void c(CharSequence charSequence) {
        this.i = charSequence;
        if ((this.f1458b & 8) != 0) {
            this.f1457a.setTitle(charSequence);
        }
    }

    private int s() {
        if (this.f1457a.getNavigationIcon() == null) {
            return 11;
        }
        this.q = this.f1457a.getNavigationIcon();
        return 15;
    }

    private void t() {
        if ((this.f1458b & 4) == 0) {
            return;
        }
        if (TextUtils.isEmpty(this.k)) {
            this.f1457a.setNavigationContentDescription(this.p);
        } else {
            this.f1457a.setNavigationContentDescription(this.k);
        }
    }

    private void u() {
        Drawable drawable;
        Toolbar toolbar;
        if ((this.f1458b & 4) != 0) {
            toolbar = this.f1457a;
            drawable = this.g;
            if (drawable == null) {
                drawable = this.q;
            }
        } else {
            toolbar = this.f1457a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    private void v() {
        Drawable drawable;
        int i2 = this.f1458b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) == 0 || (drawable = this.f) == null) {
            drawable = this.e;
        }
        this.f1457a.setLogo(drawable);
    }

    public J a(int i2, long j2) {
        J a2 = y.a(this.f1457a);
        a2.a(i2 == 0 ? 1.0f : 0.0f);
        a2.a(j2);
        a2.a((K) new ub(this, i2));
        return a2;
    }

    public void a(int i2) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i3 = this.f1458b ^ i2;
        this.f1458b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    t();
                }
                u();
            }
            if ((i3 & 3) != 0) {
                v();
            }
            if ((i3 & 8) != 0) {
                if ((i2 & 8) != 0) {
                    this.f1457a.setTitle(this.i);
                    toolbar = this.f1457a;
                    charSequence = this.j;
                } else {
                    charSequence = null;
                    this.f1457a.setTitle((CharSequence) null);
                    toolbar = this.f1457a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if ((i3 & 16) != 0 && (view = this.d) != null) {
                if ((i2 & 16) != 0) {
                    this.f1457a.addView(view);
                } else {
                    this.f1457a.removeView(view);
                }
            }
        }
    }

    public void a(Drawable drawable) {
        y.a((View) this.f1457a, drawable);
    }

    public void a(v.a aVar, l.a aVar2) {
        this.f1457a.a(aVar, aVar2);
    }

    public void a(Sa sa) {
        Toolbar toolbar;
        View view = this.f1459c;
        if (view != null && view.getParent() == (toolbar = this.f1457a)) {
            toolbar.removeView(this.f1459c);
        }
        this.f1459c = sa;
        if (sa != null && this.o == 2) {
            this.f1457a.addView(this.f1459c, 0);
            Toolbar.b bVar = (Toolbar.b) this.f1459c.getLayoutParams();
            bVar.width = -2;
            bVar.height = -2;
            bVar.f993a = 8388691;
            sa.setAllowCollapse(true);
        }
    }

    public void a(Menu menu, v.a aVar) {
        if (this.n == null) {
            this.n = new C0155g(this.f1457a.getContext());
            this.n.a(f.action_menu_presenter);
        }
        this.n.a(aVar);
        this.f1457a.a((l) menu, this.n);
    }

    public void a(View view) {
        View view2 = this.d;
        if (!(view2 == null || (this.f1458b & 16) == 0)) {
            this.f1457a.removeView(view2);
        }
        this.d = view;
        if (view != null && (this.f1458b & 16) != 0) {
            this.f1457a.addView(this.d);
        }
    }

    public void a(CharSequence charSequence) {
        this.k = charSequence;
        t();
    }

    public void a(boolean z) {
    }

    public boolean a() {
        return this.f1457a.i();
    }

    public void b() {
        this.m = true;
    }

    public void b(int i2) {
        c(i2 != 0 ? a.b.g.b.a.a.b(o(), i2) : null);
    }

    public void b(Drawable drawable) {
        this.g = drawable;
        u();
    }

    public void b(CharSequence charSequence) {
        this.j = charSequence;
        if ((this.f1458b & 8) != 0) {
            this.f1457a.setSubtitle(charSequence);
        }
    }

    public void b(boolean z) {
        this.f1457a.setCollapsible(z);
    }

    public void c(int i2) {
        a((CharSequence) i2 == 0 ? null : o().getString(i2));
    }

    public void c(Drawable drawable) {
        this.f = drawable;
        v();
    }

    public boolean c() {
        return this.f1457a.b();
    }

    public void collapseActionView() {
        this.f1457a.c();
    }

    public void d(int i2) {
        if (i2 != this.p) {
            this.p = i2;
            if (TextUtils.isEmpty(this.f1457a.getNavigationContentDescription())) {
                c(this.p);
            }
        }
    }

    public boolean d() {
        return this.f1457a.h();
    }

    public boolean e() {
        return this.f1457a.g();
    }

    public boolean f() {
        return this.f1457a.k();
    }

    public void g() {
        this.f1457a.d();
    }

    public CharSequence getTitle() {
        return this.f1457a.getTitle();
    }

    public View h() {
        return this.d;
    }

    public int i() {
        return this.f1457a.getHeight();
    }

    public int j() {
        return this.f1457a.getVisibility();
    }

    public boolean k() {
        return this.f1457a.f();
    }

    public Menu l() {
        return this.f1457a.getMenu();
    }

    public int m() {
        return this.o;
    }

    public ViewGroup n() {
        return this.f1457a;
    }

    public Context o() {
        return this.f1457a.getContext();
    }

    public int p() {
        return this.f1458b;
    }

    public void q() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public void r() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public void setIcon(int i2) {
        setIcon(i2 != 0 ? a.b.g.b.a.a.b(o(), i2) : null);
    }

    public void setIcon(Drawable drawable) {
        this.e = drawable;
        v();
    }

    public void setTitle(CharSequence charSequence) {
        this.h = true;
        c(charSequence);
    }

    public void setVisibility(int i2) {
        this.f1457a.setVisibility(i2);
    }

    public void setWindowCallback(Window.Callback callback) {
        this.l = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        if (!this.h) {
            c(charSequence);
        }
    }
}
