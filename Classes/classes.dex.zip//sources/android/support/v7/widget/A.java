package android.support.v7.widget;

import a.b.g.a.a;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RatingBar;

public class A extends RatingBar {

    /* renamed from: a  reason: collision with root package name */
    private final C0190y f1112a;

    public A(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.ratingBarStyle);
    }

    public A(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1112a = new C0190y(this);
        this.f1112a.a(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public synchronized void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        Bitmap a2 = this.f1112a.a();
        if (a2 != null) {
            setMeasuredDimension(View.resolveSizeAndState(a2.getWidth() * getNumStars(), i, 0), getMeasuredHeight());
        }
    }
}
