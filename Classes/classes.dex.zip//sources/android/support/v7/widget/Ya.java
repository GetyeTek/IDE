package android.support.v7.widget;

import android.view.View;

class Ya implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1304a;

    Ya(SearchView searchView) {
        this.f1304a = searchView;
    }

    public void onClick(View view) {
        SearchView searchView = this.f1304a;
        if (view == searchView.u) {
            searchView.f();
        } else if (view == searchView.w) {
            searchView.e();
        } else if (view == searchView.v) {
            searchView.g();
        } else if (view == searchView.x) {
            searchView.i();
        } else if (view == searchView.q) {
            searchView.c();
        }
    }
}
