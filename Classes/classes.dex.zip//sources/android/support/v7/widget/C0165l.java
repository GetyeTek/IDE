package android.support.v7.widget;

import a.b.g.a.j;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.y;
import android.util.AttributeSet;
import android.view.View;

/* renamed from: android.support.v7.widget.l  reason: case insensitive filesystem */
class C0165l {

    /* renamed from: a  reason: collision with root package name */
    private final View f1378a;

    /* renamed from: b  reason: collision with root package name */
    private final C0175q f1379b;

    /* renamed from: c  reason: collision with root package name */
    private int f1380c = -1;
    private mb d;
    private mb e;
    private mb f;

    C0165l(View view) {
        this.f1378a = view;
        this.f1379b = C0175q.a();
    }

    private boolean b(Drawable drawable) {
        if (this.f == null) {
            this.f = new mb();
        }
        mb mbVar = this.f;
        mbVar.a();
        ColorStateList c2 = y.c(this.f1378a);
        if (c2 != null) {
            mbVar.d = true;
            mbVar.f1392a = c2;
        }
        PorterDuff.Mode d2 = y.d(this.f1378a);
        if (d2 != null) {
            mbVar.f1394c = true;
            mbVar.f1393b = d2;
        }
        if (!mbVar.d && !mbVar.f1394c) {
            return false;
        }
        C0175q.a(drawable, mbVar, this.f1378a.getDrawableState());
        return true;
    }

    private boolean d() {
        int i = Build.VERSION.SDK_INT;
        return i > 21 ? this.d != null : i == 21;
    }

    /* access modifiers changed from: package-private */
    public void a() {
        Drawable background = this.f1378a.getBackground();
        if (background == null) {
            return;
        }
        if (!d() || !b(background)) {
            mb mbVar = this.e;
            if (mbVar != null) {
                C0175q.a(background, mbVar, this.f1378a.getDrawableState());
                return;
            }
            mb mbVar2 = this.d;
            if (mbVar2 != null) {
                C0175q.a(background, mbVar2, this.f1378a.getDrawableState());
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void a(int i) {
        this.f1380c = i;
        C0175q qVar = this.f1379b;
        a(qVar != null ? qVar.b(this.f1378a.getContext(), i) : null);
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.d == null) {
                this.d = new mb();
            }
            mb mbVar = this.d;
            mbVar.f1392a = colorStateList;
            mbVar.d = true;
        } else {
            this.d = null;
        }
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(PorterDuff.Mode mode) {
        if (this.e == null) {
            this.e = new mb();
        }
        mb mbVar = this.e;
        mbVar.f1393b = mode;
        mbVar.f1394c = true;
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(Drawable drawable) {
        this.f1380c = -1;
        a((ColorStateList) null);
        a();
    }

    /* access modifiers changed from: package-private */
    public void a(AttributeSet attributeSet, int i) {
        ob a2 = ob.a(this.f1378a.getContext(), attributeSet, j.ViewBackgroundHelper, i, 0);
        try {
            if (a2.g(j.ViewBackgroundHelper_android_background)) {
                this.f1380c = a2.g(j.ViewBackgroundHelper_android_background, -1);
                ColorStateList b2 = this.f1379b.b(this.f1378a.getContext(), this.f1380c);
                if (b2 != null) {
                    a(b2);
                }
            }
            if (a2.g(j.ViewBackgroundHelper_backgroundTint)) {
                y.a(this.f1378a, a2.a(j.ViewBackgroundHelper_backgroundTint));
            }
            if (a2.g(j.ViewBackgroundHelper_backgroundTintMode)) {
                y.a(this.f1378a, C0158ha.a(a2.d(j.ViewBackgroundHelper_backgroundTintMode, -1), (PorterDuff.Mode) null));
            }
        } finally {
            a2.a();
        }
    }

    /* access modifiers changed from: package-private */
    public ColorStateList b() {
        mb mbVar = this.e;
        if (mbVar != null) {
            return mbVar.f1392a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public void b(ColorStateList colorStateList) {
        if (this.e == null) {
            this.e = new mb();
        }
        mb mbVar = this.e;
        mbVar.f1392a = colorStateList;
        mbVar.d = true;
        a();
    }

    /* access modifiers changed from: package-private */
    public PorterDuff.Mode c() {
        mb mbVar = this.e;
        if (mbVar != null) {
            return mbVar.f1393b;
        }
        return null;
    }
}
