package android.support.v7.widget;

import android.support.v7.widget.C0156ga;
import java.util.ArrayList;
import java.util.Iterator;

class Z implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ArrayList f1305a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ C0156ga f1306b;

    Z(C0156ga gaVar, ArrayList arrayList) {
        this.f1306b = gaVar;
        this.f1305a = arrayList;
    }

    public void run() {
        Iterator it = this.f1305a.iterator();
        while (it.hasNext()) {
            this.f1306b.a((C0156ga.a) it.next());
        }
        this.f1305a.clear();
        this.f1306b.o.remove(this.f1305a);
    }
}
