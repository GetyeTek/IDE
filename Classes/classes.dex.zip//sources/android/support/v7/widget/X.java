package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.view.J;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.v;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

public interface X {
    J a(int i, long j);

    void a(int i);

    void a(Drawable drawable);

    void a(v.a aVar, l.a aVar2);

    void a(Sa sa);

    void a(Menu menu, v.a aVar);

    void a(View view);

    void a(boolean z);

    boolean a();

    void b();

    void b(int i);

    void b(Drawable drawable);

    void b(boolean z);

    void c(int i);

    boolean c();

    void collapseActionView();

    boolean d();

    boolean e();

    boolean f();

    void g();

    CharSequence getTitle();

    View h();

    int i();

    int j();

    boolean k();

    Menu l();

    int m();

    ViewGroup n();

    Context o();

    int p();

    void q();

    void r();

    void setIcon(int i);

    void setIcon(Drawable drawable);

    void setTitle(CharSequence charSequence);

    void setVisibility(int i);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
