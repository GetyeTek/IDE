package android.support.v7.widget;

import android.view.View;

class rb implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ Toolbar f1434a;

    rb(Toolbar toolbar) {
        this.f1434a = toolbar;
    }

    public void onClick(View view) {
        this.f1434a.c();
    }
}
