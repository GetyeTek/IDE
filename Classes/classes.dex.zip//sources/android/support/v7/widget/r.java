package android.support.v7.widget;

import a.b.g.a.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.w;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.TextView;

public class r extends EditText implements w {

    /* renamed from: a  reason: collision with root package name */
    private final C0165l f1427a;

    /* renamed from: b  reason: collision with root package name */
    private final J f1428b;

    public r(Context context) {
        this(context, (AttributeSet) null);
    }

    public r(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.editTextStyle);
    }

    public r(Context context, AttributeSet attributeSet, int i) {
        super(lb.a(context), attributeSet, i);
        this.f1427a = new C0165l(this);
        this.f1427a.a(attributeSet, i);
        this.f1428b = new J(this);
        this.f1428b.a(attributeSet, i);
        this.f1428b.a();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0165l lVar = this.f1427a;
        if (lVar != null) {
            lVar.a();
        }
        J j = this.f1428b;
        if (j != null) {
            j.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0165l lVar = this.f1427a;
        if (lVar != null) {
            return lVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0165l lVar = this.f1427a;
        if (lVar != null) {
            return lVar.c();
        }
        return null;
    }

    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0178s.a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0165l lVar = this.f1427a;
        if (lVar != null) {
            lVar.a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0165l lVar = this.f1427a;
        if (lVar != null) {
            lVar.a(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(android.support.v4.widget.r.a((TextView) this, callback));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0165l lVar = this.f1427a;
        if (lVar != null) {
            lVar.b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0165l lVar = this.f1427a;
        if (lVar != null) {
            lVar.a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        J j = this.f1428b;
        if (j != null) {
            j.a(context, i);
        }
    }
}
