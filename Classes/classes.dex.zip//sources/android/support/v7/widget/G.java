package android.support.v7.widget;

import android.support.v7.widget.E;
import android.view.ViewTreeObserver;

class G implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ E.b f1160a;

    G(E.b bVar) {
        this.f1160a = bVar;
    }

    public void onGlobalLayout() {
        E.b bVar = this.f1160a;
        if (!bVar.b(E.this)) {
            this.f1160a.dismiss();
            return;
        }
        this.f1160a.l();
        G.super.c();
    }
}
