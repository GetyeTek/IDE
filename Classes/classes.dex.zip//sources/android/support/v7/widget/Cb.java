package android.support.v7.widget;

import android.view.View;

class Cb {

    /* renamed from: a  reason: collision with root package name */
    final b f1135a;

    /* renamed from: b  reason: collision with root package name */
    a f1136b = new a();

    static class a {

        /* renamed from: a  reason: collision with root package name */
        int f1137a = 0;

        /* renamed from: b  reason: collision with root package name */
        int f1138b;

        /* renamed from: c  reason: collision with root package name */
        int f1139c;
        int d;
        int e;

        a() {
        }

        /* access modifiers changed from: package-private */
        public int a(int i, int i2) {
            if (i > i2) {
                return 1;
            }
            return i == i2 ? 2 : 4;
        }

        /* access modifiers changed from: package-private */
        public void a(int i) {
            this.f1137a = i | this.f1137a;
        }

        /* access modifiers changed from: package-private */
        public void a(int i, int i2, int i3, int i4) {
            this.f1138b = i;
            this.f1139c = i2;
            this.d = i3;
            this.e = i4;
        }

        /* access modifiers changed from: package-private */
        public boolean a() {
            int i = this.f1137a;
            if ((i & 7) != 0 && (i & (a(this.d, this.f1138b) << 0)) == 0) {
                return false;
            }
            int i2 = this.f1137a;
            if ((i2 & 112) != 0 && (i2 & (a(this.d, this.f1139c) << 4)) == 0) {
                return false;
            }
            int i3 = this.f1137a;
            if ((i3 & 1792) != 0 && (i3 & (a(this.e, this.f1138b) << 8)) == 0) {
                return false;
            }
            int i4 = this.f1137a;
            return (i4 & 28672) == 0 || (i4 & (a(this.e, this.f1139c) << 12)) != 0;
        }

        /* access modifiers changed from: package-private */
        public void b() {
            this.f1137a = 0;
        }
    }

    interface b {
        int a();

        int a(View view);

        View a(int i);

        int b();

        int b(View view);
    }

    Cb(b bVar) {
        this.f1135a = bVar;
    }

    /* access modifiers changed from: package-private */
    public View a(int i, int i2, int i3, int i4) {
        int a2 = this.f1135a.a();
        int b2 = this.f1135a.b();
        int i5 = i2 > i ? 1 : -1;
        View view = null;
        while (i != i2) {
            View a3 = this.f1135a.a(i);
            this.f1136b.a(a2, b2, this.f1135a.a(a3), this.f1135a.b(a3));
            if (i3 != 0) {
                this.f1136b.b();
                this.f1136b.a(i3);
                if (this.f1136b.a()) {
                    return a3;
                }
            }
            if (i4 != 0) {
                this.f1136b.b();
                this.f1136b.a(i4);
                if (this.f1136b.a()) {
                    view = a3;
                }
            }
            i += i5;
        }
        return view;
    }

    /* access modifiers changed from: package-private */
    public boolean a(View view, int i) {
        this.f1136b.a(this.f1135a.a(), this.f1135a.b(), this.f1135a.a(view), this.f1135a.b(view));
        if (i == 0) {
            return false;
        }
        this.f1136b.b();
        this.f1136b.a(i);
        return this.f1136b.a();
    }
}
