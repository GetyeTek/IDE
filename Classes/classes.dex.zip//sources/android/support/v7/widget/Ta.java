package android.support.v7.widget;

import android.text.Editable;
import android.text.TextWatcher;

class Ta implements TextWatcher {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1281a;

    Ta(SearchView searchView) {
        this.f1281a = searchView;
    }

    public void afterTextChanged(Editable editable) {
    }

    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        this.f1281a.b(charSequence);
    }
}
