package android.support.v7.widget;

import android.database.Cursor;
import android.support.v4.widget.d;

class Va implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ SearchView f1296a;

    Va(SearchView searchView) {
        this.f1296a = searchView;
    }

    public void run() {
        d dVar = this.f1296a.S;
        if (dVar != null && (dVar instanceof ib)) {
            dVar.a((Cursor) null);
        }
    }
}
