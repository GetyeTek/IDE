package android.support.v7.view.menu;

import android.widget.PopupWindow;

class t implements PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ u f1108a;

    t(u uVar) {
        this.f1108a = uVar;
    }

    public void onDismiss() {
        this.f1108a.d();
    }
}
