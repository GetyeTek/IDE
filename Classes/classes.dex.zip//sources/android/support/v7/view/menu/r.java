package android.support.v7.view.menu;

import a.b.f.b.a.b;
import android.content.Context;
import android.support.v4.view.C0108e;
import android.support.v7.view.menu.q;
import android.view.ActionProvider;
import android.view.MenuItem;
import android.view.View;

class r extends q {

    class a extends q.a implements ActionProvider.VisibilityListener {
        C0108e.b f;

        public a(Context context, ActionProvider actionProvider) {
            super(context, actionProvider);
        }

        public View a(MenuItem menuItem) {
            return this.d.onCreateActionView(menuItem);
        }

        public void a(C0108e.b bVar) {
            this.f = bVar;
            this.d.setVisibilityListener(bVar != null ? this : null);
        }

        public boolean b() {
            return this.d.isVisible();
        }

        public boolean e() {
            return this.d.overridesItemVisibility();
        }

        public void onActionProviderVisibilityChanged(boolean z) {
            C0108e.b bVar = this.f;
            if (bVar != null) {
                bVar.onActionProviderVisibilityChanged(z);
            }
        }
    }

    r(Context context, b bVar) {
        super(context, bVar);
    }

    /* access modifiers changed from: package-private */
    public q.a a(ActionProvider actionProvider) {
        return new a(this.f1072b, actionProvider);
    }
}
