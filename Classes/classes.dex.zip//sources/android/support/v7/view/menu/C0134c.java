package android.support.v7.view.menu;

import a.b.f.b.a.b;
import a.b.f.b.a.c;
import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.Iterator;
import java.util.Map;

/* renamed from: android.support.v7.view.menu.c  reason: case insensitive filesystem */
abstract class C0134c<T> extends C0135d<T> {

    /* renamed from: b  reason: collision with root package name */
    final Context f1072b;

    /* renamed from: c  reason: collision with root package name */
    private Map<b, MenuItem> f1073c;
    private Map<c, SubMenu> d;

    C0134c(Context context, T t) {
        super(t);
        this.f1072b = context;
    }

    /* access modifiers changed from: package-private */
    public final MenuItem a(MenuItem menuItem) {
        if (!(menuItem instanceof b)) {
            return menuItem;
        }
        b bVar = (b) menuItem;
        if (this.f1073c == null) {
            this.f1073c = new a.b.f.g.b();
        }
        MenuItem menuItem2 = this.f1073c.get(menuItem);
        if (menuItem2 != null) {
            return menuItem2;
        }
        MenuItem a2 = x.a(this.f1072b, bVar);
        this.f1073c.put(bVar, a2);
        return a2;
    }

    /* access modifiers changed from: package-private */
    public final SubMenu a(SubMenu subMenu) {
        if (!(subMenu instanceof c)) {
            return subMenu;
        }
        c cVar = (c) subMenu;
        if (this.d == null) {
            this.d = new a.b.f.g.b();
        }
        SubMenu subMenu2 = this.d.get(cVar);
        if (subMenu2 != null) {
            return subMenu2;
        }
        SubMenu a2 = x.a(this.f1072b, cVar);
        this.d.put(cVar, a2);
        return a2;
    }

    /* access modifiers changed from: package-private */
    public final void a(int i) {
        Map<b, MenuItem> map = this.f1073c;
        if (map != null) {
            Iterator<b> it = map.keySet().iterator();
            while (it.hasNext()) {
                if (i == it.next().getGroupId()) {
                    it.remove();
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final void b() {
        Map<b, MenuItem> map = this.f1073c;
        if (map != null) {
            map.clear();
        }
        Map<c, SubMenu> map2 = this.d;
        if (map2 != null) {
            map2.clear();
        }
    }

    /* access modifiers changed from: package-private */
    public final void b(int i) {
        Map<b, MenuItem> map = this.f1073c;
        if (map != null) {
            Iterator<b> it = map.keySet().iterator();
            while (it.hasNext()) {
                if (i == it.next().getItemId()) {
                    it.remove();
                    return;
                }
            }
        }
    }
}
