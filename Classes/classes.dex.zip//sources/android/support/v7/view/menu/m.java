package android.support.v7.view.menu;

import a.b.g.a.g;
import android.content.DialogInterface;
import android.os.IBinder;
import android.support.v7.app.C0131n;
import android.support.v7.view.menu.v;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

class m implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, v.a {

    /* renamed from: a  reason: collision with root package name */
    private l f1097a;

    /* renamed from: b  reason: collision with root package name */
    private C0131n f1098b;

    /* renamed from: c  reason: collision with root package name */
    j f1099c;
    private v.a d;

    public m(l lVar) {
        this.f1097a = lVar;
    }

    public void a() {
        C0131n nVar = this.f1098b;
        if (nVar != null) {
            nVar.dismiss();
        }
    }

    public void a(IBinder iBinder) {
        l lVar = this.f1097a;
        C0131n.a aVar = new C0131n.a(lVar.e());
        this.f1099c = new j(aVar.b(), g.abc_list_menu_item_layout);
        this.f1099c.a((v.a) this);
        this.f1097a.a((v) this.f1099c);
        aVar.a(this.f1099c.c(), this);
        View i = lVar.i();
        if (i != null) {
            aVar.a(i);
        } else {
            aVar.a(lVar.g());
            aVar.a(lVar.h());
        }
        aVar.a((DialogInterface.OnKeyListener) this);
        this.f1098b = aVar.a();
        this.f1098b.setOnDismissListener(this);
        WindowManager.LayoutParams attributes = this.f1098b.getWindow().getAttributes();
        attributes.type = 1003;
        if (iBinder != null) {
            attributes.token = iBinder;
        }
        attributes.flags |= 131072;
        this.f1098b.show();
    }

    public void a(l lVar, boolean z) {
        if (z || lVar == this.f1097a) {
            a();
        }
        v.a aVar = this.d;
        if (aVar != null) {
            aVar.a(lVar, z);
        }
    }

    public boolean a(l lVar) {
        v.a aVar = this.d;
        if (aVar != null) {
            return aVar.a(lVar);
        }
        return false;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f1097a.a((MenuItem) (p) this.f1099c.c().getItem(i), 0);
    }

    public void onDismiss(DialogInterface dialogInterface) {
        this.f1099c.a(this.f1097a, true);
    }

    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i == 82 || i == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f1098b.getWindow();
                if (!(window2 == null || (decorView2 = window2.getDecorView()) == null || (keyDispatcherState2 = decorView2.getKeyDispatcherState()) == null)) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f1098b.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.f1097a.a(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.f1097a.performShortcut(i, keyEvent, 0);
    }
}
