package android.support.v7.view.menu;

import a.b.g.a.d;
import a.b.g.a.g;
import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.support.v4.view.y;
import android.support.v7.view.menu.v;
import android.support.v7.widget.C0189xa;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

final class C extends s implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, v, View.OnKeyListener {

    /* renamed from: b  reason: collision with root package name */
    private static final int f1058b = g.abc_popup_menu_item_layout;

    /* renamed from: c  reason: collision with root package name */
    private final Context f1059c;
    private final l d;
    private final k e;
    private final boolean f;
    private final int g;
    private final int h;
    private final int i;
    final C0189xa j;
    final ViewTreeObserver.OnGlobalLayoutListener k = new A(this);
    private final View.OnAttachStateChangeListener l = new B(this);
    private PopupWindow.OnDismissListener m;
    private View n;
    View o;
    private v.a p;
    ViewTreeObserver q;
    private boolean r;
    private boolean s;
    private int t;
    private int u = 0;
    private boolean v;

    public C(Context context, l lVar, View view, int i2, int i3, boolean z) {
        this.f1059c = context;
        this.d = lVar;
        this.f = z;
        this.e = new k(lVar, LayoutInflater.from(context), this.f, f1058b);
        this.h = i2;
        this.i = i3;
        Resources resources = context.getResources();
        this.g = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(d.abc_config_prefDialogWidth));
        this.n = view;
        this.j = new C0189xa(this.f1059c, (AttributeSet) null, this.h, this.i);
        lVar.a((v) this, context);
    }

    private boolean h() {
        View view;
        if (d()) {
            return true;
        }
        if (this.r || (view = this.n) == null) {
            return false;
        }
        this.o = view;
        this.j.a((PopupWindow.OnDismissListener) this);
        this.j.a((AdapterView.OnItemClickListener) this);
        this.j.a(true);
        View view2 = this.o;
        boolean z = this.q == null;
        this.q = view2.getViewTreeObserver();
        if (z) {
            this.q.addOnGlobalLayoutListener(this.k);
        }
        view2.addOnAttachStateChangeListener(this.l);
        this.j.a(view2);
        this.j.c(this.u);
        if (!this.s) {
            this.t = s.a(this.e, (ViewGroup) null, this.f1059c, this.g);
            this.s = true;
        }
        this.j.b(this.t);
        this.j.f(2);
        this.j.a(g());
        this.j.c();
        ListView e2 = this.j.e();
        e2.setOnKeyListener(this);
        if (this.v && this.d.h() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.f1059c).inflate(g.abc_popup_menu_header_item_layout, e2, false);
            TextView textView = (TextView) frameLayout.findViewById(16908310);
            if (textView != null) {
                textView.setText(this.d.h());
            }
            frameLayout.setEnabled(false);
            e2.addHeaderView(frameLayout, (Object) null, false);
        }
        this.j.a((ListAdapter) this.e);
        this.j.c();
        return true;
    }

    public void a(int i2) {
        this.u = i2;
    }

    public void a(Parcelable parcelable) {
    }

    public void a(l lVar) {
    }

    public void a(l lVar, boolean z) {
        if (lVar == this.d) {
            dismiss();
            v.a aVar = this.p;
            if (aVar != null) {
                aVar.a(lVar, z);
            }
        }
    }

    public void a(v.a aVar) {
        this.p = aVar;
    }

    public void a(View view) {
        this.n = view;
    }

    public void a(PopupWindow.OnDismissListener onDismissListener) {
        this.m = onDismissListener;
    }

    public void a(boolean z) {
        this.s = false;
        k kVar = this.e;
        if (kVar != null) {
            kVar.notifyDataSetChanged();
        }
    }

    public boolean a() {
        return false;
    }

    public boolean a(D d2) {
        if (d2.hasVisibleItems()) {
            u uVar = new u(this.f1059c, d2, this.o, this.f, this.h, this.i);
            uVar.a(this.p);
            uVar.a(s.b((l) d2));
            uVar.a(this.m);
            this.m = null;
            this.d.a(false);
            int g2 = this.j.g();
            int h2 = this.j.h();
            if ((Gravity.getAbsoluteGravity(this.u, y.k(this.n)) & 7) == 5) {
                g2 += this.n.getWidth();
            }
            if (uVar.a(g2, h2)) {
                v.a aVar = this.p;
                if (aVar == null) {
                    return true;
                }
                aVar.a(d2);
                return true;
            }
        }
        return false;
    }

    public Parcelable b() {
        return null;
    }

    public void b(int i2) {
        this.j.e(i2);
    }

    public void b(boolean z) {
        this.e.a(z);
    }

    public void c() {
        if (!h()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    public void c(int i2) {
        this.j.i(i2);
    }

    public void c(boolean z) {
        this.v = z;
    }

    public boolean d() {
        return !this.r && this.j.d();
    }

    public void dismiss() {
        if (d()) {
            this.j.dismiss();
        }
    }

    public ListView e() {
        return this.j.e();
    }

    public void onDismiss() {
        this.r = true;
        this.d.close();
        ViewTreeObserver viewTreeObserver = this.q;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.q = this.o.getViewTreeObserver();
            }
            this.q.removeGlobalOnLayoutListener(this.k);
            this.q = null;
        }
        this.o.removeOnAttachStateChangeListener(this.l);
        PopupWindow.OnDismissListener onDismissListener = this.m;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }
}
