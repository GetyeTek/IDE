package android.support.v7.view.menu;

import android.view.View;
import android.view.ViewTreeObserver;

class A implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C f1056a;

    A(C c2) {
        this.f1056a = c2;
    }

    public void onGlobalLayout() {
        if (this.f1056a.d() && !this.f1056a.j.k()) {
            View view = this.f1056a.o;
            if (view == null || !view.isShown()) {
                this.f1056a.dismiss();
            } else {
                this.f1056a.j.c();
            }
        }
    }
}
