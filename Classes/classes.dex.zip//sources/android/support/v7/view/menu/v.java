package android.support.v7.view.menu;

import android.content.Context;
import android.os.Parcelable;

public interface v {

    public interface a {
        void a(l lVar, boolean z);

        boolean a(l lVar);
    }

    void a(Context context, l lVar);

    void a(Parcelable parcelable);

    void a(l lVar, boolean z);

    void a(a aVar);

    void a(boolean z);

    boolean a();

    boolean a(D d);

    boolean a(l lVar, p pVar);

    Parcelable b();

    boolean b(l lVar, p pVar);

    int getId();
}
