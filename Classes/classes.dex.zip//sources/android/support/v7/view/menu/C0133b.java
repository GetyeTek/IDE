package android.support.v7.view.menu;

import android.content.Context;
import android.support.v7.view.menu.v;
import android.support.v7.view.menu.w;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/* renamed from: android.support.v7.view.menu.b  reason: case insensitive filesystem */
public abstract class C0133b implements v {

    /* renamed from: a  reason: collision with root package name */
    protected Context f1069a;

    /* renamed from: b  reason: collision with root package name */
    protected Context f1070b;

    /* renamed from: c  reason: collision with root package name */
    protected l f1071c;
    protected LayoutInflater d;
    protected LayoutInflater e;
    private v.a f;
    private int g;
    private int h;
    protected w i;
    private int j;

    public C0133b(Context context, int i2, int i3) {
        this.f1069a = context;
        this.d = LayoutInflater.from(context);
        this.g = i2;
        this.h = i3;
    }

    public w.a a(ViewGroup viewGroup) {
        return (w.a) this.d.inflate(this.h, viewGroup, false);
    }

    public View a(p pVar, View view, ViewGroup viewGroup) {
        w.a a2 = view instanceof w.a ? (w.a) view : a(viewGroup);
        a(pVar, a2);
        return (View) a2;
    }

    public void a(int i2) {
        this.j = i2;
    }

    public void a(Context context, l lVar) {
        this.f1070b = context;
        this.e = LayoutInflater.from(this.f1070b);
        this.f1071c = lVar;
    }

    public void a(l lVar, boolean z) {
        v.a aVar = this.f;
        if (aVar != null) {
            aVar.a(lVar, z);
        }
    }

    public abstract void a(p pVar, w.a aVar);

    public void a(v.a aVar) {
        this.f = aVar;
    }

    /* access modifiers changed from: protected */
    public void a(View view, int i2) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.i).addView(view, i2);
    }

    public void a(boolean z) {
        ViewGroup viewGroup = (ViewGroup) this.i;
        if (viewGroup != null) {
            l lVar = this.f1071c;
            int i2 = 0;
            if (lVar != null) {
                lVar.b();
                ArrayList<p> n = this.f1071c.n();
                int size = n.size();
                int i3 = 0;
                for (int i4 = 0; i4 < size; i4++) {
                    p pVar = n.get(i4);
                    if (a(i3, pVar)) {
                        View childAt = viewGroup.getChildAt(i3);
                        p itemData = childAt instanceof w.a ? ((w.a) childAt).getItemData() : null;
                        View a2 = a(pVar, childAt, viewGroup);
                        if (pVar != itemData) {
                            a2.setPressed(false);
                            a2.jumpDrawablesToCurrentState();
                        }
                        if (a2 != childAt) {
                            a(a2, i3);
                        }
                        i3++;
                    }
                }
                i2 = i3;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (!a(viewGroup, i2)) {
                    i2++;
                }
            }
        }
    }

    public abstract boolean a(int i2, p pVar);

    public boolean a(D d2) {
        v.a aVar = this.f;
        if (aVar != null) {
            return aVar.a(d2);
        }
        return false;
    }

    public boolean a(l lVar, p pVar) {
        return false;
    }

    /* access modifiers changed from: protected */
    public boolean a(ViewGroup viewGroup, int i2) {
        viewGroup.removeViewAt(i2);
        return true;
    }

    public w b(ViewGroup viewGroup) {
        if (this.i == null) {
            this.i = (w) this.d.inflate(this.g, viewGroup, false);
            this.i.a(this.f1071c);
            a(true);
        }
        return this.i;
    }

    public boolean b(l lVar, p pVar) {
        return false;
    }

    public v.a c() {
        return this.f;
    }

    public int getId() {
        return this.j;
    }
}
