package android.support.v7.view.menu;

import android.widget.ListView;

public interface z {
    void c();

    boolean d();

    void dismiss();

    ListView e();
}
