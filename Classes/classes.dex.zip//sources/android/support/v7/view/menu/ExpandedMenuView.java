package android.support.v7.view.menu;

import android.content.Context;
import android.support.v7.view.menu.l;
import android.support.v7.widget.ob;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public final class ExpandedMenuView extends ListView implements l.b, w, AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    private static final int[] f1060a = {16842964, 16843049};

    /* renamed from: b  reason: collision with root package name */
    private l f1061b;

    /* renamed from: c  reason: collision with root package name */
    private int f1062c;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842868);
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        ob a2 = ob.a(context, attributeSet, f1060a, i, 0);
        if (a2.g(0)) {
            setBackgroundDrawable(a2.b(0));
        }
        if (a2.g(1)) {
            setDivider(a2.b(1));
        }
        a2.a();
    }

    public void a(l lVar) {
        this.f1061b = lVar;
    }

    public boolean a(p pVar) {
        return this.f1061b.a((MenuItem) pVar, 0);
    }

    public int getWindowAnimations() {
        return this.f1062c;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        a((p) getAdapter().getItem(i));
    }
}
