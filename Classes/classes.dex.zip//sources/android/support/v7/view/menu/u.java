package android.support.v7.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.support.v4.view.C0110g;
import android.support.v4.view.y;
import android.support.v7.view.menu.v;
import android.view.View;
import android.widget.PopupWindow;

public class u implements n {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1109a;

    /* renamed from: b  reason: collision with root package name */
    private final l f1110b;

    /* renamed from: c  reason: collision with root package name */
    private final boolean f1111c;
    private final int d;
    private final int e;
    private View f;
    private int g;
    private boolean h;
    private v.a i;
    private s j;
    private PopupWindow.OnDismissListener k;
    private final PopupWindow.OnDismissListener l;

    public u(Context context, l lVar, View view, boolean z, int i2) {
        this(context, lVar, view, z, i2, 0);
    }

    public u(Context context, l lVar, View view, boolean z, int i2, int i3) {
        this.g = 8388611;
        this.l = new t(this);
        this.f1109a = context;
        this.f1110b = lVar;
        this.f = view;
        this.f1111c = z;
        this.d = i2;
        this.e = i3;
    }

    private void a(int i2, int i3, boolean z, boolean z2) {
        s b2 = b();
        b2.c(z2);
        if (z) {
            if ((C0110g.a(this.g, y.k(this.f)) & 7) == 5) {
                i2 -= this.f.getWidth();
            }
            b2.b(i2);
            b2.c(i3);
            int i4 = (int) ((this.f1109a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            b2.a(new Rect(i2 - i4, i3 - i4, i2 + i4, i3 + i4));
        }
        b2.c();
    }

    /* JADX WARNING: type inference failed for: r0v7, types: [android.support.v7.view.menu.v, android.support.v7.view.menu.s] */
    /* JADX WARNING: type inference failed for: r7v1, types: [android.support.v7.view.menu.C] */
    /* JADX WARNING: type inference failed for: r1v13, types: [android.support.v7.view.menu.i] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.support.v7.view.menu.s g() {
        /*
            r14 = this;
            android.content.Context r0 = r14.f1109a
            java.lang.String r1 = "window"
            java.lang.Object r0 = r0.getSystemService(r1)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            android.view.Display r0 = r0.getDefaultDisplay()
            android.graphics.Point r1 = new android.graphics.Point
            r1.<init>()
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 17
            if (r2 < r3) goto L_0x001d
            r0.getRealSize(r1)
            goto L_0x0020
        L_0x001d:
            r0.getSize(r1)
        L_0x0020:
            int r0 = r1.x
            int r1 = r1.y
            int r0 = java.lang.Math.min(r0, r1)
            android.content.Context r1 = r14.f1109a
            android.content.res.Resources r1 = r1.getResources()
            int r2 = a.b.g.a.d.abc_cascading_menus_min_smallest_width
            int r1 = r1.getDimensionPixelSize(r2)
            if (r0 < r1) goto L_0x0038
            r0 = 1
            goto L_0x0039
        L_0x0038:
            r0 = 0
        L_0x0039:
            if (r0 == 0) goto L_0x004c
            android.support.v7.view.menu.i r0 = new android.support.v7.view.menu.i
            android.content.Context r2 = r14.f1109a
            android.view.View r3 = r14.f
            int r4 = r14.d
            int r5 = r14.e
            boolean r6 = r14.f1111c
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6)
            goto L_0x005e
        L_0x004c:
            android.support.v7.view.menu.C r0 = new android.support.v7.view.menu.C
            android.content.Context r8 = r14.f1109a
            android.support.v7.view.menu.l r9 = r14.f1110b
            android.view.View r10 = r14.f
            int r11 = r14.d
            int r12 = r14.e
            boolean r13 = r14.f1111c
            r7 = r0
            r7.<init>(r8, r9, r10, r11, r12, r13)
        L_0x005e:
            android.support.v7.view.menu.l r1 = r14.f1110b
            r0.a((android.support.v7.view.menu.l) r1)
            android.widget.PopupWindow$OnDismissListener r1 = r14.l
            r0.a((android.widget.PopupWindow.OnDismissListener) r1)
            android.view.View r1 = r14.f
            r0.a((android.view.View) r1)
            android.support.v7.view.menu.v$a r1 = r14.i
            r0.a((android.support.v7.view.menu.v.a) r1)
            boolean r1 = r14.h
            r0.b((boolean) r1)
            int r1 = r14.g
            r0.a((int) r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.view.menu.u.g():android.support.v7.view.menu.s");
    }

    public void a() {
        if (c()) {
            this.j.dismiss();
        }
    }

    public void a(int i2) {
        this.g = i2;
    }

    public void a(v.a aVar) {
        this.i = aVar;
        s sVar = this.j;
        if (sVar != null) {
            sVar.a(aVar);
        }
    }

    public void a(View view) {
        this.f = view;
    }

    public void a(PopupWindow.OnDismissListener onDismissListener) {
        this.k = onDismissListener;
    }

    public void a(boolean z) {
        this.h = z;
        s sVar = this.j;
        if (sVar != null) {
            sVar.b(z);
        }
    }

    public boolean a(int i2, int i3) {
        if (c()) {
            return true;
        }
        if (this.f == null) {
            return false;
        }
        a(i2, i3, true, true);
        return true;
    }

    public s b() {
        if (this.j == null) {
            this.j = g();
        }
        return this.j;
    }

    public boolean c() {
        s sVar = this.j;
        return sVar != null && sVar.d();
    }

    /* access modifiers changed from: protected */
    public void d() {
        this.j = null;
        PopupWindow.OnDismissListener onDismissListener = this.k;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public void e() {
        if (!f()) {
            throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
        }
    }

    public boolean f() {
        if (c()) {
            return true;
        }
        if (this.f == null) {
            return false;
        }
        a(0, 0, false, false);
        return true;
    }
}
