package android.support.v7.view.menu;

import android.support.v4.view.C0108e;

class o implements C0108e.b {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ p f1100a;

    o(p pVar) {
        this.f1100a = pVar;
    }

    public void onActionProviderVisibilityChanged(boolean z) {
        p pVar = this.f1100a;
        pVar.n.d(pVar);
    }
}
