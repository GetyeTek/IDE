package android.support.v7.view.menu;

import android.support.v7.view.menu.i;
import android.view.MenuItem;

class g implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ i.a f1077a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ MenuItem f1078b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ l f1079c;
    final /* synthetic */ h d;

    g(h hVar, i.a aVar, MenuItem menuItem, l lVar) {
        this.d = hVar;
        this.f1077a = aVar;
        this.f1078b = menuItem;
        this.f1079c = lVar;
    }

    public void run() {
        i.a aVar = this.f1077a;
        if (aVar != null) {
            this.d.f1080a.B = true;
            aVar.f1084b.a(false);
            this.d.f1080a.B = false;
        }
        if (this.f1078b.isEnabled() && this.f1078b.hasSubMenu()) {
            this.f1079c.a(this.f1078b, 4);
        }
    }
}
