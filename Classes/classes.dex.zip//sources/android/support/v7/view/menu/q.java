package android.support.v7.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.view.C0108e;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import java.lang.reflect.Method;

public class q extends C0134c<a.b.f.b.a.b> implements MenuItem {
    private Method e;

    class a extends C0108e {
        final ActionProvider d;

        public a(Context context, ActionProvider actionProvider) {
            super(context);
            this.d = actionProvider;
        }

        public void a(SubMenu subMenu) {
            this.d.onPrepareSubMenu(q.this.a(subMenu));
        }

        public boolean a() {
            return this.d.hasSubMenu();
        }

        public View c() {
            return this.d.onCreateActionView();
        }

        public boolean d() {
            return this.d.onPerformDefaultAction();
        }
    }

    static class b extends FrameLayout implements a.b.g.e.c {

        /* renamed from: a  reason: collision with root package name */
        final CollapsibleActionView f1104a;

        b(View view) {
            super(view.getContext());
            this.f1104a = (CollapsibleActionView) view;
            addView(view);
        }

        /* access modifiers changed from: package-private */
        public View a() {
            return (View) this.f1104a;
        }

        public void onActionViewCollapsed() {
            this.f1104a.onActionViewCollapsed();
        }

        public void onActionViewExpanded() {
            this.f1104a.onActionViewExpanded();
        }
    }

    private class c extends C0135d<MenuItem.OnActionExpandListener> implements MenuItem.OnActionExpandListener {
        c(MenuItem.OnActionExpandListener onActionExpandListener) {
            super(onActionExpandListener);
        }

        public boolean onMenuItemActionCollapse(MenuItem menuItem) {
            return ((MenuItem.OnActionExpandListener) this.f1074a).onMenuItemActionCollapse(q.this.a(menuItem));
        }

        public boolean onMenuItemActionExpand(MenuItem menuItem) {
            return ((MenuItem.OnActionExpandListener) this.f1074a).onMenuItemActionExpand(q.this.a(menuItem));
        }
    }

    private class d extends C0135d<MenuItem.OnMenuItemClickListener> implements MenuItem.OnMenuItemClickListener {
        d(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
            super(onMenuItemClickListener);
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            return ((MenuItem.OnMenuItemClickListener) this.f1074a).onMenuItemClick(q.this.a(menuItem));
        }
    }

    q(Context context, a.b.f.b.a.b bVar) {
        super(context, bVar);
    }

    /* access modifiers changed from: package-private */
    public a a(ActionProvider actionProvider) {
        return new a(this.f1072b, actionProvider);
    }

    public void a(boolean z) {
        try {
            if (this.e == null) {
                this.e = ((a.b.f.b.a.b) this.f1074a).getClass().getDeclaredMethod("setExclusiveCheckable", new Class[]{Boolean.TYPE});
            }
            this.e.invoke(this.f1074a, new Object[]{Boolean.valueOf(z)});
        } catch (Exception e2) {
            Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e2);
        }
    }

    public boolean collapseActionView() {
        return ((a.b.f.b.a.b) this.f1074a).collapseActionView();
    }

    public boolean expandActionView() {
        return ((a.b.f.b.a.b) this.f1074a).expandActionView();
    }

    public ActionProvider getActionProvider() {
        C0108e a2 = ((a.b.f.b.a.b) this.f1074a).a();
        if (a2 instanceof a) {
            return ((a) a2).d;
        }
        return null;
    }

    public View getActionView() {
        View actionView = ((a.b.f.b.a.b) this.f1074a).getActionView();
        return actionView instanceof b ? ((b) actionView).a() : actionView;
    }

    public int getAlphabeticModifiers() {
        return ((a.b.f.b.a.b) this.f1074a).getAlphabeticModifiers();
    }

    public char getAlphabeticShortcut() {
        return ((a.b.f.b.a.b) this.f1074a).getAlphabeticShortcut();
    }

    public CharSequence getContentDescription() {
        return ((a.b.f.b.a.b) this.f1074a).getContentDescription();
    }

    public int getGroupId() {
        return ((a.b.f.b.a.b) this.f1074a).getGroupId();
    }

    public Drawable getIcon() {
        return ((a.b.f.b.a.b) this.f1074a).getIcon();
    }

    public ColorStateList getIconTintList() {
        return ((a.b.f.b.a.b) this.f1074a).getIconTintList();
    }

    public PorterDuff.Mode getIconTintMode() {
        return ((a.b.f.b.a.b) this.f1074a).getIconTintMode();
    }

    public Intent getIntent() {
        return ((a.b.f.b.a.b) this.f1074a).getIntent();
    }

    public int getItemId() {
        return ((a.b.f.b.a.b) this.f1074a).getItemId();
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return ((a.b.f.b.a.b) this.f1074a).getMenuInfo();
    }

    public int getNumericModifiers() {
        return ((a.b.f.b.a.b) this.f1074a).getNumericModifiers();
    }

    public char getNumericShortcut() {
        return ((a.b.f.b.a.b) this.f1074a).getNumericShortcut();
    }

    public int getOrder() {
        return ((a.b.f.b.a.b) this.f1074a).getOrder();
    }

    public SubMenu getSubMenu() {
        return a(((a.b.f.b.a.b) this.f1074a).getSubMenu());
    }

    public CharSequence getTitle() {
        return ((a.b.f.b.a.b) this.f1074a).getTitle();
    }

    public CharSequence getTitleCondensed() {
        return ((a.b.f.b.a.b) this.f1074a).getTitleCondensed();
    }

    public CharSequence getTooltipText() {
        return ((a.b.f.b.a.b) this.f1074a).getTooltipText();
    }

    public boolean hasSubMenu() {
        return ((a.b.f.b.a.b) this.f1074a).hasSubMenu();
    }

    public boolean isActionViewExpanded() {
        return ((a.b.f.b.a.b) this.f1074a).isActionViewExpanded();
    }

    public boolean isCheckable() {
        return ((a.b.f.b.a.b) this.f1074a).isCheckable();
    }

    public boolean isChecked() {
        return ((a.b.f.b.a.b) this.f1074a).isChecked();
    }

    public boolean isEnabled() {
        return ((a.b.f.b.a.b) this.f1074a).isEnabled();
    }

    public boolean isVisible() {
        return ((a.b.f.b.a.b) this.f1074a).isVisible();
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        ((a.b.f.b.a.b) this.f1074a).a(actionProvider != null ? a(actionProvider) : null);
        return this;
    }

    public MenuItem setActionView(int i) {
        ((a.b.f.b.a.b) this.f1074a).setActionView(i);
        View actionView = ((a.b.f.b.a.b) this.f1074a).getActionView();
        if (actionView instanceof CollapsibleActionView) {
            ((a.b.f.b.a.b) this.f1074a).setActionView((View) new b(actionView));
        }
        return this;
    }

    public MenuItem setActionView(View view) {
        if (view instanceof CollapsibleActionView) {
            view = new b(view);
        }
        ((a.b.f.b.a.b) this.f1074a).setActionView(view);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c2) {
        ((a.b.f.b.a.b) this.f1074a).setAlphabeticShortcut(c2);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c2, int i) {
        ((a.b.f.b.a.b) this.f1074a).setAlphabeticShortcut(c2, i);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        ((a.b.f.b.a.b) this.f1074a).setCheckable(z);
        return this;
    }

    public MenuItem setChecked(boolean z) {
        ((a.b.f.b.a.b) this.f1074a).setChecked(z);
        return this;
    }

    public MenuItem setContentDescription(CharSequence charSequence) {
        ((a.b.f.b.a.b) this.f1074a).setContentDescription(charSequence);
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        ((a.b.f.b.a.b) this.f1074a).setEnabled(z);
        return this;
    }

    public MenuItem setIcon(int i) {
        ((a.b.f.b.a.b) this.f1074a).setIcon(i);
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        ((a.b.f.b.a.b) this.f1074a).setIcon(drawable);
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        ((a.b.f.b.a.b) this.f1074a).setIconTintList(colorStateList);
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        ((a.b.f.b.a.b) this.f1074a).setIconTintMode(mode);
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        ((a.b.f.b.a.b) this.f1074a).setIntent(intent);
        return this;
    }

    public MenuItem setNumericShortcut(char c2) {
        ((a.b.f.b.a.b) this.f1074a).setNumericShortcut(c2);
        return this;
    }

    public MenuItem setNumericShortcut(char c2, int i) {
        ((a.b.f.b.a.b) this.f1074a).setNumericShortcut(c2, i);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        ((a.b.f.b.a.b) this.f1074a).setOnActionExpandListener(onActionExpandListener != null ? new c(onActionExpandListener) : null);
        return this;
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        ((a.b.f.b.a.b) this.f1074a).setOnMenuItemClickListener(onMenuItemClickListener != null ? new d(onMenuItemClickListener) : null);
        return this;
    }

    public MenuItem setShortcut(char c2, char c3) {
        ((a.b.f.b.a.b) this.f1074a).setShortcut(c2, c3);
        return this;
    }

    public MenuItem setShortcut(char c2, char c3, int i, int i2) {
        ((a.b.f.b.a.b) this.f1074a).setShortcut(c2, c3, i, i2);
        return this;
    }

    public void setShowAsAction(int i) {
        ((a.b.f.b.a.b) this.f1074a).setShowAsAction(i);
    }

    public MenuItem setShowAsActionFlags(int i) {
        ((a.b.f.b.a.b) this.f1074a).setShowAsActionFlags(i);
        return this;
    }

    public MenuItem setTitle(int i) {
        ((a.b.f.b.a.b) this.f1074a).setTitle(i);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        ((a.b.f.b.a.b) this.f1074a).setTitle(charSequence);
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        ((a.b.f.b.a.b) this.f1074a).setTitleCondensed(charSequence);
        return this;
    }

    public MenuItem setTooltipText(CharSequence charSequence) {
        ((a.b.f.b.a.b) this.f1074a).setTooltipText(charSequence);
        return this;
    }

    public MenuItem setVisible(boolean z) {
        return ((a.b.f.b.a.b) this.f1074a).setVisible(z);
    }
}
