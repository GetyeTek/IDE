package android.support.v7.view.menu;

import a.b.f.b.a.a;
import a.b.f.b.a.b;
import a.b.f.b.a.c;
import android.content.Context;
import android.os.Build;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;

public final class x {
    public static Menu a(Context context, a aVar) {
        return new y(context, aVar);
    }

    public static MenuItem a(Context context, b bVar) {
        return Build.VERSION.SDK_INT >= 16 ? new r(context, bVar) : new q(context, bVar);
    }

    public static SubMenu a(Context context, c cVar) {
        return new E(context, cVar);
    }
}
