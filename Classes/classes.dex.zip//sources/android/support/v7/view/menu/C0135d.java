package android.support.v7.view.menu;

/* renamed from: android.support.v7.view.menu.d  reason: case insensitive filesystem */
class C0135d<T> {

    /* renamed from: a  reason: collision with root package name */
    final T f1074a;

    C0135d(T t) {
        if (t != null) {
            this.f1074a = t;
            return;
        }
        throw new IllegalArgumentException("Wrapped Object can not be null.");
    }
}
