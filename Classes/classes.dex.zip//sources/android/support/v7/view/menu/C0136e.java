package android.support.v7.view.menu;

import android.support.v7.view.menu.i;
import android.view.View;
import android.view.ViewTreeObserver;

/* renamed from: android.support.v7.view.menu.e  reason: case insensitive filesystem */
class C0136e implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ i f1075a;

    C0136e(i iVar) {
        this.f1075a = iVar;
    }

    public void onGlobalLayout() {
        if (this.f1075a.d() && this.f1075a.j.size() > 0 && !this.f1075a.j.get(0).f1083a.k()) {
            View view = this.f1075a.q;
            if (view == null || !view.isShown()) {
                this.f1075a.dismiss();
                return;
            }
            for (i.a aVar : this.f1075a.j) {
                aVar.f1083a.c();
            }
        }
    }
}
