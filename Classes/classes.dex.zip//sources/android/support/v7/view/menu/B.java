package android.support.v7.view.menu;

import android.view.View;
import android.view.ViewTreeObserver;

class B implements View.OnAttachStateChangeListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C f1057a;

    B(C c2) {
        this.f1057a = c2;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        ViewTreeObserver viewTreeObserver = this.f1057a.q;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f1057a.q = view.getViewTreeObserver();
            }
            C c2 = this.f1057a;
            c2.q.removeGlobalOnLayoutListener(c2.k);
        }
        view.removeOnAttachStateChangeListener(this);
    }
}
