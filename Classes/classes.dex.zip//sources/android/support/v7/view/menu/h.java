package android.support.v7.view.menu;

import android.os.SystemClock;
import android.support.v7.view.menu.i;
import android.support.v7.widget.C0187wa;
import android.view.MenuItem;

class h implements C0187wa {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ i f1080a;

    h(i iVar) {
        this.f1080a = iVar;
    }

    public void a(l lVar, MenuItem menuItem) {
        i.a aVar = null;
        this.f1080a.h.removeCallbacksAndMessages((Object) null);
        int size = this.f1080a.j.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                i = -1;
                break;
            } else if (lVar == this.f1080a.j.get(i).f1084b) {
                break;
            } else {
                i++;
            }
        }
        if (i != -1) {
            int i2 = i + 1;
            if (i2 < this.f1080a.j.size()) {
                aVar = this.f1080a.j.get(i2);
            }
            this.f1080a.h.postAtTime(new g(this, aVar, menuItem, lVar), lVar, SystemClock.uptimeMillis() + 200);
        }
    }

    public void b(l lVar, MenuItem menuItem) {
        this.f1080a.h.removeCallbacksAndMessages(lVar);
    }
}
