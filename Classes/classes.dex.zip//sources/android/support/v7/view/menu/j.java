package android.support.v7.view.menu;

import a.b.g.a.g;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.support.v7.view.menu.v;
import android.support.v7.view.menu.w;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import java.util.ArrayList;

public class j implements v, AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    Context f1086a;

    /* renamed from: b  reason: collision with root package name */
    LayoutInflater f1087b;

    /* renamed from: c  reason: collision with root package name */
    l f1088c;
    ExpandedMenuView d;
    int e;
    int f;
    int g;
    private v.a h;
    a i;
    private int j;

    private class a extends BaseAdapter {

        /* renamed from: a  reason: collision with root package name */
        private int f1089a = -1;

        public a() {
            a();
        }

        /* access modifiers changed from: package-private */
        public void a() {
            p f = j.this.f1088c.f();
            if (f != null) {
                ArrayList<p> j = j.this.f1088c.j();
                int size = j.size();
                for (int i = 0; i < size; i++) {
                    if (j.get(i) == f) {
                        this.f1089a = i;
                        return;
                    }
                }
            }
            this.f1089a = -1;
        }

        public int getCount() {
            int size = j.this.f1088c.j().size() - j.this.e;
            return this.f1089a < 0 ? size : size - 1;
        }

        public p getItem(int i) {
            ArrayList<p> j = j.this.f1088c.j();
            int i2 = i + j.this.e;
            int i3 = this.f1089a;
            if (i3 >= 0 && i2 >= i3) {
                i2++;
            }
            return j.get(i2);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                j jVar = j.this;
                view = jVar.f1087b.inflate(jVar.g, viewGroup, false);
            }
            ((w.a) view).a(getItem(i), 0);
            return view;
        }

        public void notifyDataSetChanged() {
            a();
            super.notifyDataSetChanged();
        }
    }

    public j(int i2, int i3) {
        this.g = i2;
        this.f = i3;
    }

    public j(Context context, int i2) {
        this(i2, 0);
        this.f1086a = context;
        this.f1087b = LayoutInflater.from(this.f1086a);
    }

    public w a(ViewGroup viewGroup) {
        if (this.d == null) {
            this.d = (ExpandedMenuView) this.f1087b.inflate(g.abc_expanded_menu_layout, viewGroup, false);
            if (this.i == null) {
                this.i = new a();
            }
            this.d.setAdapter(this.i);
            this.d.setOnItemClickListener(this);
        }
        return this.d;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x001c, code lost:
        if (r2.f1087b == null) goto L_0x000b;
     */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:12:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(android.content.Context r3, android.support.v7.view.menu.l r4) {
        /*
            r2 = this;
            int r0 = r2.f
            if (r0 == 0) goto L_0x0014
            android.view.ContextThemeWrapper r1 = new android.view.ContextThemeWrapper
            r1.<init>(r3, r0)
            r2.f1086a = r1
        L_0x000b:
            android.content.Context r3 = r2.f1086a
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r3)
            r2.f1087b = r3
            goto L_0x001f
        L_0x0014:
            android.content.Context r0 = r2.f1086a
            if (r0 == 0) goto L_0x001f
            r2.f1086a = r3
            android.view.LayoutInflater r3 = r2.f1087b
            if (r3 != 0) goto L_0x001f
            goto L_0x000b
        L_0x001f:
            r2.f1088c = r4
            android.support.v7.view.menu.j$a r3 = r2.i
            if (r3 == 0) goto L_0x0028
            r3.notifyDataSetChanged()
        L_0x0028:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.view.menu.j.a(android.content.Context, android.support.v7.view.menu.l):void");
    }

    public void a(Bundle bundle) {
        SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:list");
        if (sparseParcelableArray != null) {
            this.d.restoreHierarchyState(sparseParcelableArray);
        }
    }

    public void a(Parcelable parcelable) {
        a((Bundle) parcelable);
    }

    public void a(l lVar, boolean z) {
        v.a aVar = this.h;
        if (aVar != null) {
            aVar.a(lVar, z);
        }
    }

    public void a(v.a aVar) {
        this.h = aVar;
    }

    public void a(boolean z) {
        a aVar = this.i;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    public boolean a() {
        return false;
    }

    public boolean a(D d2) {
        if (!d2.hasVisibleItems()) {
            return false;
        }
        new m(d2).a((IBinder) null);
        v.a aVar = this.h;
        if (aVar == null) {
            return true;
        }
        aVar.a(d2);
        return true;
    }

    public boolean a(l lVar, p pVar) {
        return false;
    }

    public Parcelable b() {
        if (this.d == null) {
            return null;
        }
        Bundle bundle = new Bundle();
        b(bundle);
        return bundle;
    }

    public void b(Bundle bundle) {
        SparseArray sparseArray = new SparseArray();
        ExpandedMenuView expandedMenuView = this.d;
        if (expandedMenuView != null) {
            expandedMenuView.saveHierarchyState(sparseArray);
        }
        bundle.putSparseParcelableArray("android:menu:list", sparseArray);
    }

    public boolean b(l lVar, p pVar) {
        return false;
    }

    public ListAdapter c() {
        if (this.i == null) {
            this.i = new a();
        }
        return this.i;
    }

    public int getId() {
        return this.j;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
        this.f1088c.a((MenuItem) this.i.getItem(i2), (v) this, 0);
    }
}
