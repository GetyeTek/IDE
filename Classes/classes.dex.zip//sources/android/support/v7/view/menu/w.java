package android.support.v7.view.menu;

public interface w {

    public interface a {
        void a(p pVar, int i);

        boolean a();

        p getItemData();
    }

    void a(l lVar);
}
