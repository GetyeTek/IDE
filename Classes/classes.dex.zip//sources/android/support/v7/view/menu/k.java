package android.support.v7.view.menu;

import android.support.v7.view.menu.w;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class k extends BaseAdapter {

    /* renamed from: a  reason: collision with root package name */
    l f1091a;

    /* renamed from: b  reason: collision with root package name */
    private int f1092b = -1;

    /* renamed from: c  reason: collision with root package name */
    private boolean f1093c;
    private final boolean d;
    private final LayoutInflater e;
    private final int f;

    public k(l lVar, LayoutInflater layoutInflater, boolean z, int i) {
        this.d = z;
        this.e = layoutInflater;
        this.f1091a = lVar;
        this.f = i;
        a();
    }

    /* access modifiers changed from: package-private */
    public void a() {
        p f2 = this.f1091a.f();
        if (f2 != null) {
            ArrayList<p> j = this.f1091a.j();
            int size = j.size();
            for (int i = 0; i < size; i++) {
                if (j.get(i) == f2) {
                    this.f1092b = i;
                    return;
                }
            }
        }
        this.f1092b = -1;
    }

    public void a(boolean z) {
        this.f1093c = z;
    }

    public l b() {
        return this.f1091a;
    }

    public int getCount() {
        ArrayList<p> j = this.d ? this.f1091a.j() : this.f1091a.n();
        return this.f1092b < 0 ? j.size() : j.size() - 1;
    }

    public p getItem(int i) {
        ArrayList<p> j = this.d ? this.f1091a.j() : this.f1091a.n();
        int i2 = this.f1092b;
        if (i2 >= 0 && i >= i2) {
            i++;
        }
        return j.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.e.inflate(this.f, viewGroup, false);
        }
        int groupId = getItem(i).getGroupId();
        int i2 = i - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f1091a.o() && groupId != (i2 >= 0 ? getItem(i2).getGroupId() : groupId));
        w.a aVar = (w.a) view;
        if (this.f1093c) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.a(getItem(i), 0);
        return view;
    }

    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
