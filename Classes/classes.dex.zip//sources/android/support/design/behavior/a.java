package android.support.design.behavior;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.ViewPropertyAnimator;

class a extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ HideBottomViewOnScrollBehavior f382a;

    a(HideBottomViewOnScrollBehavior hideBottomViewOnScrollBehavior) {
        this.f382a = hideBottomViewOnScrollBehavior;
    }

    public void onAnimationEnd(Animator animator) {
        ViewPropertyAnimator unused = this.f382a.f381c = null;
    }
}
