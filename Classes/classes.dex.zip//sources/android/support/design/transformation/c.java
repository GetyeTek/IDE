package android.support.design.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

class c extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ boolean f416a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ View f417b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ View f418c;
    final /* synthetic */ FabTransformationBehavior d;

    c(FabTransformationBehavior fabTransformationBehavior, boolean z, View view, View view2) {
        this.d = fabTransformationBehavior;
        this.f416a = z;
        this.f417b = view;
        this.f418c = view2;
    }

    public void onAnimationEnd(Animator animator) {
        if (!this.f416a) {
            this.f417b.setVisibility(4);
            this.f418c.setAlpha(1.0f);
            this.f418c.setVisibility(0);
        }
    }

    public void onAnimationStart(Animator animator) {
        if (this.f416a) {
            this.f417b.setVisibility(0);
            this.f418c.setAlpha(0.0f);
            this.f418c.setVisibility(4);
        }
    }
}
