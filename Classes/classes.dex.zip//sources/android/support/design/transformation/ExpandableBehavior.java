package android.support.design.transformation;

import a.b.c.d.b;
import android.content.Context;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.view.y;
import android.util.AttributeSet;
import android.view.View;
import java.util.List;

public abstract class ExpandableBehavior extends CoordinatorLayout.b<View> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public int f406a = 0;

    public ExpandableBehavior() {
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    private boolean a(boolean z) {
        if (!z) {
            return this.f406a == 1;
        }
        int i = this.f406a;
        return i == 0 || i == 2;
    }

    public boolean a(CoordinatorLayout coordinatorLayout, View view, int i) {
        b e;
        if (y.y(view) || (e = e(coordinatorLayout, view)) == null || !a(e.a())) {
            return false;
        }
        this.f406a = e.a() ? 1 : 2;
        view.getViewTreeObserver().addOnPreDrawListener(new a(this, view, this.f406a, e));
        return false;
    }

    /* access modifiers changed from: protected */
    public abstract boolean a(View view, View view2, boolean z, boolean z2);

    public boolean b(CoordinatorLayout coordinatorLayout, View view, View view2) {
        b bVar = (b) view2;
        if (!a(bVar.a())) {
            return false;
        }
        this.f406a = bVar.a() ? 1 : 2;
        return a((View) bVar, view, bVar.a(), true);
    }

    /* access modifiers changed from: protected */
    public b e(CoordinatorLayout coordinatorLayout, View view) {
        List<View> b2 = coordinatorLayout.b(view);
        int size = b2.size();
        for (int i = 0; i < size; i++) {
            View view2 = b2.get(i);
            if (a(coordinatorLayout, view, view2)) {
                return (b) view2;
            }
        }
        return null;
    }
}
