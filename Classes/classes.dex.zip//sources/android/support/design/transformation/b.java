package android.support.design.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;

class b extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ExpandableTransformationBehavior f415a;

    b(ExpandableTransformationBehavior expandableTransformationBehavior) {
        this.f415a = expandableTransformationBehavior;
    }

    public void onAnimationEnd(Animator animator) {
        AnimatorSet unused = this.f415a.f407b = null;
    }
}
