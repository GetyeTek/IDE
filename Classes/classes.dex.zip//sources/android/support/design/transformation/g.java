package android.support.design.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

class g extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ boolean f426a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ View f427b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ FabTransformationScrimBehavior f428c;

    g(FabTransformationScrimBehavior fabTransformationScrimBehavior, boolean z, View view) {
        this.f428c = fabTransformationScrimBehavior;
        this.f426a = z;
        this.f427b = view;
    }

    public void onAnimationEnd(Animator animator) {
        if (!this.f426a) {
            this.f427b.setVisibility(4);
        }
    }

    public void onAnimationStart(Animator animator) {
        if (this.f426a) {
            this.f427b.setVisibility(0);
        }
    }
}
