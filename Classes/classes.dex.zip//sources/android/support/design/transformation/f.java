package android.support.design.transformation;

import a.b.c.c.f;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class f extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ a.b.c.c.f f424a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ FabTransformationBehavior f425b;

    f(FabTransformationBehavior fabTransformationBehavior, a.b.c.c.f fVar) {
        this.f425b = fabTransformationBehavior;
        this.f424a = fVar;
    }

    public void onAnimationEnd(Animator animator) {
        f.d revealInfo = this.f424a.getRevealInfo();
        revealInfo.f48c = Float.MAX_VALUE;
        this.f424a.setRevealInfo(revealInfo);
    }
}
