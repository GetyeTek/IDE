package android.support.design.transformation;

import a.b.c.c.f;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.graphics.drawable.Drawable;

class e extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ f f421a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ Drawable f422b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ FabTransformationBehavior f423c;

    e(FabTransformationBehavior fabTransformationBehavior, f fVar, Drawable drawable) {
        this.f423c = fabTransformationBehavior;
        this.f421a = fVar;
        this.f422b = drawable;
    }

    public void onAnimationEnd(Animator animator) {
        this.f421a.setCircularRevealOverlayDrawable((Drawable) null);
    }

    public void onAnimationStart(Animator animator) {
        this.f421a.setCircularRevealOverlayDrawable(this.f422b);
    }
}
