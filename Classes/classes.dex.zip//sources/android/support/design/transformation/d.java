package android.support.design.transformation;

import android.animation.ValueAnimator;
import android.view.View;

class d implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ View f419a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ FabTransformationBehavior f420b;

    d(FabTransformationBehavior fabTransformationBehavior, View view) {
        this.f420b = fabTransformationBehavior;
        this.f419a = view;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f419a.invalidate();
    }
}
