package android.support.design.transformation;

import a.b.c.d.b;
import android.view.View;
import android.view.ViewTreeObserver;

class a implements ViewTreeObserver.OnPreDrawListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ View f412a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ int f413b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ b f414c;
    final /* synthetic */ ExpandableBehavior d;

    a(ExpandableBehavior expandableBehavior, View view, int i, b bVar) {
        this.d = expandableBehavior;
        this.f412a = view;
        this.f413b = i;
        this.f414c = bVar;
    }

    public boolean onPreDraw() {
        this.f412a.getViewTreeObserver().removeOnPreDrawListener(this);
        if (this.d.f406a == this.f413b) {
            ExpandableBehavior expandableBehavior = this.d;
            b bVar = this.f414c;
            expandableBehavior.a((View) bVar, this.f412a, bVar.a(), false);
        }
        return false;
    }
}
