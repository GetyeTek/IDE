package android.support.design.theme;

import a.b.c.b.a;
import android.content.Context;
import android.support.annotation.Keep;
import android.support.v7.app.AppCompatViewInflater;
import android.support.v7.widget.C0167m;
import android.util.AttributeSet;

@Keep
public class MaterialComponentsViewInflater extends AppCompatViewInflater {
    /* access modifiers changed from: protected */
    public C0167m createButton(Context context, AttributeSet attributeSet) {
        return new a(context, attributeSet);
    }
}
