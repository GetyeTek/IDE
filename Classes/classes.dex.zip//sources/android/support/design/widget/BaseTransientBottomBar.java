package android.support.design.widget;

import a.b.c.h;
import a.b.c.k;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.BaseTransientBottomBar;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Q;
import android.support.design.widget.SwipeDismissBehavior;
import android.support.v4.view.C0107d;
import android.support.v4.view.a.b;
import android.support.v4.view.s;
import android.support.v4.view.y;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import android.widget.FrameLayout;
import java.util.List;

public abstract class BaseTransientBottomBar<B extends BaseTransientBottomBar<B>> {

    /* renamed from: a  reason: collision with root package name */
    static final Handler f440a = new Handler(Looper.getMainLooper(), new C0059f());
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public static final boolean f441b;

    /* renamed from: c  reason: collision with root package name */
    private static final int[] f442c = {a.b.c.b.snackbarStyle};
    private final ViewGroup d;
    private final Context e;
    protected final e f;
    /* access modifiers changed from: private */
    public final a.b.c.h.a g;
    private int h;
    private List<a<B>> i;
    private Behavior j;
    private final AccessibilityManager k;
    final Q.a l = new C0062i(this);

    public static class Behavior extends SwipeDismissBehavior<View> {
        private final b k = new b(this);

        /* access modifiers changed from: private */
        public void a(BaseTransientBottomBar<?> baseTransientBottomBar) {
            this.k.a(baseTransientBottomBar);
        }

        public boolean a(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            this.k.a(coordinatorLayout, view, motionEvent);
            return super.a(coordinatorLayout, view, motionEvent);
        }

        public boolean a(View view) {
            return this.k.a(view);
        }
    }

    public static abstract class a<B> {
        public void a(B b2) {
        }

        public void a(B b2, int i) {
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        private Q.a f443a;

        public b(SwipeDismissBehavior<?> swipeDismissBehavior) {
            swipeDismissBehavior.b(0.1f);
            swipeDismissBehavior.a(0.6f);
            swipeDismissBehavior.a(0);
        }

        public void a(BaseTransientBottomBar<?> baseTransientBottomBar) {
            this.f443a = baseTransientBottomBar.l;
        }

        public void a(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked != 0) {
                if (actionMasked == 1 || actionMasked == 3) {
                    Q.a().e(this.f443a);
                }
            } else if (coordinatorLayout.a(view, (int) motionEvent.getX(), (int) motionEvent.getY())) {
                Q.a().d(this.f443a);
            }
        }

        public boolean a(View view) {
            return view instanceof e;
        }
    }

    protected interface c {
        void onViewAttachedToWindow(View view);

        void onViewDetachedFromWindow(View view);
    }

    protected interface d {
        void a(View view, int i, int i2, int i3, int i4);
    }

    protected static class e extends FrameLayout {

        /* renamed from: a  reason: collision with root package name */
        private final AccessibilityManager f444a;

        /* renamed from: b  reason: collision with root package name */
        private final b.a f445b;

        /* renamed from: c  reason: collision with root package name */
        private d f446c;
        private c d;

        protected e(Context context) {
            this(context, (AttributeSet) null);
        }

        protected e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.SnackbarLayout);
            if (obtainStyledAttributes.hasValue(k.SnackbarLayout_elevation)) {
                y.a((View) this, (float) obtainStyledAttributes.getDimensionPixelSize(k.SnackbarLayout_elevation, 0));
            }
            obtainStyledAttributes.recycle();
            this.f444a = (AccessibilityManager) context.getSystemService("accessibility");
            this.f445b = new C0069p(this);
            android.support.v4.view.a.b.a(this.f444a, this.f445b);
            setClickableOrFocusableBasedOnAccessibility(this.f444a.isTouchExplorationEnabled());
        }

        /* access modifiers changed from: private */
        public void setClickableOrFocusableBasedOnAccessibility(boolean z) {
            setClickable(!z);
            setFocusable(z);
        }

        /* access modifiers changed from: protected */
        public void onAttachedToWindow() {
            super.onAttachedToWindow();
            c cVar = this.d;
            if (cVar != null) {
                cVar.onViewAttachedToWindow(this);
            }
            y.C(this);
        }

        /* access modifiers changed from: protected */
        public void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            c cVar = this.d;
            if (cVar != null) {
                cVar.onViewDetachedFromWindow(this);
            }
            android.support.v4.view.a.b.b(this.f444a, this.f445b);
        }

        /* access modifiers changed from: protected */
        public void onLayout(boolean z, int i, int i2, int i3, int i4) {
            super.onLayout(z, i, i2, i3, i4);
            d dVar = this.f446c;
            if (dVar != null) {
                dVar.a(this, i, i2, i3, i4);
            }
        }

        /* access modifiers changed from: package-private */
        public void setOnAttachStateChangeListener(c cVar) {
            this.d = cVar;
        }

        /* access modifiers changed from: package-private */
        public void setOnLayoutChangeListener(d dVar) {
            this.f446c = dVar;
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        f441b = i2 >= 16 && i2 <= 19;
    }

    protected BaseTransientBottomBar(ViewGroup viewGroup, View view, a.b.c.h.a aVar) {
        if (viewGroup == null) {
            throw new IllegalArgumentException("Transient bottom bar must have non-null parent");
        } else if (view == null) {
            throw new IllegalArgumentException("Transient bottom bar must have non-null content");
        } else if (aVar != null) {
            this.d = viewGroup;
            this.g = aVar;
            this.e = viewGroup.getContext();
            android.support.design.internal.k.a(this.e);
            this.f = (e) LayoutInflater.from(this.e).inflate(f(), this.d, false);
            this.f.addView(view);
            y.c(this.f, 1);
            y.d(this.f, 1);
            y.a((View) this.f, true);
            y.a((View) this.f, (s) new C0060g(this));
            y.a((View) this.f, (C0107d) new C0061h(this));
            this.k = (AccessibilityManager) this.e.getSystemService("accessibility");
        } else {
            throw new IllegalArgumentException("Transient bottom bar must have non-null callback");
        }
    }

    private void e(int i2) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setIntValues(new int[]{0, m()});
        valueAnimator.setInterpolator(a.b.c.a.a.f18b);
        valueAnimator.setDuration(250);
        valueAnimator.addListener(new C0057d(this, i2));
        valueAnimator.addUpdateListener(new C0058e(this));
        valueAnimator.start();
    }

    private int m() {
        int height = this.f.getHeight();
        ViewGroup.LayoutParams layoutParams = this.f.getLayoutParams();
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? height + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin : height;
    }

    /* access modifiers changed from: protected */
    public void a(int i2) {
        Q.a().a(this.l, i2);
    }

    /* access modifiers changed from: package-private */
    public void b() {
        int m = m();
        if (f441b) {
            y.b((View) this.f, m);
        } else {
            this.f.setTranslationY((float) m);
        }
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setIntValues(new int[]{m, 0});
        valueAnimator.setInterpolator(a.b.c.a.a.f18b);
        valueAnimator.setDuration(250);
        valueAnimator.addListener(new C0067n(this));
        valueAnimator.addUpdateListener(new C0068o(this, m));
        valueAnimator.start();
    }

    /* access modifiers changed from: package-private */
    public final void b(int i2) {
        if (!j() || this.f.getVisibility() != 0) {
            c(i2);
        } else {
            e(i2);
        }
    }

    public void c() {
        a(3);
    }

    /* access modifiers changed from: package-private */
    public void c(int i2) {
        Q.a().b(this.l);
        List<a<B>> list = this.i;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.i.get(size).a(this, i2);
            }
        }
        ViewParent parent = this.f.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(this.f);
        }
    }

    public int d() {
        return this.h;
    }

    public B d(int i2) {
        this.h = i2;
        return this;
    }

    /* access modifiers changed from: protected */
    public SwipeDismissBehavior<? extends View> e() {
        return new Behavior();
    }

    /* access modifiers changed from: protected */
    public int f() {
        return g() ? h.mtrl_layout_snackbar : h.design_layout_snackbar;
    }

    /* access modifiers changed from: protected */
    public boolean g() {
        TypedArray obtainStyledAttributes = this.e.obtainStyledAttributes(f442c);
        int resourceId = obtainStyledAttributes.getResourceId(0, -1);
        obtainStyledAttributes.recycle();
        return resourceId != -1;
    }

    public boolean h() {
        return Q.a().a(this.l);
    }

    /* access modifiers changed from: package-private */
    public void i() {
        Q.a().c(this.l);
        List<a<B>> list = this.i;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.i.get(size).a(this);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean j() {
        List<AccessibilityServiceInfo> enabledAccessibilityServiceList = this.k.getEnabledAccessibilityServiceList(1);
        return enabledAccessibilityServiceList != null && enabledAccessibilityServiceList.isEmpty();
    }

    public void k() {
        Q.a().a(d(), this.l);
    }

    /* access modifiers changed from: package-private */
    public final void l() {
        if (this.f.getParent() == null) {
            ViewGroup.LayoutParams layoutParams = this.f.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.e) {
                CoordinatorLayout.e eVar = (CoordinatorLayout.e) layoutParams;
                SwipeDismissBehavior swipeDismissBehavior = this.j;
                if (swipeDismissBehavior == null) {
                    swipeDismissBehavior = e();
                }
                if (swipeDismissBehavior instanceof Behavior) {
                    ((Behavior) swipeDismissBehavior).a((BaseTransientBottomBar<?>) this);
                }
                swipeDismissBehavior.a((SwipeDismissBehavior.a) new C0063j(this));
                eVar.a((CoordinatorLayout.b) swipeDismissBehavior);
                eVar.g = 80;
            }
            this.d.addView(this.f);
        }
        this.f.setOnAttachStateChangeListener(new C0065l(this));
        if (!y.y(this.f)) {
            this.f.setOnLayoutChangeListener(new C0066m(this));
        } else if (j()) {
            b();
        } else {
            i();
        }
    }
}
