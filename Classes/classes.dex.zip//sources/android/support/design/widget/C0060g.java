package android.support.design.widget;

import android.support.v4.view.N;
import android.support.v4.view.s;
import android.view.View;

/* renamed from: android.support.design.widget.g  reason: case insensitive filesystem */
class C0060g implements s {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f568a;

    C0060g(BaseTransientBottomBar baseTransientBottomBar) {
        this.f568a = baseTransientBottomBar;
    }

    public N a(View view, N n) {
        view.setPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), n.b());
        return n;
    }
}
