package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;

/* renamed from: android.support.design.widget.t  reason: case insensitive filesystem */
public class C0072t extends Drawable {
    public final void a(float f) {
        throw null;
    }

    public void a(ColorStateList colorStateList) {
        throw null;
    }
}
