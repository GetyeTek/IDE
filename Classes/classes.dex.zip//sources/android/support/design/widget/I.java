package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.widget.TextView;

class I extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ int f483a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ TextView f484b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ int f485c;
    final /* synthetic */ TextView d;
    final /* synthetic */ J e;

    I(J j, int i, TextView textView, int i2, TextView textView2) {
        this.e = j;
        this.f483a = i;
        this.f484b = textView;
        this.f485c = i2;
        this.d = textView2;
    }

    public void onAnimationEnd(Animator animator) {
        int unused = this.e.i = this.f483a;
        Animator unused2 = this.e.g = null;
        TextView textView = this.f484b;
        if (textView != null) {
            textView.setVisibility(4);
            if (this.f485c == 1 && this.e.m != null) {
                this.e.m.setText((CharSequence) null);
            }
        }
    }

    public void onAnimationStart(Animator animator) {
        TextView textView = this.d;
        if (textView != null) {
            textView.setVisibility(0);
        }
    }
}
