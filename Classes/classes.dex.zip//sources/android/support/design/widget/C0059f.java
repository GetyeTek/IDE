package android.support.design.widget;

import android.os.Handler;
import android.os.Message;

/* renamed from: android.support.design.widget.f  reason: case insensitive filesystem */
class C0059f implements Handler.Callback {
    C0059f() {
    }

    public boolean handleMessage(Message message) {
        int i = message.what;
        if (i == 0) {
            ((BaseTransientBottomBar) message.obj).l();
            return true;
        } else if (i != 1) {
            return false;
        } else {
            ((BaseTransientBottomBar) message.obj).b(message.arg1);
            return true;
        }
    }
}
