package android.support.design.widget;

import android.animation.ValueAnimator;
import android.support.v4.view.y;
import android.view.View;

/* renamed from: android.support.design.widget.o  reason: case insensitive filesystem */
class C0068o implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    private int f577a = this.f578b;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ int f578b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f579c;

    C0068o(BaseTransientBottomBar baseTransientBottomBar, int i) {
        this.f579c = baseTransientBottomBar;
        this.f578b = i;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        int intValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        if (BaseTransientBottomBar.f441b) {
            y.b((View) this.f579c.f, intValue - this.f577a);
        } else {
            this.f579c.f.setTranslationY((float) intValue);
        }
        this.f577a = intValue;
    }
}
