package android.support.design.widget;

import a.b.g.a.a;
import android.content.Context;
import android.support.v4.view.C0107d;
import android.support.v4.view.y;
import android.support.v7.widget.C0180t;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Checkable;
import android.widget.ImageButton;

public class CheckableImageButton extends C0180t implements Checkable {

    /* renamed from: c  reason: collision with root package name */
    private static final int[] f457c = {16842912};
    private boolean d;

    public CheckableImageButton(Context context) {
        this(context, (AttributeSet) null);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.imageButtonStyle);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        y.a((View) this, (C0107d) new C0071s(this));
    }

    public boolean isChecked() {
        return this.d;
    }

    public int[] onCreateDrawableState(int i) {
        return this.d ? ImageButton.mergeDrawableStates(super.onCreateDrawableState(i + f457c.length), f457c) : super.onCreateDrawableState(i);
    }

    public void setChecked(boolean z) {
        if (this.d != z) {
            this.d = z;
            refreshDrawableState();
            sendAccessibilityEvent(2048);
        }
    }

    public void toggle() {
        setChecked(!this.d);
    }
}
