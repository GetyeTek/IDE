package android.support.design.widget;

import a.b.c.a.g;
import a.b.c.a.h;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.y;
import android.view.View;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.Iterator;

class E {

    /* renamed from: a  reason: collision with root package name */
    static final TimeInterpolator f468a = a.b.c.a.a.f19c;

    /* renamed from: b  reason: collision with root package name */
    static final int[] f469b = {16842919, 16842910};

    /* renamed from: c  reason: collision with root package name */
    static final int[] f470c = {16843623, 16842908, 16842910};
    static final int[] d = {16842908, 16842910};
    static final int[] e = {16843623, 16842910};
    static final int[] f = {16842910};
    static final int[] g = new int[0];
    private ArrayList<Animator.AnimatorListener> A;
    final ga B;
    final O C;
    private final Rect D = new Rect();
    private final RectF E = new RectF();
    private final RectF F = new RectF();
    private final Matrix G = new Matrix();
    private ViewTreeObserver.OnPreDrawListener H;
    int h = 0;
    Animator i;
    h j;
    h k;
    private h l;
    private h m;
    private final T n;
    N o;
    private float p;
    Drawable q;
    Drawable r;
    C0072t s;
    Drawable t;
    float u;
    float v;
    float w;
    int x;
    float y = 1.0f;
    private ArrayList<Animator.AnimatorListener> z;

    private class a extends f {
        a() {
            super(E.this, (B) null);
        }
    }

    private class b extends f {
        b() {
            super(E.this, (B) null);
        }
    }

    private class c extends f {
        c() {
            super(E.this, (B) null);
        }
    }

    interface d {
        void a();

        void b();
    }

    private class e extends f {
        e() {
            super(E.this, (B) null);
        }
    }

    private abstract class f extends AnimatorListenerAdapter implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a  reason: collision with root package name */
        private boolean f471a;

        /* renamed from: b  reason: collision with root package name */
        private float f472b;

        /* renamed from: c  reason: collision with root package name */
        private float f473c;

        private f() {
        }

        /* synthetic */ f(E e, B b2) {
            this();
        }

        public void onAnimationEnd(Animator animator) {
            E.this.o.b(this.f473c);
            throw null;
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            if (!this.f471a) {
                E.this.o.b();
                throw null;
            }
            N n = E.this.o;
            float f = this.f472b;
            n.b(f + ((this.f473c - f) * valueAnimator.getAnimatedFraction()));
            throw null;
        }
    }

    E(ga gaVar, O o2) {
        this.B = gaVar;
        this.C = o2;
        this.n = new T();
        this.n.a(f469b, a((f) new c()));
        this.n.a(f470c, a((f) new b()));
        this.n.a(d, a((f) new b()));
        this.n.a(e, a((f) new b()));
        this.n.a(f, a((f) new e()));
        this.n.a(g, a((f) new a()));
        this.p = this.B.getRotation();
    }

    private AnimatorSet a(h hVar, float f2, float f3, float f4) {
        ArrayList arrayList = new ArrayList();
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.B, View.ALPHA, new float[]{f2});
        hVar.a("opacity").a((Animator) ofFloat);
        arrayList.add(ofFloat);
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.B, View.SCALE_X, new float[]{f3});
        hVar.a("scale").a((Animator) ofFloat2);
        arrayList.add(ofFloat2);
        ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(this.B, View.SCALE_Y, new float[]{f3});
        hVar.a("scale").a((Animator) ofFloat3);
        arrayList.add(ofFloat3);
        a(f4, this.G);
        ObjectAnimator ofObject = ObjectAnimator.ofObject(this.B, new a.b.c.a.f(), new g(), new Matrix[]{new Matrix(this.G)});
        hVar.a("iconScale").a((Animator) ofObject);
        arrayList.add(ofObject);
        AnimatorSet animatorSet = new AnimatorSet();
        a.b.c.a.b.a(animatorSet, arrayList);
        return animatorSet;
    }

    private ValueAnimator a(f fVar) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setInterpolator(f468a);
        valueAnimator.setDuration(100);
        valueAnimator.addListener(fVar);
        valueAnimator.addUpdateListener(fVar);
        valueAnimator.setFloatValues(new float[]{0.0f, 1.0f});
        return valueAnimator;
    }

    private void a(float f2, Matrix matrix) {
        matrix.reset();
        Drawable drawable = this.B.getDrawable();
        if (drawable != null && this.x != 0) {
            RectF rectF = this.E;
            RectF rectF2 = this.F;
            rectF.set(0.0f, 0.0f, (float) drawable.getIntrinsicWidth(), (float) drawable.getIntrinsicHeight());
            int i2 = this.x;
            rectF2.set(0.0f, 0.0f, (float) i2, (float) i2);
            matrix.setRectToRect(rectF, rectF2, Matrix.ScaleToFit.CENTER);
            int i3 = this.x;
            matrix.postScale(f2, f2, ((float) i3) / 2.0f, ((float) i3) / 2.0f);
        }
    }

    private void q() {
        if (this.H == null) {
            this.H = new D(this);
        }
    }

    private h r() {
        if (this.m == null) {
            this.m = h.a(this.B.getContext(), a.b.c.a.design_fab_hide_motion_spec);
        }
        return this.m;
    }

    private h s() {
        if (this.l == null) {
            this.l = h.a(this.B.getContext(), a.b.c.a.design_fab_show_motion_spec);
        }
        return this.l;
    }

    private boolean t() {
        return y.y(this.B) && !this.B.isInEditMode();
    }

    private void u() {
        int i2;
        ga gaVar;
        if (Build.VERSION.SDK_INT == 19) {
            if (this.p % 90.0f != 0.0f) {
                i2 = 1;
                if (this.B.getLayerType() != 1) {
                    gaVar = this.B;
                }
            } else if (this.B.getLayerType() != 0) {
                gaVar = this.B;
                i2 = 0;
            }
            gaVar.setLayerType(i2, (Paint) null);
        }
        N n2 = this.o;
        if (n2 == null) {
            C0072t tVar = this.s;
            if (tVar != null) {
                tVar.a(-this.p);
                throw null;
            }
            return;
        }
        n2.a(-this.p);
        throw null;
    }

    /* access modifiers changed from: package-private */
    public final Drawable a() {
        return this.t;
    }

    /* access modifiers changed from: package-private */
    public final void a(float f2) {
        if (this.u != f2) {
            this.u = f2;
            a(this.u, this.v, this.w);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(float f2, float f3, float f4) {
        N n2 = this.o;
        if (n2 != null) {
            n2.a(f2, this.w + f2);
            throw null;
        }
    }

    /* access modifiers changed from: package-private */
    public final void a(h hVar) {
        this.k = hVar;
    }

    public void a(Animator.AnimatorListener animatorListener) {
        if (this.A == null) {
            this.A = new ArrayList<>();
        }
        this.A.add(animatorListener);
    }

    /* access modifiers changed from: package-private */
    public void a(ColorStateList colorStateList) {
        Drawable drawable = this.q;
        if (drawable != null) {
            android.support.v4.graphics.drawable.a.a(drawable, colorStateList);
        }
        C0072t tVar = this.s;
        if (tVar != null) {
            tVar.a(colorStateList);
            throw null;
        }
    }

    /* access modifiers changed from: package-private */
    public void a(PorterDuff.Mode mode) {
        Drawable drawable = this.q;
        if (drawable != null) {
            android.support.v4.graphics.drawable.a.a(drawable, mode);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(Rect rect) {
        this.o.getPadding(rect);
        throw null;
    }

    /* access modifiers changed from: package-private */
    public void a(d dVar, boolean z2) {
        if (!g()) {
            Animator animator = this.i;
            if (animator != null) {
                animator.cancel();
            }
            if (t()) {
                h hVar = this.k;
                if (hVar == null) {
                    hVar = r();
                }
                AnimatorSet a2 = a(hVar, 0.0f, 0.0f, 0.0f);
                a2.addListener(new B(this, z2, dVar));
                ArrayList<Animator.AnimatorListener> arrayList = this.A;
                if (arrayList != null) {
                    Iterator<Animator.AnimatorListener> it = arrayList.iterator();
                    while (it.hasNext()) {
                        a2.addListener(it.next());
                    }
                }
                a2.start();
                return;
            }
            this.B.a(z2 ? 8 : 4, z2);
            if (dVar != null) {
                dVar.b();
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void a(int[] iArr) {
        this.n.a(iArr);
    }

    /* access modifiers changed from: package-private */
    public float b() {
        return this.u;
    }

    /* access modifiers changed from: package-private */
    public final void b(float f2) {
        if (this.v != f2) {
            this.v = f2;
            a(this.u, this.v, this.w);
        }
    }

    /* access modifiers changed from: package-private */
    public final void b(h hVar) {
        this.j = hVar;
    }

    /* access modifiers changed from: package-private */
    public void b(Animator.AnimatorListener animatorListener) {
        if (this.z == null) {
            this.z = new ArrayList<>();
        }
        this.z.add(animatorListener);
    }

    /* access modifiers changed from: package-private */
    public void b(ColorStateList colorStateList) {
        Drawable drawable = this.r;
        if (drawable != null) {
            android.support.v4.graphics.drawable.a.a(drawable, a.b.c.f.a.a(colorStateList));
        }
    }

    /* access modifiers changed from: package-private */
    public void b(Rect rect) {
    }

    /* access modifiers changed from: package-private */
    public void b(d dVar, boolean z2) {
        if (!h()) {
            Animator animator = this.i;
            if (animator != null) {
                animator.cancel();
            }
            if (t()) {
                if (this.B.getVisibility() != 0) {
                    this.B.setAlpha(0.0f);
                    this.B.setScaleY(0.0f);
                    this.B.setScaleX(0.0f);
                    c(0.0f);
                }
                h hVar = this.j;
                if (hVar == null) {
                    hVar = s();
                }
                AnimatorSet a2 = a(hVar, 1.0f, 1.0f, 1.0f);
                a2.addListener(new C(this, z2, dVar));
                ArrayList<Animator.AnimatorListener> arrayList = this.z;
                if (arrayList != null) {
                    Iterator<Animator.AnimatorListener> it = arrayList.iterator();
                    while (it.hasNext()) {
                        a2.addListener(it.next());
                    }
                }
                a2.start();
                return;
            }
            this.B.a(0, z2);
            this.B.setAlpha(1.0f);
            this.B.setScaleY(1.0f);
            this.B.setScaleX(1.0f);
            c(1.0f);
            if (dVar != null) {
                dVar.a();
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final h c() {
        return this.k;
    }

    /* access modifiers changed from: package-private */
    public final void c(float f2) {
        this.y = f2;
        Matrix matrix = this.G;
        a(f2, matrix);
        this.B.setImageMatrix(matrix);
    }

    public void c(Animator.AnimatorListener animatorListener) {
        ArrayList<Animator.AnimatorListener> arrayList = this.A;
        if (arrayList != null) {
            arrayList.remove(animatorListener);
        }
    }

    /* access modifiers changed from: package-private */
    public float d() {
        return this.v;
    }

    /* access modifiers changed from: package-private */
    public final void d(float f2) {
        if (this.w != f2) {
            this.w = f2;
            a(this.u, this.v, this.w);
        }
    }

    /* access modifiers changed from: package-private */
    public void d(Animator.AnimatorListener animatorListener) {
        ArrayList<Animator.AnimatorListener> arrayList = this.z;
        if (arrayList != null) {
            arrayList.remove(animatorListener);
        }
    }

    /* access modifiers changed from: package-private */
    public float e() {
        return this.w;
    }

    /* access modifiers changed from: package-private */
    public final h f() {
        return this.j;
    }

    /* access modifiers changed from: package-private */
    public boolean g() {
        return this.B.getVisibility() == 0 ? this.h == 1 : this.h != 2;
    }

    /* access modifiers changed from: package-private */
    public boolean h() {
        return this.B.getVisibility() != 0 ? this.h == 2 : this.h != 1;
    }

    /* access modifiers changed from: package-private */
    public void i() {
        this.n.a();
    }

    /* access modifiers changed from: package-private */
    public void j() {
        if (n()) {
            q();
            this.B.getViewTreeObserver().addOnPreDrawListener(this.H);
        }
    }

    /* access modifiers changed from: package-private */
    public void k() {
    }

    /* access modifiers changed from: package-private */
    public void l() {
        if (this.H != null) {
            this.B.getViewTreeObserver().removeOnPreDrawListener(this.H);
            this.H = null;
        }
    }

    /* access modifiers changed from: package-private */
    public void m() {
        float rotation = this.B.getRotation();
        if (this.p != rotation) {
            this.p = rotation;
            u();
        }
    }

    /* access modifiers changed from: package-private */
    public boolean n() {
        return true;
    }

    /* access modifiers changed from: package-private */
    public final void o() {
        c(this.y);
    }

    /* access modifiers changed from: package-private */
    public final void p() {
        Rect rect = this.D;
        a(rect);
        b(rect);
        this.C.a(rect.left, rect.top, rect.right, rect.bottom);
    }
}
