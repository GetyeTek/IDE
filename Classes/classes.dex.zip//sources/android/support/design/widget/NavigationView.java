package android.support.design.widget;

import a.b.g.e.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.internal.e;
import android.support.design.internal.j;
import android.support.design.internal.k;
import android.support.v4.content.c;
import android.support.v4.view.C0106c;
import android.support.v4.view.N;
import android.support.v4.view.y;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.v;
import android.support.v7.widget.ob;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public class NavigationView extends j {
    private static final int[] d = {16842912};
    private static final int[] e = {-16842910};
    private final android.support.design.internal.b f;
    private final e g;
    a h;
    private final int i;
    private MenuInflater j;

    public interface a {
        boolean a(MenuItem menuItem);
    }

    public static class b extends C0106c {
        public static final Parcelable.Creator<b> CREATOR = new M();

        /* renamed from: c  reason: collision with root package name */
        public Bundle f491c;

        public b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f491c = parcel.readBundle(classLoader);
        }

        public b(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeBundle(this.f491c);
        }
    }

    public NavigationView(Context context) {
        this(context, (AttributeSet) null);
    }

    public NavigationView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.b.c.b.navigationViewStyle);
    }

    public NavigationView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        int i3;
        boolean z;
        this.g = new e();
        this.f = new android.support.design.internal.b(context);
        ob b2 = k.b(context, attributeSet, a.b.c.k.NavigationView, i2, a.b.c.j.Widget_Design_NavigationView, new int[0]);
        y.a((View) this, b2.b(a.b.c.k.NavigationView_android_background));
        if (b2.g(a.b.c.k.NavigationView_elevation)) {
            y.a((View) this, (float) b2.c(a.b.c.k.NavigationView_elevation, 0));
        }
        y.a((View) this, b2.a(a.b.c.k.NavigationView_android_fitsSystemWindows, false));
        this.i = b2.c(a.b.c.k.NavigationView_android_maxWidth, 0);
        ColorStateList a2 = b2.g(a.b.c.k.NavigationView_itemIconTint) ? b2.a(a.b.c.k.NavigationView_itemIconTint) : d(16842808);
        if (b2.g(a.b.c.k.NavigationView_itemTextAppearance)) {
            i3 = b2.g(a.b.c.k.NavigationView_itemTextAppearance, 0);
            z = true;
        } else {
            z = false;
            i3 = 0;
        }
        ColorStateList a3 = b2.g(a.b.c.k.NavigationView_itemTextColor) ? b2.a(a.b.c.k.NavigationView_itemTextColor) : null;
        if (!z && a3 == null) {
            a3 = d(16842806);
        }
        Drawable b3 = b2.b(a.b.c.k.NavigationView_itemBackground);
        if (b2.g(a.b.c.k.NavigationView_itemHorizontalPadding)) {
            this.g.d(b2.c(a.b.c.k.NavigationView_itemHorizontalPadding, 0));
        }
        int c2 = b2.c(a.b.c.k.NavigationView_itemIconPadding, 0);
        this.f.a((l.a) new L(this));
        this.g.c(1);
        this.g.a(context, (l) this.f);
        this.g.a(a2);
        if (z) {
            this.g.f(i3);
        }
        this.g.b(a3);
        this.g.a(b3);
        this.g.e(c2);
        this.f.a((v) this.g);
        addView((View) this.g.a((ViewGroup) this));
        if (b2.g(a.b.c.k.NavigationView_menu)) {
            c(b2.g(a.b.c.k.NavigationView_menu, 0));
        }
        if (b2.g(a.b.c.k.NavigationView_headerLayout)) {
            b(b2.g(a.b.c.k.NavigationView_headerLayout, 0));
        }
        b2.a();
    }

    private ColorStateList d(int i2) {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(i2, typedValue, true)) {
            return null;
        }
        ColorStateList a2 = a.b.g.b.a.a.a(getContext(), typedValue.resourceId);
        if (!getContext().getTheme().resolveAttribute(a.b.g.a.a.colorPrimary, typedValue, true)) {
            return null;
        }
        int i3 = typedValue.data;
        int defaultColor = a2.getDefaultColor();
        return new ColorStateList(new int[][]{e, d, FrameLayout.EMPTY_STATE_SET}, new int[]{a2.getColorForState(e, defaultColor), i3, defaultColor});
    }

    private MenuInflater getMenuInflater() {
        if (this.j == null) {
            this.j = new g(getContext());
        }
        return this.j;
    }

    public View a(int i2) {
        return this.g.a(i2);
    }

    /* access modifiers changed from: protected */
    public void a(N n) {
        this.g.a(n);
    }

    public View b(int i2) {
        return this.g.b(i2);
    }

    public void c(int i2) {
        this.g.b(true);
        getMenuInflater().inflate(i2, this.f);
        this.g.b(false);
        this.g.a(false);
    }

    public MenuItem getCheckedItem() {
        return this.g.c();
    }

    public int getHeaderCount() {
        return this.g.d();
    }

    public Drawable getItemBackground() {
        return this.g.e();
    }

    public int getItemHorizontalPadding() {
        return this.g.f();
    }

    public int getItemIconPadding() {
        return this.g.g();
    }

    public ColorStateList getItemIconTintList() {
        return this.g.i();
    }

    public ColorStateList getItemTextColor() {
        return this.g.h();
    }

    public Menu getMenu() {
        return this.f;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        int i4;
        int mode = View.MeasureSpec.getMode(i2);
        if (mode != Integer.MIN_VALUE) {
            if (mode == 0) {
                i4 = this.i;
            }
            super.onMeasure(i2, i3);
        }
        i4 = Math.min(View.MeasureSpec.getSize(i2), this.i);
        i2 = View.MeasureSpec.makeMeasureSpec(i4, 1073741824);
        super.onMeasure(i2, i3);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        b bVar = (b) parcelable;
        super.onRestoreInstanceState(bVar.a());
        this.f.b(bVar.f491c);
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        b bVar = new b(super.onSaveInstanceState());
        bVar.f491c = new Bundle();
        this.f.d(bVar.f491c);
        return bVar;
    }

    public void setCheckedItem(int i2) {
        MenuItem findItem = this.f.findItem(i2);
        if (findItem != null) {
            this.g.a((p) findItem);
        }
    }

    public void setCheckedItem(MenuItem menuItem) {
        MenuItem findItem = this.f.findItem(menuItem.getItemId());
        if (findItem != null) {
            this.g.a((p) findItem);
            return;
        }
        throw new IllegalArgumentException("Called setCheckedItem(MenuItem) with an item that is not in the current menu.");
    }

    public void setItemBackground(Drawable drawable) {
        this.g.a(drawable);
    }

    public void setItemBackgroundResource(int i2) {
        setItemBackground(c.c(getContext(), i2));
    }

    public void setItemHorizontalPadding(int i2) {
        this.g.d(i2);
    }

    public void setItemHorizontalPaddingResource(int i2) {
        this.g.d(getResources().getDimensionPixelSize(i2));
    }

    public void setItemIconPadding(int i2) {
        this.g.e(i2);
    }

    public void setItemIconPaddingResource(int i2) {
        this.g.e(getResources().getDimensionPixelSize(i2));
    }

    public void setItemIconTintList(ColorStateList colorStateList) {
        this.g.a(colorStateList);
    }

    public void setItemTextAppearance(int i2) {
        this.g.f(i2);
    }

    public void setItemTextColor(ColorStateList colorStateList) {
        this.g.b(colorStateList);
    }

    public void setNavigationItemSelectedListener(a aVar) {
        this.h = aVar;
    }
}
