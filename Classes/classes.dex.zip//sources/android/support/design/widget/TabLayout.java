package android.support.design.widget;

import a.b.c.j;
import a.b.f.g.l;
import a.b.f.g.m;
import a.b.f.g.n;
import android.animation.Animator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.support.design.internal.k;
import android.support.v4.view.C0113j;
import android.support.v4.view.ViewPager;
import android.support.v4.view.t;
import android.support.v4.view.u;
import android.support.v4.view.y;
import android.support.v4.widget.r;
import android.support.v7.app.C0118a;
import android.support.v7.widget.wb;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

@ViewPager.a
public class TabLayout extends HorizontalScrollView {

    /* renamed from: a  reason: collision with root package name */
    private static final l<f> f514a = new n(16);
    int A;
    boolean B;
    boolean C;
    boolean D;
    private b E;
    private final ArrayList<b> F;
    private b G;
    private ValueAnimator H;
    ViewPager I;
    private t J;
    private DataSetObserver K;
    private g L;
    private a M;
    private boolean N;
    private final l<h> O;

    /* renamed from: b  reason: collision with root package name */
    private final ArrayList<f> f515b;

    /* renamed from: c  reason: collision with root package name */
    private f f516c;
    /* access modifiers changed from: private */
    public final RectF d;
    private final e e;
    int f;
    int g;
    int h;
    int i;
    int j;
    ColorStateList k;
    ColorStateList l;
    ColorStateList m;
    Drawable n;
    PorterDuff.Mode o;
    float p;
    float q;
    final int r;
    int s;
    private final int t;
    private final int u;
    private final int v;
    private int w;
    int x;
    int y;
    int z;

    private class a implements ViewPager.e {

        /* renamed from: a  reason: collision with root package name */
        private boolean f517a;

        a() {
        }

        public void a(ViewPager viewPager, t tVar, t tVar2) {
            TabLayout tabLayout = TabLayout.this;
            if (tabLayout.I == viewPager) {
                tabLayout.a(tVar2, this.f517a);
            }
        }

        /* access modifiers changed from: package-private */
        public void a(boolean z) {
            this.f517a = z;
        }
    }

    public interface b<T extends f> {
        void a(T t);

        void b(T t);

        void c(T t);
    }

    public interface c extends b<f> {
    }

    private class d extends DataSetObserver {
        d() {
        }

        public void onChanged() {
            TabLayout.this.c();
        }

        public void onInvalidated() {
            TabLayout.this.c();
        }
    }

    private class e extends LinearLayout {

        /* renamed from: a  reason: collision with root package name */
        private int f520a;

        /* renamed from: b  reason: collision with root package name */
        private final Paint f521b;

        /* renamed from: c  reason: collision with root package name */
        private final GradientDrawable f522c;
        int d = -1;
        float e;
        private int f = -1;
        private int g = -1;
        private int h = -1;
        private ValueAnimator i;

        e(Context context) {
            super(context);
            setWillNotDraw(false);
            this.f521b = new Paint();
            this.f522c = new GradientDrawable();
        }

        private void a(h hVar, RectF rectF) {
            int a2 = hVar.d();
            if (a2 < TabLayout.this.a(24)) {
                a2 = TabLayout.this.a(24);
            }
            int left = (hVar.getLeft() + hVar.getRight()) / 2;
            int i2 = a2 / 2;
            rectF.set((float) (left - i2), 0.0f, (float) (left + i2), 0.0f);
        }

        private void b() {
            int i2;
            int i3;
            View childAt = getChildAt(this.d);
            if (childAt == null || childAt.getWidth() <= 0) {
                i3 = -1;
                i2 = -1;
            } else {
                i3 = childAt.getLeft();
                i2 = childAt.getRight();
                TabLayout tabLayout = TabLayout.this;
                if (!tabLayout.C && (childAt instanceof h)) {
                    a((h) childAt, tabLayout.d);
                    i3 = (int) TabLayout.this.d.left;
                    i2 = (int) TabLayout.this.d.right;
                }
                if (this.e > 0.0f && this.d < getChildCount() - 1) {
                    View childAt2 = getChildAt(this.d + 1);
                    int left = childAt2.getLeft();
                    int right = childAt2.getRight();
                    TabLayout tabLayout2 = TabLayout.this;
                    if (!tabLayout2.C && (childAt2 instanceof h)) {
                        a((h) childAt2, tabLayout2.d);
                        left = (int) TabLayout.this.d.left;
                        right = (int) TabLayout.this.d.right;
                    }
                    float f2 = this.e;
                    i3 = (int) ((((float) left) * f2) + ((1.0f - f2) * ((float) i3)));
                    i2 = (int) ((((float) right) * f2) + ((1.0f - f2) * ((float) i2)));
                }
            }
            b(i3, i2);
        }

        /* access modifiers changed from: package-private */
        public void a(int i2) {
            if (this.f521b.getColor() != i2) {
                this.f521b.setColor(i2);
                y.B(this);
            }
        }

        /* access modifiers changed from: package-private */
        public void a(int i2, float f2) {
            ValueAnimator valueAnimator = this.i;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                this.i.cancel();
            }
            this.d = i2;
            this.e = f2;
            b();
        }

        /* access modifiers changed from: package-private */
        public void a(int i2, int i3) {
            ValueAnimator valueAnimator = this.i;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                this.i.cancel();
            }
            View childAt = getChildAt(i2);
            if (childAt == null) {
                b();
                return;
            }
            int left = childAt.getLeft();
            int right = childAt.getRight();
            TabLayout tabLayout = TabLayout.this;
            if (!tabLayout.C && (childAt instanceof h)) {
                a((h) childAt, tabLayout.d);
                left = (int) TabLayout.this.d.left;
                right = (int) TabLayout.this.d.right;
            }
            int i4 = left;
            int i5 = right;
            int i6 = this.g;
            int i7 = this.h;
            if (i6 != i4 || i7 != i5) {
                ValueAnimator valueAnimator2 = new ValueAnimator();
                this.i = valueAnimator2;
                valueAnimator2.setInterpolator(a.b.c.a.a.f18b);
                valueAnimator2.setDuration((long) i3);
                valueAnimator2.setFloatValues(new float[]{0.0f, 1.0f});
                valueAnimator2.addUpdateListener(new X(this, i6, i4, i7, i5));
                valueAnimator2.addListener(new Y(this, i2));
                valueAnimator2.start();
            }
        }

        /* access modifiers changed from: package-private */
        public boolean a() {
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                if (getChildAt(i2).getWidth() <= 0) {
                    return true;
                }
            }
            return false;
        }

        /* access modifiers changed from: package-private */
        public void b(int i2) {
            if (this.f520a != i2) {
                this.f520a = i2;
                y.B(this);
            }
        }

        /* access modifiers changed from: package-private */
        public void b(int i2, int i3) {
            if (i2 != this.g || i3 != this.h) {
                this.g = i2;
                this.h = i3;
                y.B(this);
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:24:0x0049  */
        /* JADX WARNING: Removed duplicated region for block: B:27:0x005a  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void draw(android.graphics.Canvas r6) {
            /*
                r5 = this;
                android.support.design.widget.TabLayout r0 = android.support.design.widget.TabLayout.this
                android.graphics.drawable.Drawable r0 = r0.n
                r1 = 0
                if (r0 == 0) goto L_0x000c
                int r0 = r0.getIntrinsicHeight()
                goto L_0x000d
            L_0x000c:
                r0 = 0
            L_0x000d:
                int r2 = r5.f520a
                if (r2 < 0) goto L_0x0012
                r0 = r2
            L_0x0012:
                android.support.design.widget.TabLayout r2 = android.support.design.widget.TabLayout.this
                int r2 = r2.z
                if (r2 == 0) goto L_0x0031
                r3 = 1
                r4 = 2
                if (r2 == r3) goto L_0x0023
                if (r2 == r4) goto L_0x003a
                r0 = 3
                if (r2 == r0) goto L_0x0036
                r0 = 0
                goto L_0x003a
            L_0x0023:
                int r1 = r5.getHeight()
                int r1 = r1 - r0
                int r1 = r1 / r4
                int r2 = r5.getHeight()
                int r2 = r2 + r0
                int r0 = r2 / 2
                goto L_0x003a
            L_0x0031:
                int r1 = r5.getHeight()
                int r1 = r1 - r0
            L_0x0036:
                int r0 = r5.getHeight()
            L_0x003a:
                int r2 = r5.g
                if (r2 < 0) goto L_0x0074
                int r3 = r5.h
                if (r3 <= r2) goto L_0x0074
                android.support.design.widget.TabLayout r2 = android.support.design.widget.TabLayout.this
                android.graphics.drawable.Drawable r2 = r2.n
                if (r2 == 0) goto L_0x0049
                goto L_0x004b
            L_0x0049:
                android.graphics.drawable.GradientDrawable r2 = r5.f522c
            L_0x004b:
                android.graphics.drawable.Drawable r2 = android.support.v4.graphics.drawable.a.h(r2)
                int r3 = r5.g
                int r4 = r5.h
                r2.setBounds(r3, r1, r4, r0)
                android.graphics.Paint r0 = r5.f521b
                if (r0 == 0) goto L_0x0071
                int r1 = android.os.Build.VERSION.SDK_INT
                r3 = 21
                if (r1 != r3) goto L_0x006a
                int r0 = r0.getColor()
                android.graphics.PorterDuff$Mode r1 = android.graphics.PorterDuff.Mode.SRC_IN
                r2.setColorFilter(r0, r1)
                goto L_0x0071
            L_0x006a:
                int r0 = r0.getColor()
                android.support.v4.graphics.drawable.a.b(r2, r0)
            L_0x0071:
                r2.draw(r6)
            L_0x0074:
                super.draw(r6)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.TabLayout.e.draw(android.graphics.Canvas):void");
        }

        /* access modifiers changed from: protected */
        public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
            super.onLayout(z, i2, i3, i4, i5);
            ValueAnimator valueAnimator = this.i;
            if (valueAnimator == null || !valueAnimator.isRunning()) {
                b();
                return;
            }
            this.i.cancel();
            a(this.d, Math.round((1.0f - this.i.getAnimatedFraction()) * ((float) this.i.getDuration())));
        }

        /* access modifiers changed from: protected */
        public void onMeasure(int i2, int i3) {
            super.onMeasure(i2, i3);
            if (View.MeasureSpec.getMode(i2) == 1073741824) {
                TabLayout tabLayout = TabLayout.this;
                boolean z = true;
                if (tabLayout.A == 1 && tabLayout.x == 1) {
                    int childCount = getChildCount();
                    int i4 = 0;
                    for (int i5 = 0; i5 < childCount; i5++) {
                        View childAt = getChildAt(i5);
                        if (childAt.getVisibility() == 0) {
                            i4 = Math.max(i4, childAt.getMeasuredWidth());
                        }
                    }
                    if (i4 > 0) {
                        if (i4 * childCount <= getMeasuredWidth() - (TabLayout.this.a(16) * 2)) {
                            boolean z2 = false;
                            for (int i6 = 0; i6 < childCount; i6++) {
                                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) getChildAt(i6).getLayoutParams();
                                if (layoutParams.width != i4 || layoutParams.weight != 0.0f) {
                                    layoutParams.width = i4;
                                    layoutParams.weight = 0.0f;
                                    z2 = true;
                                }
                            }
                            z = z2;
                        } else {
                            TabLayout tabLayout2 = TabLayout.this;
                            tabLayout2.x = 0;
                            tabLayout2.a(false);
                        }
                        if (z) {
                            super.onMeasure(i2, i3);
                        }
                    }
                }
            }
        }

        public void onRtlPropertiesChanged(int i2) {
            super.onRtlPropertiesChanged(i2);
            if (Build.VERSION.SDK_INT < 23 && this.f != i2) {
                requestLayout();
                this.f = i2;
            }
        }
    }

    public static class f {

        /* renamed from: a  reason: collision with root package name */
        private Object f523a;

        /* renamed from: b  reason: collision with root package name */
        private Drawable f524b;
        /* access modifiers changed from: private */

        /* renamed from: c  reason: collision with root package name */
        public CharSequence f525c;
        /* access modifiers changed from: private */
        public CharSequence d;
        private int e = -1;
        private View f;
        public TabLayout g;
        public h h;

        public f a(int i) {
            a(LayoutInflater.from(this.h.getContext()).inflate(i, this.h, false));
            return this;
        }

        public f a(Drawable drawable) {
            this.f524b = drawable;
            h();
            return this;
        }

        public f a(View view) {
            this.f = view;
            h();
            return this;
        }

        public f a(CharSequence charSequence) {
            this.d = charSequence;
            h();
            return this;
        }

        public View a() {
            return this.f;
        }

        public Drawable b() {
            return this.f524b;
        }

        public f b(int i) {
            TabLayout tabLayout = this.g;
            if (tabLayout != null) {
                a(a.b.g.b.a.a.b(tabLayout.getContext(), i));
                return this;
            }
            throw new IllegalArgumentException("Tab not attached to a TabLayout");
        }

        public f b(CharSequence charSequence) {
            if (TextUtils.isEmpty(this.d) && !TextUtils.isEmpty(charSequence)) {
                this.h.setContentDescription(charSequence);
            }
            this.f525c = charSequence;
            h();
            return this;
        }

        public int c() {
            return this.e;
        }

        /* access modifiers changed from: package-private */
        public void c(int i) {
            this.e = i;
        }

        public CharSequence d() {
            return this.f525c;
        }

        public boolean e() {
            TabLayout tabLayout = this.g;
            if (tabLayout != null) {
                return tabLayout.getSelectedTabPosition() == this.e;
            }
            throw new IllegalArgumentException("Tab not attached to a TabLayout");
        }

        /* access modifiers changed from: package-private */
        public void f() {
            this.g = null;
            this.h = null;
            this.f523a = null;
            this.f524b = null;
            this.f525c = null;
            this.d = null;
            this.e = -1;
            this.f = null;
        }

        public void g() {
            TabLayout tabLayout = this.g;
            if (tabLayout != null) {
                tabLayout.c(this);
                return;
            }
            throw new IllegalArgumentException("Tab not attached to a TabLayout");
        }

        /* access modifiers changed from: package-private */
        public void h() {
            h hVar = this.h;
            if (hVar != null) {
                hVar.b();
            }
        }
    }

    public static class g implements ViewPager.f {

        /* renamed from: a  reason: collision with root package name */
        private final WeakReference<TabLayout> f526a;

        /* renamed from: b  reason: collision with root package name */
        private int f527b;

        /* renamed from: c  reason: collision with root package name */
        private int f528c;

        public g(TabLayout tabLayout) {
            this.f526a = new WeakReference<>(tabLayout);
        }

        /* access modifiers changed from: package-private */
        public void a() {
            this.f528c = 0;
            this.f527b = 0;
        }

        public void a(int i) {
            this.f527b = this.f528c;
            this.f528c = i;
        }

        public void a(int i, float f, int i2) {
            TabLayout tabLayout = (TabLayout) this.f526a.get();
            if (tabLayout != null) {
                boolean z = false;
                boolean z2 = this.f528c != 2 || this.f527b == 1;
                if (!(this.f528c == 2 && this.f527b == 0)) {
                    z = true;
                }
                tabLayout.a(i, f, z2, z);
            }
        }

        public void b(int i) {
            TabLayout tabLayout = (TabLayout) this.f526a.get();
            if (tabLayout != null && tabLayout.getSelectedTabPosition() != i && i < tabLayout.getTabCount()) {
                int i2 = this.f528c;
                tabLayout.b(tabLayout.b(i), i2 == 0 || (i2 == 2 && this.f527b == 0));
            }
        }
    }

    class h extends LinearLayout {

        /* renamed from: a  reason: collision with root package name */
        private f f529a;

        /* renamed from: b  reason: collision with root package name */
        private TextView f530b;

        /* renamed from: c  reason: collision with root package name */
        private ImageView f531c;
        private View d;
        private TextView e;
        private ImageView f;
        private Drawable g;
        private int h = 2;

        public h(Context context) {
            super(context);
            a(context);
            y.a(this, TabLayout.this.f, TabLayout.this.g, TabLayout.this.h, TabLayout.this.i);
            setGravity(17);
            setOrientation(TabLayout.this.B ^ true ? 1 : 0);
            setClickable(true);
            y.a((View) this, u.a(getContext(), 1002));
        }

        private float a(Layout layout, int i2, float f2) {
            return layout.getLineWidth(i2) * (f2 / layout.getPaint().getTextSize());
        }

        /* JADX WARNING: type inference failed for: r2v3, types: [android.graphics.drawable.LayerDrawable] */
        /* JADX WARNING: type inference failed for: r0v3, types: [android.graphics.drawable.RippleDrawable] */
        /* access modifiers changed from: private */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void a(android.content.Context r7) {
            /*
                r6 = this;
                android.support.design.widget.TabLayout r0 = android.support.design.widget.TabLayout.this
                int r0 = r0.r
                r1 = 0
                if (r0 == 0) goto L_0x0021
                android.graphics.drawable.Drawable r7 = a.b.g.b.a.a.b(r7, r0)
                r6.g = r7
                android.graphics.drawable.Drawable r7 = r6.g
                if (r7 == 0) goto L_0x0023
                boolean r7 = r7.isStateful()
                if (r7 == 0) goto L_0x0023
                android.graphics.drawable.Drawable r7 = r6.g
                int[] r0 = r6.getDrawableState()
                r7.setState(r0)
                goto L_0x0023
            L_0x0021:
                r6.g = r1
            L_0x0023:
                android.graphics.drawable.GradientDrawable r7 = new android.graphics.drawable.GradientDrawable
                r7.<init>()
                r0 = 0
                r7.setColor(r0)
                android.support.design.widget.TabLayout r2 = android.support.design.widget.TabLayout.this
                android.content.res.ColorStateList r2 = r2.m
                if (r2 == 0) goto L_0x007a
                android.graphics.drawable.GradientDrawable r2 = new android.graphics.drawable.GradientDrawable
                r2.<init>()
                r3 = 925353388(0x3727c5ac, float:1.0E-5)
                r2.setCornerRadius(r3)
                r3 = -1
                r2.setColor(r3)
                android.support.design.widget.TabLayout r3 = android.support.design.widget.TabLayout.this
                android.content.res.ColorStateList r3 = r3.m
                android.content.res.ColorStateList r3 = a.b.c.f.a.a((android.content.res.ColorStateList) r3)
                int r4 = android.os.Build.VERSION.SDK_INT
                r5 = 21
                if (r4 < r5) goto L_0x0065
                android.graphics.drawable.RippleDrawable r0 = new android.graphics.drawable.RippleDrawable
                android.support.design.widget.TabLayout r4 = android.support.design.widget.TabLayout.this
                boolean r4 = r4.D
                if (r4 == 0) goto L_0x0058
                r7 = r1
            L_0x0058:
                android.support.design.widget.TabLayout r4 = android.support.design.widget.TabLayout.this
                boolean r4 = r4.D
                if (r4 == 0) goto L_0x005f
                goto L_0x0060
            L_0x005f:
                r1 = r2
            L_0x0060:
                r0.<init>(r3, r7, r1)
                r7 = r0
                goto L_0x007a
            L_0x0065:
                android.graphics.drawable.Drawable r1 = android.support.v4.graphics.drawable.a.h(r2)
                android.support.v4.graphics.drawable.a.a((android.graphics.drawable.Drawable) r1, (android.content.res.ColorStateList) r3)
                android.graphics.drawable.LayerDrawable r2 = new android.graphics.drawable.LayerDrawable
                r3 = 2
                android.graphics.drawable.Drawable[] r3 = new android.graphics.drawable.Drawable[r3]
                r3[r0] = r7
                r7 = 1
                r3[r7] = r1
                r2.<init>(r3)
                r7 = r2
            L_0x007a:
                android.support.v4.view.y.a((android.view.View) r6, (android.graphics.drawable.Drawable) r7)
                android.support.design.widget.TabLayout r7 = android.support.design.widget.TabLayout.this
                r7.invalidate()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.TabLayout.h.a(android.content.Context):void");
        }

        /* access modifiers changed from: private */
        public void a(Canvas canvas) {
            Drawable drawable = this.g;
            if (drawable != null) {
                drawable.setBounds(getLeft(), getTop(), getRight(), getBottom());
                this.g.draw(canvas);
            }
        }

        private void a(TextView textView, ImageView imageView) {
            f fVar = this.f529a;
            Drawable mutate = (fVar == null || fVar.b() == null) ? null : android.support.v4.graphics.drawable.a.h(this.f529a.b()).mutate();
            f fVar2 = this.f529a;
            CharSequence d2 = fVar2 != null ? fVar2.d() : null;
            if (imageView != null) {
                if (mutate != null) {
                    imageView.setImageDrawable(mutate);
                    imageView.setVisibility(0);
                    setVisibility(0);
                } else {
                    imageView.setVisibility(8);
                    imageView.setImageDrawable((Drawable) null);
                }
            }
            boolean z = !TextUtils.isEmpty(d2);
            if (textView != null) {
                if (z) {
                    textView.setText(d2);
                    textView.setVisibility(0);
                    setVisibility(0);
                } else {
                    textView.setVisibility(8);
                    textView.setText((CharSequence) null);
                }
            }
            if (imageView != null) {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) imageView.getLayoutParams();
                int a2 = (!z || imageView.getVisibility() != 0) ? 0 : TabLayout.this.a(8);
                if (TabLayout.this.B) {
                    if (a2 != C0113j.a(marginLayoutParams)) {
                        C0113j.a(marginLayoutParams, a2);
                        marginLayoutParams.bottomMargin = 0;
                    }
                } else if (a2 != marginLayoutParams.bottomMargin) {
                    marginLayoutParams.bottomMargin = a2;
                    C0113j.a(marginLayoutParams, 0);
                }
                imageView.setLayoutParams(marginLayoutParams);
                imageView.requestLayout();
            }
            f fVar3 = this.f529a;
            CharSequence a3 = fVar3 != null ? fVar3.d : null;
            if (z) {
                a3 = null;
            }
            wb.a(this, a3);
        }

        /* access modifiers changed from: private */
        public int d() {
            int i2 = 0;
            int i3 = 0;
            boolean z = false;
            for (View view : new View[]{this.f530b, this.f531c, this.d}) {
                if (view != null && view.getVisibility() == 0) {
                    i3 = z ? Math.min(i3, view.getLeft()) : view.getLeft();
                    i2 = z ? Math.max(i2, view.getRight()) : view.getRight();
                    z = true;
                }
            }
            return i2 - i3;
        }

        /* access modifiers changed from: package-private */
        public void a() {
            a((f) null);
            setSelected(false);
        }

        /* access modifiers changed from: package-private */
        public void a(f fVar) {
            if (fVar != this.f529a) {
                this.f529a = fVar;
                b();
            }
        }

        /* access modifiers changed from: package-private */
        public final void b() {
            ImageView imageView;
            TextView textView;
            f fVar = this.f529a;
            Drawable drawable = null;
            View a2 = fVar != null ? fVar.a() : null;
            if (a2 != null) {
                ViewParent parent = a2.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(a2);
                    }
                    addView(a2);
                }
                this.d = a2;
                TextView textView2 = this.f530b;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                }
                ImageView imageView2 = this.f531c;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.f531c.setImageDrawable((Drawable) null);
                }
                this.e = (TextView) a2.findViewById(16908308);
                TextView textView3 = this.e;
                if (textView3 != null) {
                    this.h = r.d(textView3);
                }
                this.f = (ImageView) a2.findViewById(16908294);
            } else {
                View view = this.d;
                if (view != null) {
                    removeView(view);
                    this.d = null;
                }
                this.e = null;
                this.f = null;
            }
            boolean z = false;
            if (this.d == null) {
                if (this.f531c == null) {
                    ImageView imageView3 = (ImageView) LayoutInflater.from(getContext()).inflate(a.b.c.h.design_layout_tab_icon, this, false);
                    addView(imageView3, 0);
                    this.f531c = imageView3;
                }
                if (!(fVar == null || fVar.b() == null)) {
                    drawable = android.support.v4.graphics.drawable.a.h(fVar.b()).mutate();
                }
                if (drawable != null) {
                    android.support.v4.graphics.drawable.a.a(drawable, TabLayout.this.l);
                    PorterDuff.Mode mode = TabLayout.this.o;
                    if (mode != null) {
                        android.support.v4.graphics.drawable.a.a(drawable, mode);
                    }
                }
                if (this.f530b == null) {
                    TextView textView4 = (TextView) LayoutInflater.from(getContext()).inflate(a.b.c.h.design_layout_tab_text, this, false);
                    addView(textView4);
                    this.f530b = textView4;
                    this.h = r.d(this.f530b);
                }
                r.d(this.f530b, TabLayout.this.j);
                ColorStateList colorStateList = TabLayout.this.k;
                if (colorStateList != null) {
                    this.f530b.setTextColor(colorStateList);
                }
                textView = this.f530b;
                imageView = this.f531c;
            } else {
                if (!(this.e == null && this.f == null)) {
                    textView = this.e;
                    imageView = this.f;
                }
                if (fVar != null && !TextUtils.isEmpty(fVar.d)) {
                    setContentDescription(fVar.d);
                }
                if (fVar != null && fVar.e()) {
                    z = true;
                }
                setSelected(z);
            }
            a(textView, imageView);
            setContentDescription(fVar.d);
            z = true;
            setSelected(z);
        }

        /* access modifiers changed from: package-private */
        public final void c() {
            ImageView imageView;
            TextView textView;
            setOrientation(TabLayout.this.B ^ true ? 1 : 0);
            if (this.e == null && this.f == null) {
                textView = this.f530b;
                imageView = this.f531c;
            } else {
                textView = this.e;
                imageView = this.f;
            }
            a(textView, imageView);
        }

        /* access modifiers changed from: protected */
        public void drawableStateChanged() {
            super.drawableStateChanged();
            int[] drawableState = getDrawableState();
            Drawable drawable = this.g;
            boolean z = false;
            if (drawable != null && drawable.isStateful()) {
                z = false | this.g.setState(drawableState);
            }
            if (z) {
                invalidate();
                TabLayout.this.invalidate();
            }
        }

        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName(C0118a.c.class.getName());
        }

        @TargetApi(14)
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName(C0118a.c.class.getName());
        }

        public void onMeasure(int i2, int i3) {
            Layout layout;
            int size = View.MeasureSpec.getSize(i2);
            int mode = View.MeasureSpec.getMode(i2);
            int tabMaxWidth = TabLayout.this.getTabMaxWidth();
            if (tabMaxWidth > 0 && (mode == 0 || size > tabMaxWidth)) {
                i2 = View.MeasureSpec.makeMeasureSpec(TabLayout.this.s, Integer.MIN_VALUE);
            }
            super.onMeasure(i2, i3);
            if (this.f530b != null) {
                float f2 = TabLayout.this.p;
                int i4 = this.h;
                ImageView imageView = this.f531c;
                boolean z = true;
                if (imageView == null || imageView.getVisibility() != 0) {
                    TextView textView = this.f530b;
                    if (textView != null && textView.getLineCount() > 1) {
                        f2 = TabLayout.this.q;
                    }
                } else {
                    i4 = 1;
                }
                float textSize = this.f530b.getTextSize();
                int lineCount = this.f530b.getLineCount();
                int d2 = r.d(this.f530b);
                if (f2 != textSize || (d2 >= 0 && i4 != d2)) {
                    if (TabLayout.this.A == 1 && f2 > textSize && lineCount == 1 && ((layout = this.f530b.getLayout()) == null || a(layout, 0, f2) > ((float) ((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight())))) {
                        z = false;
                    }
                    if (z) {
                        this.f530b.setTextSize(0, f2);
                        this.f530b.setMaxLines(i4);
                        super.onMeasure(i2, i3);
                    }
                }
            }
        }

        public boolean performClick() {
            boolean performClick = super.performClick();
            if (this.f529a == null) {
                return performClick;
            }
            if (!performClick) {
                playSoundEffect(0);
            }
            this.f529a.g();
            return true;
        }

        public void setSelected(boolean z) {
            boolean z2 = isSelected() != z;
            super.setSelected(z);
            if (z2 && z && Build.VERSION.SDK_INT < 16) {
                sendAccessibilityEvent(4);
            }
            TextView textView = this.f530b;
            if (textView != null) {
                textView.setSelected(z);
            }
            ImageView imageView = this.f531c;
            if (imageView != null) {
                imageView.setSelected(z);
            }
            View view = this.d;
            if (view != null) {
                view.setSelected(z);
            }
        }
    }

    public static class i implements c {

        /* renamed from: a  reason: collision with root package name */
        private final ViewPager f532a;

        public i(ViewPager viewPager) {
            this.f532a = viewPager;
        }

        public void a(f fVar) {
        }

        public void b(f fVar) {
        }

        public void c(f fVar) {
            this.f532a.setCurrentItem(fVar.c());
        }
    }

    public TabLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public TabLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.b.c.b.tabStyle);
    }

    /* JADX INFO: finally extract failed */
    public TabLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f515b = new ArrayList<>();
        this.d = new RectF();
        this.s = Integer.MAX_VALUE;
        this.F = new ArrayList<>();
        this.O = new m(12);
        setHorizontalScrollBarEnabled(false);
        this.e = new e(context);
        super.addView(this.e, 0, new FrameLayout.LayoutParams(-2, -1));
        TypedArray a2 = k.a(context, attributeSet, a.b.c.k.TabLayout, i2, j.Widget_Design_TabLayout, a.b.c.k.TabLayout_tabTextAppearance);
        this.e.b(a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabIndicatorHeight, -1));
        this.e.a(a2.getColor(a.b.c.k.TabLayout_tabIndicatorColor, 0));
        setSelectedTabIndicator(a.b.c.e.a.b(context, a2, a.b.c.k.TabLayout_tabIndicator));
        setSelectedTabIndicatorGravity(a2.getInt(a.b.c.k.TabLayout_tabIndicatorGravity, 0));
        setTabIndicatorFullWidth(a2.getBoolean(a.b.c.k.TabLayout_tabIndicatorFullWidth, true));
        int dimensionPixelSize = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabPadding, 0);
        this.i = dimensionPixelSize;
        this.h = dimensionPixelSize;
        this.g = dimensionPixelSize;
        this.f = dimensionPixelSize;
        this.f = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabPaddingStart, this.f);
        this.g = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabPaddingTop, this.g);
        this.h = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabPaddingEnd, this.h);
        this.i = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabPaddingBottom, this.i);
        this.j = a2.getResourceId(a.b.c.k.TabLayout_tabTextAppearance, j.TextAppearance_Design_Tab);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(this.j, a.b.g.a.j.TextAppearance);
        try {
            this.p = (float) obtainStyledAttributes.getDimensionPixelSize(a.b.g.a.j.TextAppearance_android_textSize, 0);
            this.k = a.b.c.e.a.a(context, obtainStyledAttributes, a.b.g.a.j.TextAppearance_android_textColor);
            obtainStyledAttributes.recycle();
            if (a2.hasValue(a.b.c.k.TabLayout_tabTextColor)) {
                this.k = a.b.c.e.a.a(context, a2, a.b.c.k.TabLayout_tabTextColor);
            }
            if (a2.hasValue(a.b.c.k.TabLayout_tabSelectedTextColor)) {
                this.k = b(this.k.getDefaultColor(), a2.getColor(a.b.c.k.TabLayout_tabSelectedTextColor, 0));
            }
            this.l = a.b.c.e.a.a(context, a2, a.b.c.k.TabLayout_tabIconTint);
            this.o = android.support.design.internal.l.a(a2.getInt(a.b.c.k.TabLayout_tabIconTintMode, -1), (PorterDuff.Mode) null);
            this.m = a.b.c.e.a.a(context, a2, a.b.c.k.TabLayout_tabRippleColor);
            this.y = a2.getInt(a.b.c.k.TabLayout_tabIndicatorAnimationDuration, 300);
            this.t = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabMinWidth, -1);
            this.u = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabMaxWidth, -1);
            this.r = a2.getResourceId(a.b.c.k.TabLayout_tabBackground, 0);
            this.w = a2.getDimensionPixelSize(a.b.c.k.TabLayout_tabContentStart, 0);
            this.A = a2.getInt(a.b.c.k.TabLayout_tabMode, 1);
            this.x = a2.getInt(a.b.c.k.TabLayout_tabGravity, 0);
            this.B = a2.getBoolean(a.b.c.k.TabLayout_tabInlineLabel, false);
            this.D = a2.getBoolean(a.b.c.k.TabLayout_tabUnboundedRipple, false);
            a2.recycle();
            Resources resources = getResources();
            this.q = (float) resources.getDimensionPixelSize(a.b.c.d.design_tab_text_size_2line);
            this.v = resources.getDimensionPixelSize(a.b.c.d.design_tab_scrollable_min_width);
            e();
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    private int a(int i2, float f2) {
        int i3 = 0;
        if (this.A != 0) {
            return 0;
        }
        View childAt = this.e.getChildAt(i2);
        int i4 = i2 + 1;
        View childAt2 = i4 < this.e.getChildCount() ? this.e.getChildAt(i4) : null;
        int width = childAt != null ? childAt.getWidth() : 0;
        if (childAt2 != null) {
            i3 = childAt2.getWidth();
        }
        int left = (childAt.getLeft() + (width / 2)) - (getWidth() / 2);
        int i5 = (int) (((float) (width + i3)) * 0.5f * f2);
        return y.k(this) == 0 ? left + i5 : left - i5;
    }

    private void a(f fVar, int i2) {
        fVar.c(i2);
        this.f515b.add(i2, fVar);
        int size = this.f515b.size();
        while (true) {
            i2++;
            if (i2 < size) {
                this.f515b.get(i2).c(i2);
            } else {
                return;
            }
        }
    }

    private void a(V v2) {
        f b2 = b();
        CharSequence charSequence = v2.f541a;
        if (charSequence != null) {
            b2.b(charSequence);
        }
        Drawable drawable = v2.f542b;
        if (drawable != null) {
            b2.a(drawable);
        }
        int i2 = v2.f543c;
        if (i2 != 0) {
            b2.a(i2);
        }
        if (!TextUtils.isEmpty(v2.getContentDescription())) {
            b2.a(v2.getContentDescription());
        }
        a(b2);
    }

    private void a(ViewPager viewPager, boolean z2, boolean z3) {
        ViewPager viewPager2 = this.I;
        if (viewPager2 != null) {
            g gVar = this.L;
            if (gVar != null) {
                viewPager2.b((ViewPager.f) gVar);
            }
            a aVar = this.M;
            if (aVar != null) {
                this.I.b((ViewPager.e) aVar);
            }
        }
        b bVar = this.G;
        if (bVar != null) {
            b(bVar);
            this.G = null;
        }
        if (viewPager != null) {
            this.I = viewPager;
            if (this.L == null) {
                this.L = new g(this);
            }
            this.L.a();
            viewPager.a((ViewPager.f) this.L);
            this.G = new i(viewPager);
            a(this.G);
            t adapter = viewPager.getAdapter();
            if (adapter != null) {
                a(adapter, z2);
            }
            if (this.M == null) {
                this.M = new a();
            }
            this.M.a(z2);
            viewPager.a((ViewPager.e) this.M);
            a(viewPager.getCurrentItem(), 0.0f, true);
        } else {
            this.I = null;
            a((t) null, false);
        }
        this.N = z3;
    }

    private void a(View view) {
        if (view instanceof V) {
            a((V) view);
            return;
        }
        throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
    }

    private void a(LinearLayout.LayoutParams layoutParams) {
        float f2;
        if (this.A == 1 && this.x == 0) {
            layoutParams.width = 0;
            f2 = 1.0f;
        } else {
            layoutParams.width = -2;
            f2 = 0.0f;
        }
        layoutParams.weight = f2;
    }

    private static ColorStateList b(int i2, int i3) {
        return new ColorStateList(new int[][]{HorizontalScrollView.SELECTED_STATE_SET, HorizontalScrollView.EMPTY_STATE_SET}, new int[]{i3, i2});
    }

    private void c(int i2) {
        if (i2 != -1) {
            if (getWindowToken() == null || !y.y(this) || this.e.a()) {
                a(i2, 0.0f, true);
                return;
            }
            int scrollX = getScrollX();
            int a2 = a(i2, 0.0f);
            if (scrollX != a2) {
                g();
                this.H.setIntValues(new int[]{scrollX, a2});
                this.H.start();
            }
            this.e.a(i2, this.y);
        }
    }

    private void d(int i2) {
        h hVar = (h) this.e.getChildAt(i2);
        this.e.removeViewAt(i2);
        if (hVar != null) {
            hVar.a();
            this.O.a(hVar);
        }
        requestLayout();
    }

    private void d(f fVar) {
        this.e.addView(fVar.h, fVar.c(), f());
    }

    private h e(f fVar) {
        l<h> lVar = this.O;
        h a2 = lVar != null ? lVar.a() : null;
        if (a2 == null) {
            a2 = new h(getContext());
        }
        a2.a(fVar);
        a2.setFocusable(true);
        a2.setMinimumWidth(getTabMinWidth());
        a2.setContentDescription(TextUtils.isEmpty(fVar.d) ? fVar.f525c : fVar.d);
        return a2;
    }

    private void e() {
        y.a(this.e, this.A == 0 ? Math.max(0, this.w - this.f) : 0, 0, 0, 0);
        int i2 = this.A;
        if (i2 == 0) {
            this.e.setGravity(8388611);
        } else if (i2 == 1) {
            this.e.setGravity(1);
        }
        a(true);
    }

    private LinearLayout.LayoutParams f() {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
        a(layoutParams);
        return layoutParams;
    }

    private void f(f fVar) {
        for (int size = this.F.size() - 1; size >= 0; size--) {
            this.F.get(size).a(fVar);
        }
    }

    private void g() {
        if (this.H == null) {
            this.H = new ValueAnimator();
            this.H.setInterpolator(a.b.c.a.a.f18b);
            this.H.setDuration((long) this.y);
            this.H.addUpdateListener(new W(this));
        }
    }

    private void g(f fVar) {
        for (int size = this.F.size() - 1; size >= 0; size--) {
            this.F.get(size).c(fVar);
        }
    }

    private int getDefaultHeight() {
        int size = this.f515b.size();
        boolean z2 = false;
        int i2 = 0;
        while (true) {
            if (i2 < size) {
                f fVar = this.f515b.get(i2);
                if (fVar != null && fVar.b() != null && !TextUtils.isEmpty(fVar.d())) {
                    z2 = true;
                    break;
                }
                i2++;
            } else {
                break;
            }
        }
        return (!z2 || this.B) ? 48 : 72;
    }

    private int getTabMinWidth() {
        int i2 = this.t;
        if (i2 != -1) {
            return i2;
        }
        if (this.A == 0) {
            return this.v;
        }
        return 0;
    }

    private int getTabScrollRange() {
        return Math.max(0, ((this.e.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight());
    }

    private void h() {
        int size = this.f515b.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f515b.get(i2).h();
        }
    }

    private void h(f fVar) {
        for (int size = this.F.size() - 1; size >= 0; size--) {
            this.F.get(size).b(fVar);
        }
    }

    private void setSelectedTabView(int i2) {
        int childCount = this.e.getChildCount();
        if (i2 < childCount) {
            int i3 = 0;
            while (i3 < childCount) {
                View childAt = this.e.getChildAt(i3);
                boolean z2 = true;
                childAt.setSelected(i3 == i2);
                if (i3 != i2) {
                    z2 = false;
                }
                childAt.setActivated(z2);
                i3++;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public int a(int i2) {
        return Math.round(getResources().getDisplayMetrics().density * ((float) i2));
    }

    /* access modifiers changed from: protected */
    public f a() {
        f a2 = f514a.a();
        return a2 == null ? new f() : a2;
    }

    public void a(int i2, float f2, boolean z2) {
        a(i2, f2, z2, true);
    }

    /* access modifiers changed from: package-private */
    public void a(int i2, float f2, boolean z2, boolean z3) {
        int round = Math.round(((float) i2) + f2);
        if (round >= 0 && round < this.e.getChildCount()) {
            if (z3) {
                this.e.a(i2, f2);
            }
            ValueAnimator valueAnimator = this.H;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                this.H.cancel();
            }
            scrollTo(a(i2, f2), 0);
            if (z2) {
                setSelectedTabView(round);
            }
        }
    }

    public void a(int i2, int i3) {
        setTabTextColors(b(i2, i3));
    }

    public void a(b bVar) {
        if (!this.F.contains(bVar)) {
            this.F.add(bVar);
        }
    }

    public void a(f fVar) {
        a(fVar, this.f515b.isEmpty());
    }

    public void a(f fVar, int i2, boolean z2) {
        if (fVar.g == this) {
            a(fVar, i2);
            d(fVar);
            if (z2) {
                fVar.g();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
    }

    public void a(f fVar, boolean z2) {
        a(fVar, this.f515b.size(), z2);
    }

    public void a(ViewPager viewPager, boolean z2) {
        a(viewPager, z2, false);
    }

    /* access modifiers changed from: package-private */
    public void a(t tVar, boolean z2) {
        DataSetObserver dataSetObserver;
        t tVar2 = this.J;
        if (!(tVar2 == null || (dataSetObserver = this.K) == null)) {
            tVar2.c(dataSetObserver);
        }
        this.J = tVar;
        if (z2 && tVar != null) {
            if (this.K == null) {
                this.K = new d();
            }
            tVar.a(this.K);
        }
        c();
    }

    /* access modifiers changed from: package-private */
    public void a(boolean z2) {
        for (int i2 = 0; i2 < this.e.getChildCount(); i2++) {
            View childAt = this.e.getChildAt(i2);
            childAt.setMinimumWidth(getTabMinWidth());
            a((LinearLayout.LayoutParams) childAt.getLayoutParams());
            if (z2) {
                childAt.requestLayout();
            }
        }
    }

    public void addView(View view) {
        a(view);
    }

    public void addView(View view, int i2) {
        a(view);
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        a(view);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        a(view);
    }

    public f b() {
        f a2 = a();
        a2.g = this;
        a2.h = e(a2);
        return a2;
    }

    public f b(int i2) {
        if (i2 < 0 || i2 >= getTabCount()) {
            return null;
        }
        return this.f515b.get(i2);
    }

    public void b(b bVar) {
        this.F.remove(bVar);
    }

    /* access modifiers changed from: package-private */
    public void b(f fVar, boolean z2) {
        f fVar2 = this.f516c;
        if (fVar2 != fVar) {
            int c2 = fVar != null ? fVar.c() : -1;
            if (z2) {
                if ((fVar2 == null || fVar2.c() == -1) && c2 != -1) {
                    a(c2, 0.0f, true);
                } else {
                    c(c2);
                }
                if (c2 != -1) {
                    setSelectedTabView(c2);
                }
            }
            this.f516c = fVar;
            if (fVar2 != null) {
                h(fVar2);
            }
            if (fVar != null) {
                g(fVar);
            }
        } else if (fVar2 != null) {
            f(fVar);
            c(fVar.c());
        }
    }

    /* access modifiers changed from: protected */
    public boolean b(f fVar) {
        return f514a.a(fVar);
    }

    /* access modifiers changed from: package-private */
    public void c() {
        int currentItem;
        d();
        t tVar = this.J;
        if (tVar != null) {
            int a2 = tVar.a();
            for (int i2 = 0; i2 < a2; i2++) {
                f b2 = b();
                b2.b(this.J.a(i2));
                a(b2, false);
            }
            ViewPager viewPager = this.I;
            if (viewPager != null && a2 > 0 && (currentItem = viewPager.getCurrentItem()) != getSelectedTabPosition() && currentItem < getTabCount()) {
                c(b(currentItem));
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void c(f fVar) {
        b(fVar, true);
    }

    public void d() {
        for (int childCount = this.e.getChildCount() - 1; childCount >= 0; childCount--) {
            d(childCount);
        }
        Iterator<f> it = this.f515b.iterator();
        while (it.hasNext()) {
            f next = it.next();
            it.remove();
            next.f();
            b(next);
        }
        this.f516c = null;
    }

    public FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }

    public int getSelectedTabPosition() {
        f fVar = this.f516c;
        if (fVar != null) {
            return fVar.c();
        }
        return -1;
    }

    public int getTabCount() {
        return this.f515b.size();
    }

    public int getTabGravity() {
        return this.x;
    }

    public ColorStateList getTabIconTint() {
        return this.l;
    }

    public int getTabIndicatorGravity() {
        return this.z;
    }

    /* access modifiers changed from: package-private */
    public int getTabMaxWidth() {
        return this.s;
    }

    public int getTabMode() {
        return this.A;
    }

    public ColorStateList getTabRippleColor() {
        return this.m;
    }

    public Drawable getTabSelectedIndicator() {
        return this.n;
    }

    public ColorStateList getTabTextColors() {
        return this.k;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.I == null) {
            ViewParent parent = getParent();
            if (parent instanceof ViewPager) {
                a((ViewPager) parent, true, true);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.N) {
            setupWithViewPager((ViewPager) null);
            this.N = false;
        }
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        for (int i2 = 0; i2 < this.e.getChildCount(); i2++) {
            View childAt = this.e.getChildAt(i2);
            if (childAt instanceof h) {
                ((h) childAt).a(canvas);
            }
        }
        super.onDraw(canvas);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        int a2 = a(getDefaultHeight()) + getPaddingTop() + getPaddingBottom();
        int mode = View.MeasureSpec.getMode(i3);
        if (mode == Integer.MIN_VALUE) {
            i3 = View.MeasureSpec.makeMeasureSpec(Math.min(a2, View.MeasureSpec.getSize(i3)), 1073741824);
        } else if (mode == 0) {
            i3 = View.MeasureSpec.makeMeasureSpec(a2, 1073741824);
        }
        int size = View.MeasureSpec.getSize(i2);
        if (View.MeasureSpec.getMode(i2) != 0) {
            int i4 = this.u;
            if (i4 <= 0) {
                i4 = size - a(56);
            }
            this.s = i4;
        }
        super.onMeasure(i2, i3);
        if (getChildCount() == 1) {
            boolean z2 = false;
            View childAt = getChildAt(0);
            int i5 = this.A;
            if (i5 == 0 ? childAt.getMeasuredWidth() < getMeasuredWidth() : !(i5 != 1 || childAt.getMeasuredWidth() == getMeasuredWidth())) {
                z2 = true;
            }
            if (z2) {
                childAt.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), HorizontalScrollView.getChildMeasureSpec(i3, getPaddingTop() + getPaddingBottom(), childAt.getLayoutParams().height));
            }
        }
    }

    public void setInlineLabel(boolean z2) {
        if (this.B != z2) {
            this.B = z2;
            for (int i2 = 0; i2 < this.e.getChildCount(); i2++) {
                View childAt = this.e.getChildAt(i2);
                if (childAt instanceof h) {
                    ((h) childAt).c();
                }
            }
            e();
        }
    }

    public void setInlineLabelResource(int i2) {
        setInlineLabel(getResources().getBoolean(i2));
    }

    @Deprecated
    public void setOnTabSelectedListener(b bVar) {
        b bVar2 = this.E;
        if (bVar2 != null) {
            b(bVar2);
        }
        this.E = bVar;
        if (bVar != null) {
            a(bVar);
        }
    }

    /* access modifiers changed from: package-private */
    public void setScrollAnimatorListener(Animator.AnimatorListener animatorListener) {
        g();
        this.H.addListener(animatorListener);
    }

    public void setSelectedTabIndicator(int i2) {
        setSelectedTabIndicator(i2 != 0 ? a.b.g.b.a.a.b(getContext(), i2) : null);
    }

    public void setSelectedTabIndicator(Drawable drawable) {
        if (this.n != drawable) {
            this.n = drawable;
            y.B(this.e);
        }
    }

    public void setSelectedTabIndicatorColor(int i2) {
        this.e.a(i2);
    }

    public void setSelectedTabIndicatorGravity(int i2) {
        if (this.z != i2) {
            this.z = i2;
            y.B(this.e);
        }
    }

    @Deprecated
    public void setSelectedTabIndicatorHeight(int i2) {
        this.e.b(i2);
    }

    public void setTabGravity(int i2) {
        if (this.x != i2) {
            this.x = i2;
            e();
        }
    }

    public void setTabIconTint(ColorStateList colorStateList) {
        if (this.l != colorStateList) {
            this.l = colorStateList;
            h();
        }
    }

    public void setTabIconTintResource(int i2) {
        setTabIconTint(a.b.g.b.a.a.a(getContext(), i2));
    }

    public void setTabIndicatorFullWidth(boolean z2) {
        this.C = z2;
        y.B(this.e);
    }

    public void setTabMode(int i2) {
        if (i2 != this.A) {
            this.A = i2;
            e();
        }
    }

    public void setTabRippleColor(ColorStateList colorStateList) {
        if (this.m != colorStateList) {
            this.m = colorStateList;
            for (int i2 = 0; i2 < this.e.getChildCount(); i2++) {
                View childAt = this.e.getChildAt(i2);
                if (childAt instanceof h) {
                    ((h) childAt).a(getContext());
                }
            }
        }
    }

    public void setTabRippleColorResource(int i2) {
        setTabRippleColor(a.b.g.b.a.a.a(getContext(), i2));
    }

    public void setTabTextColors(ColorStateList colorStateList) {
        if (this.k != colorStateList) {
            this.k = colorStateList;
            h();
        }
    }

    @Deprecated
    public void setTabsFromPagerAdapter(t tVar) {
        a(tVar, false);
    }

    public void setUnboundedRipple(boolean z2) {
        if (this.D != z2) {
            this.D = z2;
            for (int i2 = 0; i2 < this.e.getChildCount(); i2++) {
                View childAt = this.e.getChildAt(i2);
                if (childAt instanceof h) {
                    ((h) childAt).a(getContext());
                }
            }
        }
    }

    public void setUnboundedRippleResource(int i2) {
        setUnboundedRipple(getResources().getBoolean(i2));
    }

    public void setupWithViewPager(ViewPager viewPager) {
        a(viewPager, true);
    }

    public boolean shouldDelayChildPressedState() {
        return getTabScrollRange() > 0;
    }
}
