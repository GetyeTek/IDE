package android.support.design.widget;

import android.support.v4.view.C0107d;
import android.support.v4.view.a.c;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

/* renamed from: android.support.design.widget.s  reason: case insensitive filesystem */
class C0071s extends C0107d {

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ CheckableImageButton f582c;

    C0071s(CheckableImageButton checkableImageButton) {
        this.f582c = checkableImageButton;
    }

    public void a(View view, c cVar) {
        super.a(view, cVar);
        cVar.b(true);
        cVar.c(this.f582c.isChecked());
    }

    public void b(View view, AccessibilityEvent accessibilityEvent) {
        super.b(view, accessibilityEvent);
        accessibilityEvent.setChecked(this.f582c.isChecked());
    }
}
