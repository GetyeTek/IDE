package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.design.widget.E;

class C extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ boolean f454a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ E.d f455b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ E f456c;

    C(E e, boolean z, E.d dVar) {
        this.f456c = e;
        this.f454a = z;
        this.f455b = dVar;
    }

    public void onAnimationEnd(Animator animator) {
        E e = this.f456c;
        e.h = 0;
        e.i = null;
        E.d dVar = this.f455b;
        if (dVar != null) {
            dVar.a();
        }
    }

    public void onAnimationStart(Animator animator) {
        this.f456c.B.a(0, this.f454a);
        E e = this.f456c;
        e.h = 2;
        e.i = animator;
    }
}
