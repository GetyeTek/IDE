package android.support.design.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.View;

/* renamed from: android.support.design.widget.x  reason: case insensitive filesystem */
class C0076x extends GradientDrawable {

    /* renamed from: a  reason: collision with root package name */
    private final Paint f587a = new Paint(1);

    /* renamed from: b  reason: collision with root package name */
    private final RectF f588b;

    /* renamed from: c  reason: collision with root package name */
    private int f589c;

    C0076x() {
        c();
        this.f588b = new RectF();
    }

    private void a(Canvas canvas) {
        if (!a(getCallback())) {
            canvas.restoreToCount(this.f589c);
        }
    }

    private boolean a(Drawable.Callback callback) {
        return callback instanceof View;
    }

    private void b(Canvas canvas) {
        Drawable.Callback callback = getCallback();
        if (a(callback)) {
            ((View) callback).setLayerType(2, (Paint) null);
        } else {
            c(canvas);
        }
    }

    private void c() {
        this.f587a.setStyle(Paint.Style.FILL_AND_STROKE);
        this.f587a.setColor(-1);
        this.f587a.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
    }

    private void c(Canvas canvas) {
        int i;
        if (Build.VERSION.SDK_INT >= 21) {
            i = canvas.saveLayer(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight(), (Paint) null);
        } else {
            i = canvas.saveLayer(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight(), (Paint) null, 31);
        }
        this.f589c = i;
    }

    /* access modifiers changed from: package-private */
    public void a(float f, float f2, float f3, float f4) {
        RectF rectF = this.f588b;
        if (f != rectF.left || f2 != rectF.top || f3 != rectF.right || f4 != rectF.bottom) {
            this.f588b.set(f, f2, f3, f4);
            invalidateSelf();
        }
    }

    /* access modifiers changed from: package-private */
    public void a(RectF rectF) {
        a(rectF.left, rectF.top, rectF.right, rectF.bottom);
    }

    /* access modifiers changed from: package-private */
    public boolean a() {
        return !this.f588b.isEmpty();
    }

    /* access modifiers changed from: package-private */
    public void b() {
        a(0.0f, 0.0f, 0.0f, 0.0f);
    }

    public void draw(Canvas canvas) {
        b(canvas);
        super.draw(canvas);
        canvas.drawRect(this.f588b, this.f587a);
        a(canvas);
    }
}
