package android.support.design.widget;

import android.support.design.widget.E;
import android.support.design.widget.FloatingActionButton;

class A implements E.d {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ FloatingActionButton.a f429a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ FloatingActionButton f430b;

    A(FloatingActionButton floatingActionButton, FloatingActionButton.a aVar) {
        this.f430b = floatingActionButton;
        this.f429a = aVar;
    }

    public void a() {
        this.f429a.b(this.f430b);
    }

    public void b() {
        this.f429a.a(this.f430b);
    }
}
