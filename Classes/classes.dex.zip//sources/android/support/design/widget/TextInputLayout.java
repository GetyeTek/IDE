package android.support.design.widget;

import a.b.c.d;
import a.b.c.f;
import a.b.c.h;
import a.b.c.i;
import a.b.c.j;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.internal.k;
import android.support.design.internal.l;
import android.support.v4.view.C0106c;
import android.support.v4.view.C0107d;
import android.support.v4.view.a.c;
import android.support.v4.view.y;
import android.support.v4.widget.r;
import android.support.v7.widget.C0158ha;
import android.support.v7.widget.C0175q;
import android.support.v7.widget.K;
import android.support.v7.widget.ob;
import android.text.Editable;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.view.accessibility.AccessibilityEvent;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TextInputLayout extends LinearLayout {
    private int A;
    private Drawable B;
    private final Rect C;
    private final RectF D;
    private Typeface E;
    private boolean F;
    private Drawable G;
    private CharSequence H;
    private CheckableImageButton I;
    private boolean J;
    private Drawable K;
    private Drawable L;
    private ColorStateList M;
    private boolean N;
    private PorterDuff.Mode O;
    private boolean P;
    private ColorStateList Q;
    private ColorStateList R;
    private final int S;
    private final int T;
    private int U;
    private final int V;
    private boolean W;

    /* renamed from: a  reason: collision with root package name */
    private final FrameLayout f533a;
    final C0073u aa;

    /* renamed from: b  reason: collision with root package name */
    EditText f534b;
    private boolean ba;

    /* renamed from: c  reason: collision with root package name */
    private CharSequence f535c;
    private ValueAnimator ca;
    private final J d;
    private boolean da;
    boolean e;
    private boolean ea;
    private int f;
    /* access modifiers changed from: private */
    public boolean fa;
    private boolean g;
    private TextView h;
    private final int i;
    private final int j;
    private boolean k;
    private CharSequence l;
    private boolean m;
    private GradientDrawable n;
    private final int o;
    private final int p;
    private int q;
    private final int r;
    private float s;
    private float t;
    private float u;
    private float v;
    private int w;
    private final int x;
    private final int y;
    private int z;

    public static class a extends C0107d {

        /* renamed from: c  reason: collision with root package name */
        private final TextInputLayout f536c;

        public a(TextInputLayout textInputLayout) {
            this.f536c = textInputLayout;
        }

        public void a(View view, c cVar) {
            super.a(view, cVar);
            EditText editText = this.f536c.getEditText();
            Editable text = editText != null ? editText.getText() : null;
            CharSequence hint = this.f536c.getHint();
            CharSequence error = this.f536c.getError();
            CharSequence counterOverflowDescription = this.f536c.getCounterOverflowDescription();
            boolean z = !TextUtils.isEmpty(text);
            boolean z2 = !TextUtils.isEmpty(hint);
            boolean z3 = !TextUtils.isEmpty(error);
            boolean z4 = false;
            boolean z5 = z3 || !TextUtils.isEmpty(counterOverflowDescription);
            if (z) {
                cVar.f((CharSequence) text);
            } else if (z2) {
                cVar.f(hint);
            }
            if (z2) {
                cVar.d(hint);
                if (!z && z2) {
                    z4 = true;
                }
                cVar.m(z4);
            }
            if (z5) {
                if (!z3) {
                    error = counterOverflowDescription;
                }
                cVar.c(error);
                cVar.e(true);
            }
        }

        public void c(View view, AccessibilityEvent accessibilityEvent) {
            super.c(view, accessibilityEvent);
            EditText editText = this.f536c.getEditText();
            CharSequence text = editText != null ? editText.getText() : null;
            if (TextUtils.isEmpty(text)) {
                text = this.f536c.getHint();
            }
            if (!TextUtils.isEmpty(text)) {
                accessibilityEvent.getText().add(text);
            }
        }
    }

    static class b extends C0106c {
        public static final Parcelable.Creator<b> CREATOR = new ca();

        /* renamed from: c  reason: collision with root package name */
        CharSequence f537c;
        boolean d;

        b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f537c = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.d = parcel.readInt() != 1 ? false : true;
        }

        b(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "TextInputLayout.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " error=" + this.f537c + "}";
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            TextUtils.writeToParcel(this.f537c, parcel, i);
            parcel.writeInt(this.d ? 1 : 0);
        }
    }

    public TextInputLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public TextInputLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.b.c.b.textInputStyle);
    }

    public TextInputLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.d = new J(this);
        this.C = new Rect();
        this.D = new RectF();
        this.aa = new C0073u(this);
        setOrientation(1);
        setWillNotDraw(false);
        setAddStatesFromChildren(true);
        this.f533a = new FrameLayout(context);
        this.f533a.setAddStatesFromChildren(true);
        addView(this.f533a);
        this.aa.b(a.b.c.a.a.f17a);
        this.aa.a(a.b.c.a.a.f17a);
        this.aa.b(8388659);
        ob b2 = k.b(context, attributeSet, a.b.c.k.TextInputLayout, i2, j.Widget_Design_TextInputLayout, new int[0]);
        this.k = b2.a(a.b.c.k.TextInputLayout_hintEnabled, true);
        setHint(b2.e(a.b.c.k.TextInputLayout_android_hint));
        this.ba = b2.a(a.b.c.k.TextInputLayout_hintAnimationEnabled, true);
        this.o = context.getResources().getDimensionPixelOffset(d.mtrl_textinput_box_bottom_offset);
        this.p = context.getResources().getDimensionPixelOffset(d.mtrl_textinput_box_label_cutout_padding);
        this.r = b2.b(a.b.c.k.TextInputLayout_boxCollapsedPaddingTop, 0);
        this.s = b2.a(a.b.c.k.TextInputLayout_boxCornerRadiusTopStart, 0.0f);
        this.t = b2.a(a.b.c.k.TextInputLayout_boxCornerRadiusTopEnd, 0.0f);
        this.u = b2.a(a.b.c.k.TextInputLayout_boxCornerRadiusBottomEnd, 0.0f);
        this.v = b2.a(a.b.c.k.TextInputLayout_boxCornerRadiusBottomStart, 0.0f);
        this.A = b2.a(a.b.c.k.TextInputLayout_boxBackgroundColor, 0);
        this.U = b2.a(a.b.c.k.TextInputLayout_boxStrokeColor, 0);
        this.x = context.getResources().getDimensionPixelSize(d.mtrl_textinput_box_stroke_width_default);
        this.y = context.getResources().getDimensionPixelSize(d.mtrl_textinput_box_stroke_width_focused);
        this.w = this.x;
        setBoxBackgroundMode(b2.d(a.b.c.k.TextInputLayout_boxBackgroundMode, 0));
        if (b2.g(a.b.c.k.TextInputLayout_android_textColorHint)) {
            ColorStateList a2 = b2.a(a.b.c.k.TextInputLayout_android_textColorHint);
            this.R = a2;
            this.Q = a2;
        }
        this.S = android.support.v4.content.c.a(context, a.b.c.c.mtrl_textinput_default_box_stroke_color);
        this.V = android.support.v4.content.c.a(context, a.b.c.c.mtrl_textinput_disabled_color);
        this.T = android.support.v4.content.c.a(context, a.b.c.c.mtrl_textinput_hovered_box_stroke_color);
        if (b2.g(a.b.c.k.TextInputLayout_hintTextAppearance, -1) != -1) {
            setHintTextAppearance(b2.g(a.b.c.k.TextInputLayout_hintTextAppearance, 0));
        }
        int g2 = b2.g(a.b.c.k.TextInputLayout_errorTextAppearance, 0);
        boolean a3 = b2.a(a.b.c.k.TextInputLayout_errorEnabled, false);
        int g3 = b2.g(a.b.c.k.TextInputLayout_helperTextTextAppearance, 0);
        boolean a4 = b2.a(a.b.c.k.TextInputLayout_helperTextEnabled, false);
        CharSequence e2 = b2.e(a.b.c.k.TextInputLayout_helperText);
        boolean a5 = b2.a(a.b.c.k.TextInputLayout_counterEnabled, false);
        setCounterMaxLength(b2.d(a.b.c.k.TextInputLayout_counterMaxLength, -1));
        this.j = b2.g(a.b.c.k.TextInputLayout_counterTextAppearance, 0);
        this.i = b2.g(a.b.c.k.TextInputLayout_counterOverflowTextAppearance, 0);
        this.F = b2.a(a.b.c.k.TextInputLayout_passwordToggleEnabled, false);
        this.G = b2.b(a.b.c.k.TextInputLayout_passwordToggleDrawable);
        this.H = b2.e(a.b.c.k.TextInputLayout_passwordToggleContentDescription);
        if (b2.g(a.b.c.k.TextInputLayout_passwordToggleTint)) {
            this.N = true;
            this.M = b2.a(a.b.c.k.TextInputLayout_passwordToggleTint);
        }
        if (b2.g(a.b.c.k.TextInputLayout_passwordToggleTintMode)) {
            this.P = true;
            this.O = l.a(b2.d(a.b.c.k.TextInputLayout_passwordToggleTintMode, -1), (PorterDuff.Mode) null);
        }
        b2.a();
        setHelperTextEnabled(a4);
        setHelperText(e2);
        setHelperTextTextAppearance(g3);
        setErrorEnabled(a3);
        setErrorTextAppearance(g2);
        setCounterEnabled(a5);
        f();
        y.d(this, 2);
    }

    private void a(RectF rectF) {
        float f2 = rectF.left;
        int i2 = this.p;
        rectF.left = f2 - ((float) i2);
        rectF.top -= (float) i2;
        rectF.right += (float) i2;
        rectF.bottom += (float) i2;
    }

    private static void a(ViewGroup viewGroup, boolean z2) {
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            childAt.setEnabled(z2);
            if (childAt instanceof ViewGroup) {
                a((ViewGroup) childAt, z2);
            }
        }
    }

    private void a(boolean z2, boolean z3) {
        ColorStateList colorStateList;
        C0073u uVar;
        TextView textView;
        boolean isEnabled = isEnabled();
        EditText editText = this.f534b;
        boolean z4 = true;
        boolean z5 = editText != null && !TextUtils.isEmpty(editText.getText());
        EditText editText2 = this.f534b;
        if (editText2 == null || !editText2.hasFocus()) {
            z4 = false;
        }
        boolean c2 = this.d.c();
        ColorStateList colorStateList2 = this.Q;
        if (colorStateList2 != null) {
            this.aa.a(colorStateList2);
            this.aa.b(this.Q);
        }
        if (!isEnabled) {
            this.aa.a(ColorStateList.valueOf(this.V));
            this.aa.b(ColorStateList.valueOf(this.V));
        } else if (c2) {
            this.aa.a(this.d.f());
        } else {
            if (this.g && (textView = this.h) != null) {
                uVar = this.aa;
                colorStateList = textView.getTextColors();
            } else if (z4 && (colorStateList = this.R) != null) {
                uVar = this.aa;
            }
            uVar.a(colorStateList);
        }
        if (z5 || (isEnabled() && (z4 || c2))) {
            if (z3 || this.W) {
                c(z2);
            }
        } else if (z3 || !this.W) {
            d(z2);
        }
    }

    private void c(boolean z2) {
        ValueAnimator valueAnimator = this.ca;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.ca.cancel();
        }
        if (!z2 || !this.ba) {
            this.aa.b(1.0f);
        } else {
            a(1.0f);
        }
        this.W = false;
        if (l()) {
            p();
        }
    }

    private void d(boolean z2) {
        ValueAnimator valueAnimator = this.ca;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.ca.cancel();
        }
        if (!z2 || !this.ba) {
            this.aa.b(0.0f);
        } else {
            a(0.0f);
        }
        if (l() && ((C0076x) this.n).a()) {
            k();
        }
        this.W = true;
    }

    private void e() {
        int i2;
        Drawable drawable;
        if (this.n != null) {
            q();
            EditText editText = this.f534b;
            if (editText != null && this.q == 2) {
                if (editText.getBackground() != null) {
                    this.B = this.f534b.getBackground();
                }
                y.a((View) this.f534b, (Drawable) null);
            }
            EditText editText2 = this.f534b;
            if (!(editText2 == null || this.q != 1 || (drawable = this.B) == null)) {
                y.a((View) editText2, drawable);
            }
            int i3 = this.w;
            if (i3 > -1 && (i2 = this.z) != 0) {
                this.n.setStroke(i3, i2);
            }
            this.n.setCornerRadii(getCornerRadiiAsArray());
            this.n.setColor(this.A);
            invalidate();
        }
    }

    private void f() {
        Drawable drawable;
        if (this.G == null) {
            return;
        }
        if (this.N || this.P) {
            this.G = android.support.v4.graphics.drawable.a.h(this.G).mutate();
            if (this.N) {
                android.support.v4.graphics.drawable.a.a(this.G, this.M);
            }
            if (this.P) {
                android.support.v4.graphics.drawable.a.a(this.G, this.O);
            }
            CheckableImageButton checkableImageButton = this.I;
            if (checkableImageButton != null && checkableImageButton.getDrawable() != (drawable = this.G)) {
                this.I.setImageDrawable(drawable);
            }
        }
    }

    private void g() {
        GradientDrawable gradientDrawable;
        int i2 = this.q;
        if (i2 == 0) {
            gradientDrawable = null;
        } else if (i2 == 2 && this.k && !(this.n instanceof C0076x)) {
            gradientDrawable = new C0076x();
        } else if (!(this.n instanceof GradientDrawable)) {
            gradientDrawable = new GradientDrawable();
        } else {
            return;
        }
        this.n = gradientDrawable;
    }

    private Drawable getBoxBackground() {
        int i2 = this.q;
        if (i2 == 1 || i2 == 2) {
            return this.n;
        }
        throw new IllegalStateException();
    }

    private float[] getCornerRadiiAsArray() {
        if (!l.a(this)) {
            float f2 = this.s;
            float f3 = this.t;
            float f4 = this.u;
            float f5 = this.v;
            return new float[]{f2, f2, f3, f3, f4, f4, f5, f5};
        }
        float f6 = this.t;
        float f7 = this.s;
        float f8 = this.v;
        float f9 = this.u;
        return new float[]{f6, f6, f7, f7, f8, f8, f9, f9};
    }

    private int h() {
        EditText editText = this.f534b;
        if (editText == null) {
            return 0;
        }
        int i2 = this.q;
        if (i2 == 1) {
            return editText.getTop();
        }
        if (i2 != 2) {
            return 0;
        }
        return editText.getTop() + j();
    }

    private int i() {
        int i2 = this.q;
        return i2 != 1 ? i2 != 2 ? getPaddingTop() : getBoxBackground().getBounds().top - j() : getBoxBackground().getBounds().top + this.r;
    }

    private int j() {
        float c2;
        if (!this.k) {
            return 0;
        }
        int i2 = this.q;
        if (i2 == 0 || i2 == 1) {
            c2 = this.aa.c();
        } else if (i2 != 2) {
            return 0;
        } else {
            c2 = this.aa.c() / 2.0f;
        }
        return (int) c2;
    }

    private void k() {
        if (l()) {
            ((C0076x) this.n).b();
        }
    }

    private boolean l() {
        return this.k && !TextUtils.isEmpty(this.l) && (this.n instanceof C0076x);
    }

    private void m() {
        Drawable background;
        int i2 = Build.VERSION.SDK_INT;
        if ((i2 == 21 || i2 == 22) && (background = this.f534b.getBackground()) != null && !this.da) {
            Drawable newDrawable = background.getConstantState().newDrawable();
            if (background instanceof DrawableContainer) {
                this.da = C0078z.a((DrawableContainer) background, newDrawable.getConstantState());
            }
            if (!this.da) {
                y.a((View) this.f534b, newDrawable);
                this.da = true;
                o();
            }
        }
    }

    private boolean n() {
        EditText editText = this.f534b;
        return editText != null && (editText.getTransformationMethod() instanceof PasswordTransformationMethod);
    }

    private void o() {
        g();
        if (this.q != 0) {
            t();
        }
        v();
    }

    private void p() {
        if (l()) {
            RectF rectF = this.D;
            this.aa.a(rectF);
            a(rectF);
            ((C0076x) this.n).a(rectF);
        }
    }

    private void q() {
        int i2 = this.q;
        if (i2 == 1) {
            this.w = 0;
        } else if (i2 == 2 && this.U == 0) {
            this.U = this.R.getColorForState(getDrawableState(), this.R.getDefaultColor());
        }
    }

    private boolean r() {
        return this.F && (n() || this.J);
    }

    private void s() {
        Drawable background;
        EditText editText = this.f534b;
        if (editText != null && (background = editText.getBackground()) != null) {
            if (C0158ha.a(background)) {
                background = background.mutate();
            }
            C0077y.a((ViewGroup) this, (View) this.f534b, new Rect());
            Rect bounds = background.getBounds();
            if (bounds.left != bounds.right) {
                Rect rect = new Rect();
                background.getPadding(rect);
                background.setBounds(bounds.left - rect.left, bounds.top, bounds.right + (rect.right * 2), this.f534b.getBottom());
            }
        }
    }

    private void setEditText(EditText editText) {
        if (this.f534b == null) {
            if (!(editText instanceof TextInputEditText)) {
                Log.i("TextInputLayout", "EditText added is not a TextInputEditText. Please switch to using that class instead.");
            }
            this.f534b = editText;
            o();
            setTextInputAccessibilityDelegate(new a(this));
            if (!n()) {
                this.aa.a(this.f534b.getTypeface());
            }
            this.aa.a(this.f534b.getTextSize());
            int gravity = this.f534b.getGravity();
            this.aa.b((gravity & -113) | 48);
            this.aa.c(gravity);
            this.f534b.addTextChangedListener(new Z(this));
            if (this.Q == null) {
                this.Q = this.f534b.getHintTextColors();
            }
            if (this.k) {
                if (TextUtils.isEmpty(this.l)) {
                    this.f535c = this.f534b.getHint();
                    setHint(this.f535c);
                    this.f534b.setHint((CharSequence) null);
                }
                this.m = true;
            }
            if (this.h != null) {
                a(this.f534b.getText().length());
            }
            this.d.a();
            u();
            a(false, true);
            return;
        }
        throw new IllegalArgumentException("We already have an EditText, can only have one");
    }

    private void setHintInternal(CharSequence charSequence) {
        if (!TextUtils.equals(charSequence, this.l)) {
            this.l = charSequence;
            this.aa.a(charSequence);
            if (!this.W) {
                p();
            }
        }
    }

    private void t() {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f533a.getLayoutParams();
        int j2 = j();
        if (j2 != layoutParams.topMargin) {
            layoutParams.topMargin = j2;
            this.f533a.requestLayout();
        }
    }

    private void u() {
        if (this.f534b != null) {
            if (r()) {
                if (this.I == null) {
                    this.I = (CheckableImageButton) LayoutInflater.from(getContext()).inflate(h.design_text_input_password_icon, this.f533a, false);
                    this.I.setImageDrawable(this.G);
                    this.I.setContentDescription(this.H);
                    this.f533a.addView(this.I);
                    this.I.setOnClickListener(new aa(this));
                }
                EditText editText = this.f534b;
                if (editText != null && y.l(editText) <= 0) {
                    this.f534b.setMinimumHeight(y.l(this.I));
                }
                this.I.setVisibility(0);
                this.I.setChecked(this.J);
                if (this.K == null) {
                    this.K = new ColorDrawable();
                }
                this.K.setBounds(0, 0, this.I.getMeasuredWidth(), 1);
                Drawable[] a2 = r.a((TextView) this.f534b);
                if (a2[2] != this.K) {
                    this.L = a2[2];
                }
                r.a(this.f534b, a2[0], a2[1], this.K, a2[3]);
                this.I.setPadding(this.f534b.getPaddingLeft(), this.f534b.getPaddingTop(), this.f534b.getPaddingRight(), this.f534b.getPaddingBottom());
                return;
            }
            CheckableImageButton checkableImageButton = this.I;
            if (checkableImageButton != null && checkableImageButton.getVisibility() == 0) {
                this.I.setVisibility(8);
            }
            if (this.K != null) {
                Drawable[] a3 = r.a((TextView) this.f534b);
                if (a3[2] == this.K) {
                    r.a(this.f534b, a3[0], a3[1], this.L, a3[3]);
                    this.K = null;
                }
            }
        }
    }

    private void v() {
        if (this.q != 0 && this.n != null && this.f534b != null && getRight() != 0) {
            int left = this.f534b.getLeft();
            int h2 = h();
            int right = this.f534b.getRight();
            int bottom = this.f534b.getBottom() + this.o;
            if (this.q == 2) {
                int i2 = this.y;
                left += i2 / 2;
                h2 -= i2 / 2;
                right -= i2 / 2;
                bottom += i2 / 2;
            }
            this.n.setBounds(left, h2, right, bottom);
            e();
            s();
        }
    }

    /* access modifiers changed from: package-private */
    public void a(float f2) {
        if (this.aa.e() != f2) {
            if (this.ca == null) {
                this.ca = new ValueAnimator();
                this.ca.setInterpolator(a.b.c.a.a.f18b);
                this.ca.setDuration(167);
                this.ca.addUpdateListener(new ba(this));
            }
            this.ca.setFloatValues(new float[]{this.aa.e(), f2});
            this.ca.start();
        }
    }

    /* access modifiers changed from: package-private */
    public void a(int i2) {
        boolean z2 = this.g;
        if (this.f == -1) {
            this.h.setText(String.valueOf(i2));
            this.h.setContentDescription((CharSequence) null);
            this.g = false;
        } else {
            if (y.b(this.h) == 1) {
                y.c(this.h, 0);
            }
            this.g = i2 > this.f;
            boolean z3 = this.g;
            if (z2 != z3) {
                a(this.h, z3 ? this.i : this.j);
                if (this.g) {
                    y.c(this.h, 1);
                }
            }
            this.h.setText(getContext().getString(i.character_counter_pattern, new Object[]{Integer.valueOf(i2), Integer.valueOf(this.f)}));
            this.h.setContentDescription(getContext().getString(i.character_counter_content_description, new Object[]{Integer.valueOf(i2), Integer.valueOf(this.f)}));
        }
        if (this.f534b != null && z2 != this.g) {
            b(false);
            d();
            c();
        }
    }

    /* access modifiers changed from: package-private */
    public void a(TextView textView, int i2) {
        boolean z2 = true;
        try {
            r.d(textView, i2);
            if (Build.VERSION.SDK_INT < 23 || textView.getTextColors().getDefaultColor() != -65281) {
                z2 = false;
            }
        } catch (Exception unused) {
        }
        if (z2) {
            r.d(textView, j.TextAppearance_AppCompat_Caption);
            textView.setTextColor(android.support.v4.content.c.a(getContext(), a.b.c.c.design_error));
        }
    }

    public void a(boolean z2) {
        boolean z3;
        if (this.F) {
            int selectionEnd = this.f534b.getSelectionEnd();
            if (n()) {
                this.f534b.setTransformationMethod((TransformationMethod) null);
                z3 = true;
            } else {
                this.f534b.setTransformationMethod(PasswordTransformationMethod.getInstance());
                z3 = false;
            }
            this.J = z3;
            this.I.setChecked(this.J);
            if (z2) {
                this.I.jumpDrawablesToCurrentState();
            }
            this.f534b.setSelection(selectionEnd);
        }
    }

    public boolean a() {
        return this.d.l();
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof EditText) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams);
            layoutParams2.gravity = (layoutParams2.gravity & -113) | 16;
            this.f533a.addView(view, layoutParams2);
            this.f533a.setLayoutParams(layoutParams);
            t();
            setEditText((EditText) view);
            return;
        }
        super.addView(view, i2, layoutParams);
    }

    /* access modifiers changed from: package-private */
    public void b(boolean z2) {
        a(z2, false);
    }

    /* access modifiers changed from: package-private */
    public boolean b() {
        return this.m;
    }

    /* access modifiers changed from: package-private */
    public void c() {
        Drawable background;
        TextView textView;
        int currentTextColor;
        EditText editText = this.f534b;
        if (editText != null && (background = editText.getBackground()) != null) {
            m();
            if (C0158ha.a(background)) {
                background = background.mutate();
            }
            if (this.d.c()) {
                currentTextColor = this.d.e();
            } else if (!this.g || (textView = this.h) == null) {
                android.support.v4.graphics.drawable.a.b(background);
                this.f534b.refreshDrawableState();
                return;
            } else {
                currentTextColor = textView.getCurrentTextColor();
            }
            background.setColorFilter(C0175q.a(currentTextColor, PorterDuff.Mode.SRC_IN));
        }
    }

    /* access modifiers changed from: package-private */
    public void d() {
        TextView textView;
        if (this.n != null && this.q != 0) {
            EditText editText = this.f534b;
            boolean z2 = true;
            boolean z3 = editText != null && editText.hasFocus();
            EditText editText2 = this.f534b;
            if (editText2 == null || !editText2.isHovered()) {
                z2 = false;
            }
            if (this.q == 2) {
                this.z = !isEnabled() ? this.V : this.d.c() ? this.d.e() : (!this.g || (textView = this.h) == null) ? z3 ? this.U : z2 ? this.T : this.S : textView.getCurrentTextColor();
                this.w = ((z2 || z3) && isEnabled()) ? this.y : this.x;
                e();
            }
        }
    }

    public void dispatchProvideAutofillStructure(ViewStructure viewStructure, int i2) {
        EditText editText;
        if (this.f535c == null || (editText = this.f534b) == null) {
            super.dispatchProvideAutofillStructure(viewStructure, i2);
            return;
        }
        boolean z2 = this.m;
        this.m = false;
        CharSequence hint = editText.getHint();
        this.f534b.setHint(this.f535c);
        try {
            super.dispatchProvideAutofillStructure(viewStructure, i2);
        } finally {
            this.f534b.setHint(hint);
            this.m = z2;
        }
    }

    /* access modifiers changed from: protected */
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        this.fa = true;
        super.dispatchRestoreInstanceState(sparseArray);
        this.fa = false;
    }

    public void draw(Canvas canvas) {
        GradientDrawable gradientDrawable = this.n;
        if (gradientDrawable != null) {
            gradientDrawable.draw(canvas);
        }
        super.draw(canvas);
        if (this.k) {
            this.aa.a(canvas);
        }
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        if (!this.ea) {
            boolean z2 = true;
            this.ea = true;
            super.drawableStateChanged();
            int[] drawableState = getDrawableState();
            if (!y.y(this) || !isEnabled()) {
                z2 = false;
            }
            b(z2);
            c();
            v();
            d();
            C0073u uVar = this.aa;
            if (uVar != null ? uVar.a(drawableState) | false : false) {
                invalidate();
            }
            this.ea = false;
        }
    }

    public int getBoxBackgroundColor() {
        return this.A;
    }

    public float getBoxCornerRadiusBottomEnd() {
        return this.u;
    }

    public float getBoxCornerRadiusBottomStart() {
        return this.v;
    }

    public float getBoxCornerRadiusTopEnd() {
        return this.t;
    }

    public float getBoxCornerRadiusTopStart() {
        return this.s;
    }

    public int getBoxStrokeColor() {
        return this.U;
    }

    public int getCounterMaxLength() {
        return this.f;
    }

    /* access modifiers changed from: package-private */
    public CharSequence getCounterOverflowDescription() {
        TextView textView;
        if (!this.e || !this.g || (textView = this.h) == null) {
            return null;
        }
        return textView.getContentDescription();
    }

    public ColorStateList getDefaultHintTextColor() {
        return this.Q;
    }

    public EditText getEditText() {
        return this.f534b;
    }

    public CharSequence getError() {
        if (this.d.k()) {
            return this.d.d();
        }
        return null;
    }

    public int getErrorCurrentTextColors() {
        return this.d.e();
    }

    /* access modifiers changed from: package-private */
    public final int getErrorTextCurrentColor() {
        return this.d.e();
    }

    public CharSequence getHelperText() {
        if (this.d.l()) {
            return this.d.g();
        }
        return null;
    }

    public int getHelperTextCurrentTextColor() {
        return this.d.h();
    }

    public CharSequence getHint() {
        if (this.k) {
            return this.l;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public final float getHintCollapsedTextHeight() {
        return this.aa.c();
    }

    /* access modifiers changed from: package-private */
    public final int getHintCurrentCollapsedTextColor() {
        return this.aa.d();
    }

    public CharSequence getPasswordVisibilityToggleContentDescription() {
        return this.H;
    }

    public Drawable getPasswordVisibilityToggleDrawable() {
        return this.G;
    }

    public Typeface getTypeface() {
        return this.E;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        EditText editText;
        super.onLayout(z2, i2, i3, i4, i5);
        if (this.n != null) {
            v();
        }
        if (this.k && (editText = this.f534b) != null) {
            Rect rect = this.C;
            C0077y.a((ViewGroup) this, (View) editText, rect);
            int compoundPaddingLeft = rect.left + this.f534b.getCompoundPaddingLeft();
            int compoundPaddingRight = rect.right - this.f534b.getCompoundPaddingRight();
            int i6 = i();
            this.aa.b(compoundPaddingLeft, rect.top + this.f534b.getCompoundPaddingTop(), compoundPaddingRight, rect.bottom - this.f534b.getCompoundPaddingBottom());
            this.aa.a(compoundPaddingLeft, i6, compoundPaddingRight, (i5 - i3) - getPaddingBottom());
            this.aa.h();
            if (l() && !this.W) {
                p();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        u();
        super.onMeasure(i2, i3);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        b bVar = (b) parcelable;
        super.onRestoreInstanceState(bVar.a());
        setError(bVar.f537c);
        if (bVar.d) {
            a(true);
        }
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        b bVar = new b(super.onSaveInstanceState());
        if (this.d.c()) {
            bVar.f537c = getError();
        }
        bVar.d = this.J;
        return bVar;
    }

    public void setBoxBackgroundColor(int i2) {
        if (this.A != i2) {
            this.A = i2;
            e();
        }
    }

    public void setBoxBackgroundColorResource(int i2) {
        setBoxBackgroundColor(android.support.v4.content.c.a(getContext(), i2));
    }

    public void setBoxBackgroundMode(int i2) {
        if (i2 != this.q) {
            this.q = i2;
            o();
        }
    }

    public void setBoxStrokeColor(int i2) {
        if (this.U != i2) {
            this.U = i2;
            d();
        }
    }

    public void setCounterEnabled(boolean z2) {
        if (this.e != z2) {
            if (z2) {
                this.h = new K(getContext());
                this.h.setId(f.textinput_counter);
                Typeface typeface = this.E;
                if (typeface != null) {
                    this.h.setTypeface(typeface);
                }
                this.h.setMaxLines(1);
                a(this.h, this.j);
                this.d.a(this.h, 2);
                EditText editText = this.f534b;
                a(editText == null ? 0 : editText.getText().length());
            } else {
                this.d.b(this.h, 2);
                this.h = null;
            }
            this.e = z2;
        }
    }

    public void setCounterMaxLength(int i2) {
        if (this.f != i2) {
            if (i2 <= 0) {
                i2 = -1;
            }
            this.f = i2;
            if (this.e) {
                EditText editText = this.f534b;
                a(editText == null ? 0 : editText.getText().length());
            }
        }
    }

    public void setDefaultHintTextColor(ColorStateList colorStateList) {
        this.Q = colorStateList;
        this.R = colorStateList;
        if (this.f534b != null) {
            b(false);
        }
    }

    public void setEnabled(boolean z2) {
        a((ViewGroup) this, z2);
        super.setEnabled(z2);
    }

    public void setError(CharSequence charSequence) {
        if (!this.d.k()) {
            if (!TextUtils.isEmpty(charSequence)) {
                setErrorEnabled(true);
            } else {
                return;
            }
        }
        if (!TextUtils.isEmpty(charSequence)) {
            this.d.a(charSequence);
        } else {
            this.d.i();
        }
    }

    public void setErrorEnabled(boolean z2) {
        this.d.a(z2);
    }

    public void setErrorTextAppearance(int i2) {
        this.d.b(i2);
    }

    public void setErrorTextColor(ColorStateList colorStateList) {
        this.d.a(colorStateList);
    }

    public void setHelperText(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (!a()) {
                setHelperTextEnabled(true);
            }
            this.d.b(charSequence);
        } else if (a()) {
            setHelperTextEnabled(false);
        }
    }

    public void setHelperTextColor(ColorStateList colorStateList) {
        this.d.b(colorStateList);
    }

    public void setHelperTextEnabled(boolean z2) {
        this.d.b(z2);
    }

    public void setHelperTextTextAppearance(int i2) {
        this.d.c(i2);
    }

    public void setHint(CharSequence charSequence) {
        if (this.k) {
            setHintInternal(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    public void setHintAnimationEnabled(boolean z2) {
        this.ba = z2;
    }

    public void setHintEnabled(boolean z2) {
        if (z2 != this.k) {
            this.k = z2;
            if (!this.k) {
                this.m = false;
                if (!TextUtils.isEmpty(this.l) && TextUtils.isEmpty(this.f534b.getHint())) {
                    this.f534b.setHint(this.l);
                }
                setHintInternal((CharSequence) null);
            } else {
                CharSequence hint = this.f534b.getHint();
                if (!TextUtils.isEmpty(hint)) {
                    if (TextUtils.isEmpty(this.l)) {
                        setHint(hint);
                    }
                    this.f534b.setHint((CharSequence) null);
                }
                this.m = true;
            }
            if (this.f534b != null) {
                t();
            }
        }
    }

    public void setHintTextAppearance(int i2) {
        this.aa.a(i2);
        this.R = this.aa.b();
        if (this.f534b != null) {
            b(false);
            t();
        }
    }

    public void setPasswordVisibilityToggleContentDescription(int i2) {
        setPasswordVisibilityToggleContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setPasswordVisibilityToggleContentDescription(CharSequence charSequence) {
        this.H = charSequence;
        CheckableImageButton checkableImageButton = this.I;
        if (checkableImageButton != null) {
            checkableImageButton.setContentDescription(charSequence);
        }
    }

    public void setPasswordVisibilityToggleDrawable(int i2) {
        setPasswordVisibilityToggleDrawable(i2 != 0 ? a.b.g.b.a.a.b(getContext(), i2) : null);
    }

    public void setPasswordVisibilityToggleDrawable(Drawable drawable) {
        this.G = drawable;
        CheckableImageButton checkableImageButton = this.I;
        if (checkableImageButton != null) {
            checkableImageButton.setImageDrawable(drawable);
        }
    }

    public void setPasswordVisibilityToggleEnabled(boolean z2) {
        EditText editText;
        if (this.F != z2) {
            this.F = z2;
            if (!z2 && this.J && (editText = this.f534b) != null) {
                editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
            this.J = false;
            u();
        }
    }

    public void setPasswordVisibilityToggleTintList(ColorStateList colorStateList) {
        this.M = colorStateList;
        this.N = true;
        f();
    }

    public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode mode) {
        this.O = mode;
        this.P = true;
        f();
    }

    public void setTextInputAccessibilityDelegate(a aVar) {
        EditText editText = this.f534b;
        if (editText != null) {
            y.a((View) editText, (C0107d) aVar);
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != this.E) {
            this.E = typeface;
            this.aa.a(typeface);
            this.d.a(typeface);
            TextView textView = this.h;
            if (textView != null) {
                textView.setTypeface(typeface);
            }
        }
    }
}
