package android.support.design.widget;

import android.support.design.widget.BaseTransientBottomBar;
import android.view.View;

/* renamed from: android.support.design.widget.m  reason: case insensitive filesystem */
class C0066m implements BaseTransientBottomBar.d {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f575a;

    C0066m(BaseTransientBottomBar baseTransientBottomBar) {
        this.f575a = baseTransientBottomBar;
    }

    public void a(View view, int i, int i2, int i3, int i4) {
        this.f575a.f.setOnLayoutChangeListener((BaseTransientBottomBar.d) null);
        if (this.f575a.j()) {
            this.f575a.b();
        } else {
            this.f575a.i();
        }
    }
}
