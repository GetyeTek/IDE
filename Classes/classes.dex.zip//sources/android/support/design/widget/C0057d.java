package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: android.support.design.widget.d  reason: case insensitive filesystem */
class C0057d extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ int f557a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f558b;

    C0057d(BaseTransientBottomBar baseTransientBottomBar, int i) {
        this.f558b = baseTransientBottomBar;
        this.f557a = i;
    }

    public void onAnimationEnd(Animator animator) {
        this.f558b.c(this.f557a);
    }

    public void onAnimationStart(Animator animator) {
        this.f558b.g.b(0, 180);
    }
}
