package android.support.design.widget;

import android.os.Handler;
import android.os.Message;
import android.support.design.widget.Q;

class P implements Handler.Callback {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ Q f492a;

    P(Q q) {
        this.f492a = q;
    }

    public boolean handleMessage(Message message) {
        if (message.what != 0) {
            return false;
        }
        this.f492a.a((Q.b) message.obj);
        return true;
    }
}
