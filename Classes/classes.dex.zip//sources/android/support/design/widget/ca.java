package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.widget.TextInputLayout;

class ca implements Parcelable.ClassLoaderCreator<TextInputLayout.b> {
    ca() {
    }

    public TextInputLayout.b createFromParcel(Parcel parcel) {
        return new TextInputLayout.b(parcel, (ClassLoader) null);
    }

    public TextInputLayout.b createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new TextInputLayout.b(parcel, classLoader);
    }

    public TextInputLayout.b[] newArray(int i) {
        return new TextInputLayout.b[i];
    }
}
