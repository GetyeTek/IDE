package android.support.design.widget;

import android.text.Editable;
import android.text.TextWatcher;

class Z implements TextWatcher {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ TextInputLayout f550a;

    Z(TextInputLayout textInputLayout) {
        this.f550a = textInputLayout;
    }

    public void afterTextChanged(Editable editable) {
        TextInputLayout textInputLayout = this.f550a;
        textInputLayout.b(!textInputLayout.fa);
        TextInputLayout textInputLayout2 = this.f550a;
        if (textInputLayout2.e) {
            textInputLayout2.a(editable.length());
        }
    }

    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }
}
