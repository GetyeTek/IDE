package android.support.design.widget;

import android.support.design.widget.NavigationView;
import android.support.v7.view.menu.l;
import android.view.MenuItem;

class L implements l.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ NavigationView f489a;

    L(NavigationView navigationView) {
        this.f489a = navigationView;
    }

    public void a(l lVar) {
    }

    public boolean a(l lVar, MenuItem menuItem) {
        NavigationView.a aVar = this.f489a.h;
        return aVar != null && aVar.a(menuItem);
    }
}
