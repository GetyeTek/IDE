package android.support.design.widget;

import a.b.c.a.a;
import android.animation.ValueAnimator;
import android.support.design.widget.TabLayout;

class X implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ int f545a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ int f546b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ int f547c;
    final /* synthetic */ int d;
    final /* synthetic */ TabLayout.e e;

    X(TabLayout.e eVar, int i, int i2, int i3, int i4) {
        this.e = eVar;
        this.f545a = i;
        this.f546b = i2;
        this.f547c = i3;
        this.d = i4;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        float animatedFraction = valueAnimator.getAnimatedFraction();
        this.e.b(a.a(this.f545a, this.f546b, animatedFraction), a.a(this.f547c, this.d, animatedFraction));
    }
}
