package android.support.design.widget;

import android.support.v4.view.N;
import android.support.v4.view.s;
import android.view.View;

/* renamed from: android.support.design.widget.v  reason: case insensitive filesystem */
class C0074v implements s {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ CoordinatorLayout f586a;

    C0074v(CoordinatorLayout coordinatorLayout) {
        this.f586a = coordinatorLayout;
    }

    public N a(View view, N n) {
        return this.f586a.a(n);
    }
}
