package android.support.design.widget;

import android.os.Handler;
import android.support.design.widget.Q;

/* renamed from: android.support.design.widget.i  reason: case insensitive filesystem */
class C0062i implements Q.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f571a;

    C0062i(BaseTransientBottomBar baseTransientBottomBar) {
        this.f571a = baseTransientBottomBar;
    }

    public void a(int i) {
        Handler handler = BaseTransientBottomBar.f440a;
        handler.sendMessage(handler.obtainMessage(1, i, 0, this.f571a));
    }

    public void c() {
        Handler handler = BaseTransientBottomBar.f440a;
        handler.sendMessage(handler.obtainMessage(0, this.f571a));
    }
}
