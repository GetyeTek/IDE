package android.support.design.widget;

import android.animation.ValueAnimator;

class ba implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ TextInputLayout f556a;

    ba(TextInputLayout textInputLayout) {
        this.f556a = textInputLayout;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f556a.aa.b(((Float) valueAnimator.getAnimatedValue()).floatValue());
    }
}
