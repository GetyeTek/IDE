package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.design.widget.E;

class B extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    private boolean f437a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ boolean f438b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ E.d f439c;
    final /* synthetic */ E d;

    B(E e, boolean z, E.d dVar) {
        this.d = e;
        this.f438b = z;
        this.f439c = dVar;
    }

    public void onAnimationCancel(Animator animator) {
        this.f437a = true;
    }

    public void onAnimationEnd(Animator animator) {
        E e = this.d;
        e.h = 0;
        e.i = null;
        if (!this.f437a) {
            e.B.a(this.f438b ? 8 : 4, this.f438b);
            E.d dVar = this.f439c;
            if (dVar != null) {
                dVar.b();
            }
        }
    }

    public void onAnimationStart(Animator animator) {
        this.d.B.a(0, this.f438b);
        E e = this.d;
        e.h = 1;
        e.i = animator;
        this.f437a = false;
    }
}
