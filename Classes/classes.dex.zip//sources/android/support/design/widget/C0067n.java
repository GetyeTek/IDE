package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: android.support.design.widget.n  reason: case insensitive filesystem */
class C0067n extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f576a;

    C0067n(BaseTransientBottomBar baseTransientBottomBar) {
        this.f576a = baseTransientBottomBar;
    }

    public void onAnimationEnd(Animator animator) {
        this.f576a.i();
    }

    public void onAnimationStart(Animator animator) {
        this.f576a.g.a(70, 180);
    }
}
