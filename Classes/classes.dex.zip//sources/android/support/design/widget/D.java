package android.support.design.widget;

import android.view.ViewTreeObserver;

class D implements ViewTreeObserver.OnPreDrawListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ E f467a;

    D(E e) {
        this.f467a = e;
    }

    public boolean onPreDraw() {
        this.f467a.m();
        return true;
    }
}
