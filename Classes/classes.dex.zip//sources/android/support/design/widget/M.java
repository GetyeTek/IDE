package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.widget.NavigationView;

class M implements Parcelable.ClassLoaderCreator<NavigationView.b> {
    M() {
    }

    public NavigationView.b createFromParcel(Parcel parcel) {
        return new NavigationView.b(parcel, (ClassLoader) null);
    }

    public NavigationView.b createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new NavigationView.b(parcel, classLoader);
    }

    public NavigationView.b[] newArray(int i) {
        return new NavigationView.b[i];
    }
}
