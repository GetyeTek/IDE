package android.support.design.widget;

import android.graphics.drawable.Drawable;

public interface O {
    void a(int i, int i2, int i3, int i4);

    void a(Drawable drawable);

    boolean a();

    float b();
}
