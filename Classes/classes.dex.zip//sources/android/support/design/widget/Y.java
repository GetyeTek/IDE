package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.design.widget.TabLayout;

class Y extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ int f548a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ TabLayout.e f549b;

    Y(TabLayout.e eVar, int i) {
        this.f549b = eVar;
        this.f548a = i;
    }

    public void onAnimationEnd(Animator animator) {
        TabLayout.e eVar = this.f549b;
        eVar.d = this.f548a;
        eVar.e = 0.0f;
    }
}
