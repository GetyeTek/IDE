package android.support.design.widget;

import android.widget.ImageButton;

public class ga extends ImageButton {

    /* renamed from: a  reason: collision with root package name */
    private int f569a;

    public final void a(int i, boolean z) {
        super.setVisibility(i);
        if (z) {
            this.f569a = i;
        }
    }

    public final int getUserSetVisibility() {
        return this.f569a;
    }

    public void setVisibility(int i) {
        a(i, true);
    }
}
