package android.support.design.widget;

import a.b.f.c.a;
import android.support.v4.widget.w;
import android.view.View;

/* renamed from: android.support.design.widget.q  reason: case insensitive filesystem */
class C0070q extends w.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BottomSheetBehavior f581a;

    C0070q(BottomSheetBehavior bottomSheetBehavior) {
        this.f581a = bottomSheetBehavior;
    }

    public int a(View view, int i, int i2) {
        return view.getLeft();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00a2, code lost:
        if (r9 < java.lang.Math.abs(r9 - r10.i)) goto L_0x0026;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x00b4, code lost:
        if (java.lang.Math.abs(r9 - r1) < java.lang.Math.abs(r9 - r7.f581a.i)) goto L_0x00b6;
     */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00cb  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00dc  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(android.view.View r8, float r9, float r10) {
        /*
            r7 = this;
            r0 = 0
            r1 = 0
            r2 = 4
            r3 = 6
            r4 = 3
            int r5 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r5 >= 0) goto L_0x0028
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            boolean r9 = r9.f447a
            if (r9 == 0) goto L_0x0018
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            int r9 = r9.g
        L_0x0015:
            r2 = 3
            goto L_0x00bd
        L_0x0018:
            int r9 = r8.getTop()
            android.support.design.widget.BottomSheetBehavior r10 = r7.f581a
            int r10 = r10.h
            if (r9 <= r10) goto L_0x0026
            r9 = r10
        L_0x0023:
            r2 = 6
            goto L_0x00bd
        L_0x0026:
            r9 = 0
            goto L_0x0015
        L_0x0028:
            android.support.design.widget.BottomSheetBehavior r5 = r7.f581a
            boolean r6 = r5.j
            if (r6 == 0) goto L_0x0051
            boolean r5 = r5.a(r8, r10)
            if (r5 == 0) goto L_0x0051
            int r5 = r8.getTop()
            android.support.design.widget.BottomSheetBehavior r6 = r7.f581a
            int r6 = r6.i
            if (r5 > r6) goto L_0x004a
            float r5 = java.lang.Math.abs(r9)
            float r6 = java.lang.Math.abs(r10)
            int r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
            if (r5 >= 0) goto L_0x0051
        L_0x004a:
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            int r9 = r9.q
            r2 = 5
            goto L_0x00bd
        L_0x0051:
            int r1 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r1 == 0) goto L_0x0067
            float r9 = java.lang.Math.abs(r9)
            float r10 = java.lang.Math.abs(r10)
            int r9 = (r9 > r10 ? 1 : (r9 == r10 ? 0 : -1))
            if (r9 <= 0) goto L_0x0062
            goto L_0x0067
        L_0x0062:
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            int r9 = r9.i
            goto L_0x00bd
        L_0x0067:
            int r9 = r8.getTop()
            android.support.design.widget.BottomSheetBehavior r10 = r7.f581a
            boolean r10 = r10.f447a
            if (r10 == 0) goto L_0x0094
            android.support.design.widget.BottomSheetBehavior r10 = r7.f581a
            int r10 = r10.g
            int r10 = r9 - r10
            int r10 = java.lang.Math.abs(r10)
            android.support.design.widget.BottomSheetBehavior r0 = r7.f581a
            int r0 = r0.i
            int r9 = r9 - r0
            int r9 = java.lang.Math.abs(r9)
            if (r10 >= r9) goto L_0x008e
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            int r0 = r9.g
            r9 = r0
            goto L_0x0015
        L_0x008e:
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            int r0 = r9.i
            r9 = r0
            goto L_0x00bd
        L_0x0094:
            android.support.design.widget.BottomSheetBehavior r10 = r7.f581a
            int r1 = r10.h
            if (r9 >= r1) goto L_0x00a5
            int r10 = r10.i
            int r10 = r9 - r10
            int r10 = java.lang.Math.abs(r10)
            if (r9 >= r10) goto L_0x00b6
            goto L_0x0026
        L_0x00a5:
            int r10 = r9 - r1
            int r10 = java.lang.Math.abs(r10)
            android.support.design.widget.BottomSheetBehavior r0 = r7.f581a
            int r0 = r0.i
            int r9 = r9 - r0
            int r9 = java.lang.Math.abs(r9)
            if (r10 >= r9) goto L_0x008e
        L_0x00b6:
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            int r0 = r9.h
            r9 = r0
            goto L_0x0023
        L_0x00bd:
            android.support.design.widget.BottomSheetBehavior r10 = r7.f581a
            android.support.v4.widget.w r10 = r10.m
            int r0 = r8.getLeft()
            boolean r9 = r10.d(r0, r9)
            if (r9 == 0) goto L_0x00dc
            android.support.design.widget.BottomSheetBehavior r9 = r7.f581a
            r10 = 2
            r9.c((int) r10)
            android.support.design.widget.BottomSheetBehavior$c r9 = new android.support.design.widget.BottomSheetBehavior$c
            android.support.design.widget.BottomSheetBehavior r10 = r7.f581a
            r9.<init>(r8, r2)
            android.support.v4.view.y.a((android.view.View) r8, (java.lang.Runnable) r9)
            goto L_0x00e1
        L_0x00dc:
            android.support.design.widget.BottomSheetBehavior r8 = r7.f581a
            r8.c((int) r2)
        L_0x00e1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.C0070q.a(android.view.View, float, float):void");
    }

    public void a(View view, int i, int i2, int i3, int i4) {
        this.f581a.a(i2);
    }

    public int b(View view) {
        BottomSheetBehavior bottomSheetBehavior = this.f581a;
        return bottomSheetBehavior.j ? bottomSheetBehavior.q : bottomSheetBehavior.i;
    }

    public int b(View view, int i, int i2) {
        int b2 = this.f581a.c();
        BottomSheetBehavior bottomSheetBehavior = this.f581a;
        return a.a(i, b2, bottomSheetBehavior.j ? bottomSheetBehavior.q : bottomSheetBehavior.i);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0015, code lost:
        r7 = (android.view.View) r0.s.get();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0027, code lost:
        r7 = r5.f581a.r;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean b(android.view.View r6, int r7) {
        /*
            r5 = this;
            android.support.design.widget.BottomSheetBehavior r0 = r5.f581a
            int r1 = r0.l
            r2 = 1
            r3 = 0
            if (r1 != r2) goto L_0x0009
            return r3
        L_0x0009:
            boolean r4 = r0.x
            if (r4 == 0) goto L_0x000e
            return r3
        L_0x000e:
            r4 = 3
            if (r1 != r4) goto L_0x0027
            int r1 = r0.v
            if (r1 != r7) goto L_0x0027
            java.lang.ref.WeakReference<android.view.View> r7 = r0.s
            java.lang.Object r7 = r7.get()
            android.view.View r7 = (android.view.View) r7
            if (r7 == 0) goto L_0x0027
            r0 = -1
            boolean r7 = r7.canScrollVertically(r0)
            if (r7 == 0) goto L_0x0027
            return r3
        L_0x0027:
            android.support.design.widget.BottomSheetBehavior r7 = r5.f581a
            java.lang.ref.WeakReference<V> r7 = r7.r
            if (r7 == 0) goto L_0x0034
            java.lang.Object r7 = r7.get()
            if (r7 != r6) goto L_0x0034
            goto L_0x0035
        L_0x0034:
            r2 = 0
        L_0x0035:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.C0070q.b(android.view.View, int):boolean");
    }

    public void c(int i) {
        if (i == 1) {
            this.f581a.c(1);
        }
    }
}
