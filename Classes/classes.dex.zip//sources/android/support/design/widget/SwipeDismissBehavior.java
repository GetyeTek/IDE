package android.support.design.widget;

import android.support.design.widget.CoordinatorLayout;
import android.support.v4.view.y;
import android.support.v4.widget.w;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

public class SwipeDismissBehavior<V extends View> extends CoordinatorLayout.b<V> {

    /* renamed from: a  reason: collision with root package name */
    w f503a;

    /* renamed from: b  reason: collision with root package name */
    a f504b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f505c;
    private float d = 0.0f;
    private boolean e;
    int f = 2;
    float g = 0.5f;
    float h = 0.0f;
    float i = 0.5f;
    private final w.a j = new U(this);

    public interface a {
        void a(int i);

        void a(View view);
    }

    private class b implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private final View f506a;

        /* renamed from: b  reason: collision with root package name */
        private final boolean f507b;

        b(View view, boolean z) {
            this.f506a = view;
            this.f507b = z;
        }

        public void run() {
            a aVar;
            w wVar = SwipeDismissBehavior.this.f503a;
            if (wVar != null && wVar.a(true)) {
                y.a(this.f506a, (Runnable) this);
            } else if (this.f507b && (aVar = SwipeDismissBehavior.this.f504b) != null) {
                aVar.a(this.f506a);
            }
        }
    }

    static float a(float f2, float f3, float f4) {
        return Math.min(Math.max(f2, f3), f4);
    }

    static int a(int i2, int i3, int i4) {
        return Math.min(Math.max(i2, i3), i4);
    }

    private void a(ViewGroup viewGroup) {
        if (this.f503a == null) {
            this.f503a = this.e ? w.a(viewGroup, this.d, this.j) : w.a(viewGroup, this.j);
        }
    }

    static float b(float f2, float f3, float f4) {
        return (f4 - f2) / (f3 - f2);
    }

    public void a(float f2) {
        this.i = a(0.0f, f2, 1.0f);
    }

    public void a(int i2) {
        this.f = i2;
    }

    public void a(a aVar) {
        this.f504b = aVar;
    }

    public boolean a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        boolean z = this.f505c;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f505c = coordinatorLayout.a((View) v, (int) motionEvent.getX(), (int) motionEvent.getY());
            z = this.f505c;
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f505c = false;
        }
        if (!z) {
            return false;
        }
        a((ViewGroup) coordinatorLayout);
        return this.f503a.b(motionEvent);
    }

    public boolean a(View view) {
        return true;
    }

    public void b(float f2) {
        this.h = a(0.0f, f2, 1.0f);
    }

    public boolean b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        w wVar = this.f503a;
        if (wVar == null) {
            return false;
        }
        wVar.a(motionEvent);
        return true;
    }
}
