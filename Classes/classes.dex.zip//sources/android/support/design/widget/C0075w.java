package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.widget.CoordinatorLayout;

/* renamed from: android.support.design.widget.w  reason: case insensitive filesystem */
class C0075w implements Parcelable.ClassLoaderCreator<CoordinatorLayout.g> {
    C0075w() {
    }

    public CoordinatorLayout.g createFromParcel(Parcel parcel) {
        return new CoordinatorLayout.g(parcel, (ClassLoader) null);
    }

    public CoordinatorLayout.g createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new CoordinatorLayout.g(parcel, classLoader);
    }

    public CoordinatorLayout.g[] newArray(int i) {
        return new CoordinatorLayout.g[i];
    }
}
