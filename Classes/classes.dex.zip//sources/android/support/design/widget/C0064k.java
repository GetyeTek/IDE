package android.support.design.widget;

/* renamed from: android.support.design.widget.k  reason: case insensitive filesystem */
class C0064k implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0065l f573a;

    C0064k(C0065l lVar) {
        this.f573a = lVar;
    }

    public void run() {
        this.f573a.f574a.c(3);
    }
}
