package android.support.design.widget;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.util.StateSet;
import java.util.ArrayList;

public final class T {

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList<a> f509a = new ArrayList<>();

    /* renamed from: b  reason: collision with root package name */
    private a f510b = null;

    /* renamed from: c  reason: collision with root package name */
    ValueAnimator f511c = null;
    private final Animator.AnimatorListener d = new S(this);

    static class a {

        /* renamed from: a  reason: collision with root package name */
        final int[] f512a;

        /* renamed from: b  reason: collision with root package name */
        final ValueAnimator f513b;

        a(int[] iArr, ValueAnimator valueAnimator) {
            this.f512a = iArr;
            this.f513b = valueAnimator;
        }
    }

    private void a(a aVar) {
        this.f511c = aVar.f513b;
        this.f511c.start();
    }

    private void b() {
        ValueAnimator valueAnimator = this.f511c;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            this.f511c = null;
        }
    }

    public void a() {
        ValueAnimator valueAnimator = this.f511c;
        if (valueAnimator != null) {
            valueAnimator.end();
            this.f511c = null;
        }
    }

    public void a(int[] iArr) {
        a aVar;
        int size = this.f509a.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                aVar = null;
                break;
            }
            aVar = this.f509a.get(i);
            if (StateSet.stateSetMatches(aVar.f512a, iArr)) {
                break;
            }
            i++;
        }
        a aVar2 = this.f510b;
        if (aVar != aVar2) {
            if (aVar2 != null) {
                b();
            }
            this.f510b = aVar;
            if (aVar != null) {
                a(aVar);
            }
        }
    }

    public void a(int[] iArr, ValueAnimator valueAnimator) {
        a aVar = new a(iArr, valueAnimator);
        valueAnimator.addListener(this.d);
        this.f509a.add(aVar);
    }
}
