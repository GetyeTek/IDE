package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.widget.AppBarLayout;

/* renamed from: android.support.design.widget.c  reason: case insensitive filesystem */
class C0056c implements Parcelable.ClassLoaderCreator<AppBarLayout.BaseBehavior.b> {
    C0056c() {
    }

    public AppBarLayout.BaseBehavior.b createFromParcel(Parcel parcel) {
        return new AppBarLayout.BaseBehavior.b(parcel, (ClassLoader) null);
    }

    public AppBarLayout.BaseBehavior.b createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new AppBarLayout.BaseBehavior.b(parcel, classLoader);
    }

    public AppBarLayout.BaseBehavior.b[] newArray(int i) {
        return new AppBarLayout.BaseBehavior.b[i];
    }
}
