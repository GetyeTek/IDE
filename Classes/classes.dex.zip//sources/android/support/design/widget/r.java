package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.widget.BottomSheetBehavior;

class r implements Parcelable.ClassLoaderCreator<BottomSheetBehavior.b> {
    r() {
    }

    public BottomSheetBehavior.b createFromParcel(Parcel parcel) {
        return new BottomSheetBehavior.b(parcel, (ClassLoader) null);
    }

    public BottomSheetBehavior.b createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new BottomSheetBehavior.b(parcel, classLoader);
    }

    public BottomSheetBehavior.b[] newArray(int i) {
        return new BottomSheetBehavior.b[i];
    }
}
