package android.support.design.widget;

import android.support.design.widget.BaseTransientBottomBar;
import android.view.View;

/* renamed from: android.support.design.widget.l  reason: case insensitive filesystem */
class C0065l implements BaseTransientBottomBar.c {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f574a;

    C0065l(BaseTransientBottomBar baseTransientBottomBar) {
        this.f574a = baseTransientBottomBar;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        if (this.f574a.h()) {
            BaseTransientBottomBar.f440a.post(new C0064k(this));
        }
    }
}
