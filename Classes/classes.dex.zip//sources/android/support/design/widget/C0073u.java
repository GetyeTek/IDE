package android.support.design.widget;

import a.b.c.a.a;
import a.b.f.f.d;
import a.b.g.a.j;
import android.animation.TimeInterpolator;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.support.v4.view.y;
import android.support.v7.widget.ob;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

/* renamed from: android.support.design.widget.u  reason: case insensitive filesystem */
public final class C0073u {

    /* renamed from: a  reason: collision with root package name */
    private static final boolean f583a = (Build.VERSION.SDK_INT < 18);

    /* renamed from: b  reason: collision with root package name */
    private static final Paint f584b = null;
    private boolean A;
    private Bitmap B;
    private Paint C;
    private float D;
    private float E;
    private float F;
    private float G;
    private int[] H;
    private boolean I;
    private final TextPaint J;
    private final TextPaint K;
    private TimeInterpolator L;
    private TimeInterpolator M;
    private float N;
    private float O;
    private float P;
    private int Q;
    private float R;
    private float S;
    private float T;
    private int U;

    /* renamed from: c  reason: collision with root package name */
    private final View f585c;
    private boolean d;
    private float e;
    private final Rect f;
    private final Rect g;
    private final RectF h;
    private int i = 16;
    private int j = 16;
    private float k = 15.0f;
    private float l = 15.0f;
    private ColorStateList m;
    private ColorStateList n;
    private float o;
    private float p;
    private float q;
    private float r;
    private float s;
    private float t;
    private Typeface u;
    private Typeface v;
    private Typeface w;
    private CharSequence x;
    private CharSequence y;
    private boolean z;

    static {
        Paint paint = f584b;
        if (paint != null) {
            paint.setAntiAlias(true);
            f584b.setColor(-65281);
        }
    }

    public C0073u(View view) {
        this.f585c = view;
        this.J = new TextPaint(129);
        this.K = new TextPaint(this.J);
        this.g = new Rect();
        this.f = new Rect();
        this.h = new RectF();
    }

    private static float a(float f2, float f3, float f4, TimeInterpolator timeInterpolator) {
        if (timeInterpolator != null) {
            f4 = timeInterpolator.getInterpolation(f4);
        }
        return a.a(f2, f3, f4);
    }

    private static int a(int i2, int i3, float f2) {
        float f3 = 1.0f - f2;
        return Color.argb((int) ((((float) Color.alpha(i2)) * f3) + (((float) Color.alpha(i3)) * f2)), (int) ((((float) Color.red(i2)) * f3) + (((float) Color.red(i3)) * f2)), (int) ((((float) Color.green(i2)) * f3) + (((float) Color.green(i3)) * f2)), (int) ((((float) Color.blue(i2)) * f3) + (((float) Color.blue(i3)) * f2)));
    }

    private void a(TextPaint textPaint) {
        textPaint.setTextSize(this.l);
        textPaint.setTypeface(this.u);
    }

    private static boolean a(float f2, float f3) {
        return Math.abs(f2 - f3) < 0.001f;
    }

    private static boolean a(Rect rect, int i2, int i3, int i4, int i5) {
        return rect.left == i2 && rect.top == i3 && rect.right == i4 && rect.bottom == i5;
    }

    private boolean b(CharSequence charSequence) {
        boolean z2 = true;
        if (y.k(this.f585c) != 1) {
            z2 = false;
        }
        return (z2 ? d.d : d.f244c).isRtl(charSequence, 0, charSequence.length());
    }

    private void c(float f2) {
        int i2;
        TextPaint textPaint;
        e(f2);
        this.s = a(this.q, this.r, f2, this.L);
        this.t = a(this.o, this.p, f2, this.L);
        f(a(this.k, this.l, f2, this.M));
        if (this.n != this.m) {
            textPaint = this.J;
            i2 = a(m(), d(), f2);
        } else {
            textPaint = this.J;
            i2 = d();
        }
        textPaint.setColor(i2);
        this.J.setShadowLayer(a(this.R, this.N, f2, (TimeInterpolator) null), a(this.S, this.O, f2, (TimeInterpolator) null), a(this.T, this.P, f2, (TimeInterpolator) null), a(this.U, this.Q, f2));
        y.B(this.f585c);
    }

    private Typeface d(int i2) {
        TypedArray obtainStyledAttributes = this.f585c.getContext().obtainStyledAttributes(i2, new int[]{16843692});
        try {
            String string = obtainStyledAttributes.getString(0);
            if (string != null) {
                return Typeface.create(string, 0);
            }
            obtainStyledAttributes.recycle();
            return null;
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    private void d(float f2) {
        boolean z2;
        float f3;
        boolean z3;
        if (this.x != null) {
            float width = (float) this.g.width();
            float width2 = (float) this.f.width();
            boolean z4 = true;
            if (a(f2, this.l)) {
                float f4 = this.l;
                this.F = 1.0f;
                Typeface typeface = this.w;
                Typeface typeface2 = this.u;
                if (typeface != typeface2) {
                    this.w = typeface2;
                    z3 = true;
                } else {
                    z3 = false;
                }
                f3 = f4;
                z2 = z3;
            } else {
                f3 = this.k;
                Typeface typeface3 = this.w;
                Typeface typeface4 = this.v;
                if (typeface3 != typeface4) {
                    this.w = typeface4;
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (a(f2, this.k)) {
                    this.F = 1.0f;
                } else {
                    this.F = f2 / this.k;
                }
                float f5 = this.l / this.k;
                width = width2 * f5 > width ? Math.min(width / f5, width2) : width2;
            }
            if (width > 0.0f) {
                z2 = this.G != f3 || this.I || z2;
                this.G = f3;
                this.I = false;
            }
            if (this.y == null || z2) {
                this.J.setTextSize(this.G);
                this.J.setTypeface(this.w);
                TextPaint textPaint = this.J;
                if (this.F == 1.0f) {
                    z4 = false;
                }
                textPaint.setLinearText(z4);
                CharSequence ellipsize = TextUtils.ellipsize(this.x, this.J, width, TextUtils.TruncateAt.END);
                if (!TextUtils.equals(ellipsize, this.y)) {
                    this.y = ellipsize;
                    this.z = b(this.y);
                }
            }
        }
    }

    private void e(float f2) {
        this.h.left = a((float) this.f.left, (float) this.g.left, f2, this.L);
        this.h.top = a(this.o, this.p, f2, this.L);
        this.h.right = a((float) this.f.right, (float) this.g.right, f2, this.L);
        this.h.bottom = a((float) this.f.bottom, (float) this.g.bottom, f2, this.L);
    }

    private void f(float f2) {
        d(f2);
        this.A = f583a && this.F != 1.0f;
        if (this.A) {
            l();
        }
        y.B(this.f585c);
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x008d  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00cb  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00dc  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00ec  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void i() {
        /*
            r11 = this;
            float r0 = r11.G
            float r1 = r11.l
            r11.d((float) r1)
            java.lang.CharSequence r1 = r11.y
            r2 = 0
            r3 = 0
            if (r1 == 0) goto L_0x0018
            android.text.TextPaint r4 = r11.J
            int r5 = r1.length()
            float r1 = r4.measureText(r1, r2, r5)
            goto L_0x0019
        L_0x0018:
            r1 = 0
        L_0x0019:
            int r4 = r11.j
            boolean r5 = r11.z
            int r4 = android.support.v4.view.C0110g.a(r4, r5)
            r5 = r4 & 112(0x70, float:1.57E-43)
            r6 = 80
            r7 = 48
            r8 = 1073741824(0x40000000, float:2.0)
            if (r5 == r7) goto L_0x0053
            if (r5 == r6) goto L_0x004d
            android.text.TextPaint r5 = r11.J
            float r5 = r5.descent()
            android.text.TextPaint r9 = r11.J
            float r9 = r9.ascent()
            float r5 = r5 - r9
            float r5 = r5 / r8
            android.text.TextPaint r9 = r11.J
            float r9 = r9.descent()
            float r5 = r5 - r9
            android.graphics.Rect r9 = r11.g
            int r9 = r9.centerY()
            float r9 = (float) r9
            float r9 = r9 + r5
            r11.p = r9
            goto L_0x0061
        L_0x004d:
            android.graphics.Rect r5 = r11.g
            int r5 = r5.bottom
            float r5 = (float) r5
            goto L_0x005f
        L_0x0053:
            android.graphics.Rect r5 = r11.g
            int r5 = r5.top
            float r5 = (float) r5
            android.text.TextPaint r9 = r11.J
            float r9 = r9.ascent()
            float r5 = r5 - r9
        L_0x005f:
            r11.p = r5
        L_0x0061:
            r5 = 8388615(0x800007, float:1.1754953E-38)
            r4 = r4 & r5
            r9 = 5
            r10 = 1
            if (r4 == r10) goto L_0x0079
            if (r4 == r9) goto L_0x0073
            android.graphics.Rect r1 = r11.g
            int r1 = r1.left
            float r1 = (float) r1
            r11.r = r1
            goto L_0x0084
        L_0x0073:
            android.graphics.Rect r4 = r11.g
            int r4 = r4.right
            float r4 = (float) r4
            goto L_0x0081
        L_0x0079:
            android.graphics.Rect r4 = r11.g
            int r4 = r4.centerX()
            float r4 = (float) r4
            float r1 = r1 / r8
        L_0x0081:
            float r4 = r4 - r1
            r11.r = r4
        L_0x0084:
            float r1 = r11.k
            r11.d((float) r1)
            java.lang.CharSequence r1 = r11.y
            if (r1 == 0) goto L_0x0097
            android.text.TextPaint r3 = r11.J
            int r4 = r1.length()
            float r3 = r3.measureText(r1, r2, r4)
        L_0x0097:
            int r1 = r11.i
            boolean r2 = r11.z
            int r1 = android.support.v4.view.C0110g.a(r1, r2)
            r2 = r1 & 112(0x70, float:1.57E-43)
            if (r2 == r7) goto L_0x00cb
            if (r2 == r6) goto L_0x00c5
            android.text.TextPaint r2 = r11.J
            float r2 = r2.descent()
            android.text.TextPaint r4 = r11.J
            float r4 = r4.ascent()
            float r2 = r2 - r4
            float r2 = r2 / r8
            android.text.TextPaint r4 = r11.J
            float r4 = r4.descent()
            float r2 = r2 - r4
            android.graphics.Rect r4 = r11.f
            int r4 = r4.centerY()
            float r4 = (float) r4
            float r4 = r4 + r2
            r11.o = r4
            goto L_0x00d9
        L_0x00c5:
            android.graphics.Rect r2 = r11.f
            int r2 = r2.bottom
            float r2 = (float) r2
            goto L_0x00d7
        L_0x00cb:
            android.graphics.Rect r2 = r11.f
            int r2 = r2.top
            float r2 = (float) r2
            android.text.TextPaint r4 = r11.J
            float r4 = r4.ascent()
            float r2 = r2 - r4
        L_0x00d7:
            r11.o = r2
        L_0x00d9:
            r1 = r1 & r5
            if (r1 == r10) goto L_0x00ec
            if (r1 == r9) goto L_0x00e6
            android.graphics.Rect r1 = r11.f
            int r1 = r1.left
            float r1 = (float) r1
        L_0x00e3:
            r11.q = r1
            goto L_0x00f6
        L_0x00e6:
            android.graphics.Rect r1 = r11.f
            int r1 = r1.right
            float r1 = (float) r1
            goto L_0x00f4
        L_0x00ec:
            android.graphics.Rect r1 = r11.f
            int r1 = r1.centerX()
            float r1 = (float) r1
            float r3 = r3 / r8
        L_0x00f4:
            float r1 = r1 - r3
            goto L_0x00e3
        L_0x00f6:
            r11.k()
            r11.f(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.C0073u.i():void");
    }

    private void j() {
        c(this.e);
    }

    private void k() {
        Bitmap bitmap = this.B;
        if (bitmap != null) {
            bitmap.recycle();
            this.B = null;
        }
    }

    private void l() {
        if (this.B == null && !this.f.isEmpty() && !TextUtils.isEmpty(this.y)) {
            c(0.0f);
            this.D = this.J.ascent();
            this.E = this.J.descent();
            TextPaint textPaint = this.J;
            CharSequence charSequence = this.y;
            int round = Math.round(textPaint.measureText(charSequence, 0, charSequence.length()));
            int round2 = Math.round(this.E - this.D);
            if (round > 0 && round2 > 0) {
                this.B = Bitmap.createBitmap(round, round2, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(this.B);
                CharSequence charSequence2 = this.y;
                canvas.drawText(charSequence2, 0, charSequence2.length(), 0.0f, ((float) round2) - this.J.descent(), this.J);
                if (this.C == null) {
                    this.C = new Paint(3);
                }
            }
        }
    }

    private int m() {
        int[] iArr = this.H;
        return iArr != null ? this.m.getColorForState(iArr, 0) : this.m.getDefaultColor();
    }

    public float a() {
        if (this.x == null) {
            return 0.0f;
        }
        a(this.K);
        TextPaint textPaint = this.K;
        CharSequence charSequence = this.x;
        return textPaint.measureText(charSequence, 0, charSequence.length());
    }

    public void a(float f2) {
        if (this.k != f2) {
            this.k = f2;
            h();
        }
    }

    public void a(int i2) {
        ob a2 = ob.a(this.f585c.getContext(), i2, j.TextAppearance);
        if (a2.g(j.TextAppearance_android_textColor)) {
            this.n = a2.a(j.TextAppearance_android_textColor);
        }
        if (a2.g(j.TextAppearance_android_textSize)) {
            this.l = (float) a2.c(j.TextAppearance_android_textSize, (int) this.l);
        }
        this.Q = a2.d(j.TextAppearance_android_shadowColor, 0);
        this.O = a2.b(j.TextAppearance_android_shadowDx, 0.0f);
        this.P = a2.b(j.TextAppearance_android_shadowDy, 0.0f);
        this.N = a2.b(j.TextAppearance_android_shadowRadius, 0.0f);
        a2.a();
        if (Build.VERSION.SDK_INT >= 16) {
            this.u = d(i2);
        }
        h();
    }

    public void a(int i2, int i3, int i4, int i5) {
        if (!a(this.g, i2, i3, i4, i5)) {
            this.g.set(i2, i3, i4, i5);
            this.I = true;
            g();
        }
    }

    public void a(TimeInterpolator timeInterpolator) {
        this.L = timeInterpolator;
        h();
    }

    public void a(ColorStateList colorStateList) {
        if (this.n != colorStateList) {
            this.n = colorStateList;
            h();
        }
    }

    public void a(Canvas canvas) {
        float f2;
        int save = canvas.save();
        if (this.y != null && this.d) {
            float f3 = this.s;
            float f4 = this.t;
            boolean z2 = this.A && this.B != null;
            if (z2) {
                f2 = this.D * this.F;
                float f5 = this.E;
            } else {
                f2 = this.J.ascent() * this.F;
                this.J.descent();
                float f6 = this.F;
            }
            if (z2) {
                f4 += f2;
            }
            float f7 = f4;
            float f8 = this.F;
            if (f8 != 1.0f) {
                canvas.scale(f8, f8, f3, f7);
            }
            if (z2) {
                canvas.drawBitmap(this.B, f3, f7, this.C);
            } else {
                CharSequence charSequence = this.y;
                canvas.drawText(charSequence, 0, charSequence.length(), f3, f7, this.J);
            }
        }
        canvas.restoreToCount(save);
    }

    public void a(RectF rectF) {
        boolean b2 = b(this.x);
        rectF.left = !b2 ? (float) this.g.left : ((float) this.g.right) - a();
        Rect rect = this.g;
        rectF.top = (float) rect.top;
        rectF.right = !b2 ? rectF.left + a() : (float) rect.right;
        rectF.bottom = ((float) this.g.top) + c();
    }

    public void a(Typeface typeface) {
        this.v = typeface;
        this.u = typeface;
        h();
    }

    public void a(CharSequence charSequence) {
        if (charSequence == null || !charSequence.equals(this.x)) {
            this.x = charSequence;
            this.y = null;
            k();
            h();
        }
    }

    public final boolean a(int[] iArr) {
        this.H = iArr;
        if (!f()) {
            return false;
        }
        h();
        return true;
    }

    public ColorStateList b() {
        return this.n;
    }

    public void b(float f2) {
        float a2 = a.b.f.c.a.a(f2, 0.0f, 1.0f);
        if (a2 != this.e) {
            this.e = a2;
            j();
        }
    }

    public void b(int i2) {
        if (this.j != i2) {
            this.j = i2;
            h();
        }
    }

    public void b(int i2, int i3, int i4, int i5) {
        if (!a(this.f, i2, i3, i4, i5)) {
            this.f.set(i2, i3, i4, i5);
            this.I = true;
            g();
        }
    }

    public void b(TimeInterpolator timeInterpolator) {
        this.M = timeInterpolator;
        h();
    }

    public void b(ColorStateList colorStateList) {
        if (this.m != colorStateList) {
            this.m = colorStateList;
            h();
        }
    }

    public float c() {
        a(this.K);
        return -this.K.ascent();
    }

    public void c(int i2) {
        if (this.i != i2) {
            this.i = i2;
            h();
        }
    }

    public int d() {
        int[] iArr = this.H;
        return iArr != null ? this.n.getColorForState(iArr, 0) : this.n.getDefaultColor();
    }

    public float e() {
        return this.e;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000a, code lost:
        r0 = r1.m;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean f() {
        /*
            r1 = this;
            android.content.res.ColorStateList r0 = r1.n
            if (r0 == 0) goto L_0x000a
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x0014
        L_0x000a:
            android.content.res.ColorStateList r0 = r1.m
            if (r0 == 0) goto L_0x0016
            boolean r0 = r0.isStateful()
            if (r0 == 0) goto L_0x0016
        L_0x0014:
            r0 = 1
            goto L_0x0017
        L_0x0016:
            r0 = 0
        L_0x0017:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.C0073u.f():boolean");
    }

    /* access modifiers changed from: package-private */
    public void g() {
        this.d = this.g.width() > 0 && this.g.height() > 0 && this.f.width() > 0 && this.f.height() > 0;
    }

    public void h() {
        if (this.f585c.getHeight() > 0 && this.f585c.getWidth() > 0) {
            i();
            j();
        }
    }
}
