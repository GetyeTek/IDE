package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.lang.ref.WeakReference;

class Q {

    /* renamed from: a  reason: collision with root package name */
    private static Q f493a;

    /* renamed from: b  reason: collision with root package name */
    private final Object f494b = new Object();

    /* renamed from: c  reason: collision with root package name */
    private final Handler f495c = new Handler(Looper.getMainLooper(), new P(this));
    private b d;
    private b e;

    interface a {
        void a(int i);

        void c();
    }

    private static class b {

        /* renamed from: a  reason: collision with root package name */
        final WeakReference<a> f496a;

        /* renamed from: b  reason: collision with root package name */
        int f497b;

        /* renamed from: c  reason: collision with root package name */
        boolean f498c;

        b(int i, a aVar) {
            this.f496a = new WeakReference<>(aVar);
            this.f497b = i;
        }

        /* access modifiers changed from: package-private */
        public boolean a(a aVar) {
            return aVar != null && this.f496a.get() == aVar;
        }
    }

    private Q() {
    }

    static Q a() {
        if (f493a == null) {
            f493a = new Q();
        }
        return f493a;
    }

    private boolean a(b bVar, int i) {
        a aVar = (a) bVar.f496a.get();
        if (aVar == null) {
            return false;
        }
        this.f495c.removeCallbacksAndMessages(bVar);
        aVar.a(i);
        return true;
    }

    private void b() {
        b bVar = this.e;
        if (bVar != null) {
            this.d = bVar;
            this.e = null;
            a aVar = (a) this.d.f496a.get();
            if (aVar != null) {
                aVar.c();
            } else {
                this.d = null;
            }
        }
    }

    private void b(b bVar) {
        int i = bVar.f497b;
        if (i != -2) {
            if (i <= 0) {
                i = i == -1 ? 1500 : 2750;
            }
            this.f495c.removeCallbacksAndMessages(bVar);
            Handler handler = this.f495c;
            handler.sendMessageDelayed(Message.obtain(handler, 0, bVar), (long) i);
        }
    }

    private boolean f(a aVar) {
        b bVar = this.d;
        return bVar != null && bVar.a(aVar);
    }

    private boolean g(a aVar) {
        b bVar = this.e;
        return bVar != null && bVar.a(aVar);
    }

    public void a(int i, a aVar) {
        synchronized (this.f494b) {
            if (f(aVar)) {
                this.d.f497b = i;
                this.f495c.removeCallbacksAndMessages(this.d);
                b(this.d);
                return;
            }
            if (g(aVar)) {
                this.e.f497b = i;
            } else {
                this.e = new b(i, aVar);
            }
            if (this.d == null || !a(this.d, 4)) {
                this.d = null;
                b();
            }
        }
    }

    public void a(a aVar, int i) {
        b bVar;
        synchronized (this.f494b) {
            if (f(aVar)) {
                bVar = this.d;
            } else if (g(aVar)) {
                bVar = this.e;
            }
            a(bVar, i);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(b bVar) {
        synchronized (this.f494b) {
            if (this.d == bVar || this.e == bVar) {
                a(bVar, 2);
            }
        }
    }

    public boolean a(a aVar) {
        boolean z;
        synchronized (this.f494b) {
            if (!f(aVar)) {
                if (!g(aVar)) {
                    z = false;
                }
            }
            z = true;
        }
        return z;
    }

    public void b(a aVar) {
        synchronized (this.f494b) {
            if (f(aVar)) {
                this.d = null;
                if (this.e != null) {
                    b();
                }
            }
        }
    }

    public void c(a aVar) {
        synchronized (this.f494b) {
            if (f(aVar)) {
                b(this.d);
            }
        }
    }

    public void d(a aVar) {
        synchronized (this.f494b) {
            if (f(aVar) && !this.d.f498c) {
                this.d.f498c = true;
                this.f495c.removeCallbacksAndMessages(this.d);
            }
        }
    }

    public void e(a aVar) {
        synchronized (this.f494b) {
            if (f(aVar) && this.d.f498c) {
                this.d.f498c = false;
                b(this.d);
            }
        }
    }
}
