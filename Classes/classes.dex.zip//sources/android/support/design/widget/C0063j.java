package android.support.design.widget;

import android.support.design.widget.SwipeDismissBehavior;
import android.view.View;

/* renamed from: android.support.design.widget.j  reason: case insensitive filesystem */
class C0063j implements SwipeDismissBehavior.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f572a;

    C0063j(BaseTransientBottomBar baseTransientBottomBar) {
        this.f572a = baseTransientBottomBar;
    }

    public void a(int i) {
        if (i == 0) {
            Q.a().e(this.f572a.l);
        } else if (i == 1 || i == 2) {
            Q.a().d(this.f572a.l);
        }
    }

    public void a(View view) {
        view.setVisibility(8);
        this.f572a.a(0);
    }
}
