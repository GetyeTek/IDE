package android.support.design.widget;

import android.animation.ValueAnimator;

class W implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ TabLayout f544a;

    W(TabLayout tabLayout) {
        this.f544a = tabLayout;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f544a.scrollTo(((Integer) valueAnimator.getAnimatedValue()).intValue(), 0);
    }
}
