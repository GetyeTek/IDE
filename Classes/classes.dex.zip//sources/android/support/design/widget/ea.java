package android.support.design.widget;

import android.support.v4.view.y;
import android.view.View;

class ea {

    /* renamed from: a  reason: collision with root package name */
    private final View f564a;

    /* renamed from: b  reason: collision with root package name */
    private int f565b;

    /* renamed from: c  reason: collision with root package name */
    private int f566c;
    private int d;
    private int e;

    public ea(View view) {
        this.f564a = view;
    }

    private void c() {
        View view = this.f564a;
        y.b(view, this.d - (view.getTop() - this.f565b));
        View view2 = this.f564a;
        y.a(view2, this.e - (view2.getLeft() - this.f566c));
    }

    public int a() {
        return this.d;
    }

    public boolean a(int i) {
        if (this.e == i) {
            return false;
        }
        this.e = i;
        c();
        return true;
    }

    public void b() {
        this.f565b = this.f564a.getTop();
        this.f566c = this.f564a.getLeft();
        c();
    }

    public boolean b(int i) {
        if (this.d == i) {
            return false;
        }
        this.d = i;
        c();
        return true;
    }
}
