package android.support.design.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

public class V extends View {

    /* renamed from: a  reason: collision with root package name */
    public final CharSequence f541a;

    /* renamed from: b  reason: collision with root package name */
    public final Drawable f542b;

    /* renamed from: c  reason: collision with root package name */
    public final int f543c;
}
