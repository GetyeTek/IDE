package android.support.design.widget;

import android.support.v4.view.N;
import android.support.v4.view.s;
import android.view.View;

/* renamed from: android.support.design.widget.a  reason: case insensitive filesystem */
class C0054a implements s {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ AppBarLayout f551a;

    C0054a(AppBarLayout appBarLayout) {
        this.f551a = appBarLayout;
    }

    public N a(View view, N n) {
        return this.f551a.a(n);
    }
}
