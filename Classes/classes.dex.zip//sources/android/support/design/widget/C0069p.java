package android.support.design.widget;

import android.support.design.widget.BaseTransientBottomBar;
import android.support.v4.view.a.b;

/* renamed from: android.support.design.widget.p  reason: case insensitive filesystem */
class C0069p implements b.a {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar.e f580a;

    C0069p(BaseTransientBottomBar.e eVar) {
        this.f580a = eVar;
    }

    public void onTouchExplorationStateChanged(boolean z) {
        this.f580a.setClickableOrFocusableBasedOnAccessibility(z);
    }
}
