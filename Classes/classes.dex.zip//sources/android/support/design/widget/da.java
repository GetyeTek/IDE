package android.support.design.widget;

import android.content.Context;
import android.support.design.widget.CoordinatorLayout;
import android.util.AttributeSet;
import android.view.View;

class da<V extends View> extends CoordinatorLayout.b<V> {

    /* renamed from: a  reason: collision with root package name */
    private ea f559a;

    /* renamed from: b  reason: collision with root package name */
    private int f560b = 0;

    /* renamed from: c  reason: collision with root package name */
    private int f561c = 0;

    public da() {
    }

    public da(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean a(int i) {
        ea eaVar = this.f559a;
        if (eaVar != null) {
            return eaVar.b(i);
        }
        this.f560b = i;
        return false;
    }

    public boolean a(CoordinatorLayout coordinatorLayout, V v, int i) {
        b(coordinatorLayout, v, i);
        if (this.f559a == null) {
            this.f559a = new ea(v);
        }
        this.f559a.b();
        int i2 = this.f560b;
        if (i2 != 0) {
            this.f559a.b(i2);
            this.f560b = 0;
        }
        int i3 = this.f561c;
        if (i3 == 0) {
            return true;
        }
        this.f559a.a(i3);
        this.f561c = 0;
        return true;
    }

    public int b() {
        ea eaVar = this.f559a;
        if (eaVar != null) {
            return eaVar.a();
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    public void b(CoordinatorLayout coordinatorLayout, V v, int i) {
        coordinatorLayout.c((View) v, i);
    }
}
