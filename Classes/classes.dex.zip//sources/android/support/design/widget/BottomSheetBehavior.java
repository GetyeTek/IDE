package android.support.design.widget;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.view.C0106c;
import android.support.v4.view.y;
import android.support.v4.widget.w;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.b<V> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public boolean f447a = true;

    /* renamed from: b  reason: collision with root package name */
    private float f448b;

    /* renamed from: c  reason: collision with root package name */
    private int f449c;
    private boolean d;
    private int e;
    private int f;
    int g;
    int h;
    int i;
    boolean j;
    private boolean k;
    int l = 4;
    w m;
    private boolean n;
    private int o;
    private boolean p;
    int q;
    WeakReference<V> r;
    WeakReference<View> s;
    private a t;
    private VelocityTracker u;
    int v;
    private int w;
    boolean x;
    private Map<View, Integer> y;
    private final w.a z = new C0070q(this);

    public static abstract class a {
        public abstract void a(View view, float f);

        public abstract void a(View view, int i);
    }

    protected static class b extends C0106c {
        public static final Parcelable.Creator<b> CREATOR = new r();

        /* renamed from: c  reason: collision with root package name */
        final int f450c;

        public b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f450c = parcel.readInt();
        }

        public b(Parcelable parcelable, int i) {
            super(parcelable);
            this.f450c = i;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f450c);
        }
    }

    private class c implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private final View f451a;

        /* renamed from: b  reason: collision with root package name */
        private final int f452b;

        c(View view, int i) {
            this.f451a = view;
            this.f452b = i;
        }

        public void run() {
            w wVar = BottomSheetBehavior.this.m;
            if (wVar == null || !wVar.a(true)) {
                BottomSheetBehavior.this.c(this.f452b);
            } else {
                y.a(this.f451a, (Runnable) this);
            }
        }
    }

    public BottomSheetBehavior() {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x001f, code lost:
        r1 = r1.data;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public BottomSheetBehavior(android.content.Context r4, android.util.AttributeSet r5) {
        /*
            r3 = this;
            r3.<init>(r4, r5)
            r0 = 1
            r3.f447a = r0
            r1 = 4
            r3.l = r1
            android.support.design.widget.q r1 = new android.support.design.widget.q
            r1.<init>(r3)
            r3.z = r1
            int[] r1 = a.b.c.k.BottomSheetBehavior_Layout
            android.content.res.TypedArray r5 = r4.obtainStyledAttributes(r5, r1)
            int r1 = a.b.c.k.BottomSheetBehavior_Layout_behavior_peekHeight
            android.util.TypedValue r1 = r5.peekValue(r1)
            r2 = -1
            if (r1 == 0) goto L_0x0024
            int r1 = r1.data
            if (r1 != r2) goto L_0x0024
            goto L_0x002a
        L_0x0024:
            int r1 = a.b.c.k.BottomSheetBehavior_Layout_behavior_peekHeight
            int r1 = r5.getDimensionPixelSize(r1, r2)
        L_0x002a:
            r3.b((int) r1)
            int r1 = a.b.c.k.BottomSheetBehavior_Layout_behavior_hideable
            r2 = 0
            boolean r1 = r5.getBoolean(r1, r2)
            r3.b((boolean) r1)
            int r1 = a.b.c.k.BottomSheetBehavior_Layout_behavior_fitToContents
            boolean r0 = r5.getBoolean(r1, r0)
            r3.a((boolean) r0)
            int r0 = a.b.c.k.BottomSheetBehavior_Layout_behavior_skipCollapsed
            boolean r0 = r5.getBoolean(r0, r2)
            r3.c((boolean) r0)
            r5.recycle()
            android.view.ViewConfiguration r4 = android.view.ViewConfiguration.get(r4)
            int r4 = r4.getScaledMaximumFlingVelocity()
            float r4 = (float) r4
            r3.f448b = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.BottomSheetBehavior.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    private void b() {
        this.i = this.f447a ? Math.max(this.q - this.f, this.g) : this.q - this.f;
    }

    /* access modifiers changed from: private */
    public int c() {
        if (this.f447a) {
            return this.g;
        }
        return 0;
    }

    private float d() {
        VelocityTracker velocityTracker = this.u;
        if (velocityTracker == null) {
            return 0.0f;
        }
        velocityTracker.computeCurrentVelocity(1000, this.f448b);
        return this.u.getYVelocity(this.v);
    }

    private void d(boolean z2) {
        int i2;
        WeakReference<V> weakReference = this.r;
        if (weakReference != null) {
            ViewParent parent = ((View) weakReference.get()).getParent();
            if (parent instanceof CoordinatorLayout) {
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
                int childCount = coordinatorLayout.getChildCount();
                if (Build.VERSION.SDK_INT >= 16 && z2) {
                    if (this.y == null) {
                        this.y = new HashMap(childCount);
                    } else {
                        return;
                    }
                }
                for (int i3 = 0; i3 < childCount; i3++) {
                    View childAt = coordinatorLayout.getChildAt(i3);
                    if (childAt != this.r.get()) {
                        if (!z2) {
                            Map<View, Integer> map = this.y;
                            if (map != null && map.containsKey(childAt)) {
                                i2 = this.y.get(childAt).intValue();
                            }
                        } else {
                            if (Build.VERSION.SDK_INT >= 16) {
                                this.y.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                            }
                            i2 = 4;
                        }
                        y.d(childAt, i2);
                    }
                }
                if (!z2) {
                    this.y = null;
                }
            }
        }
    }

    private void e() {
        this.v = -1;
        VelocityTracker velocityTracker = this.u;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.u = null;
        }
    }

    /* access modifiers changed from: package-private */
    public View a(View view) {
        if (y.z(view)) {
            return view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View a2 = a(viewGroup.getChildAt(i2));
            if (a2 != null) {
                return a2;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public void a(int i2) {
        a aVar;
        float f2;
        float f3;
        View view = (View) this.r.get();
        if (view != null && (aVar = this.t) != null) {
            int i3 = this.i;
            if (i2 > i3) {
                f2 = (float) (i3 - i2);
                f3 = (float) (this.q - i3);
            } else {
                f2 = (float) (i3 - i2);
                f3 = (float) (i3 - c());
            }
            aVar.a(view, f2 / f3);
        }
    }

    public void a(CoordinatorLayout coordinatorLayout, V v2, Parcelable parcelable) {
        b bVar = (b) parcelable;
        super.a(coordinatorLayout, v2, bVar.a());
        int i2 = bVar.f450c;
        if (i2 == 1 || i2 == 2) {
            i2 = 4;
        }
        this.l = i2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0078, code lost:
        if (java.lang.Math.abs(r4 - r1) < java.lang.Math.abs(r4 - r3.i)) goto L_0x007a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(android.support.design.widget.CoordinatorLayout r4, V r5, android.view.View r6, int r7) {
        /*
            r3 = this;
            int r4 = r5.getTop()
            int r7 = r3.c()
            r0 = 3
            if (r4 != r7) goto L_0x000f
            r3.c((int) r0)
            return
        L_0x000f:
            java.lang.ref.WeakReference<android.view.View> r4 = r3.s
            java.lang.Object r4 = r4.get()
            if (r6 != r4) goto L_0x009f
            boolean r4 = r3.p
            if (r4 != 0) goto L_0x001d
            goto L_0x009f
        L_0x001d:
            int r4 = r3.o
            r6 = 0
            r7 = 4
            if (r4 <= 0) goto L_0x0028
            int r4 = r3.c()
            goto L_0x0081
        L_0x0028:
            boolean r4 = r3.j
            if (r4 == 0) goto L_0x003a
            float r4 = r3.d()
            boolean r4 = r3.a(r5, r4)
            if (r4 == 0) goto L_0x003a
            int r4 = r3.q
            r0 = 5
            goto L_0x0081
        L_0x003a:
            int r4 = r3.o
            if (r4 != 0) goto L_0x007e
            int r4 = r5.getTop()
            boolean r1 = r3.f447a
            r2 = 6
            if (r1 == 0) goto L_0x005b
            int r1 = r3.g
            int r1 = r4 - r1
            int r1 = java.lang.Math.abs(r1)
            int r2 = r3.i
            int r4 = r4 - r2
            int r4 = java.lang.Math.abs(r4)
            if (r1 >= r4) goto L_0x007e
            int r4 = r3.g
            goto L_0x0081
        L_0x005b:
            int r1 = r3.h
            if (r4 >= r1) goto L_0x006b
            int r7 = r3.i
            int r7 = r4 - r7
            int r7 = java.lang.Math.abs(r7)
            if (r4 >= r7) goto L_0x007a
            r4 = 0
            goto L_0x0081
        L_0x006b:
            int r0 = r4 - r1
            int r0 = java.lang.Math.abs(r0)
            int r1 = r3.i
            int r4 = r4 - r1
            int r4 = java.lang.Math.abs(r4)
            if (r0 >= r4) goto L_0x007e
        L_0x007a:
            int r4 = r3.h
            r0 = 6
            goto L_0x0081
        L_0x007e:
            int r4 = r3.i
            r0 = 4
        L_0x0081:
            android.support.v4.widget.w r7 = r3.m
            int r1 = r5.getLeft()
            boolean r4 = r7.b((android.view.View) r5, (int) r1, (int) r4)
            if (r4 == 0) goto L_0x009a
            r4 = 2
            r3.c((int) r4)
            android.support.design.widget.BottomSheetBehavior$c r4 = new android.support.design.widget.BottomSheetBehavior$c
            r4.<init>(r5, r0)
            android.support.v4.view.y.a((android.view.View) r5, (java.lang.Runnable) r4)
            goto L_0x009d
        L_0x009a:
            r3.c((int) r0)
        L_0x009d:
            r3.p = r6
        L_0x009f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.BottomSheetBehavior.a(android.support.design.widget.CoordinatorLayout, android.view.View, android.view.View, int):void");
    }

    public void a(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int[] iArr, int i4) {
        int i5;
        if (i4 != 1 && view == ((View) this.s.get())) {
            int top = v2.getTop();
            int i6 = top - i3;
            if (i3 <= 0) {
                if (i3 < 0 && !view.canScrollVertically(-1)) {
                    int i7 = this.i;
                    if (i6 <= i7 || this.j) {
                        iArr[1] = i3;
                        y.b((View) v2, -i3);
                        c(1);
                    } else {
                        iArr[1] = top - i7;
                        y.b((View) v2, -iArr[1]);
                        i5 = 4;
                    }
                }
                a(v2.getTop());
                this.o = i3;
                this.p = true;
            } else if (i6 < c()) {
                iArr[1] = top - c();
                y.b((View) v2, -iArr[1]);
                i5 = 3;
            } else {
                iArr[1] = i3;
                y.b((View) v2, -i3);
                c(1);
                a(v2.getTop());
                this.o = i3;
                this.p = true;
            }
            c(i5);
            a(v2.getTop());
            this.o = i3;
            this.p = true;
        }
    }

    public void a(boolean z2) {
        if (this.f447a != z2) {
            this.f447a = z2;
            if (this.r != null) {
                b();
            }
            c((!this.f447a || this.l != 6) ? this.l : 3);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:32:0x0093  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean a(android.support.design.widget.CoordinatorLayout r5, V r6, int r7) {
        /*
            r4 = this;
            boolean r0 = android.support.v4.view.y.h(r5)
            r1 = 1
            if (r0 == 0) goto L_0x0010
            boolean r0 = android.support.v4.view.y.h(r6)
            if (r0 != 0) goto L_0x0010
            r6.setFitsSystemWindows(r1)
        L_0x0010:
            int r0 = r6.getTop()
            r5.c((android.view.View) r6, (int) r7)
            int r7 = r5.getHeight()
            r4.q = r7
            boolean r7 = r4.d
            if (r7 == 0) goto L_0x0043
            int r7 = r4.e
            if (r7 != 0) goto L_0x0031
            android.content.res.Resources r7 = r5.getResources()
            int r2 = a.b.c.d.design_bottom_sheet_peek_height_min
            int r7 = r7.getDimensionPixelSize(r2)
            r4.e = r7
        L_0x0031:
            int r7 = r4.e
            int r2 = r4.q
            int r3 = r5.getWidth()
            int r3 = r3 * 9
            int r3 = r3 / 16
            int r2 = r2 - r3
            int r7 = java.lang.Math.max(r7, r2)
            goto L_0x0045
        L_0x0043:
            int r7 = r4.f449c
        L_0x0045:
            r4.f = r7
            r7 = 0
            int r2 = r4.q
            int r3 = r6.getHeight()
            int r2 = r2 - r3
            int r7 = java.lang.Math.max(r7, r2)
            r4.g = r7
            int r7 = r4.q
            r2 = 2
            int r7 = r7 / r2
            r4.h = r7
            r4.b()
            int r7 = r4.l
            r3 = 3
            if (r7 != r3) goto L_0x006b
            int r7 = r4.c()
        L_0x0067:
            android.support.v4.view.y.b((android.view.View) r6, (int) r7)
            goto L_0x008f
        L_0x006b:
            r3 = 6
            if (r7 != r3) goto L_0x0071
            int r7 = r4.h
            goto L_0x0067
        L_0x0071:
            boolean r3 = r4.j
            if (r3 == 0) goto L_0x007b
            r3 = 5
            if (r7 != r3) goto L_0x007b
            int r7 = r4.q
            goto L_0x0067
        L_0x007b:
            int r7 = r4.l
            r3 = 4
            if (r7 != r3) goto L_0x0083
            int r7 = r4.i
            goto L_0x0067
        L_0x0083:
            if (r7 == r1) goto L_0x0087
            if (r7 != r2) goto L_0x008f
        L_0x0087:
            int r7 = r6.getTop()
            int r0 = r0 - r7
            android.support.v4.view.y.b((android.view.View) r6, (int) r0)
        L_0x008f:
            android.support.v4.widget.w r7 = r4.m
            if (r7 != 0) goto L_0x009b
            android.support.v4.widget.w$a r7 = r4.z
            android.support.v4.widget.w r5 = android.support.v4.widget.w.a((android.view.ViewGroup) r5, (android.support.v4.widget.w.a) r7)
            r4.m = r5
        L_0x009b:
            java.lang.ref.WeakReference r5 = new java.lang.ref.WeakReference
            r5.<init>(r6)
            r4.r = r5
            java.lang.ref.WeakReference r5 = new java.lang.ref.WeakReference
            android.view.View r6 = r4.a((android.view.View) r6)
            r5.<init>(r6)
            r4.s = r5
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.BottomSheetBehavior.a(android.support.design.widget.CoordinatorLayout, android.view.View, int):boolean");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v12, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: android.view.View} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean a(android.support.design.widget.CoordinatorLayout r9, V r10, android.view.MotionEvent r11) {
        /*
            r8 = this;
            boolean r0 = r10.isShown()
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x000b
            r8.n = r2
            return r1
        L_0x000b:
            int r0 = r11.getActionMasked()
            if (r0 != 0) goto L_0x0014
            r8.e()
        L_0x0014:
            android.view.VelocityTracker r3 = r8.u
            if (r3 != 0) goto L_0x001e
            android.view.VelocityTracker r3 = android.view.VelocityTracker.obtain()
            r8.u = r3
        L_0x001e:
            android.view.VelocityTracker r3 = r8.u
            r3.addMovement(r11)
            r3 = 0
            r4 = -1
            if (r0 == 0) goto L_0x0038
            if (r0 == r2) goto L_0x002d
            r10 = 3
            if (r0 == r10) goto L_0x002d
            goto L_0x0077
        L_0x002d:
            r8.x = r1
            r8.v = r4
            boolean r10 = r8.n
            if (r10 == 0) goto L_0x0077
            r8.n = r1
            return r1
        L_0x0038:
            float r5 = r11.getX()
            int r5 = (int) r5
            float r6 = r11.getY()
            int r6 = (int) r6
            r8.w = r6
            java.lang.ref.WeakReference<android.view.View> r6 = r8.s
            if (r6 == 0) goto L_0x004f
            java.lang.Object r6 = r6.get()
            android.view.View r6 = (android.view.View) r6
            goto L_0x0050
        L_0x004f:
            r6 = r3
        L_0x0050:
            if (r6 == 0) goto L_0x0066
            int r7 = r8.w
            boolean r6 = r9.a((android.view.View) r6, (int) r5, (int) r7)
            if (r6 == 0) goto L_0x0066
            int r6 = r11.getActionIndex()
            int r6 = r11.getPointerId(r6)
            r8.v = r6
            r8.x = r2
        L_0x0066:
            int r6 = r8.v
            if (r6 != r4) goto L_0x0074
            int r4 = r8.w
            boolean r10 = r9.a((android.view.View) r10, (int) r5, (int) r4)
            if (r10 != 0) goto L_0x0074
            r10 = 1
            goto L_0x0075
        L_0x0074:
            r10 = 0
        L_0x0075:
            r8.n = r10
        L_0x0077:
            boolean r10 = r8.n
            if (r10 != 0) goto L_0x0086
            android.support.v4.widget.w r10 = r8.m
            if (r10 == 0) goto L_0x0086
            boolean r10 = r10.b((android.view.MotionEvent) r11)
            if (r10 == 0) goto L_0x0086
            return r2
        L_0x0086:
            java.lang.ref.WeakReference<android.view.View> r10 = r8.s
            if (r10 == 0) goto L_0x0091
            java.lang.Object r10 = r10.get()
            r3 = r10
            android.view.View r3 = (android.view.View) r3
        L_0x0091:
            r10 = 2
            if (r0 != r10) goto L_0x00ca
            if (r3 == 0) goto L_0x00ca
            boolean r10 = r8.n
            if (r10 != 0) goto L_0x00ca
            int r10 = r8.l
            if (r10 == r2) goto L_0x00ca
            float r10 = r11.getX()
            int r10 = (int) r10
            float r0 = r11.getY()
            int r0 = (int) r0
            boolean r9 = r9.a((android.view.View) r3, (int) r10, (int) r0)
            if (r9 != 0) goto L_0x00ca
            android.support.v4.widget.w r9 = r8.m
            if (r9 == 0) goto L_0x00ca
            int r9 = r8.w
            float r9 = (float) r9
            float r10 = r11.getY()
            float r9 = r9 - r10
            float r9 = java.lang.Math.abs(r9)
            android.support.v4.widget.w r10 = r8.m
            int r10 = r10.d()
            float r10 = (float) r10
            int r9 = (r9 > r10 ? 1 : (r9 == r10 ? 0 : -1))
            if (r9 <= 0) goto L_0x00ca
            r1 = 1
        L_0x00ca:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.BottomSheetBehavior.a(android.support.design.widget.CoordinatorLayout, android.view.View, android.view.MotionEvent):boolean");
    }

    public boolean a(CoordinatorLayout coordinatorLayout, V v2, View view, float f2, float f3) {
        return view == this.s.get() && (this.l != 3 || super.a(coordinatorLayout, v2, view, f2, f3));
    }

    /* access modifiers changed from: package-private */
    public boolean a(View view, float f2) {
        if (this.k) {
            return true;
        }
        return view.getTop() >= this.i && Math.abs((((float) view.getTop()) + (f2 * 0.1f)) - ((float) this.i)) / ((float) this.f449c) > 0.5f;
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0037  */
    /* JADX WARNING: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void b(int r4) {
        /*
            r3 = this;
            r0 = 1
            r1 = 0
            r2 = -1
            if (r4 != r2) goto L_0x000c
            boolean r4 = r3.d
            if (r4 != 0) goto L_0x0015
            r3.d = r0
            goto L_0x0024
        L_0x000c:
            boolean r2 = r3.d
            if (r2 != 0) goto L_0x0017
            int r2 = r3.f449c
            if (r2 == r4) goto L_0x0015
            goto L_0x0017
        L_0x0015:
            r0 = 0
            goto L_0x0024
        L_0x0017:
            r3.d = r1
            int r1 = java.lang.Math.max(r1, r4)
            r3.f449c = r1
            int r1 = r3.q
            int r1 = r1 - r4
            r3.i = r1
        L_0x0024:
            if (r0 == 0) goto L_0x003a
            int r4 = r3.l
            r0 = 4
            if (r4 != r0) goto L_0x003a
            java.lang.ref.WeakReference<V> r4 = r3.r
            if (r4 == 0) goto L_0x003a
            java.lang.Object r4 = r4.get()
            android.view.View r4 = (android.view.View) r4
            if (r4 == 0) goto L_0x003a
            r4.requestLayout()
        L_0x003a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.BottomSheetBehavior.b(int):void");
    }

    public void b(boolean z2) {
        this.j = z2;
    }

    public boolean b(CoordinatorLayout coordinatorLayout, V v2, MotionEvent motionEvent) {
        if (!v2.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.l == 1 && actionMasked == 0) {
            return true;
        }
        w wVar = this.m;
        if (wVar != null) {
            wVar.a(motionEvent);
        }
        if (actionMasked == 0) {
            e();
        }
        if (this.u == null) {
            this.u = VelocityTracker.obtain();
        }
        this.u.addMovement(motionEvent);
        if (actionMasked == 2 && !this.n && Math.abs(((float) this.w) - motionEvent.getY()) > ((float) this.m.d())) {
            this.m.a((View) v2, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        return !this.n;
    }

    public boolean b(CoordinatorLayout coordinatorLayout, V v2, View view, View view2, int i2, int i3) {
        this.o = 0;
        this.p = false;
        return (i2 & 2) != 0;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0028  */
    /* JADX WARNING: Removed duplicated region for block: B:21:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void c(int r3) {
        /*
            r2 = this;
            int r0 = r2.l
            if (r0 != r3) goto L_0x0005
            return
        L_0x0005:
            r2.l = r3
            r0 = 6
            if (r3 == r0) goto L_0x0016
            r0 = 3
            if (r3 != r0) goto L_0x000e
            goto L_0x0016
        L_0x000e:
            r0 = 5
            if (r3 == r0) goto L_0x0014
            r0 = 4
            if (r3 != r0) goto L_0x001a
        L_0x0014:
            r0 = 0
            goto L_0x0017
        L_0x0016:
            r0 = 1
        L_0x0017:
            r2.d(r0)
        L_0x001a:
            java.lang.ref.WeakReference<V> r0 = r2.r
            java.lang.Object r0 = r0.get()
            android.view.View r0 = (android.view.View) r0
            if (r0 == 0) goto L_0x002b
            android.support.design.widget.BottomSheetBehavior$a r1 = r2.t
            if (r1 == 0) goto L_0x002b
            r1.a((android.view.View) r0, (int) r3)
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.BottomSheetBehavior.c(int):void");
    }

    public void c(boolean z2) {
        this.k = z2;
    }

    public Parcelable d(CoordinatorLayout coordinatorLayout, V v2) {
        return new b(super.d(coordinatorLayout, v2), this.l);
    }
}
