package android.support.design.widget;

import a.b.c.f.a;
import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.view.View;
import java.util.ArrayList;

class F extends E {
    private InsetDrawable I;

    F(ga gaVar, O o) {
        super(gaVar, o);
    }

    private Animator a(float f, float f2) {
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(ObjectAnimator.ofFloat(this.B, "elevation", new float[]{f}).setDuration(0)).with(ObjectAnimator.ofFloat(this.B, View.TRANSLATION_Z, new float[]{f2}).setDuration(100));
        animatorSet.setInterpolator(E.f468a);
        return animatorSet;
    }

    /* access modifiers changed from: package-private */
    public void a(float f, float f2, float f3) {
        if (Build.VERSION.SDK_INT == 21) {
            this.B.refreshDrawableState();
        } else {
            StateListAnimator stateListAnimator = new StateListAnimator();
            stateListAnimator.addState(E.f469b, a(f, f3));
            stateListAnimator.addState(E.f470c, a(f, f2));
            stateListAnimator.addState(E.d, a(f, f2));
            stateListAnimator.addState(E.e, a(f, f2));
            AnimatorSet animatorSet = new AnimatorSet();
            ArrayList arrayList = new ArrayList();
            arrayList.add(ObjectAnimator.ofFloat(this.B, "elevation", new float[]{f}).setDuration(0));
            int i = Build.VERSION.SDK_INT;
            if (i >= 22 && i <= 24) {
                ga gaVar = this.B;
                arrayList.add(ObjectAnimator.ofFloat(gaVar, View.TRANSLATION_Z, new float[]{gaVar.getTranslationZ()}).setDuration(100));
            }
            arrayList.add(ObjectAnimator.ofFloat(this.B, View.TRANSLATION_Z, new float[]{0.0f}).setDuration(100));
            animatorSet.playSequentially((Animator[]) arrayList.toArray(new Animator[0]));
            animatorSet.setInterpolator(E.f468a);
            stateListAnimator.addState(E.f, animatorSet);
            stateListAnimator.addState(E.g, a(0.0f, 0.0f));
            this.B.setStateListAnimator(stateListAnimator);
        }
        if (this.C.a()) {
            p();
        }
    }

    /* access modifiers changed from: package-private */
    public void a(Rect rect) {
        if (this.C.a()) {
            float b2 = this.C.b();
            float b3 = b() + this.w;
            int ceil = (int) Math.ceil((double) N.a(b3, b2, false));
            int ceil2 = (int) Math.ceil((double) N.b(b3, b2, false));
            rect.set(ceil, ceil2, ceil, ceil2);
            return;
        }
        rect.set(0, 0, 0, 0);
    }

    /* access modifiers changed from: package-private */
    public void a(int[] iArr) {
        ga gaVar;
        if (Build.VERSION.SDK_INT == 21) {
            float f = 0.0f;
            if (this.B.isEnabled()) {
                this.B.setElevation(this.u);
                if (this.B.isPressed()) {
                    gaVar = this.B;
                    f = this.w;
                } else if (this.B.isFocused() || this.B.isHovered()) {
                    gaVar = this.B;
                    f = this.v;
                }
                gaVar.setTranslationZ(f);
            }
            this.B.setElevation(0.0f);
            gaVar = this.B;
            gaVar.setTranslationZ(f);
        }
    }

    public float b() {
        return this.B.getElevation();
    }

    /* access modifiers changed from: package-private */
    public void b(ColorStateList colorStateList) {
        Drawable drawable = this.r;
        if (drawable instanceof RippleDrawable) {
            ((RippleDrawable) drawable).setColor(a.a(colorStateList));
        } else {
            super.b(colorStateList);
        }
    }

    /* access modifiers changed from: package-private */
    public void b(Rect rect) {
        O o;
        Drawable drawable;
        if (this.C.a()) {
            this.I = new InsetDrawable(this.r, rect.left, rect.top, rect.right, rect.bottom);
            o = this.C;
            drawable = this.I;
        } else {
            o = this.C;
            drawable = this.r;
        }
        o.a(drawable);
    }

    /* access modifiers changed from: package-private */
    public void i() {
    }

    /* access modifiers changed from: package-private */
    public void k() {
        p();
    }

    /* access modifiers changed from: package-private */
    public boolean n() {
        return false;
    }
}
