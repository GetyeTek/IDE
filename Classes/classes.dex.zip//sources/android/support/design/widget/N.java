package android.support.design.widget;

import a.b.g.c.a.e;
import android.graphics.Rect;

public class N extends e {

    /* renamed from: b  reason: collision with root package name */
    static final double f490b = Math.cos(Math.toRadians(45.0d));

    public static float a(float f, float f2, boolean z) {
        if (!z) {
            return f;
        }
        double d = (double) f;
        double d2 = (double) f2;
        Double.isNaN(d2);
        Double.isNaN(d);
        return (float) (d + ((1.0d - f490b) * d2));
    }

    public static float b(float f, float f2, boolean z) {
        if (!z) {
            return f * 1.5f;
        }
        double d = (double) (f * 1.5f);
        double d2 = (double) f2;
        Double.isNaN(d2);
        Double.isNaN(d);
        return (float) (d + ((1.0d - f490b) * d2));
    }

    public final void a(float f) {
        throw null;
    }

    public void a(float f, float f2) {
        throw null;
    }

    public float b() {
        throw null;
    }

    public void b(float f) {
        throw null;
    }

    public boolean getPadding(Rect rect) {
        throw null;
    }
}
