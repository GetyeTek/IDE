package android.support.design.widget;

import android.animation.ValueAnimator;
import android.support.v4.view.y;
import android.view.View;

/* renamed from: android.support.design.widget.e  reason: case insensitive filesystem */
class C0058e implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    private int f562a = 0;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f563b;

    C0058e(BaseTransientBottomBar baseTransientBottomBar) {
        this.f563b = baseTransientBottomBar;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        int intValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        if (BaseTransientBottomBar.f441b) {
            y.b((View) this.f563b.f, intValue - this.f562a);
        } else {
            this.f563b.f.setTranslationY((float) intValue);
        }
        this.f562a = intValue;
    }
}
