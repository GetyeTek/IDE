package android.support.design.widget;

import android.animation.ValueAnimator;
import android.support.design.widget.AppBarLayout;

/* renamed from: android.support.design.widget.b  reason: case insensitive filesystem */
class C0055b implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ CoordinatorLayout f553a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ AppBarLayout f554b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ AppBarLayout.BaseBehavior f555c;

    C0055b(AppBarLayout.BaseBehavior baseBehavior, CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
        this.f555c = baseBehavior;
        this.f553a = coordinatorLayout;
        this.f554b = appBarLayout;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f555c.c(this.f553a, this.f554b, ((Integer) valueAnimator.getAnimatedValue()).intValue());
    }
}
