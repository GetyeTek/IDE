package android.support.design.widget;

import android.support.design.widget.SwipeDismissBehavior;
import android.support.v4.view.y;
import android.support.v4.widget.w;
import android.view.View;
import android.view.ViewParent;

class U extends w.a {

    /* renamed from: a  reason: collision with root package name */
    private int f538a;

    /* renamed from: b  reason: collision with root package name */
    private int f539b = -1;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ SwipeDismissBehavior f540c;

    U(SwipeDismissBehavior swipeDismissBehavior) {
        this.f540c = swipeDismissBehavior;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0025 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0034 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean a(android.view.View r6, float r7) {
        /*
            r5 = this;
            r0 = 0
            r1 = 0
            r2 = 1
            int r3 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
            if (r3 == 0) goto L_0x0036
            int r6 = android.support.v4.view.y.k(r6)
            if (r6 != r2) goto L_0x000f
            r6 = 1
            goto L_0x0010
        L_0x000f:
            r6 = 0
        L_0x0010:
            android.support.design.widget.SwipeDismissBehavior r3 = r5.f540c
            int r3 = r3.f
            r4 = 2
            if (r3 != r4) goto L_0x0018
            return r2
        L_0x0018:
            if (r3 != 0) goto L_0x0027
            if (r6 == 0) goto L_0x0021
            int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
            if (r6 >= 0) goto L_0x0026
            goto L_0x0025
        L_0x0021:
            int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
            if (r6 <= 0) goto L_0x0026
        L_0x0025:
            r1 = 1
        L_0x0026:
            return r1
        L_0x0027:
            if (r3 != r2) goto L_0x0035
            if (r6 == 0) goto L_0x0030
            int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
            if (r6 <= 0) goto L_0x0035
            goto L_0x0034
        L_0x0030:
            int r6 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
            if (r6 >= 0) goto L_0x0035
        L_0x0034:
            r1 = 1
        L_0x0035:
            return r1
        L_0x0036:
            int r7 = r6.getLeft()
            int r0 = r5.f538a
            int r7 = r7 - r0
            int r6 = r6.getWidth()
            float r6 = (float) r6
            android.support.design.widget.SwipeDismissBehavior r0 = r5.f540c
            float r0 = r0.g
            float r6 = r6 * r0
            int r6 = java.lang.Math.round(r6)
            int r7 = java.lang.Math.abs(r7)
            if (r7 < r6) goto L_0x0053
            r1 = 1
        L_0x0053:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.U.a(android.view.View, float):boolean");
    }

    public int a(View view) {
        return view.getWidth();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0026, code lost:
        if (r5 != false) goto L_0x001c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0010, code lost:
        if (r5 != false) goto L_0x0012;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x001c, code lost:
        r5 = r2.f538a;
        r3 = r3.getWidth() + r5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int a(android.view.View r3, int r4, int r5) {
        /*
            r2 = this;
            int r5 = android.support.v4.view.y.k(r3)
            r0 = 1
            if (r5 != r0) goto L_0x0009
            r5 = 1
            goto L_0x000a
        L_0x0009:
            r5 = 0
        L_0x000a:
            android.support.design.widget.SwipeDismissBehavior r1 = r2.f540c
            int r1 = r1.f
            if (r1 != 0) goto L_0x0024
            if (r5 == 0) goto L_0x001c
        L_0x0012:
            int r5 = r2.f538a
            int r3 = r3.getWidth()
            int r5 = r5 - r3
            int r3 = r2.f538a
            goto L_0x0037
        L_0x001c:
            int r5 = r2.f538a
            int r3 = r3.getWidth()
            int r3 = r3 + r5
            goto L_0x0037
        L_0x0024:
            if (r1 != r0) goto L_0x0029
            if (r5 == 0) goto L_0x0012
            goto L_0x001c
        L_0x0029:
            int r5 = r2.f538a
            int r0 = r3.getWidth()
            int r5 = r5 - r0
            int r0 = r2.f538a
            int r3 = r3.getWidth()
            int r3 = r3 + r0
        L_0x0037:
            int r3 = android.support.design.widget.SwipeDismissBehavior.a((int) r5, (int) r4, (int) r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.U.a(android.view.View, int, int):int");
    }

    public void a(View view, float f, float f2) {
        boolean z;
        int i;
        SwipeDismissBehavior.a aVar;
        this.f539b = -1;
        int width = view.getWidth();
        if (a(view, f)) {
            int left = view.getLeft();
            int i2 = this.f538a;
            i = left < i2 ? i2 - width : i2 + width;
            z = true;
        } else {
            i = this.f538a;
            z = false;
        }
        if (this.f540c.f503a.d(i, view.getTop())) {
            y.a(view, (Runnable) new SwipeDismissBehavior.b(view, z));
        } else if (z && (aVar = this.f540c.f504b) != null) {
            aVar.a(view);
        }
    }

    public void a(View view, int i) {
        this.f539b = i;
        this.f538a = view.getLeft();
        ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
    }

    public void a(View view, int i, int i2, int i3, int i4) {
        float width = ((float) this.f538a) + (((float) view.getWidth()) * this.f540c.h);
        float width2 = ((float) this.f538a) + (((float) view.getWidth()) * this.f540c.i);
        float f = (float) i;
        if (f <= width) {
            view.setAlpha(1.0f);
        } else if (f >= width2) {
            view.setAlpha(0.0f);
        } else {
            view.setAlpha(SwipeDismissBehavior.a(0.0f, 1.0f - SwipeDismissBehavior.b(width, width2, f), 1.0f));
        }
    }

    public int b(View view, int i, int i2) {
        return view.getTop();
    }

    public boolean b(View view, int i) {
        return this.f539b == -1 && this.f540c.a(view);
    }

    public void c(int i) {
        SwipeDismissBehavior.a aVar = this.f540c.f504b;
        if (aVar != null) {
            aVar.a(i);
        }
    }
}
