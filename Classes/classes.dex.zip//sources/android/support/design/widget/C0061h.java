package android.support.design.widget;

import android.os.Bundle;
import android.support.v4.view.C0107d;
import android.support.v4.view.a.c;
import android.view.View;

/* renamed from: android.support.design.widget.h  reason: case insensitive filesystem */
class C0061h extends C0107d {

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ BaseTransientBottomBar f570c;

    C0061h(BaseTransientBottomBar baseTransientBottomBar) {
        this.f570c = baseTransientBottomBar;
    }

    public void a(View view, c cVar) {
        super.a(view, cVar);
        cVar.a(1048576);
        cVar.f(true);
    }

    public boolean a(View view, int i, Bundle bundle) {
        if (i != 1048576) {
            return super.a(view, i, bundle);
        }
        this.f570c.c();
        return true;
    }
}
