package android.support.design.widget;

import android.view.View;

class aa implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ TextInputLayout f552a;

    aa(TextInputLayout textInputLayout) {
        this.f552a = textInputLayout;
    }

    public void onClick(View view) {
        this.f552a.a(false);
    }
}
