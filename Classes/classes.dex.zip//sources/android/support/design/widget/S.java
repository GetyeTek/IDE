package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class S extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ T f499a;

    S(T t) {
        this.f499a = t;
    }

    public void onAnimationEnd(Animator animator) {
        T t = this.f499a;
        if (t.f511c == animator) {
            t.f511c = null;
        }
    }
}
