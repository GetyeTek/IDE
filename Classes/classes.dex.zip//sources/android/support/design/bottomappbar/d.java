package android.support.design.bottomappbar;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.bottomappbar.BottomAppBar;

class d implements Parcelable.ClassLoaderCreator<BottomAppBar.a> {
    d() {
    }

    public BottomAppBar.a createFromParcel(Parcel parcel) {
        return new BottomAppBar.a(parcel, (ClassLoader) null);
    }

    public BottomAppBar.a createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new BottomAppBar.a(parcel, classLoader);
    }

    public BottomAppBar.a[] newArray(int i) {
        return new BottomAppBar.a[i];
    }
}
