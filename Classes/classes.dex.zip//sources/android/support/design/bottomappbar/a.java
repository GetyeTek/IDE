package android.support.design.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class a extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BottomAppBar f384a;

    a(BottomAppBar bottomAppBar) {
        this.f384a = bottomAppBar;
    }

    public void onAnimationEnd(Animator animator) {
        Animator unused = this.f384a.T = null;
    }
}
