package android.support.design.bottomappbar;

import a.b.c.g.b;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.behavior.HideBottomViewOnScrollBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.C0106c;
import android.support.v4.view.y;
import android.support.v7.widget.ActionMenuView;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class BottomAppBar extends Toolbar implements CoordinatorLayout.a {
    private final int P;
    private final b Q;
    private final e R;
    private Animator S;
    /* access modifiers changed from: private */
    public Animator T;
    /* access modifiers changed from: private */
    public Animator U;
    private int V;
    private boolean W;
    private boolean aa;
    AnimatorListenerAdapter ba;

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {
        private final Rect d = new Rect();

        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        private boolean a(FloatingActionButton floatingActionButton, BottomAppBar bottomAppBar) {
            ((CoordinatorLayout.e) floatingActionButton.getLayoutParams()).d = 17;
            bottomAppBar.a(floatingActionButton);
            return true;
        }

        /* access modifiers changed from: protected */
        public void a(BottomAppBar bottomAppBar) {
            super.a(bottomAppBar);
            FloatingActionButton a2 = bottomAppBar.t();
            if (a2 != null) {
                a2.a(this.d);
                a2.clearAnimation();
                a2.animate().translationY(((float) (-a2.getPaddingBottom())) + ((float) (a2.getMeasuredHeight() - this.d.height()))).setInterpolator(a.b.c.a.a.f19c).setDuration(175);
            }
        }

        public boolean a(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, int i) {
            FloatingActionButton a2 = bottomAppBar.t();
            if (a2 != null) {
                a(a2, bottomAppBar);
                a2.b(this.d);
                bottomAppBar.setFabDiameter(this.d.height());
            }
            if (bottomAppBar.u()) {
                coordinatorLayout.c((View) bottomAppBar, i);
                return super.a(coordinatorLayout, bottomAppBar, i);
            }
            BottomAppBar.c(bottomAppBar);
            throw null;
        }

        /* renamed from: a */
        public boolean b(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, View view, View view2, int i, int i2) {
            return bottomAppBar.getHideOnScroll() && super.b(coordinatorLayout, bottomAppBar, view, view2, i, i2);
        }

        /* access modifiers changed from: protected */
        public void b(BottomAppBar bottomAppBar) {
            super.b(bottomAppBar);
            FloatingActionButton a2 = bottomAppBar.t();
            if (a2 != null) {
                a2.clearAnimation();
                a2.animate().translationY(bottomAppBar.getFabTranslationY()).setInterpolator(a.b.c.a.a.d).setDuration(225);
            }
        }
    }

    static class a extends C0106c {
        public static final Parcelable.Creator<a> CREATOR = new d();

        /* renamed from: c  reason: collision with root package name */
        int f383c;
        boolean d;

        public a(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f383c = parcel.readInt();
            this.d = parcel.readInt() != 0;
        }

        public a(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f383c);
            parcel.writeInt(this.d ? 1 : 0);
        }
    }

    private float a(boolean z) {
        FloatingActionButton t = t();
        if (t == null) {
            return 0.0f;
        }
        Rect rect = new Rect();
        t.a(rect);
        float height = (float) rect.height();
        if (height == 0.0f) {
            height = (float) t.getMeasuredHeight();
        }
        float height2 = (float) (t.getHeight() - rect.height());
        float height3 = (-getCradleVerticalOffset()) + (height / 2.0f) + ((float) (t.getHeight() - rect.bottom));
        float paddingBottom = height2 - ((float) t.getPaddingBottom());
        float f = (float) (-getMeasuredHeight());
        if (z) {
            paddingBottom = height3;
        }
        return f + paddingBottom;
    }

    private void a(int i, List<Animator> list) {
        if (this.aa) {
            float[] fArr = new float[2];
            this.R.e();
            throw null;
        }
    }

    private void a(int i, boolean z) {
        if (y.y(this)) {
            Animator animator = this.U;
            if (animator != null) {
                animator.cancel();
            }
            ArrayList arrayList = new ArrayList();
            if (!v()) {
                i = 0;
                z = false;
            }
            a(i, z, (List<Animator>) arrayList);
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(arrayList);
            this.U = animatorSet;
            this.U.addListener(new b(this));
            this.U.start();
        }
    }

    private void a(int i, boolean z, List<Animator> list) {
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView != null) {
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{1.0f});
            if ((this.aa || (z && v())) && (this.V == 1 || i == 1)) {
                ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{0.0f});
                ofFloat2.addListener(new c(this, actionMenuView, i, z));
                AnimatorSet animatorSet = new AnimatorSet();
                animatorSet.setDuration(150);
                animatorSet.playSequentially(new Animator[]{ofFloat2, ofFloat});
                list.add(animatorSet);
            } else if (actionMenuView.getAlpha() < 1.0f) {
                list.add(ofFloat);
            }
        }
    }

    /* access modifiers changed from: private */
    public void a(FloatingActionButton floatingActionButton) {
        b(floatingActionButton);
        floatingActionButton.a((Animator.AnimatorListener) this.ba);
        floatingActionButton.b((Animator.AnimatorListener) this.ba);
    }

    /* access modifiers changed from: private */
    public void a(ActionMenuView actionMenuView, int i, boolean z) {
        boolean z2 = y.k(this) == 1;
        int i2 = 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if ((childAt.getLayoutParams() instanceof Toolbar.b) && (((Toolbar.b) childAt.getLayoutParams()).f993a & 8388615) == 8388611) {
                i2 = Math.max(i2, z2 ? childAt.getLeft() : childAt.getRight());
            }
        }
        actionMenuView.setTranslationX((i != 1 || !z) ? 0.0f : (float) (i2 - (z2 ? actionMenuView.getRight() : actionMenuView.getLeft())));
    }

    private void b(int i, List<Animator> list) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(t(), "translationX", new float[]{(float) c(i)});
        ofFloat.setDuration(300);
        list.add(ofFloat);
    }

    private void b(FloatingActionButton floatingActionButton) {
        floatingActionButton.c((Animator.AnimatorListener) this.ba);
        floatingActionButton.d(this.ba);
    }

    private int c(int i) {
        int i2 = 1;
        boolean z = y.k(this) == 1;
        if (i != 1) {
            return 0;
        }
        int measuredWidth = (getMeasuredWidth() / 2) - this.P;
        if (z) {
            i2 = -1;
        }
        return measuredWidth * i2;
    }

    static /* synthetic */ void c(BottomAppBar bottomAppBar) {
        bottomAppBar.w();
        throw null;
    }

    private void d(int i) {
        if (this.V != i && y.y(this)) {
            Animator animator = this.T;
            if (animator != null) {
                animator.cancel();
            }
            ArrayList arrayList = new ArrayList();
            a(i, (List<Animator>) arrayList);
            b(i, (List<Animator>) arrayList);
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(arrayList);
            this.T = animatorSet;
            this.T.addListener(new a(this));
            this.T.start();
        }
    }

    private ActionMenuView getActionMenuView() {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt instanceof ActionMenuView) {
                return (ActionMenuView) childAt;
            }
        }
        return null;
    }

    private float getFabTranslationX() {
        return (float) c(this.V);
    }

    /* access modifiers changed from: private */
    public float getFabTranslationY() {
        return a(this.aa);
    }

    private void s() {
        Animator animator = this.S;
        if (animator != null) {
            animator.cancel();
        }
        Animator animator2 = this.U;
        if (animator2 != null) {
            animator2.cancel();
        }
        Animator animator3 = this.T;
        if (animator3 != null) {
            animator3.cancel();
        }
    }

    /* access modifiers changed from: private */
    public FloatingActionButton t() {
        if (!(getParent() instanceof CoordinatorLayout)) {
            return null;
        }
        for (View next : ((CoordinatorLayout) getParent()).c((View) this)) {
            if (next instanceof FloatingActionButton) {
                return (FloatingActionButton) next;
            }
        }
        return null;
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000a, code lost:
        r0 = r1.U;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0014, code lost:
        r0 = r1.T;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean u() {
        /*
            r1 = this;
            android.animation.Animator r0 = r1.S
            if (r0 == 0) goto L_0x000a
            boolean r0 = r0.isRunning()
            if (r0 != 0) goto L_0x001e
        L_0x000a:
            android.animation.Animator r0 = r1.U
            if (r0 == 0) goto L_0x0014
            boolean r0 = r0.isRunning()
            if (r0 != 0) goto L_0x001e
        L_0x0014:
            android.animation.Animator r0 = r1.T
            if (r0 == 0) goto L_0x0020
            boolean r0 = r0.isRunning()
            if (r0 == 0) goto L_0x0020
        L_0x001e:
            r0 = 1
            goto L_0x0021
        L_0x0020:
            r0 = 0
        L_0x0021:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.bottomappbar.BottomAppBar.u():boolean");
    }

    private boolean v() {
        FloatingActionButton t = t();
        return t != null && t.b();
    }

    private void w() {
        this.R.d(getFabTranslationX());
        throw null;
    }

    public ColorStateList getBackgroundTint() {
        this.Q.a();
        throw null;
    }

    public CoordinatorLayout.b<BottomAppBar> getBehavior() {
        return new Behavior();
    }

    public float getCradleVerticalOffset() {
        this.R.a();
        throw null;
    }

    public int getFabAlignmentMode() {
        return this.V;
    }

    public float getFabCradleMargin() {
        this.R.b();
        throw null;
    }

    public float getFabCradleRoundedCornerRadius() {
        this.R.c();
        throw null;
    }

    public boolean getHideOnScroll() {
        return this.W;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        s();
        w();
        throw null;
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof a)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        a aVar = (a) parcelable;
        super.onRestoreInstanceState(aVar.a());
        this.V = aVar.f383c;
        this.aa = aVar.d;
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        a aVar = new a(super.onSaveInstanceState());
        aVar.f383c = this.V;
        aVar.d = this.aa;
        return aVar;
    }

    public void setBackgroundTint(ColorStateList colorStateList) {
        android.support.v4.graphics.drawable.a.a((Drawable) this.Q, colorStateList);
    }

    public void setCradleVerticalOffset(float f) {
        if (f != getCradleVerticalOffset()) {
            this.R.a(f);
            throw null;
        }
    }

    public void setFabAlignmentMode(int i) {
        d(i);
        a(i, this.aa);
        this.V = i;
    }

    public void setFabCradleMargin(float f) {
        if (f != getFabCradleMargin()) {
            this.R.b(f);
            throw null;
        }
    }

    public void setFabCradleRoundedCornerRadius(float f) {
        if (f != getFabCradleRoundedCornerRadius()) {
            this.R.c(f);
            throw null;
        }
    }

    /* access modifiers changed from: package-private */
    public void setFabDiameter(int i) {
        this.R.d();
        throw null;
    }

    public void setHideOnScroll(boolean z) {
        this.W = z;
    }

    public void setSubtitle(CharSequence charSequence) {
    }

    public void setTitle(CharSequence charSequence) {
    }
}
