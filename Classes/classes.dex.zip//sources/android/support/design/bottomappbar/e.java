package android.support.design.bottomappbar;

import a.b.c.g.a;

public class e extends a {
    /* access modifiers changed from: package-private */
    public float a() {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public void a(float f) {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public float b() {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public void b(float f) {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public float c() {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public void c(float f) {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public float d() {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public void d(float f) {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public float e() {
        throw null;
    }
}
