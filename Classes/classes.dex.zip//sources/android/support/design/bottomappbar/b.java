package android.support.design.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class b extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ BottomAppBar f385a;

    b(BottomAppBar bottomAppBar) {
        this.f385a = bottomAppBar;
    }

    public void onAnimationEnd(Animator animator) {
        Animator unused = this.f385a.U = null;
    }
}
