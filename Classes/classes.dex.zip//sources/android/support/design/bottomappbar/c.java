package android.support.design.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.support.v7.widget.ActionMenuView;

class c extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public boolean f386a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ActionMenuView f387b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ int f388c;
    final /* synthetic */ boolean d;
    final /* synthetic */ BottomAppBar e;

    c(BottomAppBar bottomAppBar, ActionMenuView actionMenuView, int i, boolean z) {
        this.e = bottomAppBar;
        this.f387b = actionMenuView;
        this.f388c = i;
        this.d = z;
    }

    public void onAnimationCancel(Animator animator) {
        this.f386a = true;
    }

    public void onAnimationEnd(Animator animator) {
        if (!this.f386a) {
            this.e.a(this.f387b, this.f388c, this.d);
        }
    }
}
