package android.support.design.internal;

import a.b.c.k;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v4.view.N;
import android.support.v4.view.s;
import android.support.v4.view.y;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

public class j extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    Drawable f401a;

    /* renamed from: b  reason: collision with root package name */
    Rect f402b;

    /* renamed from: c  reason: collision with root package name */
    private Rect f403c;

    public j(Context context) {
        this(context, (AttributeSet) null);
    }

    public j(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public j(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f403c = new Rect();
        TypedArray a2 = k.a(context, attributeSet, k.ScrimInsetsFrameLayout, i, a.b.c.j.Widget_Design_ScrimInsetsFrameLayout, new int[0]);
        this.f401a = a2.getDrawable(k.ScrimInsetsFrameLayout_insetForeground);
        a2.recycle();
        setWillNotDraw(true);
        y.a((View) this, (s) new i(this));
    }

    /* access modifiers changed from: protected */
    public void a(N n) {
        throw null;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.f402b != null && this.f401a != null) {
            int save = canvas.save();
            canvas.translate((float) getScrollX(), (float) getScrollY());
            this.f403c.set(0, 0, width, this.f402b.top);
            this.f401a.setBounds(this.f403c);
            this.f401a.draw(canvas);
            this.f403c.set(0, height - this.f402b.bottom, width, height);
            this.f401a.setBounds(this.f403c);
            this.f401a.draw(canvas);
            Rect rect = this.f403c;
            Rect rect2 = this.f402b;
            rect.set(0, rect2.top, rect2.left, height - rect2.bottom);
            this.f401a.setBounds(this.f403c);
            this.f401a.draw(canvas);
            Rect rect3 = this.f403c;
            Rect rect4 = this.f402b;
            rect3.set(width - rect4.right, rect4.top, width, height - rect4.bottom);
            this.f401a.setBounds(this.f403c);
            this.f401a.draw(canvas);
            canvas.restoreToCount(save);
        }
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable drawable = this.f401a;
        if (drawable != null) {
            drawable.setCallback(this);
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Drawable drawable = this.f401a;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
    }
}
