package android.support.design.internal;

import android.os.Parcel;
import android.os.Parcelable;

class g implements Parcelable.ClassLoaderCreator<h> {
    g() {
    }

    public h createFromParcel(Parcel parcel) {
        return new h(parcel, (ClassLoader) null);
    }

    public h createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new h(parcel, classLoader);
    }

    public h[] newArray(int i) {
        return new h[i];
    }
}
