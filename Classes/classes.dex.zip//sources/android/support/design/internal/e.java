package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.N;
import android.support.v4.view.y;
import android.support.v7.view.menu.D;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.v;
import android.support.v7.view.menu.w;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class e implements v {

    /* renamed from: a  reason: collision with root package name */
    private NavigationMenuView f392a;

    /* renamed from: b  reason: collision with root package name */
    LinearLayout f393b;

    /* renamed from: c  reason: collision with root package name */
    private v.a f394c;
    l d;
    private int e;
    b f;
    LayoutInflater g;
    int h;
    boolean i;
    ColorStateList j;
    ColorStateList k;
    Drawable l;
    int m;
    int n;
    private int o;
    int p;
    final View.OnClickListener q = new d(this);

    private static class a extends j {
        public a(View view) {
            super(view);
        }
    }

    private class b extends RecyclerView.a<j> {

        /* renamed from: c  reason: collision with root package name */
        private final ArrayList<d> f395c = new ArrayList<>();
        private p d;
        private boolean e;

        b() {
            g();
        }

        private void a(int i, int i2) {
            while (i < i2) {
                ((f) this.f395c.get(i)).f399b = true;
                i++;
            }
        }

        private void g() {
            if (!this.e) {
                this.e = true;
                this.f395c.clear();
                this.f395c.add(new c());
                int size = e.this.d.n().size();
                int i = -1;
                boolean z = false;
                int i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    p pVar = e.this.d.n().get(i3);
                    if (pVar.isChecked()) {
                        a(pVar);
                    }
                    if (pVar.isCheckable()) {
                        pVar.c(false);
                    }
                    if (pVar.hasSubMenu()) {
                        SubMenu subMenu = pVar.getSubMenu();
                        if (subMenu.hasVisibleItems()) {
                            if (i3 != 0) {
                                this.f395c.add(new C0010e(e.this.p, 0));
                            }
                            this.f395c.add(new f(pVar));
                            int size2 = this.f395c.size();
                            int size3 = subMenu.size();
                            boolean z2 = false;
                            for (int i4 = 0; i4 < size3; i4++) {
                                p pVar2 = (p) subMenu.getItem(i4);
                                if (pVar2.isVisible()) {
                                    if (!z2 && pVar2.getIcon() != null) {
                                        z2 = true;
                                    }
                                    if (pVar2.isCheckable()) {
                                        pVar2.c(false);
                                    }
                                    if (pVar.isChecked()) {
                                        a(pVar);
                                    }
                                    this.f395c.add(new f(pVar2));
                                }
                            }
                            if (z2) {
                                a(size2, this.f395c.size());
                            }
                        }
                    } else {
                        int groupId = pVar.getGroupId();
                        if (groupId != i) {
                            i2 = this.f395c.size();
                            boolean z3 = pVar.getIcon() != null;
                            if (i3 != 0) {
                                i2++;
                                ArrayList<d> arrayList = this.f395c;
                                int i5 = e.this.p;
                                arrayList.add(new C0010e(i5, i5));
                            }
                            z = z3;
                        } else if (!z && pVar.getIcon() != null) {
                            a(i2, this.f395c.size());
                            z = true;
                        }
                        f fVar = new f(pVar);
                        fVar.f399b = z;
                        this.f395c.add(fVar);
                        i = groupId;
                    }
                }
                this.e = false;
            }
        }

        public int a() {
            return this.f395c.size();
        }

        public long a(int i) {
            return (long) i;
        }

        public void a(Bundle bundle) {
            p a2;
            View actionView;
            h hVar;
            p a3;
            int i = bundle.getInt("android:menu:checked", 0);
            if (i != 0) {
                this.e = true;
                int size = this.f395c.size();
                int i2 = 0;
                while (true) {
                    if (i2 >= size) {
                        break;
                    }
                    d dVar = this.f395c.get(i2);
                    if ((dVar instanceof f) && (a3 = ((f) dVar).a()) != null && a3.getItemId() == i) {
                        a(a3);
                        break;
                    }
                    i2++;
                }
                this.e = false;
                g();
            }
            SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:action_views");
            if (sparseParcelableArray != null) {
                int size2 = this.f395c.size();
                for (int i3 = 0; i3 < size2; i3++) {
                    d dVar2 = this.f395c.get(i3);
                    if (!(!(dVar2 instanceof f) || (a2 = ((f) dVar2).a()) == null || (actionView = a2.getActionView()) == null || (hVar = (h) sparseParcelableArray.get(a2.getItemId())) == null)) {
                        actionView.restoreHierarchyState(hVar);
                    }
                }
            }
        }

        /* renamed from: a */
        public void d(j jVar) {
            if (jVar instanceof g) {
                ((NavigationMenuItemView) jVar.f1249b).b();
            }
        }

        /* renamed from: a */
        public void b(j jVar, int i) {
            int b2 = b(i);
            if (b2 == 0) {
                NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView) jVar.f1249b;
                navigationMenuItemView.setIconTintList(e.this.k);
                e eVar = e.this;
                if (eVar.i) {
                    navigationMenuItemView.setTextAppearance(eVar.h);
                }
                ColorStateList colorStateList = e.this.j;
                if (colorStateList != null) {
                    navigationMenuItemView.setTextColor(colorStateList);
                }
                Drawable drawable = e.this.l;
                y.a((View) navigationMenuItemView, drawable != null ? drawable.getConstantState().newDrawable() : null);
                f fVar = (f) this.f395c.get(i);
                navigationMenuItemView.setNeedsEmptyIcon(fVar.f399b);
                navigationMenuItemView.setHorizontalPadding(e.this.m);
                navigationMenuItemView.setIconPadding(e.this.n);
                navigationMenuItemView.a(fVar.a(), 0);
            } else if (b2 == 1) {
                ((TextView) jVar.f1249b).setText(((f) this.f395c.get(i)).a().getTitle());
            } else if (b2 == 2) {
                C0010e eVar2 = (C0010e) this.f395c.get(i);
                jVar.f1249b.setPadding(0, eVar2.b(), 0, eVar2.a());
            }
        }

        public void a(p pVar) {
            if (this.d != pVar && pVar.isCheckable()) {
                p pVar2 = this.d;
                if (pVar2 != null) {
                    pVar2.setChecked(false);
                }
                this.d = pVar;
                pVar.setChecked(true);
            }
        }

        public void a(boolean z) {
            this.e = z;
        }

        public int b(int i) {
            d dVar = this.f395c.get(i);
            if (dVar instanceof C0010e) {
                return 2;
            }
            if (dVar instanceof c) {
                return 3;
            }
            if (dVar instanceof f) {
                return ((f) dVar).a().hasSubMenu() ? 1 : 0;
            }
            throw new RuntimeException("Unknown item type.");
        }

        public j b(ViewGroup viewGroup, int i) {
            if (i == 0) {
                e eVar = e.this;
                return new g(eVar.g, viewGroup, eVar.q);
            } else if (i == 1) {
                return new i(e.this.g, viewGroup);
            } else {
                if (i == 2) {
                    return new h(e.this.g, viewGroup);
                }
                if (i != 3) {
                    return null;
                }
                return new a(e.this.f393b);
            }
        }

        public Bundle d() {
            Bundle bundle = new Bundle();
            p pVar = this.d;
            if (pVar != null) {
                bundle.putInt("android:menu:checked", pVar.getItemId());
            }
            SparseArray sparseArray = new SparseArray();
            int size = this.f395c.size();
            for (int i = 0; i < size; i++) {
                d dVar = this.f395c.get(i);
                if (dVar instanceof f) {
                    p a2 = ((f) dVar).a();
                    View actionView = a2 != null ? a2.getActionView() : null;
                    if (actionView != null) {
                        h hVar = new h();
                        actionView.saveHierarchyState(hVar);
                        sparseArray.put(a2.getItemId(), hVar);
                    }
                }
            }
            bundle.putSparseParcelableArray("android:menu:action_views", sparseArray);
            return bundle;
        }

        public p e() {
            return this.d;
        }

        public void f() {
            g();
            c();
        }
    }

    private static class c implements d {
        c() {
        }
    }

    private interface d {
    }

    /* renamed from: android.support.design.internal.e$e  reason: collision with other inner class name */
    private static class C0010e implements d {

        /* renamed from: a  reason: collision with root package name */
        private final int f396a;

        /* renamed from: b  reason: collision with root package name */
        private final int f397b;

        public C0010e(int i, int i2) {
            this.f396a = i;
            this.f397b = i2;
        }

        public int a() {
            return this.f397b;
        }

        public int b() {
            return this.f396a;
        }
    }

    private static class f implements d {

        /* renamed from: a  reason: collision with root package name */
        private final p f398a;

        /* renamed from: b  reason: collision with root package name */
        boolean f399b;

        f(p pVar) {
            this.f398a = pVar;
        }

        public p a() {
            return this.f398a;
        }
    }

    private static class g extends j {
        public g(LayoutInflater layoutInflater, ViewGroup viewGroup, View.OnClickListener onClickListener) {
            super(layoutInflater.inflate(a.b.c.h.design_navigation_item, viewGroup, false));
            this.f1249b.setOnClickListener(onClickListener);
        }
    }

    private static class h extends j {
        public h(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(a.b.c.h.design_navigation_item_separator, viewGroup, false));
        }
    }

    private static class i extends j {
        public i(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(a.b.c.h.design_navigation_item_subheader, viewGroup, false));
        }
    }

    private static abstract class j extends RecyclerView.x {
        public j(View view) {
            super(view);
        }
    }

    public w a(ViewGroup viewGroup) {
        if (this.f392a == null) {
            this.f392a = (NavigationMenuView) this.g.inflate(a.b.c.h.design_navigation_menu, viewGroup, false);
            if (this.f == null) {
                this.f = new b();
            }
            this.f393b = (LinearLayout) this.g.inflate(a.b.c.h.design_navigation_item_header, this.f392a, false);
            this.f392a.setAdapter(this.f);
        }
        return this.f392a;
    }

    public View a(int i2) {
        return this.f393b.getChildAt(i2);
    }

    public void a(Context context, l lVar) {
        this.g = LayoutInflater.from(context);
        this.d = lVar;
        this.p = context.getResources().getDimensionPixelOffset(a.b.c.d.design_navigation_separator_vertical_padding);
    }

    public void a(ColorStateList colorStateList) {
        this.k = colorStateList;
        a(false);
    }

    public void a(Drawable drawable) {
        this.l = drawable;
        a(false);
    }

    public void a(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:list");
            if (sparseParcelableArray != null) {
                this.f392a.restoreHierarchyState(sparseParcelableArray);
            }
            Bundle bundle2 = bundle.getBundle("android:menu:adapter");
            if (bundle2 != null) {
                this.f.a(bundle2);
            }
            SparseArray sparseParcelableArray2 = bundle.getSparseParcelableArray("android:menu:header");
            if (sparseParcelableArray2 != null) {
                this.f393b.restoreHierarchyState(sparseParcelableArray2);
            }
        }
    }

    public void a(N n2) {
        int e2 = n2.e();
        if (this.o != e2) {
            this.o = e2;
            if (this.f393b.getChildCount() == 0) {
                NavigationMenuView navigationMenuView = this.f392a;
                navigationMenuView.setPadding(0, this.o, 0, navigationMenuView.getPaddingBottom());
            }
        }
        y.a((View) this.f393b, n2);
    }

    public void a(l lVar, boolean z) {
        v.a aVar = this.f394c;
        if (aVar != null) {
            aVar.a(lVar, z);
        }
    }

    public void a(p pVar) {
        this.f.a(pVar);
    }

    public void a(View view) {
        this.f393b.addView(view);
        NavigationMenuView navigationMenuView = this.f392a;
        navigationMenuView.setPadding(0, 0, 0, navigationMenuView.getPaddingBottom());
    }

    public void a(boolean z) {
        b bVar = this.f;
        if (bVar != null) {
            bVar.f();
        }
    }

    public boolean a() {
        return false;
    }

    public boolean a(D d2) {
        return false;
    }

    public boolean a(l lVar, p pVar) {
        return false;
    }

    public Parcelable b() {
        Bundle bundle = new Bundle();
        if (this.f392a != null) {
            SparseArray sparseArray = new SparseArray();
            this.f392a.saveHierarchyState(sparseArray);
            bundle.putSparseParcelableArray("android:menu:list", sparseArray);
        }
        b bVar = this.f;
        if (bVar != null) {
            bundle.putBundle("android:menu:adapter", bVar.d());
        }
        if (this.f393b != null) {
            SparseArray sparseArray2 = new SparseArray();
            this.f393b.saveHierarchyState(sparseArray2);
            bundle.putSparseParcelableArray("android:menu:header", sparseArray2);
        }
        return bundle;
    }

    public View b(int i2) {
        View inflate = this.g.inflate(i2, this.f393b, false);
        a(inflate);
        return inflate;
    }

    public void b(ColorStateList colorStateList) {
        this.j = colorStateList;
        a(false);
    }

    public void b(boolean z) {
        b bVar = this.f;
        if (bVar != null) {
            bVar.a(z);
        }
    }

    public boolean b(l lVar, p pVar) {
        return false;
    }

    public p c() {
        return this.f.e();
    }

    public void c(int i2) {
        this.e = i2;
    }

    public int d() {
        return this.f393b.getChildCount();
    }

    public void d(int i2) {
        this.m = i2;
        a(false);
    }

    public Drawable e() {
        return this.l;
    }

    public void e(int i2) {
        this.n = i2;
        a(false);
    }

    public int f() {
        return this.m;
    }

    public void f(int i2) {
        this.h = i2;
        this.i = true;
        a(false);
    }

    public int g() {
        return this.n;
    }

    public int getId() {
        return this.e;
    }

    public ColorStateList h() {
        return this.j;
    }

    public ColorStateList i() {
        return this.k;
    }
}
