package android.support.design.internal;

import android.content.Context;
import android.support.v7.view.menu.D;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.p;
import android.view.SubMenu;

public class b extends l {
    public b(Context context) {
        super(context);
    }

    public SubMenu addSubMenu(int i, int i2, int i3, CharSequence charSequence) {
        p pVar = (p) a(i, i2, i3, charSequence);
        f fVar = new f(e(), this, pVar);
        pVar.a((D) fVar);
        return fVar;
    }
}
