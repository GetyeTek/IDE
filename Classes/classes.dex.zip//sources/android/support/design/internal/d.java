package android.support.design.internal;

import android.support.v7.view.menu.p;
import android.support.v7.view.menu.v;
import android.view.MenuItem;
import android.view.View;

class d implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ e f391a;

    d(e eVar) {
        this.f391a = eVar;
    }

    public void onClick(View view) {
        this.f391a.b(true);
        p itemData = ((NavigationMenuItemView) view).getItemData();
        e eVar = this.f391a;
        boolean a2 = eVar.d.a((MenuItem) itemData, (v) eVar, 0);
        if (itemData != null && itemData.isCheckable() && a2) {
            this.f391a.f.a(itemData);
        }
        this.f391a.b(false);
        this.f391a.a(false);
    }
}
