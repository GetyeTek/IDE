package android.support.design.internal;

import android.support.v4.view.C0107d;
import android.view.View;

class c extends C0107d {

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ NavigationMenuItemView f390c;

    c(NavigationMenuItemView navigationMenuItemView) {
        this.f390c = navigationMenuItemView;
    }

    public void a(View view, android.support.v4.view.a.c cVar) {
        super.a(view, cVar);
        cVar.b(this.f390c.y);
    }
}
