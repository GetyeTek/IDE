package android.support.design.internal;

import android.graphics.Rect;
import android.support.v4.view.N;
import android.support.v4.view.s;
import android.support.v4.view.y;
import android.view.View;

class i implements s {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ j f400a;

    i(j jVar) {
        this.f400a = jVar;
    }

    public N a(View view, N n) {
        j jVar = this.f400a;
        if (jVar.f402b == null) {
            jVar.f402b = new Rect();
        }
        this.f400a.f402b.set(n.c(), n.e(), n.d(), n.b());
        this.f400a.a(n);
        this.f400a.setWillNotDraw(!n.f() || this.f400a.f401a == null);
        y.B(this.f400a);
        return n.a();
    }
}
