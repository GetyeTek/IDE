package android.support.design.internal;

import android.content.Context;
import android.support.v7.view.menu.D;
import android.support.v7.view.menu.l;
import android.support.v7.view.menu.p;

public class f extends D {
    public f(Context context, b bVar, p pVar) {
        super(context, bVar, pVar);
    }

    public void b(boolean z) {
        super.b(z);
        ((l) t()).b(z);
    }
}
