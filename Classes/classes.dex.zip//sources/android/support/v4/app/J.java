package android.support.v4.app;

import android.view.View;
import java.util.ArrayList;

class J implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ Object f606a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ W f607b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ View f608c;
    final /* synthetic */ C0090l d;
    final /* synthetic */ ArrayList e;
    final /* synthetic */ ArrayList f;
    final /* synthetic */ ArrayList g;
    final /* synthetic */ Object h;

    J(Object obj, W w, View view, C0090l lVar, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
        this.f606a = obj;
        this.f607b = w;
        this.f608c = view;
        this.d = lVar;
        this.e = arrayList;
        this.f = arrayList2;
        this.g = arrayList3;
        this.h = obj2;
    }

    public void run() {
        Object obj = this.f606a;
        if (obj != null) {
            this.f607b.b(obj, this.f608c);
            this.f.addAll(M.a(this.f607b, this.f606a, this.d, (ArrayList<View>) this.e, this.f608c));
        }
        if (this.g != null) {
            if (this.h != null) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(this.f608c);
                this.f607b.a(this.h, (ArrayList<View>) this.g, (ArrayList<View>) arrayList);
            }
            this.g.clear();
            this.g.add(this.f608c);
        }
    }
}
