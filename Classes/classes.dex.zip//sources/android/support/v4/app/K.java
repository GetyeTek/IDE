package android.support.v4.app;

import a.b.f.g.b;
import android.graphics.Rect;
import android.view.View;

class K implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0090l f609a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ C0090l f610b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ boolean f611c;
    final /* synthetic */ b d;
    final /* synthetic */ View e;
    final /* synthetic */ W f;
    final /* synthetic */ Rect g;

    K(C0090l lVar, C0090l lVar2, boolean z, b bVar, View view, W w, Rect rect) {
        this.f609a = lVar;
        this.f610b = lVar2;
        this.f611c = z;
        this.d = bVar;
        this.e = view;
        this.f = w;
        this.g = rect;
    }

    public void run() {
        M.a(this.f609a, this.f610b, this.f611c, (b<String, View>) this.d, false);
        View view = this.e;
        if (view != null) {
            this.f.a(view, this.g);
        }
    }
}
