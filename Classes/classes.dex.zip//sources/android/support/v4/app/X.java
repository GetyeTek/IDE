package android.support.v4.app;

import android.arch.lifecycle.f;
import android.arch.lifecycle.t;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class X {
    public static <T extends f & t> X a(T t) {
        return new LoaderManagerImpl(t, ((t) t).b());
    }

    public abstract void a();

    @Deprecated
    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);
}
