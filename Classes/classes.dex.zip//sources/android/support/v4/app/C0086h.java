package android.support.v4.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

/* renamed from: android.support.v4.app.h  reason: case insensitive filesystem */
public class C0086h extends C0090l implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    int Y = 0;
    int Z = 0;
    boolean aa = true;
    boolean ba = true;
    int ca = -1;
    Dialog da;
    boolean ea;
    boolean fa;
    boolean ga;

    public void M() {
        super.M();
        Dialog dialog = this.da;
        if (dialog != null) {
            this.ea = true;
            dialog.dismiss();
            this.da = null;
        }
    }

    public void N() {
        super.N();
        if (!this.ga && !this.fa) {
            this.fa = true;
        }
    }

    public void Q() {
        super.Q();
        Dialog dialog = this.da;
        if (dialog != null) {
            this.ea = false;
            dialog.show();
        }
    }

    public void R() {
        super.R();
        Dialog dialog = this.da;
        if (dialog != null) {
            dialog.hide();
        }
    }

    public int a(H h, String str) {
        this.fa = false;
        this.ga = true;
        h.a((C0090l) this, str);
        this.ea = false;
        this.ca = h.a();
        return this.ca;
    }

    public void a(Dialog dialog, int i) {
        if (!(i == 1 || i == 2)) {
            if (i == 3) {
                dialog.getWindow().addFlags(24);
            } else {
                return;
            }
        }
        dialog.requestWindowFeature(1);
    }

    public void a(Context context) {
        super.a(context);
        if (!this.ga) {
            this.fa = false;
        }
    }

    public void b(int i, int i2) {
        this.Y = i;
        int i3 = this.Y;
        if (i3 == 2 || i3 == 3) {
            this.Z = 16973913;
        }
        if (i2 != 0) {
            this.Z = i2;
        }
    }

    public void b(Bundle bundle) {
        Bundle bundle2;
        super.b(bundle);
        if (this.ba) {
            View z = z();
            if (z != null) {
                if (z.getParent() == null) {
                    this.da.setContentView(z);
                } else {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
            }
            C0093o d = d();
            if (d != null) {
                this.da.setOwnerActivity(d);
            }
            this.da.setCancelable(this.aa);
            this.da.setOnCancelListener(this);
            this.da.setOnDismissListener(this);
            if (bundle != null && (bundle2 = bundle.getBundle("android:savedDialogState")) != null) {
                this.da.onRestoreInstanceState(bundle2);
            }
        }
    }

    public void c(Bundle bundle) {
        super.c(bundle);
        this.ba = this.A == 0;
        if (bundle != null) {
            this.Y = bundle.getInt("android:style", 0);
            this.Z = bundle.getInt("android:theme", 0);
            this.aa = bundle.getBoolean("android:cancelable", true);
            this.ba = bundle.getBoolean("android:showsDialog", this.ba);
            this.ca = bundle.getInt("android:backStackId", -1);
        }
    }

    public LayoutInflater d(Bundle bundle) {
        Context c2;
        if (!this.ba) {
            return super.d(bundle);
        }
        this.da = n(bundle);
        Dialog dialog = this.da;
        if (dialog != null) {
            a(dialog, this.Y);
            c2 = this.da.getContext();
        } else {
            c2 = this.u.c();
        }
        return (LayoutInflater) c2.getSystemService("layout_inflater");
    }

    public void da() {
        i(false);
    }

    public void e(Bundle bundle) {
        Bundle onSaveInstanceState;
        super.e(bundle);
        Dialog dialog = this.da;
        if (!(dialog == null || (onSaveInstanceState = dialog.onSaveInstanceState()) == null)) {
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i = this.Y;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        int i2 = this.Z;
        if (i2 != 0) {
            bundle.putInt("android:theme", i2);
        }
        boolean z = this.aa;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.ba;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i3 = this.ca;
        if (i3 != -1) {
            bundle.putInt("android:backStackId", i3);
        }
    }

    public Dialog ea() {
        return this.da;
    }

    public int fa() {
        return this.Z;
    }

    /* access modifiers changed from: package-private */
    public void i(boolean z) {
        if (!this.fa) {
            this.fa = true;
            this.ga = false;
            Dialog dialog = this.da;
            if (dialog != null) {
                dialog.dismiss();
            }
            this.ea = true;
            if (this.ca >= 0) {
                p().a(this.ca, 1);
                this.ca = -1;
                return;
            }
            H a2 = p().a();
            a2.c(this);
            if (z) {
                a2.b();
            } else {
                a2.a();
            }
        }
    }

    public Dialog n(Bundle bundle) {
        return new Dialog(d(), fa());
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.ea) {
            i(true);
        }
    }
}
