package android.support.v4.app;

import android.transition.Transition;
import android.view.View;
import java.util.ArrayList;

class P implements Transition.TransitionListener {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ Object f632a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ArrayList f633b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ Object f634c;
    final /* synthetic */ ArrayList d;
    final /* synthetic */ Object e;
    final /* synthetic */ ArrayList f;
    final /* synthetic */ S g;

    P(S s, Object obj, ArrayList arrayList, Object obj2, ArrayList arrayList2, Object obj3, ArrayList arrayList3) {
        this.g = s;
        this.f632a = obj;
        this.f633b = arrayList;
        this.f634c = obj2;
        this.d = arrayList2;
        this.e = obj3;
        this.f = arrayList3;
    }

    public void onTransitionCancel(Transition transition) {
    }

    public void onTransitionEnd(Transition transition) {
    }

    public void onTransitionPause(Transition transition) {
    }

    public void onTransitionResume(Transition transition) {
    }

    public void onTransitionStart(Transition transition) {
        Object obj = this.f632a;
        if (obj != null) {
            this.g.a(obj, (ArrayList<View>) this.f633b, (ArrayList<View>) null);
        }
        Object obj2 = this.f634c;
        if (obj2 != null) {
            this.g.a(obj2, (ArrayList<View>) this.d, (ArrayList<View>) null);
        }
        Object obj3 = this.e;
        if (obj3 != null) {
            this.g.a(obj3, (ArrayList<View>) this.f, (ArrayList<View>) null);
        }
    }
}
