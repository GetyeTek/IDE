package android.support.v4.app;

import android.os.Parcelable;
import android.support.v4.view.t;
import android.view.View;
import android.view.ViewGroup;

public abstract class D extends t {

    /* renamed from: c  reason: collision with root package name */
    private final C0096s f600c;
    private H d = null;
    private C0090l e = null;

    public D(C0096s sVar) {
        this.f600c = sVar;
    }

    private static String a(int i, long j) {
        return "android:switcher:" + i + ":" + j;
    }

    public Object a(ViewGroup viewGroup, int i) {
        if (this.d == null) {
            this.d = this.f600c.a();
        }
        long d2 = d(i);
        C0090l a2 = this.f600c.a(a(viewGroup.getId(), d2));
        if (a2 != null) {
            this.d.a(a2);
        } else {
            a2 = c(i);
            this.d.a(viewGroup.getId(), a2, a(viewGroup.getId(), d2));
        }
        if (a2 != this.e) {
            a2.g(false);
            a2.h(false);
        }
        return a2;
    }

    public void a(Parcelable parcelable, ClassLoader classLoader) {
    }

    public void a(ViewGroup viewGroup) {
        H h = this.d;
        if (h != null) {
            h.c();
            this.d = null;
        }
    }

    public void a(ViewGroup viewGroup, int i, Object obj) {
        if (this.d == null) {
            this.d = this.f600c.a();
        }
        this.d.b((C0090l) obj);
    }

    public boolean a(View view, Object obj) {
        return ((C0090l) obj).z() == view;
    }

    public Parcelable b() {
        return null;
    }

    public void b(ViewGroup viewGroup) {
        if (viewGroup.getId() == -1) {
            throw new IllegalStateException("ViewPager with adapter " + this + " requires a view id");
        }
    }

    public void b(ViewGroup viewGroup, int i, Object obj) {
        C0090l lVar = (C0090l) obj;
        C0090l lVar2 = this.e;
        if (lVar != lVar2) {
            if (lVar2 != null) {
                lVar2.g(false);
                this.e.h(false);
            }
            lVar.g(true);
            lVar.h(true);
            this.e = lVar;
        }
    }

    public abstract C0090l c(int i);

    public long d(int i) {
        return (long) i;
    }
}
