package android.support.v4.app;

import android.arch.lifecycle.q;
import android.arch.lifecycle.r;
import android.support.v4.app.LoaderManagerImpl;

class Y implements r.a {
    Y() {
    }

    public <T extends q> T a(Class<T> cls) {
        return new LoaderManagerImpl.LoaderViewModel();
    }
}
