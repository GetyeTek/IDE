package android.support.v4.app;

import a.b.f.g.b;
import android.graphics.Rect;
import android.os.Build;
import android.support.v4.view.y;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

class M {

    /* renamed from: a  reason: collision with root package name */
    private static final int[] f621a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8};

    /* renamed from: b  reason: collision with root package name */
    private static final W f622b = (Build.VERSION.SDK_INT >= 21 ? new S() : null);

    /* renamed from: c  reason: collision with root package name */
    private static final W f623c = a();

    static class a {

        /* renamed from: a  reason: collision with root package name */
        public C0090l f624a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f625b;

        /* renamed from: c  reason: collision with root package name */
        public C0082d f626c;
        public C0090l d;
        public boolean e;
        public C0082d f;

        a() {
        }
    }

    private static b<String, String> a(int i, ArrayList<C0082d> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        ArrayList<String> arrayList3;
        ArrayList<String> arrayList4;
        b<String, String> bVar = new b<>();
        for (int i4 = i3 - 1; i4 >= i2; i4--) {
            C0082d dVar = arrayList.get(i4);
            if (dVar.b(i)) {
                boolean booleanValue = arrayList2.get(i4).booleanValue();
                ArrayList<String> arrayList5 = dVar.r;
                if (arrayList5 != null) {
                    int size = arrayList5.size();
                    if (booleanValue) {
                        arrayList3 = dVar.r;
                        arrayList4 = dVar.s;
                    } else {
                        ArrayList<String> arrayList6 = dVar.r;
                        arrayList3 = dVar.s;
                        arrayList4 = arrayList6;
                    }
                    for (int i5 = 0; i5 < size; i5++) {
                        String str = arrayList4.get(i5);
                        String str2 = arrayList3.get(i5);
                        String remove = bVar.remove(str2);
                        if (remove != null) {
                            bVar.put(str, remove);
                        } else {
                            bVar.put(str, str2);
                        }
                    }
                }
            }
        }
        return bVar;
    }

    static b<String, View> a(W w, b<String, String> bVar, Object obj, a aVar) {
        ba baVar;
        ArrayList<String> arrayList;
        String a2;
        C0090l lVar = aVar.f624a;
        View z = lVar.z();
        if (bVar.isEmpty() || obj == null || z == null) {
            bVar.clear();
            return null;
        }
        b<String, View> bVar2 = new b<>();
        w.a((Map<String, View>) bVar2, z);
        C0082d dVar = aVar.f626c;
        if (aVar.f625b) {
            baVar = lVar.o();
            arrayList = dVar.r;
        } else {
            baVar = lVar.m();
            arrayList = dVar.s;
        }
        if (arrayList != null) {
            bVar2.a(arrayList);
            bVar2.a(bVar.values());
        }
        if (baVar != null) {
            baVar.a(arrayList, bVar2);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = arrayList.get(size);
                View view = bVar2.get(str);
                if (view == null) {
                    String a3 = a(bVar, str);
                    if (a3 != null) {
                        bVar.remove(a3);
                    }
                } else if (!str.equals(y.q(view)) && (a2 = a(bVar, str)) != null) {
                    bVar.put(a2, y.q(view));
                }
            }
        } else {
            a(bVar, bVar2);
        }
        return bVar2;
    }

    private static a a(a aVar, SparseArray<a> sparseArray, int i) {
        if (aVar != null) {
            return aVar;
        }
        a aVar2 = new a();
        sparseArray.put(i, aVar2);
        return aVar2;
    }

    private static W a() {
        try {
            return (W) Class.forName("a.b.e.t").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            return null;
        }
    }

    private static W a(C0090l lVar, C0090l lVar2) {
        ArrayList arrayList = new ArrayList();
        if (lVar != null) {
            Object n = lVar.n();
            if (n != null) {
                arrayList.add(n);
            }
            Object v = lVar.v();
            if (v != null) {
                arrayList.add(v);
            }
            Object x = lVar.x();
            if (x != null) {
                arrayList.add(x);
            }
        }
        if (lVar2 != null) {
            Object l = lVar2.l();
            if (l != null) {
                arrayList.add(l);
            }
            Object t = lVar2.t();
            if (t != null) {
                arrayList.add(t);
            }
            Object w = lVar2.w();
            if (w != null) {
                arrayList.add(w);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        W w2 = f622b;
        if (w2 != null && a(w2, (List<Object>) arrayList)) {
            return f622b;
        }
        W w3 = f623c;
        if (w3 != null && a(w3, (List<Object>) arrayList)) {
            return f623c;
        }
        if (f622b == null && f623c == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    static View a(b<String, View> bVar, a aVar, Object obj, boolean z) {
        ArrayList<String> arrayList;
        C0082d dVar = aVar.f626c;
        if (obj == null || bVar == null || (arrayList = dVar.r) == null || arrayList.isEmpty()) {
            return null;
        }
        return bVar.get((z ? dVar.r : dVar.s).get(0));
    }

    private static Object a(W w, C0090l lVar, C0090l lVar2, boolean z) {
        if (lVar == null || lVar2 == null) {
            return null;
        }
        return w.c(w.b(z ? lVar2.x() : lVar.w()));
    }

    private static Object a(W w, C0090l lVar, boolean z) {
        if (lVar == null) {
            return null;
        }
        return w.b(z ? lVar.t() : lVar.l());
    }

    private static Object a(W w, ViewGroup viewGroup, View view, b<String, String> bVar, a aVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        b<String, String> bVar2;
        Object obj3;
        Object obj4;
        Rect rect;
        W w2 = w;
        a aVar2 = aVar;
        ArrayList<View> arrayList3 = arrayList;
        Object obj5 = obj;
        C0090l lVar = aVar2.f624a;
        C0090l lVar2 = aVar2.d;
        if (lVar == null || lVar2 == null) {
            return null;
        }
        boolean z = aVar2.f625b;
        if (bVar.isEmpty()) {
            bVar2 = bVar;
            obj3 = null;
        } else {
            obj3 = a(w2, lVar, lVar2, z);
            bVar2 = bVar;
        }
        b<String, View> b2 = b(w2, bVar2, obj3, aVar2);
        if (bVar.isEmpty()) {
            obj4 = null;
        } else {
            arrayList3.addAll(b2.values());
            obj4 = obj3;
        }
        if (obj5 == null && obj2 == null && obj4 == null) {
            return null;
        }
        a(lVar, lVar2, z, b2, true);
        if (obj4 != null) {
            rect = new Rect();
            w2.b(obj4, view, arrayList3);
            a(w, obj4, obj2, b2, aVar2.e, aVar2.f);
            if (obj5 != null) {
                w2.a(obj5, rect);
            }
        } else {
            rect = null;
        }
        L l = r0;
        L l2 = new L(w, bVar, obj4, aVar, arrayList2, view, lVar, lVar2, z, arrayList, obj, rect);
        aa.a(viewGroup, l);
        return obj4;
    }

    private static Object a(W w, Object obj, Object obj2, Object obj3, C0090l lVar, boolean z) {
        return (obj == null || obj2 == null || lVar == null) ? true : z ? lVar.f() : lVar.e() ? w.b(obj2, obj, obj3) : w.a(obj2, obj, obj3);
    }

    private static String a(b<String, String> bVar, String str) {
        int size = bVar.size();
        for (int i = 0; i < size; i++) {
            if (str.equals(bVar.d(i))) {
                return bVar.b(i);
            }
        }
        return null;
    }

    static ArrayList<View> a(W w, Object obj, C0090l lVar, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View z = lVar.z();
        if (z != null) {
            w.a(arrayList2, z);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        w.a(obj, arrayList2);
        return arrayList2;
    }

    private static void a(b<String, String> bVar, b<String, View> bVar2) {
        for (int size = bVar.size() - 1; size >= 0; size--) {
            if (!bVar2.containsKey(bVar.d(size))) {
                bVar.c(size);
            }
        }
    }

    private static void a(W w, ViewGroup viewGroup, C0090l lVar, View view, ArrayList<View> arrayList, Object obj, ArrayList<View> arrayList2, Object obj2, ArrayList<View> arrayList3) {
        ViewGroup viewGroup2 = viewGroup;
        aa.a(viewGroup, new J(obj, w, view, lVar, arrayList, arrayList2, arrayList3, obj2));
    }

    private static void a(W w, Object obj, C0090l lVar, ArrayList<View> arrayList) {
        if (lVar != null && obj != null && lVar.m && lVar.C && lVar.Q) {
            lVar.f(true);
            w.a(obj, lVar.z(), arrayList);
            aa.a(lVar.J, new I(arrayList));
        }
    }

    private static void a(W w, Object obj, Object obj2, b<String, View> bVar, boolean z, C0082d dVar) {
        ArrayList<String> arrayList = dVar.r;
        if (arrayList != null && !arrayList.isEmpty()) {
            View view = bVar.get((z ? dVar.s : dVar.r).get(0));
            w.c(obj, view);
            if (obj2 != null) {
                w.c(obj2, view);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0041, code lost:
        if (r10.m != false) goto L_0x0094;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x0076, code lost:
        r1 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x0092, code lost:
        if (r10.C == false) goto L_0x0094;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x0094, code lost:
        r1 = true;
     */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x00a2  */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x00e7 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:96:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void a(android.support.v4.app.C0082d r16, android.support.v4.app.C0082d.a r17, android.util.SparseArray<android.support.v4.app.M.a> r18, boolean r19, boolean r20) {
        /*
            r0 = r16
            r1 = r17
            r2 = r18
            r3 = r19
            android.support.v4.app.l r10 = r1.f657b
            if (r10 != 0) goto L_0x000d
            return
        L_0x000d:
            int r11 = r10.A
            if (r11 != 0) goto L_0x0012
            return
        L_0x0012:
            if (r3 == 0) goto L_0x001b
            int[] r4 = f621a
            int r1 = r1.f656a
            r1 = r4[r1]
            goto L_0x001d
        L_0x001b:
            int r1 = r1.f656a
        L_0x001d:
            r4 = 0
            r5 = 1
            if (r1 == r5) goto L_0x0087
            r6 = 3
            if (r1 == r6) goto L_0x005f
            r6 = 4
            if (r1 == r6) goto L_0x0047
            r6 = 5
            if (r1 == r6) goto L_0x0035
            r6 = 6
            if (r1 == r6) goto L_0x005f
            r6 = 7
            if (r1 == r6) goto L_0x0087
            r1 = 0
        L_0x0031:
            r12 = 0
            r13 = 0
            goto L_0x009a
        L_0x0035:
            if (r20 == 0) goto L_0x0044
            boolean r1 = r10.Q
            if (r1 == 0) goto L_0x0096
            boolean r1 = r10.C
            if (r1 != 0) goto L_0x0096
            boolean r1 = r10.m
            if (r1 == 0) goto L_0x0096
            goto L_0x0094
        L_0x0044:
            boolean r1 = r10.C
            goto L_0x0097
        L_0x0047:
            if (r20 == 0) goto L_0x0056
            boolean r1 = r10.Q
            if (r1 == 0) goto L_0x0078
            boolean r1 = r10.m
            if (r1 == 0) goto L_0x0078
            boolean r1 = r10.C
            if (r1 == 0) goto L_0x0078
        L_0x0055:
            goto L_0x0076
        L_0x0056:
            boolean r1 = r10.m
            if (r1 == 0) goto L_0x0078
            boolean r1 = r10.C
            if (r1 != 0) goto L_0x0078
            goto L_0x0055
        L_0x005f:
            if (r20 == 0) goto L_0x007a
            boolean r1 = r10.m
            if (r1 != 0) goto L_0x0078
            android.view.View r1 = r10.K
            if (r1 == 0) goto L_0x0078
            int r1 = r1.getVisibility()
            if (r1 != 0) goto L_0x0078
            float r1 = r10.R
            r6 = 0
            int r1 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r1 < 0) goto L_0x0078
        L_0x0076:
            r1 = 1
            goto L_0x0083
        L_0x0078:
            r1 = 0
            goto L_0x0083
        L_0x007a:
            boolean r1 = r10.m
            if (r1 == 0) goto L_0x0078
            boolean r1 = r10.C
            if (r1 != 0) goto L_0x0078
            goto L_0x0076
        L_0x0083:
            r13 = r1
            r1 = 0
            r12 = 1
            goto L_0x009a
        L_0x0087:
            if (r20 == 0) goto L_0x008c
            boolean r1 = r10.P
            goto L_0x0097
        L_0x008c:
            boolean r1 = r10.m
            if (r1 != 0) goto L_0x0096
            boolean r1 = r10.C
            if (r1 != 0) goto L_0x0096
        L_0x0094:
            r1 = 1
            goto L_0x0097
        L_0x0096:
            r1 = 0
        L_0x0097:
            r4 = r1
            r1 = 1
            goto L_0x0031
        L_0x009a:
            java.lang.Object r6 = r2.get(r11)
            android.support.v4.app.M$a r6 = (android.support.v4.app.M.a) r6
            if (r4 == 0) goto L_0x00ac
            android.support.v4.app.M$a r6 = a((android.support.v4.app.M.a) r6, (android.util.SparseArray<android.support.v4.app.M.a>) r2, (int) r11)
            r6.f624a = r10
            r6.f625b = r3
            r6.f626c = r0
        L_0x00ac:
            r14 = r6
            r15 = 0
            if (r20 != 0) goto L_0x00d3
            if (r1 == 0) goto L_0x00d3
            if (r14 == 0) goto L_0x00ba
            android.support.v4.app.l r1 = r14.d
            if (r1 != r10) goto L_0x00ba
            r14.d = r15
        L_0x00ba:
            android.support.v4.app.z r4 = r0.f653a
            int r1 = r10.f673c
            if (r1 >= r5) goto L_0x00d3
            int r1 = r4.r
            if (r1 < r5) goto L_0x00d3
            boolean r1 = r0.t
            if (r1 != 0) goto L_0x00d3
            r4.g(r10)
            r6 = 1
            r7 = 0
            r8 = 0
            r9 = 0
            r5 = r10
            r4.a((android.support.v4.app.C0090l) r5, (int) r6, (int) r7, (int) r8, (boolean) r9)
        L_0x00d3:
            if (r13 == 0) goto L_0x00e5
            if (r14 == 0) goto L_0x00db
            android.support.v4.app.l r1 = r14.d
            if (r1 != 0) goto L_0x00e5
        L_0x00db:
            android.support.v4.app.M$a r14 = a((android.support.v4.app.M.a) r14, (android.util.SparseArray<android.support.v4.app.M.a>) r2, (int) r11)
            r14.d = r10
            r14.e = r3
            r14.f = r0
        L_0x00e5:
            if (r20 != 0) goto L_0x00f1
            if (r12 == 0) goto L_0x00f1
            if (r14 == 0) goto L_0x00f1
            android.support.v4.app.l r0 = r14.f624a
            if (r0 != r10) goto L_0x00f1
            r14.f624a = r15
        L_0x00f1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.M.a(android.support.v4.app.d, android.support.v4.app.d$a, android.util.SparseArray, boolean, boolean):void");
    }

    public static void a(C0082d dVar, SparseArray<a> sparseArray, boolean z) {
        int size = dVar.f654b.size();
        for (int i = 0; i < size; i++) {
            a(dVar, dVar.f654b.get(i), sparseArray, false, z);
        }
    }

    static void a(C0090l lVar, C0090l lVar2, boolean z, b<String, View> bVar, boolean z2) {
        ba m = z ? lVar2.m() : lVar.m();
        if (m != null) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int size = bVar == null ? 0 : bVar.size();
            for (int i = 0; i < size; i++) {
                arrayList2.add(bVar.b(i));
                arrayList.add(bVar.d(i));
            }
            if (z2) {
                m.b(arrayList2, arrayList, (List<View>) null);
            } else {
                m.a(arrayList2, arrayList, (List<View>) null);
            }
        }
    }

    private static void a(C0103z zVar, int i, a aVar, View view, b<String, String> bVar) {
        C0090l lVar;
        C0090l lVar2;
        W a2;
        Object obj;
        C0103z zVar2 = zVar;
        a aVar2 = aVar;
        View view2 = view;
        b<String, String> bVar2 = bVar;
        ViewGroup viewGroup = zVar2.t.a() ? (ViewGroup) zVar2.t.a(i) : null;
        if (viewGroup != null && (a2 = a(lVar2, lVar)) != null) {
            boolean z = aVar2.f625b;
            boolean z2 = aVar2.e;
            Object a3 = a(a2, (lVar = aVar2.f624a), z);
            Object b2 = b(a2, (lVar2 = aVar2.d), z2);
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = arrayList;
            Object obj2 = b2;
            W w = a2;
            Object a4 = a(a2, viewGroup, view, bVar, aVar, (ArrayList<View>) arrayList, (ArrayList<View>) arrayList2, a3, obj2);
            Object obj3 = a3;
            if (obj3 == null && a4 == null) {
                obj = obj2;
                if (obj == null) {
                    return;
                }
            } else {
                obj = obj2;
            }
            ArrayList<View> a5 = a(w, obj, lVar2, (ArrayList<View>) arrayList3, view2);
            Object obj4 = (a5 == null || a5.isEmpty()) ? null : obj;
            w.a(obj3, view2);
            Object a6 = a(w, obj3, obj4, a4, lVar, aVar2.f625b);
            if (a6 != null) {
                ArrayList arrayList4 = new ArrayList();
                W w2 = w;
                w2.a(a6, obj3, arrayList4, obj4, a5, a4, arrayList2);
                a(w2, viewGroup, lVar, view, (ArrayList<View>) arrayList2, obj3, (ArrayList<View>) arrayList4, obj4, a5);
                ArrayList arrayList5 = arrayList2;
                w.a((View) viewGroup, (ArrayList<View>) arrayList5, (Map<String, String>) bVar2);
                w.a(viewGroup, a6);
                w.a(viewGroup, (ArrayList<View>) arrayList5, (Map<String, String>) bVar2);
            }
        }
    }

    static void a(C0103z zVar, ArrayList<C0082d> arrayList, ArrayList<Boolean> arrayList2, int i, int i2, boolean z) {
        if (zVar.r >= 1) {
            SparseArray sparseArray = new SparseArray();
            for (int i3 = i; i3 < i2; i3++) {
                C0082d dVar = arrayList.get(i3);
                if (arrayList2.get(i3).booleanValue()) {
                    b(dVar, (SparseArray<a>) sparseArray, z);
                } else {
                    a(dVar, (SparseArray<a>) sparseArray, z);
                }
            }
            if (sparseArray.size() != 0) {
                View view = new View(zVar.s.c());
                int size = sparseArray.size();
                for (int i4 = 0; i4 < size; i4++) {
                    int keyAt = sparseArray.keyAt(i4);
                    b<String, String> a2 = a(keyAt, arrayList, arrayList2, i, i2);
                    a aVar = (a) sparseArray.valueAt(i4);
                    if (z) {
                        b(zVar, keyAt, aVar, view, a2);
                    } else {
                        a(zVar, keyAt, aVar, view, a2);
                    }
                }
            }
        }
    }

    static void a(ArrayList<View> arrayList, int i) {
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                arrayList.get(size).setVisibility(i);
            }
        }
    }

    private static void a(ArrayList<View> arrayList, b<String, View> bVar, Collection<String> collection) {
        for (int size = bVar.size() - 1; size >= 0; size--) {
            View d = bVar.d(size);
            if (collection.contains(y.q(d))) {
                arrayList.add(d);
            }
        }
    }

    private static boolean a(W w, List<Object> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            if (!w.a(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    private static b<String, View> b(W w, b<String, String> bVar, Object obj, a aVar) {
        ba baVar;
        ArrayList<String> arrayList;
        if (bVar.isEmpty() || obj == null) {
            bVar.clear();
            return null;
        }
        C0090l lVar = aVar.d;
        b<String, View> bVar2 = new b<>();
        w.a((Map<String, View>) bVar2, lVar.z());
        C0082d dVar = aVar.f;
        if (aVar.e) {
            baVar = lVar.m();
            arrayList = dVar.s;
        } else {
            baVar = lVar.o();
            arrayList = dVar.r;
        }
        bVar2.a(arrayList);
        if (baVar != null) {
            baVar.a(arrayList, bVar2);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = arrayList.get(size);
                View view = bVar2.get(str);
                if (view == null) {
                    bVar.remove(str);
                } else if (!str.equals(y.q(view))) {
                    bVar.put(y.q(view), bVar.remove(str));
                }
            }
        } else {
            bVar.a(bVar2.keySet());
        }
        return bVar2;
    }

    private static Object b(W w, C0090l lVar, boolean z) {
        if (lVar == null) {
            return null;
        }
        return w.b(z ? lVar.v() : lVar.n());
    }

    private static Object b(W w, ViewGroup viewGroup, View view, b<String, String> bVar, a aVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object obj3;
        Rect rect;
        View view2;
        W w2 = w;
        View view3 = view;
        b<String, String> bVar2 = bVar;
        a aVar2 = aVar;
        ArrayList<View> arrayList3 = arrayList;
        ArrayList<View> arrayList4 = arrayList2;
        Object obj4 = obj;
        C0090l lVar = aVar2.f624a;
        C0090l lVar2 = aVar2.d;
        if (lVar != null) {
            lVar.z().setVisibility(0);
        }
        if (lVar == null || lVar2 == null) {
            return null;
        }
        boolean z = aVar2.f625b;
        Object a2 = bVar.isEmpty() ? null : a(w, lVar, lVar2, z);
        b<String, View> b2 = b(w, bVar2, a2, aVar2);
        b<String, View> a3 = a(w, bVar2, a2, aVar2);
        if (bVar.isEmpty()) {
            if (b2 != null) {
                b2.clear();
            }
            if (a3 != null) {
                a3.clear();
            }
            obj3 = null;
        } else {
            a(arrayList3, b2, (Collection<String>) bVar.keySet());
            a(arrayList4, a3, bVar.values());
            obj3 = a2;
        }
        if (obj4 == null && obj2 == null && obj3 == null) {
            return null;
        }
        a(lVar, lVar2, z, b2, true);
        if (obj3 != null) {
            arrayList4.add(view3);
            w.b(obj3, view3, arrayList3);
            a(w, obj3, obj2, b2, aVar2.e, aVar2.f);
            Rect rect2 = new Rect();
            View a4 = a(a3, aVar2, obj4, z);
            if (a4 != null) {
                w.a(obj4, rect2);
            }
            rect = rect2;
            view2 = a4;
        } else {
            view2 = null;
            rect = null;
        }
        aa.a(viewGroup, new K(lVar, lVar2, z, a3, view2, w, rect));
        return obj3;
    }

    public static void b(C0082d dVar, SparseArray<a> sparseArray, boolean z) {
        if (dVar.f653a.t.a()) {
            for (int size = dVar.f654b.size() - 1; size >= 0; size--) {
                a(dVar, dVar.f654b.get(size), sparseArray, true, z);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x001e, code lost:
        r11 = r4.f624a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void b(android.support.v4.app.C0103z r17, int r18, android.support.v4.app.M.a r19, android.view.View r20, a.b.f.g.b<java.lang.String, java.lang.String> r21) {
        /*
            r0 = r17
            r4 = r19
            r9 = r20
            android.support.v4.app.p r1 = r0.t
            boolean r1 = r1.a()
            if (r1 == 0) goto L_0x0019
            android.support.v4.app.p r0 = r0.t
            r1 = r18
            android.view.View r0 = r0.a(r1)
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            goto L_0x001a
        L_0x0019:
            r0 = 0
        L_0x001a:
            r10 = r0
            if (r10 != 0) goto L_0x001e
            return
        L_0x001e:
            android.support.v4.app.l r11 = r4.f624a
            android.support.v4.app.l r12 = r4.d
            android.support.v4.app.W r13 = a((android.support.v4.app.C0090l) r12, (android.support.v4.app.C0090l) r11)
            if (r13 != 0) goto L_0x0029
            return
        L_0x0029:
            boolean r14 = r4.f625b
            boolean r0 = r4.e
            java.util.ArrayList r15 = new java.util.ArrayList
            r15.<init>()
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            java.lang.Object r7 = a((android.support.v4.app.W) r13, (android.support.v4.app.C0090l) r11, (boolean) r14)
            java.lang.Object r6 = b((android.support.v4.app.W) r13, (android.support.v4.app.C0090l) r12, (boolean) r0)
            r0 = r13
            r1 = r10
            r2 = r20
            r3 = r21
            r4 = r19
            r5 = r8
            r17 = r6
            r6 = r15
            r18 = r7
            r16 = r10
            r10 = r8
            r8 = r17
            java.lang.Object r8 = b(r0, r1, r2, r3, r4, r5, r6, r7, r8)
            r6 = r18
            if (r6 != 0) goto L_0x0061
            if (r8 != 0) goto L_0x0061
            r7 = r17
            if (r7 != 0) goto L_0x0063
            return
        L_0x0061:
            r7 = r17
        L_0x0063:
            java.util.ArrayList r5 = a((android.support.v4.app.W) r13, (java.lang.Object) r7, (android.support.v4.app.C0090l) r12, (java.util.ArrayList<android.view.View>) r10, (android.view.View) r9)
            java.util.ArrayList r9 = a((android.support.v4.app.W) r13, (java.lang.Object) r6, (android.support.v4.app.C0090l) r11, (java.util.ArrayList<android.view.View>) r15, (android.view.View) r9)
            r0 = 4
            a((java.util.ArrayList<android.view.View>) r9, (int) r0)
            r0 = r13
            r1 = r6
            r2 = r7
            r3 = r8
            r4 = r11
            r11 = r5
            r5 = r14
            java.lang.Object r14 = a((android.support.v4.app.W) r0, (java.lang.Object) r1, (java.lang.Object) r2, (java.lang.Object) r3, (android.support.v4.app.C0090l) r4, (boolean) r5)
            if (r14 == 0) goto L_0x00a4
            a((android.support.v4.app.W) r13, (java.lang.Object) r7, (android.support.v4.app.C0090l) r12, (java.util.ArrayList<android.view.View>) r11)
            java.util.ArrayList r12 = r13.a((java.util.ArrayList<android.view.View>) r15)
            r0 = r13
            r1 = r14
            r2 = r6
            r3 = r9
            r4 = r7
            r5 = r11
            r6 = r8
            r7 = r15
            r0.a(r1, r2, r3, r4, r5, r6, r7)
            r0 = r16
            r13.a((android.view.ViewGroup) r0, (java.lang.Object) r14)
            r1 = r13
            r2 = r0
            r3 = r10
            r4 = r15
            r5 = r12
            r6 = r21
            r1.a(r2, r3, r4, r5, r6)
            r0 = 0
            a((java.util.ArrayList<android.view.View>) r9, (int) r0)
            r13.b((java.lang.Object) r8, (java.util.ArrayList<android.view.View>) r10, (java.util.ArrayList<android.view.View>) r15)
        L_0x00a4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.M.b(android.support.v4.app.z, int, android.support.v4.app.M$a, android.view.View, a.b.f.g.b):void");
    }
}
