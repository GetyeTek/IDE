package android.support.v4.app;

import android.support.v4.view.y;
import android.view.View;
import java.util.ArrayList;

class T implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ int f637a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ArrayList f638b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ ArrayList f639c;
    final /* synthetic */ ArrayList d;
    final /* synthetic */ ArrayList e;
    final /* synthetic */ W f;

    T(W w, int i, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4) {
        this.f = w;
        this.f637a = i;
        this.f638b = arrayList;
        this.f639c = arrayList2;
        this.d = arrayList3;
        this.e = arrayList4;
    }

    public void run() {
        for (int i = 0; i < this.f637a; i++) {
            y.a((View) this.f638b.get(i), (String) this.f639c.get(i));
            y.a((View) this.d.get(i), (String) this.e.get(i));
        }
    }
}
