package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.app.C0090l;

/* renamed from: android.support.v4.app.m  reason: case insensitive filesystem */
class C0091m implements Parcelable.ClassLoaderCreator<C0090l.d> {
    C0091m() {
    }

    public C0090l.d createFromParcel(Parcel parcel) {
        return new C0090l.d(parcel, (ClassLoader) null);
    }

    public C0090l.d createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new C0090l.d(parcel, classLoader);
    }

    public C0090l.d[] newArray(int i) {
        return new C0090l.d[i];
    }
}
