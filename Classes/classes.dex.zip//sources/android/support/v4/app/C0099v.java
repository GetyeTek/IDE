package android.support.v4.app;

import android.support.v4.app.C0103z;
import android.view.ViewGroup;
import android.view.animation.Animation;

/* renamed from: android.support.v4.app.v  reason: case insensitive filesystem */
class C0099v extends C0103z.b {

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ ViewGroup f689b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ C0090l f690c;
    final /* synthetic */ C0103z d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0099v(C0103z zVar, Animation.AnimationListener animationListener, ViewGroup viewGroup, C0090l lVar) {
        super(animationListener);
        this.d = zVar;
        this.f689b = viewGroup;
        this.f690c = lVar;
    }

    public void onAnimationEnd(Animation animation) {
        super.onAnimationEnd(animation);
        this.f689b.post(new C0098u(this));
    }
}
