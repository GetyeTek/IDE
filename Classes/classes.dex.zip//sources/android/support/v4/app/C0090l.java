package android.support.v4.app;

import a.b.f.g.p;
import android.animation.Animator;
import android.app.Activity;
import android.arch.lifecycle.d;
import android.arch.lifecycle.f;
import android.arch.lifecycle.h;
import android.arch.lifecycle.m;
import android.arch.lifecycle.s;
import android.arch.lifecycle.t;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.C0112i;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

/* renamed from: android.support.v4.app.l  reason: case insensitive filesystem */
public class C0090l implements ComponentCallbacks, View.OnCreateContextMenuListener, f, t {

    /* renamed from: a  reason: collision with root package name */
    private static final p<String, Class<?>> f671a = new p<>();

    /* renamed from: b  reason: collision with root package name */
    static final Object f672b = new Object();
    int A;
    String B;
    boolean C;
    boolean D;
    boolean E;
    boolean F;
    boolean G;
    boolean H = true;
    boolean I;
    ViewGroup J;
    View K;
    View L;
    boolean M;
    boolean N = true;
    a O;
    boolean P;
    boolean Q;
    float R;
    LayoutInflater S;
    boolean T;
    h U = new h(this);
    h V;
    f W;
    m<f> X = new m<>();

    /* renamed from: c  reason: collision with root package name */
    int f673c = 0;
    Bundle d;
    SparseArray<Parcelable> e;
    Boolean f;
    int g = -1;
    String h;
    Bundle i;
    C0090l j;
    int k = -1;
    int l;
    boolean m;
    boolean n;
    boolean o;
    boolean p;
    boolean q;
    boolean r;
    int s;
    C0103z t;
    r u;
    C0103z v;
    A w;
    s x;
    C0090l y;
    int z;

    /* renamed from: android.support.v4.app.l$a */
    static class a {

        /* renamed from: a  reason: collision with root package name */
        View f674a;

        /* renamed from: b  reason: collision with root package name */
        Animator f675b;

        /* renamed from: c  reason: collision with root package name */
        int f676c;
        int d;
        int e;
        int f;
        Object g = null;
        Object h;
        Object i;
        Object j;
        Object k;
        Object l;
        Boolean m;
        Boolean n;
        ba o;
        ba p;
        boolean q;
        c r;
        boolean s;

        a() {
            Object obj = C0090l.f672b;
            this.h = obj;
            this.i = null;
            this.j = obj;
            this.k = null;
            this.l = obj;
            this.o = null;
            this.p = null;
        }
    }

    /* renamed from: android.support.v4.app.l$b */
    public static class b extends RuntimeException {
        public b(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* renamed from: android.support.v4.app.l$c */
    interface c {
        void a();

        void b();
    }

    /* renamed from: android.support.v4.app.l$d */
    public static class d implements Parcelable {
        public static final Parcelable.Creator<d> CREATOR = new C0091m();

        /* renamed from: a  reason: collision with root package name */
        final Bundle f677a;

        d(Bundle bundle) {
            this.f677a = bundle;
        }

        d(Parcel parcel, ClassLoader classLoader) {
            Bundle bundle;
            this.f677a = parcel.readBundle();
            if (classLoader != null && (bundle = this.f677a) != null) {
                bundle.setClassLoader(classLoader);
            }
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeBundle(this.f677a);
        }
    }

    public static C0090l a(Context context, String str, Bundle bundle) {
        try {
            Class<?> cls = f671a.get(str);
            if (cls == null) {
                cls = context.getClassLoader().loadClass(str);
                f671a.put(str, cls);
            }
            C0090l lVar = (C0090l) cls.getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(lVar.getClass().getClassLoader());
                lVar.m(bundle);
            }
            return lVar;
        } catch (ClassNotFoundException e2) {
            throw new b("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new b("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e3);
        } catch (IllegalAccessException e4) {
            throw new b("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an" + " empty constructor that is public", e4);
        } catch (NoSuchMethodException e5) {
            throw new b("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e5);
        } catch (InvocationTargetException e6) {
            throw new b("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e6);
        }
    }

    static boolean a(Context context, String str) {
        try {
            Class<?> cls = f671a.get(str);
            if (cls == null) {
                cls = context.getClassLoader().loadClass(str);
                f671a.put(str, cls);
            }
            return C0090l.class.isAssignableFrom(cls);
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    private a da() {
        if (this.O == null) {
            this.O = new a();
        }
        return this.O;
    }

    /* access modifiers changed from: package-private */
    public void A() {
        this.g = -1;
        this.h = null;
        this.m = false;
        this.n = false;
        this.o = false;
        this.p = false;
        this.q = false;
        this.s = 0;
        this.t = null;
        this.v = null;
        this.u = null;
        this.z = 0;
        this.A = 0;
        this.B = null;
        this.C = false;
        this.D = false;
        this.F = false;
    }

    /* access modifiers changed from: package-private */
    public void B() {
        if (this.u != null) {
            this.v = new C0103z();
            this.v.a(this.u, (C0094p) new C0088j(this), this);
            return;
        }
        throw new IllegalStateException("Fragment has not been attached yet.");
    }

    public final boolean C() {
        return this.u != null && this.m;
    }

    public final boolean D() {
        return this.C;
    }

    /* access modifiers changed from: package-private */
    public boolean E() {
        a aVar = this.O;
        if (aVar == null) {
            return false;
        }
        return aVar.s;
    }

    /* access modifiers changed from: package-private */
    public final boolean F() {
        return this.s > 0;
    }

    /* access modifiers changed from: package-private */
    public boolean G() {
        a aVar = this.O;
        if (aVar == null) {
            return false;
        }
        return aVar.q;
    }

    public final boolean H() {
        return this.f673c >= 4;
    }

    public final boolean I() {
        C0103z zVar = this.t;
        if (zVar == null) {
            return false;
        }
        return zVar.c();
    }

    /* access modifiers changed from: package-private */
    public void J() {
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.r();
        }
    }

    public void K() {
        boolean z2 = true;
        this.I = true;
        C0093o d2 = d();
        if (d2 == null || !d2.isChangingConfigurations()) {
            z2 = false;
        }
        s sVar = this.x;
        if (sVar != null && !z2) {
            sVar.a();
        }
    }

    public void L() {
    }

    public void M() {
        this.I = true;
    }

    public void N() {
        this.I = true;
    }

    public void O() {
        this.I = true;
    }

    public void P() {
        this.I = true;
    }

    public void Q() {
        this.I = true;
    }

    public void R() {
        this.I = true;
    }

    /* access modifiers changed from: package-private */
    public C0096s S() {
        return this.v;
    }

    /* access modifiers changed from: package-private */
    public void T() {
        this.U.b(d.a.ON_DESTROY);
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.g();
        }
        this.f673c = 0;
        this.I = false;
        this.T = false;
        K();
        if (this.I) {
            this.v = null;
            return;
        }
        throw new ca("Fragment " + this + " did not call through to super.onDestroy()");
    }

    /* access modifiers changed from: package-private */
    public void U() {
        if (this.K != null) {
            this.V.b(d.a.ON_DESTROY);
        }
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.h();
        }
        this.f673c = 1;
        this.I = false;
        M();
        if (this.I) {
            X.a(this).a();
            this.r = false;
            return;
        }
        throw new ca("Fragment " + this + " did not call through to super.onDestroyView()");
    }

    /* access modifiers changed from: package-private */
    public void V() {
        this.I = false;
        N();
        this.S = null;
        if (this.I) {
            C0103z zVar = this.v;
            if (zVar == null) {
                return;
            }
            if (this.F) {
                zVar.g();
                this.v = null;
                return;
            }
            throw new IllegalStateException("Child FragmentManager of " + this + " was not " + " destroyed and this fragment is not retaining instance");
        }
        throw new ca("Fragment " + this + " did not call through to super.onDetach()");
    }

    /* access modifiers changed from: package-private */
    public void W() {
        onLowMemory();
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.i();
        }
    }

    /* access modifiers changed from: package-private */
    public void X() {
        if (this.K != null) {
            this.V.b(d.a.ON_PAUSE);
        }
        this.U.b(d.a.ON_PAUSE);
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.j();
        }
        this.f673c = 3;
        this.I = false;
        O();
        if (!this.I) {
            throw new ca("Fragment " + this + " did not call through to super.onPause()");
        }
    }

    /* access modifiers changed from: package-private */
    public void Y() {
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.r();
            this.v.o();
        }
        this.f673c = 4;
        this.I = false;
        P();
        if (this.I) {
            C0103z zVar2 = this.v;
            if (zVar2 != null) {
                zVar2.k();
                this.v.o();
            }
            this.U.b(d.a.ON_RESUME);
            if (this.K != null) {
                this.V.b(d.a.ON_RESUME);
                return;
            }
            return;
        }
        throw new ca("Fragment " + this + " did not call through to super.onResume()");
    }

    /* access modifiers changed from: package-private */
    public void Z() {
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.r();
            this.v.o();
        }
        this.f673c = 3;
        this.I = false;
        Q();
        if (this.I) {
            C0103z zVar2 = this.v;
            if (zVar2 != null) {
                zVar2.l();
            }
            this.U.b(d.a.ON_START);
            if (this.K != null) {
                this.V.b(d.a.ON_START);
                return;
            }
            return;
        }
        throw new ca("Fragment " + this + " did not call through to super.onStart()");
    }

    public android.arch.lifecycle.d a() {
        return this.U;
    }

    /* access modifiers changed from: package-private */
    public C0090l a(String str) {
        if (str.equals(this.h)) {
            return this;
        }
        C0103z zVar = this.v;
        if (zVar != null) {
            return zVar.b(str);
        }
        return null;
    }

    @Deprecated
    public LayoutInflater a(Bundle bundle) {
        r rVar = this.u;
        if (rVar != null) {
            LayoutInflater f2 = rVar.f();
            j();
            C0103z zVar = this.v;
            zVar.p();
            C0112i.a(f2, zVar);
            return f2;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    public Animation a(int i2, boolean z2, int i3) {
        return null;
    }

    public final String a(int i2) {
        return u().getString(i2);
    }

    /* access modifiers changed from: package-private */
    public void a(int i2, int i3) {
        if (this.O != null || i2 != 0 || i3 != 0) {
            da();
            a aVar = this.O;
            aVar.e = i2;
            aVar.f = i3;
        }
    }

    public void a(int i2, int i3, Intent intent) {
    }

    /* access modifiers changed from: package-private */
    public final void a(int i2, C0090l lVar) {
        String str;
        StringBuilder sb;
        this.g = i2;
        if (lVar != null) {
            sb = new StringBuilder();
            sb.append(lVar.h);
            str = ":";
        } else {
            sb = new StringBuilder();
            str = "android:fragment:";
        }
        sb.append(str);
        sb.append(this.g);
        this.h = sb.toString();
    }

    public void a(int i2, String[] strArr, int[] iArr) {
    }

    /* access modifiers changed from: package-private */
    public void a(Animator animator) {
        da().f675b = animator;
    }

    @Deprecated
    public void a(Activity activity) {
        this.I = true;
    }

    @Deprecated
    public void a(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.I = true;
    }

    public void a(Context context) {
        this.I = true;
        r rVar = this.u;
        Activity b2 = rVar == null ? null : rVar.b();
        if (b2 != null) {
            this.I = false;
            a(b2);
        }
    }

    public void a(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.I = true;
        r rVar = this.u;
        Activity b2 = rVar == null ? null : rVar.b();
        if (b2 != null) {
            this.I = false;
            a(b2, attributeSet, bundle);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(Configuration configuration) {
        onConfigurationChanged(configuration);
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.a(configuration);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(c cVar) {
        da();
        c cVar2 = this.O.r;
        if (cVar != cVar2) {
            if (cVar == null || cVar2 == null) {
                a aVar = this.O;
                if (aVar.q) {
                    aVar.r = cVar;
                }
                if (cVar != null) {
                    cVar.a();
                    return;
                }
                return;
            }
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
    }

    public void a(d dVar) {
        Bundle bundle;
        if (this.g < 0) {
            if (dVar == null || (bundle = dVar.f677a) == null) {
                bundle = null;
            }
            this.d = bundle;
            return;
        }
        throw new IllegalStateException("Fragment already active");
    }

    public void a(C0090l lVar) {
    }

    public void a(Menu menu) {
    }

    public void a(Menu menu, MenuInflater menuInflater) {
    }

    /* access modifiers changed from: package-private */
    public void a(View view) {
        da().f674a = view;
    }

    public void a(View view, Bundle bundle) {
    }

    public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.z));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.A));
        printWriter.print(" mTag=");
        printWriter.println(this.B);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.f673c);
        printWriter.print(" mIndex=");
        printWriter.print(this.g);
        printWriter.print(" mWho=");
        printWriter.print(this.h);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.s);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.m);
        printWriter.print(" mRemoving=");
        printWriter.print(this.n);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.o);
        printWriter.print(" mInLayout=");
        printWriter.println(this.p);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.C);
        printWriter.print(" mDetached=");
        printWriter.print(this.D);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.H);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.G);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.E);
        printWriter.print(" mRetaining=");
        printWriter.print(this.F);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.N);
        if (this.t != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.t);
        }
        if (this.u != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.u);
        }
        if (this.y != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.y);
        }
        if (this.i != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.i);
        }
        if (this.d != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.d);
        }
        if (this.e != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.e);
        }
        if (this.j != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(this.j);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.l);
        }
        if (q() != 0) {
            printWriter.print(str);
            printWriter.print("mNextAnim=");
            printWriter.println(q());
        }
        if (this.J != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.J);
        }
        if (this.K != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.K);
        }
        if (this.L != null) {
            printWriter.print(str);
            printWriter.print("mInnerView=");
            printWriter.println(this.K);
        }
        if (g() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(g());
            printWriter.print(str);
            printWriter.print("mStateAfterAnimating=");
            printWriter.println(y());
        }
        if (k() != null) {
            X.a(this).a(str, fileDescriptor, printWriter, strArr);
        }
        if (this.v != null) {
            printWriter.print(str);
            printWriter.println("Child " + this.v + ":");
            C0103z zVar = this.v;
            zVar.a(str + "  ", fileDescriptor, printWriter, strArr);
        }
    }

    public void a(boolean z2) {
    }

    public boolean a(MenuItem menuItem) {
        return false;
    }

    /* access modifiers changed from: package-private */
    public void aa() {
        if (this.K != null) {
            this.V.b(d.a.ON_STOP);
        }
        this.U.b(d.a.ON_STOP);
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.m();
        }
        this.f673c = 2;
        this.I = false;
        R();
        if (!this.I) {
            throw new ca("Fragment " + this + " did not call through to super.onStop()");
        }
    }

    public Animator b(int i2, boolean z2, int i3) {
        return null;
    }

    public s b() {
        if (k() != null) {
            if (this.x == null) {
                this.x = new s();
            }
            return this.x;
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    /* access modifiers changed from: package-private */
    public void b(int i2) {
        if (this.O != null || i2 != 0) {
            da().d = i2;
        }
    }

    public void b(Bundle bundle) {
        this.I = true;
    }

    /* access modifiers changed from: package-private */
    public void b(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.r();
        }
        this.r = true;
        this.W = new C0089k(this);
        this.V = null;
        this.K = a(layoutInflater, viewGroup, bundle);
        if (this.K != null) {
            this.W.a();
            this.X.b(this.W);
        } else if (this.V == null) {
            this.W = null;
        } else {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
        }
    }

    public void b(Menu menu) {
    }

    public void b(boolean z2) {
    }

    /* access modifiers changed from: package-private */
    public boolean b(Menu menu, MenuInflater menuInflater) {
        boolean z2 = false;
        if (this.C) {
            return false;
        }
        if (this.G && this.H) {
            a(menu, menuInflater);
            z2 = true;
        }
        C0103z zVar = this.v;
        return zVar != null ? z2 | zVar.a(menu, menuInflater) : z2;
    }

    public boolean b(MenuItem menuItem) {
        return false;
    }

    public final Context ba() {
        Context k2 = k();
        if (k2 != null) {
            return k2;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    /* access modifiers changed from: package-private */
    public void c() {
        a aVar = this.O;
        c cVar = null;
        if (aVar != null) {
            aVar.q = false;
            c cVar2 = aVar.r;
            aVar.r = null;
            cVar = cVar2;
        }
        if (cVar != null) {
            cVar.b();
        }
    }

    /* access modifiers changed from: package-private */
    public void c(int i2) {
        da().f676c = i2;
    }

    public void c(Bundle bundle) {
        this.I = true;
        k(bundle);
        C0103z zVar = this.v;
        if (zVar != null && !zVar.c(1)) {
            this.v.f();
        }
    }

    /* access modifiers changed from: package-private */
    public void c(Menu menu) {
        if (!this.C) {
            if (this.G && this.H) {
                a(menu);
            }
            C0103z zVar = this.v;
            if (zVar != null) {
                zVar.a(menu);
            }
        }
    }

    public void c(boolean z2) {
    }

    /* access modifiers changed from: package-private */
    public boolean c(MenuItem menuItem) {
        if (this.C) {
            return false;
        }
        if (a(menuItem)) {
            return true;
        }
        C0103z zVar = this.v;
        return zVar != null && zVar.a(menuItem);
    }

    public void ca() {
        C0103z zVar = this.t;
        if (zVar == null || zVar.s == null) {
            da().q = false;
        } else if (Looper.myLooper() != this.t.s.e().getLooper()) {
            this.t.s.e().postAtFrontOfQueue(new C0087i(this));
        } else {
            c();
        }
    }

    public final C0093o d() {
        r rVar = this.u;
        if (rVar == null) {
            return null;
        }
        return (C0093o) rVar.b();
    }

    public LayoutInflater d(Bundle bundle) {
        return a(bundle);
    }

    /* access modifiers changed from: package-private */
    public void d(boolean z2) {
        b(z2);
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.a(z2);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean d(Menu menu) {
        boolean z2 = false;
        if (this.C) {
            return false;
        }
        if (this.G && this.H) {
            b(menu);
            z2 = true;
        }
        C0103z zVar = this.v;
        return zVar != null ? z2 | zVar.b(menu) : z2;
    }

    /* access modifiers changed from: package-private */
    public boolean d(MenuItem menuItem) {
        if (this.C) {
            return false;
        }
        if (this.G && this.H && b(menuItem)) {
            return true;
        }
        C0103z zVar = this.v;
        return zVar != null && zVar.b(menuItem);
    }

    public void e(Bundle bundle) {
    }

    /* access modifiers changed from: package-private */
    public void e(boolean z2) {
        c(z2);
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.b(z2);
        }
    }

    public boolean e() {
        Boolean bool;
        a aVar = this.O;
        if (aVar == null || (bool = aVar.n) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public void f(Bundle bundle) {
        this.I = true;
    }

    /* access modifiers changed from: package-private */
    public void f(boolean z2) {
        da().s = z2;
    }

    public boolean f() {
        Boolean bool;
        a aVar = this.O;
        if (aVar == null || (bool = aVar.m) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    /* access modifiers changed from: package-private */
    public View g() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        return aVar.f674a;
    }

    /* access modifiers changed from: package-private */
    public void g(Bundle bundle) {
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.r();
        }
        this.f673c = 2;
        this.I = false;
        b(bundle);
        if (this.I) {
            C0103z zVar2 = this.v;
            if (zVar2 != null) {
                zVar2.e();
                return;
            }
            return;
        }
        throw new ca("Fragment " + this + " did not call through to super.onActivityCreated()");
    }

    public void g(boolean z2) {
        if (this.H != z2) {
            this.H = z2;
            if (this.G && C() && !D()) {
                this.u.i();
            }
        }
    }

    /* access modifiers changed from: package-private */
    public Animator h() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        return aVar.f675b;
    }

    /* access modifiers changed from: package-private */
    public void h(Bundle bundle) {
        C0103z zVar = this.v;
        if (zVar != null) {
            zVar.r();
        }
        this.f673c = 1;
        this.I = false;
        c(bundle);
        this.T = true;
        if (this.I) {
            this.U.b(d.a.ON_CREATE);
            return;
        }
        throw new ca("Fragment " + this + " did not call through to super.onCreate()");
    }

    public void h(boolean z2) {
        if (!this.N && z2 && this.f673c < 3 && this.t != null && C() && this.T) {
            this.t.k(this);
        }
        this.N = z2;
        this.M = this.f673c < 3 && !z2;
        if (this.d != null) {
            this.f = Boolean.valueOf(z2);
        }
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public final Bundle i() {
        return this.i;
    }

    /* access modifiers changed from: package-private */
    public LayoutInflater i(Bundle bundle) {
        this.S = d(bundle);
        return this.S;
    }

    public final C0096s j() {
        if (this.v == null) {
            B();
            int i2 = this.f673c;
            if (i2 >= 4) {
                this.v.k();
            } else if (i2 >= 3) {
                this.v.l();
            } else if (i2 >= 2) {
                this.v.e();
            } else if (i2 >= 1) {
                this.v.f();
            }
        }
        return this.v;
    }

    /* access modifiers changed from: package-private */
    public void j(Bundle bundle) {
        Parcelable u2;
        e(bundle);
        C0103z zVar = this.v;
        if (zVar != null && (u2 = zVar.u()) != null) {
            bundle.putParcelable("android:support:fragments", u2);
        }
    }

    public Context k() {
        r rVar = this.u;
        if (rVar == null) {
            return null;
        }
        return rVar.c();
    }

    /* access modifiers changed from: package-private */
    public void k(Bundle bundle) {
        Parcelable parcelable;
        if (bundle != null && (parcelable = bundle.getParcelable("android:support:fragments")) != null) {
            if (this.v == null) {
                B();
            }
            this.v.a(parcelable, this.w);
            this.w = null;
            this.v.f();
        }
    }

    public Object l() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        return aVar.g;
    }

    /* access modifiers changed from: package-private */
    public final void l(Bundle bundle) {
        SparseArray<Parcelable> sparseArray = this.e;
        if (sparseArray != null) {
            this.L.restoreHierarchyState(sparseArray);
            this.e = null;
        }
        this.I = false;
        f(bundle);
        if (!this.I) {
            throw new ca("Fragment " + this + " did not call through to super.onViewStateRestored()");
        } else if (this.K != null) {
            this.V.b(d.a.ON_CREATE);
        }
    }

    /* access modifiers changed from: package-private */
    public ba m() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        return aVar.o;
    }

    public void m(Bundle bundle) {
        if (this.g < 0 || !I()) {
            this.i = bundle;
            return;
        }
        throw new IllegalStateException("Fragment already active and state has been saved");
    }

    public Object n() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        return aVar.i;
    }

    /* access modifiers changed from: package-private */
    public ba o() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        return aVar.p;
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.I = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        d().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public void onLowMemory() {
        this.I = true;
    }

    public final C0096s p() {
        return this.t;
    }

    /* access modifiers changed from: package-private */
    public int q() {
        a aVar = this.O;
        if (aVar == null) {
            return 0;
        }
        return aVar.d;
    }

    /* access modifiers changed from: package-private */
    public int r() {
        a aVar = this.O;
        if (aVar == null) {
            return 0;
        }
        return aVar.e;
    }

    /* access modifiers changed from: package-private */
    public int s() {
        a aVar = this.O;
        if (aVar == null) {
            return 0;
        }
        return aVar.f;
    }

    public Object t() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.j;
        return obj == f672b ? n() : obj;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        a.b.f.g.f.a(this, sb);
        if (this.g >= 0) {
            sb.append(" #");
            sb.append(this.g);
        }
        if (this.z != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.z));
        }
        if (this.B != null) {
            sb.append(" ");
            sb.append(this.B);
        }
        sb.append('}');
        return sb.toString();
    }

    public final Resources u() {
        return ba().getResources();
    }

    public Object v() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.h;
        return obj == f672b ? l() : obj;
    }

    public Object w() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        return aVar.k;
    }

    public Object x() {
        a aVar = this.O;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.l;
        return obj == f672b ? w() : obj;
    }

    /* access modifiers changed from: package-private */
    public int y() {
        a aVar = this.O;
        if (aVar == null) {
            return 0;
        }
        return aVar.f676c;
    }

    public View z() {
        return this.K;
    }
}
