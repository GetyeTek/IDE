package android.support.v4.app;

import android.arch.lifecycle.f;
import android.arch.lifecycle.m;
import android.arch.lifecycle.n;
import android.arch.lifecycle.q;
import android.arch.lifecycle.r;
import android.arch.lifecycle.s;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.content.e;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;

class LoaderManagerImpl extends X {

    /* renamed from: a  reason: collision with root package name */
    static boolean f615a = false;

    /* renamed from: b  reason: collision with root package name */
    private final f f616b;

    /* renamed from: c  reason: collision with root package name */
    private final LoaderViewModel f617c;

    static class LoaderViewModel extends q {

        /* renamed from: a  reason: collision with root package name */
        private static final r.a f618a = new Y();

        /* renamed from: b  reason: collision with root package name */
        private a.b.f.g.q<a> f619b = new a.b.f.g.q<>();

        /* renamed from: c  reason: collision with root package name */
        private boolean f620c = false;

        LoaderViewModel() {
        }

        static LoaderViewModel a(s sVar) {
            return (LoaderViewModel) new r(sVar, f618a).a(LoaderViewModel.class);
        }

        /* access modifiers changed from: protected */
        public void a() {
            super.a();
            int b2 = this.f619b.b();
            for (int i = 0; i < b2; i++) {
                this.f619b.e(i).a(true);
            }
            this.f619b.a();
        }

        public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            if (this.f619b.b() > 0) {
                printWriter.print(str);
                printWriter.println("Loaders:");
                String str2 = str + "    ";
                for (int i = 0; i < this.f619b.b(); i++) {
                    a e = this.f619b.e(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(this.f619b.c(i));
                    printWriter.print(": ");
                    printWriter.println(e.toString());
                    e.a(str2, fileDescriptor, printWriter, strArr);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void b() {
            int b2 = this.f619b.b();
            for (int i = 0; i < b2; i++) {
                this.f619b.e(i).g();
            }
        }
    }

    public static class a<D> extends m<D> implements e.c<D> {
        private final int k;
        private final Bundle l;
        private final e<D> m;
        private f n;
        private b<D> o;
        private e<D> p;

        /* access modifiers changed from: package-private */
        public e<D> a(boolean z) {
            if (LoaderManagerImpl.f615a) {
                Log.v("LoaderManager", "  Destroying: " + this);
            }
            this.m.b();
            this.m.a();
            b<D> bVar = this.o;
            if (bVar != null) {
                a(bVar);
                if (z) {
                    bVar.b();
                    throw null;
                }
            }
            this.m.a(this);
            if (bVar != null) {
                bVar.a();
                throw null;
            } else if (!z) {
                return this.m;
            } else {
                this.m.q();
                return this.p;
            }
        }

        public void a(n<? super D> nVar) {
            super.a(nVar);
            this.n = null;
            this.o = null;
        }

        public void a(e<D> eVar, D d) {
            if (LoaderManagerImpl.f615a) {
                Log.v("LoaderManager", "onLoadComplete: " + this);
            }
            if (Looper.myLooper() == Looper.getMainLooper()) {
                b(d);
                return;
            }
            if (LoaderManagerImpl.f615a) {
                Log.w("LoaderManager", "onLoadComplete was incorrectly called on a background thread");
            }
            a(d);
        }

        public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.print(str);
            printWriter.print("mId=");
            printWriter.print(this.k);
            printWriter.print(" mArgs=");
            printWriter.println(this.l);
            printWriter.print(str);
            printWriter.print("mLoader=");
            printWriter.println(this.m);
            e<D> eVar = this.m;
            eVar.a(str + "  ", fileDescriptor, printWriter, strArr);
            if (this.o == null) {
                printWriter.print(str);
                printWriter.print("mData=");
                printWriter.println(f().a(b()));
                printWriter.print(str);
                printWriter.print("mStarted=");
                printWriter.println(c());
                return;
            }
            printWriter.print(str);
            printWriter.print("mCallbacks=");
            printWriter.println(this.o);
            b<D> bVar = this.o;
            bVar.a(str + "  ", printWriter);
            throw null;
        }

        public void b(D d) {
            super.b(d);
            e<D> eVar = this.p;
            if (eVar != null) {
                eVar.q();
                this.p = null;
            }
        }

        /* access modifiers changed from: protected */
        public void d() {
            if (LoaderManagerImpl.f615a) {
                Log.v("LoaderManager", "  Starting: " + this);
            }
            this.m.s();
        }

        /* access modifiers changed from: protected */
        public void e() {
            if (LoaderManagerImpl.f615a) {
                Log.v("LoaderManager", "  Stopping: " + this);
            }
            this.m.t();
        }

        /* access modifiers changed from: package-private */
        public e<D> f() {
            return this.m;
        }

        /* access modifiers changed from: package-private */
        public void g() {
            f fVar = this.n;
            b<D> bVar = this.o;
            if (fVar != null && bVar != null) {
                super.a(bVar);
                a(fVar, bVar);
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(this.k);
            sb.append(" : ");
            a.b.f.g.f.a(this.m, sb);
            sb.append("}}");
            return sb.toString();
        }
    }

    static class b<D> implements n<D> {
        public void a(String str, PrintWriter printWriter) {
            throw null;
        }

        /* access modifiers changed from: package-private */
        public boolean a() {
            throw null;
        }

        /* access modifiers changed from: package-private */
        public void b() {
            throw null;
        }
    }

    LoaderManagerImpl(f fVar, s sVar) {
        this.f616b = fVar;
        this.f617c = LoaderViewModel.a(sVar);
    }

    public void a() {
        this.f617c.b();
    }

    @Deprecated
    public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f617c.a(str, fileDescriptor, printWriter, strArr);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        a.b.f.g.f.a(this.f616b, sb);
        sb.append("}}");
        return sb.toString();
    }
}
