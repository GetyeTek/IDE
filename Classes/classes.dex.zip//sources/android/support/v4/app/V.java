package android.support.v4.app;

import android.support.v4.view.y;
import android.view.View;
import java.util.ArrayList;
import java.util.Map;

class V implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ArrayList f643a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ Map f644b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ W f645c;

    V(W w, ArrayList arrayList, Map map) {
        this.f645c = w;
        this.f643a = arrayList;
        this.f644b = map;
    }

    public void run() {
        int size = this.f643a.size();
        for (int i = 0; i < size; i++) {
            View view = (View) this.f643a.get(i);
            y.a(view, (String) this.f644b.get(y.q(view)));
        }
    }
}
