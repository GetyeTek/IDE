package android.support.v4.app;

import android.view.View;
import android.view.ViewTreeObserver;

class aa implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* renamed from: a  reason: collision with root package name */
    private final View f649a;

    /* renamed from: b  reason: collision with root package name */
    private ViewTreeObserver f650b;

    /* renamed from: c  reason: collision with root package name */
    private final Runnable f651c;

    private aa(View view, Runnable runnable) {
        this.f649a = view;
        this.f650b = view.getViewTreeObserver();
        this.f651c = runnable;
    }

    public static aa a(View view, Runnable runnable) {
        aa aaVar = new aa(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(aaVar);
        view.addOnAttachStateChangeListener(aaVar);
        return aaVar;
    }

    public void a() {
        (this.f650b.isAlive() ? this.f650b : this.f649a.getViewTreeObserver()).removeOnPreDrawListener(this);
        this.f649a.removeOnAttachStateChangeListener(this);
    }

    public boolean onPreDraw() {
        a();
        this.f651c.run();
        return true;
    }

    public void onViewAttachedToWindow(View view) {
        this.f650b = view.getViewTreeObserver();
    }

    public void onViewDetachedFromWindow(View view) {
        a();
    }
}
