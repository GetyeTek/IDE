package android.support.v4.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.C0080b;

/* renamed from: android.support.v4.app.a  reason: case insensitive filesystem */
class C0079a implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ String[] f646a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ Activity f647b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ int f648c;

    C0079a(String[] strArr, Activity activity, int i) {
        this.f646a = strArr;
        this.f647b = activity;
        this.f648c = i;
    }

    public void run() {
        int[] iArr = new int[this.f646a.length];
        PackageManager packageManager = this.f647b.getPackageManager();
        String packageName = this.f647b.getPackageName();
        int length = this.f646a.length;
        for (int i = 0; i < length; i++) {
            iArr[i] = packageManager.checkPermission(this.f646a[i], packageName);
        }
        ((C0080b.a) this.f647b).onRequestPermissionsResult(this.f648c, this.f646a, iArr);
    }
}
