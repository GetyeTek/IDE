package android.support.v4.app;

import android.arch.lifecycle.s;
import java.util.List;

public class A {

    /* renamed from: a  reason: collision with root package name */
    private final List<C0090l> f594a;

    /* renamed from: b  reason: collision with root package name */
    private final List<A> f595b;

    /* renamed from: c  reason: collision with root package name */
    private final List<s> f596c;

    A(List<C0090l> list, List<A> list2, List<s> list3) {
        this.f594a = list;
        this.f595b = list2;
        this.f596c = list3;
    }

    /* access modifiers changed from: package-private */
    public List<A> a() {
        return this.f595b;
    }

    /* access modifiers changed from: package-private */
    public List<C0090l> b() {
        return this.f594a;
    }

    /* access modifiers changed from: package-private */
    public List<s> c() {
        return this.f596c;
    }
}
