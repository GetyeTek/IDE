package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;

final class C implements Parcelable {
    public static final Parcelable.Creator<C> CREATOR = new B();

    /* renamed from: a  reason: collision with root package name */
    F[] f597a;

    /* renamed from: b  reason: collision with root package name */
    int[] f598b;

    /* renamed from: c  reason: collision with root package name */
    C0084f[] f599c;
    int d = -1;
    int e;

    public C() {
    }

    public C(Parcel parcel) {
        this.f597a = (F[]) parcel.createTypedArray(F.CREATOR);
        this.f598b = parcel.createIntArray();
        this.f599c = (C0084f[]) parcel.createTypedArray(C0084f.CREATOR);
        this.d = parcel.readInt();
        this.e = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedArray(this.f597a, i);
        parcel.writeIntArray(this.f598b);
        parcel.writeTypedArray(this.f599c, i);
        parcel.writeInt(this.d);
        parcel.writeInt(this.e);
    }
}
