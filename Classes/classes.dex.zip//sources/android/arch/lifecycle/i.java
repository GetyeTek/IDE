package android.arch.lifecycle;

@Deprecated
public interface i extends f {
    h a();
}
