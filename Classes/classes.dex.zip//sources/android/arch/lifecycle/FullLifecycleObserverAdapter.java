package android.arch.lifecycle;

import android.arch.lifecycle.d;

class FullLifecycleObserverAdapter implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    private final FullLifecycleObserver f343a;

    FullLifecycleObserverAdapter(FullLifecycleObserver fullLifecycleObserver) {
        this.f343a = fullLifecycleObserver;
    }

    public void a(f fVar, d.a aVar) {
        switch (b.f360a[aVar.ordinal()]) {
            case 1:
                this.f343a.d(fVar);
                return;
            case 2:
                this.f343a.a(fVar);
                return;
            case 3:
                this.f343a.e(fVar);
                return;
            case 4:
                this.f343a.b(fVar);
                return;
            case 5:
                this.f343a.f(fVar);
                return;
            case 6:
                this.f343a.c(fVar);
                return;
            case 7:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
            default:
                return;
        }
    }
}
