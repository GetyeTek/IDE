package android.arch.lifecycle;

public class r {

    /* renamed from: a  reason: collision with root package name */
    private final a f376a;

    /* renamed from: b  reason: collision with root package name */
    private final s f377b;

    public interface a {
        <T extends q> T a(Class<T> cls);
    }

    public r(s sVar, a aVar) {
        this.f376a = aVar;
        this.f377b = sVar;
    }

    public <T extends q> T a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return a("android.arch.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public <T extends q> T a(String str, Class<T> cls) {
        T a2 = this.f377b.a(str);
        if (cls.isInstance(a2)) {
            return a2;
        }
        T a3 = this.f376a.a(cls);
        this.f377b.a(str, a3);
        return a3;
    }
}
