package android.arch.lifecycle;

public interface n<T> {
    void a(T t);
}
