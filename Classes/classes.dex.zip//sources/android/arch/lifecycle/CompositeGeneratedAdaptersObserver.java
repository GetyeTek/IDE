package android.arch.lifecycle;

import android.arch.lifecycle.d;

public class CompositeGeneratedAdaptersObserver implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    private final c[] f342a;

    CompositeGeneratedAdaptersObserver(c[] cVarArr) {
        this.f342a = cVarArr;
    }

    public void a(f fVar, d.a aVar) {
        l lVar = new l();
        for (c a2 : this.f342a) {
            a2.a(fVar, aVar, false, lVar);
        }
        for (c a3 : this.f342a) {
            a3.a(fVar, aVar, true, lVar);
        }
    }
}
