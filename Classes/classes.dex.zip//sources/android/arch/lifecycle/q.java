package android.arch.lifecycle;

public abstract class q {
    /* access modifiers changed from: protected */
    public void a() {
    }
}
