package android.arch.lifecycle;

import java.util.HashMap;

public class s {

    /* renamed from: a  reason: collision with root package name */
    private final HashMap<String, q> f378a = new HashMap<>();

    /* access modifiers changed from: package-private */
    public final q a(String str) {
        return this.f378a.get(str);
    }

    public final void a() {
        for (q a2 : this.f378a.values()) {
            a2.a();
        }
        this.f378a.clear();
    }

    /* access modifiers changed from: package-private */
    public final void a(String str, q qVar) {
        q put = this.f378a.put(str, qVar);
        if (put != null) {
            put.a();
        }
    }
}
