package android.arch.lifecycle;

class k implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ LiveData f373a;

    k(LiveData liveData) {
        this.f373a = liveData;
    }

    public void run() {
        Object b2;
        synchronized (this.f373a.f345b) {
            b2 = this.f373a.f;
            Object unused = this.f373a.f = LiveData.f344a;
        }
        this.f373a.b(b2);
    }
}
