package android.arch.lifecycle;

import android.arch.lifecycle.d;

public interface GenericLifecycleObserver extends e {
    void a(f fVar, d.a aVar);
}
