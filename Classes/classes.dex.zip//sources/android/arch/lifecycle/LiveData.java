package android.arch.lifecycle;

import a.a.a.b.c;
import android.arch.lifecycle.d;
import java.util.Map;

public abstract class LiveData<T> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static final Object f344a = new Object();
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Object f345b = new Object();

    /* renamed from: c  reason: collision with root package name */
    private c<n<T>, LiveData<T>.a> f346c = new c<>();
    /* access modifiers changed from: private */
    public int d = 0;
    private volatile Object e;
    /* access modifiers changed from: private */
    public volatile Object f;
    private int g;
    private boolean h;
    private boolean i;
    private final Runnable j;

    class LifecycleBoundObserver extends LiveData<T>.a implements GenericLifecycleObserver {
        final f e;

        LifecycleBoundObserver(f fVar, n<T> nVar) {
            super(nVar);
            this.e = fVar;
        }

        /* access modifiers changed from: package-private */
        public void a() {
            this.e.a().b(this);
        }

        public void a(f fVar, d.a aVar) {
            if (this.e.a().a() == d.b.DESTROYED) {
                LiveData.this.a(this.f347a);
            } else {
                a(b());
            }
        }

        /* access modifiers changed from: package-private */
        public boolean a(f fVar) {
            return this.e == fVar;
        }

        /* access modifiers changed from: package-private */
        public boolean b() {
            return this.e.a().a().a(d.b.STARTED);
        }
    }

    private abstract class a {

        /* renamed from: a  reason: collision with root package name */
        final n<T> f347a;

        /* renamed from: b  reason: collision with root package name */
        boolean f348b;

        /* renamed from: c  reason: collision with root package name */
        int f349c = -1;

        a(n<T> nVar) {
            this.f347a = nVar;
        }

        /* access modifiers changed from: package-private */
        public void a() {
        }

        /* access modifiers changed from: package-private */
        public void a(boolean z) {
            if (z != this.f348b) {
                this.f348b = z;
                int i = 1;
                boolean z2 = LiveData.this.d == 0;
                LiveData liveData = LiveData.this;
                int c2 = liveData.d;
                if (!this.f348b) {
                    i = -1;
                }
                int unused = liveData.d = c2 + i;
                if (z2 && this.f348b) {
                    LiveData.this.d();
                }
                if (LiveData.this.d == 0 && !this.f348b) {
                    LiveData.this.e();
                }
                if (this.f348b) {
                    LiveData.this.b((LiveData<T>.a) this);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public boolean a(f fVar) {
            return false;
        }

        /* access modifiers changed from: package-private */
        public abstract boolean b();
    }

    public LiveData() {
        Object obj = f344a;
        this.e = obj;
        this.f = obj;
        this.g = -1;
        this.j = new k(this);
    }

    private void a(LiveData<T>.a aVar) {
        if (aVar.f348b) {
            if (!aVar.b()) {
                aVar.a(false);
                return;
            }
            int i2 = aVar.f349c;
            int i3 = this.g;
            if (i2 < i3) {
                aVar.f349c = i3;
                aVar.f347a.a(this.e);
            }
        }
    }

    private static void a(String str) {
        if (!a.a.a.a.c.b().a()) {
            throw new IllegalStateException("Cannot invoke " + str + " on a background" + " thread");
        }
    }

    /* access modifiers changed from: private */
    public void b(LiveData<T>.a aVar) {
        if (this.h) {
            this.i = true;
            return;
        }
        this.h = true;
        do {
            this.i = false;
            if (aVar == null) {
                c<K, V>.d b2 = this.f346c.b();
                while (b2.hasNext()) {
                    a((LiveData<T>.a) (a) ((Map.Entry) b2.next()).getValue());
                    if (this.i) {
                        break;
                    }
                }
            } else {
                a(aVar);
                aVar = null;
            }
        } while (this.i);
        this.h = false;
    }

    public void a(f fVar, n<T> nVar) {
        if (fVar.a().a() != d.b.DESTROYED) {
            LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(fVar, nVar);
            a b2 = this.f346c.b(nVar, lifecycleBoundObserver);
            if (b2 != null && !b2.a(fVar)) {
                throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
            } else if (b2 == null) {
                fVar.a().a(lifecycleBoundObserver);
            }
        }
    }

    public void a(n<T> nVar) {
        a("removeObserver");
        a remove = this.f346c.remove(nVar);
        if (remove != null) {
            remove.a();
            remove.a(false);
        }
    }

    /* access modifiers changed from: protected */
    public void a(T t) {
        boolean z;
        synchronized (this.f345b) {
            z = this.f == f344a;
            this.f = t;
        }
        if (z) {
            a.a.a.a.c.b().b(this.j);
        }
    }

    public T b() {
        T t = this.e;
        if (t != f344a) {
            return t;
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void b(T t) {
        a("setValue");
        this.g++;
        this.e = t;
        b((LiveData<T>.a) null);
    }

    public boolean c() {
        return this.d > 0;
    }

    /* access modifiers changed from: protected */
    public void d() {
    }

    /* access modifiers changed from: protected */
    public void e() {
    }
}
