package android.arch.lifecycle;

import android.arch.lifecycle.a;
import android.arch.lifecycle.d;

class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    private final Object f350a;

    /* renamed from: b  reason: collision with root package name */
    private final a.C0009a f351b = a.f353a.a(this.f350a.getClass());

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.f350a = obj;
    }

    public void a(f fVar, d.a aVar) {
        this.f351b.a(fVar, aVar, this.f350a);
    }
}
