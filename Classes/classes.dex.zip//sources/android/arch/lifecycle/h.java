package android.arch.lifecycle;

import a.a.a.b.c;
import android.arch.lifecycle.d;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class h extends d {

    /* renamed from: a  reason: collision with root package name */
    private a.a.a.b.a<e, a> f366a = new a.a.a.b.a<>();

    /* renamed from: b  reason: collision with root package name */
    private d.b f367b;

    /* renamed from: c  reason: collision with root package name */
    private final WeakReference<f> f368c;
    private int d = 0;
    private boolean e = false;
    private boolean f = false;
    private ArrayList<d.b> g = new ArrayList<>();

    static class a {

        /* renamed from: a  reason: collision with root package name */
        d.b f369a;

        /* renamed from: b  reason: collision with root package name */
        GenericLifecycleObserver f370b;

        a(e eVar, d.b bVar) {
            this.f370b = j.a((Object) eVar);
            this.f369a = bVar;
        }

        /* access modifiers changed from: package-private */
        public void a(f fVar, d.a aVar) {
            d.b a2 = h.a(aVar);
            this.f369a = h.a(this.f369a, a2);
            this.f370b.a(fVar, aVar);
            this.f369a = a2;
        }
    }

    public h(f fVar) {
        this.f368c = new WeakReference<>(fVar);
        this.f367b = d.b.INITIALIZED;
    }

    static d.b a(d.a aVar) {
        switch (g.f364a[aVar.ordinal()]) {
            case 1:
            case 2:
                return d.b.CREATED;
            case 3:
            case 4:
                return d.b.STARTED;
            case 5:
                return d.b.RESUMED;
            case 6:
                return d.b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    static d.b a(d.b bVar, d.b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    private void a(f fVar) {
        Iterator<Map.Entry<e, a>> descendingIterator = this.f366a.descendingIterator();
        while (descendingIterator.hasNext() && !this.f) {
            Map.Entry next = descendingIterator.next();
            a aVar = (a) next.getValue();
            while (aVar.f369a.compareTo(this.f367b) > 0 && !this.f && this.f366a.contains(next.getKey())) {
                d.a b2 = b(aVar.f369a);
                d(a(b2));
                aVar.a(fVar, b2);
                c();
            }
        }
    }

    private static d.a b(d.b bVar) {
        int i = g.f365b[bVar.ordinal()];
        if (i == 1) {
            throw new IllegalArgumentException();
        } else if (i == 2) {
            return d.a.ON_DESTROY;
        } else {
            if (i == 3) {
                return d.a.ON_STOP;
            }
            if (i == 4) {
                return d.a.ON_PAUSE;
            }
            if (i != 5) {
                throw new IllegalArgumentException("Unexpected state value " + bVar);
            }
            throw new IllegalArgumentException();
        }
    }

    private void b(f fVar) {
        c<K, V>.d b2 = this.f366a.b();
        while (b2.hasNext() && !this.f) {
            Map.Entry entry = (Map.Entry) b2.next();
            a aVar = (a) entry.getValue();
            while (aVar.f369a.compareTo(this.f367b) < 0 && !this.f && this.f366a.contains(entry.getKey())) {
                d(aVar.f369a);
                aVar.a(fVar, e(aVar.f369a));
                c();
            }
        }
    }

    private boolean b() {
        if (this.f366a.size() == 0) {
            return true;
        }
        d.b bVar = this.f366a.a().getValue().f369a;
        d.b bVar2 = this.f366a.c().getValue().f369a;
        return bVar == bVar2 && this.f367b == bVar2;
    }

    private d.b c(e eVar) {
        Map.Entry<e, a> b2 = this.f366a.b(eVar);
        d.b bVar = null;
        d.b bVar2 = b2 != null ? b2.getValue().f369a : null;
        if (!this.g.isEmpty()) {
            ArrayList<d.b> arrayList = this.g;
            bVar = arrayList.get(arrayList.size() - 1);
        }
        return a(a(this.f367b, bVar2), bVar);
    }

    private void c() {
        ArrayList<d.b> arrayList = this.g;
        arrayList.remove(arrayList.size() - 1);
    }

    private void c(d.b bVar) {
        if (this.f367b != bVar) {
            this.f367b = bVar;
            if (this.e || this.d != 0) {
                this.f = true;
                return;
            }
            this.e = true;
            d();
            this.e = false;
        }
    }

    private void d() {
        f fVar = (f) this.f368c.get();
        if (fVar == null) {
            Log.w("LifecycleRegistry", "LifecycleOwner is garbage collected, you shouldn't try dispatch new events from it.");
            return;
        }
        while (!b()) {
            this.f = false;
            if (this.f367b.compareTo(this.f366a.a().getValue().f369a) < 0) {
                a(fVar);
            }
            Map.Entry<e, a> c2 = this.f366a.c();
            if (!this.f && c2 != null && this.f367b.compareTo(c2.getValue().f369a) > 0) {
                b(fVar);
            }
        }
        this.f = false;
    }

    private void d(d.b bVar) {
        this.g.add(bVar);
    }

    private static d.a e(d.b bVar) {
        int i = g.f365b[bVar.ordinal()];
        if (i != 1) {
            if (i == 2) {
                return d.a.ON_START;
            }
            if (i == 3) {
                return d.a.ON_RESUME;
            }
            if (i == 4) {
                throw new IllegalArgumentException();
            } else if (i != 5) {
                throw new IllegalArgumentException("Unexpected state value " + bVar);
            }
        }
        return d.a.ON_CREATE;
    }

    public d.b a() {
        return this.f367b;
    }

    public void a(d.b bVar) {
        c(bVar);
    }

    public void a(e eVar) {
        f fVar;
        d.b bVar = this.f367b;
        d.b bVar2 = d.b.DESTROYED;
        if (bVar != bVar2) {
            bVar2 = d.b.INITIALIZED;
        }
        a aVar = new a(eVar, bVar2);
        if (this.f366a.b(eVar, aVar) == null && (fVar = (f) this.f368c.get()) != null) {
            boolean z = this.d != 0 || this.e;
            d.b c2 = c(eVar);
            this.d++;
            while (aVar.f369a.compareTo(c2) < 0 && this.f366a.contains(eVar)) {
                d(aVar.f369a);
                aVar.a(fVar, e(aVar.f369a));
                c();
                c2 = c(eVar);
            }
            if (!z) {
                d();
            }
            this.d--;
        }
    }

    public void b(d.a aVar) {
        c(a(aVar));
    }

    public void b(e eVar) {
        this.f366a.remove(eVar);
    }
}
