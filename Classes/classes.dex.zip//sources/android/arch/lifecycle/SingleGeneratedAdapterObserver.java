package android.arch.lifecycle;

import android.arch.lifecycle.d;

public class SingleGeneratedAdapterObserver implements GenericLifecycleObserver {

    /* renamed from: a  reason: collision with root package name */
    private final c f352a;

    SingleGeneratedAdapterObserver(c cVar) {
        this.f352a = cVar;
    }

    public void a(f fVar, d.a aVar) {
        this.f352a.a(fVar, aVar, false, (l) null);
        this.f352a.a(fVar, aVar, true, (l) null);
    }
}
