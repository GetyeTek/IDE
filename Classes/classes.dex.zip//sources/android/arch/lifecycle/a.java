package android.arch.lifecycle;

import android.arch.lifecycle.d;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class a {

    /* renamed from: a  reason: collision with root package name */
    static a f353a = new a();

    /* renamed from: b  reason: collision with root package name */
    private final Map<Class, C0009a> f354b = new HashMap();

    /* renamed from: c  reason: collision with root package name */
    private final Map<Class, Boolean> f355c = new HashMap();

    /* renamed from: android.arch.lifecycle.a$a  reason: collision with other inner class name */
    static class C0009a {

        /* renamed from: a  reason: collision with root package name */
        final Map<d.a, List<b>> f356a = new HashMap();

        /* renamed from: b  reason: collision with root package name */
        final Map<b, d.a> f357b;

        C0009a(Map<b, d.a> map) {
            this.f357b = map;
            for (Map.Entry next : map.entrySet()) {
                d.a aVar = (d.a) next.getValue();
                List list = this.f356a.get(aVar);
                if (list == null) {
                    list = new ArrayList();
                    this.f356a.put(aVar, list);
                }
                list.add(next.getKey());
            }
        }

        private static void a(List<b> list, f fVar, d.a aVar, Object obj) {
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    list.get(size).a(fVar, aVar, obj);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void a(f fVar, d.a aVar, Object obj) {
            a(this.f356a.get(aVar), fVar, aVar, obj);
            a(this.f356a.get(d.a.ON_ANY), fVar, aVar, obj);
        }
    }

    static class b {

        /* renamed from: a  reason: collision with root package name */
        final int f358a;

        /* renamed from: b  reason: collision with root package name */
        final Method f359b;

        b(int i, Method method) {
            this.f358a = i;
            this.f359b = method;
            this.f359b.setAccessible(true);
        }

        /* access modifiers changed from: package-private */
        public void a(f fVar, d.a aVar, Object obj) {
            try {
                int i = this.f358a;
                if (i == 0) {
                    this.f359b.invoke(obj, new Object[0]);
                } else if (i == 1) {
                    this.f359b.invoke(obj, new Object[]{fVar});
                } else if (i == 2) {
                    this.f359b.invoke(obj, new Object[]{fVar, aVar});
                }
            } catch (InvocationTargetException e) {
                throw new RuntimeException("Failed to call observer method", e.getCause());
            } catch (IllegalAccessException e2) {
                throw new RuntimeException(e2);
            }
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || b.class != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            return this.f358a == bVar.f358a && this.f359b.getName().equals(bVar.f359b.getName());
        }

        public int hashCode() {
            return (this.f358a * 31) + this.f359b.getName().hashCode();
        }
    }

    a() {
    }

    private C0009a a(Class cls, Method[] methodArr) {
        int i;
        C0009a a2;
        Class superclass = cls.getSuperclass();
        HashMap hashMap = new HashMap();
        if (!(superclass == null || (a2 = a(superclass)) == null)) {
            hashMap.putAll(a2.f357b);
        }
        for (Class a3 : cls.getInterfaces()) {
            for (Map.Entry next : a(a3).f357b.entrySet()) {
                a(hashMap, (b) next.getKey(), (d.a) next.getValue(), cls);
            }
        }
        if (methodArr == null) {
            methodArr = c(cls);
        }
        boolean z = false;
        for (Method method : methodArr) {
            o oVar = (o) method.getAnnotation(o.class);
            if (oVar != null) {
                Class[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else if (parameterTypes[0].isAssignableFrom(f.class)) {
                    i = 1;
                } else {
                    throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                }
                d.a value = oVar.value();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(d.a.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    } else if (value == d.a.ON_ANY) {
                        i = 2;
                    } else {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                }
                if (parameterTypes.length <= 2) {
                    a(hashMap, new b(i, method), value, cls);
                    z = true;
                } else {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
            }
        }
        C0009a aVar = new C0009a(hashMap);
        this.f354b.put(cls, aVar);
        this.f355c.put(cls, Boolean.valueOf(z));
        return aVar;
    }

    private void a(Map<b, d.a> map, b bVar, d.a aVar, Class cls) {
        d.a aVar2 = map.get(bVar);
        if (aVar2 != null && aVar != aVar2) {
            Method method = bVar.f359b;
            throw new IllegalArgumentException("Method " + method.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + aVar2 + ", new value " + aVar);
        } else if (aVar2 == null) {
            map.put(bVar, aVar);
        }
    }

    private Method[] c(Class cls) {
        try {
            return cls.getDeclaredMethods();
        } catch (NoClassDefFoundError e) {
            throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e);
        }
    }

    /* access modifiers changed from: package-private */
    public C0009a a(Class cls) {
        C0009a aVar = this.f354b.get(cls);
        return aVar != null ? aVar : a(cls, (Method[]) null);
    }

    /* access modifiers changed from: package-private */
    public boolean b(Class cls) {
        if (this.f355c.containsKey(cls)) {
            return this.f355c.get(cls).booleanValue();
        }
        Method[] c2 = c(cls);
        for (Method annotation : c2) {
            if (((o) annotation.getAnnotation(o.class)) != null) {
                a(cls, c2);
                return true;
            }
        }
        this.f355c.put(cls, false);
        return false;
    }
}
