package android.arch.lifecycle;

import android.arch.lifecycle.d;

public interface c {
    void a(f fVar, d.a aVar, boolean z, l lVar);
}
