package android.arch.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.arch.lifecycle.d;
import android.os.Bundle;

public class p extends Fragment {

    /* renamed from: a  reason: collision with root package name */
    private a f375a;

    interface a {
        void a();

        void onCreate();

        void onResume();
    }

    public static void a(Activity activity) {
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new p(), "android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    private void a(d.a aVar) {
        Activity activity = getActivity();
        if (activity instanceof i) {
            ((i) activity).a().b(aVar);
        } else if (activity instanceof f) {
            d a2 = ((f) activity).a();
            if (a2 instanceof h) {
                ((h) a2).b(aVar);
            }
        }
    }

    private void a(a aVar) {
        if (aVar != null) {
            aVar.onCreate();
        }
    }

    private void b(a aVar) {
        if (aVar != null) {
            aVar.onResume();
        }
    }

    private void c(a aVar) {
        if (aVar != null) {
            aVar.a();
        }
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(this.f375a);
        a(d.a.ON_CREATE);
    }

    public void onDestroy() {
        super.onDestroy();
        a(d.a.ON_DESTROY);
        this.f375a = null;
    }

    public void onPause() {
        super.onPause();
        a(d.a.ON_PAUSE);
    }

    public void onResume() {
        super.onResume();
        b(this.f375a);
        a(d.a.ON_RESUME);
    }

    public void onStart() {
        super.onStart();
        c(this.f375a);
        a(d.a.ON_START);
    }

    public void onStop() {
        super.onStop();
        a(d.a.ON_STOP);
    }
}
