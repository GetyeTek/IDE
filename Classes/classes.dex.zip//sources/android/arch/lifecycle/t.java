package android.arch.lifecycle;

public interface t {
    s b();
}
