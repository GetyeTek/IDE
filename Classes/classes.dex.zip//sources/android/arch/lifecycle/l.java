package android.arch.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class l {

    /* renamed from: a  reason: collision with root package name */
    private Map<String, Integer> f374a = new HashMap();
}
