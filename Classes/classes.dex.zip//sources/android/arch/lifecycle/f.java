package android.arch.lifecycle;

public interface f {
    d a();
}
