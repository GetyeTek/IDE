package com.squareup.okhttp;

import com.squareup.okhttp.internal.DiskLruCache;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.http.HttpMethod;
import com.squareup.okhttp.internal.http.Request;
import com.squareup.okhttp.internal.http.Response;
import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.Okio;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.CacheRequest;
import java.net.CacheResponse;
import java.net.ResponseCache;
import java.net.URI;
import java.net.URLConnection;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Cache extends ResponseCache implements OkResponseCache {
    private static final int ENTRY_BODY = 1;
    private static final int ENTRY_COUNT = 2;
    private static final int ENTRY_METADATA = 0;
    private static final int VERSION = 201105;
    private final DiskLruCache cache;
    private int hitCount;
    private int networkCount;
    private int requestCount;
    private int writeAbortCount;
    private int writeSuccessCount;

    /* renamed from: com.squareup.okhttp.Cache$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$squareup$okhttp$ResponseSource = new int[ResponseSource.values().length];

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|8) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0014 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001f */
        static {
            /*
                com.squareup.okhttp.ResponseSource[] r0 = com.squareup.okhttp.ResponseSource.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$com$squareup$okhttp$ResponseSource = r0
                int[] r0 = $SwitchMap$com$squareup$okhttp$ResponseSource     // Catch:{ NoSuchFieldError -> 0x0014 }
                com.squareup.okhttp.ResponseSource r1 = com.squareup.okhttp.ResponseSource.CACHE     // Catch:{ NoSuchFieldError -> 0x0014 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0014 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                int[] r0 = $SwitchMap$com$squareup$okhttp$ResponseSource     // Catch:{ NoSuchFieldError -> 0x001f }
                com.squareup.okhttp.ResponseSource r1 = com.squareup.okhttp.ResponseSource.CONDITIONAL_CACHE     // Catch:{ NoSuchFieldError -> 0x001f }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001f }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                int[] r0 = $SwitchMap$com$squareup$okhttp$ResponseSource     // Catch:{ NoSuchFieldError -> 0x002a }
                com.squareup.okhttp.ResponseSource r1 = com.squareup.okhttp.ResponseSource.NETWORK     // Catch:{ NoSuchFieldError -> 0x002a }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x002a }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x002a }
            L_0x002a:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.Cache.AnonymousClass1.<clinit>():void");
        }
    }

    private final class CacheRequestImpl extends CacheRequest {
        private OutputStream body;
        private OutputStream cacheOut;
        /* access modifiers changed from: private */
        public boolean done;
        private final DiskLruCache.Editor editor;

        public CacheRequestImpl(final DiskLruCache.Editor editor2) {
            this.editor = editor2;
            this.cacheOut = editor2.newOutputStream(1);
            this.body = new FilterOutputStream(this.cacheOut, Cache.this) {
                public void close() {
                    synchronized (Cache.this) {
                        if (!CacheRequestImpl.this.done) {
                            boolean unused = CacheRequestImpl.this.done = true;
                            Cache.access$208(Cache.this);
                            super.close();
                            editor2.commit();
                        }
                    }
                }

                public void write(byte[] bArr, int i, int i2) {
                    this.out.write(bArr, i, i2);
                }
            };
        }

        public void abort() {
            synchronized (Cache.this) {
                if (!this.done) {
                    this.done = true;
                    Cache.access$308(Cache.this);
                    Util.closeQuietly((Closeable) this.cacheOut);
                    try {
                        this.editor.abort();
                    } catch (IOException unused) {
                    }
                }
            }
        }

        public OutputStream getBody() {
            return this.body;
        }
    }

    private static class CacheResponseBody extends Response.Body {
        private final InputStream bodyIn;
        private final String contentLength;
        private final String contentType;
        /* access modifiers changed from: private */
        public final DiskLruCache.Snapshot snapshot;

        public CacheResponseBody(final DiskLruCache.Snapshot snapshot2, String str, String str2) {
            this.snapshot = snapshot2;
            this.contentType = str;
            this.contentLength = str2;
            this.bodyIn = new FilterInputStream(snapshot2.getInputStream(1)) {
                public void close() {
                    snapshot2.close();
                    super.close();
                }
            };
        }

        public InputStream byteStream() {
            return this.bodyIn;
        }

        public long contentLength() {
            try {
                if (this.contentLength != null) {
                    return Long.parseLong(this.contentLength);
                }
                return -1;
            } catch (NumberFormatException unused) {
                return -1;
            }
        }

        public MediaType contentType() {
            String str = this.contentType;
            if (str != null) {
                return MediaType.parse(str);
            }
            return null;
        }

        public boolean ready() {
            return true;
        }
    }

    private static final class Entry {
        private final Handshake handshake;
        private final String requestMethod;
        private final Headers responseHeaders;
        private final String statusLine;
        private final String url;
        private final Headers varyHeaders;

        public Entry(Response response) {
            this.url = response.request().urlString();
            this.varyHeaders = response.request().headers().getAll(response.getVaryFields());
            this.requestMethod = response.request().method();
            this.statusLine = response.statusLine();
            this.responseHeaders = response.headers();
            this.handshake = response.handshake();
        }

        public Entry(InputStream inputStream) {
            try {
                BufferedSource buffer = Okio.buffer(Okio.source(inputStream));
                this.url = buffer.readUtf8Line(true);
                this.requestMethod = buffer.readUtf8Line(true);
                Headers.Builder builder = new Headers.Builder();
                int access$400 = Cache.readInt(buffer);
                for (int i = 0; i < access$400; i++) {
                    builder.addLine(buffer.readUtf8Line(true));
                }
                this.varyHeaders = builder.build();
                this.statusLine = buffer.readUtf8Line(true);
                Headers.Builder builder2 = new Headers.Builder();
                int access$4002 = Cache.readInt(buffer);
                for (int i2 = 0; i2 < access$4002; i2++) {
                    builder2.addLine(buffer.readUtf8Line(true));
                }
                this.responseHeaders = builder2.build();
                if (isHttps()) {
                    String readUtf8Line = buffer.readUtf8Line(true);
                    if (readUtf8Line.length() <= 0) {
                        this.handshake = Handshake.get(buffer.readUtf8Line(true), readCertificateList(buffer), readCertificateList(buffer));
                    } else {
                        throw new IOException("expected \"\" but was \"" + readUtf8Line + "\"");
                    }
                } else {
                    this.handshake = null;
                }
            } finally {
                inputStream.close();
            }
        }

        private boolean isHttps() {
            return this.url.startsWith("https://");
        }

        private List<Certificate> readCertificateList(BufferedSource bufferedSource) {
            int access$400 = Cache.readInt(bufferedSource);
            if (access$400 == -1) {
                return Collections.emptyList();
            }
            try {
                CertificateFactory instance = CertificateFactory.getInstance("X.509");
                ArrayList arrayList = new ArrayList(access$400);
                for (int i = 0; i < access$400; i++) {
                    arrayList.add(instance.generateCertificate(new ByteArrayInputStream(ByteString.decodeBase64(bufferedSource.readUtf8Line(true)).toByteArray())));
                }
                return arrayList;
            } catch (CertificateException e) {
                throw new IOException(e.getMessage());
            }
        }

        private void writeCertArray(Writer writer, List<Certificate> list) {
            try {
                writer.write(Integer.toString(list.size()) + 10);
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    String base64 = ByteString.of(list.get(i).getEncoded()).base64();
                    writer.write(base64 + 10);
                }
            } catch (CertificateEncodingException e) {
                throw new IOException(e.getMessage());
            }
        }

        public boolean matches(Request request, Response response) {
            return this.url.equals(request.urlString()) && this.requestMethod.equals(request.method()) && response.varyMatches(this.varyHeaders, request);
        }

        public Response response(Request request, DiskLruCache.Snapshot snapshot) {
            return new Response.Builder().request(request).statusLine(this.statusLine).headers(this.responseHeaders).body(new CacheResponseBody(snapshot, this.responseHeaders.get("Content-Type"), this.responseHeaders.get("Content-Length"))).handshake(this.handshake).build();
        }

        public void writeTo(DiskLruCache.Editor editor) {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(editor.newOutputStream(0), Util.UTF_8));
            bufferedWriter.write(this.url + 10);
            bufferedWriter.write(this.requestMethod + 10);
            bufferedWriter.write(Integer.toString(this.varyHeaders.size()) + 10);
            for (int i = 0; i < this.varyHeaders.size(); i++) {
                bufferedWriter.write(this.varyHeaders.name(i) + ": " + this.varyHeaders.value(i) + 10);
            }
            bufferedWriter.write(this.statusLine + 10);
            bufferedWriter.write(Integer.toString(this.responseHeaders.size()) + 10);
            for (int i2 = 0; i2 < this.responseHeaders.size(); i2++) {
                bufferedWriter.write(this.responseHeaders.name(i2) + ": " + this.responseHeaders.value(i2) + 10);
            }
            if (isHttps()) {
                bufferedWriter.write(10);
                bufferedWriter.write(this.handshake.cipherSuite() + 10);
                writeCertArray(bufferedWriter, this.handshake.peerCertificates());
                writeCertArray(bufferedWriter, this.handshake.localCertificates());
            }
            bufferedWriter.close();
        }
    }

    public Cache(File file, long j) {
        this.cache = DiskLruCache.open(file, VERSION, 2, j);
    }

    private void abortQuietly(DiskLruCache.Editor editor) {
        if (editor != null) {
            try {
                editor.abort();
            } catch (IOException unused) {
            }
        }
    }

    static /* synthetic */ int access$208(Cache cache2) {
        int i = cache2.writeSuccessCount;
        cache2.writeSuccessCount = i + 1;
        return i;
    }

    static /* synthetic */ int access$308(Cache cache2) {
        int i = cache2.writeAbortCount;
        cache2.writeAbortCount = i + 1;
        return i;
    }

    /* access modifiers changed from: private */
    public static int readInt(BufferedSource bufferedSource) {
        String readUtf8Line = bufferedSource.readUtf8Line(true);
        try {
            return Integer.parseInt(readUtf8Line);
        } catch (NumberFormatException unused) {
            throw new IOException("Expected an integer but was \"" + readUtf8Line + "\"");
        }
    }

    private static String urlToKey(Request request) {
        return Util.hash(request.urlString());
    }

    public void close() {
        this.cache.close();
    }

    public void delete() {
        this.cache.delete();
    }

    public void flush() {
        this.cache.flush();
    }

    public Response get(Request request) {
        try {
            DiskLruCache.Snapshot snapshot = this.cache.get(urlToKey(request));
            if (snapshot == null) {
                return null;
            }
            Entry entry = new Entry(snapshot.getInputStream(0));
            Response response = entry.response(request, snapshot);
            if (entry.matches(request, response)) {
                return response;
            }
            Util.closeQuietly((Closeable) response.body());
            return null;
        } catch (IOException unused) {
            return null;
        }
    }

    public CacheResponse get(URI uri, String str, Map<String, List<String>> map) {
        throw new UnsupportedOperationException("This is not a general purpose response cache.");
    }

    public File getDirectory() {
        return this.cache.getDirectory();
    }

    public synchronized int getHitCount() {
        return this.hitCount;
    }

    public long getMaxSize() {
        return this.cache.getMaxSize();
    }

    public synchronized int getNetworkCount() {
        return this.networkCount;
    }

    public synchronized int getRequestCount() {
        return this.requestCount;
    }

    public long getSize() {
        return this.cache.size();
    }

    public synchronized int getWriteAbortCount() {
        return this.writeAbortCount;
    }

    public synchronized int getWriteSuccessCount() {
        return this.writeSuccessCount;
    }

    public boolean isClosed() {
        return this.cache.isClosed();
    }

    public boolean maybeRemove(Request request) {
        if (!HttpMethod.invalidatesCache(request.method())) {
            return false;
        }
        try {
            this.cache.remove(urlToKey(request));
            return true;
        } catch (IOException unused) {
            return true;
        }
    }

    public CacheRequest put(Response response) {
        DiskLruCache.Editor editor;
        String method = response.request().method();
        if (maybeRemove(response.request()) || !method.equals("GET") || response.hasVaryAll()) {
            return null;
        }
        Entry entry = new Entry(response);
        try {
            editor = this.cache.edit(urlToKey(response.request()));
            if (editor == null) {
                return null;
            }
            try {
                entry.writeTo(editor);
                return new CacheRequestImpl(editor);
            } catch (IOException unused) {
                abortQuietly(editor);
                return null;
            }
        } catch (IOException unused2) {
            editor = null;
            abortQuietly(editor);
            return null;
        }
    }

    public CacheRequest put(URI uri, URLConnection uRLConnection) {
        throw new UnsupportedOperationException("This is not a general purpose response cache.");
    }

    public synchronized void trackConditionalCacheHit() {
        this.hitCount++;
    }

    public synchronized void trackResponse(ResponseSource responseSource) {
        this.requestCount++;
        int i = AnonymousClass1.$SwitchMap$com$squareup$okhttp$ResponseSource[responseSource.ordinal()];
        if (i == 1) {
            this.hitCount++;
        } else if (i == 2 || i == 3) {
            this.networkCount++;
        }
    }

    public void update(Response response, Response response2) {
        DiskLruCache.Editor editor;
        Entry entry = new Entry(response2);
        try {
            editor = ((CacheResponseBody) response.body()).snapshot.edit();
            if (editor != null) {
                try {
                    entry.writeTo(editor);
                    editor.commit();
                } catch (IOException unused) {
                }
            }
        } catch (IOException unused2) {
            editor = null;
            abortQuietly(editor);
        }
    }
}
