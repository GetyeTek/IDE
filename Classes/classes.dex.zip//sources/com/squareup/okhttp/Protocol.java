package com.squareup.okhttp;

import com.squareup.okhttp.internal.okio.ByteString;

public enum Protocol {
    HTTP_2("HTTP-draft-09/2.0", true),
    SPDY_3("spdy/3.1", true),
    HTTP_11("http/1.1", false);
    
    @Deprecated
    public final ByteString name;
    @Deprecated
    public final boolean spdyVariant;

    private Protocol(String str, boolean z) {
        this.name = ByteString.encodeUtf8(str);
        this.spdyVariant = z;
    }
}
