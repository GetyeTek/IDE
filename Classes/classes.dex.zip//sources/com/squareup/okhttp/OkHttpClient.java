package com.squareup.okhttp;

import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.HttpAuthenticator;
import com.squareup.okhttp.internal.http.HttpURLConnectionImpl;
import com.squareup.okhttp.internal.http.HttpsURLConnectionImpl;
import com.squareup.okhttp.internal.http.ResponseCacheAdapter;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.tls.OkHostnameVerifier;
import java.io.IOException;
import java.net.CookieHandler;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.ResponseCache;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.net.URLStreamHandlerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;

public final class OkHttpClient implements URLStreamHandlerFactory, Cloneable {
    private OkAuthenticator authenticator;
    private int connectTimeout;
    private ConnectionPool connectionPool;
    private CookieHandler cookieHandler;
    private boolean followProtocolRedirects = true;
    private HostnameVerifier hostnameVerifier;
    private List<Protocol> protocols;
    private Proxy proxy;
    private ProxySelector proxySelector;
    private int readTimeout;
    private OkResponseCache responseCache;
    private final RouteDatabase routeDatabase = new RouteDatabase();
    private SSLSocketFactory sslSocketFactory;

    /* JADX WARNING: Can't wrap try/catch for region: R(6:4|5|6|7|8|9) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0016 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized javax.net.ssl.SSLSocketFactory getDefaultSSLSocketFactory() {
        /*
            r2 = this;
            monitor-enter(r2)
            javax.net.ssl.SSLSocketFactory r0 = r2.sslSocketFactory     // Catch:{ all -> 0x0020 }
            if (r0 != 0) goto L_0x001c
            java.lang.String r0 = "TLS"
            javax.net.ssl.SSLContext r0 = javax.net.ssl.SSLContext.getInstance(r0)     // Catch:{ GeneralSecurityException -> 0x0016 }
            r1 = 0
            r0.init(r1, r1, r1)     // Catch:{ GeneralSecurityException -> 0x0016 }
            javax.net.ssl.SSLSocketFactory r0 = r0.getSocketFactory()     // Catch:{ GeneralSecurityException -> 0x0016 }
            r2.sslSocketFactory = r0     // Catch:{ GeneralSecurityException -> 0x0016 }
            goto L_0x001c
        L_0x0016:
            java.lang.AssertionError r0 = new java.lang.AssertionError     // Catch:{ all -> 0x0020 }
            r0.<init>()     // Catch:{ all -> 0x0020 }
            throw r0     // Catch:{ all -> 0x0020 }
        L_0x001c:
            javax.net.ssl.SSLSocketFactory r0 = r2.sslSocketFactory     // Catch:{ all -> 0x0020 }
            monitor-exit(r2)
            return r0
        L_0x0020:
            r0 = move-exception
            monitor-exit(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.OkHttpClient.getDefaultSSLSocketFactory():javax.net.ssl.SSLSocketFactory");
    }

    private OkResponseCache toOkResponseCache(ResponseCache responseCache2) {
        return (responseCache2 == null || (responseCache2 instanceof OkResponseCache)) ? (OkResponseCache) responseCache2 : new ResponseCacheAdapter(responseCache2);
    }

    public OkHttpClient clone() {
        try {
            return (OkHttpClient) super.clone();
        } catch (CloneNotSupportedException unused) {
            throw new AssertionError();
        }
    }

    /* access modifiers changed from: package-private */
    public OkHttpClient copyWithDefaults() {
        OkHttpClient clone = clone();
        if (clone.proxySelector == null) {
            clone.proxySelector = ProxySelector.getDefault();
        }
        if (clone.cookieHandler == null) {
            clone.cookieHandler = CookieHandler.getDefault();
        }
        if (clone.responseCache == null) {
            clone.responseCache = toOkResponseCache(ResponseCache.getDefault());
        }
        if (clone.sslSocketFactory == null) {
            clone.sslSocketFactory = getDefaultSSLSocketFactory();
        }
        if (clone.hostnameVerifier == null) {
            clone.hostnameVerifier = OkHostnameVerifier.INSTANCE;
        }
        if (clone.authenticator == null) {
            clone.authenticator = HttpAuthenticator.SYSTEM_DEFAULT;
        }
        if (clone.connectionPool == null) {
            clone.connectionPool = ConnectionPool.getDefault();
        }
        if (clone.protocols == null) {
            clone.protocols = Util.HTTP2_SPDY3_AND_HTTP;
        }
        return clone;
    }

    @Deprecated
    public URLStreamHandler createURLStreamHandler(final String str) {
        if (str.equals("http") || str.equals("https")) {
            return new URLStreamHandler() {
                /* access modifiers changed from: protected */
                public int getDefaultPort() {
                    if (str.equals("http")) {
                        return 80;
                    }
                    if (str.equals("https")) {
                        return 443;
                    }
                    throw new AssertionError();
                }

                /* access modifiers changed from: protected */
                public URLConnection openConnection(URL url) {
                    return OkHttpClient.this.open(url);
                }

                /* access modifiers changed from: protected */
                public URLConnection openConnection(URL url, Proxy proxy) {
                    return OkHttpClient.this.open(url, proxy);
                }
            };
        }
        return null;
    }

    public OkAuthenticator getAuthenticator() {
        return this.authenticator;
    }

    public Cache getCache() {
        OkResponseCache okResponseCache = this.responseCache;
        if (okResponseCache instanceof Cache) {
            return (Cache) okResponseCache;
        }
        return null;
    }

    public int getConnectTimeout() {
        return this.connectTimeout;
    }

    public ConnectionPool getConnectionPool() {
        return this.connectionPool;
    }

    public CookieHandler getCookieHandler() {
        return this.cookieHandler;
    }

    @Deprecated
    public boolean getFollowProtocolRedirects() {
        return this.followProtocolRedirects;
    }

    public boolean getFollowSslRedirects() {
        return this.followProtocolRedirects;
    }

    public HostnameVerifier getHostnameVerifier() {
        return this.hostnameVerifier;
    }

    @Deprecated
    public OkResponseCache getOkResponseCache() {
        return this.responseCache;
    }

    public List<Protocol> getProtocols() {
        return this.protocols;
    }

    public Proxy getProxy() {
        return this.proxy;
    }

    public ProxySelector getProxySelector() {
        return this.proxySelector;
    }

    public int getReadTimeout() {
        return this.readTimeout;
    }

    @Deprecated
    public ResponseCache getResponseCache() {
        OkResponseCache okResponseCache = this.responseCache;
        if (okResponseCache instanceof ResponseCacheAdapter) {
            return ((ResponseCacheAdapter) okResponseCache).getDelegate();
        }
        return null;
    }

    @Deprecated
    public RouteDatabase getRoutesDatabase() {
        return this.routeDatabase;
    }

    public SSLSocketFactory getSslSocketFactory() {
        return this.sslSocketFactory;
    }

    @Deprecated
    public List<String> getTransports() {
        ArrayList arrayList = new ArrayList(this.protocols.size());
        int size = this.protocols.size();
        for (int i = 0; i < size; i++) {
            arrayList.add(this.protocols.get(i).name.utf8());
        }
        return arrayList;
    }

    @Deprecated
    public HttpURLConnection open(URL url) {
        return open(url, this.proxy);
    }

    /* access modifiers changed from: package-private */
    public HttpURLConnection open(URL url, Proxy proxy2) {
        String protocol = url.getProtocol();
        OkHttpClient copyWithDefaults = copyWithDefaults();
        copyWithDefaults.proxy = proxy2;
        if (protocol.equals("http")) {
            return new HttpURLConnectionImpl(url, copyWithDefaults);
        }
        if (protocol.equals("https")) {
            return new HttpsURLConnectionImpl(url, copyWithDefaults);
        }
        throw new IllegalArgumentException("Unexpected protocol: " + protocol);
    }

    public OkHttpClient setAuthenticator(OkAuthenticator okAuthenticator) {
        this.authenticator = okAuthenticator;
        return this;
    }

    public OkHttpClient setCache(Cache cache) {
        this.responseCache = cache;
        return this;
    }

    public void setConnectTimeout(long j, TimeUnit timeUnit) {
        if (j < 0) {
            throw new IllegalArgumentException("timeout < 0");
        } else if (timeUnit != null) {
            long millis = timeUnit.toMillis(j);
            if (millis <= 2147483647L) {
                this.connectTimeout = (int) millis;
                return;
            }
            throw new IllegalArgumentException("Timeout too large.");
        } else {
            throw new IllegalArgumentException("unit == null");
        }
    }

    public OkHttpClient setConnectionPool(ConnectionPool connectionPool2) {
        this.connectionPool = connectionPool2;
        return this;
    }

    public OkHttpClient setCookieHandler(CookieHandler cookieHandler2) {
        this.cookieHandler = cookieHandler2;
        return this;
    }

    @Deprecated
    public OkHttpClient setFollowProtocolRedirects(boolean z) {
        this.followProtocolRedirects = z;
        return this;
    }

    public OkHttpClient setFollowSslRedirects(boolean z) {
        this.followProtocolRedirects = z;
        return this;
    }

    public OkHttpClient setHostnameVerifier(HostnameVerifier hostnameVerifier2) {
        this.hostnameVerifier = hostnameVerifier2;
        return this;
    }

    @Deprecated
    public OkHttpClient setOkResponseCache(OkResponseCache okResponseCache) {
        this.responseCache = okResponseCache;
        return this;
    }

    public OkHttpClient setProtocols(List<Protocol> list) {
        List<T> immutableList = Util.immutableList(list);
        if (!immutableList.contains(Protocol.HTTP_11)) {
            throw new IllegalArgumentException("protocols doesn't contain http/1.1: " + immutableList);
        } else if (!immutableList.contains((Object) null)) {
            this.protocols = Util.immutableList(immutableList);
            return this;
        } else {
            throw new IllegalArgumentException("protocols must not contain null");
        }
    }

    public OkHttpClient setProxy(Proxy proxy2) {
        this.proxy = proxy2;
        return this;
    }

    public OkHttpClient setProxySelector(ProxySelector proxySelector2) {
        this.proxySelector = proxySelector2;
        return this;
    }

    public void setReadTimeout(long j, TimeUnit timeUnit) {
        if (j < 0) {
            throw new IllegalArgumentException("timeout < 0");
        } else if (timeUnit != null) {
            long millis = timeUnit.toMillis(j);
            if (millis <= 2147483647L) {
                this.readTimeout = (int) millis;
                return;
            }
            throw new IllegalArgumentException("Timeout too large.");
        } else {
            throw new IllegalArgumentException("unit == null");
        }
    }

    @Deprecated
    public OkHttpClient setResponseCache(ResponseCache responseCache2) {
        return setOkResponseCache(toOkResponseCache(responseCache2));
    }

    public OkHttpClient setSslSocketFactory(SSLSocketFactory sSLSocketFactory) {
        this.sslSocketFactory = sSLSocketFactory;
        return this;
    }

    @Deprecated
    public OkHttpClient setTransports(List<String> list) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        int i = 0;
        while (i < size) {
            try {
                arrayList.add(Util.getProtocol(ByteString.encodeUtf8(list.get(i))));
                i++;
            } catch (IOException e) {
                throw new IllegalArgumentException(e);
            }
        }
        return setProtocols(arrayList);
    }
}
