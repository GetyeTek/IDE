package com.squareup.okhttp;

import java.io.File;

@Deprecated
public final class HttpResponseCache extends Cache {
    public HttpResponseCache(File file, long j) {
        super(file, j);
    }
}
