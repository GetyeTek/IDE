package com.squareup.okhttp.internal.spdy;

import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.Deadline;
import com.squareup.okhttp.internal.okio.InflaterSource;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.okio.Source;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

class NameValueBlockReader {
    /* access modifiers changed from: private */
    public int compressedLimit;
    private final InflaterSource inflaterSource;
    private final BufferedSource source = Okio.buffer((Source) this.inflaterSource);

    public NameValueBlockReader(final BufferedSource bufferedSource) {
        this.inflaterSource = new InflaterSource((Source) new Source() {
            public void close() {
                bufferedSource.close();
            }

            public Source deadline(Deadline deadline) {
                bufferedSource.deadline(deadline);
                return this;
            }

            public long read(OkBuffer okBuffer, long j) {
                if (NameValueBlockReader.this.compressedLimit == 0) {
                    return -1;
                }
                long read = bufferedSource.read(okBuffer, Math.min(j, (long) NameValueBlockReader.this.compressedLimit));
                if (read == -1) {
                    return -1;
                }
                NameValueBlockReader.access$022(NameValueBlockReader.this, read);
                return read;
            }
        }, (Inflater) new Inflater() {
            public int inflate(byte[] bArr, int i, int i2) {
                int inflate = super.inflate(bArr, i, i2);
                if (inflate != 0 || !needsDictionary()) {
                    return inflate;
                }
                setDictionary(Spdy3.DICTIONARY);
                return super.inflate(bArr, i, i2);
            }
        });
    }

    static /* synthetic */ int access$022(NameValueBlockReader nameValueBlockReader, long j) {
        int i = (int) (((long) nameValueBlockReader.compressedLimit) - j);
        nameValueBlockReader.compressedLimit = i;
        return i;
    }

    private void doneReading() {
        if (this.compressedLimit > 0) {
            this.inflaterSource.refill();
            if (this.compressedLimit != 0) {
                throw new IOException("compressedLimit > 0: " + this.compressedLimit);
            }
        }
    }

    private ByteString readByteString() {
        return this.source.readByteString((long) this.source.readInt());
    }

    public void close() {
        this.source.close();
    }

    public List<Header> readNameValueBlock(int i) {
        this.compressedLimit += i;
        int readInt = this.source.readInt();
        if (readInt < 0) {
            throw new IOException("numberOfPairs < 0: " + readInt);
        } else if (readInt <= 1024) {
            ArrayList arrayList = new ArrayList(readInt);
            int i2 = 0;
            while (i2 < readInt) {
                ByteString asciiLowercase = readByteString().toAsciiLowercase();
                ByteString readByteString = readByteString();
                if (asciiLowercase.size() != 0) {
                    arrayList.add(new Header(asciiLowercase, readByteString));
                    i2++;
                } else {
                    throw new IOException("name.size == 0");
                }
            }
            doneReading();
            return arrayList;
        } else {
            throw new IOException("numberOfPairs > 1024: " + readInt);
        }
    }
}
