package com.squareup.okhttp.internal.okio;

import java.io.Closeable;

public interface Sink extends Closeable {
    void close();

    Sink deadline(Deadline deadline);

    void flush();

    void write(OkBuffer okBuffer, long j);
}
