package com.squareup.okhttp.internal.spdy;

import com.squareup.okhttp.internal.BitArray;
import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.okio.Source;
import com.squareup.okhttp.internal.spdy.Huffman;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class HpackDraft05 {
    /* access modifiers changed from: private */
    public static final Map<ByteString, Integer> NAME_TO_FIRST_INDEX = nameToFirstIndex();
    private static final int PREFIX_6_BITS = 63;
    private static final int PREFIX_7_BITS = 127;
    /* access modifiers changed from: private */
    public static final Header[] STATIC_HEADER_TABLE = {new Header(Header.TARGET_AUTHORITY, ""), new Header(Header.TARGET_METHOD, "GET"), new Header(Header.TARGET_METHOD, "POST"), new Header(Header.TARGET_PATH, "/"), new Header(Header.TARGET_PATH, "/index.html"), new Header(Header.TARGET_SCHEME, "http"), new Header(Header.TARGET_SCHEME, "https"), new Header(Header.RESPONSE_STATUS, "200"), new Header(Header.RESPONSE_STATUS, "500"), new Header(Header.RESPONSE_STATUS, "404"), new Header(Header.RESPONSE_STATUS, "403"), new Header(Header.RESPONSE_STATUS, "400"), new Header(Header.RESPONSE_STATUS, "401"), new Header("accept-charset", ""), new Header("accept-encoding", ""), new Header("accept-language", ""), new Header("accept-ranges", ""), new Header("accept", ""), new Header("access-control-allow-origin", ""), new Header("age", ""), new Header("allow", ""), new Header("authorization", ""), new Header("cache-control", ""), new Header("content-disposition", ""), new Header("content-encoding", ""), new Header("content-language", ""), new Header("content-length", ""), new Header("content-location", ""), new Header("content-range", ""), new Header("content-type", ""), new Header("cookie", ""), new Header("date", ""), new Header("etag", ""), new Header("expect", ""), new Header("expires", ""), new Header("from", ""), new Header("host", ""), new Header("if-match", ""), new Header("if-modified-since", ""), new Header("if-none-match", ""), new Header("if-range", ""), new Header("if-unmodified-since", ""), new Header("last-modified", ""), new Header("link", ""), new Header("location", ""), new Header("max-forwards", ""), new Header("proxy-authenticate", ""), new Header("proxy-authorization", ""), new Header("range", ""), new Header("referer", ""), new Header("refresh", ""), new Header("retry-after", ""), new Header("server", ""), new Header("set-cookie", ""), new Header("strict-transport-security", ""), new Header("transfer-encoding", ""), new Header("user-agent", ""), new Header("vary", ""), new Header("via", ""), new Header("www-authenticate", "")};

    static final class Reader {
        private final List<Header> emittedHeaders = new ArrayList();
        BitArray emittedReferencedHeaders = new BitArray.FixedCapacity();
        int headerCount = 0;
        Header[] headerTable = new Header[8];
        int headerTableByteCount = 0;
        private final Huffman.Codec huffmanCodec;
        private int maxHeaderTableByteCount;
        int nextHeaderIndex = (this.headerTable.length - 1);
        BitArray referencedHeaders = new BitArray.FixedCapacity();
        private final BufferedSource source;

        Reader(boolean z, int i, Source source2) {
            this.huffmanCodec = z ? Huffman.Codec.RESPONSE : Huffman.Codec.REQUEST;
            this.maxHeaderTableByteCount = i;
            this.source = Okio.buffer(source2);
        }

        private void clearHeaderTable() {
            clearReferenceSet();
            Arrays.fill(this.headerTable, (Object) null);
            this.nextHeaderIndex = this.headerTable.length - 1;
            this.headerCount = 0;
            this.headerTableByteCount = 0;
        }

        private void clearReferenceSet() {
            this.referencedHeaders.clear();
            this.emittedReferencedHeaders.clear();
        }

        private int evictToRecoverBytes(int i) {
            int i2 = 0;
            if (i > 0) {
                int length = this.headerTable.length;
                while (true) {
                    length--;
                    if (length < this.nextHeaderIndex || i <= 0) {
                        this.referencedHeaders.shiftLeft(i2);
                        this.emittedReferencedHeaders.shiftLeft(i2);
                        Header[] headerArr = this.headerTable;
                        int i3 = this.nextHeaderIndex;
                        System.arraycopy(headerArr, i3 + 1, headerArr, i3 + 1 + i2, this.headerCount);
                        this.nextHeaderIndex += i2;
                    } else {
                        Header[] headerArr2 = this.headerTable;
                        i -= headerArr2[length].hpackSize;
                        this.headerTableByteCount -= headerArr2[length].hpackSize;
                        this.headerCount--;
                        i2++;
                    }
                }
                this.referencedHeaders.shiftLeft(i2);
                this.emittedReferencedHeaders.shiftLeft(i2);
                Header[] headerArr3 = this.headerTable;
                int i32 = this.nextHeaderIndex;
                System.arraycopy(headerArr3, i32 + 1, headerArr3, i32 + 1 + i2, this.headerCount);
                this.nextHeaderIndex += i2;
            }
            return i2;
        }

        private ByteString getName(int i) {
            return (isStaticHeader(i) ? HpackDraft05.STATIC_HEADER_TABLE[i - this.headerCount] : this.headerTable[headerTableIndex(i)]).name;
        }

        private int headerTableIndex(int i) {
            return this.nextHeaderIndex + 1 + i;
        }

        private void insertIntoHeaderTable(int i, Header header) {
            int i2 = header.hpackSize;
            if (i != -1) {
                i2 -= this.headerTable[headerTableIndex(i)].hpackSize;
            }
            int i3 = this.maxHeaderTableByteCount;
            if (i2 > i3) {
                clearHeaderTable();
                this.emittedHeaders.add(header);
                return;
            }
            int evictToRecoverBytes = evictToRecoverBytes((this.headerTableByteCount + i2) - i3);
            if (i == -1) {
                int i4 = this.headerCount + 1;
                Header[] headerArr = this.headerTable;
                if (i4 > headerArr.length) {
                    Header[] headerArr2 = new Header[(headerArr.length * 2)];
                    System.arraycopy(headerArr, 0, headerArr2, headerArr.length, headerArr.length);
                    if (headerArr2.length == 64) {
                        this.referencedHeaders = ((BitArray.FixedCapacity) this.referencedHeaders).toVariableCapacity();
                        this.emittedReferencedHeaders = ((BitArray.FixedCapacity) this.emittedReferencedHeaders).toVariableCapacity();
                    }
                    this.referencedHeaders.shiftLeft(this.headerTable.length);
                    this.emittedReferencedHeaders.shiftLeft(this.headerTable.length);
                    this.nextHeaderIndex = this.headerTable.length - 1;
                    this.headerTable = headerArr2;
                }
                int i5 = this.nextHeaderIndex;
                this.nextHeaderIndex = i5 - 1;
                this.referencedHeaders.set(i5);
                this.headerTable[i5] = header;
                this.headerCount++;
            } else {
                int headerTableIndex = i + headerTableIndex(i) + evictToRecoverBytes;
                this.referencedHeaders.set(headerTableIndex);
                this.headerTable[headerTableIndex] = header;
            }
            this.headerTableByteCount += i2;
        }

        private boolean isStaticHeader(int i) {
            return i >= this.headerCount;
        }

        private int readByte() {
            return this.source.readByte() & 255;
        }

        private void readIndexedHeader(int i) {
            if (isStaticHeader(i)) {
                Header header = HpackDraft05.STATIC_HEADER_TABLE[i - this.headerCount];
                if (this.maxHeaderTableByteCount == 0) {
                    this.emittedHeaders.add(header);
                } else {
                    insertIntoHeaderTable(-1, header);
                }
            } else {
                int headerTableIndex = headerTableIndex(i);
                if (!this.referencedHeaders.get(headerTableIndex)) {
                    this.emittedHeaders.add(this.headerTable[headerTableIndex]);
                    this.emittedReferencedHeaders.set(headerTableIndex);
                }
                this.referencedHeaders.toggle(headerTableIndex);
            }
        }

        private void readLiteralHeaderWithIncrementalIndexingIndexedName(int i) {
            insertIntoHeaderTable(-1, new Header(getName(i), readByteString(false)));
        }

        private void readLiteralHeaderWithIncrementalIndexingNewName() {
            insertIntoHeaderTable(-1, new Header(readByteString(true), readByteString(false)));
        }

        private void readLiteralHeaderWithoutIndexingIndexedName(int i) {
            this.emittedHeaders.add(new Header(getName(i), readByteString(false)));
        }

        private void readLiteralHeaderWithoutIndexingNewName() {
            this.emittedHeaders.add(new Header(readByteString(true), readByteString(false)));
        }

        /* access modifiers changed from: package-private */
        public void emitReferenceSet() {
            int length = this.headerTable.length;
            while (true) {
                length--;
                if (length == this.nextHeaderIndex) {
                    return;
                }
                if (this.referencedHeaders.get(length) && !this.emittedReferencedHeaders.get(length)) {
                    this.emittedHeaders.add(this.headerTable[length]);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public List<Header> getAndReset() {
            ArrayList arrayList = new ArrayList(this.emittedHeaders);
            this.emittedHeaders.clear();
            this.emittedReferencedHeaders.clear();
            return arrayList;
        }

        /* access modifiers changed from: package-private */
        public int maxHeaderTableByteCount() {
            return this.maxHeaderTableByteCount;
        }

        /* access modifiers changed from: package-private */
        public void maxHeaderTableByteCount(int i) {
            this.maxHeaderTableByteCount = i;
            int i2 = this.maxHeaderTableByteCount;
            int i3 = this.headerTableByteCount;
            if (i2 >= i3) {
                return;
            }
            if (i2 == 0) {
                clearHeaderTable();
            } else {
                evictToRecoverBytes(i3 - i2);
            }
        }

        /* access modifiers changed from: package-private */
        public ByteString readByteString(boolean z) {
            int readByte = readByte();
            boolean z2 = (readByte & 128) == 128;
            ByteString readByteString = this.source.readByteString((long) readInt(readByte, HpackDraft05.PREFIX_7_BITS));
            if (z2) {
                readByteString = this.huffmanCodec.decode(readByteString);
            }
            return z ? readByteString.toAsciiLowercase() : readByteString;
        }

        /* access modifiers changed from: package-private */
        public void readHeaders() {
            while (!this.source.exhausted()) {
                byte readByte = this.source.readByte() & 255;
                if (readByte == 128) {
                    clearReferenceSet();
                } else if ((readByte & 128) == 128) {
                    readIndexedHeader(readInt(readByte, HpackDraft05.PREFIX_7_BITS) - 1);
                } else if (readByte == 64) {
                    readLiteralHeaderWithoutIndexingNewName();
                } else if ((readByte & 64) == 64) {
                    readLiteralHeaderWithoutIndexingIndexedName(readInt(readByte, 63) - 1);
                } else if (readByte == 0) {
                    readLiteralHeaderWithIncrementalIndexingNewName();
                } else if ((readByte & 192) == 0) {
                    readLiteralHeaderWithIncrementalIndexingIndexedName(readInt(readByte, 63) - 1);
                } else {
                    throw new AssertionError("unhandled byte: " + Integer.toBinaryString(readByte));
                }
            }
        }

        /* access modifiers changed from: package-private */
        public int readInt(int i, int i2) {
            int i3 = i & i2;
            if (i3 < i2) {
                return i3;
            }
            int i4 = 0;
            while (true) {
                int readByte = readByte();
                if ((readByte & 128) == 0) {
                    return i2 + (readByte << i4);
                }
                i2 += (readByte & HpackDraft05.PREFIX_7_BITS) << i4;
                i4 += 7;
            }
        }
    }

    static final class Writer {
        private final OkBuffer out;

        Writer(OkBuffer okBuffer) {
            this.out = okBuffer;
        }

        /* access modifiers changed from: package-private */
        public void writeByteString(ByteString byteString) {
            writeInt(byteString.size(), HpackDraft05.PREFIX_7_BITS, 0);
            this.out.write(byteString);
        }

        /* access modifiers changed from: package-private */
        public void writeHeaders(List<Header> list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                ByteString byteString = list.get(i).name;
                Integer num = (Integer) HpackDraft05.NAME_TO_FIRST_INDEX.get(byteString);
                if (num != null) {
                    writeInt(num.intValue() + 1, 63, 64);
                } else {
                    this.out.writeByte(64);
                    writeByteString(byteString);
                }
                writeByteString(list.get(i).value);
            }
        }

        /* access modifiers changed from: package-private */
        public void writeInt(int i, int i2, int i3) {
            int i4;
            OkBuffer okBuffer;
            if (i < i2) {
                okBuffer = this.out;
                i4 = i | i3;
            } else {
                this.out.writeByte(i3 | i2);
                i4 = i - i2;
                while (i4 >= 128) {
                    this.out.writeByte(128 | (i4 & HpackDraft05.PREFIX_7_BITS));
                    i4 >>>= 7;
                }
                okBuffer = this.out;
            }
            okBuffer.writeByte(i4);
        }
    }

    private HpackDraft05() {
    }

    private static Map<ByteString, Integer> nameToFirstIndex() {
        LinkedHashMap linkedHashMap = new LinkedHashMap(STATIC_HEADER_TABLE.length);
        int i = 0;
        while (true) {
            Header[] headerArr = STATIC_HEADER_TABLE;
            if (i >= headerArr.length) {
                return Collections.unmodifiableMap(linkedHashMap);
            }
            if (!linkedHashMap.containsKey(headerArr[i].name)) {
                linkedHashMap.put(STATIC_HEADER_TABLE[i].name, Integer.valueOf(i));
            }
            i++;
        }
    }
}
