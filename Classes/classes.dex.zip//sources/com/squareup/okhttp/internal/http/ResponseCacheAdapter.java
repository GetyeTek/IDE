package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.Handshake;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkResponseCache;
import com.squareup.okhttp.ResponseSource;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.http.Response;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CacheRequest;
import java.net.CacheResponse;
import java.net.HttpURLConnection;
import java.net.ResponseCache;
import java.net.SecureCacheResponse;
import java.security.cert.Certificate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocketFactory;

public class ResponseCacheAdapter implements OkResponseCache {
    private final ResponseCache delegate;

    private static final class CacheHttpURLConnection extends HttpURLConnection {
        private final Request request;
        /* access modifiers changed from: private */
        public final Response response;

        public CacheHttpURLConnection(Response response2) {
            super(response2.request().url());
            this.request = response2.request();
            this.response = response2;
            boolean z = true;
            this.connected = true;
            this.doOutput = response2.body() != null ? false : z;
            this.method = this.request.method();
        }

        public void addRequestProperty(String str, String str2) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void connect() {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void disconnect() {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public boolean getAllowUserInteraction() {
            return false;
        }

        public int getConnectTimeout() {
            return 0;
        }

        public Object getContent() {
            ResponseCacheAdapter.access$200();
            throw null;
        }

        public Object getContent(Class[] clsArr) {
            ResponseCacheAdapter.access$200();
            throw null;
        }

        public boolean getDefaultUseCaches() {
            return super.getDefaultUseCaches();
        }

        public boolean getDoInput() {
            return true;
        }

        public boolean getDoOutput() {
            return this.request.body() != null;
        }

        public InputStream getErrorStream() {
            return null;
        }

        public String getHeaderField(int i) {
            if (i >= 0) {
                return i == 0 ? this.response.statusLine() : this.response.headers().value(i - 1);
            }
            throw new IllegalArgumentException("Invalid header index: " + i);
        }

        public String getHeaderField(String str) {
            return str == null ? this.response.statusLine() : this.response.headers().get(str);
        }

        public String getHeaderFieldKey(int i) {
            if (i < 0) {
                throw new IllegalArgumentException("Invalid header index: " + i);
            } else if (i == 0) {
                return null;
            } else {
                return this.response.headers().name(i - 1);
            }
        }

        public Map<String, List<String>> getHeaderFields() {
            return OkHeaders.toMultimap(this.response.headers(), this.response.statusLine());
        }

        public long getIfModifiedSince() {
            return 0;
        }

        public InputStream getInputStream() {
            ResponseCacheAdapter.access$200();
            throw null;
        }

        public boolean getInstanceFollowRedirects() {
            return super.getInstanceFollowRedirects();
        }

        public OutputStream getOutputStream() {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public int getReadTimeout() {
            return 0;
        }

        public String getRequestMethod() {
            return this.request.method();
        }

        public Map<String, List<String>> getRequestProperties() {
            ResponseCacheAdapter.access$100();
            throw null;
        }

        public String getRequestProperty(String str) {
            return this.request.header(str);
        }

        public int getResponseCode() {
            return this.response.code();
        }

        public String getResponseMessage() {
            return this.response.statusMessage();
        }

        public boolean getUseCaches() {
            return super.getUseCaches();
        }

        public void setAllowUserInteraction(boolean z) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setChunkedStreamingMode(int i) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setConnectTimeout(int i) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setDefaultUseCaches(boolean z) {
            super.setDefaultUseCaches(z);
        }

        public void setDoInput(boolean z) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setDoOutput(boolean z) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setFixedLengthStreamingMode(int i) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setFixedLengthStreamingMode(long j) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setIfModifiedSince(long j) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setInstanceFollowRedirects(boolean z) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setReadTimeout(int i) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setRequestMethod(String str) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setRequestProperty(String str, String str2) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setUseCaches(boolean z) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public boolean usingProxy() {
            return false;
        }
    }

    private static final class CacheHttpsURLConnection extends DelegatingHttpsURLConnection {
        private final CacheHttpURLConnection delegate;

        public CacheHttpsURLConnection(CacheHttpURLConnection cacheHttpURLConnection) {
            super(cacheHttpURLConnection);
            this.delegate = cacheHttpURLConnection;
        }

        public long getContentLengthLong() {
            return this.delegate.getContentLengthLong();
        }

        public long getHeaderFieldLong(String str, long j) {
            return this.delegate.getHeaderFieldLong(str, j);
        }

        public HostnameVerifier getHostnameVerifier() {
            ResponseCacheAdapter.access$400();
            throw null;
        }

        public SSLSocketFactory getSSLSocketFactory() {
            ResponseCacheAdapter.access$400();
            throw null;
        }

        /* access modifiers changed from: protected */
        public Handshake handshake() {
            return this.delegate.response.handshake();
        }

        public void setFixedLengthStreamingMode(long j) {
            this.delegate.setFixedLengthStreamingMode(j);
        }

        public void setHostnameVerifier(HostnameVerifier hostnameVerifier) {
            ResponseCacheAdapter.access$000();
            throw null;
        }

        public void setSSLSocketFactory(SSLSocketFactory sSLSocketFactory) {
            ResponseCacheAdapter.access$000();
            throw null;
        }
    }

    public ResponseCacheAdapter(ResponseCache responseCache) {
        this.delegate = responseCache;
    }

    static /* synthetic */ RuntimeException access$000() {
        throwRequestModificationException();
        throw null;
    }

    static /* synthetic */ RuntimeException access$100() {
        throwRequestHeaderAccessException();
        throw null;
    }

    static /* synthetic */ RuntimeException access$200() {
        throwResponseBodyAccessException();
        throw null;
    }

    static /* synthetic */ RuntimeException access$400() {
        throwRequestSslAccessException();
        throw null;
    }

    private static HttpURLConnection createJavaUrlConnection(Response response) {
        return response.request().isHttps() ? new CacheHttpsURLConnection(new CacheHttpURLConnection(response)) : new CacheHttpURLConnection(response);
    }

    private static Response.Body createOkBody(final Headers headers, final InputStream inputStream) {
        return new Response.Body() {
            public InputStream byteStream() {
                return inputStream;
            }

            public long contentLength() {
                return OkHeaders.contentLength(headers);
            }

            public MediaType contentType() {
                String str = headers.get("Content-Type");
                if (str == null) {
                    return null;
                }
                return MediaType.parse(str);
            }

            public boolean ready() {
                return true;
            }
        };
    }

    private static Map<String, List<String>> extractJavaHeaders(Request request) {
        return OkHeaders.toMultimap(request.headers(), (String) null);
    }

    private static Headers extractOkHeaders(CacheResponse cacheResponse) {
        Map<String, List<String>> headers = cacheResponse.getHeaders();
        Headers.Builder builder = new Headers.Builder();
        for (Map.Entry next : headers.entrySet()) {
            String str = (String) next.getKey();
            if (str != null) {
                for (String add : (List) next.getValue()) {
                    builder.add(str, add);
                }
            }
        }
        return builder.build();
    }

    private static String extractStatusLine(CacheResponse cacheResponse) {
        List list = cacheResponse.getHeaders().get((Object) null);
        if (list == null || list.size() == 0) {
            return null;
        }
        return (String) list.get(0);
    }

    private CacheResponse getJavaCachedResponse(Request request) {
        return this.delegate.get(request.uri(), request.method(), extractJavaHeaders(request));
    }

    private static RuntimeException throwRequestHeaderAccessException() {
        throw new UnsupportedOperationException("ResponseCache cannot access request headers");
    }

    private static RuntimeException throwRequestModificationException() {
        throw new UnsupportedOperationException("ResponseCache cannot modify the request.");
    }

    private static RuntimeException throwRequestSslAccessException() {
        throw new UnsupportedOperationException("ResponseCache cannot access SSL internals");
    }

    private static RuntimeException throwResponseBodyAccessException() {
        throw new UnsupportedOperationException("ResponseCache cannot access the response body.");
    }

    public Response get(Request request) {
        List<Certificate> list;
        CacheResponse javaCachedResponse = getJavaCachedResponse(request);
        if (javaCachedResponse == null) {
            return null;
        }
        Response.Builder builder = new Response.Builder();
        builder.request(request);
        builder.statusLine(extractStatusLine(javaCachedResponse));
        Headers extractOkHeaders = extractOkHeaders(javaCachedResponse);
        builder.headers(extractOkHeaders);
        builder.setResponseSource(ResponseSource.CACHE);
        builder.body(createOkBody(extractOkHeaders, javaCachedResponse.getBody()));
        if (javaCachedResponse instanceof SecureCacheResponse) {
            SecureCacheResponse secureCacheResponse = (SecureCacheResponse) javaCachedResponse;
            try {
                list = secureCacheResponse.getServerCertificateChain();
            } catch (SSLPeerUnverifiedException unused) {
                list = Collections.emptyList();
            }
            List<Certificate> localCertificateChain = secureCacheResponse.getLocalCertificateChain();
            if (localCertificateChain == null) {
                localCertificateChain = Collections.emptyList();
            }
            builder.handshake(Handshake.get(secureCacheResponse.getCipherSuite(), list, localCertificateChain));
        }
        return builder.build();
    }

    public ResponseCache getDelegate() {
        return this.delegate;
    }

    public boolean maybeRemove(Request request) {
        return false;
    }

    public CacheRequest put(Response response) {
        return this.delegate.put(response.request().uri(), createJavaUrlConnection(response));
    }

    public void trackConditionalCacheHit() {
    }

    public void trackResponse(ResponseSource responseSource) {
    }

    public void update(Response response, Response response2) {
    }
}
