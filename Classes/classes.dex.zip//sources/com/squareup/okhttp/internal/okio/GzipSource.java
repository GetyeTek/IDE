package com.squareup.okhttp.internal.okio;

import java.io.IOException;
import java.util.zip.CRC32;
import java.util.zip.Inflater;

public final class GzipSource implements Source {
    private static final byte FCOMMENT = 4;
    private static final byte FEXTRA = 2;
    private static final byte FHCRC = 1;
    private static final byte FNAME = 3;
    private static final byte SECTION_BODY = 1;
    private static final byte SECTION_DONE = 3;
    private static final byte SECTION_HEADER = 0;
    private static final byte SECTION_TRAILER = 2;
    private final CRC32 crc = new CRC32();
    private final Inflater inflater = new Inflater(true);
    private final InflaterSource inflaterSource;
    private int section = 0;
    private final BufferedSource source;

    public GzipSource(Source source2) {
        this.source = Okio.buffer(source2);
        this.inflaterSource = new InflaterSource(this.source, this.inflater);
    }

    private void checkEqual(String str, int i, int i2) {
        if (i2 != i) {
            throw new IOException(String.format("%s: actual 0x%08x != expected 0x%08x", new Object[]{str, Integer.valueOf(i2), Integer.valueOf(i)}));
        }
    }

    private void consumeHeader() {
        this.source.require(10);
        byte b2 = this.source.buffer().getByte(3);
        boolean z = ((b2 >> 1) & 1) == 1;
        if (z) {
            updateCrc(this.source.buffer(), 0, 10);
        }
        checkEqual("ID1ID2", 8075, this.source.readShort());
        this.source.skip(8);
        if (((b2 >> 2) & 1) == 1) {
            this.source.require(2);
            if (z) {
                updateCrc(this.source.buffer(), 0, 2);
            }
            long readShortLe = (long) (this.source.buffer().readShortLe() & 65535);
            this.source.require(readShortLe);
            if (z) {
                updateCrc(this.source.buffer(), 0, readShortLe);
            }
            this.source.skip(readShortLe);
        }
        if (((b2 >> 3) & 1) == 1) {
            long seek = this.source.seek(SECTION_HEADER);
            if (z) {
                updateCrc(this.source.buffer(), 0, seek + 1);
            }
            this.source.skip(seek + 1);
        }
        if (((b2 >> FCOMMENT) & 1) == 1) {
            long seek2 = this.source.seek(SECTION_HEADER);
            if (z) {
                updateCrc(this.source.buffer(), 0, seek2 + 1);
            }
            this.source.skip(seek2 + 1);
        }
        if (z) {
            checkEqual("FHCRC", this.source.readShortLe(), (short) ((int) this.crc.getValue()));
            this.crc.reset();
        }
    }

    private void consumeTrailer() {
        checkEqual("CRC", this.source.readIntLe(), (int) this.crc.getValue());
        checkEqual("ISIZE", this.source.readIntLe(), this.inflater.getTotalOut());
    }

    private void updateCrc(OkBuffer okBuffer, long j, long j2) {
        Segment segment = okBuffer.head;
        while (j2 > 0) {
            long j3 = (long) (segment.limit - segment.pos);
            if (j < j3) {
                int min = (int) Math.min(j2, j3 - j);
                this.crc.update(segment.data, (int) (((long) segment.pos) + j), min);
                j2 -= (long) min;
            }
            j -= j3;
            segment = segment.next;
        }
    }

    public void close() {
        this.inflaterSource.close();
    }

    public Source deadline(Deadline deadline) {
        this.source.deadline(deadline);
        return this;
    }

    public long read(OkBuffer okBuffer, long j) {
        if (j < 0) {
            throw new IllegalArgumentException("byteCount < 0: " + j);
        } else if (j == 0) {
            return 0;
        } else {
            if (this.section == 0) {
                consumeHeader();
                this.section = 1;
            }
            if (this.section == 1) {
                long j2 = okBuffer.size;
                long read = this.inflaterSource.read(okBuffer, j);
                if (read != -1) {
                    updateCrc(okBuffer, j2, read);
                    return read;
                }
                this.section = 2;
            }
            if (this.section == 2) {
                consumeTrailer();
                this.section = 3;
                if (!this.source.exhausted()) {
                    throw new IOException("gzip finished without exhausting source");
                }
            }
            return -1;
        }
    }
}
