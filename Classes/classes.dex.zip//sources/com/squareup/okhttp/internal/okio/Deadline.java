package com.squareup.okhttp.internal.okio;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

public class Deadline {
    public static final Deadline NONE = new Deadline() {
        public boolean reached() {
            return false;
        }

        public Deadline start(long j, TimeUnit timeUnit) {
            throw new UnsupportedOperationException();
        }
    };
    private long deadlineNanos;

    public boolean reached() {
        return System.nanoTime() - this.deadlineNanos >= 0;
    }

    public Deadline start(long j, TimeUnit timeUnit) {
        this.deadlineNanos = System.nanoTime() + timeUnit.toNanos(j);
        return this;
    }

    public final void throwIfReached() {
        if (reached()) {
            throw new IOException("Deadline reached");
        } else if (Thread.interrupted()) {
            throw new InterruptedIOException();
        }
    }
}
