package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.CacheControl;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.internal.Platform;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.okio.BufferedSink;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;

public final class Request {
    /* access modifiers changed from: private */
    public final Body body;
    private volatile CacheControl cacheControl;
    /* access modifiers changed from: private */
    public final Headers headers;
    /* access modifiers changed from: private */
    public final String method;
    private volatile ParsedHeaders parsedHeaders;
    /* access modifiers changed from: private */
    public final Object tag;
    private volatile URI uri;
    /* access modifiers changed from: private */
    public final URL url;

    public static abstract class Body {
        public static Body create(final MediaType mediaType, final File file) {
            if (mediaType == null) {
                throw new NullPointerException("contentType == null");
            } else if (file != null) {
                return new Body() {
                    public long contentLength() {
                        return file.length();
                    }

                    public MediaType contentType() {
                        return mediaType;
                    }

                    public void writeTo(BufferedSink bufferedSink) {
                        FileInputStream fileInputStream;
                        long contentLength = contentLength();
                        if (contentLength != 0) {
                            try {
                                fileInputStream = new FileInputStream(file);
                                try {
                                    byte[] bArr = new byte[((int) Math.min(8192, contentLength))];
                                    while (true) {
                                        int read = fileInputStream.read(bArr);
                                        if (read != -1) {
                                            bufferedSink.write(bArr, 0, read);
                                        } else {
                                            Util.closeQuietly((Closeable) fileInputStream);
                                            return;
                                        }
                                    }
                                } catch (Throwable th) {
                                    th = th;
                                    Util.closeQuietly((Closeable) fileInputStream);
                                    throw th;
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                fileInputStream = null;
                                Util.closeQuietly((Closeable) fileInputStream);
                                throw th;
                            }
                        }
                    }
                };
            } else {
                throw new NullPointerException("content == null");
            }
        }

        public static Body create(MediaType mediaType, String str) {
            if (mediaType.charset() == null) {
                mediaType = MediaType.parse(mediaType + "; charset=utf-8");
            }
            try {
                return create(mediaType, str.getBytes(mediaType.charset().name()));
            } catch (UnsupportedEncodingException unused) {
                throw new AssertionError();
            }
        }

        public static Body create(final MediaType mediaType, final byte[] bArr) {
            if (mediaType == null) {
                throw new NullPointerException("contentType == null");
            } else if (bArr != null) {
                return new Body() {
                    public long contentLength() {
                        return (long) bArr.length;
                    }

                    public MediaType contentType() {
                        return mediaType;
                    }

                    public void writeTo(BufferedSink bufferedSink) {
                        bufferedSink.write(bArr);
                    }
                };
            } else {
                throw new NullPointerException("content == null");
            }
        }

        public long contentLength() {
            return -1;
        }

        public abstract MediaType contentType();

        public abstract void writeTo(BufferedSink bufferedSink);
    }

    public static class Builder {
        /* access modifiers changed from: private */
        public Body body;
        /* access modifiers changed from: private */
        public Headers.Builder headers;
        /* access modifiers changed from: private */
        public String method;
        /* access modifiers changed from: private */
        public Object tag;
        /* access modifiers changed from: private */
        public URL url;

        public Builder() {
            this.method = "GET";
            this.headers = new Headers.Builder();
        }

        private Builder(Request request) {
            this.url = request.url;
            this.method = request.method;
            this.body = request.body;
            this.tag = request.tag;
            this.headers = request.headers.newBuilder();
        }

        public Builder addHeader(String str, String str2) {
            this.headers.add(str, str2);
            return this;
        }

        public Request build() {
            if (this.url != null) {
                return new Request(this);
            }
            throw new IllegalStateException("url == null");
        }

        public Builder get() {
            return method("GET", (Body) null);
        }

        public Builder head() {
            return method("HEAD", (Body) null);
        }

        public Builder header(String str, String str2) {
            this.headers.set(str, str2);
            return this;
        }

        public Builder headers(Headers headers2) {
            this.headers = headers2.newBuilder();
            return this;
        }

        public Builder method(String str, Body body2) {
            if (str == null || str.length() == 0) {
                throw new IllegalArgumentException("method == null || method.length() == 0");
            }
            this.method = str;
            this.body = body2;
            return this;
        }

        public Builder post(Body body2) {
            return method("POST", body2);
        }

        public Builder put(Body body2) {
            return method("PUT", body2);
        }

        public Builder removeHeader(String str) {
            this.headers.removeAll(str);
            return this;
        }

        public Builder setUserAgent(String str) {
            return header("User-Agent", str);
        }

        public Builder tag(Object obj) {
            this.tag = obj;
            return this;
        }

        public Builder url(String str) {
            try {
                return url(new URL(str));
            } catch (MalformedURLException unused) {
                throw new IllegalArgumentException("Malformed URL: " + str);
            }
        }

        public Builder url(URL url2) {
            if (url2 != null) {
                this.url = url2;
                return this;
            }
            throw new IllegalArgumentException("url == null");
        }
    }

    private static class ParsedHeaders {
        /* access modifiers changed from: private */
        public String proxyAuthorization;
        /* access modifiers changed from: private */
        public String userAgent;

        public ParsedHeaders(Headers headers) {
            for (int i = 0; i < headers.size(); i++) {
                String name = headers.name(i);
                String value = headers.value(i);
                if ("User-Agent".equalsIgnoreCase(name)) {
                    this.userAgent = value;
                } else if ("Proxy-Authorization".equalsIgnoreCase(name)) {
                    this.proxyAuthorization = value;
                }
            }
        }
    }

    private Request(Builder builder) {
        this.url = builder.url;
        this.method = builder.method;
        this.headers = builder.headers.build();
        this.body = builder.body;
        this.tag = builder.tag != null ? builder.tag : this;
    }

    private ParsedHeaders parsedHeaders() {
        ParsedHeaders parsedHeaders2 = this.parsedHeaders;
        if (parsedHeaders2 != null) {
            return parsedHeaders2;
        }
        ParsedHeaders parsedHeaders3 = new ParsedHeaders(this.headers);
        this.parsedHeaders = parsedHeaders3;
        return parsedHeaders3;
    }

    public Body body() {
        return this.body;
    }

    public CacheControl cacheControl() {
        CacheControl cacheControl2 = this.cacheControl;
        if (cacheControl2 != null) {
            return cacheControl2;
        }
        CacheControl parse = CacheControl.parse(this.headers);
        this.cacheControl = parse;
        return parse;
    }

    public Headers getHeaders() {
        return this.headers;
    }

    public String getProxyAuthorization() {
        return parsedHeaders().proxyAuthorization;
    }

    public String getUserAgent() {
        return parsedHeaders().userAgent;
    }

    public String header(String str) {
        return this.headers.get(str);
    }

    public Headers headers() {
        return this.headers;
    }

    public List<String> headers(String str) {
        return this.headers.values(str);
    }

    public boolean isHttps() {
        return url().getProtocol().equals("https");
    }

    public String method() {
        return this.method;
    }

    public Builder newBuilder() {
        return new Builder();
    }

    public Object tag() {
        return this.tag;
    }

    public URI uri() {
        try {
            URI uri2 = this.uri;
            if (uri2 != null) {
                return uri2;
            }
            URI uriLenient = Platform.get().toUriLenient(this.url);
            this.uri = uriLenient;
            return uriLenient;
        } catch (URISyntaxException e) {
            throw new IOException(e.getMessage());
        }
    }

    public URL url() {
        return this.url;
    }

    public String urlString() {
        return this.url.toString();
    }
}
