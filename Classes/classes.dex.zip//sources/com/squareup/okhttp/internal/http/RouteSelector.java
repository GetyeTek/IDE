package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.Address;
import com.squareup.okhttp.Connection;
import com.squareup.okhttp.ConnectionPool;
import com.squareup.okhttp.Route;
import com.squareup.okhttp.RouteDatabase;
import com.squareup.okhttp.internal.Dns;
import com.squareup.okhttp.internal.Util;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLProtocolException;

public final class RouteSelector {
    private static final int TLS_MODE_COMPATIBLE = 0;
    private static final int TLS_MODE_MODERN = 1;
    private static final int TLS_MODE_NULL = -1;
    private final Address address;
    private final Dns dns;
    private boolean hasNextProxy;
    private InetSocketAddress lastInetSocketAddress;
    private Proxy lastProxy;
    private int nextSocketAddressIndex;
    private int nextTlsMode = TLS_MODE_NULL;
    private final ConnectionPool pool;
    private final List<Route> postponedRoutes;
    private final ProxySelector proxySelector;
    private Iterator<Proxy> proxySelectorProxies;
    private final RouteDatabase routeDatabase;
    private InetAddress[] socketAddresses;
    private int socketPort;
    private final URI uri;
    private Proxy userSpecifiedProxy;

    public RouteSelector(Address address2, URI uri2, ProxySelector proxySelector2, ConnectionPool connectionPool, Dns dns2, RouteDatabase routeDatabase2) {
        this.address = address2;
        this.uri = uri2;
        this.proxySelector = proxySelector2;
        this.pool = connectionPool;
        this.dns = dns2;
        this.routeDatabase = routeDatabase2;
        this.postponedRoutes = new LinkedList();
        resetNextProxy(uri2, address2.getProxy());
    }

    private boolean hasNextInetSocketAddress() {
        return this.socketAddresses != null;
    }

    private boolean hasNextPostponed() {
        return !this.postponedRoutes.isEmpty();
    }

    private boolean hasNextProxy() {
        return this.hasNextProxy;
    }

    private boolean hasNextTlsMode() {
        return this.nextTlsMode != TLS_MODE_NULL;
    }

    private InetSocketAddress nextInetSocketAddress() {
        InetAddress[] inetAddressArr = this.socketAddresses;
        int i = this.nextSocketAddressIndex;
        this.nextSocketAddressIndex = i + 1;
        InetSocketAddress inetSocketAddress = new InetSocketAddress(inetAddressArr[i], this.socketPort);
        if (this.nextSocketAddressIndex == this.socketAddresses.length) {
            this.socketAddresses = null;
            this.nextSocketAddressIndex = 0;
        }
        return inetSocketAddress;
    }

    private Route nextPostponed() {
        return this.postponedRoutes.remove(0);
    }

    private Proxy nextProxy() {
        Proxy proxy = this.userSpecifiedProxy;
        if (proxy != null) {
            this.hasNextProxy = false;
            return proxy;
        }
        if (this.proxySelectorProxies != null) {
            while (this.proxySelectorProxies.hasNext()) {
                Proxy next = this.proxySelectorProxies.next();
                if (next.type() != Proxy.Type.DIRECT) {
                    return next;
                }
            }
        }
        this.hasNextProxy = false;
        return Proxy.NO_PROXY;
    }

    private int nextTlsMode() {
        int i = this.nextTlsMode;
        if (i == 1) {
            this.nextTlsMode = 0;
            return 1;
        } else if (i == 0) {
            this.nextTlsMode = TLS_MODE_NULL;
            return 0;
        } else {
            throw new AssertionError();
        }
    }

    private void resetNextInetSocketAddress(Proxy proxy) {
        String str;
        this.socketAddresses = null;
        if (proxy.type() == Proxy.Type.DIRECT) {
            str = this.uri.getHost();
            this.socketPort = Util.getEffectivePort(this.uri);
        } else {
            SocketAddress address2 = proxy.address();
            if (address2 instanceof InetSocketAddress) {
                InetSocketAddress inetSocketAddress = (InetSocketAddress) address2;
                String hostName = inetSocketAddress.getHostName();
                this.socketPort = inetSocketAddress.getPort();
                str = hostName;
            } else {
                throw new IllegalArgumentException("Proxy.address() is not an InetSocketAddress: " + address2.getClass());
            }
        }
        this.socketAddresses = this.dns.getAllByName(str);
        this.nextSocketAddressIndex = 0;
    }

    private void resetNextProxy(URI uri2, Proxy proxy) {
        this.hasNextProxy = true;
        if (proxy != null) {
            this.userSpecifiedProxy = proxy;
            return;
        }
        List<Proxy> select = this.proxySelector.select(uri2);
        if (select != null) {
            this.proxySelectorProxies = select.iterator();
        }
    }

    private void resetNextTlsMode() {
        this.nextTlsMode = this.address.getSslSocketFactory() != null ? 1 : 0;
    }

    public void connectFailed(Connection connection, IOException iOException) {
        ProxySelector proxySelector2;
        if (connection.recycleCount() <= 0) {
            Route route = connection.getRoute();
            if (!(route.getProxy().type() == Proxy.Type.DIRECT || (proxySelector2 = this.proxySelector) == null)) {
                proxySelector2.connectFailed(this.uri, route.getProxy().address(), iOException);
            }
            this.routeDatabase.failed(route);
            if (hasNextTlsMode() && !(iOException instanceof SSLHandshakeException) && !(iOException instanceof SSLProtocolException)) {
                boolean z = true;
                if (nextTlsMode() != 1) {
                    z = false;
                }
                this.routeDatabase.failed(new Route(this.address, this.lastProxy, this.lastInetSocketAddress, z));
            }
        }
    }

    public boolean hasNext() {
        return hasNextTlsMode() || hasNextInetSocketAddress() || hasNextProxy() || hasNextPostponed();
    }

    public Connection next(String str) {
        Connection connection;
        while (true) {
            connection = this.pool.get(this.address);
            if (connection == null) {
                if (!hasNextTlsMode()) {
                    if (!hasNextInetSocketAddress()) {
                        if (hasNextProxy()) {
                            this.lastProxy = nextProxy();
                            resetNextInetSocketAddress(this.lastProxy);
                        } else if (hasNextPostponed()) {
                            return new Connection(this.pool, nextPostponed());
                        } else {
                            throw new NoSuchElementException();
                        }
                    }
                    this.lastInetSocketAddress = nextInetSocketAddress();
                    resetNextTlsMode();
                }
                boolean z = true;
                if (nextTlsMode() != 1) {
                    z = false;
                }
                Route route = new Route(this.address, this.lastProxy, this.lastInetSocketAddress, z);
                if (!this.routeDatabase.shouldPostpone(route)) {
                    return new Connection(this.pool, route);
                }
                this.postponedRoutes.add(route);
                return next(str);
            } else if (str.equals("GET") || connection.isReadable()) {
                return connection;
            } else {
                connection.close();
            }
        }
        return connection;
    }
}
