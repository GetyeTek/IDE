package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.internal.http.Response;
import com.squareup.okhttp.internal.okio.Sink;
import com.squareup.okhttp.internal.okio.Source;
import java.net.CacheRequest;

public final class HttpTransport implements Transport {
    private final HttpConnection httpConnection;
    private final HttpEngine httpEngine;

    public HttpTransport(HttpEngine httpEngine2, HttpConnection httpConnection2) {
        this.httpEngine = httpEngine2;
        this.httpConnection = httpConnection2;
    }

    public boolean canReuseConnection() {
        return !"close".equalsIgnoreCase(this.httpEngine.getRequest().header("Connection")) && !"close".equalsIgnoreCase(this.httpEngine.getResponse().header("Connection")) && !this.httpConnection.isClosed();
    }

    public Sink createRequestBody(Request request) {
        long contentLength = OkHeaders.contentLength(request);
        if (this.httpEngine.bufferRequestBody) {
            if (contentLength > 2147483647L) {
                throw new IllegalStateException("Use setFixedLengthStreamingMode() or setChunkedStreamingMode() for requests larger than 2 GiB.");
            } else if (contentLength == -1) {
                return new RetryableSink();
            } else {
                writeRequestHeaders(request);
                return new RetryableSink((int) contentLength);
            }
        } else if ("chunked".equalsIgnoreCase(request.header("Transfer-Encoding"))) {
            writeRequestHeaders(request);
            return this.httpConnection.newChunkedSink();
        } else if (contentLength != -1) {
            writeRequestHeaders(request);
            return this.httpConnection.newFixedLengthSink(contentLength);
        } else {
            throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
        }
    }

    public void disconnect(HttpEngine httpEngine2) {
        this.httpConnection.closeIfOwnedBy(httpEngine2);
    }

    public void emptyTransferStream() {
        this.httpConnection.emptyResponseBody();
    }

    public void flushRequest() {
        this.httpConnection.flush();
    }

    public Source getTransferStream(CacheRequest cacheRequest) {
        if (!this.httpEngine.hasResponseBody()) {
            return this.httpConnection.newFixedLengthSource(cacheRequest, 0);
        }
        if ("chunked".equalsIgnoreCase(this.httpEngine.getResponse().header("Transfer-Encoding"))) {
            return this.httpConnection.newChunkedSource(cacheRequest, this.httpEngine);
        }
        long contentLength = OkHeaders.contentLength(this.httpEngine.getResponse());
        return contentLength != -1 ? this.httpConnection.newFixedLengthSource(cacheRequest, contentLength) : this.httpConnection.newUnknownLengthSource(cacheRequest);
    }

    public Response.Builder readResponseHeaders() {
        return this.httpConnection.readResponse();
    }

    public void releaseConnectionOnIdle() {
        if (canReuseConnection()) {
            this.httpConnection.poolOnIdle();
        } else {
            this.httpConnection.closeOnIdle();
        }
    }

    public void writeRequestBody(RetryableSink retryableSink) {
        this.httpConnection.writeRequestBody(retryableSink);
    }

    public void writeRequestHeaders(Request request) {
        this.httpEngine.writingRequestHeaders();
        this.httpConnection.writeRequest(request.getHeaders(), RequestLine.get(request, this.httpEngine.getConnection().getRoute().getProxy().type(), this.httpEngine.getConnection().getHttpMinorVersion()));
    }
}
