package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.Connection;
import com.squareup.okhttp.Handshake;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.OkResponseCache;
import com.squareup.okhttp.Route;
import com.squareup.okhttp.internal.Platform;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.http.Request;
import com.squareup.okhttp.internal.okio.BufferedSink;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.Sink;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpRetryException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.SocketPermission;
import java.net.URL;
import java.security.Permission;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class HttpURLConnectionImpl extends HttpURLConnection {
    public static final int MAX_REDIRECTS = 20;
    final OkHttpClient client;
    private long fixedContentLength = -1;
    Handshake handshake;
    protected HttpEngine httpEngine;
    protected IOException httpEngineFailure;
    private int redirectionCount;
    private Headers.Builder requestHeaders = new Headers.Builder();
    private Route route;

    enum Retry {
        NONE,
        SAME_CONNECTION,
        DIFFERENT_CONNECTION
    }

    public HttpURLConnectionImpl(URL url, OkHttpClient okHttpClient) {
        super(url);
        this.client = okHttpClient;
    }

    private boolean execute(boolean z) {
        try {
            this.httpEngine.sendRequest();
            this.route = this.httpEngine.getRoute();
            this.handshake = this.httpEngine.getConnection() != null ? this.httpEngine.getConnection().getHandshake() : null;
            if (!z) {
                return true;
            }
            this.httpEngine.readResponse();
            return true;
        } catch (IOException e) {
            HttpEngine recover = this.httpEngine.recover(e);
            if (recover != null) {
                this.httpEngine = recover;
                return false;
            }
            this.httpEngineFailure = e;
            throw e;
        }
    }

    private HttpEngine getResponse() {
        initHttpEngine();
        if (this.httpEngine.hasResponse()) {
            return this.httpEngine;
        }
        while (true) {
            if (execute(true)) {
                Retry processResponseHeaders = processResponseHeaders();
                if (processResponseHeaders == Retry.NONE) {
                    this.httpEngine.releaseConnection();
                    return this.httpEngine;
                }
                String str = this.method;
                Sink requestBody = this.httpEngine.getRequestBody();
                int code = this.httpEngine.getResponse().code();
                if (code == 300 || code == 301 || code == 302 || code == 303) {
                    this.requestHeaders.removeAll("Content-Length");
                    requestBody = null;
                    str = "GET";
                }
                if (requestBody == null || (requestBody instanceof RetryableSink)) {
                    if (processResponseHeaders == Retry.DIFFERENT_CONNECTION) {
                        this.httpEngine.releaseConnection();
                    }
                    this.httpEngine = newHttpEngine(str, this.httpEngine.close(), (RetryableSink) requestBody);
                } else {
                    throw new HttpRetryException("Cannot retry streamed HTTP body", code);
                }
            }
        }
    }

    private void initHttpEngine() {
        IOException iOException = this.httpEngineFailure;
        if (iOException != null) {
            throw iOException;
        } else if (this.httpEngine == null) {
            this.connected = true;
            try {
                if (this.doOutput) {
                    if (this.method.equals("GET")) {
                        this.method = "POST";
                    } else if (!HttpMethod.hasRequestBody(this.method)) {
                        throw new ProtocolException(this.method + " does not support writing");
                    }
                }
                this.httpEngine = newHttpEngine(this.method, (Connection) null, (RetryableSink) null);
            } catch (IOException e) {
                this.httpEngineFailure = e;
                throw e;
            }
        }
    }

    private HttpEngine newHttpEngine(String str, Connection connection, RetryableSink retryableSink) {
        boolean z;
        OkHttpClient okHttpClient;
        Request.Builder method = new Request.Builder().url(getURL()).method(str, (Request.Body) null);
        Headers build = this.requestHeaders.build();
        for (int i = 0; i < build.size(); i++) {
            method.addHeader(build.name(i), build.value(i));
        }
        if (HttpMethod.hasRequestBody(str)) {
            long j = this.fixedContentLength;
            if (j != -1) {
                method.header("Content-Length", Long.toString(j));
            } else if (this.chunkLength > 0) {
                method.header("Transfer-Encoding", "chunked");
            } else {
                z = true;
                Request build2 = method.build();
                okHttpClient = this.client;
                if (okHttpClient.getOkResponseCache() != null && !getUseCaches()) {
                    okHttpClient = this.client.clone().setOkResponseCache((OkResponseCache) null);
                }
                return new HttpEngine(okHttpClient, build2, z, connection, (RouteSelector) null, retryableSink);
            }
        }
        z = false;
        Request build22 = method.build();
        okHttpClient = this.client;
        okHttpClient = this.client.clone().setOkResponseCache((OkResponseCache) null);
        return new HttpEngine(okHttpClient, build22, z, connection, (RouteSelector) null, retryableSink);
    }

    private Retry processResponseHeaders() {
        Connection connection = this.httpEngine.getConnection();
        Proxy proxy = connection != null ? connection.getRoute().getProxy() : this.client.getProxy();
        int responseCode = getResponseCode();
        if (responseCode != 307) {
            if (responseCode != 401) {
                if (responseCode != 407) {
                    switch (responseCode) {
                        case 300:
                        case 301:
                        case 302:
                        case 303:
                            break;
                        default:
                            return Retry.NONE;
                    }
                } else if (proxy.type() != Proxy.Type.HTTP) {
                    throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
                }
            }
            Request processAuthHeader = HttpAuthenticator.processAuthHeader(this.client.getAuthenticator(), this.httpEngine.getResponse(), proxy);
            if (processAuthHeader == null) {
                return Retry.NONE;
            }
            this.requestHeaders = processAuthHeader.getHeaders().newBuilder();
            return Retry.SAME_CONNECTION;
        }
        if (!getInstanceFollowRedirects()) {
            return Retry.NONE;
        }
        boolean z = true;
        int i = this.redirectionCount + 1;
        this.redirectionCount = i;
        if (i > 20) {
            throw new ProtocolException("Too many redirects: " + this.redirectionCount);
        } else if (responseCode == 307 && !this.method.equals("GET") && !this.method.equals("HEAD")) {
            return Retry.NONE;
        } else {
            String headerField = getHeaderField("Location");
            if (headerField == null) {
                return Retry.NONE;
            }
            URL url = this.url;
            this.url = new URL(url, headerField);
            if (!this.url.getProtocol().equals("https") && !this.url.getProtocol().equals("http")) {
                return Retry.NONE;
            }
            boolean equals = url.getProtocol().equals(this.url.getProtocol());
            if (!equals && !this.client.getFollowProtocolRedirects()) {
                return Retry.NONE;
            }
            boolean equals2 = url.getHost().equals(this.url.getHost());
            if (Util.getEffectivePort(url) != Util.getEffectivePort(this.url)) {
                z = false;
            }
            return (!equals2 || !z || !equals) ? Retry.DIFFERENT_CONNECTION : Retry.SAME_CONNECTION;
        }
    }

    private void setProtocols(String str, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (z) {
            arrayList.addAll(this.client.getProtocols());
        }
        String[] split = str.split(",", -1);
        int length = split.length;
        int i = 0;
        while (i < length) {
            try {
                arrayList.add(Util.getProtocol(ByteString.encodeUtf8(split[i])));
                i++;
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        }
        this.client.setProtocols(arrayList);
    }

    public final void addRequestProperty(String str, String str2) {
        if (this.connected) {
            throw new IllegalStateException("Cannot add request property after connection is made");
        } else if (str == null) {
            throw new NullPointerException("field == null");
        } else if (str2 == null) {
            Platform platform = Platform.get();
            platform.logW("Ignoring header " + str + " because its value was null.");
        } else if ("X-Android-Transports".equals(str) || "X-Android-Protocols".equals(str)) {
            setProtocols(str2, true);
        } else {
            this.requestHeaders.add(str, str2);
        }
    }

    public final void connect() {
        initHttpEngine();
        do {
        } while (!execute(false));
    }

    public final void disconnect() {
        HttpEngine httpEngine2 = this.httpEngine;
        if (httpEngine2 != null) {
            try {
                httpEngine2.disconnect();
            } catch (IOException unused) {
            }
        }
    }

    public int getConnectTimeout() {
        return this.client.getConnectTimeout();
    }

    public final InputStream getErrorStream() {
        try {
            HttpEngine response = getResponse();
            if (!response.hasResponseBody() || response.getResponse().code() < 400) {
                return null;
            }
            return response.getResponseBodyBytes();
        } catch (IOException unused) {
            return null;
        }
    }

    public final String getHeaderField(int i) {
        try {
            return getResponse().getResponse().headers().value(i);
        } catch (IOException unused) {
            return null;
        }
    }

    public final String getHeaderField(String str) {
        try {
            Response response = getResponse().getResponse();
            return str == null ? response.statusLine() : response.headers().get(str);
        } catch (IOException unused) {
            return null;
        }
    }

    public final String getHeaderFieldKey(int i) {
        try {
            return getResponse().getResponse().headers().name(i);
        } catch (IOException unused) {
            return null;
        }
    }

    public final Map<String, List<String>> getHeaderFields() {
        try {
            Response response = getResponse().getResponse();
            return OkHeaders.toMultimap(response.headers(), response.statusLine());
        } catch (IOException unused) {
            return Collections.emptyMap();
        }
    }

    public final InputStream getInputStream() {
        if (this.doInput) {
            HttpEngine response = getResponse();
            if (getResponseCode() < 400) {
                InputStream responseBodyBytes = response.getResponseBodyBytes();
                if (responseBodyBytes != null) {
                    return responseBodyBytes;
                }
                throw new ProtocolException("No response body exists; responseCode=" + getResponseCode());
            }
            throw new FileNotFoundException(this.url.toString());
        }
        throw new ProtocolException("This protocol does not support input");
    }

    public final OutputStream getOutputStream() {
        connect();
        BufferedSink bufferedRequestBody = this.httpEngine.getBufferedRequestBody();
        if (bufferedRequestBody == null) {
            throw new ProtocolException("method does not support a request body: " + this.method);
        } else if (!this.httpEngine.hasResponse()) {
            return bufferedRequestBody.outputStream();
        } else {
            throw new ProtocolException("cannot write request body after response has been read");
        }
    }

    public final Permission getPermission() {
        String host = getURL().getHost();
        int effectivePort = Util.getEffectivePort(getURL());
        if (usingProxy()) {
            InetSocketAddress inetSocketAddress = (InetSocketAddress) this.client.getProxy().address();
            String hostName = inetSocketAddress.getHostName();
            effectivePort = inetSocketAddress.getPort();
            host = hostName;
        }
        return new SocketPermission(host + ":" + effectivePort, "connect, resolve");
    }

    public int getReadTimeout() {
        return this.client.getReadTimeout();
    }

    public final Map<String, List<String>> getRequestProperties() {
        if (!this.connected) {
            return OkHeaders.toMultimap(this.requestHeaders.build(), (String) null);
        }
        throw new IllegalStateException("Cannot access request header fields after connection is set");
    }

    public final String getRequestProperty(String str) {
        if (str == null) {
            return null;
        }
        return this.requestHeaders.get(str);
    }

    public final int getResponseCode() {
        return getResponse().getResponse().code();
    }

    public String getResponseMessage() {
        return getResponse().getResponse().statusMessage();
    }

    public void setConnectTimeout(int i) {
        this.client.setConnectTimeout((long) i, TimeUnit.MILLISECONDS);
    }

    public void setFixedLengthStreamingMode(int i) {
        setFixedLengthStreamingMode((long) i);
    }

    public void setFixedLengthStreamingMode(long j) {
        if (this.connected) {
            throw new IllegalStateException("Already connected");
        } else if (this.chunkLength > 0) {
            throw new IllegalStateException("Already in chunked mode");
        } else if (j >= 0) {
            this.fixedContentLength = j;
            this.fixedContentLength = (int) Math.min(j, 2147483647L);
        } else {
            throw new IllegalArgumentException("contentLength < 0");
        }
    }

    public void setIfModifiedSince(long j) {
        super.setIfModifiedSince(j);
        if (this.ifModifiedSince != 0) {
            this.requestHeaders.set("If-Modified-Since", HttpDate.format(new Date(this.ifModifiedSince)));
        } else {
            this.requestHeaders.removeAll("If-Modified-Since");
        }
    }

    public void setReadTimeout(int i) {
        this.client.setReadTimeout((long) i, TimeUnit.MILLISECONDS);
    }

    public void setRequestMethod(String str) {
        if (HttpMethod.METHODS.contains(str)) {
            this.method = str;
            return;
        }
        throw new ProtocolException("Expected one of " + HttpMethod.METHODS + " but was " + str);
    }

    public final void setRequestProperty(String str, String str2) {
        if (this.connected) {
            throw new IllegalStateException("Cannot set request property after connection is made");
        } else if (str == null) {
            throw new NullPointerException("field == null");
        } else if (str2 == null) {
            Platform platform = Platform.get();
            platform.logW("Ignoring header " + str + " because its value was null.");
        } else if ("X-Android-Transports".equals(str) || "X-Android-Protocols".equals(str)) {
            setProtocols(str2, false);
        } else {
            this.requestHeaders.set(str, str2);
        }
    }

    public final boolean usingProxy() {
        Route route2 = this.route;
        Proxy proxy = route2 != null ? route2.getProxy() : this.client.getProxy();
        return (proxy == null || proxy.type() == Proxy.Type.DIRECT) ? false : true;
    }
}
