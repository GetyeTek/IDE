package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.okio.BufferedSink;
import com.squareup.okhttp.internal.okio.Deadline;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Sink;
import java.net.ProtocolException;

final class RetryableSink implements Sink {
    private boolean closed;
    private final OkBuffer content;
    private final int limit;

    public RetryableSink() {
        this(-1);
    }

    public RetryableSink(int i) {
        this.content = new OkBuffer();
        this.limit = i;
    }

    public void close() {
        if (!this.closed) {
            this.closed = true;
            if (this.content.size() < ((long) this.limit)) {
                throw new ProtocolException("content-length promised " + this.limit + " bytes, but received " + this.content.size());
            }
        }
    }

    public long contentLength() {
        return this.content.size();
    }

    public Sink deadline(Deadline deadline) {
        return this;
    }

    public void flush() {
    }

    public void write(OkBuffer okBuffer, long j) {
        if (!this.closed) {
            Util.checkOffsetAndCount(okBuffer.size(), 0, j);
            if (this.limit == -1 || this.content.size() <= ((long) this.limit) - j) {
                this.content.write(okBuffer, j);
                return;
            }
            throw new ProtocolException("exceeded content-length limit of " + this.limit + " bytes");
        }
        throw new IllegalStateException("closed");
    }

    public void writeToSocket(BufferedSink bufferedSink) {
        bufferedSink.write(this.content.clone(), this.content.size());
    }
}
