package com.squareup.okhttp.internal.spdy;

import com.squareup.okhttp.internal.okio.OkBuffer;
import java.io.Closeable;
import java.util.List;

public interface FrameWriter extends Closeable {
    void ackSettings();

    void connectionHeader();

    void data(boolean z, int i, OkBuffer okBuffer);

    void data(boolean z, int i, OkBuffer okBuffer, int i2);

    void flush();

    void goAway(int i, ErrorCode errorCode, byte[] bArr);

    void headers(int i, List<Header> list);

    void ping(boolean z, int i, int i2);

    void pushPromise(int i, int i2, List<Header> list);

    void rstStream(int i, ErrorCode errorCode);

    void settings(Settings settings);

    void synReply(boolean z, int i, List<Header> list);

    void synStream(boolean z, boolean z2, int i, int i2, int i3, int i4, List<Header> list);

    void windowUpdate(int i, long j);
}
