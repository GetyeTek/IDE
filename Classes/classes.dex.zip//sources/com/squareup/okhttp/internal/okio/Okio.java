package com.squareup.okhttp.internal.okio;

import java.io.InputStream;
import java.io.OutputStream;

public final class Okio {
    private Okio() {
    }

    public static BufferedSink buffer(Sink sink) {
        return new RealBufferedSink(sink);
    }

    public static BufferedSource buffer(Source source) {
        return new RealBufferedSource(source);
    }

    public static void copy(OkBuffer okBuffer, long j, long j2, OutputStream outputStream) {
        Util.checkOffsetAndCount(okBuffer.size, j, j2);
        Segment segment = okBuffer.head;
        while (true) {
            int i = segment.limit;
            int i2 = segment.pos;
            if (j < ((long) (i - i2))) {
                break;
            }
            j -= (long) (i - i2);
            segment = segment.next;
        }
        while (j2 > 0) {
            int i3 = (int) (((long) segment.pos) + j);
            int min = (int) Math.min((long) (segment.limit - i3), j2);
            outputStream.write(segment.data, i3, min);
            j2 -= (long) min;
            j = 0;
        }
    }

    public static Sink sink(final OutputStream outputStream) {
        return new Sink() {
            private Deadline deadline = Deadline.NONE;

            public void close() {
                outputStream.close();
            }

            public Sink deadline(Deadline deadline2) {
                if (deadline2 != null) {
                    this.deadline = deadline2;
                    return this;
                }
                throw new IllegalArgumentException("deadline == null");
            }

            public void flush() {
                outputStream.flush();
            }

            public String toString() {
                return "sink(" + outputStream + ")";
            }

            public void write(OkBuffer okBuffer, long j) {
                Util.checkOffsetAndCount(okBuffer.size, 0, j);
                while (j > 0) {
                    this.deadline.throwIfReached();
                    Segment segment = okBuffer.head;
                    int min = (int) Math.min(j, (long) (segment.limit - segment.pos));
                    outputStream.write(segment.data, segment.pos, min);
                    segment.pos += min;
                    long j2 = (long) min;
                    j -= j2;
                    okBuffer.size -= j2;
                    if (segment.pos == segment.limit) {
                        okBuffer.head = segment.pop();
                        SegmentPool.INSTANCE.recycle(segment);
                    }
                }
            }
        };
    }

    public static Source source(final InputStream inputStream) {
        return new Source() {
            private Deadline deadline = Deadline.NONE;

            public void close() {
                inputStream.close();
            }

            public Source deadline(Deadline deadline2) {
                if (deadline2 != null) {
                    this.deadline = deadline2;
                    return this;
                }
                throw new IllegalArgumentException("deadline == null");
            }

            public long read(OkBuffer okBuffer, long j) {
                if (j >= 0) {
                    this.deadline.throwIfReached();
                    Segment writableSegment = okBuffer.writableSegment(1);
                    int read = inputStream.read(writableSegment.data, writableSegment.limit, (int) Math.min(j, (long) (2048 - writableSegment.limit)));
                    if (read == -1) {
                        return -1;
                    }
                    writableSegment.limit += read;
                    long j2 = (long) read;
                    okBuffer.size += j2;
                    return j2;
                }
                throw new IllegalArgumentException("byteCount < 0: " + j);
            }

            public String toString() {
                return "source(" + inputStream + ")";
            }
        };
    }
}
