package com.squareup.okhttp.internal.okio;

import java.io.OutputStream;

public interface BufferedSink extends Sink {
    OkBuffer buffer();

    BufferedSink emitCompleteSegments();

    OutputStream outputStream();

    BufferedSink write(ByteString byteString);

    BufferedSink write(byte[] bArr);

    BufferedSink write(byte[] bArr, int i, int i2);

    BufferedSink writeByte(int i);

    BufferedSink writeInt(int i);

    BufferedSink writeShort(int i);

    BufferedSink writeUtf8(String str);
}
