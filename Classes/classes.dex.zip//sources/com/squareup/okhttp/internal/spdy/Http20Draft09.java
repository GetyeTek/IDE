package com.squareup.okhttp.internal.spdy;

import com.squareup.okhttp.Protocol;
import com.squareup.okhttp.internal.okio.BufferedSink;
import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.Deadline;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Source;
import com.squareup.okhttp.internal.spdy.FrameReader;
import com.squareup.okhttp.internal.spdy.HpackDraft05;
import java.io.IOException;
import java.util.List;

public final class Http20Draft09 implements Variant {
    /* access modifiers changed from: private */
    public static final ByteString CONNECTION_HEADER = ByteString.encodeUtf8("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");
    static final byte FLAG_ACK = 1;
    static final byte FLAG_END_HEADERS = 4;
    static final byte FLAG_END_PUSH_PROMISE = 4;
    static final byte FLAG_END_STREAM = 1;
    static final byte FLAG_NONE = 0;
    static final byte FLAG_PRIORITY = 8;
    static final byte TYPE_CONTINUATION = 10;
    static final byte TYPE_DATA = 0;
    static final byte TYPE_GOAWAY = 7;
    static final byte TYPE_HEADERS = 1;
    static final byte TYPE_PING = 6;
    static final byte TYPE_PRIORITY = 2;
    static final byte TYPE_PUSH_PROMISE = 5;
    static final byte TYPE_RST_STREAM = 3;
    static final byte TYPE_SETTINGS = 4;
    static final byte TYPE_WINDOW_UPDATE = 9;

    static final class ContinuationSource implements Source {
        byte flags;
        int left;
        int length;
        private final BufferedSource source;
        int streamId;

        public ContinuationSource(BufferedSource bufferedSource) {
            this.source = bufferedSource;
        }

        private void readContinuationHeader() {
            int i = this.streamId;
            int readInt = this.source.readInt();
            int readInt2 = this.source.readInt();
            short s = (short) ((1073676288 & readInt) >> 16);
            this.left = s;
            this.length = s;
            byte b2 = (byte) ((65280 & readInt) >> 8);
            this.flags = (byte) (readInt & 255);
            this.streamId = Integer.MAX_VALUE & readInt2;
            if (b2 != 10) {
                Http20Draft09.access$100("%s != TYPE_CONTINUATION", new Object[]{Byte.valueOf(b2)});
                throw null;
            } else if (this.streamId != i) {
                Http20Draft09.access$100("TYPE_CONTINUATION streamId changed", new Object[0]);
                throw null;
            }
        }

        public void close() {
        }

        public Source deadline(Deadline deadline) {
            this.source.deadline(deadline);
            return this;
        }

        public long read(OkBuffer okBuffer, long j) {
            while (true) {
                int i = this.left;
                if (i != 0) {
                    long read = this.source.read(okBuffer, Math.min(j, (long) i));
                    if (read == -1) {
                        return -1;
                    }
                    this.left = (int) (((long) this.left) - read);
                    return read;
                } else if ((this.flags & 4) != 0) {
                    return -1;
                } else {
                    readContinuationHeader();
                }
            }
        }
    }

    static final class Reader implements FrameReader {
        private final boolean client;
        private final ContinuationSource continuation = new ContinuationSource(this.source);
        final HpackDraft05.Reader hpackReader;
        private final BufferedSource source;

        Reader(BufferedSource bufferedSource, int i, boolean z) {
            this.source = bufferedSource;
            this.client = z;
            this.hpackReader = new HpackDraft05.Reader(z, i, this.continuation);
        }

        private void readData(FrameReader.Handler handler, short s, byte b2, int i) {
            boolean z = true;
            if ((b2 & 1) == 0) {
                z = false;
            }
            handler.data(z, i, this.source, s);
        }

        private void readGoAway(FrameReader.Handler handler, short s, byte b2, int i) {
            if (s < 8) {
                Http20Draft09.access$100("TYPE_GOAWAY length < 8: %s", new Object[]{Short.valueOf(s)});
                throw null;
            } else if (i == 0) {
                int readInt = this.source.readInt();
                int readInt2 = this.source.readInt();
                int i2 = s - 8;
                ErrorCode fromHttp2 = ErrorCode.fromHttp2(readInt2);
                if (fromHttp2 != null) {
                    ByteString byteString = ByteString.EMPTY;
                    if (i2 > 0) {
                        byteString = this.source.readByteString((long) i2);
                    }
                    handler.goAway(readInt, fromHttp2, byteString);
                    return;
                }
                Http20Draft09.access$100("TYPE_GOAWAY unexpected error code: %d", new Object[]{Integer.valueOf(readInt2)});
                throw null;
            } else {
                Http20Draft09.access$100("TYPE_GOAWAY streamId != 0", new Object[0]);
                throw null;
            }
        }

        private List<Header> readHeaderBlock(short s, byte b2, int i) {
            ContinuationSource continuationSource = this.continuation;
            continuationSource.left = s;
            continuationSource.length = s;
            continuationSource.flags = b2;
            continuationSource.streamId = i;
            this.hpackReader.readHeaders();
            this.hpackReader.emitReferenceSet();
            return this.hpackReader.getAndReset();
        }

        private void readHeaders(FrameReader.Handler handler, short s, byte b2, int i) {
            int i2;
            if (i != 0) {
                boolean z = (b2 & 1) != 0;
                if ((b2 & Http20Draft09.FLAG_PRIORITY) != 0) {
                    s = (short) (s - 4);
                    i2 = this.source.readInt() & Integer.MAX_VALUE;
                } else {
                    i2 = -1;
                }
                handler.headers(false, z, i, -1, i2, readHeaderBlock(s, b2, i), HeadersMode.HTTP_20_HEADERS);
                return;
            }
            Http20Draft09.access$100("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0", new Object[0]);
            throw null;
        }

        private void readPing(FrameReader.Handler handler, short s, byte b2, int i) {
            boolean z = false;
            if (s != 8) {
                Http20Draft09.access$100("TYPE_PING length != 8: %s", new Object[]{Short.valueOf(s)});
                throw null;
            } else if (i == 0) {
                int readInt = this.source.readInt();
                int readInt2 = this.source.readInt();
                if ((b2 & 1) != 0) {
                    z = true;
                }
                handler.ping(z, readInt, readInt2);
            } else {
                Http20Draft09.access$100("TYPE_PING streamId != 0", new Object[0]);
                throw null;
            }
        }

        private void readPriority(FrameReader.Handler handler, short s, byte b2, int i) {
            if (s != 4) {
                Http20Draft09.access$100("TYPE_PRIORITY length: %d != 4", new Object[]{Short.valueOf(s)});
                throw null;
            } else if (i != 0) {
                handler.priority(i, this.source.readInt() & Integer.MAX_VALUE);
            } else {
                Http20Draft09.access$100("TYPE_PRIORITY streamId == 0", new Object[0]);
                throw null;
            }
        }

        private void readPushPromise(FrameReader.Handler handler, short s, byte b2, int i) {
            if (i != 0) {
                handler.pushPromise(i, this.source.readInt() & Integer.MAX_VALUE, readHeaderBlock((short) (s - 4), b2, i));
            } else {
                Http20Draft09.access$100("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0", new Object[0]);
                throw null;
            }
        }

        private void readRstStream(FrameReader.Handler handler, short s, byte b2, int i) {
            if (s != 4) {
                Http20Draft09.access$100("TYPE_RST_STREAM length: %d != 4", new Object[]{Short.valueOf(s)});
                throw null;
            } else if (i != 0) {
                int readInt = this.source.readInt();
                ErrorCode fromHttp2 = ErrorCode.fromHttp2(readInt);
                if (fromHttp2 != null) {
                    handler.rstStream(i, fromHttp2);
                    return;
                }
                Http20Draft09.access$100("TYPE_RST_STREAM unexpected error code: %d", new Object[]{Integer.valueOf(readInt)});
                throw null;
            } else {
                Http20Draft09.access$100("TYPE_RST_STREAM streamId == 0", new Object[0]);
                throw null;
            }
        }

        private void readSettings(FrameReader.Handler handler, short s, byte b2, int i) {
            if (i != 0) {
                Http20Draft09.access$100("TYPE_SETTINGS streamId != 0", new Object[0]);
                throw null;
            } else if ((b2 & 1) != 0) {
                if (s == 0) {
                    handler.ackSettings();
                } else {
                    Http20Draft09.access$100("FRAME_SIZE_ERROR ack frame should be empty!", new Object[0]);
                    throw null;
                }
            } else if (s % 8 == 0) {
                Settings settings = new Settings();
                for (int i2 = 0; i2 < s; i2 += 8) {
                    settings.set(this.source.readInt() & 16777215, 0, this.source.readInt());
                }
                handler.settings(false, settings);
                if (settings.getHeaderTableSize() >= 0) {
                    this.hpackReader.maxHeaderTableByteCount(settings.getHeaderTableSize());
                }
            } else {
                Http20Draft09.access$100("TYPE_SETTINGS length %% 8 != 0: %s", new Object[]{Short.valueOf(s)});
                throw null;
            }
        }

        private void readWindowUpdate(FrameReader.Handler handler, short s, byte b2, int i) {
            if (s == 4) {
                long readInt = (long) (this.source.readInt() & Integer.MAX_VALUE);
                if (readInt != 0) {
                    handler.windowUpdate(i, readInt);
                    return;
                }
                Http20Draft09.access$100("windowSizeIncrement was 0", new Object[]{Long.valueOf(readInt)});
                throw null;
            }
            Http20Draft09.access$100("TYPE_WINDOW_UPDATE length !=4: %s", new Object[]{Short.valueOf(s)});
            throw null;
        }

        public void close() {
            this.source.close();
        }

        public boolean nextFrame(FrameReader.Handler handler) {
            try {
                int readInt = this.source.readInt();
                short s = (short) ((1073676288 & readInt) >> 16);
                byte b2 = (byte) ((65280 & readInt) >> 8);
                byte b3 = (byte) (readInt & 255);
                int readInt2 = this.source.readInt() & Integer.MAX_VALUE;
                switch (b2) {
                    case 0:
                        readData(handler, s, b3, readInt2);
                        return true;
                    case 1:
                        readHeaders(handler, s, b3, readInt2);
                        return true;
                    case 2:
                        readPriority(handler, s, b3, readInt2);
                        return true;
                    case 3:
                        readRstStream(handler, s, b3, readInt2);
                        return true;
                    case 4:
                        readSettings(handler, s, b3, readInt2);
                        return true;
                    case 5:
                        readPushPromise(handler, s, b3, readInt2);
                        return true;
                    case 6:
                        readPing(handler, s, b3, readInt2);
                        return true;
                    case 7:
                        readGoAway(handler, s, b3, readInt2);
                        return true;
                    case 9:
                        readWindowUpdate(handler, s, b3, readInt2);
                        return true;
                    default:
                        this.source.skip((long) s);
                        return true;
                }
            } catch (IOException unused) {
                return false;
            }
        }

        public void readConnectionHeader() {
            if (!this.client) {
                ByteString readByteString = this.source.readByteString((long) Http20Draft09.CONNECTION_HEADER.size());
                if (!Http20Draft09.CONNECTION_HEADER.equals(readByteString)) {
                    Http20Draft09.access$100("Expected a connection header but was %s", new Object[]{readByteString.utf8()});
                    throw null;
                }
            }
        }
    }

    static final class Writer implements FrameWriter {
        private final boolean client;
        private boolean closed;
        private final OkBuffer hpackBuffer = new OkBuffer();
        private final HpackDraft05.Writer hpackWriter = new HpackDraft05.Writer(this.hpackBuffer);
        private final BufferedSink sink;

        Writer(BufferedSink bufferedSink, boolean z) {
            this.sink = bufferedSink;
            this.client = z;
        }

        private void headers(boolean z, int i, int i2, List<Header> list) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (this.hpackBuffer.size() == 0) {
                this.hpackWriter.writeHeaders(list);
                int size = (int) this.hpackBuffer.size();
                byte b2 = z ? (byte) 5 : 4;
                if (i2 != -1) {
                    b2 = (byte) (b2 | Http20Draft09.FLAG_PRIORITY);
                }
                if (i2 != -1) {
                    size += 4;
                }
                frameHeader(size, (byte) 1, b2, i);
                if (i2 != -1) {
                    this.sink.writeInt(Integer.MAX_VALUE & i2);
                }
                BufferedSink bufferedSink = this.sink;
                OkBuffer okBuffer = this.hpackBuffer;
                bufferedSink.write(okBuffer, okBuffer.size());
            } else {
                throw new IllegalStateException();
            }
        }

        public synchronized void ackSettings() {
            if (!this.closed) {
                frameHeader(0, (byte) 4, (byte) 1, 0);
                this.sink.flush();
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void close() {
            this.closed = true;
            this.sink.close();
        }

        public synchronized void connectionHeader() {
            if (this.closed) {
                throw new IOException("closed");
            } else if (this.client) {
                this.sink.write(Http20Draft09.CONNECTION_HEADER.toByteArray());
                this.sink.flush();
            }
        }

        public synchronized void data(boolean z, int i, OkBuffer okBuffer) {
            data(z, i, okBuffer, (int) okBuffer.size());
        }

        public synchronized void data(boolean z, int i, OkBuffer okBuffer, int i2) {
            if (!this.closed) {
                byte b2 = 0;
                if (z) {
                    b2 = (byte) 1;
                }
                dataFrame(i, b2, okBuffer, i2);
            } else {
                throw new IOException("closed");
            }
        }

        /* access modifiers changed from: package-private */
        public void dataFrame(int i, byte b2, OkBuffer okBuffer, int i2) {
            frameHeader(i2, (byte) 0, b2, i);
            if (i2 > 0) {
                this.sink.write(okBuffer, (long) i2);
            }
        }

        public synchronized void flush() {
            if (!this.closed) {
                this.sink.flush();
            } else {
                throw new IOException("closed");
            }
        }

        /* access modifiers changed from: package-private */
        public void frameHeader(int i, byte b2, byte b3, int i2) {
            if (i > 16383) {
                Http20Draft09.access$200("FRAME_SIZE_ERROR length > 16383: %s", new Object[]{Integer.valueOf(i)});
                throw null;
            } else if ((Integer.MIN_VALUE & i2) == 0) {
                this.sink.writeInt(((i & 16383) << 16) | ((b2 & 255) << Http20Draft09.FLAG_PRIORITY) | (b3 & 255));
                this.sink.writeInt(Integer.MAX_VALUE & i2);
            } else {
                Http20Draft09.access$200("reserved bit set: %s", new Object[]{Integer.valueOf(i2)});
                throw null;
            }
        }

        public synchronized void goAway(int i, ErrorCode errorCode, byte[] bArr) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (errorCode.httpCode != -1) {
                frameHeader(bArr.length + 8, Http20Draft09.TYPE_GOAWAY, (byte) 0, 0);
                this.sink.writeInt(i);
                this.sink.writeInt(errorCode.httpCode);
                if (bArr.length > 0) {
                    this.sink.write(bArr);
                }
                this.sink.flush();
            } else {
                Http20Draft09.access$200("errorCode.httpCode == -1", new Object[0]);
                throw null;
            }
        }

        public synchronized void headers(int i, List<Header> list) {
            if (!this.closed) {
                headers(false, i, -1, list);
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void ping(boolean z, int i, int i2) {
            if (!this.closed) {
                frameHeader(8, Http20Draft09.TYPE_PING, z ? (byte) 1 : 0, 0);
                this.sink.writeInt(i);
                this.sink.writeInt(i2);
                this.sink.flush();
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void pushPromise(int i, int i2, List<Header> list) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (this.hpackBuffer.size() == 0) {
                this.hpackWriter.writeHeaders(list);
                frameHeader((int) (this.hpackBuffer.size() + 4), Http20Draft09.TYPE_PUSH_PROMISE, (byte) 4, i);
                this.sink.writeInt(i2 & Integer.MAX_VALUE);
                this.sink.write(this.hpackBuffer, this.hpackBuffer.size());
            } else {
                throw new IllegalStateException();
            }
        }

        public synchronized void rstStream(int i, ErrorCode errorCode) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (errorCode.spdyRstCode != -1) {
                frameHeader(4, Http20Draft09.TYPE_RST_STREAM, (byte) 0, i);
                this.sink.writeInt(errorCode.httpCode);
                this.sink.flush();
            } else {
                throw new IllegalArgumentException();
            }
        }

        public synchronized void settings(Settings settings) {
            if (!this.closed) {
                frameHeader(settings.size() * 8, (byte) 4, (byte) 0, 0);
                for (int i = 0; i < 10; i++) {
                    if (settings.isSet(i)) {
                        this.sink.writeInt(16777215 & i);
                        this.sink.writeInt(settings.get(i));
                    }
                }
                this.sink.flush();
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void synReply(boolean z, int i, List<Header> list) {
            if (!this.closed) {
                headers(z, i, -1, list);
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void synStream(boolean z, boolean z2, int i, int i2, int i3, int i4, List<Header> list) {
            if (!z2) {
                try {
                    if (!this.closed) {
                        headers(z, i, i3, list);
                    } else {
                        throw new IOException("closed");
                    }
                } catch (Throwable th) {
                    throw th;
                }
            } else {
                throw new UnsupportedOperationException();
            }
        }

        public synchronized void windowUpdate(int i, long j) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (j == 0 || j > 2147483647L) {
                Http20Draft09.access$200("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s", new Object[]{Long.valueOf(j)});
                throw null;
            } else {
                frameHeader(4, Http20Draft09.TYPE_WINDOW_UPDATE, (byte) 0, i);
                this.sink.writeInt((int) j);
                this.sink.flush();
            }
        }
    }

    static /* synthetic */ IOException access$100(String str, Object[] objArr) {
        ioException(str, objArr);
        throw null;
    }

    static /* synthetic */ IllegalArgumentException access$200(String str, Object[] objArr) {
        illegalArgument(str, objArr);
        throw null;
    }

    private static IllegalArgumentException illegalArgument(String str, Object... objArr) {
        throw new IllegalArgumentException(String.format(str, objArr));
    }

    private static IOException ioException(String str, Object... objArr) {
        throw new IOException(String.format(str, objArr));
    }

    public Protocol getProtocol() {
        return Protocol.HTTP_2;
    }

    public int maxFrameSize() {
        return 16383;
    }

    public FrameReader newReader(BufferedSource bufferedSource, boolean z) {
        return new Reader(bufferedSource, 4096, z);
    }

    public FrameWriter newWriter(BufferedSink bufferedSink, boolean z) {
        return new Writer(bufferedSink, z);
    }
}
