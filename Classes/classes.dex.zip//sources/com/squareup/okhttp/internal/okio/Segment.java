package com.squareup.okhttp.internal.okio;

final class Segment {
    static final int SIZE = 2048;
    final byte[] data = new byte[SIZE];
    int limit;
    Segment next;
    int pos;
    Segment prev;

    Segment() {
    }

    public void compact() {
        Segment segment = this.prev;
        if (segment != this) {
            int i = segment.limit - segment.pos;
            int i2 = this.limit;
            int i3 = this.pos;
            if (i + (i2 - i3) <= SIZE) {
                writeTo(segment, i2 - i3);
                pop();
                SegmentPool.INSTANCE.recycle(this);
                return;
            }
            return;
        }
        throw new IllegalStateException();
    }

    public Segment pop() {
        Segment segment = this.next;
        if (segment == this) {
            segment = null;
        }
        Segment segment2 = this.prev;
        segment2.next = this.next;
        this.next.prev = segment2;
        this.next = null;
        this.prev = null;
        return segment;
    }

    public Segment push(Segment segment) {
        segment.prev = this;
        segment.next = this.next;
        this.next.prev = segment;
        this.next = segment;
        return segment;
    }

    public Segment split(int i) {
        int i2 = (this.limit - this.pos) - i;
        if (i <= 0 || i2 <= 0) {
            throw new IllegalArgumentException();
        } else if (i < i2) {
            Segment take = SegmentPool.INSTANCE.take();
            System.arraycopy(this.data, this.pos, take.data, take.pos, i);
            this.pos += i;
            take.limit += i;
            this.prev.push(take);
            return take;
        } else {
            Segment take2 = SegmentPool.INSTANCE.take();
            System.arraycopy(this.data, this.pos + i, take2.data, take2.pos, i2);
            this.limit -= i2;
            take2.limit += i2;
            push(take2);
            return this;
        }
    }

    public void writeTo(Segment segment, int i) {
        int i2 = segment.limit;
        int i3 = segment.pos;
        if ((i2 - i3) + i <= SIZE) {
            if (i2 + i > SIZE) {
                byte[] bArr = segment.data;
                System.arraycopy(bArr, i3, bArr, 0, i2 - i3);
                segment.limit -= segment.pos;
                segment.pos = 0;
            }
            System.arraycopy(this.data, this.pos, segment.data, segment.limit, i);
            segment.limit += i;
            this.pos += i;
            return;
        }
        throw new IllegalArgumentException();
    }
}
