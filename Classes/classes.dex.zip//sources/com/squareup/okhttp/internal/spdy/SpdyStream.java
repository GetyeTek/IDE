package com.squareup.okhttp.internal.spdy;

import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.Deadline;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Sink;
import com.squareup.okhttp.internal.okio.Source;
import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

public final class SpdyStream {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    long bytesLeftInWriteWindow;
    /* access modifiers changed from: private */
    public final SpdyConnection connection;
    /* access modifiers changed from: private */
    public ErrorCode errorCode = null;
    /* access modifiers changed from: private */
    public final int id;
    private final int priority;
    /* access modifiers changed from: private */
    public long readTimeoutMillis = 0;
    private final List<Header> requestHeaders;
    private List<Header> responseHeaders;
    final SpdyDataSink sink;
    private final SpdyDataSource source;
    long unacknowledgedBytesRead = 0;

    final class SpdyDataSink implements Sink {
        static final /* synthetic */ boolean $assertionsDisabled = false;
        /* access modifiers changed from: private */
        public boolean closed;
        /* access modifiers changed from: private */
        public boolean finished;

        SpdyDataSink() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0012, code lost:
            com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r0).writeData(com.squareup.okhttp.internal.spdy.SpdyStream.access$600(r8.this$0), true, (com.squareup.okhttp.internal.okio.OkBuffer) null, 0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:11:0x0023, code lost:
            r1 = r8.this$0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x0025, code lost:
            monitor-enter(r1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:?, code lost:
            r8.closed = true;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0029, code lost:
            monitor-exit(r1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x002a, code lost:
            com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0).flush();
            com.squareup.okhttp.internal.spdy.SpdyStream.access$900(r8.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:0x0038, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:8:0x000a, code lost:
            r0 = r8.this$0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:9:0x0010, code lost:
            if (r0.sink.finished != false) goto L_0x0023;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void close() {
            /*
                r8 = this;
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                monitor-enter(r0)
                boolean r1 = r8.closed     // Catch:{ all -> 0x003c }
                if (r1 == 0) goto L_0x0009
                monitor-exit(r0)     // Catch:{ all -> 0x003c }
                return
            L_0x0009:
                monitor-exit(r0)     // Catch:{ all -> 0x003c }
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                com.squareup.okhttp.internal.spdy.SpdyStream$SpdyDataSink r1 = r0.sink
                boolean r1 = r1.finished
                if (r1 != 0) goto L_0x0023
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = r0.connection
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                int r3 = r0.id
                r4 = 1
                r5 = 0
                r6 = 0
                r2.writeData(r3, r4, r5, r6)
            L_0x0023:
                com.squareup.okhttp.internal.spdy.SpdyStream r1 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                monitor-enter(r1)
                r0 = 1
                r8.closed = r0     // Catch:{ all -> 0x0039 }
                monitor-exit(r1)     // Catch:{ all -> 0x0039 }
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                com.squareup.okhttp.internal.spdy.SpdyConnection r0 = r0.connection
                r0.flush()
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                r0.cancelStreamIfNecessary()
                return
            L_0x0039:
                r0 = move-exception
                monitor-exit(r1)     // Catch:{ all -> 0x0039 }
                throw r0
            L_0x003c:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x003c }
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyStream.SpdyDataSink.close():void");
        }

        public Sink deadline(Deadline deadline) {
            return this;
        }

        public void flush() {
            synchronized (SpdyStream.this) {
                SpdyStream.this.checkOutNotClosed();
            }
            SpdyStream.this.connection.flush();
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(3:13|14|15) */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0046, code lost:
            throw new java.io.InterruptedIOException();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:9:?, code lost:
            com.squareup.okhttp.internal.spdy.SpdyStream.access$1000(r9.this$0);
            r7 = java.lang.Math.min(r9.this$0.bytesLeftInWriteWindow, r11);
            r9.this$0.bytesLeftInWriteWindow -= r7;
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0041 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void write(com.squareup.okhttp.internal.okio.OkBuffer r10, long r11) {
            /*
                r9 = this;
            L_0x0000:
                r0 = 0
                int r2 = (r11 > r0 ? 1 : (r11 == r0 ? 0 : -1))
                if (r2 <= 0) goto L_0x0049
                com.squareup.okhttp.internal.spdy.SpdyStream r2 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                monitor-enter(r2)
            L_0x0009:
                com.squareup.okhttp.internal.spdy.SpdyStream r3 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ InterruptedException -> 0x0041 }
                long r3 = r3.bytesLeftInWriteWindow     // Catch:{ InterruptedException -> 0x0041 }
                int r5 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1))
                if (r5 > 0) goto L_0x0017
                com.squareup.okhttp.internal.spdy.SpdyStream r3 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ InterruptedException -> 0x0041 }
                r3.wait()     // Catch:{ InterruptedException -> 0x0041 }
                goto L_0x0009
            L_0x0017:
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x003f }
                r0.checkOutNotClosed()     // Catch:{ all -> 0x003f }
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x003f }
                long r0 = r0.bytesLeftInWriteWindow     // Catch:{ all -> 0x003f }
                long r7 = java.lang.Math.min(r0, r11)     // Catch:{ all -> 0x003f }
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x003f }
                long r3 = r0.bytesLeftInWriteWindow     // Catch:{ all -> 0x003f }
                long r3 = r3 - r7
                r0.bytesLeftInWriteWindow = r3     // Catch:{ all -> 0x003f }
                monitor-exit(r2)     // Catch:{ all -> 0x003f }
                long r11 = r11 - r7
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                com.squareup.okhttp.internal.spdy.SpdyConnection r3 = r0.connection
                com.squareup.okhttp.internal.spdy.SpdyStream r0 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                int r4 = r0.id
                r5 = 0
                r6 = r10
                r3.writeData(r4, r5, r6, r7)
                goto L_0x0000
            L_0x003f:
                r10 = move-exception
                goto L_0x0047
            L_0x0041:
                java.io.InterruptedIOException r10 = new java.io.InterruptedIOException     // Catch:{ all -> 0x003f }
                r10.<init>()     // Catch:{ all -> 0x003f }
                throw r10     // Catch:{ all -> 0x003f }
            L_0x0047:
                monitor-exit(r2)     // Catch:{ all -> 0x003f }
                throw r10
            L_0x0049:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyStream.SpdyDataSink.write(com.squareup.okhttp.internal.okio.OkBuffer, long):void");
        }
    }

    private final class SpdyDataSource implements Source {
        static final /* synthetic */ boolean $assertionsDisabled = false;
        /* access modifiers changed from: private */
        public boolean closed;
        /* access modifiers changed from: private */
        public boolean finished;
        private final long maxByteCount;
        private final OkBuffer readBuffer;
        private final OkBuffer receiveBuffer;

        private SpdyDataSource(long j) {
            this.receiveBuffer = new OkBuffer();
            this.readBuffer = new OkBuffer();
            this.maxByteCount = j;
        }

        private void checkNotClosed() {
            if (this.closed) {
                throw new IOException("stream closed");
            } else if (SpdyStream.this.errorCode != null) {
                throw new IOException("stream was reset: " + SpdyStream.this.errorCode);
            }
        }

        private void waitUntilReadable() {
            long j;
            long j2;
            if (SpdyStream.this.readTimeoutMillis != 0) {
                j2 = System.nanoTime() / 1000000;
                j = SpdyStream.this.readTimeoutMillis;
            } else {
                j2 = 0;
                j = 0;
            }
            while (this.readBuffer.size() == 0 && !this.finished && !this.closed && SpdyStream.this.errorCode == null) {
                try {
                    if (SpdyStream.this.readTimeoutMillis == 0) {
                        SpdyStream.this.wait();
                    } else if (j > 0) {
                        SpdyStream.this.wait(j);
                        j = (SpdyStream.this.readTimeoutMillis + j2) - (System.nanoTime() / 1000000);
                    } else {
                        throw new SocketTimeoutException("Read timed out");
                    }
                } catch (InterruptedException unused) {
                    throw new InterruptedIOException();
                }
            }
        }

        public void close() {
            synchronized (SpdyStream.this) {
                this.closed = true;
                this.readBuffer.clear();
                SpdyStream.this.notifyAll();
            }
            SpdyStream.this.cancelStreamIfNecessary();
        }

        public Source deadline(Deadline deadline) {
            return this;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x0065, code lost:
            r11 = com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x006b, code lost:
            monitor-enter(r11);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:?, code lost:
            com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0).unacknowledgedBytesRead += r9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:0x0090, code lost:
            if (com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0).unacknowledgedBytesRead < ((long) (com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0).peerSettings.getInitialWindowSize(65536) / 2))) goto L_0x00ac;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:0x0092, code lost:
            com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0).writeWindowUpdateLater(0, com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0).unacknowledgedBytesRead);
            com.squareup.okhttp.internal.spdy.SpdyStream.access$500(r8.this$0).unacknowledgedBytesRead = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x00ac, code lost:
            monitor-exit(r11);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x00ad, code lost:
            return r9;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public long read(com.squareup.okhttp.internal.okio.OkBuffer r9, long r10) {
            /*
                r8 = this;
                r0 = 0
                int r2 = (r10 > r0 ? 1 : (r10 == r0 ? 0 : -1))
                if (r2 < 0) goto L_0x00b4
                com.squareup.okhttp.internal.spdy.SpdyStream r2 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                monitor-enter(r2)
                r8.waitUntilReadable()     // Catch:{ all -> 0x00b1 }
                r8.checkNotClosed()     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.okio.OkBuffer r3 = r8.readBuffer     // Catch:{ all -> 0x00b1 }
                long r3 = r3.size()     // Catch:{ all -> 0x00b1 }
                int r5 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1))
                if (r5 != 0) goto L_0x001d
                r9 = -1
                monitor-exit(r2)     // Catch:{ all -> 0x00b1 }
                return r9
            L_0x001d:
                com.squareup.okhttp.internal.okio.OkBuffer r3 = r8.readBuffer     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.okio.OkBuffer r4 = r8.readBuffer     // Catch:{ all -> 0x00b1 }
                long r4 = r4.size()     // Catch:{ all -> 0x00b1 }
                long r10 = java.lang.Math.min(r10, r4)     // Catch:{ all -> 0x00b1 }
                long r9 = r3.read(r9, r10)     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r11 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00b1 }
                long r3 = r11.unacknowledgedBytesRead     // Catch:{ all -> 0x00b1 }
                long r3 = r3 + r9
                r11.unacknowledgedBytesRead = r3     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r11 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00b1 }
                long r3 = r11.unacknowledgedBytesRead     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r11 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r11 = r11.connection     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.Settings r11 = r11.peerSettings     // Catch:{ all -> 0x00b1 }
                r5 = 65536(0x10000, float:9.18355E-41)
                int r11 = r11.getInitialWindowSize(r5)     // Catch:{ all -> 0x00b1 }
                int r11 = r11 / 2
                long r6 = (long) r11     // Catch:{ all -> 0x00b1 }
                int r11 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
                if (r11 < 0) goto L_0x0064
                com.squareup.okhttp.internal.spdy.SpdyStream r11 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r11 = r11.connection     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r3 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00b1 }
                int r3 = r3.id     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r4 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00b1 }
                long r6 = r4.unacknowledgedBytesRead     // Catch:{ all -> 0x00b1 }
                r11.writeWindowUpdateLater(r3, r6)     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r11 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00b1 }
                r11.unacknowledgedBytesRead = r0     // Catch:{ all -> 0x00b1 }
            L_0x0064:
                monitor-exit(r2)     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r11 = com.squareup.okhttp.internal.spdy.SpdyStream.this
                com.squareup.okhttp.internal.spdy.SpdyConnection r11 = r11.connection
                monitor-enter(r11)
                com.squareup.okhttp.internal.spdy.SpdyStream r2 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = r2.connection     // Catch:{ all -> 0x00ae }
                long r3 = r2.unacknowledgedBytesRead     // Catch:{ all -> 0x00ae }
                long r3 = r3 + r9
                r2.unacknowledgedBytesRead = r3     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyStream r2 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = r2.connection     // Catch:{ all -> 0x00ae }
                long r2 = r2.unacknowledgedBytesRead     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyStream r4 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyConnection r4 = r4.connection     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.Settings r4 = r4.peerSettings     // Catch:{ all -> 0x00ae }
                int r4 = r4.getInitialWindowSize(r5)     // Catch:{ all -> 0x00ae }
                int r4 = r4 / 2
                long r4 = (long) r4     // Catch:{ all -> 0x00ae }
                int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r6 < 0) goto L_0x00ac
                com.squareup.okhttp.internal.spdy.SpdyStream r2 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = r2.connection     // Catch:{ all -> 0x00ae }
                r3 = 0
                com.squareup.okhttp.internal.spdy.SpdyStream r4 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyConnection r4 = r4.connection     // Catch:{ all -> 0x00ae }
                long r4 = r4.unacknowledgedBytesRead     // Catch:{ all -> 0x00ae }
                r2.writeWindowUpdateLater(r3, r4)     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyStream r2 = com.squareup.okhttp.internal.spdy.SpdyStream.this     // Catch:{ all -> 0x00ae }
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = r2.connection     // Catch:{ all -> 0x00ae }
                r2.unacknowledgedBytesRead = r0     // Catch:{ all -> 0x00ae }
            L_0x00ac:
                monitor-exit(r11)     // Catch:{ all -> 0x00ae }
                return r9
            L_0x00ae:
                r9 = move-exception
                monitor-exit(r11)     // Catch:{ all -> 0x00ae }
                throw r9
            L_0x00b1:
                r9 = move-exception
                monitor-exit(r2)     // Catch:{ all -> 0x00b1 }
                throw r9
            L_0x00b4:
                java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "byteCount < 0: "
                r0.append(r1)
                r0.append(r10)
                java.lang.String r10 = r0.toString()
                r9.<init>(r10)
                throw r9
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyStream.SpdyDataSource.read(com.squareup.okhttp.internal.okio.OkBuffer, long):long");
        }

        /* access modifiers changed from: package-private */
        public void receive(BufferedSource bufferedSource, long j) {
            boolean z;
            boolean z2;
            boolean z3;
            while (j > 0) {
                synchronized (SpdyStream.this) {
                    z = this.finished;
                    z2 = true;
                    z3 = this.readBuffer.size() + j > this.maxByteCount;
                }
                if (z3) {
                    bufferedSource.skip(j);
                    SpdyStream.this.closeLater(ErrorCode.FLOW_CONTROL_ERROR);
                    return;
                } else if (z) {
                    bufferedSource.skip(j);
                    return;
                } else {
                    long read = bufferedSource.read(this.receiveBuffer, j);
                    if (read != -1) {
                        j -= read;
                        synchronized (SpdyStream.this) {
                            if (this.readBuffer.size() != 0) {
                                z2 = false;
                            }
                            this.readBuffer.write(this.receiveBuffer, this.receiveBuffer.size());
                            if (z2) {
                                SpdyStream.this.notifyAll();
                            }
                        }
                    } else {
                        throw new EOFException();
                    }
                }
            }
        }
    }

    SpdyStream(int i, SpdyConnection spdyConnection, boolean z, boolean z2, int i2, List<Header> list) {
        if (spdyConnection == null) {
            throw new NullPointerException("connection == null");
        } else if (list != null) {
            this.id = i;
            this.connection = spdyConnection;
            this.bytesLeftInWriteWindow = (long) spdyConnection.peerSettings.getInitialWindowSize(65536);
            this.source = new SpdyDataSource((long) spdyConnection.okHttpSettings.getInitialWindowSize(65536));
            this.sink = new SpdyDataSink();
            boolean unused = this.source.finished = z2;
            boolean unused2 = this.sink.finished = z;
            this.priority = i2;
            this.requestHeaders = list;
        } else {
            throw new NullPointerException("requestHeaders == null");
        }
    }

    /* access modifiers changed from: private */
    public void cancelStreamIfNecessary() {
        boolean z;
        boolean isOpen;
        synchronized (this) {
            z = !this.source.finished && this.source.closed && (this.sink.finished || this.sink.closed);
            isOpen = isOpen();
        }
        if (z) {
            close(ErrorCode.CANCEL);
        } else if (!isOpen) {
            this.connection.removeStream(this.id);
        }
    }

    /* access modifiers changed from: private */
    public void checkOutNotClosed() {
        if (this.sink.closed) {
            throw new IOException("stream closed");
        } else if (this.sink.finished) {
            throw new IOException("stream finished");
        } else if (this.errorCode != null) {
            throw new IOException("stream was reset: " + this.errorCode);
        }
    }

    private boolean closeInternal(ErrorCode errorCode2) {
        synchronized (this) {
            if (this.errorCode != null) {
                return false;
            }
            if (this.source.finished && this.sink.finished) {
                return false;
            }
            this.errorCode = errorCode2;
            notifyAll();
            this.connection.removeStream(this.id);
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public void addBytesToWriteWindow(long j) {
        this.bytesLeftInWriteWindow += j;
        if (j > 0) {
            notifyAll();
        }
    }

    public void close(ErrorCode errorCode2) {
        if (closeInternal(errorCode2)) {
            this.connection.writeSynReset(this.id, errorCode2);
        }
    }

    public void closeLater(ErrorCode errorCode2) {
        if (closeInternal(errorCode2)) {
            this.connection.writeSynResetLater(this.id, errorCode2);
        }
    }

    public SpdyConnection getConnection() {
        return this.connection;
    }

    public synchronized ErrorCode getErrorCode() {
        return this.errorCode;
    }

    public int getId() {
        return this.id;
    }

    /* access modifiers changed from: package-private */
    public int getPriority() {
        return this.priority;
    }

    public long getReadTimeoutMillis() {
        return this.readTimeoutMillis;
    }

    public List<Header> getRequestHeaders() {
        return this.requestHeaders;
    }

    public synchronized List<Header> getResponseHeaders() {
        long j;
        long j2;
        if (this.readTimeoutMillis != 0) {
            j2 = System.nanoTime() / 1000000;
            j = this.readTimeoutMillis;
        } else {
            j2 = 0;
            j = 0;
        }
        while (this.responseHeaders == null && this.errorCode == null) {
            try {
                if (this.readTimeoutMillis == 0) {
                    wait();
                } else if (j > 0) {
                    wait(j);
                    j = (this.readTimeoutMillis + j2) - (System.nanoTime() / 1000000);
                } else {
                    throw new SocketTimeoutException("Read response header timeout. readTimeoutMillis: " + this.readTimeoutMillis);
                }
            } catch (InterruptedException e) {
                InterruptedIOException interruptedIOException = new InterruptedIOException();
                interruptedIOException.initCause(e);
                throw interruptedIOException;
            }
        }
        if (this.responseHeaders != null) {
        } else {
            throw new IOException("stream was reset: " + this.errorCode);
        }
        return this.responseHeaders;
    }

    public Sink getSink() {
        synchronized (this) {
            if (this.responseHeaders == null) {
                if (!isLocallyInitiated()) {
                    throw new IllegalStateException("reply before requesting the sink");
                }
            }
        }
        return this.sink;
    }

    public Source getSource() {
        return this.source;
    }

    public boolean isLocallyInitiated() {
        return this.connection.client == ((this.id & 1) == 1);
    }

    public synchronized boolean isOpen() {
        if (this.errorCode != null) {
            return false;
        }
        return (!this.source.finished && !this.source.closed) || (!this.sink.finished && !this.sink.closed) || this.responseHeaders == null;
    }

    /* access modifiers changed from: package-private */
    public void receiveData(BufferedSource bufferedSource, int i) {
        this.source.receive(bufferedSource, (long) i);
    }

    /* access modifiers changed from: package-private */
    public void receiveFin() {
        boolean isOpen;
        synchronized (this) {
            boolean unused = this.source.finished = true;
            isOpen = isOpen();
            notifyAll();
        }
        if (!isOpen) {
            this.connection.removeStream(this.id);
        }
    }

    /* access modifiers changed from: package-private */
    public void receiveHeaders(List<Header> list, HeadersMode headersMode) {
        ErrorCode errorCode2 = null;
        boolean z = true;
        synchronized (this) {
            if (this.responseHeaders == null) {
                if (headersMode.failIfHeadersAbsent()) {
                    errorCode2 = ErrorCode.PROTOCOL_ERROR;
                } else {
                    this.responseHeaders = list;
                    z = isOpen();
                    notifyAll();
                }
            } else if (headersMode.failIfHeadersPresent()) {
                errorCode2 = ErrorCode.STREAM_IN_USE;
            } else {
                ArrayList arrayList = new ArrayList();
                arrayList.addAll(this.responseHeaders);
                arrayList.addAll(list);
                this.responseHeaders = arrayList;
            }
        }
        if (errorCode2 != null) {
            closeLater(errorCode2);
        } else if (!z) {
            this.connection.removeStream(this.id);
        }
    }

    /* access modifiers changed from: package-private */
    public synchronized void receiveRstStream(ErrorCode errorCode2) {
        if (this.errorCode == null) {
            this.errorCode = errorCode2;
            notifyAll();
        }
    }

    public void reply(List<Header> list, boolean z) {
        boolean z2 = false;
        synchronized (this) {
            if (list != null) {
                try {
                    if (this.responseHeaders == null) {
                        this.responseHeaders = list;
                        if (!z) {
                            boolean unused = this.sink.finished = true;
                            z2 = true;
                        }
                    } else {
                        throw new IllegalStateException("reply already sent");
                    }
                } catch (Throwable th) {
                    throw th;
                }
            } else {
                throw new NullPointerException("responseHeaders == null");
            }
        }
        this.connection.writeSynReply(this.id, z2, list);
        if (z2) {
            this.connection.flush();
        }
    }

    public void setReadTimeout(long j) {
        this.readTimeoutMillis = j;
    }
}
