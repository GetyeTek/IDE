package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.CacheControl;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.ResponseSource;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public final class CacheStrategy {
    /* access modifiers changed from: private */
    public static final Response.Body EMPTY_BODY = new Response.Body() {
        public InputStream byteStream() {
            return Util.EMPTY_INPUT_STREAM;
        }

        public long contentLength() {
            return 0;
        }

        public MediaType contentType() {
            return null;
        }

        public boolean ready() {
            return true;
        }
    };
    /* access modifiers changed from: private */
    public static final StatusLine GATEWAY_TIMEOUT_STATUS_LINE;
    public final Request request;
    public final Response response;
    public final ResponseSource source;

    public static class Factory {
        private int ageSeconds = -1;
        final Response cacheResponse;
        private String etag;
        private Date expires;
        private Date lastModified;
        private String lastModifiedString;
        final long nowMillis;
        private long receivedResponseMillis;
        final Request request;
        private long sentRequestMillis;
        private Date servedDate;
        private String servedDateString;

        public Factory(long j, Request request2, Response response) {
            this.nowMillis = j;
            this.request = request2;
            this.cacheResponse = response;
            if (response != null) {
                for (int i = 0; i < response.headers().size(); i++) {
                    String name = response.headers().name(i);
                    String value = response.headers().value(i);
                    if ("Date".equalsIgnoreCase(name)) {
                        this.servedDate = HttpDate.parse(value);
                        this.servedDateString = value;
                    } else if ("Expires".equalsIgnoreCase(name)) {
                        this.expires = HttpDate.parse(value);
                    } else if ("Last-Modified".equalsIgnoreCase(name)) {
                        this.lastModified = HttpDate.parse(value);
                        this.lastModifiedString = value;
                    } else if ("ETag".equalsIgnoreCase(name)) {
                        this.etag = value;
                    } else if ("Age".equalsIgnoreCase(name)) {
                        this.ageSeconds = HeaderParser.parseSeconds(value);
                    } else if (OkHeaders.SENT_MILLIS.equalsIgnoreCase(name)) {
                        this.sentRequestMillis = Long.parseLong(value);
                    } else if (OkHeaders.RECEIVED_MILLIS.equalsIgnoreCase(name)) {
                        this.receivedResponseMillis = Long.parseLong(value);
                    }
                }
            }
        }

        private long cacheResponseAge() {
            Date date = this.servedDate;
            long j = 0;
            if (date != null) {
                j = Math.max(0, this.receivedResponseMillis - date.getTime());
            }
            int i = this.ageSeconds;
            if (i != -1) {
                j = Math.max(j, TimeUnit.SECONDS.toMillis((long) i));
            }
            long j2 = this.receivedResponseMillis;
            return j + (j2 - this.sentRequestMillis) + (this.nowMillis - j2);
        }

        private long computeFreshnessLifetime() {
            CacheControl cacheControl = this.cacheResponse.cacheControl();
            if (cacheControl.maxAgeSeconds() != -1) {
                return TimeUnit.SECONDS.toMillis((long) cacheControl.maxAgeSeconds());
            }
            if (this.expires != null) {
                Date date = this.servedDate;
                long time = this.expires.getTime() - (date != null ? date.getTime() : this.receivedResponseMillis);
                if (time > 0) {
                    return time;
                }
                return 0;
            } else if (this.lastModified == null || this.cacheResponse.request().url().getQuery() != null) {
                return 0;
            } else {
                Date date2 = this.servedDate;
                long time2 = (date2 != null ? date2.getTime() : this.sentRequestMillis) - this.lastModified.getTime();
                if (time2 > 0) {
                    return time2 / 10;
                }
                return 0;
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:53:0x0107  */
        /* JADX WARNING: Removed duplicated region for block: B:56:0x0116  */
        /* JADX WARNING: Removed duplicated region for block: B:57:0x0119  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private com.squareup.okhttp.internal.http.CacheStrategy getCandidate() {
            /*
                r13 = this;
                com.squareup.okhttp.internal.http.Response r0 = r13.cacheResponse
                r1 = 0
                if (r0 != 0) goto L_0x000f
                com.squareup.okhttp.internal.http.CacheStrategy r2 = new com.squareup.okhttp.internal.http.CacheStrategy
                com.squareup.okhttp.internal.http.Request r3 = r13.request
                com.squareup.okhttp.ResponseSource r4 = com.squareup.okhttp.ResponseSource.NETWORK
                r2.<init>(r3, r0, r4)
                return r2
            L_0x000f:
                com.squareup.okhttp.internal.http.Request r0 = r13.request
                boolean r0 = r0.isHttps()
                if (r0 == 0) goto L_0x002b
                com.squareup.okhttp.internal.http.Response r0 = r13.cacheResponse
                com.squareup.okhttp.Handshake r0 = r0.handshake()
                if (r0 != 0) goto L_0x002b
                com.squareup.okhttp.internal.http.CacheStrategy r0 = new com.squareup.okhttp.internal.http.CacheStrategy
                com.squareup.okhttp.internal.http.Request r2 = r13.request
                com.squareup.okhttp.internal.http.Response r3 = r13.cacheResponse
                com.squareup.okhttp.ResponseSource r4 = com.squareup.okhttp.ResponseSource.NETWORK
                r0.<init>(r2, r3, r4)
                return r0
            L_0x002b:
                com.squareup.okhttp.internal.http.Response r0 = r13.cacheResponse
                com.squareup.okhttp.internal.http.Request r2 = r13.request
                boolean r0 = com.squareup.okhttp.internal.http.CacheStrategy.isCacheable(r0, r2)
                if (r0 != 0) goto L_0x0041
                com.squareup.okhttp.internal.http.CacheStrategy r0 = new com.squareup.okhttp.internal.http.CacheStrategy
                com.squareup.okhttp.internal.http.Request r2 = r13.request
                com.squareup.okhttp.internal.http.Response r3 = r13.cacheResponse
                com.squareup.okhttp.ResponseSource r4 = com.squareup.okhttp.ResponseSource.NETWORK
                r0.<init>(r2, r3, r4)
                return r0
            L_0x0041:
                com.squareup.okhttp.internal.http.Request r0 = r13.request
                com.squareup.okhttp.CacheControl r0 = r0.cacheControl()
                boolean r2 = r0.noCache()
                if (r2 != 0) goto L_0x0123
                com.squareup.okhttp.internal.http.Request r2 = r13.request
                boolean r2 = hasConditions(r2)
                if (r2 == 0) goto L_0x0057
                goto L_0x0123
            L_0x0057:
                long r2 = r13.cacheResponseAge()
                long r4 = r13.computeFreshnessLifetime()
                int r6 = r0.maxAgeSeconds()
                r7 = -1
                if (r6 == r7) goto L_0x0075
                java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.SECONDS
                int r8 = r0.maxAgeSeconds()
                long r8 = (long) r8
                long r8 = r6.toMillis(r8)
                long r4 = java.lang.Math.min(r4, r8)
            L_0x0075:
                int r6 = r0.minFreshSeconds()
                r8 = 0
                if (r6 == r7) goto L_0x0089
                java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.SECONDS
                int r10 = r0.minFreshSeconds()
                long r10 = (long) r10
                long r10 = r6.toMillis(r10)
                goto L_0x008a
            L_0x0089:
                r10 = r8
            L_0x008a:
                com.squareup.okhttp.internal.http.Response r6 = r13.cacheResponse
                com.squareup.okhttp.CacheControl r6 = r6.cacheControl()
                boolean r12 = r6.mustRevalidate()
                if (r12 != 0) goto L_0x00a7
                int r12 = r0.maxStaleSeconds()
                if (r12 == r7) goto L_0x00a7
                java.util.concurrent.TimeUnit r7 = java.util.concurrent.TimeUnit.SECONDS
                int r0 = r0.maxStaleSeconds()
                long r8 = (long) r0
                long r8 = r7.toMillis(r8)
            L_0x00a7:
                boolean r0 = r6.noCache()
                if (r0 != 0) goto L_0x00ea
                long r10 = r10 + r2
                long r8 = r8 + r4
                int r0 = (r10 > r8 ? 1 : (r10 == r8 ? 0 : -1))
                if (r0 >= 0) goto L_0x00ea
                com.squareup.okhttp.internal.http.Response r0 = r13.cacheResponse
                com.squareup.okhttp.internal.http.Response$Builder r0 = r0.newBuilder()
                com.squareup.okhttp.ResponseSource r6 = com.squareup.okhttp.ResponseSource.CACHE
                com.squareup.okhttp.internal.http.Response$Builder r0 = r0.setResponseSource(r6)
                java.lang.String r6 = "Warning"
                int r7 = (r10 > r4 ? 1 : (r10 == r4 ? 0 : -1))
                if (r7 < 0) goto L_0x00ca
                java.lang.String r4 = "110 HttpURLConnection \"Response is stale\""
                r0.addHeader(r6, r4)
            L_0x00ca:
                r4 = 86400000(0x5265c00, double:4.2687272E-316)
                int r7 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r7 <= 0) goto L_0x00dc
                boolean r2 = r13.isFreshnessLifetimeHeuristic()
                if (r2 == 0) goto L_0x00dc
                java.lang.String r2 = "113 HttpURLConnection \"Heuristic expiration\""
                r0.addHeader(r6, r2)
            L_0x00dc:
                com.squareup.okhttp.internal.http.CacheStrategy r2 = new com.squareup.okhttp.internal.http.CacheStrategy
                com.squareup.okhttp.internal.http.Request r3 = r13.request
                com.squareup.okhttp.internal.http.Response r0 = r0.build()
                com.squareup.okhttp.ResponseSource r4 = com.squareup.okhttp.ResponseSource.CACHE
                r2.<init>(r3, r0, r4)
                return r2
            L_0x00ea:
                com.squareup.okhttp.internal.http.Request r0 = r13.request
                com.squareup.okhttp.internal.http.Request$Builder r0 = r0.newBuilder()
                java.util.Date r2 = r13.lastModified
                java.lang.String r3 = "If-Modified-Since"
                if (r2 == 0) goto L_0x00fc
                java.lang.String r2 = r13.lastModifiedString
            L_0x00f8:
                r0.header(r3, r2)
                goto L_0x0103
            L_0x00fc:
                java.util.Date r2 = r13.servedDate
                if (r2 == 0) goto L_0x0103
                java.lang.String r2 = r13.servedDateString
                goto L_0x00f8
            L_0x0103:
                java.lang.String r2 = r13.etag
                if (r2 == 0) goto L_0x010c
                java.lang.String r3 = "If-None-Match"
                r0.header(r3, r2)
            L_0x010c:
                com.squareup.okhttp.internal.http.Request r0 = r0.build()
                boolean r2 = hasConditions(r0)
                if (r2 == 0) goto L_0x0119
                com.squareup.okhttp.ResponseSource r2 = com.squareup.okhttp.ResponseSource.CONDITIONAL_CACHE
                goto L_0x011b
            L_0x0119:
                com.squareup.okhttp.ResponseSource r2 = com.squareup.okhttp.ResponseSource.NETWORK
            L_0x011b:
                com.squareup.okhttp.internal.http.CacheStrategy r3 = new com.squareup.okhttp.internal.http.CacheStrategy
                com.squareup.okhttp.internal.http.Response r4 = r13.cacheResponse
                r3.<init>(r0, r4, r2)
                return r3
            L_0x0123:
                com.squareup.okhttp.internal.http.CacheStrategy r0 = new com.squareup.okhttp.internal.http.CacheStrategy
                com.squareup.okhttp.internal.http.Request r2 = r13.request
                com.squareup.okhttp.internal.http.Response r3 = r13.cacheResponse
                com.squareup.okhttp.ResponseSource r4 = com.squareup.okhttp.ResponseSource.NETWORK
                r0.<init>(r2, r3, r4)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.http.CacheStrategy.Factory.getCandidate():com.squareup.okhttp.internal.http.CacheStrategy");
        }

        private static boolean hasConditions(Request request2) {
            return (request2.header("If-Modified-Since") == null && request2.header("If-None-Match") == null) ? false : true;
        }

        private boolean isFreshnessLifetimeHeuristic() {
            return this.cacheResponse.cacheControl().maxAgeSeconds() == -1 && this.expires == null;
        }

        public CacheStrategy get() {
            CacheStrategy candidate = getCandidate();
            if (candidate.source == ResponseSource.CACHE || !this.request.cacheControl().onlyIfCached()) {
                return candidate;
            }
            return new CacheStrategy(candidate.request, new Response.Builder().request(candidate.request).statusLine(CacheStrategy.GATEWAY_TIMEOUT_STATUS_LINE).setResponseSource(ResponseSource.NONE).body(CacheStrategy.EMPTY_BODY).build(), ResponseSource.NONE);
        }
    }

    static {
        try {
            GATEWAY_TIMEOUT_STATUS_LINE = new StatusLine("HTTP/1.1 504 Gateway Timeout");
        } catch (IOException unused) {
            throw new AssertionError();
        }
    }

    private CacheStrategy(Request request2, Response response2, ResponseSource responseSource) {
        this.request = request2;
        this.response = response2;
        this.source = responseSource;
    }

    public static boolean isCacheable(Response response2, Request request2) {
        int code = response2.code();
        if (code != 200 && code != 203 && code != 300 && code != 301 && code != 410) {
            return false;
        }
        CacheControl cacheControl = response2.cacheControl();
        return (request2.header("Authorization") == null || cacheControl.isPublic() || cacheControl.mustRevalidate() || cacheControl.sMaxAgeSeconds() != -1) && !cacheControl.noStore();
    }
}
