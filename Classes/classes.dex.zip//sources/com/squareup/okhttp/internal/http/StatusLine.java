package com.squareup.okhttp.internal.http;

import java.net.ProtocolException;

public final class StatusLine {
    public static final int HTTP_CONTINUE = 100;
    public static final int HTTP_TEMP_REDIRECT = 307;
    private final int httpMinorVersion;
    private final int responseCode;
    private final String responseMessage;
    private final String statusLine;

    public StatusLine(String str) {
        int i;
        String str2;
        int i2 = 9;
        if (str.startsWith("HTTP/1.")) {
            if (str.length() < 9 || str.charAt(8) != ' ') {
                throw new ProtocolException("Unexpected status line: " + str);
            }
            i = str.charAt(7) - '0';
            if (i < 0 || i > 9) {
                throw new ProtocolException("Unexpected status line: " + str);
            }
        } else if (str.startsWith("ICY ")) {
            i = 0;
            i2 = 4;
        } else {
            throw new ProtocolException("Unexpected status line: " + str);
        }
        int i3 = i2 + 3;
        if (str.length() >= i3) {
            try {
                int parseInt = Integer.parseInt(str.substring(i2, i3));
                if (str.length() <= i3) {
                    str2 = "";
                } else if (str.charAt(i3) == ' ') {
                    str2 = str.substring(i2 + 4);
                } else {
                    throw new ProtocolException("Unexpected status line: " + str);
                }
                this.responseMessage = str2;
                this.responseCode = parseInt;
                this.statusLine = str;
                this.httpMinorVersion = i;
            } catch (NumberFormatException unused) {
                throw new ProtocolException("Unexpected status line: " + str);
            }
        } else {
            throw new ProtocolException("Unexpected status line: " + str);
        }
    }

    public int code() {
        return this.responseCode;
    }

    public String getStatusLine() {
        return this.statusLine;
    }

    public int httpMinorVersion() {
        int i = this.httpMinorVersion;
        if (i != -1) {
            return i;
        }
        return 1;
    }

    public String message() {
        return this.responseMessage;
    }
}
