package com.squareup.okhttp.internal.okio;

final class Util {
    public static final String UTF_8 = "UTF-8";

    private Util() {
    }

    public static void checkOffsetAndCount(long j, long j2, long j3) {
        if ((j2 | j3) < 0 || j2 > j || j - j2 < j3) {
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    public static int reverseBytesInt(int i) {
        return ((i & 255) << 24) | ((-16777216 & i) >>> 24) | ((16711680 & i) >>> 8) | ((65280 & i) << 8);
    }

    public static int reverseBytesShort(short s) {
        short s2 = s & 65535;
        return ((s2 & 255) << 8) | ((65280 & s2) >>> 8);
    }

    public static void sneakyRethrow(Throwable th) {
        sneakyThrow2(th);
        throw null;
    }

    private static <T extends Throwable> void sneakyThrow2(Throwable th) {
        throw th;
    }
}
