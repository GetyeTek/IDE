package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.CacheControl;
import com.squareup.okhttp.Handshake;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.ResponseSource;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.okio.Source;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public final class Response {
    /* access modifiers changed from: private */
    public final Body body;
    private volatile CacheControl cacheControl;
    /* access modifiers changed from: private */
    public final Handshake handshake;
    /* access modifiers changed from: private */
    public final Headers headers;
    private volatile ParsedHeaders parsedHeaders;
    /* access modifiers changed from: private */
    public final Response redirectedBy;
    /* access modifiers changed from: private */
    public final Request request;
    /* access modifiers changed from: private */
    public final StatusLine statusLine;

    public static abstract class Body implements Closeable {
        private Reader reader;
        private Source source;

        private Charset charset() {
            MediaType contentType = contentType();
            return contentType != null ? contentType.charset(Util.UTF_8) : Util.UTF_8;
        }

        public abstract InputStream byteStream();

        public final byte[] bytes() {
            long contentLength = contentLength();
            if (contentLength > 2147483647L) {
                throw new IOException("Cannot buffer entire body for content length: " + contentLength);
            } else if (contentLength != -1) {
                byte[] bArr = new byte[((int) contentLength)];
                InputStream byteStream = byteStream();
                Util.readFully(byteStream, bArr);
                if (byteStream.read() == -1) {
                    return bArr;
                }
                throw new IOException("Content-Length and stream length disagree");
            } else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                Util.copy(byteStream(), byteArrayOutputStream);
                return byteArrayOutputStream.toByteArray();
            }
        }

        public final Reader charStream() {
            Reader reader2 = this.reader;
            if (reader2 != null) {
                return reader2;
            }
            InputStreamReader inputStreamReader = new InputStreamReader(byteStream(), charset());
            this.reader = inputStreamReader;
            return inputStreamReader;
        }

        public void close() {
            byteStream().close();
        }

        public abstract long contentLength();

        public abstract MediaType contentType();

        public abstract boolean ready();

        public Source source() {
            Source source2 = this.source;
            if (source2 != null) {
                return source2;
            }
            Source source3 = Okio.source(byteStream());
            this.source = source3;
            return source3;
        }

        public final String string() {
            return new String(bytes(), charset().name());
        }
    }

    public static class Builder {
        /* access modifiers changed from: private */
        public Body body;
        /* access modifiers changed from: private */
        public Handshake handshake;
        /* access modifiers changed from: private */
        public Headers.Builder headers;
        /* access modifiers changed from: private */
        public Response redirectedBy;
        /* access modifiers changed from: private */
        public Request request;
        /* access modifiers changed from: private */
        public StatusLine statusLine;

        public Builder() {
            this.headers = new Headers.Builder();
        }

        private Builder(Response response) {
            this.request = response.request;
            this.statusLine = response.statusLine;
            this.handshake = response.handshake;
            this.headers = response.headers.newBuilder();
            this.body = response.body;
            this.redirectedBy = response.redirectedBy;
        }

        public Builder addHeader(String str, String str2) {
            this.headers.add(str, str2);
            return this;
        }

        public Builder body(Body body2) {
            this.body = body2;
            return this;
        }

        public Response build() {
            if (this.request == null) {
                throw new IllegalStateException("request == null");
            } else if (this.statusLine != null) {
                return new Response(this);
            } else {
                throw new IllegalStateException("statusLine == null");
            }
        }

        public Builder handshake(Handshake handshake2) {
            this.handshake = handshake2;
            return this;
        }

        public Builder header(String str, String str2) {
            this.headers.set(str, str2);
            return this;
        }

        public Builder headers(Headers headers2) {
            this.headers = headers2.newBuilder();
            return this;
        }

        public Builder redirectedBy(Response response) {
            this.redirectedBy = response;
            return this;
        }

        public Builder removeHeader(String str) {
            this.headers.removeAll(str);
            return this;
        }

        public Builder request(Request request2) {
            this.request = request2;
            return this;
        }

        public Builder setResponseSource(ResponseSource responseSource) {
            String str = OkHeaders.RESPONSE_SOURCE;
            return header(str, responseSource + " " + this.statusLine.code());
        }

        public Builder statusLine(StatusLine statusLine2) {
            if (statusLine2 != null) {
                this.statusLine = statusLine2;
                return this;
            }
            throw new IllegalArgumentException("statusLine == null");
        }

        public Builder statusLine(String str) {
            try {
                return statusLine(new StatusLine(str));
            } catch (IOException e) {
                throw new IllegalArgumentException(e);
            }
        }
    }

    private static class ParsedHeaders {
        Date lastModified;
        /* access modifiers changed from: private */
        public Set<String> varyFields;

        private ParsedHeaders(Headers headers) {
            this.varyFields = Collections.emptySet();
            for (int i = 0; i < headers.size(); i++) {
                String name = headers.name(i);
                String value = headers.value(i);
                if ("Last-Modified".equalsIgnoreCase(name)) {
                    this.lastModified = HttpDate.parse(value);
                } else if ("Vary".equalsIgnoreCase(name)) {
                    if (this.varyFields.isEmpty()) {
                        this.varyFields = new TreeSet(String.CASE_INSENSITIVE_ORDER);
                    }
                    for (String trim : value.split(",")) {
                        this.varyFields.add(trim.trim());
                    }
                }
            }
        }
    }

    public interface Receiver {
        void onFailure(Failure failure);

        boolean onResponse(Response response);
    }

    private Response(Builder builder) {
        this.request = builder.request;
        this.statusLine = builder.statusLine;
        this.handshake = builder.handshake;
        this.headers = builder.headers.build();
        this.body = builder.body;
        this.redirectedBy = builder.redirectedBy;
    }

    private ParsedHeaders parsedHeaders() {
        ParsedHeaders parsedHeaders2 = this.parsedHeaders;
        if (parsedHeaders2 != null) {
            return parsedHeaders2;
        }
        ParsedHeaders parsedHeaders3 = new ParsedHeaders(this.headers);
        this.parsedHeaders = parsedHeaders3;
        return parsedHeaders3;
    }

    public Body body() {
        return this.body;
    }

    public CacheControl cacheControl() {
        CacheControl cacheControl2 = this.cacheControl;
        if (cacheControl2 != null) {
            return cacheControl2;
        }
        CacheControl parse = CacheControl.parse(this.headers);
        this.cacheControl = parse;
        return parse;
    }

    public int code() {
        return this.statusLine.code();
    }

    public Set<String> getVaryFields() {
        return parsedHeaders().varyFields;
    }

    public Handshake handshake() {
        return this.handshake;
    }

    public boolean hasVaryAll() {
        return parsedHeaders().varyFields.contains("*");
    }

    public String header(String str) {
        return header(str, (String) null);
    }

    public String header(String str, String str2) {
        String str3 = this.headers.get(str);
        return str3 != null ? str3 : str2;
    }

    public Headers headers() {
        return this.headers;
    }

    public List<String> headers(String str) {
        return this.headers.values(str);
    }

    public int httpMinorVersion() {
        return this.statusLine.httpMinorVersion();
    }

    public Builder newBuilder() {
        return new Builder();
    }

    public Response redirectedBy() {
        return this.redirectedBy;
    }

    public Request request() {
        return this.request;
    }

    public String statusLine() {
        return this.statusLine.getStatusLine();
    }

    public String statusMessage() {
        return this.statusLine.message();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0016, code lost:
        r7 = r7.lastModified;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean validate(com.squareup.okhttp.internal.http.Response r7) {
        /*
            r6 = this;
            int r0 = r7.code()
            r1 = 1
            r2 = 304(0x130, float:4.26E-43)
            if (r0 != r2) goto L_0x000a
            return r1
        L_0x000a:
            com.squareup.okhttp.internal.http.Response$ParsedHeaders r7 = r7.parsedHeaders()
            com.squareup.okhttp.internal.http.Response$ParsedHeaders r0 = r6.parsedHeaders()
            java.util.Date r0 = r0.lastModified
            if (r0 == 0) goto L_0x002d
            java.util.Date r7 = r7.lastModified
            if (r7 == 0) goto L_0x002d
            long r2 = r7.getTime()
            com.squareup.okhttp.internal.http.Response$ParsedHeaders r7 = r6.parsedHeaders()
            java.util.Date r7 = r7.lastModified
            long r4 = r7.getTime()
            int r7 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r7 >= 0) goto L_0x002d
            return r1
        L_0x002d:
            r7 = 0
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.http.Response.validate(com.squareup.okhttp.internal.http.Response):boolean");
    }

    public boolean varyMatches(Headers headers2, Request request2) {
        for (String str : parsedHeaders().varyFields) {
            if (!Util.equal(headers2.values(str), request2.headers(str))) {
                return false;
            }
        }
        return true;
    }
}
