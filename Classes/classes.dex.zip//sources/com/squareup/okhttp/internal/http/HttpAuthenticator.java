package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.OkAuthenticator;
import java.net.Authenticator;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public final class HttpAuthenticator {
    public static final OkAuthenticator SYSTEM_DEFAULT = new OkAuthenticator() {
        private InetAddress getConnectToInetAddress(Proxy proxy, URL url) {
            return (proxy == null || proxy.type() == Proxy.Type.DIRECT) ? InetAddress.getByName(url.getHost()) : ((InetSocketAddress) proxy.address()).getAddress();
        }

        public OkAuthenticator.Credential authenticate(Proxy proxy, URL url, List<OkAuthenticator.Challenge> list) {
            PasswordAuthentication requestPasswordAuthentication;
            int size = list.size();
            for (int i = 0; i < size; i++) {
                OkAuthenticator.Challenge challenge = list.get(i);
                if ("Basic".equalsIgnoreCase(challenge.getScheme()) && (requestPasswordAuthentication = Authenticator.requestPasswordAuthentication(url.getHost(), getConnectToInetAddress(proxy, url), url.getPort(), url.getProtocol(), challenge.getRealm(), challenge.getScheme(), url, Authenticator.RequestorType.SERVER)) != null) {
                    return OkAuthenticator.Credential.basic(requestPasswordAuthentication.getUserName(), new String(requestPasswordAuthentication.getPassword()));
                }
            }
            return null;
        }

        public OkAuthenticator.Credential authenticateProxy(Proxy proxy, URL url, List<OkAuthenticator.Challenge> list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                OkAuthenticator.Challenge challenge = list.get(i);
                if ("Basic".equalsIgnoreCase(challenge.getScheme())) {
                    InetSocketAddress inetSocketAddress = (InetSocketAddress) proxy.address();
                    PasswordAuthentication requestPasswordAuthentication = Authenticator.requestPasswordAuthentication(inetSocketAddress.getHostName(), getConnectToInetAddress(proxy, url), inetSocketAddress.getPort(), url.getProtocol(), challenge.getRealm(), challenge.getScheme(), url, Authenticator.RequestorType.PROXY);
                    if (requestPasswordAuthentication != null) {
                        return OkAuthenticator.Credential.basic(requestPasswordAuthentication.getUserName(), new String(requestPasswordAuthentication.getPassword()));
                    }
                }
            }
            return null;
        }
    };

    private HttpAuthenticator() {
    }

    private static List<OkAuthenticator.Challenge> parseChallenges(Headers headers, String str) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < headers.size(); i++) {
            if (str.equalsIgnoreCase(headers.name(i))) {
                String value = headers.value(i);
                int i2 = 0;
                while (i2 < value.length()) {
                    int skipUntil = HeaderParser.skipUntil(value, i2, " ");
                    String trim = value.substring(i2, skipUntil).trim();
                    int skipWhitespace = HeaderParser.skipWhitespace(value, skipUntil);
                    if (!value.regionMatches(true, skipWhitespace, "realm=\"", 0, 7)) {
                        break;
                    }
                    int i3 = skipWhitespace + 7;
                    int skipUntil2 = HeaderParser.skipUntil(value, i3, "\"");
                    String substring = value.substring(i3, skipUntil2);
                    i2 = HeaderParser.skipWhitespace(value, HeaderParser.skipUntil(value, skipUntil2 + 1, ",") + 1);
                    arrayList.add(new OkAuthenticator.Challenge(trim, substring));
                }
            }
        }
        return arrayList;
    }

    public static Request processAuthHeader(OkAuthenticator okAuthenticator, Response response, Proxy proxy) {
        String str;
        String str2;
        if (response.code() == 401) {
            str2 = "WWW-Authenticate";
            str = "Authorization";
        } else if (response.code() == 407) {
            str2 = "Proxy-Authenticate";
            str = "Proxy-Authorization";
        } else {
            throw new IllegalArgumentException();
        }
        List<OkAuthenticator.Challenge> parseChallenges = parseChallenges(response.headers(), str2);
        if (parseChallenges.isEmpty()) {
            return null;
        }
        Request request = response.request();
        OkAuthenticator.Credential authenticateProxy = response.code() == 407 ? okAuthenticator.authenticateProxy(proxy, request.url(), parseChallenges) : okAuthenticator.authenticate(proxy, request.url(), parseChallenges);
        if (authenticateProxy == null) {
            return null;
        }
        return request.newBuilder().header(str, authenticateProxy.getHeaderValue()).build();
    }
}
