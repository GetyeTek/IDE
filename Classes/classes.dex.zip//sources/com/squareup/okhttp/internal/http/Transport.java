package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.internal.http.Response;
import com.squareup.okhttp.internal.okio.Sink;
import com.squareup.okhttp.internal.okio.Source;
import java.net.CacheRequest;

interface Transport {
    public static final int DISCARD_STREAM_TIMEOUT_MILLIS = 100;

    boolean canReuseConnection();

    Sink createRequestBody(Request request);

    void disconnect(HttpEngine httpEngine);

    void emptyTransferStream();

    void flushRequest();

    Source getTransferStream(CacheRequest cacheRequest);

    Response.Builder readResponseHeaders();

    void releaseConnectionOnIdle();

    void writeRequestBody(RetryableSink retryableSink);

    void writeRequestHeaders(Request request);
}
