package com.squareup.okhttp.internal.http;

public final class Failure {
    private final Throwable exception;
    private final Request request;

    public static class Builder {
        /* access modifiers changed from: private */
        public Throwable exception;
        /* access modifiers changed from: private */
        public Request request;

        public Failure build() {
            return new Failure(this);
        }

        public Builder exception(Throwable th) {
            this.exception = th;
            return this;
        }

        public Builder request(Request request2) {
            this.request = request2;
            return this;
        }
    }

    private Failure(Builder builder) {
        this.request = builder.request;
        this.exception = builder.exception;
    }

    public Throwable exception() {
        return this.exception;
    }

    public Request request() {
        return this.request;
    }
}
