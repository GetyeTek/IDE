package com.squareup.okhttp.internal.okio;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

final class RealBufferedSource implements BufferedSource {
    public final OkBuffer buffer;
    /* access modifiers changed from: private */
    public boolean closed;
    public final Source source;

    public RealBufferedSource(Source source2) {
        this(source2, new OkBuffer());
    }

    public RealBufferedSource(Source source2, OkBuffer okBuffer) {
        if (source2 != null) {
            this.buffer = okBuffer;
            this.source = source2;
            return;
        }
        throw new IllegalArgumentException("source == null");
    }

    private void checkNotClosed() {
        if (this.closed) {
            throw new IllegalStateException("closed");
        }
    }

    public OkBuffer buffer() {
        return this.buffer;
    }

    public void close() {
        if (!this.closed) {
            this.closed = true;
            this.source.close();
            this.buffer.clear();
        }
    }

    public Source deadline(Deadline deadline) {
        this.source.deadline(deadline);
        return this;
    }

    public boolean exhausted() {
        checkNotClosed();
        return this.buffer.exhausted() && this.source.read(this.buffer, 2048) == -1;
    }

    public InputStream inputStream() {
        return new InputStream() {
            private void checkNotClosed() {
                if (RealBufferedSource.this.closed) {
                    throw new IOException("closed");
                }
            }

            public int available() {
                checkNotClosed();
                return (int) Math.min(RealBufferedSource.this.buffer.size, 2147483647L);
            }

            public void close() {
                RealBufferedSource.this.close();
            }

            public int read() {
                checkNotClosed();
                RealBufferedSource realBufferedSource = RealBufferedSource.this;
                OkBuffer okBuffer = realBufferedSource.buffer;
                if (okBuffer.size == 0 && realBufferedSource.source.read(okBuffer, 2048) == -1) {
                    return -1;
                }
                return RealBufferedSource.this.buffer.readByte() & 255;
            }

            public int read(byte[] bArr, int i, int i2) {
                checkNotClosed();
                Util.checkOffsetAndCount((long) bArr.length, (long) i, (long) i2);
                RealBufferedSource realBufferedSource = RealBufferedSource.this;
                OkBuffer okBuffer = realBufferedSource.buffer;
                if (okBuffer.size == 0 && realBufferedSource.source.read(okBuffer, 2048) == -1) {
                    return -1;
                }
                return RealBufferedSource.this.buffer.read(bArr, i, i2);
            }

            public String toString() {
                return RealBufferedSource.this + ".inputStream()";
            }
        };
    }

    public long read(OkBuffer okBuffer, long j) {
        if (j >= 0) {
            checkNotClosed();
            OkBuffer okBuffer2 = this.buffer;
            if (okBuffer2.size == 0 && this.source.read(okBuffer2, 2048) == -1) {
                return -1;
            }
            return this.buffer.read(okBuffer, Math.min(j, this.buffer.size));
        }
        throw new IllegalArgumentException("byteCount < 0: " + j);
    }

    public byte readByte() {
        require(1);
        return this.buffer.readByte();
    }

    public ByteString readByteString(long j) {
        require(j);
        return this.buffer.readByteString(j);
    }

    public int readInt() {
        require(4);
        return this.buffer.readInt();
    }

    public int readIntLe() {
        require(4);
        return this.buffer.readIntLe();
    }

    public short readShort() {
        require(2);
        return this.buffer.readShort();
    }

    public int readShortLe() {
        require(2);
        return this.buffer.readShortLe();
    }

    public String readUtf8(long j) {
        require(j);
        return this.buffer.readUtf8(j);
    }

    public String readUtf8Line(boolean z) {
        checkNotClosed();
        long j = 0;
        while (true) {
            long indexOf = this.buffer.indexOf((byte) 10, j);
            if (indexOf == -1) {
                OkBuffer okBuffer = this.buffer;
                long j2 = okBuffer.size;
                if (this.source.read(okBuffer, 2048) != -1) {
                    j = j2;
                } else if (!z) {
                    long j3 = this.buffer.size;
                    if (j3 != 0) {
                        return readUtf8(j3);
                    }
                    return null;
                } else {
                    throw new EOFException();
                }
            } else {
                if (indexOf > 0) {
                    long j4 = indexOf - 1;
                    if (this.buffer.getByte(j4) == 13) {
                        String readUtf8 = readUtf8(j4);
                        skip(2);
                        return readUtf8;
                    }
                }
                String readUtf82 = readUtf8(indexOf);
                skip(1);
                return readUtf82;
            }
        }
    }

    public void require(long j) {
        OkBuffer okBuffer;
        checkNotClosed();
        do {
            okBuffer = this.buffer;
            if (okBuffer.size >= j) {
                return;
            }
        } while (this.source.read(okBuffer, 2048) != -1);
        throw new EOFException();
    }

    public long seek(byte b2) {
        checkNotClosed();
        long j = 0;
        while (true) {
            long indexOf = this.buffer.indexOf(b2, j);
            if (indexOf != -1) {
                return indexOf;
            }
            OkBuffer okBuffer = this.buffer;
            long j2 = okBuffer.size;
            if (this.source.read(okBuffer, 2048) != -1) {
                j = j2;
            } else {
                throw new EOFException();
            }
        }
    }

    public void skip(long j) {
        checkNotClosed();
        while (j > 0) {
            OkBuffer okBuffer = this.buffer;
            if (okBuffer.size == 0 && this.source.read(okBuffer, 2048) == -1) {
                throw new EOFException();
            }
            long min = Math.min(j, this.buffer.size());
            this.buffer.skip(min);
            j -= min;
        }
    }

    public String toString() {
        return "buffer(" + this.source + ")";
    }
}
