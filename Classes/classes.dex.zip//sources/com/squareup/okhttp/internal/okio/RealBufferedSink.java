package com.squareup.okhttp.internal.okio;

import java.io.IOException;
import java.io.OutputStream;

final class RealBufferedSink implements BufferedSink {
    public final OkBuffer buffer;
    /* access modifiers changed from: private */
    public boolean closed;
    public final Sink sink;

    public RealBufferedSink(Sink sink2) {
        this(sink2, new OkBuffer());
    }

    public RealBufferedSink(Sink sink2, OkBuffer okBuffer) {
        if (sink2 != null) {
            this.buffer = okBuffer;
            this.sink = sink2;
            return;
        }
        throw new IllegalArgumentException("sink == null");
    }

    private void checkNotClosed() {
        if (this.closed) {
            throw new IllegalStateException("closed");
        }
    }

    public OkBuffer buffer() {
        return this.buffer;
    }

    public void close() {
        if (!this.closed) {
            try {
                if (this.buffer.size > 0) {
                    this.sink.write(this.buffer, this.buffer.size);
                }
                th = null;
            } catch (Throwable th) {
                th = th;
            }
            try {
                this.sink.close();
            } catch (Throwable th2) {
                if (th == null) {
                    th = th2;
                }
            }
            this.closed = true;
            if (th != null) {
                Util.sneakyRethrow(th);
                throw null;
            }
        }
    }

    public Sink deadline(Deadline deadline) {
        this.sink.deadline(deadline);
        return this;
    }

    public BufferedSink emitCompleteSegments() {
        checkNotClosed();
        long completeSegmentByteCount = this.buffer.completeSegmentByteCount();
        if (completeSegmentByteCount > 0) {
            this.sink.write(this.buffer, completeSegmentByteCount);
        }
        return this;
    }

    public void flush() {
        checkNotClosed();
        OkBuffer okBuffer = this.buffer;
        long j = okBuffer.size;
        if (j > 0) {
            this.sink.write(okBuffer, j);
        }
        this.sink.flush();
    }

    public OutputStream outputStream() {
        return new OutputStream() {
            private void checkNotClosed() {
                if (RealBufferedSink.this.closed) {
                    throw new IOException("closed");
                }
            }

            public void close() {
                RealBufferedSink.this.close();
            }

            public void flush() {
                if (!RealBufferedSink.this.closed) {
                    RealBufferedSink.this.flush();
                }
            }

            public String toString() {
                return RealBufferedSink.this + ".outputStream()";
            }

            public void write(int i) {
                checkNotClosed();
                RealBufferedSink.this.buffer.writeByte((int) (byte) i);
                RealBufferedSink.this.emitCompleteSegments();
            }

            public void write(byte[] bArr, int i, int i2) {
                checkNotClosed();
                RealBufferedSink.this.buffer.write(bArr, i, i2);
                RealBufferedSink.this.emitCompleteSegments();
            }
        };
    }

    public String toString() {
        return "buffer(" + this.sink + ")";
    }

    public BufferedSink write(ByteString byteString) {
        checkNotClosed();
        this.buffer.write(byteString);
        return emitCompleteSegments();
    }

    public BufferedSink write(byte[] bArr) {
        checkNotClosed();
        this.buffer.write(bArr);
        return emitCompleteSegments();
    }

    public BufferedSink write(byte[] bArr, int i, int i2) {
        checkNotClosed();
        this.buffer.write(bArr, i, i2);
        return emitCompleteSegments();
    }

    public void write(OkBuffer okBuffer, long j) {
        checkNotClosed();
        this.buffer.write(okBuffer, j);
        emitCompleteSegments();
    }

    public BufferedSink writeByte(int i) {
        checkNotClosed();
        this.buffer.writeByte(i);
        return emitCompleteSegments();
    }

    public BufferedSink writeInt(int i) {
        checkNotClosed();
        this.buffer.writeInt(i);
        return emitCompleteSegments();
    }

    public BufferedSink writeShort(int i) {
        checkNotClosed();
        this.buffer.writeShort(i);
        return emitCompleteSegments();
    }

    public BufferedSink writeUtf8(String str) {
        checkNotClosed();
        this.buffer.writeUtf8(str);
        return emitCompleteSegments();
    }
}
