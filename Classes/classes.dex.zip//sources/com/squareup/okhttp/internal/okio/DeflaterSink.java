package com.squareup.okhttp.internal.okio;

import java.util.zip.Deflater;

public final class DeflaterSink implements Sink {
    private boolean closed;
    private final Deflater deflater;
    private final BufferedSink sink;

    public DeflaterSink(Sink sink2, Deflater deflater2) {
        this.sink = Okio.buffer(sink2);
        this.deflater = deflater2;
    }

    private void deflate(boolean z) {
        int i;
        OkBuffer buffer = this.sink.buffer();
        while (true) {
            Segment writableSegment = buffer.writableSegment(1);
            if (z) {
                Deflater deflater2 = this.deflater;
                byte[] bArr = writableSegment.data;
                int i2 = writableSegment.limit;
                i = deflater2.deflate(bArr, i2, 2048 - i2, 2);
            } else {
                Deflater deflater3 = this.deflater;
                byte[] bArr2 = writableSegment.data;
                int i3 = writableSegment.limit;
                i = deflater3.deflate(bArr2, i3, 2048 - i3);
            }
            if (i > 0) {
                writableSegment.limit += i;
                buffer.size += (long) i;
                this.sink.emitCompleteSegments();
            } else if (this.deflater.needsInput()) {
                return;
            }
        }
    }

    public void close() {
        if (!this.closed) {
            try {
                this.deflater.finish();
                deflate(false);
                th = null;
            } catch (Throwable th) {
                th = th;
            }
            try {
                this.deflater.end();
            } catch (Throwable th2) {
                if (th == null) {
                    th = th2;
                }
            }
            try {
                this.sink.close();
            } catch (Throwable th3) {
                if (th == null) {
                    th = th3;
                }
            }
            this.closed = true;
            if (th != null) {
                Util.sneakyRethrow(th);
                throw null;
            }
        }
    }

    public Sink deadline(Deadline deadline) {
        this.sink.deadline(deadline);
        return this;
    }

    public void flush() {
        deflate(true);
        this.sink.flush();
    }

    public String toString() {
        return "DeflaterSink(" + this.sink + ")";
    }

    public void write(OkBuffer okBuffer, long j) {
        Util.checkOffsetAndCount(okBuffer.size, 0, j);
        while (j > 0) {
            Segment segment = okBuffer.head;
            int min = (int) Math.min(j, (long) (segment.limit - segment.pos));
            this.deflater.setInput(segment.data, segment.pos, min);
            deflate(false);
            long j2 = (long) min;
            okBuffer.size -= j2;
            segment.pos += min;
            if (segment.pos == segment.limit) {
                okBuffer.head = segment.pop();
                SegmentPool.INSTANCE.recycle(segment);
            }
            j -= j2;
        }
    }
}
