package com.squareup.okhttp.internal.spdy;

import com.squareup.okhttp.Protocol;
import com.squareup.okhttp.internal.NamedRunnable;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.okio.BufferedSink;
import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.spdy.FrameReader;
import java.io.Closeable;
import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class SpdyConnection implements Closeable {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    /* access modifiers changed from: private */
    public static final ExecutorService executor = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, TimeUnit.SECONDS, new SynchronousQueue(), Util.threadFactory("OkHttp SpdyConnection", true));
    long bytesLeftInWriteWindow;
    final boolean client;
    /* access modifiers changed from: private */
    public final Set<Integer> currentPushRequests;
    final FrameReader frameReader;
    final FrameWriter frameWriter;
    /* access modifiers changed from: private */
    public final IncomingStreamHandler handler;
    /* access modifiers changed from: private */
    public final String hostName;
    private long idleStartTimeNs;
    /* access modifiers changed from: private */
    public int lastGoodStreamId;
    final long maxFrameSize;
    private int nextPingId;
    /* access modifiers changed from: private */
    public int nextStreamId;
    final Settings okHttpSettings;
    final Settings peerSettings;
    private Map<Integer, Ping> pings;
    final Protocol protocol;
    /* access modifiers changed from: private */
    public final PushObserver pushObserver;
    final Reader readerRunnable;
    /* access modifiers changed from: private */
    public boolean receivedInitialPeerSettings;
    /* access modifiers changed from: private */
    public boolean shutdown;
    /* access modifiers changed from: private */
    public final Map<Integer, SpdyStream> streams;
    long unacknowledgedBytesRead;

    public static class Builder {
        /* access modifiers changed from: private */
        public boolean client;
        /* access modifiers changed from: private */
        public IncomingStreamHandler handler;
        /* access modifiers changed from: private */
        public String hostName;
        /* access modifiers changed from: private */
        public Protocol protocol;
        /* access modifiers changed from: private */
        public PushObserver pushObserver;
        /* access modifiers changed from: private */
        public BufferedSink sink;
        /* access modifiers changed from: private */
        public BufferedSource source;

        public Builder(String str, boolean z, BufferedSource bufferedSource, BufferedSink bufferedSink) {
            this.handler = IncomingStreamHandler.REFUSE_INCOMING_STREAMS;
            this.protocol = Protocol.SPDY_3;
            this.pushObserver = PushObserver.CANCEL;
            this.hostName = str;
            this.client = z;
            this.source = bufferedSource;
            this.sink = bufferedSink;
        }

        public Builder(boolean z, Socket socket) {
            this("", z, Okio.buffer(Okio.source(socket.getInputStream())), Okio.buffer(Okio.sink(socket.getOutputStream())));
        }

        public SpdyConnection build() {
            return new SpdyConnection(this);
        }

        public Builder handler(IncomingStreamHandler incomingStreamHandler) {
            this.handler = incomingStreamHandler;
            return this;
        }

        public Builder protocol(Protocol protocol2) {
            this.protocol = protocol2;
            return this;
        }

        public Builder pushObserver(PushObserver pushObserver2) {
            this.pushObserver = pushObserver2;
            return this;
        }
    }

    class Reader extends NamedRunnable implements FrameReader.Handler {
        private Reader() {
            super("OkHttp %s", SpdyConnection.this.hostName);
        }

        private void ackSettingsLater() {
            SpdyConnection.executor.submit(new NamedRunnable("OkHttp %s ACK Settings", SpdyConnection.this.hostName) {
                public void execute() {
                    try {
                        SpdyConnection.this.frameWriter.ackSettings();
                    } catch (IOException unused) {
                    }
                }
            });
        }

        public void ackSettings() {
        }

        public void data(boolean z, int i, BufferedSource bufferedSource, int i2) {
            if (SpdyConnection.this.pushedStream(i)) {
                SpdyConnection.this.pushDataLater(i, bufferedSource, i2, z);
                return;
            }
            SpdyStream stream = SpdyConnection.this.getStream(i);
            if (stream == null) {
                SpdyConnection.this.writeSynResetLater(i, ErrorCode.INVALID_STREAM);
                bufferedSource.skip((long) i2);
                return;
            }
            stream.receiveData(bufferedSource, i2);
            if (z) {
                stream.receiveFin();
            }
        }

        /* access modifiers changed from: protected */
        /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
            r1 = com.squareup.okhttp.internal.spdy.ErrorCode.PROTOCOL_ERROR;
            r0 = com.squareup.okhttp.internal.spdy.ErrorCode.PROTOCOL_ERROR;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x002e, code lost:
            r2 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x002f, code lost:
            r4 = r2;
            r2 = r1;
            r1 = r4;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0028 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void execute() {
            /*
                r5 = this;
                com.squareup.okhttp.internal.spdy.ErrorCode r0 = com.squareup.okhttp.internal.spdy.ErrorCode.INTERNAL_ERROR
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                boolean r1 = r1.client     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                if (r1 != 0) goto L_0x000f
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                com.squareup.okhttp.internal.spdy.FrameReader r1 = r1.frameReader     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                r1.readConnectionHeader()     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
            L_0x000f:
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                com.squareup.okhttp.internal.spdy.FrameReader r1 = r1.frameReader     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                boolean r1 = r1.nextFrame(r5)     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                if (r1 == 0) goto L_0x001a
                goto L_0x000f
            L_0x001a:
                com.squareup.okhttp.internal.spdy.ErrorCode r1 = com.squareup.okhttp.internal.spdy.ErrorCode.NO_ERROR     // Catch:{ IOException -> 0x0027, all -> 0x0024 }
                com.squareup.okhttp.internal.spdy.ErrorCode r0 = com.squareup.okhttp.internal.spdy.ErrorCode.CANCEL     // Catch:{ IOException -> 0x0028 }
            L_0x001e:
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ IOException -> 0x002d }
                r2.close(r1, r0)     // Catch:{ IOException -> 0x002d }
                goto L_0x002d
            L_0x0024:
                r1 = move-exception
                r2 = r0
                goto L_0x0032
            L_0x0027:
                r1 = r0
            L_0x0028:
                com.squareup.okhttp.internal.spdy.ErrorCode r1 = com.squareup.okhttp.internal.spdy.ErrorCode.PROTOCOL_ERROR     // Catch:{ all -> 0x002e }
                com.squareup.okhttp.internal.spdy.ErrorCode r0 = com.squareup.okhttp.internal.spdy.ErrorCode.PROTOCOL_ERROR     // Catch:{ all -> 0x002e }
                goto L_0x001e
            L_0x002d:
                return
            L_0x002e:
                r2 = move-exception
                r4 = r2
                r2 = r1
                r1 = r4
            L_0x0032:
                com.squareup.okhttp.internal.spdy.SpdyConnection r3 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ IOException -> 0x0037 }
                r3.close(r2, r0)     // Catch:{ IOException -> 0x0037 }
            L_0x0037:
                goto L_0x0039
            L_0x0038:
                throw r1
            L_0x0039:
                goto L_0x0038
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyConnection.Reader.execute():void");
        }

        public void goAway(int i, ErrorCode errorCode, ByteString byteString) {
            byteString.size();
            synchronized (SpdyConnection.this) {
                boolean unused = SpdyConnection.this.shutdown = true;
                Iterator it = SpdyConnection.this.streams.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry entry = (Map.Entry) it.next();
                    if (((Integer) entry.getKey()).intValue() > i && ((SpdyStream) entry.getValue()).isLocallyInitiated()) {
                        ((SpdyStream) entry.getValue()).receiveRstStream(ErrorCode.REFUSED_STREAM);
                        it.remove();
                    }
                }
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:31:0x0099, code lost:
            if (r20.failIfStreamPresent() == false) goto L_0x00a6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x009b, code lost:
            r2.closeLater(com.squareup.okhttp.internal.spdy.ErrorCode.PROTOCOL_ERROR);
            r1.this$0.removeStream(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x00a5, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:34:0x00a6, code lost:
            r2.receiveHeaders(r8, r20);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x00ab, code lost:
            if (r0 == false) goto L_?;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x00ad, code lost:
            r2.receiveFin();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:44:?, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:45:?, code lost:
            return;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void headers(boolean r14, boolean r15, int r16, int r17, int r18, java.util.List<com.squareup.okhttp.internal.spdy.Header> r19, com.squareup.okhttp.internal.spdy.HeadersMode r20) {
            /*
                r13 = this;
                r1 = r13
                r0 = r15
                r9 = r16
                r8 = r19
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = com.squareup.okhttp.internal.spdy.SpdyConnection.this
                boolean r2 = r2.pushedStream(r9)
                if (r2 == 0) goto L_0x0014
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = com.squareup.okhttp.internal.spdy.SpdyConnection.this
                r2.pushHeadersLater(r9, r8, r15)
                return
            L_0x0014:
                com.squareup.okhttp.internal.spdy.SpdyConnection r10 = com.squareup.okhttp.internal.spdy.SpdyConnection.this
                monitor-enter(r10)
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                boolean r2 = r2.shutdown     // Catch:{ all -> 0x00b1 }
                if (r2 == 0) goto L_0x0021
                monitor-exit(r10)     // Catch:{ all -> 0x00b1 }
                return
            L_0x0021:
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyStream r2 = r2.getStream(r9)     // Catch:{ all -> 0x00b1 }
                if (r2 != 0) goto L_0x0094
                boolean r2 = r20.failIfStreamAbsent()     // Catch:{ all -> 0x00b1 }
                if (r2 == 0) goto L_0x0038
                com.squareup.okhttp.internal.spdy.SpdyConnection r0 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.ErrorCode r2 = com.squareup.okhttp.internal.spdy.ErrorCode.INVALID_STREAM     // Catch:{ all -> 0x00b1 }
                r0.writeSynResetLater(r9, r2)     // Catch:{ all -> 0x00b1 }
                monitor-exit(r10)     // Catch:{ all -> 0x00b1 }
                return
            L_0x0038:
                com.squareup.okhttp.internal.spdy.SpdyConnection r2 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                int r2 = r2.lastGoodStreamId     // Catch:{ all -> 0x00b1 }
                if (r9 > r2) goto L_0x0042
                monitor-exit(r10)     // Catch:{ all -> 0x00b1 }
                return
            L_0x0042:
                int r2 = r9 % 2
                com.squareup.okhttp.internal.spdy.SpdyConnection r3 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                int r3 = r3.nextStreamId     // Catch:{ all -> 0x00b1 }
                r11 = 2
                int r3 = r3 % r11
                if (r2 != r3) goto L_0x0050
                monitor-exit(r10)     // Catch:{ all -> 0x00b1 }
                return
            L_0x0050:
                com.squareup.okhttp.internal.spdy.SpdyStream r12 = new com.squareup.okhttp.internal.spdy.SpdyStream     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r4 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                r2 = r12
                r3 = r16
                r5 = r14
                r6 = r15
                r7 = r18
                r8 = r19
                r2.<init>(r3, r4, r5, r6, r7, r8)     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r0 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                int unused = r0.lastGoodStreamId = r9     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r0 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                java.util.Map r0 = r0.streams     // Catch:{ all -> 0x00b1 }
                java.lang.Integer r2 = java.lang.Integer.valueOf(r16)     // Catch:{ all -> 0x00b1 }
                r0.put(r2, r12)     // Catch:{ all -> 0x00b1 }
                java.util.concurrent.ExecutorService r0 = com.squareup.okhttp.internal.spdy.SpdyConnection.executor     // Catch:{ all -> 0x00b1 }
                com.squareup.okhttp.internal.spdy.SpdyConnection$Reader$1 r2 = new com.squareup.okhttp.internal.spdy.SpdyConnection$Reader$1     // Catch:{ all -> 0x00b1 }
                java.lang.String r3 = "OkHttp %s stream %d"
                java.lang.Object[] r4 = new java.lang.Object[r11]     // Catch:{ all -> 0x00b1 }
                r5 = 0
                com.squareup.okhttp.internal.spdy.SpdyConnection r6 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00b1 }
                java.lang.String r6 = r6.hostName     // Catch:{ all -> 0x00b1 }
                r4[r5] = r6     // Catch:{ all -> 0x00b1 }
                r5 = 1
                java.lang.Integer r6 = java.lang.Integer.valueOf(r16)     // Catch:{ all -> 0x00b1 }
                r4[r5] = r6     // Catch:{ all -> 0x00b1 }
                r2.<init>(r3, r4, r12)     // Catch:{ all -> 0x00b1 }
                r0.submit(r2)     // Catch:{ all -> 0x00b1 }
                monitor-exit(r10)     // Catch:{ all -> 0x00b1 }
                return
            L_0x0094:
                monitor-exit(r10)     // Catch:{ all -> 0x00b1 }
                boolean r3 = r20.failIfStreamPresent()
                if (r3 == 0) goto L_0x00a6
                com.squareup.okhttp.internal.spdy.ErrorCode r0 = com.squareup.okhttp.internal.spdy.ErrorCode.PROTOCOL_ERROR
                r2.closeLater(r0)
                com.squareup.okhttp.internal.spdy.SpdyConnection r0 = com.squareup.okhttp.internal.spdy.SpdyConnection.this
                r0.removeStream(r9)
                return
            L_0x00a6:
                r3 = r20
                r2.receiveHeaders(r8, r3)
                if (r0 == 0) goto L_0x00b0
                r2.receiveFin()
            L_0x00b0:
                return
            L_0x00b1:
                r0 = move-exception
                monitor-exit(r10)     // Catch:{ all -> 0x00b1 }
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyConnection.Reader.headers(boolean, boolean, int, int, int, java.util.List, com.squareup.okhttp.internal.spdy.HeadersMode):void");
        }

        public void ping(boolean z, int i, int i2) {
            if (z) {
                Ping access$2300 = SpdyConnection.this.removePing(i);
                if (access$2300 != null) {
                    access$2300.receive();
                    return;
                }
                return;
            }
            SpdyConnection.this.writePingLater(true, i, i2, (Ping) null);
        }

        public void priority(int i, int i2) {
        }

        public void pushPromise(int i, int i2, List<Header> list) {
            SpdyConnection.this.pushRequestLater(i2, list);
        }

        public void rstStream(int i, ErrorCode errorCode) {
            if (SpdyConnection.this.pushedStream(i)) {
                SpdyConnection.this.pushResetLater(i, errorCode);
                return;
            }
            SpdyStream removeStream = SpdyConnection.this.removeStream(i);
            if (removeStream != null) {
                removeStream.receiveRstStream(errorCode);
            }
        }

        /* JADX WARNING: type inference failed for: r1v14, types: [java.lang.Object[]] */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void settings(boolean r7, com.squareup.okhttp.internal.spdy.Settings r8) {
            /*
                r6 = this;
                com.squareup.okhttp.internal.spdy.SpdyConnection r0 = com.squareup.okhttp.internal.spdy.SpdyConnection.this
                monitor-enter(r0)
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.Settings r1 = r1.peerSettings     // Catch:{ all -> 0x00a5 }
                r2 = 65536(0x10000, float:9.18355E-41)
                int r1 = r1.getInitialWindowSize(r2)     // Catch:{ all -> 0x00a5 }
                if (r7 == 0) goto L_0x0016
                com.squareup.okhttp.internal.spdy.SpdyConnection r7 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.Settings r7 = r7.peerSettings     // Catch:{ all -> 0x00a5 }
                r7.clear()     // Catch:{ all -> 0x00a5 }
            L_0x0016:
                com.squareup.okhttp.internal.spdy.SpdyConnection r7 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.Settings r7 = r7.peerSettings     // Catch:{ all -> 0x00a5 }
                r7.merge(r8)     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r7 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.Protocol r7 = r7.getProtocol()     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.Protocol r8 = com.squareup.okhttp.Protocol.HTTP_2     // Catch:{ all -> 0x00a5 }
                if (r7 != r8) goto L_0x002a
                r6.ackSettingsLater()     // Catch:{ all -> 0x00a5 }
            L_0x002a:
                com.squareup.okhttp.internal.spdy.SpdyConnection r7 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.Settings r7 = r7.peerSettings     // Catch:{ all -> 0x00a5 }
                int r7 = r7.getInitialWindowSize(r2)     // Catch:{ all -> 0x00a5 }
                r8 = -1
                r2 = 0
                r4 = 0
                if (r7 == r8) goto L_0x0079
                if (r7 == r1) goto L_0x0079
                int r7 = r7 - r1
                long r7 = (long) r7     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                boolean r1 = r1.receivedInitialPeerSettings     // Catch:{ all -> 0x00a5 }
                if (r1 != 0) goto L_0x004f
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                r1.addBytesToWriteWindow(r7)     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                r5 = 1
                boolean unused = r1.receivedInitialPeerSettings = r5     // Catch:{ all -> 0x00a5 }
            L_0x004f:
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                java.util.Map r1 = r1.streams     // Catch:{ all -> 0x00a5 }
                boolean r1 = r1.isEmpty()     // Catch:{ all -> 0x00a5 }
                if (r1 != 0) goto L_0x007a
                com.squareup.okhttp.internal.spdy.SpdyConnection r1 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                java.util.Map r1 = r1.streams     // Catch:{ all -> 0x00a5 }
                java.util.Collection r1 = r1.values()     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.SpdyConnection r4 = com.squareup.okhttp.internal.spdy.SpdyConnection.this     // Catch:{ all -> 0x00a5 }
                java.util.Map r4 = r4.streams     // Catch:{ all -> 0x00a5 }
                int r4 = r4.size()     // Catch:{ all -> 0x00a5 }
                com.squareup.okhttp.internal.spdy.SpdyStream[] r4 = new com.squareup.okhttp.internal.spdy.SpdyStream[r4]     // Catch:{ all -> 0x00a5 }
                java.lang.Object[] r1 = r1.toArray(r4)     // Catch:{ all -> 0x00a5 }
                r4 = r1
                com.squareup.okhttp.internal.spdy.SpdyStream[] r4 = (com.squareup.okhttp.internal.spdy.SpdyStream[]) r4     // Catch:{ all -> 0x00a5 }
                goto L_0x007a
            L_0x0079:
                r7 = r2
            L_0x007a:
                monitor-exit(r0)     // Catch:{ all -> 0x00a5 }
                if (r4 == 0) goto L_0x00a4
                int r0 = (r7 > r2 ? 1 : (r7 == r2 ? 0 : -1))
                if (r0 == 0) goto L_0x00a4
                com.squareup.okhttp.internal.spdy.SpdyConnection r0 = com.squareup.okhttp.internal.spdy.SpdyConnection.this
                java.util.Map r0 = r0.streams
                java.util.Collection r0 = r0.values()
                java.util.Iterator r0 = r0.iterator()
            L_0x008f:
                boolean r1 = r0.hasNext()
                if (r1 == 0) goto L_0x00a4
                java.lang.Object r1 = r0.next()
                com.squareup.okhttp.internal.spdy.SpdyStream r1 = (com.squareup.okhttp.internal.spdy.SpdyStream) r1
                monitor-enter(r1)
                r1.addBytesToWriteWindow(r7)     // Catch:{ all -> 0x00a1 }
                monitor-exit(r1)     // Catch:{ all -> 0x00a1 }
                goto L_0x008f
            L_0x00a1:
                r7 = move-exception
                monitor-exit(r1)     // Catch:{ all -> 0x00a1 }
                throw r7
            L_0x00a4:
                return
            L_0x00a5:
                r7 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x00a5 }
                goto L_0x00a9
            L_0x00a8:
                throw r7
            L_0x00a9:
                goto L_0x00a8
            */
            throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyConnection.Reader.settings(boolean, com.squareup.okhttp.internal.spdy.Settings):void");
        }

        public void windowUpdate(int i, long j) {
            if (i == 0) {
                synchronized (SpdyConnection.this) {
                    SpdyConnection.this.bytesLeftInWriteWindow += j;
                    SpdyConnection.this.notifyAll();
                }
                return;
            }
            SpdyStream stream = SpdyConnection.this.getStream(i);
            if (stream != null) {
                synchronized (stream) {
                    stream.addBytesToWriteWindow(j);
                }
            }
        }
    }

    private SpdyConnection(Builder builder) {
        Variant variant;
        this.streams = new HashMap();
        this.idleStartTimeNs = System.nanoTime();
        this.unacknowledgedBytesRead = 0;
        this.okHttpSettings = new Settings();
        this.peerSettings = new Settings();
        this.receivedInitialPeerSettings = false;
        this.currentPushRequests = new LinkedHashSet();
        this.protocol = builder.protocol;
        this.pushObserver = builder.pushObserver;
        this.client = builder.client;
        this.handler = builder.handler;
        int i = 1;
        this.nextStreamId = builder.client ? 1 : 2;
        this.nextPingId = !builder.client ? 2 : i;
        if (builder.client) {
            this.okHttpSettings.set(7, 0, 16777216);
        }
        this.hostName = builder.hostName;
        Protocol protocol2 = this.protocol;
        if (protocol2 == Protocol.HTTP_2) {
            variant = new Http20Draft09();
        } else if (protocol2 == Protocol.SPDY_3) {
            variant = new Spdy3();
        } else {
            throw new AssertionError(protocol2);
        }
        this.bytesLeftInWriteWindow = (long) this.peerSettings.getInitialWindowSize(65536);
        this.frameReader = variant.newReader(builder.source, this.client);
        this.frameWriter = variant.newWriter(builder.sink, this.client);
        this.maxFrameSize = (long) variant.maxFrameSize();
        this.readerRunnable = new Reader();
        new Thread(this.readerRunnable).start();
    }

    /* access modifiers changed from: private */
    public void close(ErrorCode errorCode, ErrorCode errorCode2) {
        int i;
        SpdyStream[] spdyStreamArr;
        Ping[] pingArr = null;
        try {
            shutdown(errorCode);
            e = null;
        } catch (IOException e) {
            e = e;
        }
        synchronized (this) {
            if (!this.streams.isEmpty()) {
                spdyStreamArr = (SpdyStream[]) this.streams.values().toArray(new SpdyStream[this.streams.size()]);
                this.streams.clear();
                setIdle(false);
            } else {
                spdyStreamArr = null;
            }
            if (this.pings != null) {
                this.pings = null;
                pingArr = (Ping[]) this.pings.values().toArray(new Ping[this.pings.size()]);
            }
        }
        if (spdyStreamArr != null) {
            IOException iOException = e;
            for (SpdyStream close : spdyStreamArr) {
                try {
                    close.close(errorCode2);
                } catch (IOException e2) {
                    if (iOException != null) {
                        iOException = e2;
                    }
                }
            }
            e = iOException;
        }
        if (pingArr != null) {
            for (Ping cancel : pingArr) {
                cancel.cancel();
            }
        }
        try {
            this.frameReader.close();
        } catch (IOException e3) {
            e = e3;
        }
        try {
            this.frameWriter.close();
        } catch (IOException e4) {
            if (e == null) {
                e = e4;
            }
        }
        if (e != null) {
            throw e;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x003c, code lost:
        if (r0 != 0) goto L_0x004b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0040, code lost:
        r2 = r1;
        r1 = r13;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
        r8.frameWriter.synStream(r10, r11, r12, r18, -1, 0, r19);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x004b, code lost:
        r2 = r1;
        r1 = r13;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x004f, code lost:
        if (r8.client != false) goto L_0x0061;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0051, code lost:
        r8.frameWriter.pushPromise(r0, r12, r19);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0058, code lost:
        monitor-exit(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0059, code lost:
        if (r20 != false) goto L_0x0060;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x005b, code lost:
        r8.frameWriter.flush();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0060, code lost:
        return r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0068, code lost:
        throw new java.lang.IllegalArgumentException("client streams shouldn't have associated stream IDs");
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.squareup.okhttp.internal.spdy.SpdyStream newStream(int r18, java.util.List<com.squareup.okhttp.internal.spdy.Header> r19, boolean r20, boolean r21) {
        /*
            r17 = this;
            r8 = r17
            r0 = r18
            r10 = r20 ^ 1
            r11 = r21 ^ 1
            r14 = -1
            r15 = 0
            com.squareup.okhttp.internal.spdy.FrameWriter r13 = r8.frameWriter
            monitor-enter(r13)
            monitor-enter(r17)     // Catch:{ all -> 0x0078 }
            boolean r1 = r8.shutdown     // Catch:{ all -> 0x0072 }
            if (r1 != 0) goto L_0x0069
            int r12 = r8.nextStreamId     // Catch:{ all -> 0x0072 }
            int r1 = r8.nextStreamId     // Catch:{ all -> 0x0072 }
            int r1 = r1 + 2
            r8.nextStreamId = r1     // Catch:{ all -> 0x0072 }
            com.squareup.okhttp.internal.spdy.SpdyStream r9 = new com.squareup.okhttp.internal.spdy.SpdyStream     // Catch:{ all -> 0x0072 }
            r6 = -1
            r1 = r9
            r2 = r12
            r3 = r17
            r4 = r10
            r5 = r11
            r7 = r19
            r1.<init>(r2, r3, r4, r5, r6, r7)     // Catch:{ all -> 0x0072 }
            boolean r1 = r9.isOpen()     // Catch:{ all -> 0x0072 }
            if (r1 == 0) goto L_0x003b
            java.util.Map<java.lang.Integer, com.squareup.okhttp.internal.spdy.SpdyStream> r1 = r8.streams     // Catch:{ all -> 0x0072 }
            java.lang.Integer r2 = java.lang.Integer.valueOf(r12)     // Catch:{ all -> 0x0072 }
            r1.put(r2, r9)     // Catch:{ all -> 0x0072 }
            r1 = 0
            r8.setIdle(r1)     // Catch:{ all -> 0x0072 }
        L_0x003b:
            monitor-exit(r17)     // Catch:{ all -> 0x0072 }
            if (r0 != 0) goto L_0x004b
            com.squareup.okhttp.internal.spdy.FrameWriter r1 = r8.frameWriter     // Catch:{ all -> 0x0078 }
            r2 = r9
            r9 = r1
            r1 = r13
            r13 = r18
            r16 = r19
            r9.synStream(r10, r11, r12, r13, r14, r15, r16)     // Catch:{ all -> 0x007c }
            goto L_0x0058
        L_0x004b:
            r2 = r9
            r1 = r13
            boolean r3 = r8.client     // Catch:{ all -> 0x007c }
            if (r3 != 0) goto L_0x0061
            com.squareup.okhttp.internal.spdy.FrameWriter r3 = r8.frameWriter     // Catch:{ all -> 0x007c }
            r4 = r19
            r3.pushPromise(r0, r12, r4)     // Catch:{ all -> 0x007c }
        L_0x0058:
            monitor-exit(r1)     // Catch:{ all -> 0x007c }
            if (r20 != 0) goto L_0x0060
            com.squareup.okhttp.internal.spdy.FrameWriter r0 = r8.frameWriter
            r0.flush()
        L_0x0060:
            return r2
        L_0x0061:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x007c }
            java.lang.String r2 = "client streams shouldn't have associated stream IDs"
            r0.<init>(r2)     // Catch:{ all -> 0x007c }
            throw r0     // Catch:{ all -> 0x007c }
        L_0x0069:
            r1 = r13
            java.io.IOException r0 = new java.io.IOException     // Catch:{ all -> 0x0076 }
            java.lang.String r2 = "shutdown"
            r0.<init>(r2)     // Catch:{ all -> 0x0076 }
            throw r0     // Catch:{ all -> 0x0076 }
        L_0x0072:
            r0 = move-exception
            r1 = r13
        L_0x0074:
            monitor-exit(r17)     // Catch:{ all -> 0x0076 }
            throw r0     // Catch:{ all -> 0x007c }
        L_0x0076:
            r0 = move-exception
            goto L_0x0074
        L_0x0078:
            r0 = move-exception
            r1 = r13
        L_0x007a:
            monitor-exit(r1)     // Catch:{ all -> 0x007c }
            throw r0
        L_0x007c:
            r0 = move-exception
            goto L_0x007a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyConnection.newStream(int, java.util.List, boolean, boolean):com.squareup.okhttp.internal.spdy.SpdyStream");
    }

    /* access modifiers changed from: private */
    public void pushDataLater(int i, BufferedSource bufferedSource, int i2, boolean z) {
        final OkBuffer okBuffer = new OkBuffer();
        long j = (long) i2;
        bufferedSource.require(j);
        bufferedSource.read(okBuffer, j);
        if (okBuffer.size() == j) {
            final int i3 = i;
            final int i4 = i2;
            final boolean z2 = z;
            executor.submit(new NamedRunnable("OkHttp %s Push Data[%s]", new Object[]{this.hostName, Integer.valueOf(i)}) {
                public void execute() {
                    try {
                        boolean onData = SpdyConnection.this.pushObserver.onData(i3, okBuffer, i4, z2);
                        if (onData) {
                            SpdyConnection.this.frameWriter.rstStream(i3, ErrorCode.CANCEL);
                        }
                        if (onData || z2) {
                            synchronized (SpdyConnection.this) {
                                SpdyConnection.this.currentPushRequests.remove(Integer.valueOf(i3));
                            }
                        }
                    } catch (IOException unused) {
                    }
                }
            });
            return;
        }
        throw new IOException(okBuffer.size() + " != " + i2);
    }

    /* access modifiers changed from: private */
    public void pushHeadersLater(int i, List<Header> list, boolean z) {
        final int i2 = i;
        final List<Header> list2 = list;
        final boolean z2 = z;
        executor.submit(new NamedRunnable("OkHttp %s Push Headers[%s]", new Object[]{this.hostName, Integer.valueOf(i)}) {
            public void execute() {
                boolean onHeaders = SpdyConnection.this.pushObserver.onHeaders(i2, list2, z2);
                if (onHeaders) {
                    try {
                        SpdyConnection.this.frameWriter.rstStream(i2, ErrorCode.CANCEL);
                    } catch (IOException unused) {
                        return;
                    }
                }
                if (onHeaders || z2) {
                    synchronized (SpdyConnection.this) {
                        SpdyConnection.this.currentPushRequests.remove(Integer.valueOf(i2));
                    }
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public void pushRequestLater(int i, List<Header> list) {
        synchronized (this) {
            if (this.currentPushRequests.contains(Integer.valueOf(i))) {
                writeSynResetLater(i, ErrorCode.PROTOCOL_ERROR);
                return;
            }
            this.currentPushRequests.add(Integer.valueOf(i));
            final int i2 = i;
            final List<Header> list2 = list;
            executor.submit(new NamedRunnable("OkHttp %s Push Request[%s]", new Object[]{this.hostName, Integer.valueOf(i)}) {
                public void execute() {
                    if (SpdyConnection.this.pushObserver.onRequest(i2, list2)) {
                        try {
                            SpdyConnection.this.frameWriter.rstStream(i2, ErrorCode.CANCEL);
                            synchronized (SpdyConnection.this) {
                                SpdyConnection.this.currentPushRequests.remove(Integer.valueOf(i2));
                            }
                        } catch (IOException unused) {
                        }
                    }
                }
            });
        }
    }

    /* access modifiers changed from: private */
    public void pushResetLater(int i, ErrorCode errorCode) {
        final int i2 = i;
        final ErrorCode errorCode2 = errorCode;
        executor.submit(new NamedRunnable("OkHttp %s Push Reset[%s]", new Object[]{this.hostName, Integer.valueOf(i)}) {
            public void execute() {
                SpdyConnection.this.pushObserver.onReset(i2, errorCode2);
                synchronized (SpdyConnection.this) {
                    SpdyConnection.this.currentPushRequests.remove(Integer.valueOf(i2));
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public boolean pushedStream(int i) {
        return this.protocol == Protocol.HTTP_2 && i != 0 && (i & 1) == 0;
    }

    /* access modifiers changed from: private */
    public synchronized Ping removePing(int i) {
        return this.pings != null ? this.pings.remove(Integer.valueOf(i)) : null;
    }

    private synchronized void setIdle(boolean z) {
        long j;
        if (z) {
            try {
                j = System.nanoTime();
            } catch (Throwable th) {
                throw th;
            }
        } else {
            j = Long.MAX_VALUE;
        }
        this.idleStartTimeNs = j;
    }

    /* access modifiers changed from: private */
    public void writePing(boolean z, int i, int i2, Ping ping) {
        synchronized (this.frameWriter) {
            if (ping != null) {
                ping.send();
            }
            this.frameWriter.ping(z, i, i2);
        }
    }

    /* access modifiers changed from: private */
    public void writePingLater(boolean z, int i, int i2, Ping ping) {
        final boolean z2 = z;
        final int i3 = i;
        final int i4 = i2;
        final Ping ping2 = ping;
        executor.submit(new NamedRunnable("OkHttp %s ping %08x%08x", new Object[]{this.hostName, Integer.valueOf(i), Integer.valueOf(i2)}) {
            public void execute() {
                try {
                    SpdyConnection.this.writePing(z2, i3, i4, ping2);
                } catch (IOException unused) {
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    public void addBytesToWriteWindow(long j) {
        this.bytesLeftInWriteWindow += j;
        if (j > 0) {
            notifyAll();
        }
    }

    public void close() {
        close(ErrorCode.NO_ERROR, ErrorCode.CANCEL);
    }

    public void flush() {
        this.frameWriter.flush();
    }

    public synchronized long getIdleStartTimeNs() {
        return this.idleStartTimeNs;
    }

    public Protocol getProtocol() {
        return this.protocol;
    }

    /* access modifiers changed from: package-private */
    public synchronized SpdyStream getStream(int i) {
        return this.streams.get(Integer.valueOf(i));
    }

    public synchronized boolean isIdle() {
        return this.idleStartTimeNs != Long.MAX_VALUE;
    }

    public SpdyStream newStream(List<Header> list, boolean z, boolean z2) {
        return newStream(0, list, z, z2);
    }

    public synchronized int openStreamCount() {
        return this.streams.size();
    }

    public Ping ping() {
        int i;
        Ping ping = new Ping();
        synchronized (this) {
            if (!this.shutdown) {
                i = this.nextPingId;
                this.nextPingId += 2;
                if (this.pings == null) {
                    this.pings = new HashMap();
                }
                this.pings.put(Integer.valueOf(i), ping);
            } else {
                throw new IOException("shutdown");
            }
        }
        writePing(false, i, 1330343787, ping);
        return ping;
    }

    public SpdyStream pushStream(int i, List<Header> list, boolean z) {
        if (this.client) {
            throw new IllegalStateException("Client cannot push requests.");
        } else if (this.protocol == Protocol.HTTP_2) {
            return newStream(i, list, z, false);
        } else {
            throw new IllegalStateException("protocol != HTTP_2");
        }
    }

    /* access modifiers changed from: package-private */
    public synchronized SpdyStream removeStream(int i) {
        SpdyStream remove;
        remove = this.streams.remove(Integer.valueOf(i));
        if (remove != null && this.streams.isEmpty()) {
            setIdle(true);
        }
        return remove;
    }

    public void sendConnectionHeader() {
        this.frameWriter.connectionHeader();
        this.frameWriter.settings(this.okHttpSettings);
    }

    public void shutdown(ErrorCode errorCode) {
        synchronized (this.frameWriter) {
            synchronized (this) {
                if (!this.shutdown) {
                    this.shutdown = true;
                    int i = this.lastGoodStreamId;
                    this.frameWriter.goAway(i, errorCode, Util.EMPTY_BYTE_ARRAY);
                }
            }
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:22|23|24) */
    /* JADX WARNING: Code restructure failed: missing block: B:12:?, code lost:
        r4 = (int) java.lang.Math.min(java.lang.Math.min(r13, r9.bytesLeftInWriteWindow), r9.maxFrameSize);
        r7 = (long) r4;
        r9.bytesLeftInWriteWindow -= r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0047, code lost:
        throw new java.io.InterruptedIOException();
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:22:0x0042 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void writeData(int r10, boolean r11, com.squareup.okhttp.internal.okio.OkBuffer r12, long r13) {
        /*
            r9 = this;
            r0 = 0
            r1 = 0
            int r3 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1))
            if (r3 != 0) goto L_0x000d
            com.squareup.okhttp.internal.spdy.FrameWriter r13 = r9.frameWriter
            r13.data(r11, r10, r12, r0)
            return
        L_0x000d:
            int r3 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1))
            if (r3 <= 0) goto L_0x004a
            monitor-enter(r9)
        L_0x0012:
            long r3 = r9.bytesLeftInWriteWindow     // Catch:{ InterruptedException -> 0x0042 }
            int r5 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r5 > 0) goto L_0x001c
            r9.wait()     // Catch:{ InterruptedException -> 0x0042 }
            goto L_0x0012
        L_0x001c:
            long r3 = r9.bytesLeftInWriteWindow     // Catch:{ all -> 0x0040 }
            long r3 = java.lang.Math.min(r13, r3)     // Catch:{ all -> 0x0040 }
            long r5 = r9.maxFrameSize     // Catch:{ all -> 0x0040 }
            long r3 = java.lang.Math.min(r3, r5)     // Catch:{ all -> 0x0040 }
            int r4 = (int) r3     // Catch:{ all -> 0x0040 }
            long r5 = r9.bytesLeftInWriteWindow     // Catch:{ all -> 0x0040 }
            long r7 = (long) r4     // Catch:{ all -> 0x0040 }
            long r5 = r5 - r7
            r9.bytesLeftInWriteWindow = r5     // Catch:{ all -> 0x0040 }
            monitor-exit(r9)     // Catch:{ all -> 0x0040 }
            long r13 = r13 - r7
            com.squareup.okhttp.internal.spdy.FrameWriter r3 = r9.frameWriter
            if (r11 == 0) goto L_0x003b
            int r5 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1))
            if (r5 != 0) goto L_0x003b
            r5 = 1
            goto L_0x003c
        L_0x003b:
            r5 = 0
        L_0x003c:
            r3.data(r5, r10, r12, r4)
            goto L_0x000d
        L_0x0040:
            r10 = move-exception
            goto L_0x0048
        L_0x0042:
            java.io.InterruptedIOException r10 = new java.io.InterruptedIOException     // Catch:{ all -> 0x0040 }
            r10.<init>()     // Catch:{ all -> 0x0040 }
            throw r10     // Catch:{ all -> 0x0040 }
        L_0x0048:
            monitor-exit(r9)     // Catch:{ all -> 0x0040 }
            throw r10
        L_0x004a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.spdy.SpdyConnection.writeData(int, boolean, com.squareup.okhttp.internal.okio.OkBuffer, long):void");
    }

    /* access modifiers changed from: package-private */
    public void writeSynReply(int i, boolean z, List<Header> list) {
        this.frameWriter.synReply(z, i, list);
    }

    /* access modifiers changed from: package-private */
    public void writeSynReset(int i, ErrorCode errorCode) {
        this.frameWriter.rstStream(i, errorCode);
    }

    /* access modifiers changed from: package-private */
    public void writeSynResetLater(int i, ErrorCode errorCode) {
        final int i2 = i;
        final ErrorCode errorCode2 = errorCode;
        executor.submit(new NamedRunnable("OkHttp %s stream %d", new Object[]{this.hostName, Integer.valueOf(i)}) {
            public void execute() {
                try {
                    SpdyConnection.this.writeSynReset(i2, errorCode2);
                } catch (IOException unused) {
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    public void writeWindowUpdateLater(int i, long j) {
        final int i2 = i;
        final long j2 = j;
        executor.submit(new NamedRunnable("OkHttp Window Update %s stream %d", new Object[]{this.hostName, Integer.valueOf(i)}) {
            public void execute() {
                try {
                    SpdyConnection.this.frameWriter.windowUpdate(i2, j2);
                } catch (IOException unused) {
                }
            }
        });
    }
}
