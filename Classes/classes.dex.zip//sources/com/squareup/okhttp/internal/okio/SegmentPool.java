package com.squareup.okhttp.internal.okio;

final class SegmentPool {
    static final SegmentPool INSTANCE = new SegmentPool();
    static final long MAX_SIZE = 65536;
    long byteCount;
    private Segment next;

    private SegmentPool() {
    }

    /* access modifiers changed from: package-private */
    public void recycle(Segment segment) {
        if (segment.next == null && segment.prev == null) {
            synchronized (this) {
                if (this.byteCount + 2048 <= MAX_SIZE) {
                    this.byteCount += 2048;
                    segment.next = this.next;
                    segment.limit = 0;
                    segment.pos = 0;
                    this.next = segment;
                    return;
                }
                return;
            }
        }
        throw new IllegalArgumentException();
    }

    /* access modifiers changed from: package-private */
    public Segment take() {
        synchronized (this) {
            if (this.next == null) {
                return new Segment();
            }
            Segment segment = this.next;
            this.next = segment.next;
            segment.next = null;
            this.byteCount -= 2048;
            return segment;
        }
    }
}
