package com.squareup.okhttp.internal;

import com.squareup.okhttp.Protocol;
import com.squareup.okhttp.internal.okio.ByteString;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import javax.net.ssl.SSLSocket;

public class Platform {
    private static final Platform PLATFORM = findPlatform();
    private Constructor<DeflaterOutputStream> deflaterConstructor;

    private static class Android extends Platform {
        private final Method getNpnSelectedProtocol;
        protected final Class<?> openSslSocketClass;
        private final Method setHostname;
        private final Method setNpnProtocols;
        private final Method setUseSessionTickets;

        private Android(Class<?> cls, Method method, Method method2, Method method3, Method method4) {
            this.openSslSocketClass = cls;
            this.setUseSessionTickets = method;
            this.setHostname = method2;
            this.setNpnProtocols = method3;
            this.getNpnSelectedProtocol = method4;
        }

        public void connectSocket(Socket socket, InetSocketAddress inetSocketAddress, int i) {
            try {
                socket.connect(inetSocketAddress, i);
            } catch (SecurityException e) {
                IOException iOException = new IOException("Exception in connect");
                iOException.initCause(e);
                throw iOException;
            }
        }

        public void enableTlsExtensions(SSLSocket sSLSocket, String str) {
            Platform.super.enableTlsExtensions(sSLSocket, str);
            if (this.openSslSocketClass.isInstance(sSLSocket)) {
                try {
                    this.setUseSessionTickets.invoke(sSLSocket, new Object[]{true});
                    this.setHostname.invoke(sSLSocket, new Object[]{str});
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e2) {
                    throw new AssertionError(e2);
                }
            }
        }

        public ByteString getNpnSelectedProtocol(SSLSocket sSLSocket) {
            if (this.getNpnSelectedProtocol == null || !this.openSslSocketClass.isInstance(sSLSocket)) {
                return null;
            }
            try {
                byte[] bArr = (byte[]) this.getNpnSelectedProtocol.invoke(sSLSocket, new Object[0]);
                if (bArr == null) {
                    return null;
                }
                return ByteString.of(bArr);
            } catch (InvocationTargetException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e2) {
                throw new AssertionError(e2);
            }
        }

        public void setNpnProtocols(SSLSocket sSLSocket, List<Protocol> list) {
            if (this.setNpnProtocols != null && this.openSslSocketClass.isInstance(sSLSocket)) {
                try {
                    this.setNpnProtocols.invoke(sSLSocket, new Object[]{Platform.concatLengthPrefixed(list)});
                } catch (IllegalAccessException e) {
                    throw new AssertionError(e);
                } catch (InvocationTargetException e2) {
                    throw new RuntimeException(e2);
                }
            }
        }
    }

    private static class JdkWithJettyNpnPlatform extends Platform {
        private final Class<?> clientProviderClass;
        private final Method getMethod;
        private final Method putMethod;
        private final Class<?> serverProviderClass;

        public JdkWithJettyNpnPlatform(Method method, Method method2, Class<?> cls, Class<?> cls2) {
            this.putMethod = method;
            this.getMethod = method2;
            this.clientProviderClass = cls;
            this.serverProviderClass = cls2;
        }

        public ByteString getNpnSelectedProtocol(SSLSocket sSLSocket) {
            try {
                JettyNpnProvider jettyNpnProvider = (JettyNpnProvider) Proxy.getInvocationHandler(this.getMethod.invoke((Object) null, new Object[]{sSLSocket}));
                if (!jettyNpnProvider.unsupported && jettyNpnProvider.selected == null) {
                    Logger.getLogger("com.squareup.okhttp.OkHttpClient").log(Level.INFO, "NPN callback dropped so SPDY is disabled. Is npn-boot on the boot class path?");
                    return null;
                } else if (jettyNpnProvider.unsupported) {
                    return null;
                } else {
                    return ByteString.encodeUtf8(jettyNpnProvider.selected);
                }
            } catch (InvocationTargetException unused) {
                throw new AssertionError();
            } catch (IllegalAccessException unused2) {
                throw new AssertionError();
            }
        }

        public void setNpnProtocols(SSLSocket sSLSocket, List<Protocol> list) {
            try {
                ArrayList arrayList = new ArrayList(list.size());
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    arrayList.add(list.get(i).name.utf8());
                }
                Object newProxyInstance = Proxy.newProxyInstance(Platform.class.getClassLoader(), new Class[]{this.clientProviderClass, this.serverProviderClass}, new JettyNpnProvider(arrayList));
                this.putMethod.invoke((Object) null, new Object[]{sSLSocket, newProxyInstance});
            } catch (InvocationTargetException e) {
                throw new AssertionError(e);
            } catch (IllegalAccessException e2) {
                throw new AssertionError(e2);
            }
        }
    }

    private static class JettyNpnProvider implements InvocationHandler {
        private final List<String> protocols;
        /* access modifiers changed from: private */
        public String selected;
        /* access modifiers changed from: private */
        public boolean unsupported;

        public JettyNpnProvider(List<String> list) {
            this.protocols = list;
        }

        public Object invoke(Object obj, Method method, Object[] objArr) {
            Object obj2;
            String name = method.getName();
            Class<?> returnType = method.getReturnType();
            if (objArr == null) {
                objArr = Util.EMPTY_STRING_ARRAY;
            }
            if (name.equals("supports") && Boolean.TYPE == returnType) {
                return true;
            }
            if (name.equals("unsupported") && Void.TYPE == returnType) {
                this.unsupported = true;
                return null;
            } else if (name.equals("protocols") && objArr.length == 0) {
                return this.protocols;
            } else {
                if (name.equals("selectProtocol") && String.class == returnType && objArr.length == 1 && (objArr[0] == null || (objArr[0] instanceof List))) {
                    List list = (List) objArr[0];
                    int size = list.size();
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            obj2 = this.protocols.get(0);
                            break;
                        } else if (this.protocols.contains(list.get(i))) {
                            obj2 = list.get(i);
                            break;
                        } else {
                            i++;
                        }
                    }
                    String str = (String) obj2;
                    this.selected = str;
                    return str;
                } else if (!name.equals("protocolSelected") || objArr.length != 1) {
                    return method.invoke(this, objArr);
                } else {
                    this.selected = (String) objArr[0];
                    return null;
                }
            }
        }
    }

    static byte[] concatLengthPrefixed(List<Protocol> list) {
        int i = 0;
        for (Protocol protocol : list) {
            i += protocol.name.size() + 1;
        }
        byte[] bArr = new byte[i];
        int i2 = 0;
        for (Protocol next : list) {
            int size = next.name.size();
            int i3 = i2 + 1;
            bArr[i2] = (byte) size;
            System.arraycopy(next.name.toByteArray(), 0, bArr, i3, size);
            i2 = i3 + size;
        }
        return bArr;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
        r3 = java.lang.Class.forName("org.eclipse.jetty.npn.NextProtoNego");
        r4 = java.lang.Class.forName("org.eclipse.jetty.npn.NextProtoNego" + "$Provider");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x00b1, code lost:
        return new com.squareup.okhttp.internal.Platform.JdkWithJettyNpnPlatform(r3.getMethod("put", new java.lang.Class[]{javax.net.ssl.SSLSocket.class, r4}), r3.getMethod("get", new java.lang.Class[]{javax.net.ssl.SSLSocket.class}), java.lang.Class.forName("org.eclipse.jetty.npn.NextProtoNego" + "$ClientProvider"), java.lang.Class.forName("org.eclipse.jetty.npn.NextProtoNego" + "$ServerProvider"));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x00b7, code lost:
        return new com.squareup.okhttp.internal.Platform();
     */
    /* JADX WARNING: Removed duplicated region for block: B:23:? A[ExcHandler: NoSuchMethodException (unused java.lang.NoSuchMethodException), SYNTHETIC, Splitter:B:6:0x000c] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static com.squareup.okhttp.internal.Platform findPlatform() {
        /*
            java.lang.String r0 = "com.android.org.conscrypt.OpenSSLSocketImpl"
            r1 = 1
            r2 = 0
            java.lang.Class r0 = java.lang.Class.forName(r0)     // Catch:{ ClassNotFoundException -> 0x000a }
        L_0x0008:
            r4 = r0
            goto L_0x0011
        L_0x000a:
            java.lang.String r0 = "org.apache.harmony.xnet.provider.jsse.OpenSSLSocketImpl"
            java.lang.Class r0 = java.lang.Class.forName(r0)     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            goto L_0x0008
        L_0x0011:
            java.lang.String r0 = "setUseSessionTickets"
            java.lang.Class[] r3 = new java.lang.Class[r1]     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            java.lang.Class r5 = java.lang.Boolean.TYPE     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            r3[r2] = r5     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            java.lang.reflect.Method r5 = r4.getMethod(r0, r3)     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            java.lang.String r0 = "setHostname"
            java.lang.Class[] r3 = new java.lang.Class[r1]     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            java.lang.Class<java.lang.String> r6 = java.lang.String.class
            r3[r2] = r6     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            java.lang.reflect.Method r6 = r4.getMethod(r0, r3)     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            r0 = 0
            java.lang.String r3 = "setNpnProtocols"
            java.lang.Class[] r7 = new java.lang.Class[r1]     // Catch:{ NoSuchMethodException -> 0x003f }
            java.lang.Class<byte[]> r8 = byte[].class
            r7[r2] = r8     // Catch:{ NoSuchMethodException -> 0x003f }
            java.lang.reflect.Method r3 = r4.getMethod(r3, r7)     // Catch:{ NoSuchMethodException -> 0x003f }
            java.lang.String r7 = "getNpnSelectedProtocol"
            java.lang.Class[] r8 = new java.lang.Class[r2]     // Catch:{ NoSuchMethodException -> 0x0040 }
            java.lang.reflect.Method r0 = r4.getMethod(r7, r8)     // Catch:{ NoSuchMethodException -> 0x0040 }
            goto L_0x0040
        L_0x003f:
            r3 = r0
        L_0x0040:
            r8 = r0
            r7 = r3
            com.squareup.okhttp.internal.Platform$Android r0 = new com.squareup.okhttp.internal.Platform$Android     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            r9 = 0
            r3 = r0
            r3.<init>(r4, r5, r6, r7, r8)     // Catch:{ NoSuchMethodException -> 0x004a, NoSuchMethodException -> 0x004a }
            return r0
        L_0x004a:
            java.lang.String r0 = "org.eclipse.jetty.npn.NextProtoNego"
            java.lang.String r3 = "org.eclipse.jetty.npn.NextProtoNego"
            java.lang.Class r3 = java.lang.Class.forName(r3)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r4.<init>()     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r4.append(r0)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r5 = "$Provider"
            r4.append(r5)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r4 = r4.toString()     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.Class r4 = java.lang.Class.forName(r4)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r5.<init>()     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r5.append(r0)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r6 = "$ClientProvider"
            r5.append(r6)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r5 = r5.toString()     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.Class r5 = java.lang.Class.forName(r5)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r6.<init>()     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r6.append(r0)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r0 = "$ServerProvider"
            r6.append(r0)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r0 = r6.toString()     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.Class r0 = java.lang.Class.forName(r0)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r6 = "put"
            r7 = 2
            java.lang.Class[] r7 = new java.lang.Class[r7]     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.Class<javax.net.ssl.SSLSocket> r8 = javax.net.ssl.SSLSocket.class
            r7[r2] = r8     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r7[r1] = r4     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.reflect.Method r4 = r3.getMethod(r6, r7)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.String r6 = "get"
            java.lang.Class[] r1 = new java.lang.Class[r1]     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.Class<javax.net.ssl.SSLSocket> r7 = javax.net.ssl.SSLSocket.class
            r1[r2] = r7     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            java.lang.reflect.Method r1 = r3.getMethod(r6, r1)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            com.squareup.okhttp.internal.Platform$JdkWithJettyNpnPlatform r2 = new com.squareup.okhttp.internal.Platform$JdkWithJettyNpnPlatform     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            r2.<init>(r4, r1, r5, r0)     // Catch:{ ClassNotFoundException | NoSuchMethodException -> 0x00b2 }
            return r2
        L_0x00b2:
            com.squareup.okhttp.internal.Platform r0 = new com.squareup.okhttp.internal.Platform
            r0.<init>()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.Platform.findPlatform():com.squareup.okhttp.internal.Platform");
    }

    public static Platform get() {
        return PLATFORM;
    }

    public void connectSocket(Socket socket, InetSocketAddress inetSocketAddress, int i) {
        socket.connect(inetSocketAddress, i);
    }

    public void enableTlsExtensions(SSLSocket sSLSocket, String str) {
    }

    public ByteString getNpnSelectedProtocol(SSLSocket sSLSocket) {
        return null;
    }

    public String getPrefix() {
        return "OkHttp";
    }

    public void logW(String str) {
        System.out.println(str);
    }

    public OutputStream newDeflaterOutputStream(OutputStream outputStream, Deflater deflater, boolean z) {
        try {
            Constructor<DeflaterOutputStream> constructor = this.deflaterConstructor;
            if (constructor == null) {
                constructor = DeflaterOutputStream.class.getConstructor(new Class[]{OutputStream.class, Deflater.class, Boolean.TYPE});
                this.deflaterConstructor = constructor;
            }
            return constructor.newInstance(new Object[]{outputStream, deflater, Boolean.valueOf(z)});
        } catch (NoSuchMethodException unused) {
            throw new UnsupportedOperationException("Cannot SPDY; no SYNC_FLUSH available");
        } catch (InvocationTargetException e) {
            throw (e.getCause() instanceof RuntimeException ? (RuntimeException) e.getCause() : new RuntimeException(e.getCause()));
        } catch (InstantiationException e2) {
            throw new RuntimeException(e2);
        } catch (IllegalAccessException unused2) {
            throw new AssertionError();
        }
    }

    public void setNpnProtocols(SSLSocket sSLSocket, List<Protocol> list) {
    }

    public void supportTlsIntolerantServer(SSLSocket sSLSocket) {
        sSLSocket.setEnabledProtocols(new String[]{"SSLv3"});
    }

    public void tagSocket(Socket socket) {
    }

    public URI toUriLenient(URL url) {
        return url.toURI();
    }

    public void untagSocket(Socket socket) {
    }
}
