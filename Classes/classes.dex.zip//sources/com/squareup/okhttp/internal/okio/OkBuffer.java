package com.squareup.okhttp.internal.okio;

import java.io.EOFException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class OkBuffer implements BufferedSource, BufferedSink, Cloneable {
    Segment head;
    long size;

    private byte[] readBytes(long j) {
        Util.checkOffsetAndCount(this.size, 0, j);
        if (j <= 2147483647L) {
            int i = 0;
            byte[] bArr = new byte[((int) j)];
            while (true) {
                long j2 = (long) i;
                if (j2 < j) {
                    Segment segment = this.head;
                    int min = (int) Math.min(j - j2, (long) (segment.limit - segment.pos));
                    Segment segment2 = this.head;
                    System.arraycopy(segment2.data, segment2.pos, bArr, i, min);
                    i += min;
                    Segment segment3 = this.head;
                    segment3.pos += min;
                    if (segment3.pos == segment3.limit) {
                        this.head = segment3.pop();
                        SegmentPool.INSTANCE.recycle(segment3);
                    }
                } else {
                    this.size -= j;
                    return bArr;
                }
            }
        } else {
            throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: " + j);
        }
    }

    public OkBuffer buffer() {
        return this;
    }

    public void clear() {
        skip(this.size);
    }

    public OkBuffer clone() {
        OkBuffer okBuffer = new OkBuffer();
        if (size() == 0) {
            return okBuffer;
        }
        Segment segment = this.head;
        byte[] bArr = segment.data;
        int i = segment.pos;
        okBuffer.write(bArr, i, segment.limit - i);
        Segment segment2 = this.head;
        while (true) {
            segment2 = segment2.next;
            if (segment2 == this.head) {
                return okBuffer;
            }
            byte[] bArr2 = segment2.data;
            int i2 = segment2.pos;
            okBuffer.write(bArr2, i2, segment2.limit - i2);
        }
    }

    public void close() {
    }

    public long completeSegmentByteCount() {
        long j = this.size;
        if (j == 0) {
            return 0;
        }
        Segment segment = this.head.prev;
        int i = segment.limit;
        return i < 2048 ? j - ((long) (i - segment.pos)) : j;
    }

    public OkBuffer deadline(Deadline deadline) {
        return this;
    }

    public OkBuffer emitCompleteSegments() {
        return this;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof OkBuffer)) {
            return false;
        }
        OkBuffer okBuffer = (OkBuffer) obj;
        long j = this.size;
        if (j != okBuffer.size) {
            return false;
        }
        long j2 = 0;
        if (j == 0) {
            return true;
        }
        Segment segment = this.head;
        Segment segment2 = okBuffer.head;
        int i = segment.pos;
        int i2 = segment2.pos;
        while (j2 < this.size) {
            long min = (long) Math.min(segment.limit - i, segment2.limit - i2);
            int i3 = i2;
            int i4 = i;
            int i5 = 0;
            while (((long) i5) < min) {
                int i6 = i4 + 1;
                int i7 = i3 + 1;
                if (segment.data[i4] != segment2.data[i3]) {
                    return false;
                }
                i5++;
                i4 = i6;
                i3 = i7;
            }
            if (i4 == segment.limit) {
                segment = segment.next;
                i = segment.pos;
            } else {
                i = i4;
            }
            if (i3 == segment2.limit) {
                segment2 = segment2.next;
                i2 = segment2.pos;
            } else {
                i2 = i3;
            }
            j2 += min;
        }
        return true;
    }

    public boolean exhausted() {
        return this.size == 0;
    }

    public void flush() {
    }

    public byte getByte(long j) {
        Util.checkOffsetAndCount(this.size, j, 1);
        Segment segment = this.head;
        while (true) {
            int i = segment.limit;
            int i2 = segment.pos;
            long j2 = (long) (i - i2);
            if (j < j2) {
                return segment.data[i2 + ((int) j)];
            }
            j -= j2;
            segment = segment.next;
        }
    }

    public int hashCode() {
        Segment segment = this.head;
        if (segment == null) {
            return 0;
        }
        int i = 1;
        do {
            int i2 = segment.limit;
            for (int i3 = segment.pos; i3 < i2; i3++) {
                i = (i * 31) + segment.data[i3];
            }
            segment = segment.next;
        } while (segment != this.head);
        return i;
    }

    public long indexOf(byte b2) {
        return indexOf(b2, 0);
    }

    public long indexOf(byte b2, long j) {
        Segment segment = this.head;
        if (segment == null) {
            return -1;
        }
        long j2 = j;
        long j3 = 0;
        do {
            int i = segment.limit;
            int i2 = segment.pos;
            long j4 = (long) (i - i2);
            if (j2 > j4) {
                j2 -= j4;
                byte b3 = b2;
            } else {
                byte[] bArr = segment.data;
                long j5 = (long) i;
                for (long j6 = ((long) i2) + j2; j6 < j5; j6++) {
                    if (bArr[(int) j6] == b2) {
                        return (j3 + j6) - ((long) segment.pos);
                    }
                }
                byte b4 = b2;
                j2 = 0;
            }
            j3 += j4;
            segment = segment.next;
        } while (segment != this.head);
        return -1;
    }

    public InputStream inputStream() {
        return new InputStream() {
            public int available() {
                return (int) Math.min(OkBuffer.this.size, 2147483647L);
            }

            public void close() {
            }

            public int read() {
                return OkBuffer.this.readByte() & 255;
            }

            public int read(byte[] bArr, int i, int i2) {
                return OkBuffer.this.read(bArr, i, i2);
            }

            public String toString() {
                return OkBuffer.this + ".inputStream()";
            }
        };
    }

    public OutputStream outputStream() {
        return new OutputStream() {
            public void close() {
            }

            public void flush() {
            }

            public String toString() {
                return this + ".outputStream()";
            }

            public void write(int i) {
                OkBuffer.this.writeByte((int) (byte) i);
            }

            public void write(byte[] bArr, int i, int i2) {
                OkBuffer.this.write(bArr, i, i2);
            }
        };
    }

    /* access modifiers changed from: package-private */
    public int read(byte[] bArr, int i, int i2) {
        Segment segment = this.head;
        if (segment == null) {
            return -1;
        }
        int min = Math.min(i2, segment.limit - segment.pos);
        System.arraycopy(segment.data, segment.pos, bArr, i, min);
        segment.pos += min;
        this.size -= (long) min;
        if (segment.pos == segment.limit) {
            this.head = segment.pop();
            SegmentPool.INSTANCE.recycle(segment);
        }
        return min;
    }

    public long read(OkBuffer okBuffer, long j) {
        long j2 = this.size;
        if (j2 == 0) {
            return -1;
        }
        if (j > j2) {
            j = j2;
        }
        okBuffer.write(this, j);
        return j;
    }

    public byte readByte() {
        long j = this.size;
        if (j != 0) {
            Segment segment = this.head;
            int i = segment.pos;
            int i2 = segment.limit;
            int i3 = i + 1;
            byte b2 = segment.data[i];
            this.size = j - 1;
            if (i3 == i2) {
                this.head = segment.pop();
                SegmentPool.INSTANCE.recycle(segment);
            } else {
                segment.pos = i3;
            }
            return b2;
        }
        throw new IllegalStateException("size == 0");
    }

    public ByteString readByteString(long j) {
        return new ByteString(readBytes(j));
    }

    public int readInt() {
        long j = this.size;
        if (j >= 4) {
            Segment segment = this.head;
            int i = segment.pos;
            int i2 = segment.limit;
            if (i2 - i < 4) {
                return ((readByte() & 255) << 24) | ((readByte() & 255) << 16) | ((readByte() & 255) << 8) | (readByte() & 255);
            }
            byte[] bArr = segment.data;
            int i3 = i + 1;
            int i4 = i3 + 1;
            byte b2 = ((bArr[i] & 255) << 24) | ((bArr[i3] & 255) << 16);
            int i5 = i4 + 1;
            byte b3 = b2 | ((bArr[i4] & 255) << 8);
            int i6 = i5 + 1;
            byte b4 = b3 | (bArr[i5] & 255);
            this.size = j - 4;
            if (i6 == i2) {
                this.head = segment.pop();
                SegmentPool.INSTANCE.recycle(segment);
            } else {
                segment.pos = i6;
            }
            return b4;
        }
        throw new IllegalArgumentException("size < 4: " + this.size);
    }

    public int readIntLe() {
        return Util.reverseBytesInt(readInt());
    }

    public short readShort() {
        long j = this.size;
        if (j >= 2) {
            Segment segment = this.head;
            int i = segment.pos;
            int i2 = segment.limit;
            if (i2 - i < 2) {
                return (short) (((readByte() & 255) << 8) | (readByte() & 255));
            }
            byte[] bArr = segment.data;
            int i3 = i + 1;
            int i4 = i3 + 1;
            byte b2 = ((bArr[i] & 255) << 8) | (bArr[i3] & 255);
            this.size = j - 2;
            if (i4 == i2) {
                this.head = segment.pop();
                SegmentPool.INSTANCE.recycle(segment);
            } else {
                segment.pos = i4;
            }
            return (short) b2;
        }
        throw new IllegalArgumentException("size < 2: " + this.size);
    }

    public int readShortLe() {
        return Util.reverseBytesShort(readShort());
    }

    public String readUtf8(long j) {
        Util.checkOffsetAndCount(this.size, 0, j);
        if (j > 2147483647L) {
            throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: " + j);
        } else if (j == 0) {
            return "";
        } else {
            Segment segment = this.head;
            int i = segment.pos;
            if (((long) i) + j > ((long) segment.limit)) {
                try {
                    return new String(readBytes(j), Util.UTF_8);
                } catch (UnsupportedEncodingException e) {
                    throw new AssertionError(e);
                }
            } else {
                try {
                    String str = new String(segment.data, i, (int) j, Util.UTF_8);
                    segment.pos = (int) (((long) segment.pos) + j);
                    this.size -= j;
                    if (segment.pos == segment.limit) {
                        this.head = segment.pop();
                        SegmentPool.INSTANCE.recycle(segment);
                    }
                    return str;
                } catch (UnsupportedEncodingException e2) {
                    throw new AssertionError(e2);
                }
            }
        }
    }

    public String readUtf8Line(boolean z) {
        long indexOf = indexOf((byte) 10);
        if (indexOf != -1) {
            if (indexOf > 0) {
                long j = indexOf - 1;
                if (getByte(j) == 13) {
                    String readUtf8 = readUtf8(j);
                    skip(2);
                    return readUtf8;
                }
            }
            String readUtf82 = readUtf8(indexOf);
            skip(1);
            return readUtf82;
        } else if (!z) {
            long j2 = this.size;
            if (j2 != 0) {
                return readUtf8(j2);
            }
            return null;
        } else {
            throw new EOFException();
        }
    }

    public void require(long j) {
        if (this.size < j) {
            throw new EOFException();
        }
    }

    public long seek(byte b2) {
        long indexOf = indexOf(b2);
        if (indexOf != -1) {
            return indexOf;
        }
        throw new EOFException();
    }

    /* access modifiers changed from: package-private */
    public List<Integer> segmentSizes() {
        if (this.head == null) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        Segment segment = this.head;
        arrayList.add(Integer.valueOf(segment.limit - segment.pos));
        Segment segment2 = this.head;
        while (true) {
            segment2 = segment2.next;
            if (segment2 == this.head) {
                return arrayList;
            }
            arrayList.add(Integer.valueOf(segment2.limit - segment2.pos));
        }
    }

    public long size() {
        return this.size;
    }

    public void skip(long j) {
        Util.checkOffsetAndCount(this.size, 0, j);
        this.size -= j;
        while (j > 0) {
            Segment segment = this.head;
            int min = (int) Math.min(j, (long) (segment.limit - segment.pos));
            j -= (long) min;
            Segment segment2 = this.head;
            segment2.pos += min;
            if (segment2.pos == segment2.limit) {
                this.head = segment2.pop();
                SegmentPool.INSTANCE.recycle(segment2);
            }
        }
    }

    public String toString() {
        long j = this.size;
        if (j == 0) {
            return "OkBuffer[size=0]";
        }
        if (j <= 16) {
            return String.format("OkBuffer[size=%s data=%s]", new Object[]{Long.valueOf(this.size), clone().readByteString(this.size).hex()});
        }
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(this.head.data, this.head.pos, this.head.limit - this.head.pos);
            Segment segment = this.head;
            while (true) {
                segment = segment.next;
                if (segment != this.head) {
                    instance.update(segment.data, segment.pos, segment.limit - segment.pos);
                } else {
                    return String.format("OkBuffer[size=%s md5=%s]", new Object[]{Long.valueOf(this.size), ByteString.of(instance.digest()).hex()});
                }
            }
        } catch (NoSuchAlgorithmException unused) {
            throw new AssertionError();
        }
    }

    /* access modifiers changed from: package-private */
    public Segment writableSegment(int i) {
        if (i < 1 || i > 2048) {
            throw new IllegalArgumentException();
        }
        Segment segment = this.head;
        if (segment == null) {
            this.head = SegmentPool.INSTANCE.take();
            Segment segment2 = this.head;
            segment2.prev = segment2;
            segment2.next = segment2;
            return segment2;
        }
        Segment segment3 = segment.prev;
        return segment3.limit + i > 2048 ? segment3.push(SegmentPool.INSTANCE.take()) : segment3;
    }

    public OkBuffer write(ByteString byteString) {
        byte[] bArr = byteString.data;
        return write(bArr, 0, bArr.length);
    }

    public OkBuffer write(byte[] bArr) {
        return write(bArr, 0, bArr.length);
    }

    public OkBuffer write(byte[] bArr, int i, int i2) {
        int i3 = i + i2;
        while (i < i3) {
            Segment writableSegment = writableSegment(1);
            int min = Math.min(i3 - i, 2048 - writableSegment.limit);
            System.arraycopy(bArr, i, writableSegment.data, writableSegment.limit, min);
            i += min;
            writableSegment.limit += min;
        }
        this.size += (long) i2;
        return this;
    }

    public void write(OkBuffer okBuffer, long j) {
        if (okBuffer != this) {
            Util.checkOffsetAndCount(okBuffer.size, 0, j);
            while (j > 0) {
                Segment segment = okBuffer.head;
                if (j < ((long) (segment.limit - segment.pos))) {
                    Segment segment2 = this.head;
                    Segment segment3 = segment2 != null ? segment2.prev : null;
                    if (segment3 == null || ((long) (segment3.limit - segment3.pos)) + j > 2048) {
                        okBuffer.head = okBuffer.head.split((int) j);
                    } else {
                        okBuffer.head.writeTo(segment3, (int) j);
                        okBuffer.size -= j;
                        this.size += j;
                        return;
                    }
                }
                Segment segment4 = okBuffer.head;
                long j2 = (long) (segment4.limit - segment4.pos);
                okBuffer.head = segment4.pop();
                Segment segment5 = this.head;
                if (segment5 == null) {
                    this.head = segment4;
                    Segment segment6 = this.head;
                    segment6.prev = segment6;
                    segment6.next = segment6;
                } else {
                    segment5.prev.push(segment4).compact();
                }
                okBuffer.size -= j2;
                this.size += j2;
                j -= j2;
            }
            return;
        }
        throw new IllegalArgumentException("source == this");
    }

    public OkBuffer writeByte(int i) {
        Segment writableSegment = writableSegment(1);
        byte[] bArr = writableSegment.data;
        int i2 = writableSegment.limit;
        writableSegment.limit = i2 + 1;
        bArr[i2] = (byte) i;
        this.size++;
        return this;
    }

    public OkBuffer writeInt(int i) {
        Segment writableSegment = writableSegment(4);
        byte[] bArr = writableSegment.data;
        int i2 = writableSegment.limit;
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((i >> 24) & 255);
        int i4 = i3 + 1;
        bArr[i3] = (byte) ((i >> 16) & 255);
        int i5 = i4 + 1;
        bArr[i4] = (byte) ((i >> 8) & 255);
        bArr[i5] = (byte) (i & 255);
        writableSegment.limit = i5 + 1;
        this.size += 4;
        return this;
    }

    public OkBuffer writeShort(int i) {
        Segment writableSegment = writableSegment(2);
        byte[] bArr = writableSegment.data;
        int i2 = writableSegment.limit;
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((i >> 8) & 255);
        bArr[i3] = (byte) (i & 255);
        writableSegment.limit = i3 + 1;
        this.size += 2;
        return this;
    }

    public OkBuffer writeUtf8(String str) {
        try {
            byte[] bytes = str.getBytes(Util.UTF_8);
            return write(bytes, 0, bytes.length);
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError(e);
        }
    }
}
