package com.squareup.okhttp.internal.okio;

import java.io.Closeable;

public interface Source extends Closeable {
    void close();

    Source deadline(Deadline deadline);

    long read(OkBuffer okBuffer, long j);
}
