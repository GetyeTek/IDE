package com.squareup.okhttp.internal.okio;

import java.io.InputStream;

public interface BufferedSource extends Source {
    OkBuffer buffer();

    boolean exhausted();

    InputStream inputStream();

    byte readByte();

    ByteString readByteString(long j);

    int readInt();

    int readIntLe();

    short readShort();

    int readShortLe();

    String readUtf8(long j);

    String readUtf8Line(boolean z);

    void require(long j);

    long seek(byte b2);

    void skip(long j);
}
