package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.Address;
import com.squareup.okhttp.Connection;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.OkResponseCache;
import com.squareup.okhttp.ResponseSource;
import com.squareup.okhttp.Route;
import com.squareup.okhttp.TunnelRequest;
import com.squareup.okhttp.internal.Dns;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.CacheStrategy;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.http.Request;
import com.squareup.okhttp.internal.http.Response;
import com.squareup.okhttp.internal.okio.BufferedSink;
import com.squareup.okhttp.internal.okio.GzipSource;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.okio.Sink;
import com.squareup.okhttp.internal.okio.Source;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.CacheRequest;
import java.net.CookieHandler;
import java.net.ProtocolException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.cert.CertificateException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLSocketFactory;

public class HttpEngine {
    public final boolean bufferRequestBody;
    private BufferedSink bufferedRequestBody;
    private CacheRequest cacheRequest;
    final OkHttpClient client;
    private Connection connection;
    private Request originalRequest;
    private Request request;
    private Sink requestBodyOut;
    private Response response;
    private Source responseBody;
    private InputStream responseBodyBytes;
    private ResponseSource responseSource;
    private Source responseTransferSource;
    private Route route;
    private RouteSelector routeSelector;
    long sentRequestMillis = -1;
    private boolean transparentGzip;
    private Transport transport;
    private Response validatingResponse;

    public HttpEngine(OkHttpClient okHttpClient, Request request2, boolean z, Connection connection2, RouteSelector routeSelector2, RetryableSink retryableSink) {
        Route route2;
        this.client = okHttpClient;
        this.originalRequest = request2;
        this.request = request2;
        this.bufferRequestBody = z;
        this.connection = connection2;
        this.routeSelector = routeSelector2;
        this.requestBodyOut = retryableSink;
        if (connection2 != null) {
            connection2.setOwner(this);
            route2 = connection2.getRoute();
        } else {
            route2 = null;
        }
        this.route = route2;
    }

    private Response cacheableResponse() {
        return this.response.newBuilder().body((Response.Body) null).build();
    }

    private static Response combine(Response response2, Response response3) {
        Headers.Builder builder = new Headers.Builder();
        Headers headers = response2.headers();
        for (int i = 0; i < headers.size(); i++) {
            String name = headers.name(i);
            String value = headers.value(i);
            if ((!"Warning".equals(name) || !value.startsWith("1")) && (!isEndToEnd(name) || response3.header(name) == null)) {
                builder.add(name, value);
            }
        }
        Headers headers2 = response3.headers();
        for (int i2 = 0; i2 < headers2.size(); i2++) {
            String name2 = headers2.name(i2);
            if (isEndToEnd(name2)) {
                builder.add(name2, headers2.value(i2));
            }
        }
        return response2.newBuilder().headers(builder.build()).build();
    }

    private void connect() {
        HostnameVerifier hostnameVerifier;
        SSLSocketFactory sSLSocketFactory;
        if (this.connection == null) {
            if (this.routeSelector == null) {
                String host = this.request.url().getHost();
                if (host == null || host.length() == 0) {
                    throw new UnknownHostException(this.request.url().toString());
                }
                if (this.request.isHttps()) {
                    sSLSocketFactory = this.client.getSslSocketFactory();
                    hostnameVerifier = this.client.getHostnameVerifier();
                } else {
                    sSLSocketFactory = null;
                    hostnameVerifier = null;
                }
                this.routeSelector = new RouteSelector(new Address(host, Util.getEffectivePort(this.request.url()), sSLSocketFactory, hostnameVerifier, this.client.getAuthenticator(), this.client.getProxy(), this.client.getProtocols()), this.request.uri(), this.client.getProxySelector(), this.client.getConnectionPool(), Dns.DEFAULT, this.client.getRoutesDatabase());
            }
            this.connection = this.routeSelector.next(this.request.method());
            this.connection.setOwner(this);
            if (!this.connection.isConnected()) {
                this.connection.connect(this.client.getConnectTimeout(), this.client.getReadTimeout(), getTunnelConfig());
                if (this.connection.isSpdy()) {
                    this.client.getConnectionPool().share(this.connection);
                }
                this.client.getRoutesDatabase().connected(this.connection.getRoute());
            } else if (!this.connection.isSpdy()) {
                this.connection.updateReadTimeout(this.client.getReadTimeout());
            }
            this.route = this.connection.getRoute();
            return;
        }
        throw new IllegalStateException();
    }

    public static String getDefaultUserAgent() {
        String property = System.getProperty("http.agent");
        if (property != null) {
            return property;
        }
        return "Java" + System.getProperty("java.version");
    }

    private TunnelRequest getTunnelConfig() {
        if (!this.request.isHttps()) {
            return null;
        }
        String userAgent = this.request.getUserAgent();
        if (userAgent == null) {
            userAgent = getDefaultUserAgent();
        }
        URL url = this.request.url();
        return new TunnelRequest(url.getHost(), Util.getEffectivePort(url), userAgent, this.request.getProxyAuthorization());
    }

    public static String hostHeader(URL url) {
        if (Util.getEffectivePort(url) == Util.getDefaultPort(url.getProtocol())) {
            return url.getHost();
        }
        return url.getHost() + ":" + url.getPort();
    }

    private void initContentStream(Source source) {
        this.responseTransferSource = source;
        if (!this.transparentGzip || !"gzip".equalsIgnoreCase(this.response.header("Content-Encoding"))) {
            this.responseBody = source;
            return;
        }
        this.response = this.response.newBuilder().removeHeader("Content-Encoding").removeHeader("Content-Length").build();
        this.responseBody = new GzipSource(source);
    }

    private static boolean isEndToEnd(String str) {
        return !"Connection".equalsIgnoreCase(str) && !"Keep-Alive".equalsIgnoreCase(str) && !"Proxy-Authenticate".equalsIgnoreCase(str) && !"Proxy-Authorization".equalsIgnoreCase(str) && !"TE".equalsIgnoreCase(str) && !"Trailers".equalsIgnoreCase(str) && !"Transfer-Encoding".equalsIgnoreCase(str) && !"Upgrade".equalsIgnoreCase(str);
    }

    private boolean isRecoverable(IOException iOException) {
        return !((iOException instanceof SSLHandshakeException) && (iOException.getCause() instanceof CertificateException)) && !(iOException instanceof ProtocolException);
    }

    private void maybeCache() {
        OkResponseCache okResponseCache = this.client.getOkResponseCache();
        if (okResponseCache != null) {
            if (!CacheStrategy.isCacheable(this.response, this.request)) {
                okResponseCache.maybeRemove(this.request);
            } else {
                this.cacheRequest = okResponseCache.put(cacheableResponse());
            }
        }
    }

    private void prepareRawRequestHeaders() {
        Request.Builder newBuilder = this.request.newBuilder();
        if (this.request.getUserAgent() == null) {
            newBuilder.setUserAgent(getDefaultUserAgent());
        }
        if (this.request.header("Host") == null) {
            newBuilder.header("Host", hostHeader(this.request.url()));
        }
        Connection connection2 = this.connection;
        if ((connection2 == null || connection2.getHttpMinorVersion() != 0) && this.request.header("Connection") == null) {
            newBuilder.header("Connection", "Keep-Alive");
        }
        if (this.request.header("Accept-Encoding") == null) {
            this.transparentGzip = true;
            newBuilder.header("Accept-Encoding", "gzip");
        }
        if (hasRequestBody() && this.request.header("Content-Type") == null) {
            newBuilder.header("Content-Type", "application/x-www-form-urlencoded");
        }
        CookieHandler cookieHandler = this.client.getCookieHandler();
        if (cookieHandler != null) {
            OkHeaders.addCookies(newBuilder, cookieHandler.get(this.request.uri(), OkHeaders.toMultimap(newBuilder.build().headers(), (String) null)));
        }
        this.request = newBuilder.build();
    }

    public final Connection close() {
        Closeable closeable = this.bufferedRequestBody;
        if (!(closeable == null && (closeable = this.requestBodyOut) == null)) {
            Util.closeQuietly(closeable);
        }
        Source source = this.responseBody;
        if (source != null) {
            Util.closeQuietly((Closeable) source);
            Util.closeQuietly((Closeable) this.responseBodyBytes);
            Transport transport2 = this.transport;
            if (transport2 == null || transport2.canReuseConnection()) {
                Connection connection2 = this.connection;
                if (connection2 != null && !connection2.clearOwner()) {
                    this.connection = null;
                }
                Connection connection3 = this.connection;
                this.connection = null;
                return connection3;
            }
        }
        Util.closeQuietly((Closeable) this.connection);
        this.connection = null;
        return null;
    }

    public final void disconnect() {
        Transport transport2 = this.transport;
        if (transport2 != null) {
            transport2.disconnect(this);
        }
    }

    public final BufferedSink getBufferedRequestBody() {
        BufferedSink bufferedSink = this.bufferedRequestBody;
        if (bufferedSink != null) {
            return bufferedSink;
        }
        Sink requestBody = getRequestBody();
        if (requestBody == null) {
            return null;
        }
        BufferedSink buffer = Okio.buffer(requestBody);
        this.bufferedRequestBody = buffer;
        return buffer;
    }

    public final Connection getConnection() {
        return this.connection;
    }

    public final Request getRequest() {
        return this.request;
    }

    public final Sink getRequestBody() {
        if (this.responseSource != null) {
            return this.requestBodyOut;
        }
        throw new IllegalStateException();
    }

    public final Response getResponse() {
        Response response2 = this.response;
        if (response2 != null) {
            return response2;
        }
        throw new IllegalStateException();
    }

    public final Source getResponseBody() {
        if (this.response != null) {
            return this.responseBody;
        }
        throw new IllegalStateException();
    }

    public final InputStream getResponseBodyBytes() {
        InputStream inputStream = this.responseBodyBytes;
        if (inputStream != null) {
            return inputStream;
        }
        InputStream inputStream2 = Okio.buffer(getResponseBody()).inputStream();
        this.responseBodyBytes = inputStream2;
        return inputStream2;
    }

    public Route getRoute() {
        return this.route;
    }

    /* access modifiers changed from: package-private */
    public boolean hasRequestBody() {
        return HttpMethod.hasRequestBody(this.request.method());
    }

    public final boolean hasResponse() {
        return this.response != null;
    }

    public final boolean hasResponseBody() {
        if (this.request.method().equals("HEAD")) {
            return false;
        }
        int code = this.response.code();
        return (((code >= 100 && code < 200) || code == 204 || code == 304) && OkHeaders.contentLength(this.response) == -1 && !"chunked".equalsIgnoreCase(this.response.header("Transfer-Encoding"))) ? false : true;
    }

    public final void readResponse() {
        if (this.response == null) {
            ResponseSource responseSource2 = this.responseSource;
            if (responseSource2 == null) {
                throw new IllegalStateException("call sendRequest() first!");
            } else if (responseSource2.requiresConnection()) {
                BufferedSink bufferedSink = this.bufferedRequestBody;
                if (bufferedSink != null && bufferedSink.buffer().size() > 0) {
                    this.bufferedRequestBody.flush();
                }
                if (this.sentRequestMillis == -1) {
                    if (OkHeaders.contentLength(this.request) == -1) {
                        Sink sink = this.requestBodyOut;
                        if (sink instanceof RetryableSink) {
                            this.request = this.request.newBuilder().header("Content-Length", Long.toString(((RetryableSink) sink).contentLength())).build();
                        }
                    }
                    this.transport.writeRequestHeaders(this.request);
                }
                Sink sink2 = this.requestBodyOut;
                if (sink2 != null) {
                    BufferedSink bufferedSink2 = this.bufferedRequestBody;
                    if (bufferedSink2 != null) {
                        bufferedSink2.close();
                    } else {
                        sink2.close();
                    }
                    Sink sink3 = this.requestBodyOut;
                    if (sink3 instanceof RetryableSink) {
                        this.transport.writeRequestBody((RetryableSink) sink3);
                    }
                }
                this.transport.flushRequest();
                this.response = this.transport.readResponseHeaders().request(this.request).handshake(this.connection.getHandshake()).header(OkHeaders.SENT_MILLIS, Long.toString(this.sentRequestMillis)).header(OkHeaders.RECEIVED_MILLIS, Long.toString(System.currentTimeMillis())).setResponseSource(this.responseSource).build();
                this.connection.setHttpMinorVersion(this.response.httpMinorVersion());
                receiveHeaders(this.response.headers());
                if (this.responseSource == ResponseSource.CONDITIONAL_CACHE) {
                    if (this.validatingResponse.validate(this.response)) {
                        this.transport.emptyTransferStream();
                        releaseConnection();
                        this.response = combine(this.validatingResponse, this.response);
                        OkResponseCache okResponseCache = this.client.getOkResponseCache();
                        okResponseCache.trackConditionalCacheHit();
                        okResponseCache.update(this.validatingResponse, cacheableResponse());
                        if (this.validatingResponse.body() != null) {
                            initContentStream(this.validatingResponse.body().source());
                            return;
                        }
                        return;
                    }
                    Util.closeQuietly((Closeable) this.validatingResponse.body());
                }
                if (!hasResponseBody()) {
                    this.responseTransferSource = this.transport.getTransferStream(this.cacheRequest);
                    this.responseBody = this.responseTransferSource;
                    return;
                }
                maybeCache();
                initContentStream(this.transport.getTransferStream(this.cacheRequest));
            }
        }
    }

    public void receiveHeaders(Headers headers) {
        CookieHandler cookieHandler = this.client.getCookieHandler();
        if (cookieHandler != null) {
            cookieHandler.put(this.request.uri(), OkHeaders.toMultimap(headers, (String) null));
        }
    }

    public HttpEngine recover(IOException iOException) {
        Connection connection2;
        RouteSelector routeSelector2 = this.routeSelector;
        if (!(routeSelector2 == null || (connection2 = this.connection) == null)) {
            routeSelector2.connectFailed(connection2, iOException);
        }
        Sink sink = this.requestBodyOut;
        boolean z = sink == null || (sink instanceof RetryableSink);
        if (this.routeSelector == null && this.connection == null) {
            return null;
        }
        RouteSelector routeSelector3 = this.routeSelector;
        if ((routeSelector3 != null && !routeSelector3.hasNext()) || !isRecoverable(iOException) || !z) {
            return null;
        }
        return new HttpEngine(this.client, this.originalRequest, this.bufferRequestBody, close(), this.routeSelector, (RetryableSink) this.requestBodyOut);
    }

    public final void releaseConnection() {
        Transport transport2 = this.transport;
        if (!(transport2 == null || this.connection == null)) {
            transport2.releaseConnectionOnIdle();
        }
        this.connection = null;
    }

    public final ResponseSource responseSource() {
        return this.responseSource;
    }

    public final void sendRequest() {
        if (this.responseSource == null) {
            if (this.transport == null) {
                prepareRawRequestHeaders();
                OkResponseCache okResponseCache = this.client.getOkResponseCache();
                Response response2 = okResponseCache != null ? okResponseCache.get(this.request) : null;
                CacheStrategy cacheStrategy = new CacheStrategy.Factory(System.currentTimeMillis(), this.request, response2).get();
                this.responseSource = cacheStrategy.source;
                this.request = cacheStrategy.request;
                if (okResponseCache != null) {
                    okResponseCache.trackResponse(this.responseSource);
                }
                if (this.responseSource != ResponseSource.NETWORK) {
                    this.validatingResponse = cacheStrategy.response;
                }
                if (response2 != null && !this.responseSource.usesCache()) {
                    Util.closeQuietly((Closeable) response2.body());
                }
                if (this.responseSource.requiresConnection()) {
                    if (this.connection == null) {
                        connect();
                    }
                    if (this.connection.getOwner() == this || this.connection.isSpdy()) {
                        this.transport = (Transport) this.connection.newTransport(this);
                        if (hasRequestBody() && this.requestBodyOut == null) {
                            this.requestBodyOut = this.transport.createRequestBody(this.request);
                            return;
                        }
                        return;
                    }
                    throw new AssertionError();
                }
                if (this.connection != null) {
                    this.client.getConnectionPool().recycle(this.connection);
                    this.connection = null;
                }
                Response response3 = this.validatingResponse;
                this.response = response3;
                if (response3.body() != null) {
                    initContentStream(this.validatingResponse.body().source());
                    return;
                }
                return;
            }
            throw new IllegalStateException();
        }
    }

    public void writingRequestHeaders() {
        if (this.sentRequestMillis == -1) {
            this.sentRequestMillis = System.currentTimeMillis();
            return;
        }
        throw new IllegalStateException();
    }
}
