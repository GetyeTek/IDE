package com.squareup.okhttp.internal.http;

import java.net.Proxy;
import java.net.URL;

public final class RequestLine {
    private RequestLine() {
    }

    static String get(Request request, Proxy.Type type, int i) {
        StringBuilder sb = new StringBuilder();
        sb.append(request.method());
        sb.append(" ");
        if (includeAuthorityInRequestLine(request, type)) {
            sb.append(request.url());
        } else {
            sb.append(requestPath(request.url()));
        }
        sb.append(" ");
        sb.append(version(i));
        return sb.toString();
    }

    private static boolean includeAuthorityInRequestLine(Request request, Proxy.Type type) {
        return !request.isHttps() && type == Proxy.Type.HTTP;
    }

    public static String requestPath(URL url) {
        String file = url.getFile();
        if (file == null) {
            return "/";
        }
        if (file.startsWith("/")) {
            return file;
        }
        return "/" + file;
    }

    public static String version(int i) {
        return i == 1 ? "HTTP/1.1" : "HTTP/1.0";
    }
}
