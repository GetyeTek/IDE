package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.Protocol;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.http.Response;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.Deadline;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.okio.Sink;
import com.squareup.okhttp.internal.okio.Source;
import com.squareup.okhttp.internal.spdy.ErrorCode;
import com.squareup.okhttp.internal.spdy.Header;
import com.squareup.okhttp.internal.spdy.SpdyConnection;
import com.squareup.okhttp.internal.spdy.SpdyStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.CacheRequest;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public final class SpdyTransport implements Transport {
    private final HttpEngine httpEngine;
    private final SpdyConnection spdyConnection;
    private SpdyStream stream;

    private static class SpdySource implements Source {
        private final OutputStream cacheBody;
        private final CacheRequest cacheRequest;
        private boolean closed;
        private boolean inputExhausted;
        private final Source source;
        private final SpdyStream stream;

        SpdySource(SpdyStream spdyStream, CacheRequest cacheRequest2) {
            this.stream = spdyStream;
            this.source = spdyStream.getSource();
            CacheRequest cacheRequest3 = null;
            OutputStream body = cacheRequest2 != null ? cacheRequest2.getBody() : null;
            cacheRequest3 = body != null ? cacheRequest2 : cacheRequest3;
            this.cacheBody = body;
            this.cacheRequest = cacheRequest3;
        }

        private boolean discardStream() {
            long readTimeoutMillis;
            try {
                readTimeoutMillis = this.stream.getReadTimeoutMillis();
                this.stream.setReadTimeout(readTimeoutMillis);
                this.stream.setReadTimeout(100);
                Util.skipAll(this, 100);
                this.stream.setReadTimeout(readTimeoutMillis);
                return true;
            } catch (IOException unused) {
                return false;
            } catch (Throwable th) {
                this.stream.setReadTimeout(readTimeoutMillis);
                throw th;
            }
        }

        public void close() {
            if (!this.closed) {
                if (!this.inputExhausted && this.cacheBody != null) {
                    discardStream();
                }
                this.closed = true;
                if (!this.inputExhausted) {
                    this.stream.closeLater(ErrorCode.CANCEL);
                    CacheRequest cacheRequest2 = this.cacheRequest;
                    if (cacheRequest2 != null) {
                        cacheRequest2.abort();
                    }
                }
            }
        }

        public Source deadline(Deadline deadline) {
            this.source.deadline(deadline);
            return this;
        }

        public long read(OkBuffer okBuffer, long j) {
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j);
            } else if (this.closed) {
                throw new IllegalStateException("closed");
            } else if (this.inputExhausted) {
                return -1;
            } else {
                long read = this.source.read(okBuffer, j);
                if (read == -1) {
                    this.inputExhausted = true;
                    if (this.cacheRequest != null) {
                        this.cacheBody.close();
                    }
                    return -1;
                }
                if (this.cacheBody != null) {
                    Okio.copy(okBuffer, okBuffer.size() - read, read, this.cacheBody);
                }
                return read;
            }
        }
    }

    public SpdyTransport(HttpEngine httpEngine2, SpdyConnection spdyConnection2) {
        this.httpEngine = httpEngine2;
        this.spdyConnection = spdyConnection2;
    }

    private static boolean isProhibitedHeader(Protocol protocol, ByteString byteString) {
        if (protocol == Protocol.SPDY_3) {
            if (byteString.equalsAscii("connection") || byteString.equalsAscii("host") || byteString.equalsAscii("keep-alive") || byteString.equalsAscii("proxy-connection") || byteString.equalsAscii("transfer-encoding")) {
                return true;
            }
        } else if (protocol != Protocol.HTTP_2) {
            throw new AssertionError(protocol);
        } else if (byteString.equalsAscii("connection") || byteString.equalsAscii("host") || byteString.equalsAscii("keep-alive") || byteString.equalsAscii("proxy-connection") || byteString.equalsAscii("te") || byteString.equalsAscii("transfer-encoding") || byteString.equalsAscii("encoding") || byteString.equalsAscii("upgrade")) {
            return true;
        }
        return false;
    }

    private static String joinOnNull(String str, String str2) {
        return str + 0 + str2;
    }

    public static Response.Builder readNameValueBlock(List<Header> list, Protocol protocol) {
        Headers.Builder builder = new Headers.Builder();
        builder.set(OkHeaders.SELECTED_PROTOCOL, protocol.name.utf8());
        String str = "HTTP/1.1";
        String str2 = null;
        int i = 0;
        while (i < list.size()) {
            ByteString byteString = list.get(i).name;
            String utf8 = list.get(i).value.utf8();
            String str3 = str;
            String str4 = str2;
            int i2 = 0;
            while (i2 < utf8.length()) {
                int indexOf = utf8.indexOf(0, i2);
                if (indexOf == -1) {
                    indexOf = utf8.length();
                }
                String substring = utf8.substring(i2, indexOf);
                if (byteString.equals(Header.RESPONSE_STATUS)) {
                    str4 = substring;
                } else if (byteString.equals(Header.VERSION)) {
                    str3 = substring;
                } else if (!isProhibitedHeader(protocol, byteString)) {
                    builder.add(byteString.utf8(), substring);
                }
                i2 = indexOf + 1;
            }
            i++;
            str2 = str4;
            str = str3;
        }
        if (str2 == null) {
            throw new ProtocolException("Expected ':status' header not present");
        } else if (str != null) {
            return new Response.Builder().statusLine(new StatusLine(str + " " + str2)).headers(builder.build());
        } else {
            throw new ProtocolException("Expected ':version' header not present");
        }
    }

    public static List<Header> writeNameValueBlock(Request request, Protocol protocol, String str) {
        Header header;
        Headers headers = request.headers();
        ArrayList arrayList = new ArrayList(headers.size() + 10);
        arrayList.add(new Header(Header.TARGET_METHOD, request.method()));
        arrayList.add(new Header(Header.TARGET_PATH, RequestLine.requestPath(request.url())));
        String hostHeader = HttpEngine.hostHeader(request.url());
        if (Protocol.SPDY_3 == protocol) {
            arrayList.add(new Header(Header.VERSION, str));
            header = new Header(Header.TARGET_HOST, hostHeader);
        } else if (Protocol.HTTP_2 == protocol) {
            header = new Header(Header.TARGET_AUTHORITY, hostHeader);
        } else {
            throw new AssertionError();
        }
        arrayList.add(header);
        arrayList.add(new Header(Header.TARGET_SCHEME, request.url().getProtocol()));
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        for (int i = 0; i < headers.size(); i++) {
            ByteString encodeUtf8 = ByteString.encodeUtf8(headers.name(i).toLowerCase(Locale.US));
            String value = headers.value(i);
            if (!isProhibitedHeader(protocol, encodeUtf8) && !encodeUtf8.equals(Header.TARGET_METHOD) && !encodeUtf8.equals(Header.TARGET_PATH) && !encodeUtf8.equals(Header.TARGET_SCHEME) && !encodeUtf8.equals(Header.TARGET_AUTHORITY) && !encodeUtf8.equals(Header.TARGET_HOST) && !encodeUtf8.equals(Header.VERSION)) {
                if (linkedHashSet.add(encodeUtf8)) {
                    arrayList.add(new Header(encodeUtf8, value));
                } else {
                    int i2 = 0;
                    while (true) {
                        if (i2 >= arrayList.size()) {
                            break;
                        } else if (((Header) arrayList.get(i2)).name.equals(encodeUtf8)) {
                            arrayList.set(i2, new Header(encodeUtf8, joinOnNull(((Header) arrayList.get(i2)).value.utf8(), value)));
                            break;
                        } else {
                            i2++;
                        }
                    }
                }
            }
        }
        return arrayList;
    }

    public boolean canReuseConnection() {
        return true;
    }

    public Sink createRequestBody(Request request) {
        writeRequestHeaders(request);
        return this.stream.getSink();
    }

    public void disconnect(HttpEngine httpEngine2) {
        this.stream.close(ErrorCode.CANCEL);
    }

    public void emptyTransferStream() {
    }

    public void flushRequest() {
        this.stream.getSink().close();
    }

    public Source getTransferStream(CacheRequest cacheRequest) {
        return new SpdySource(this.stream, cacheRequest);
    }

    public Response.Builder readResponseHeaders() {
        return readNameValueBlock(this.stream.getResponseHeaders(), this.spdyConnection.getProtocol());
    }

    public void releaseConnectionOnIdle() {
    }

    public void writeRequestBody(RetryableSink retryableSink) {
        throw new UnsupportedOperationException();
    }

    public void writeRequestHeaders(Request request) {
        if (this.stream == null) {
            this.httpEngine.writingRequestHeaders();
            boolean hasRequestBody = this.httpEngine.hasRequestBody();
            String version = RequestLine.version(this.httpEngine.getConnection().getHttpMinorVersion());
            SpdyConnection spdyConnection2 = this.spdyConnection;
            this.stream = spdyConnection2.newStream(writeNameValueBlock(request, spdyConnection2.getProtocol(), version), hasRequestBody, true);
            this.stream.setReadTimeout((long) this.httpEngine.client.getReadTimeout());
        }
    }
}
