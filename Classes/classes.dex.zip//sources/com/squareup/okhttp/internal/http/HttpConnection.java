package com.squareup.okhttp.internal.http;

import com.squareup.okhttp.Connection;
import com.squareup.okhttp.ConnectionPool;
import com.squareup.okhttp.Protocol;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Headers;
import com.squareup.okhttp.internal.http.Response;
import com.squareup.okhttp.internal.okio.BufferedSink;
import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.Deadline;
import com.squareup.okhttp.internal.okio.OkBuffer;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.okio.Sink;
import com.squareup.okhttp.internal.okio.Source;
import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.net.CacheRequest;
import java.net.ProtocolException;
import java.net.Socket;

public final class HttpConnection {
    private static final String CRLF = "\r\n";
    /* access modifiers changed from: private */
    public static final byte[] FINAL_CHUNK = {48, 13, 10, 13, 10};
    /* access modifiers changed from: private */
    public static final byte[] HEX_DIGITS = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102};
    private static final int ON_IDLE_CLOSE = 2;
    private static final int ON_IDLE_HOLD = 0;
    private static final int ON_IDLE_POOL = 1;
    private static final int STATE_CLOSED = 6;
    private static final int STATE_IDLE = 0;
    private static final int STATE_OPEN_REQUEST_BODY = 1;
    private static final int STATE_OPEN_RESPONSE_BODY = 4;
    private static final int STATE_READING_RESPONSE_BODY = 5;
    private static final int STATE_READ_RESPONSE_HEADERS = 3;
    private static final int STATE_WRITING_REQUEST_BODY = 2;
    /* access modifiers changed from: private */
    public final Connection connection;
    /* access modifiers changed from: private */
    public int onIdle = 0;
    /* access modifiers changed from: private */
    public final ConnectionPool pool;
    /* access modifiers changed from: private */
    public final BufferedSink sink;
    /* access modifiers changed from: private */
    public final BufferedSource source;
    /* access modifiers changed from: private */
    public int state = 0;

    private class AbstractSource {
        protected final OutputStream cacheBody;
        private final CacheRequest cacheRequest;
        protected boolean closed;

        AbstractSource(CacheRequest cacheRequest2) {
            CacheRequest cacheRequest3 = null;
            OutputStream body = cacheRequest2 != null ? cacheRequest2.getBody() : null;
            cacheRequest3 = body != null ? cacheRequest2 : cacheRequest3;
            this.cacheBody = body;
            this.cacheRequest = cacheRequest3;
        }

        /* access modifiers changed from: protected */
        public final void cacheWrite(OkBuffer okBuffer, long j) {
            if (this.cacheBody != null) {
                Okio.copy(okBuffer, okBuffer.size() - j, j, this.cacheBody);
            }
        }

        /* access modifiers changed from: protected */
        public final void endOfInput(boolean z) {
            if (HttpConnection.this.state == 5) {
                if (this.cacheRequest != null) {
                    this.cacheBody.close();
                }
                int unused = HttpConnection.this.state = 0;
                if (z && HttpConnection.this.onIdle == 1) {
                    int unused2 = HttpConnection.this.onIdle = 0;
                    HttpConnection.this.pool.recycle(HttpConnection.this.connection);
                } else if (HttpConnection.this.onIdle == 2) {
                    int unused3 = HttpConnection.this.state = 6;
                    HttpConnection.this.connection.close();
                }
            } else {
                throw new IllegalStateException("state: " + HttpConnection.this.state);
            }
        }

        /* access modifiers changed from: protected */
        public final void unexpectedEndOfInput() {
            CacheRequest cacheRequest2 = this.cacheRequest;
            if (cacheRequest2 != null) {
                cacheRequest2.abort();
            }
            Util.closeQuietly((Closeable) HttpConnection.this.connection);
            int unused = HttpConnection.this.state = 6;
        }
    }

    private final class ChunkedSink implements Sink {
        private boolean closed;
        private final byte[] hex;

        private ChunkedSink() {
            this.hex = new byte[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 10};
        }

        private void writeHex(long j) {
            int i = 16;
            do {
                i--;
                this.hex[i] = HttpConnection.HEX_DIGITS[(int) (15 & j)];
                j >>>= 4;
            } while (j != 0);
            BufferedSink access$200 = HttpConnection.this.sink;
            byte[] bArr = this.hex;
            access$200.write(bArr, i, bArr.length - i);
        }

        public synchronized void close() {
            if (!this.closed) {
                this.closed = true;
                HttpConnection.this.sink.write(HttpConnection.FINAL_CHUNK);
                int unused = HttpConnection.this.state = 3;
            }
        }

        public Sink deadline(Deadline deadline) {
            return this;
        }

        public synchronized void flush() {
            if (!this.closed) {
                HttpConnection.this.sink.flush();
            }
        }

        public void write(OkBuffer okBuffer, long j) {
            if (this.closed) {
                throw new IllegalStateException("closed");
            } else if (j != 0) {
                writeHex(j);
                HttpConnection.this.sink.write(okBuffer, j);
                HttpConnection.this.sink.writeUtf8(HttpConnection.CRLF);
            }
        }
    }

    private class ChunkedSource extends AbstractSource implements Source {
        private static final int NO_CHUNK_YET = -1;
        private int bytesRemainingInChunk = NO_CHUNK_YET;
        private boolean hasMoreChunks = true;
        private final HttpEngine httpEngine;

        ChunkedSource(CacheRequest cacheRequest, HttpEngine httpEngine2) {
            super(cacheRequest);
            this.httpEngine = httpEngine2;
        }

        private void readChunkSize() {
            if (this.bytesRemainingInChunk != NO_CHUNK_YET) {
                HttpConnection.this.source.readUtf8Line(true);
            }
            String readUtf8Line = HttpConnection.this.source.readUtf8Line(true);
            int indexOf = readUtf8Line.indexOf(";");
            if (indexOf != NO_CHUNK_YET) {
                readUtf8Line = readUtf8Line.substring(0, indexOf);
            }
            try {
                this.bytesRemainingInChunk = Integer.parseInt(readUtf8Line.trim(), 16);
                if (this.bytesRemainingInChunk == 0) {
                    this.hasMoreChunks = false;
                    Headers.Builder builder = new Headers.Builder();
                    HttpConnection.this.readHeaders(builder);
                    this.httpEngine.receiveHeaders(builder.build());
                    endOfInput(true);
                }
            } catch (NumberFormatException unused) {
                throw new ProtocolException("Expected a hex chunk size but was " + readUtf8Line);
            }
        }

        public void close() {
            if (!this.closed) {
                if (this.hasMoreChunks && !HttpConnection.this.discard(this, 100)) {
                    unexpectedEndOfInput();
                }
                this.closed = true;
            }
        }

        public Source deadline(Deadline deadline) {
            HttpConnection.this.source.deadline(deadline);
            return this;
        }

        public long read(OkBuffer okBuffer, long j) {
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j);
            } else if (this.closed) {
                throw new IllegalStateException("closed");
            } else if (!this.hasMoreChunks) {
                return -1;
            } else {
                int i = this.bytesRemainingInChunk;
                if (i == 0 || i == NO_CHUNK_YET) {
                    readChunkSize();
                    if (!this.hasMoreChunks) {
                        return -1;
                    }
                }
                long read = HttpConnection.this.source.read(okBuffer, Math.min(j, (long) this.bytesRemainingInChunk));
                if (read != -1) {
                    this.bytesRemainingInChunk = (int) (((long) this.bytesRemainingInChunk) - read);
                    cacheWrite(okBuffer, read);
                    return read;
                }
                unexpectedEndOfInput();
                throw new IOException("unexpected end of stream");
            }
        }
    }

    private final class FixedLengthSink implements Sink {
        private long bytesRemaining;
        private boolean closed;

        private FixedLengthSink(long j) {
            this.bytesRemaining = j;
        }

        public void close() {
            if (!this.closed) {
                this.closed = true;
                if (this.bytesRemaining <= 0) {
                    int unused = HttpConnection.this.state = 3;
                    return;
                }
                throw new ProtocolException("unexpected end of stream");
            }
        }

        public Sink deadline(Deadline deadline) {
            return this;
        }

        public void flush() {
            if (!this.closed) {
                HttpConnection.this.sink.flush();
            }
        }

        public void write(OkBuffer okBuffer, long j) {
            if (!this.closed) {
                Util.checkOffsetAndCount(okBuffer.size(), 0, j);
                if (j <= this.bytesRemaining) {
                    HttpConnection.this.sink.write(okBuffer, j);
                    this.bytesRemaining -= j;
                    return;
                }
                throw new ProtocolException("expected " + this.bytesRemaining + " bytes but received " + j);
            }
            throw new IllegalStateException("closed");
        }
    }

    private class FixedLengthSource extends AbstractSource implements Source {
        private long bytesRemaining;

        public FixedLengthSource(CacheRequest cacheRequest, long j) {
            super(cacheRequest);
            this.bytesRemaining = j;
            if (this.bytesRemaining == 0) {
                endOfInput(true);
            }
        }

        public void close() {
            if (!this.closed) {
                if (this.bytesRemaining != 0 && !HttpConnection.this.discard(this, 100)) {
                    unexpectedEndOfInput();
                }
                this.closed = true;
            }
        }

        public Source deadline(Deadline deadline) {
            HttpConnection.this.source.deadline(deadline);
            return this;
        }

        public long read(OkBuffer okBuffer, long j) {
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j);
            } else if (this.closed) {
                throw new IllegalStateException("closed");
            } else if (this.bytesRemaining == 0) {
                return -1;
            } else {
                long read = HttpConnection.this.source.read(okBuffer, Math.min(this.bytesRemaining, j));
                if (read != -1) {
                    this.bytesRemaining -= read;
                    cacheWrite(okBuffer, read);
                    if (this.bytesRemaining == 0) {
                        endOfInput(true);
                    }
                    return read;
                }
                unexpectedEndOfInput();
                throw new ProtocolException("unexpected end of stream");
            }
        }
    }

    class UnknownLengthSource extends AbstractSource implements Source {
        private boolean inputExhausted;

        UnknownLengthSource(CacheRequest cacheRequest) {
            super(cacheRequest);
        }

        public void close() {
            if (!this.closed) {
                if (!this.inputExhausted) {
                    unexpectedEndOfInput();
                }
                this.closed = true;
            }
        }

        public Source deadline(Deadline deadline) {
            HttpConnection.this.source.deadline(deadline);
            return this;
        }

        public long read(OkBuffer okBuffer, long j) {
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j);
            } else if (this.closed) {
                throw new IllegalStateException("closed");
            } else if (this.inputExhausted) {
                return -1;
            } else {
                long read = HttpConnection.this.source.read(okBuffer, j);
                if (read == -1) {
                    this.inputExhausted = true;
                    endOfInput(false);
                    return -1;
                }
                cacheWrite(okBuffer, read);
                return read;
            }
        }
    }

    public HttpConnection(ConnectionPool connectionPool, Connection connection2, BufferedSource bufferedSource, BufferedSink bufferedSink) {
        this.pool = connectionPool;
        this.connection = connection2;
        this.source = bufferedSource;
        this.sink = bufferedSink;
    }

    public void closeIfOwnedBy(Object obj) {
        this.connection.closeIfOwnedBy(obj);
    }

    public void closeOnIdle() {
        this.onIdle = 2;
        if (this.state == 0) {
            this.state = 6;
            this.connection.close();
        }
    }

    public boolean discard(Source source2, int i) {
        int soTimeout;
        Socket socket = this.connection.getSocket();
        try {
            soTimeout = socket.getSoTimeout();
            socket.setSoTimeout(i);
            boolean skipAll = Util.skipAll(source2, i);
            socket.setSoTimeout(soTimeout);
            return skipAll;
        } catch (IOException unused) {
            return false;
        } catch (Throwable th) {
            socket.setSoTimeout(soTimeout);
            throw th;
        }
    }

    public void emptyResponseBody() {
        newFixedLengthSource((CacheRequest) null, 0);
    }

    public void flush() {
        this.sink.flush();
    }

    public boolean isClosed() {
        return this.state == 6;
    }

    public Sink newChunkedSink() {
        if (this.state == 1) {
            this.state = 2;
            return new ChunkedSink();
        }
        throw new IllegalStateException("state: " + this.state);
    }

    public Source newChunkedSource(CacheRequest cacheRequest, HttpEngine httpEngine) {
        if (this.state == 4) {
            this.state = 5;
            return new ChunkedSource(cacheRequest, httpEngine);
        }
        throw new IllegalStateException("state: " + this.state);
    }

    public Sink newFixedLengthSink(long j) {
        if (this.state == 1) {
            this.state = 2;
            return new FixedLengthSink(j);
        }
        throw new IllegalStateException("state: " + this.state);
    }

    public Source newFixedLengthSource(CacheRequest cacheRequest, long j) {
        if (this.state == 4) {
            this.state = 5;
            return new FixedLengthSource(cacheRequest, j);
        }
        throw new IllegalStateException("state: " + this.state);
    }

    public Source newUnknownLengthSource(CacheRequest cacheRequest) {
        if (this.state == 4) {
            this.state = 5;
            return new UnknownLengthSource(cacheRequest);
        }
        throw new IllegalStateException("state: " + this.state);
    }

    public void poolOnIdle() {
        this.onIdle = 1;
        if (this.state == 0) {
            this.onIdle = 0;
            this.pool.recycle(this.connection);
        }
    }

    public void readHeaders(Headers.Builder builder) {
        while (true) {
            String readUtf8Line = this.source.readUtf8Line(true);
            if (readUtf8Line.length() != 0) {
                builder.addLine(readUtf8Line);
            } else {
                return;
            }
        }
    }

    public Response.Builder readResponse() {
        StatusLine statusLine;
        Response.Builder header;
        int i = this.state;
        if (i == 1 || i == 3) {
            do {
                statusLine = new StatusLine(this.source.readUtf8Line(true));
                header = new Response.Builder().statusLine(statusLine).header(OkHeaders.SELECTED_PROTOCOL, Protocol.HTTP_11.name.utf8());
                Headers.Builder builder = new Headers.Builder();
                readHeaders(builder);
                header.headers(builder.build());
            } while (statusLine.code() == 100);
            this.state = 4;
            return header;
        }
        throw new IllegalStateException("state: " + this.state);
    }

    public void writeRequest(Headers headers, String str) {
        if (this.state == 0) {
            this.sink.writeUtf8(str).writeUtf8(CRLF);
            for (int i = 0; i < headers.size(); i++) {
                this.sink.writeUtf8(headers.name(i)).writeUtf8(": ").writeUtf8(headers.value(i)).writeUtf8(CRLF);
            }
            this.sink.writeUtf8(CRLF);
            this.state = 1;
            return;
        }
        throw new IllegalStateException("state: " + this.state);
    }

    public void writeRequestBody(RetryableSink retryableSink) {
        if (this.state == 1) {
            this.state = 3;
            retryableSink.writeToSocket(this.sink);
            return;
        }
        throw new IllegalStateException("state: " + this.state);
    }
}
