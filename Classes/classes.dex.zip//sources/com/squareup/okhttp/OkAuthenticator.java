package com.squareup.okhttp;

import com.squareup.okhttp.internal.okio.ByteString;
import java.io.UnsupportedEncodingException;
import java.net.Proxy;
import java.net.URL;
import java.util.List;

@Deprecated
public interface OkAuthenticator {

    public static final class Challenge {
        private final String realm;
        private final String scheme;

        public Challenge(String str, String str2) {
            this.scheme = str;
            this.realm = str2;
        }

        public boolean equals(Object obj) {
            if (obj instanceof Challenge) {
                Challenge challenge = (Challenge) obj;
                return challenge.scheme.equals(this.scheme) && challenge.realm.equals(this.realm);
            }
        }

        public String getRealm() {
            return this.realm;
        }

        public String getScheme() {
            return this.scheme;
        }

        public int hashCode() {
            return this.scheme.hashCode() + (this.realm.hashCode() * 31);
        }

        public String toString() {
            return this.scheme + " realm=\"" + this.realm + "\"";
        }
    }

    public static final class Credential {
        private final String headerValue;

        private Credential(String str) {
            this.headerValue = str;
        }

        public static Credential basic(String str, String str2) {
            try {
                String base64 = ByteString.of((str + ":" + str2).getBytes("ISO-8859-1")).base64();
                return new Credential("Basic " + base64);
            } catch (UnsupportedEncodingException unused) {
                throw new AssertionError();
            }
        }

        public boolean equals(Object obj) {
            return (obj instanceof Credential) && ((Credential) obj).headerValue.equals(this.headerValue);
        }

        public String getHeaderValue() {
            return this.headerValue;
        }

        public int hashCode() {
            return this.headerValue.hashCode();
        }

        public String toString() {
            return this.headerValue;
        }
    }

    Credential authenticate(Proxy proxy, URL url, List<Challenge> list);

    Credential authenticateProxy(Proxy proxy, URL url, List<Challenge> list);
}
