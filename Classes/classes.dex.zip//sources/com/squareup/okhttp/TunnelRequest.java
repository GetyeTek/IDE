package com.squareup.okhttp;

import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.Request;
import java.net.URL;

@Deprecated
public final class TunnelRequest {
    final String host;
    final int port;
    final String proxyAuthorization;
    final String userAgent;

    public TunnelRequest(String str, int i, String str2, String str3) {
        if (str == null) {
            throw new NullPointerException("host == null");
        } else if (str2 != null) {
            this.host = str;
            this.port = i;
            this.userAgent = str2;
            this.proxyAuthorization = str3;
        } else {
            throw new NullPointerException("userAgent == null");
        }
    }

    /* access modifiers changed from: package-private */
    public Request getRequest() {
        String str;
        Request.Builder url = new Request.Builder().url(new URL("https", this.host, this.port, "/"));
        if (this.port == Util.getDefaultPort("https")) {
            str = this.host;
        } else {
            str = this.host + ":" + this.port;
        }
        url.header("Host", str);
        url.header("User-Agent", this.userAgent);
        String str2 = this.proxyAuthorization;
        if (str2 != null) {
            url.header("Proxy-Authorization", str2);
        }
        url.header("Proxy-Connection", "Keep-Alive");
        return url.build();
    }

    /* access modifiers changed from: package-private */
    public String requestLine() {
        return "CONNECT " + this.host + ":" + this.port + " HTTP/1.1";
    }
}
