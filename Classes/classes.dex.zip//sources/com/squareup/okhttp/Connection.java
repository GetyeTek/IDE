package com.squareup.okhttp;

import com.squareup.okhttp.internal.Platform;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.http.HttpAuthenticator;
import com.squareup.okhttp.internal.http.HttpConnection;
import com.squareup.okhttp.internal.http.HttpEngine;
import com.squareup.okhttp.internal.http.HttpTransport;
import com.squareup.okhttp.internal.http.Request;
import com.squareup.okhttp.internal.http.Response;
import com.squareup.okhttp.internal.http.SpdyTransport;
import com.squareup.okhttp.internal.okio.BufferedSink;
import com.squareup.okhttp.internal.okio.BufferedSource;
import com.squareup.okhttp.internal.okio.ByteString;
import com.squareup.okhttp.internal.okio.Okio;
import com.squareup.okhttp.internal.spdy.SpdyConnection;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketTimeoutException;
import javax.net.ssl.SSLSocket;

public final class Connection implements Closeable {
    private boolean connected = false;
    private Handshake handshake;
    private HttpConnection httpConnection;
    private int httpMinorVersion = 1;
    private long idleStartTimeNs;
    private InputStream in;
    private OutputStream out;
    private Object owner;
    private final ConnectionPool pool;
    private int recycleCount;
    private final Route route;
    private BufferedSink sink;
    private Socket socket;
    private BufferedSource source;
    private SpdyConnection spdyConnection;

    public Connection(ConnectionPool connectionPool, Route route2) {
        this.pool = connectionPool;
        this.route = route2;
    }

    private void initSourceAndSink() {
        this.source = Okio.buffer(Okio.source(this.in));
        this.sink = Okio.buffer(Okio.sink(this.out));
    }

    private void makeTunnel(TunnelRequest tunnelRequest) {
        BufferedSource buffer = Okio.buffer(Okio.source(this.in));
        HttpConnection httpConnection2 = new HttpConnection(this.pool, this, buffer, Okio.buffer(Okio.sink(this.out)));
        Request request = tunnelRequest.getRequest();
        String requestLine = tunnelRequest.requestLine();
        do {
            httpConnection2.writeRequest(request.headers(), requestLine);
            httpConnection2.flush();
            Response build = httpConnection2.readResponse().request(request).build();
            httpConnection2.emptyResponseBody();
            int code = build.code();
            if (code != 200) {
                if (code == 407) {
                    Route route2 = this.route;
                    request = HttpAuthenticator.processAuthHeader(route2.address.authenticator, build, route2.proxy);
                } else {
                    throw new IOException("Unexpected response code for CONNECT: " + build.code());
                }
            } else if (buffer.buffer().size() > 0) {
                throw new IOException("TLS tunnel buffered too many bytes!");
            } else {
                return;
            }
        } while (request != null);
        throw new IOException("Failed to authenticate with proxy");
    }

    private void upgradeToTls(TunnelRequest tunnelRequest) {
        ByteString npnSelectedProtocol;
        Platform platform = Platform.get();
        if (requiresTunnel()) {
            makeTunnel(tunnelRequest);
        }
        Address address = this.route.address;
        this.socket = address.sslSocketFactory.createSocket(this.socket, address.uriHost, address.uriPort, true);
        SSLSocket sSLSocket = (SSLSocket) this.socket;
        Route route2 = this.route;
        if (route2.modernTls) {
            platform.enableTlsExtensions(sSLSocket, route2.address.uriHost);
        } else {
            platform.supportTlsIntolerantServer(sSLSocket);
        }
        Route route3 = this.route;
        boolean z = route3.modernTls && (route3.address.protocols.contains(Protocol.HTTP_2) || this.route.address.protocols.contains(Protocol.SPDY_3));
        if (z) {
            platform.setNpnProtocols(sSLSocket, (!this.route.address.protocols.contains(Protocol.HTTP_2) || !this.route.address.protocols.contains(Protocol.SPDY_3)) ? this.route.address.protocols.contains(Protocol.HTTP_2) ? Util.HTTP2_AND_HTTP_11 : Util.SPDY3_AND_HTTP11 : Util.HTTP2_SPDY3_AND_HTTP);
        }
        sSLSocket.startHandshake();
        Address address2 = this.route.address;
        if (address2.hostnameVerifier.verify(address2.uriHost, sSLSocket.getSession())) {
            this.out = sSLSocket.getOutputStream();
            this.in = sSLSocket.getInputStream();
            this.handshake = Handshake.get(sSLSocket.getSession());
            initSourceAndSink();
            Protocol protocol = Protocol.HTTP_11;
            if (z && (npnSelectedProtocol = platform.getNpnSelectedProtocol(sSLSocket)) != null) {
                protocol = Util.getProtocol(npnSelectedProtocol);
            }
            if (protocol.spdyVariant) {
                sSLSocket.setSoTimeout(0);
                this.spdyConnection = new SpdyConnection.Builder(this.route.address.getUriHost(), true, this.source, this.sink).protocol(protocol).build();
                this.spdyConnection.sendConnectionHeader();
                return;
            }
            this.httpConnection = new HttpConnection(this.pool, this, this.source, this.sink);
            return;
        }
        throw new IOException("Hostname '" + this.route.address.uriHost + "' was not verified");
    }

    public boolean clearOwner() {
        synchronized (this.pool) {
            if (this.owner == null) {
                return false;
            }
            this.owner = null;
            return true;
        }
    }

    public void close() {
        this.socket.close();
    }

    public void closeIfOwnedBy(Object obj) {
        if (!isSpdy()) {
            synchronized (this.pool) {
                if (this.owner == obj) {
                    this.owner = null;
                    this.socket.close();
                    return;
                }
                return;
            }
        }
        throw new IllegalStateException();
    }

    public void connect(int i, int i2, TunnelRequest tunnelRequest) {
        if (!this.connected) {
            this.socket = this.route.proxy.type() != Proxy.Type.HTTP ? new Socket(this.route.proxy) : new Socket();
            Platform.get().connectSocket(this.socket, this.route.inetSocketAddress, i);
            this.socket.setSoTimeout(i2);
            this.in = this.socket.getInputStream();
            this.out = this.socket.getOutputStream();
            if (this.route.address.sslSocketFactory != null) {
                upgradeToTls(tunnelRequest);
            } else {
                initSourceAndSink();
                this.httpConnection = new HttpConnection(this.pool, this, this.source, this.sink);
            }
            this.connected = true;
            return;
        }
        throw new IllegalStateException("already connected");
    }

    public Handshake getHandshake() {
        return this.handshake;
    }

    public int getHttpMinorVersion() {
        return this.httpMinorVersion;
    }

    public long getIdleStartTimeNs() {
        SpdyConnection spdyConnection2 = this.spdyConnection;
        return spdyConnection2 == null ? this.idleStartTimeNs : spdyConnection2.getIdleStartTimeNs();
    }

    public Object getOwner() {
        Object obj;
        synchronized (this.pool) {
            obj = this.owner;
        }
        return obj;
    }

    public Route getRoute() {
        return this.route;
    }

    public Socket getSocket() {
        return this.socket;
    }

    public void incrementRecycleCount() {
        this.recycleCount++;
    }

    public boolean isAlive() {
        return !this.socket.isClosed() && !this.socket.isInputShutdown() && !this.socket.isOutputShutdown();
    }

    public boolean isConnected() {
        return this.connected;
    }

    public boolean isExpired(long j) {
        return getIdleStartTimeNs() < System.nanoTime() - j;
    }

    public boolean isIdle() {
        SpdyConnection spdyConnection2 = this.spdyConnection;
        return spdyConnection2 == null || spdyConnection2.isIdle();
    }

    public boolean isReadable() {
        int soTimeout;
        if (this.source == null || isSpdy()) {
            return true;
        }
        try {
            soTimeout = this.socket.getSoTimeout();
            this.socket.setSoTimeout(1);
            if (this.source.exhausted()) {
                this.socket.setSoTimeout(soTimeout);
                return false;
            }
            this.socket.setSoTimeout(soTimeout);
            return true;
        } catch (SocketTimeoutException unused) {
            return true;
        } catch (IOException unused2) {
            return false;
        } catch (Throwable th) {
            this.socket.setSoTimeout(soTimeout);
            throw th;
        }
    }

    public boolean isSpdy() {
        return this.spdyConnection != null;
    }

    public Object newTransport(HttpEngine httpEngine) {
        SpdyConnection spdyConnection2 = this.spdyConnection;
        return spdyConnection2 != null ? new SpdyTransport(httpEngine, spdyConnection2) : new HttpTransport(httpEngine, this.httpConnection);
    }

    public int recycleCount() {
        return this.recycleCount;
    }

    public boolean requiresTunnel() {
        Route route2 = this.route;
        return route2.address.sslSocketFactory != null && route2.proxy.type() == Proxy.Type.HTTP;
    }

    public void resetIdleStartTime() {
        if (this.spdyConnection == null) {
            this.idleStartTimeNs = System.nanoTime();
            return;
        }
        throw new IllegalStateException("spdyConnection != null");
    }

    public void setHttpMinorVersion(int i) {
        this.httpMinorVersion = i;
    }

    public void setOwner(Object obj) {
        if (!isSpdy()) {
            synchronized (this.pool) {
                if (this.owner == null) {
                    this.owner = obj;
                } else {
                    throw new IllegalStateException("Connection already has an owner!");
                }
            }
        }
    }

    public void updateReadTimeout(int i) {
        if (this.connected) {
            this.socket.setSoTimeout(i);
            return;
        }
        throw new IllegalStateException("updateReadTimeout - not connected");
    }
}
