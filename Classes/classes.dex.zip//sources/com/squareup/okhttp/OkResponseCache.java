package com.squareup.okhttp;

import com.squareup.okhttp.internal.http.Request;
import com.squareup.okhttp.internal.http.Response;
import java.net.CacheRequest;

@Deprecated
public interface OkResponseCache {
    Response get(Request request);

    boolean maybeRemove(Request request);

    CacheRequest put(Response response);

    void trackConditionalCacheHit();

    void trackResponse(ResponseSource responseSource);

    void update(Response response, Response response2);
}
