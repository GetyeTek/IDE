package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class LibraryVersion {
    @b("version_code")
    private String versionCode;
    @b("version_english")
    private String versionEnglish;
    @b("version_name")
    private String versionName;

    public String getVersionCode() {
        return this.versionCode;
    }

    public String getVersionEnglish() {
        return this.versionEnglish;
    }

    public String getVersionName() {
        return this.versionName;
    }

    public void setVersionCode(String str) {
        this.versionCode = str;
    }

    public void setVersionEnglish(String str) {
        this.versionEnglish = str;
    }

    public void setVersionName(String str) {
        this.versionName = str;
    }
}
