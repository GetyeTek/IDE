package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class AudioLocation {
    private String baseUrl;
    private String cdn;
    private String priority;
    private String protocol;
    @b("root_path")
    private String rootPath;
    private String server;

    public String getBaseUrl() {
        return this.server + this.rootPath;
    }

    public String getCdn() {
        return this.cdn;
    }

    public String getPriority() {
        return this.priority;
    }

    public String getProtocol() {
        return this.protocol;
    }

    public String getRootPath() {
        return this.rootPath;
    }

    public String getServer() {
        return this.server;
    }

    public void setCdn(String str) {
        this.cdn = str;
    }

    public void setProtocol(String str) {
        this.protocol = str;
    }

    public void setRootPath(String str) {
        this.rootPath = str;
    }

    public void setServer(String str) {
        this.server = str;
    }
}
