package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class BookOrder {
    @b("book_code")
    private String bookCode;
    @b("book_name")
    private String bookName;
    @b("book_order")
    private String bookOrder;
    @b("dam_id_root")
    private String damId;

    public String getBookCode() {
        return this.bookCode;
    }

    public String getBookName() {
        return this.bookName;
    }

    public String getBookOrder() {
        return this.bookOrder;
    }

    public String getDamId() {
        return this.damId;
    }

    public void setBookCode(String str) {
        this.bookCode = str;
    }

    public void setBookName(String str) {
        this.bookName = str;
    }

    public void setBookOrder(String str) {
        this.bookOrder = str;
    }

    public void setDamId(String str) {
        this.damId = str;
    }
}
