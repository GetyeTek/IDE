package com.faithcomesbyhearing.dbt.model;

import java.util.List;

public class VerseInfo {
    private List<String> bookId;

    public List<String> getBookId() {
        return this.bookId;
    }

    public void setBookId(List<String> list) {
        this.bookId = list;
    }
}
