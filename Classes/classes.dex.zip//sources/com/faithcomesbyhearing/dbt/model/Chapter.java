package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class Chapter {
    @b("book_id")
    private String bookId;
    @b("chapter_id")
    private String chapterId;
    @b("chapter_name")
    private String chapterName;
    @b("dam_id")
    private String damId;
    @b("default")
    private String def;

    public String getBookId() {
        return this.bookId;
    }

    public String getChapterId() {
        return this.chapterId;
    }

    public String getChapterName() {
        return this.chapterName;
    }

    public String getDamId() {
        return this.damId;
    }

    public String getDef() {
        return this.def;
    }

    public void setBookId(String str) {
        this.bookId = str;
    }

    public void setChapterId(String str) {
        this.chapterId = str;
    }

    public void setChapterName(String str) {
        this.chapterName = str;
    }

    public void setDamId(String str) {
        this.damId = str;
    }

    public void setDef(String str) {
        this.def = str;
    }
}
