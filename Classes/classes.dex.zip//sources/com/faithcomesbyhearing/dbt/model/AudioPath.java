package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class AudioPath {
    @b("book_id")
    String bookId;
    @b("chapter_id")
    String chapterId;
    String path;

    public String getBookId() {
        return this.bookId;
    }

    public String getChapterId() {
        return this.chapterId;
    }

    public String getPath() {
        return this.path;
    }

    public void setBookId(String str) {
        this.bookId = str;
    }

    public void setChapterId(String str) {
        this.chapterId = str;
    }

    public void setPath(String str) {
        this.path = str;
    }
}
