package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;
import java.util.List;

public class Volume {
    @b("collection_name")
    private String collectionName;
    @b("dam_id")
    private String damId;
    @b("delivery")
    private List<String> deliveryTypes;
    private String expiration;
    @b("fcbh_id")
    private String fcbhId;
    @b("language_code")
    private String langaugeCode;
    @b("language_english")
    private String langaugeEnglish;
    @b("language_name")
    private String langaugeName;
    @b("language_family_code")
    private String languageFamilyCode;
    @b("language_family_english")
    private String languageFamilyEnglish;
    @b("language_family_iso")
    private String languageFamilyIso;
    @b("language_family_iso_2B")
    private String languageFamilyIsoTwoB;
    @b("language_family_iso_2T")
    private String languageFamilyIsoTwoT;
    @b("language_family_name")
    private String languageFamilyName;
    @b("language_family_iso_1")
    private String languageFamilyOne;
    @b("language_iso")
    private String languageIso;
    @b("language_iso_name")
    private String languageIsoName;
    @b("language_iso_1")
    private String languageIsoOne;
    @b("language_iso_2B")
    private String languageIsoTwoB;
    @b("language_iso_2T")
    private String languageIsoTwoT;
    private String media;
    @b("media_type")
    private String mediaType;
    @b("num_art")
    private long numberOfArtFiles;
    @b("num_sample_audio")
    private long numberOfSampleAudio;
    private List<String> resolution;
    @b("right_to_left")
    private Boolean rightToLeft;
    private String sku;
    private String status;
    @b("updated_on")
    private String updatedOn;
    @b("version_code")
    private String versionCode;
    @b("volume_name")
    private String volumeName;

    public String getCollectionName() {
        return this.collectionName;
    }

    public String getDamId() {
        return this.damId;
    }

    public List<String> getDeliveryTypes() {
        return this.deliveryTypes;
    }

    public String getExpiration() {
        return this.expiration;
    }

    public String getFcbhId() {
        return this.fcbhId;
    }

    public String getLangaugeCode() {
        return this.langaugeCode;
    }

    public String getLangaugeEnglish() {
        return this.langaugeEnglish;
    }

    public String getLangaugeName() {
        return this.langaugeName;
    }

    public String getLanguageFamilyCode() {
        return this.languageFamilyCode;
    }

    public String getLanguageFamilyEnglish() {
        return this.languageFamilyEnglish;
    }

    public String getLanguageFamilyIso() {
        return this.languageFamilyIso;
    }

    public String getLanguageFamilyIsoTwoB() {
        return this.languageFamilyIsoTwoB;
    }

    public String getLanguageFamilyIsoTwoT() {
        return this.languageFamilyIsoTwoT;
    }

    public String getLanguageFamilyName() {
        return this.languageFamilyName;
    }

    public String getLanguageFamilyOne() {
        return this.languageFamilyOne;
    }

    public String getLanguageIso() {
        return this.languageIso;
    }

    public String getLanguageIsoName() {
        return this.languageIsoName;
    }

    public String getLanguageIsoOne() {
        return this.languageIsoOne;
    }

    public String getLanguageIsoTwoB() {
        return this.languageIsoTwoB;
    }

    public String getLanguageIsoTwoT() {
        return this.languageIsoTwoT;
    }

    public String getMedia() {
        return this.media;
    }

    public String getMediaType() {
        return this.mediaType;
    }

    public long getNumberOfArtFiles() {
        return this.numberOfArtFiles;
    }

    public long getNumberOfSampleAudio() {
        return this.numberOfSampleAudio;
    }

    public List<String> getResolution() {
        return this.resolution;
    }

    public Boolean getRightToLeft() {
        return this.rightToLeft;
    }

    public String getSku() {
        return this.sku;
    }

    public String getStatus() {
        return this.status;
    }

    public String getUpdatedOn() {
        return this.updatedOn;
    }

    public String getVersionCode() {
        return this.versionCode;
    }

    public String getVolumeName() {
        return this.volumeName;
    }

    public void setCollectionName(String str) {
        this.collectionName = str;
    }

    public void setDamId(String str) {
        this.damId = str;
    }

    public void setDeliveryTypes(List<String> list) {
        this.deliveryTypes = list;
    }

    public void setExpiration(String str) {
        this.expiration = str;
    }

    public void setFcbhId(String str) {
        this.fcbhId = str;
    }

    public void setLangaugeCode(String str) {
        this.langaugeCode = str;
    }

    public void setLangaugeEnglish(String str) {
        this.langaugeEnglish = str;
    }

    public void setLangaugeName(String str) {
        this.langaugeName = str;
    }

    public void setLanguageFamilyCode(String str) {
        this.languageFamilyCode = str;
    }

    public void setLanguageFamilyEnglish(String str) {
        this.languageFamilyEnglish = str;
    }

    public void setLanguageFamilyIso(String str) {
        this.languageFamilyIso = str;
    }

    public void setLanguageFamilyIsoTwoB(String str) {
        this.languageFamilyIsoTwoB = str;
    }

    public void setLanguageFamilyIsoTwoT(String str) {
        this.languageFamilyIsoTwoT = str;
    }

    public void setLanguageFamilyName(String str) {
        this.languageFamilyName = str;
    }

    public void setLanguageFamilyOne(String str) {
        this.languageFamilyOne = str;
    }

    public void setLanguageIso(String str) {
        this.languageIso = str;
    }

    public void setLanguageIsoName(String str) {
        this.languageIsoName = str;
    }

    public void setLanguageIsoOne(String str) {
        this.languageIsoOne = str;
    }

    public void setLanguageIsoTwoB(String str) {
        this.languageIsoTwoB = str;
    }

    public void setLanguageIsoTwoT(String str) {
        this.languageIsoTwoT = str;
    }

    public void setMedia(String str) {
        this.media = str;
    }

    public void setMediaType(String str) {
        this.mediaType = str;
    }

    public void setNumberOfArtFiles(long j) {
        this.numberOfArtFiles = j;
    }

    public void setNumberOfSampleAudio(long j) {
        this.numberOfSampleAudio = j;
    }

    public void setResolution(List<String> list) {
        this.resolution = list;
    }

    public void setRightToLeft(Boolean bool) {
        this.rightToLeft = bool;
    }

    public void setSku(String str) {
        this.sku = str;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setUpdatedOn(String str) {
        this.updatedOn = str;
    }

    public void setVersionCode(String str) {
        this.versionCode = str;
    }

    public void setVolumeName(String str) {
        this.volumeName = str;
    }
}
