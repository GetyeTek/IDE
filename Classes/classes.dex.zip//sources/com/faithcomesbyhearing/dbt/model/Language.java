package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class Language {
    @b("english_name")
    private String englishName;
    @b("language_code")
    private String languageCode;
    @b("language_family_code")
    private String languageFamilyCode;
    @b("language_iso")
    private String languageIso;
    @b("language_iso_name")
    private String languageIsoName;
    @b("language_iso_1")
    private String languageIsoOne;
    @b("language_iso_2B")
    private String languageIsoTwoB;
    @b("language_iso_2T")
    private String languageIsoTwoT;
    @b("language_name")
    private String languageName;

    public String getEnglishName() {
        return this.englishName;
    }

    public String getLanguageCode() {
        return this.languageCode;
    }

    public String getLanguageFamilyCode() {
        return this.languageFamilyCode;
    }

    public String getLanguageIso() {
        return this.languageIso;
    }

    public String getLanguageIsoName() {
        return this.languageIsoName;
    }

    public String getLanguageIsoOne() {
        return this.languageIsoOne;
    }

    public String getLanguageIsoTwoB() {
        return this.languageIsoTwoB;
    }

    public String getLanguageIsoTwoT() {
        return this.languageIsoTwoT;
    }

    public String getLanguageName() {
        return this.languageName;
    }

    public void setEnglishName(String str) {
        this.englishName = str;
    }

    public void setLanguageCode(String str) {
        this.languageCode = str;
    }

    public void setLanguageFamilyCode(String str) {
        this.languageFamilyCode = str;
    }

    public void setLanguageIso(String str) {
        this.languageIso = str;
    }

    public void setLanguageIsoName(String str) {
        this.languageIsoName = str;
    }

    public void setLanguageIsoOne(String str) {
        this.languageIsoOne = str;
    }

    public void setLanguageIsoTwoB(String str) {
        this.languageIsoTwoB = str;
    }

    public void setLanguageIsoTwoT(String str) {
        this.languageIsoTwoT = str;
    }

    public void setLanguageName(String str) {
        this.languageName = str;
    }
}
