package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class Verse {
    @b("book_id")
    private String bookId;
    @b("book_name")
    private String bookName;
    @b("book_order")
    private String bookOrder;
    @b("chapter_id")
    private String chapterId;
    @b("chapter_title")
    private String chapterTitle;
    @b("paragraph_number")
    private String paragraphNumber;
    @b("verse_id")
    private String verseId;
    @b("verse_text")
    private String verseText;

    public String getBookId() {
        return this.bookId;
    }

    public String getBookName() {
        return this.bookName;
    }

    public String getBookOrder() {
        return this.bookOrder;
    }

    public String getChapterId() {
        return this.chapterId;
    }

    public String getChapterTitle() {
        return this.chapterTitle;
    }

    public String getParagraphNumber() {
        return this.paragraphNumber;
    }

    public String getVerseId() {
        return this.verseId;
    }

    public String getVerseText() {
        return this.verseText;
    }

    public void setBookId(String str) {
        this.bookId = str;
    }

    public void setBookName(String str) {
        this.bookName = str;
    }

    public void setBookOrder(String str) {
        this.bookOrder = str;
    }

    public void setChapterId(String str) {
        this.chapterId = str;
    }

    public void setChapterTitle(String str) {
        this.chapterTitle = str;
    }

    public void setParagraphNumber(String str) {
        this.paragraphNumber = str;
    }

    public void setVerseId(String str) {
        this.verseId = str;
    }

    public void setVerseText(String str) {
        this.verseText = str;
    }
}
