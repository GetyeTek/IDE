package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;
import java.util.List;

public class VolumeLanguageFamily {
    private List<String> delivery;
    private String language;
    @b("language_family_code")
    private String languageFamilyCode;
    @b("language_family_english")
    private String languageFamilyEnglish;
    @b("language_family_iso_1")
    private String languageFamilyIsoOne;
    @b("language_family_iso_2B")
    private String languageFamilyIsoTwoB;
    @b("language_family_iso_2T")
    private String languageFamilyIsoTwoT;
    @b("language_family_name")
    private String languageFamilyName;
    @b("language_family_iso")
    private String languageIsoFamilyIso;
    private List<String> media;
    private List<String> resolution;

    public List<String> getDelivery() {
        return this.delivery;
    }

    public String getLanguage() {
        return this.language;
    }

    public String getLanguageFamilyCode() {
        return this.languageFamilyCode;
    }

    public String getLanguageFamilyEnglish() {
        return this.languageFamilyEnglish;
    }

    public String getLanguageFamilyIsoOne() {
        return this.languageFamilyIsoOne;
    }

    public String getLanguageFamilyIsoTwoB() {
        return this.languageFamilyIsoTwoB;
    }

    public String getLanguageFamilyIsoTwoT() {
        return this.languageFamilyIsoTwoT;
    }

    public String getLanguageFamilyName() {
        return this.languageFamilyName;
    }

    public String getLanguageIsoFamilyIso() {
        return this.languageIsoFamilyIso;
    }

    public List<String> getMedia() {
        return this.media;
    }

    public List<String> getResolution() {
        return this.resolution;
    }

    public void setDelivery(List<String> list) {
        this.delivery = list;
    }

    public void setLanguage(String str) {
        this.language = str;
    }

    public void setLanguageFamilyCode(String str) {
        this.languageFamilyCode = str;
    }

    public void setLanguageFamilyEnglish(String str) {
        this.languageFamilyEnglish = str;
    }

    public void setLanguageFamilyIsoOne(String str) {
        this.languageFamilyIsoOne = str;
    }

    public void setLanguageFamilyIsoTwoB(String str) {
        this.languageFamilyIsoTwoB = str;
    }

    public void setLanguageFamilyIsoTwoT(String str) {
        this.languageFamilyIsoTwoT = str;
    }

    public void setLanguageFamilyName(String str) {
        this.languageFamilyName = str;
    }

    public void setLanguageIsoFamilyIso(String str) {
        this.languageIsoFamilyIso = str;
    }

    public void setMedia(List<String> list) {
        this.media = list;
    }

    public void setResolution(List<String> list) {
        this.resolution = list;
    }
}
