package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;
import java.util.List;

public class TextSearch {
    private List<TextSearchResult> results;
    @b("total_results")
    private long resultsReturned;

    public List<TextSearchResult> getResults() {
        return this.results;
    }

    public long getResultsReturned() {
        return this.resultsReturned;
    }

    public void setResults(List<TextSearchResult> list) {
        this.results = list;
    }

    public void setResultsReturned(long j) {
        this.resultsReturned = j;
    }
}
