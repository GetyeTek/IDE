package com.faithcomesbyhearing.dbt.model;

public class VideoLocation {
    private String protocol;
    private String server;

    public String getProtocol() {
        return this.protocol;
    }

    public String getServer() {
        return this.server;
    }

    public void setProtocol(String str) {
        this.protocol = str;
    }

    public void setServer(String str) {
        this.server = str;
    }
}
