package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class Asset {
    private String priority;
    @b("root_path")
    private String rootPath;
    private String server;
    @b("volume_id")
    private String volumeId;

    public String getPriority() {
        return this.priority;
    }

    public String getRootPath() {
        return this.rootPath;
    }

    public String getServer() {
        return this.server;
    }

    public String getVolumeId() {
        return this.volumeId;
    }

    public void setPriority(String str) {
        this.priority = str;
    }

    public void setRootPath(String str) {
        this.rootPath = str;
    }

    public void setServer(String str) {
        this.server = str;
    }

    public void setVolumeId(String str) {
        this.volumeId = str;
    }
}
