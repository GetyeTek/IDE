package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class VideoPath {
    @b("book_id")
    private String bookId;
    @b("chapter_end")
    private String chapterEnd;
    @b("chapter_start")
    private String chapterStart;
    private String path;
    private String references;
    @b("segment_order")
    private String segmentOrder;
    @b("thumbnail_image")
    private String thumbnailImage;
    private String title;
    @b("verse_end")
    private String verseEnd;
    @b("verse_start")
    private String verseStart;
    @b("video_type")
    private String videoType;

    public String getBookId() {
        return this.bookId;
    }

    public String getChapterEnd() {
        return this.chapterEnd;
    }

    public String getChapterStart() {
        return this.chapterStart;
    }

    public String getPath() {
        return this.path;
    }

    public String getReferences() {
        return this.references;
    }

    public String getSegmentOrder() {
        return this.segmentOrder;
    }

    public String getThumbnailImage() {
        return this.thumbnailImage;
    }

    public String getTitle() {
        return this.title;
    }

    public String getVerseEnd() {
        return this.verseEnd;
    }

    public String getVerseStart() {
        return this.verseStart;
    }

    public String getVideoType() {
        return this.videoType;
    }

    public void setBookId(String str) {
        this.bookId = str;
    }

    public void setChapterEnd(String str) {
        this.chapterEnd = str;
    }

    public void setChapterStart(String str) {
        this.chapterStart = str;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public void setReferences(String str) {
        this.references = str;
    }

    public void setSegmentOrder(String str) {
        this.segmentOrder = str;
    }

    public void setThumbnailImage(String str) {
        this.thumbnailImage = str;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public void setVerseEnd(String str) {
        this.verseEnd = str;
    }

    public void setVerseStart(String str) {
        this.verseStart = str;
    }

    public void setVideoType(String str) {
        this.videoType = str;
    }
}
