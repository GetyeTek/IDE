package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class Book {
    @b("book_id")
    private String bookId;
    @b("book_name")
    private String bookName;
    @b("book_order")
    private String bookOrder;
    @b("dam_id_root")
    private String damIdRoot;
    @b("number_of_chapters")
    private long numberOfChapters;

    public String getBookId() {
        return this.bookId;
    }

    public String getBookName() {
        return this.bookName;
    }

    public String getBookOrder() {
        return this.bookOrder;
    }

    public String getDamIdRoot() {
        return this.damIdRoot;
    }

    public long getNumberOfChapters() {
        return this.numberOfChapters;
    }

    public void setBookId(String str) {
        this.bookId = str;
    }

    public void setBookName(String str) {
        this.bookName = str;
    }

    public void setBookOrder(String str) {
        this.bookOrder = str;
    }

    public void setDamIdRoot(String str) {
        this.damIdRoot = str;
    }

    public void setNumberOfChapters(long j) {
        this.numberOfChapters = j;
    }
}
