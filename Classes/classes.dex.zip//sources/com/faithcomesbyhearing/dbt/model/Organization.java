package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class Organization {
    private String description;
    @b("donation_url")
    private String donationUrl;
    private String enabled;
    @b("english_description")
    private String englishDescription;
    @b("english_name")
    private String englishName;
    private String id;
    private String name;
    @b("web_url")
    private String webUrl;

    public String getDescription() {
        return this.description;
    }

    public String getDonationUrl() {
        return this.donationUrl;
    }

    public String getEnabled() {
        return this.enabled;
    }

    public String getEnglishDescription() {
        return this.englishDescription;
    }

    public String getEnglishName() {
        return this.englishName;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getWebUrl() {
        return this.webUrl;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public void setDonationUrl(String str) {
        this.donationUrl = str;
    }

    public void setEnabled(String str) {
        this.enabled = str;
    }

    public void setEnglishDescription(String str) {
        this.englishDescription = str;
    }

    public void setEnglishName(String str) {
        this.englishName = str;
    }

    public void setId(String str) {
        this.id = str;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setWebUrl(String str) {
        this.webUrl = str;
    }
}
