package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;

public class VerseStart {
    @b("verse_id")
    private String verseId;
    @b("verse_start")
    private String verseStart;

    public String getVerseId() {
        return this.verseId;
    }

    public String getVerseStart() {
        return this.verseStart;
    }

    public void setVerseId(String str) {
        this.verseId = str;
    }

    public void setVerseStart(String str) {
        this.verseStart = str;
    }
}
