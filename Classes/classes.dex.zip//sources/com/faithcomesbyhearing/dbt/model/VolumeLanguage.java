package com.faithcomesbyhearing.dbt.model;

import b.c.a.a.b;
import java.util.List;

public class VolumeLanguage {
    private List<String> delivery;
    @b("english_name")
    private String englishName;
    @b("language_code")
    private String languageCode;
    @b("language_family_code")
    private String languageFamilyCode;
    @b("language_family_english")
    private String languageFamilyEnglish;
    @b("language_family_iso")
    private String languageFamilyIso;
    @b("language_family_iso_1")
    private String languageFamilyIsoOne;
    @b("language_family_iso_2B")
    private String languageFamilyIsoTwoB;
    @b("language_family_iso_2T")
    private String languageFamilyIsoTwoT;
    @b("language_family_name")
    private String languageFamilyName;
    @b("language_iso")
    private String languageIso;
    @b("language_iso_name")
    private String languageIsoName;
    @b("language_iso_1")
    private String languageIsoOne;
    @b("language_iso_2B")
    private String languageIsoTwoB;
    @b("language_iso_2T")
    private String languageIsoTwoT;
    @b("language_name")
    private String languageName;
    private List<String> media;
    private List<String> resolution;

    public List<String> getDelivery() {
        return this.delivery;
    }

    public String getEnglishName() {
        return this.englishName;
    }

    public String getLanguageCode() {
        return this.languageCode;
    }

    public String getLanguageFamilyCode() {
        return this.languageFamilyCode;
    }

    public String getLanguageFamilyEnglish() {
        return this.languageFamilyEnglish;
    }

    public String getLanguageFamilyIso() {
        return this.languageFamilyIso;
    }

    public String getLanguageFamilyIsoOne() {
        return this.languageFamilyIsoOne;
    }

    public String getLanguageFamilyIsoTwoB() {
        return this.languageFamilyIsoTwoB;
    }

    public String getLanguageFamilyIsoTwoT() {
        return this.languageFamilyIsoTwoT;
    }

    public String getLanguageFamilyName() {
        return this.languageFamilyName;
    }

    public String getLanguageIso() {
        return this.languageIso;
    }

    public String getLanguageIsoName() {
        return this.languageIsoName;
    }

    public String getLanguageIsoOne() {
        return this.languageIsoOne;
    }

    public String getLanguageIsoTwoB() {
        return this.languageIsoTwoB;
    }

    public String getLanguageIsoTwoT() {
        return this.languageIsoTwoT;
    }

    public String getLanguageName() {
        return this.languageName;
    }

    public List<String> getMedia() {
        return this.media;
    }

    public List<String> getResolution() {
        return this.resolution;
    }

    public void setDelivery(List<String> list) {
        this.delivery = list;
    }

    public void setEnglishName(String str) {
        this.englishName = str;
    }

    public void setLanguageCode(String str) {
        this.languageCode = str;
    }

    public void setLanguageFamilyCode(String str) {
        this.languageFamilyCode = str;
    }

    public void setLanguageFamilyEnglish(String str) {
        this.languageFamilyEnglish = str;
    }

    public void setLanguageFamilyIso(String str) {
        this.languageFamilyIso = str;
    }

    public void setLanguageFamilyIsoOne(String str) {
        this.languageFamilyIsoOne = str;
    }

    public void setLanguageFamilyIsoTwoB(String str) {
        this.languageFamilyIsoTwoB = str;
    }

    public void setLanguageFamilyIsoTwoT(String str) {
        this.languageFamilyIsoTwoT = str;
    }

    public void setLanguageFamilyName(String str) {
        this.languageFamilyName = str;
    }

    public void setLanguageIso(String str) {
        this.languageIso = str;
    }

    public void setLanguageIsoName(String str) {
        this.languageIsoName = str;
    }

    public void setLanguageIsoOne(String str) {
        this.languageIsoOne = str;
    }

    public void setLanguageIsoTwoB(String str) {
        this.languageIsoTwoB = str;
    }

    public void setLanguageIsoTwoT(String str) {
        this.languageIsoTwoT = str;
    }

    public void setLanguageName(String str) {
        this.languageName = str;
    }

    public void setMedia(List<String> list) {
        this.media = list;
    }

    public void setResolution(List<String> list) {
        this.resolution = list;
    }
}
