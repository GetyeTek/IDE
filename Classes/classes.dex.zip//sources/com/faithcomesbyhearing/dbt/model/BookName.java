package com.faithcomesbyhearing.dbt.model;

import java.util.HashMap;

public class BookName {
    private HashMap<String, String> bookNames;

    public HashMap<String, String> getBookNames() {
        return this.bookNames;
    }

    public void setBookNames(HashMap<String, String> hashMap) {
        this.bookNames = hashMap;
    }
}
