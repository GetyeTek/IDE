package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseIntArray;

class c extends b {

    /* renamed from: a  reason: collision with root package name */
    private final SparseIntArray f1477a;

    /* renamed from: b  reason: collision with root package name */
    private final Parcel f1478b;

    /* renamed from: c  reason: collision with root package name */
    private final int f1479c;
    private final int d;
    private final String e;
    private int f;
    private int g;

    c(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "");
    }

    c(Parcel parcel, int i, int i2, String str) {
        this.f1477a = new SparseIntArray();
        this.f = -1;
        this.g = 0;
        this.f1478b = parcel;
        this.f1479c = i;
        this.d = i2;
        this.g = this.f1479c;
        this.e = str;
    }

    private int d(int i) {
        int readInt;
        do {
            int i2 = this.g;
            if (i2 >= this.d) {
                return -1;
            }
            this.f1478b.setDataPosition(i2);
            int readInt2 = this.f1478b.readInt();
            readInt = this.f1478b.readInt();
            this.g += readInt2;
        } while (readInt != i);
        return this.f1478b.dataPosition();
    }

    public void a() {
        int i = this.f;
        if (i >= 0) {
            int i2 = this.f1477a.get(i);
            int dataPosition = this.f1478b.dataPosition();
            this.f1478b.setDataPosition(i2);
            this.f1478b.writeInt(dataPosition - i2);
            this.f1478b.setDataPosition(dataPosition);
        }
    }

    public void a(Parcelable parcelable) {
        this.f1478b.writeParcelable(parcelable, 0);
    }

    public void a(String str) {
        this.f1478b.writeString(str);
    }

    public void a(byte[] bArr) {
        if (bArr != null) {
            this.f1478b.writeInt(bArr.length);
            this.f1478b.writeByteArray(bArr);
            return;
        }
        this.f1478b.writeInt(-1);
    }

    public boolean a(int i) {
        int d2 = d(i);
        if (d2 == -1) {
            return false;
        }
        this.f1478b.setDataPosition(d2);
        return true;
    }

    /* access modifiers changed from: protected */
    public b b() {
        Parcel parcel = this.f1478b;
        int dataPosition = parcel.dataPosition();
        int i = this.g;
        if (i == this.f1479c) {
            i = this.d;
        }
        return new c(parcel, dataPosition, i, this.e + "  ");
    }

    public void b(int i) {
        a();
        this.f = i;
        this.f1477a.put(i, this.f1478b.dataPosition());
        c(0);
        c(i);
    }

    public void c(int i) {
        this.f1478b.writeInt(i);
    }

    public byte[] d() {
        int readInt = this.f1478b.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f1478b.readByteArray(bArr);
        return bArr;
    }

    public int e() {
        return this.f1478b.readInt();
    }

    public <T extends Parcelable> T f() {
        return this.f1478b.readParcelable(c.class.getClassLoader());
    }

    public String g() {
        return this.f1478b.readString();
    }
}
