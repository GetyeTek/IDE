package androidx.media;

import android.support.v4.media.AudioAttributesCompat;
import androidx.versionedparcelable.b;
import androidx.versionedparcelable.d;

public final class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(b bVar) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        audioAttributesCompat.f772c = (a) bVar.a(audioAttributesCompat.f772c, 1);
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, b bVar) {
        bVar.a(false, false);
        bVar.b((d) audioAttributesCompat.f772c, 1);
    }
}
