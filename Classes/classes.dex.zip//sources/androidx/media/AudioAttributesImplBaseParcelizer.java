package androidx.media;

import androidx.versionedparcelable.b;

public final class AudioAttributesImplBaseParcelizer {
    public static c read(b bVar) {
        c cVar = new c();
        cVar.f788a = bVar.a(cVar.f788a, 1);
        cVar.f789b = bVar.a(cVar.f789b, 2);
        cVar.f790c = bVar.a(cVar.f790c, 3);
        cVar.d = bVar.a(cVar.d, 4);
        return cVar;
    }

    public static void write(c cVar, b bVar) {
        bVar.a(false, false);
        bVar.b(cVar.f788a, 1);
        bVar.b(cVar.f789b, 2);
        bVar.b(cVar.f790c, 3);
        bVar.b(cVar.d, 4);
    }
}
