package L8;

import M4.c;
import P8.a;
import java.io.IOException;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;

public final class b {
    public static final ReentrantLock l = new ReentrantLock();
    public static b m = null;
    public a a;
    public SocketChannel b;
    public R8.b c;
    public R8.a d;
    public byte[] e;
    public boolean f;
    public boolean g;
    public long h;
    public ArrayList<M8.b> i;
    public Random j;
    public boolean k;

    /* JADX WARNING: type inference failed for: r1v1, types: [L8.b, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v2, types: [java.lang.Object, R8.a] */
    public static b b() {
        b bVar = m;
        if (bVar != null) {
            return bVar;
        }
        ReentrantLock reentrantLock = l;
        reentrantLock.lock();
        b bVar2 = m;
        if (bVar2 != null) {
            return bVar2;
        }
        ? obj = new Object();
        obj.a = new a();
        obj.c = new R8.b();
        obj.d = new Object();
        obj.i = new ArrayList<>();
        obj.k = false;
        obj.f = false;
        obj.g = true;
        obj.h = System.currentTimeMillis();
        obj.j = new Random();
        obj.k = false;
        m = obj;
        reentrantLock.unlock();
        return m;
    }

    /* JADX WARNING: type inference failed for: r3v20, types: [java.lang.Object, R8.a] */
    /* JADX WARNING: type inference failed for: r4v5, types: [java.lang.Object, R8.a] */
    /* JADX WARNING: type inference failed for: r15v2, types: [O8.a, com.onemdos.base.component.aace.handler.a] */
    /* JADX WARNING: type inference failed for: r6v25, types: [O8.a, com.onemdos.base.component.aace.handler.a] */
    /* JADX WARNING: Removed duplicated region for block: B:119:0x0289  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x028e  */
    /* JADX WARNING: Removed duplicated region for block: B:131:0x02d7 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x02d9  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00f1  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0134  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x0192  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x01dc  */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x0231  */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x0234  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.nio.channels.SocketChannel a(boolean r23, S8.a r24) {
        /*
            r22 = this;
            r0 = r22
            r1 = 0
            r2 = 1
            boolean r3 = r0.f
            java.lang.String r5 = "ConnectHolder"
            if (r3 == 0) goto L_0x0041
            java.nio.channels.SocketChannel r3 = r0.b
            if (r3 == 0) goto L_0x0041
            boolean r3 = r3.isConnected()
            if (r3 == 0) goto L_0x0041
            if (r23 != 0) goto L_0x0041
            long r6 = java.lang.System.currentTimeMillis()
            long r8 = r0.h
            long r6 = r6 - r8
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r8 = "reConnect diff="
            r3.<init>(r8)
            r3.append(r6)
            java.lang.String r3 = r3.toString()
            M4.c.b(r5, r3)
            r3 = 30000(0x7530, float:4.2039E-41)
            long r8 = (long) r3
            int r3 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r3 <= 0) goto L_0x003e
            java.lang.String r3 = "force shutdown socket"
            M4.c.b(r5, r3)
            r22.e()
            goto L_0x0041
        L_0x003e:
            r1 = 1
            goto L_0x02d5
        L_0x0041:
            boolean r3 = r0.k
            if (r3 == 0) goto L_0x0047
            goto L_0x02d5
        L_0x0047:
            java.lang.String r3 = "start reConnect"
            M4.c.b(r5, r3)
            r3 = r24
            r3.a = r2
            r0.k = r2
            r22.e()
            java.lang.String r3 = J8.a.a
            int r6 = J8.a.b
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            java.lang.String r8 = "ConnectHolder connectSrv host:"
            r7.<init>(r8)
            r7.append(r3)
            java.lang.String r8 = " port:"
            r7.append(r8)
            r7.append(r6)
            java.lang.String r7 = r7.toString()
            M4.c.b(r5, r7)
            r22.e()
            P8.a r7 = r0.a
            if (r3 == 0) goto L_0x00b3
            boolean r8 = r3.isEmpty()
            if (r8 == 0) goto L_0x0080
            goto L_0x00b3
        L_0x0080:
            r7.a()
            java.nio.channels.SocketChannel r8 = java.nio.channels.SocketChannel.open()     // Catch:{ all -> 0x00b0 }
            r8.configureBlocking(r1)     // Catch:{ all -> 0x00b0 }
            java.net.InetSocketAddress r9 = new java.net.InetSocketAddress     // Catch:{ all -> 0x00b0 }
            r9.<init>(r3, r6)     // Catch:{ all -> 0x00b0 }
            boolean r3 = r8.connect(r9)     // Catch:{ all -> 0x00b0 }
            if (r3 != 0) goto L_0x00b5
            long r9 = java.lang.System.currentTimeMillis()     // Catch:{ all -> 0x00b0 }
        L_0x0099:
            boolean r3 = r8.finishConnect()     // Catch:{ all -> 0x00b0 }
            if (r3 != 0) goto L_0x00b5
            long r11 = java.lang.System.currentTimeMillis()     // Catch:{ all -> 0x00b0 }
            long r11 = r11 - r9
            r13 = 1000(0x3e8, double:4.94E-321)
            int r3 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r3 >= 0) goto L_0x00b0
            r11 = 100
            java.lang.Thread.sleep(r11)     // Catch:{ all -> 0x00b0 }
            goto L_0x0099
        L_0x00b0:
            r7.b()
        L_0x00b3:
            r8 = 0
            goto L_0x00ec
        L_0x00b5:
            r8.configureBlocking(r2)     // Catch:{ all -> 0x00b0 }
            r0.b = r8     // Catch:{ all -> 0x00b0 }
            java.util.concurrent.locks.Condition r3 = r7.b     // Catch:{ all -> 0x00b0 }
            r3.signalAll()     // Catch:{ all -> 0x00b0 }
            r7.b()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r6 = "ConnectHolder connectSrv success channel = "
            r3.<init>(r6)
            java.nio.channels.SocketChannel r6 = r0.b
            java.net.Socket r6 = r6.socket()
            if (r6 == 0) goto L_0x00e0
            java.nio.channels.SocketChannel r6 = r0.b
            java.net.Socket r6 = r6.socket()
            int r6 = r6.getLocalPort()
            java.lang.String r6 = java.lang.String.valueOf(r6)
            goto L_0x00e2
        L_0x00e0:
            java.lang.String r6 = "0"
        L_0x00e2:
            r3.append(r6)
            java.lang.String r3 = r3.toString()
            M4.c.b(r5, r3)
        L_0x00ec:
            if (r8 != 0) goto L_0x00f1
        L_0x00ee:
            r2 = 0
            goto L_0x02d2
        L_0x00f1:
            java.lang.String r3 = "ConnectHolder exchangeKey"
            M4.c.b(r5, r3)
            java.nio.channels.SocketChannel r3 = r0.b
            if (r3 != 0) goto L_0x00fb
            goto L_0x00ee
        L_0x00fb:
            O8.a r3 = O8.a.b
            if (r3 == 0) goto L_0x0101
        L_0x00ff:
            r8 = r3
            goto L_0x0119
        L_0x0101:
            java.util.concurrent.locks.ReentrantLock r3 = O8.a.a
            r3.lock()
            O8.a r6 = O8.a.b
            if (r6 == 0) goto L_0x010c
            r8 = r6
            goto L_0x0119
        L_0x010c:
            O8.a r6 = new O8.a
            r6.<init>()
            O8.a.b = r6
            r3.unlock()
            O8.a r3 = O8.a.b
            goto L_0x00ff
        L_0x0119:
            byte[] r11 = new byte[r2]
            r11[r1] = r1
            r12 = 10000(0x2710, float:1.4013E-41)
            r13 = 0
            java.lang.String r9 = "IMCore"
            java.lang.String r10 = "gk"
            P8.d r3 = r8.invoke(r9, r10, r11, r12, r13)
            int r6 = r3.a
            java.lang.String r8 = "PACK_LENGTH_ERROR"
            r9 = 5
            java.lang.String r10 = "PACK_TYPEMATCH_ERROR"
            r11 = 3
            if (r6 == 0) goto L_0x0134
        L_0x0132:
            r3 = 0
            goto L_0x017a
        L_0x0134:
            Q8.c r6 = new Q8.c
            r6.<init>()
            byte[] r3 = r3.b
            r6.o(r3)
            long r13 = r6.w()     // Catch:{ PackException -> 0x0175 }
            int r3 = (int) r13
            byte r13 = r6.t()     // Catch:{ PackException -> 0x015f }
            if (r13 < r2) goto L_0x0167
            Q8.b r13 = r6.v()     // Catch:{ PackException -> 0x015f }
            byte r13 = r13.a     // Catch:{ PackException -> 0x015f }
            boolean r13 = Q8.c.f(r13, r11)     // Catch:{ PackException -> 0x015f }
            if (r13 == 0) goto L_0x0161
            java.lang.String r6 = r6.x()     // Catch:{ PackException -> 0x015f }
            r21 = r6
            r6 = r3
            r3 = r21
            goto L_0x017a
        L_0x015f:
            goto L_0x016d
        L_0x0161:
            com.onemdos.base.component.aace.packer.PackException r6 = new com.onemdos.base.component.aace.packer.PackException     // Catch:{ PackException -> 0x015f }
            r6.<init>(r9, r10)     // Catch:{ PackException -> 0x015f }
            throw r6     // Catch:{ PackException -> 0x015f }
        L_0x0167:
            com.onemdos.base.component.aace.packer.PackException r6 = new com.onemdos.base.component.aace.packer.PackException     // Catch:{ PackException -> 0x015f }
            r6.<init>(r11, r8)     // Catch:{ PackException -> 0x015f }
            throw r6     // Catch:{ PackException -> 0x015f }
        L_0x016d:
            if (r3 == 0) goto L_0x0171
            r6 = r3
            goto L_0x0132
        L_0x0171:
            r6 = -90006(0xfffffffffffea06a, float:NaN)
            goto L_0x0132
        L_0x0175:
            r3 = 0
            r6 = -90006(0xfffffffffffea06a, float:NaN)
        L_0x017a:
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            java.lang.String r14 = "getPublicKey iRet:"
            r13.<init>(r14)
            r13.append(r6)
            java.lang.String r13 = r13.toString()
            M4.c.b(r5, r13)
            if (r6 == 0) goto L_0x0192
            r22.e()
            goto L_0x00ee
        L_0x0192:
            R8.b r6 = r0.c
            r6.getClass()
            byte[] r3 = android.util.Base64.decode(r3, r1)     // Catch:{ all -> 0x01ac }
            java.security.spec.X509EncodedKeySpec r13 = new java.security.spec.X509EncodedKeySpec     // Catch:{ all -> 0x01ac }
            r13.<init>(r3)     // Catch:{ all -> 0x01ac }
            java.lang.String r3 = "RSA"
            java.security.KeyFactory r3 = java.security.KeyFactory.getInstance(r3)     // Catch:{ all -> 0x01ac }
            java.security.PublicKey r3 = r3.generatePublic(r13)     // Catch:{ all -> 0x01ac }
            r6.b = r3     // Catch:{ all -> 0x01ac }
        L_0x01ac:
            java.lang.String r3 = "getPublicKey gk success"
            M4.c.b(r5, r3)
            r3 = 16
            byte[] r13 = new byte[r3]
            java.util.Random r14 = r0.j
            r14.nextBytes(r13)
            java.lang.Object r14 = r6.b
            java.security.PublicKey r14 = (java.security.PublicKey) r14
            if (r14 != 0) goto L_0x01c2
        L_0x01c0:
            r6 = 0
            goto L_0x01d6
        L_0x01c2:
            java.lang.String r14 = "RSA/ECB/PKCS1Padding"
            javax.crypto.Cipher r14 = javax.crypto.Cipher.getInstance(r14)     // Catch:{ Exception -> 0x01d4 }
            java.lang.Object r6 = r6.b     // Catch:{ Exception -> 0x01d4 }
            java.security.PublicKey r6 = (java.security.PublicKey) r6     // Catch:{ Exception -> 0x01d4 }
            r14.init(r2, r6)     // Catch:{ Exception -> 0x01d4 }
            byte[] r6 = r14.doFinal(r13)     // Catch:{ Exception -> 0x01d4 }
            goto L_0x01d6
        L_0x01d4:
            goto L_0x01c0
        L_0x01d6:
            O8.a r14 = O8.a.b
            if (r14 == 0) goto L_0x01dc
        L_0x01da:
            r15 = r14
            goto L_0x01f3
        L_0x01dc:
            java.util.concurrent.locks.ReentrantLock r14 = O8.a.a
            r14.lock()
            O8.a r15 = O8.a.b
            if (r15 == 0) goto L_0x01e6
            goto L_0x01f3
        L_0x01e6:
            O8.a r15 = new O8.a
            r15.<init>()
            O8.a.b = r15
            r14.unlock()
            O8.a r14 = O8.a.b
            goto L_0x01da
        L_0x01f3:
            r15.getClass()
            Q8.c r14 = new Q8.c
            r14.<init>()
            int r16 = Q8.c.e(r6)
            int r16 = r16 + 3
            long r3 = (long) r2
            int r3 = Q8.c.c(r3)
            int r3 = r3 + r16
            byte[] r3 = new byte[r3]
            r14.p(r3)
            r4 = 2
            r14.g(r4)
            r12 = 8
            r14.g(r12)
            r14.h(r6)
            r14.g(r4)
            r14.i(r2)
            java.lang.String r16 = "IMCore"
            java.lang.String r17 = "ek"
            r19 = 10000(0x2710, float:1.4013E-41)
            r20 = 0
            r18 = r3
            P8.d r3 = r15.invoke(r16, r17, r18, r19, r20)
            int r4 = r3.a
            if (r4 == 0) goto L_0x0234
            r12 = r4
        L_0x0232:
            r4 = 0
            goto L_0x0276
        L_0x0234:
            Q8.c r4 = new Q8.c
            r4.<init>()
            byte[] r3 = r3.b
            r4.o(r3)
            long r14 = r4.w()     // Catch:{ PackException -> 0x0271 }
            int r3 = (int) r14
            byte r6 = r4.t()     // Catch:{ PackException -> 0x025b }
            if (r6 < r2) goto L_0x0263
            Q8.b r6 = r4.v()     // Catch:{ PackException -> 0x025b }
            byte r6 = r6.a     // Catch:{ PackException -> 0x025b }
            boolean r6 = Q8.c.f(r6, r12)     // Catch:{ PackException -> 0x025b }
            if (r6 == 0) goto L_0x025d
            byte[] r4 = r4.u()     // Catch:{ PackException -> 0x025b }
            r12 = r3
            goto L_0x0276
        L_0x025b:
            goto L_0x0269
        L_0x025d:
            com.onemdos.base.component.aace.packer.PackException r4 = new com.onemdos.base.component.aace.packer.PackException     // Catch:{ PackException -> 0x025b }
            r4.<init>(r9, r10)     // Catch:{ PackException -> 0x025b }
            throw r4     // Catch:{ PackException -> 0x025b }
        L_0x0263:
            com.onemdos.base.component.aace.packer.PackException r4 = new com.onemdos.base.component.aace.packer.PackException     // Catch:{ PackException -> 0x025b }
            r4.<init>(r11, r8)     // Catch:{ PackException -> 0x025b }
            throw r4     // Catch:{ PackException -> 0x025b }
        L_0x0269:
            if (r3 == 0) goto L_0x026d
            r12 = r3
            goto L_0x0232
        L_0x026d:
            r12 = -90006(0xfffffffffffea06a, float:NaN)
            goto L_0x0232
        L_0x0271:
            r4 = 0
            r12 = -90006(0xfffffffffffea06a, float:NaN)
        L_0x0276:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r6 = "ConnectHolder exchangeKey iRet:"
            r3.<init>(r6)
            r3.append(r12)
            java.lang.String r3 = r3.toString()
            M4.c.b(r5, r3)
            if (r12 == 0) goto L_0x028e
            r22.e()
            goto L_0x00ee
        L_0x028e:
            java.lang.String r3 = "exchangeKey ek success"
            M4.c.b(r5, r3)
            r7.a()
            R8.a r3 = new R8.a
            r3.<init>()
            javax.crypto.spec.SecretKeySpec r5 = new javax.crypto.spec.SecretKeySpec
            java.lang.String r6 = "AES"
            r5.<init>(r13, r6)
            r3.a = r5
            byte[] r3 = r3.a(r4)
            r0.e = r3
            R8.a r4 = r0.d
            if (r4 != 0) goto L_0x02b5
            R8.a r4 = new R8.a
            r4.<init>()
            r0.d = r4
        L_0x02b5:
            R8.a r4 = r0.d
            r4.getClass()
            if (r3 == 0) goto L_0x02c9
            int r5 = r3.length
            r8 = 16
            if (r5 == r8) goto L_0x02c2
            goto L_0x02c9
        L_0x02c2:
            javax.crypto.spec.SecretKeySpec r5 = new javax.crypto.spec.SecretKeySpec
            r5.<init>(r3, r6)
            r4.a = r5
        L_0x02c9:
            r0.f = r2
            r7.b()
            r0.k = r1
            r0.g = r2
        L_0x02d2:
            r0.k = r1
            r1 = r2
        L_0x02d5:
            if (r1 != 0) goto L_0x02d9
            r1 = 0
            return r1
        L_0x02d9:
            java.nio.channels.SocketChannel r1 = r22.c()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: L8.b.a(boolean, S8.a):java.nio.channels.SocketChannel");
    }

    public final SocketChannel c() {
        a aVar = this.a;
        aVar.a();
        if (this.b == null) {
            try {
                aVar.b.awaitNanos(500000000);
            } catch (InterruptedException unused) {
            }
        }
        SocketChannel socketChannel = this.b;
        aVar.b();
        return socketChannel;
    }

    public final void d(SocketChannel socketChannel) {
        c.b("ConnectHolder", "channelClose ConnectHolder shutdown...");
        ArrayList<M8.b> arrayList = null;
        if (socketChannel != null) {
            try {
                socketChannel.close();
            } catch (IOException unused) {
            }
            a aVar = this.a;
            aVar.a();
            if (this.b == socketChannel) {
                this.f = false;
                this.e = null;
                this.b = null;
                arrayList = this.i;
            }
            aVar.b();
        } else {
            e();
        }
        if (arrayList != null) {
            Iterator<M8.b> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().a();
            }
        }
    }

    public final void e() {
        c.b("ConnectHolder", "channelClose ConnectHolder shutdownConnect...");
        if (this.b == null) {
            this.f = false;
            this.e = null;
            return;
        }
        a aVar = this.a;
        aVar.a();
        SocketChannel socketChannel = this.b;
        this.b = null;
        try {
            socketChannel.close();
        } catch (IOException unused) {
        }
        this.f = false;
        this.e = null;
        aVar.b();
    }
}
