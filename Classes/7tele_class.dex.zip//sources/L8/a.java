package L8;

import N8.b;
import N8.c;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import com.huawei.payment.base.App;
import com.onemdos.base.component.aace.handler.d;
import com.onemdos.base.component.aace.handler.e;
import com.onemdos.base.component.aace.handler.f;
import com.onemdos.base.component.aace.handler.g;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public final class a {
    public static final AtomicInteger k = new AtomicInteger(0);
    public static final ReentrantLock l = new ReentrantLock();
    public static a m = null;
    public boolean a;
    public N8.a b;
    public b c;
    public c d;
    public d e;
    public f f;
    public com.onemdos.base.component.aace.handler.c g;
    public e h;
    public g i;
    public K8.a j;

    public static long b() {
        AtomicInteger atomicInteger = k;
        int incrementAndGet = atomicInteger.incrementAndGet();
        if (incrementAndGet < 0) {
            incrementAndGet = 0;
            atomicInteger.set(0);
        }
        return ((System.currentTimeMillis() / 1000) << 31) + ((long) incrementAndGet);
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Object, L8.a] */
    /* JADX WARNING: type inference failed for: r4v0, types: [java.lang.Thread, N8.a] */
    /* JADX WARNING: type inference failed for: r4v1, types: [java.lang.Object, N8.c] */
    /* JADX WARNING: type inference failed for: r6v1, types: [N8.c$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v1, types: [java.lang.Thread, N8.b] */
    /* JADX WARNING: type inference failed for: r2v2, types: [com.onemdos.base.component.aace.handler.d, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v3, types: [com.onemdos.base.component.aace.handler.e, java.lang.Thread] */
    /* JADX WARNING: type inference failed for: r2v4, types: [com.onemdos.base.component.aace.handler.f, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v5, types: [java.lang.Object, com.onemdos.base.component.aace.handler.c] */
    /* JADX WARNING: type inference failed for: r2v6, types: [java.lang.Thread, com.onemdos.base.component.aace.handler.g] */
    public static a c() {
        a aVar = m;
        if (aVar != null) {
            return aVar;
        }
        ReentrantLock reentrantLock = l;
        reentrantLock.lock();
        a aVar2 = m;
        if (aVar2 != null) {
            return aVar2;
        }
        ? obj = new Object();
        obj.a = false;
        obj.j = null;
        ? thread = new Thread();
        thread.a = obj;
        thread.setDaemon(true);
        thread.setName("AACE-MsgReader");
        obj.b = thread;
        ? obj2 = new Object();
        ? obj3 = new Object();
        obj3.a = false;
        obj3.b = 0;
        obj2.b = obj3;
        obj2.a = obj;
        obj.d = obj2;
        ? thread2 = new Thread();
        thread2.d = new ArrayBlockingQueue<>(128);
        thread2.a = obj;
        thread2.b = null;
        thread2.c = -1;
        thread2.setName("AACE-MsgSender");
        obj.c = thread2;
        ? obj4 = new Object();
        obj4.a = new ReentrantReadWriteLock();
        obj4.b = new HashMap<>();
        obj.e = obj4;
        ? thread3 = new Thread();
        thread3.b = new ArrayBlockingQueue<>(128);
        thread3.a = obj;
        thread3.setName("AACE-MsgDispatcher");
        thread3.setDaemon(true);
        obj.h = thread3;
        ? obj5 = new Object();
        obj5.a = new ReentrantReadWriteLock();
        obj5.b = new HashMap<>();
        obj5.c = new ReentrantLock();
        obj5.d = new P8.f<>();
        obj.f = obj5;
        ? obj6 = new Object();
        obj6.a = 0;
        obj.g = obj6;
        ? thread4 = new Thread();
        thread4.a = new P8.f<>();
        thread4.setName("AACE-TimerHandler");
        thread4.setDaemon(true);
        obj.i = thread4;
        m = obj;
        reentrantLock.unlock();
        return m;
    }

    public final int a(long j2, int i2, String str, String str2, boolean z, byte[] bArr, boolean z2) {
        boolean z3;
        NetworkInfo activeNetworkInfo;
        long j3 = j2;
        int i3 = i2;
        String str3 = str;
        String str4 = str2;
        byte[] bArr2 = bArr;
        App app = J8.b.a().a;
        if (app == null || (activeNetworkInfo = ((ConnectivityManager) app.getSystemService("connectivity")).getActiveNetworkInfo()) == null || !activeNetworkInfo.isConnectedOrConnecting()) {
            z3 = false;
        } else {
            z3 = true;
        }
        f fVar = this.f;
        if (z3 || i3 != 0) {
            Q8.a aVar = new Q8.a();
            aVar.c = (byte) i3;
            aVar.d = j3;
            aVar.a = str3;
            aVar.b = str4;
            Log.e("AaceMgr.Request", str3 + str4);
            byte[] bArr3 = new byte[(aVar.size() + bArr2.length)];
            Q8.c cVar = new Q8.c();
            cVar.p(bArr3);
            aVar.packData(cVar);
            System.arraycopy(bArr2, 0, bArr3, cVar.d, bArr2.length);
            if (!this.c.b(new P8.e(1, bArr3, z2))) {
                if (i3 == 0) {
                    P8.c d2 = fVar.d(j3, str3, str4);
                    if (!z && d2 != null) {
                        P8.d dVar = new P8.d(-90002);
                        d2.e = dVar;
                        M8.a aVar2 = d2.f;
                        if (aVar2 != null) {
                            try {
                                aVar2.__process(dVar);
                            } catch (Throwable unused) {
                            }
                        }
                    }
                }
                Log.e("AaceMgr.Request", str3 + str4 + "---RET_FAIL");
                return -90002;
            }
            Log.e("AaceMgr.Request", str3 + str4 + "---RET_SUCCESS");
            return 0;
        }
        P8.c d3 = fVar.d(j3, str3, str4);
        if (!z && d3 != null) {
            P8.d dVar2 = new P8.d(-90002);
            d3.e = dVar2;
            M8.a aVar3 = d3.f;
            if (aVar3 != null) {
                try {
                    aVar3.__process(dVar2);
                } catch (Throwable unused2) {
                }
            }
        }
        return -90002;
    }

    /* JADX WARNING: type inference failed for: r5v5, types: [com.onemdos.base.component.aace.handler.d$b, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v3, types: [com.onemdos.base.component.aace.handler.d$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r3v0, types: [com.onemdos.base.component.aace.handler.d$b, java.lang.Object] */
    public final boolean d(String str, String str2, com.onemdos.base.component.aace.handler.b bVar, String str3) {
        boolean z;
        d dVar = this.e;
        ReentrantReadWriteLock reentrantReadWriteLock = dVar.a;
        reentrantReadWriteLock.writeLock().lock();
        HashMap<String, d.a> hashMap = dVar.b;
        d.a aVar = hashMap.get(str);
        if (aVar == null) {
            ? obj = new Object();
            obj.a = bVar;
            HashMap<String, d.b> hashMap2 = new HashMap<>();
            obj.b = hashMap2;
            ? obj2 = new Object();
            obj2.a = str3;
            hashMap2.put(str2, obj2);
            hashMap.put(str, obj);
        } else if (aVar.b.containsKey(str2)) {
            z = false;
            reentrantReadWriteLock.writeLock().unlock();
            return z;
        } else {
            ? obj3 = new Object();
            obj3.a = str3;
            aVar.b.put(str2, obj3);
        }
        z = true;
        reentrantReadWriteLock.writeLock().unlock();
        return z;
    }

    public final void e(SocketChannel socketChannel) {
        M4.c.b("AaceMgr", "channelClose AaceMgr shutdown...");
        if (socketChannel != null) {
            P8.e eVar = new P8.e(0, (byte[]) null, false);
            eVar.e = socketChannel;
            this.c.b(eVar);
        } else {
            b.b().e();
        }
        c.a aVar = this.d.b;
        aVar.a = false;
        aVar.b = 0;
        aVar.c = null;
    }
}
