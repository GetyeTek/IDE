package ia;

import fa.z;

/* renamed from: ia.c  reason: case insensitive filesystem */
public final class C0294c {
    public static final z a = new z("STATE_REG");
    public static final z b = new z("STATE_COMPLETED");
    public static final z c = new z("STATE_CANCELLED");
}
