package ia;

/* renamed from: ia.b  reason: case insensitive filesystem */
public interface C0293b<R> {
    boolean a(Object obj, Object obj2);
}
