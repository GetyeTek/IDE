package ia;

import H9.j;
import J9.a;
import ca.C0119g;
import ca.C0120h;
import ca.E0;
import fa.x;
import fa.z;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.collections.r;
import kotlin.jvm.internal.h;

/* renamed from: ia.a  reason: case insensitive filesystem */
public final class C0292a<R> extends C0119g implements C0293b, E0 {
    public static final AtomicReferenceFieldUpdater a = AtomicReferenceFieldUpdater.newUpdater(C0292a.class, Object.class, "state");
    private volatile Object state;

    /* renamed from: ia.a$a  reason: collision with other inner class name */
    public final class C0031a {
    }

    public final boolean a(Object obj, Object obj2) {
        if (d(obj) == 0) {
            return true;
        }
        return false;
    }

    public final void c(Throwable th) {
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = a;
            Object obj = atomicReferenceFieldUpdater.get(this);
            if (obj != C0294c.b) {
                z zVar = C0294c.c;
                while (true) {
                    if (!atomicReferenceFieldUpdater.compareAndSet(this, obj, zVar)) {
                        if (atomicReferenceFieldUpdater.get(this) != obj) {
                        }
                    } else {
                        return;
                    }
                }
            } else {
                return;
            }
        }
    }

    public final int d(Object obj) {
        boolean z;
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = a;
            Object obj2 = atomicReferenceFieldUpdater.get(this);
            if (!(obj2 instanceof C0120h)) {
                if (h.a(obj2, C0294c.b)) {
                    z = true;
                } else {
                    z = obj2 instanceof C0031a;
                }
                if (z) {
                    return 3;
                }
                if (h.a(obj2, C0294c.c)) {
                    return 2;
                }
                boolean z2 = false;
                if (h.a(obj2, C0294c.a)) {
                    List f = a.f(obj);
                    while (true) {
                        if (!atomicReferenceFieldUpdater.compareAndSet(this, obj2, f)) {
                            if (atomicReferenceFieldUpdater.get(this) != obj2) {
                                break;
                            }
                        } else {
                            z2 = true;
                            break;
                        }
                    }
                    if (z2) {
                        return 1;
                    }
                } else if (obj2 instanceof List) {
                    ArrayList A = r.A((Collection) obj2, obj);
                    while (true) {
                        if (!atomicReferenceFieldUpdater.compareAndSet(this, obj2, A)) {
                            if (atomicReferenceFieldUpdater.get(this) != obj2) {
                                break;
                            }
                        } else {
                            z2 = true;
                            break;
                        }
                    }
                    if (z2) {
                        return 1;
                    }
                } else {
                    throw new IllegalStateException(("Unexpected state: " + obj2).toString());
                }
            }
        }
    }

    public final /* bridge */ /* synthetic */ Object invoke(Object obj) {
        c((Throwable) obj);
        return j.a;
    }

    public final void b(x<?> xVar, int i) {
    }
}
