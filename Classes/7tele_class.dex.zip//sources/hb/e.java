package hb;

public interface e extends C0290a {
    c a();
}
