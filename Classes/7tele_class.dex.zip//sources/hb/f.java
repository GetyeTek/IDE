package hb;

import java.math.BigInteger;

public final class f implements C0290a {
    public final BigInteger a;

    public f(BigInteger bigInteger) {
        this.a = bigInteger;
    }

    public final int b() {
        return 1;
    }

    public final BigInteger c() {
        return this.a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        return this.a.equals(((f) obj).a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}
