package hb;

import java.math.BigInteger;

public abstract class b {
    public static final f a = new f(BigInteger.valueOf(2));
    public static final f b = new f(BigInteger.valueOf(3));
}
