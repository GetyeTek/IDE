package hb;

import java.math.BigInteger;

/* renamed from: hb.a  reason: case insensitive filesystem */
public interface C0290a {
    int b();

    BigInteger c();
}
