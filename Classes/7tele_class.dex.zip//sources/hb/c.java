package hb;

import java.util.Arrays;
import org.bouncycastle.util.a;

public final class c {
    public final int[] a;

    public c(int[] iArr) {
        this.a = (int[]) iArr.clone();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        return Arrays.equals(this.a, ((c) obj).a);
    }

    public final int hashCode() {
        return a.i(this.a);
    }
}
