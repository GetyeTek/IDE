package hb;

import java.math.BigInteger;
import org.bouncycastle.util.a;

public final class d implements e {
    public final f a;
    public final c b;

    public d(f fVar, c cVar) {
        this.a = fVar;
        this.b = cVar;
    }

    public final c a() {
        return this.b;
    }

    public final int b() {
        this.a.getClass();
        int[] iArr = this.b.a;
        return iArr[iArr.length - 1];
    }

    public final BigInteger c() {
        return this.a.a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        if (!this.a.equals(dVar.a) || !this.b.equals(dVar.b)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.a.a.hashCode() ^ Integer.rotateLeft(a.i(this.b.a), 16);
    }
}
