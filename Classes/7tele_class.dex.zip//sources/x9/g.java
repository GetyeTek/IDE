package x9;

@FunctionalInterface
public interface g<T> {
}
