package x9;

@FunctionalInterface
public interface j<T> {
    void a(l<? super T> lVar);
}
