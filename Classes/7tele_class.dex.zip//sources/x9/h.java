package x9;

import A9.f;
import C9.b;
import Qa.c;
import io.reactivex.rxjava3.internal.operators.observable.e;
import io.reactivex.rxjava3.internal.operators.observable.g;
import io.reactivex.rxjava3.internal.operators.observable.l;
import io.reactivex.rxjava3.internal.operators.observable.n;
import io.reactivex.rxjava3.internal.operators.observable.o;
import io.reactivex.rxjava3.internal.operators.observable.r;
import io.reactivex.rxjava3.operators.d;
import java.util.Objects;

public abstract class h<T> implements j<T> {

    public static /* synthetic */ class a {
        public static final /* synthetic */ int[] a;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            /*
                io.reactivex.rxjava3.core.BackpressureStrategy[] r0 = io.reactivex.rxjava3.core.BackpressureStrategy.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                a = r0
                io.reactivex.rxjava3.core.BackpressureStrategy r1 = io.reactivex.rxjava3.core.BackpressureStrategy.DROP     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x001d }
                io.reactivex.rxjava3.core.BackpressureStrategy r1 = io.reactivex.rxjava3.core.BackpressureStrategy.LATEST     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0028 }
                io.reactivex.rxjava3.core.BackpressureStrategy r1 = io.reactivex.rxjava3.core.BackpressureStrategy.MISSING     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0033 }
                io.reactivex.rxjava3.core.BackpressureStrategy r1 = io.reactivex.rxjava3.core.BackpressureStrategy.ERROR     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: x9.h.a.<clinit>():void");
        }
    }

    public static l d(Object obj) {
        Objects.requireNonNull(obj, "item is null");
        return new l(obj);
    }

    public final void a(l<? super T> lVar) {
        try {
            f(lVar);
        } catch (NullPointerException e) {
            throw e;
        } catch (Throwable th) {
            c.d(th);
            E9.a.a(th);
            NullPointerException nullPointerException = new NullPointerException("Actually not, but can't throw other exceptions due to RS");
            nullPointerException.initCause(th);
            throw nullPointerException;
        }
    }

    public final <R> h<R> b(k<? super T, ? extends R> kVar) {
        Objects.requireNonNull(kVar, "composer is null");
        j<? extends R> a2 = kVar.a(this);
        Objects.requireNonNull(a2, "source is null");
        if (a2 instanceof h) {
            return (h) a2;
        }
        return new g(a2);
    }

    public final <R> h<R> c(f<? super T, ? extends j<? extends R>> fVar) {
        h<R> fVar2;
        int i = d.a;
        b.h(Integer.MAX_VALUE, "maxConcurrency");
        b.h(i, "bufferSize");
        if (this instanceof d) {
            Object obj = ((d) this).get();
            if (obj == null) {
                return e.a;
            }
            fVar2 = new o<>(obj, fVar);
        } else {
            fVar2 = new io.reactivex.rxjava3.internal.operators.observable.f<>(this, fVar, i);
        }
        return fVar2;
    }

    public final n e(m mVar) {
        int i = d.a;
        Objects.requireNonNull(mVar, "scheduler is null");
        b.h(i, "bufferSize");
        return new n(this, mVar, i);
    }

    public abstract void f(l<? super T> lVar);

    public final r g(m mVar) {
        Objects.requireNonNull(mVar, "scheduler is null");
        return new r(this, mVar);
    }
}
