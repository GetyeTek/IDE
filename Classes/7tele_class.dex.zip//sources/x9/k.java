package x9;

@FunctionalInterface
public interface k<Upstream, Downstream> {
    j<Downstream> a(h<Upstream> hVar);
}
