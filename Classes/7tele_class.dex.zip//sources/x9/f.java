package x9;

import y9.C0477b;

public interface f<T> {
    void onComplete();

    void onError(Throwable th);

    void onSubscribe(C0477b bVar);
}
