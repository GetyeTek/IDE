package x9;

import y9.C0477b;

public interface b {
    void onComplete();

    void onError(Throwable th);

    void onSubscribe(C0477b bVar);
}
