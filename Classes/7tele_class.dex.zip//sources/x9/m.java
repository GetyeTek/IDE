package x9;

import io.reactivex.rxjava3.internal.disposables.SequentialDisposable;
import io.reactivex.rxjava3.internal.operators.observable.n;
import io.reactivex.rxjava3.internal.operators.observable.r;
import io.reactivex.rxjava3.internal.schedulers.f;
import java.util.concurrent.TimeUnit;
import y9.C0477b;

public abstract class m {
    public static final boolean a = Boolean.getBoolean("rx3.scheduler.use-nanotime");
    public static final long b;

    public static final class a implements C0477b, Runnable {
        public final r.b a;
        public final b b;
        public Thread c;

        public a(r.b bVar, b bVar2) {
            this.a = bVar;
            this.b = bVar2;
        }

        public final void dispose() {
            if (this.c == Thread.currentThread()) {
                b bVar = this.b;
                if (bVar instanceof f) {
                    f fVar = (f) bVar;
                    if (!fVar.b) {
                        fVar.b = true;
                        fVar.a.shutdown();
                        return;
                    }
                    return;
                }
            }
            this.b.dispose();
        }

        public final boolean isDisposed() {
            return this.b.isDisposed();
        }

        public final void run() {
            this.c = Thread.currentThread();
            try {
                this.a.run();
                dispose();
                this.c = null;
            } catch (Throwable th) {
                dispose();
                this.c = null;
                throw th;
            }
        }
    }

    public static abstract class b implements C0477b {

        public final class a implements Runnable {
            public final Object a;
            public final SequentialDisposable b;
            public final long c;
            public long d;
            public long e;
            public long f;

            public a(long j, Runnable runnable, long j2, SequentialDisposable sequentialDisposable, long j3) {
                this.a = runnable;
                this.b = sequentialDisposable;
                this.c = j3;
                this.e = j2;
                this.f = j;
            }

            /* JADX WARNING: type inference failed for: r1v0, types: [java.lang.Object, java.lang.Runnable] */
            public final void run() {
                long j;
                this.a.run();
                SequentialDisposable sequentialDisposable = this.b;
                if (!sequentialDisposable.isDisposed()) {
                    TimeUnit timeUnit = TimeUnit.NANOSECONDS;
                    b bVar = b.this;
                    bVar.getClass();
                    long a2 = b.a(timeUnit);
                    long j2 = m.b;
                    long j3 = this.e;
                    long j4 = this.c;
                    if (a2 + j2 < j3 || a2 >= j3 + j4 + j2) {
                        j = a2 + j4;
                        long j5 = this.d + 1;
                        this.d = j5;
                        this.f = j - (j4 * j5);
                    } else {
                        long j6 = this.f;
                        long j7 = this.d + 1;
                        this.d = j7;
                        j = (j7 * j4) + j6;
                    }
                    this.e = a2;
                    sequentialDisposable.replace(bVar.b(this, j - a2, timeUnit));
                }
            }
        }

        public static long a(TimeUnit timeUnit) {
            if (!m.a) {
                return timeUnit.convert(System.currentTimeMillis(), TimeUnit.MILLISECONDS);
            }
            return timeUnit.convert(System.nanoTime(), TimeUnit.NANOSECONDS);
        }

        public abstract C0477b b(Runnable runnable, long j, TimeUnit timeUnit);

        public void c(n.a aVar) {
            b(aVar, 0, TimeUnit.NANOSECONDS);
        }
    }

    static {
        long j;
        long longValue = Long.getLong("rx3.scheduler.drift-tolerance", 15).longValue();
        String property = System.getProperty("rx3.scheduler.drift-tolerance-unit", "minutes");
        if ("seconds".equalsIgnoreCase(property)) {
            j = TimeUnit.SECONDS.toNanos(longValue);
        } else if ("milliseconds".equalsIgnoreCase(property)) {
            j = TimeUnit.MILLISECONDS.toNanos(longValue);
        } else {
            j = TimeUnit.MINUTES.toNanos(longValue);
        }
        b = j;
    }

    public abstract b a();

    public C0477b b(r.b bVar) {
        return c(bVar, TimeUnit.NANOSECONDS);
    }

    public C0477b c(r.b bVar, TimeUnit timeUnit) {
        b a2 = a();
        a aVar = new a(bVar, a2);
        a2.b(aVar, 0, timeUnit);
        return aVar;
    }
}
