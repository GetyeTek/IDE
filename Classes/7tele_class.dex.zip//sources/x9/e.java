package x9;

public abstract class e<T> implements g<T> {
}
