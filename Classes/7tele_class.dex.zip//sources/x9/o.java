package x9;

import y9.C0477b;

public interface o<T> {
    void onError(Throwable th);

    void onSubscribe(C0477b bVar);
}
