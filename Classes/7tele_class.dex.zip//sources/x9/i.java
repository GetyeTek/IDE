package x9;

import io.reactivex.rxjava3.internal.operators.observable.c;

@FunctionalInterface
public interface i<T> {
    void a(c.a aVar) throws Throwable;
}
