package x9;

public abstract class n<T> {
}
