package x9;

/* renamed from: x9.a  reason: case insensitive filesystem */
public abstract class C0472a {
}
