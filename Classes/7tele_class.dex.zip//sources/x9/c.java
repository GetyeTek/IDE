package x9;

public interface c<T> {
}
