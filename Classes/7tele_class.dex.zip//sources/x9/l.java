package x9;

import y9.C0477b;

public interface l<T> {
    void onComplete();

    void onError(Throwable th);

    void onNext(T t);

    void onSubscribe(C0477b bVar);
}
