package x9;

import bc.a;

public abstract class d<T> implements a<T> {
    public static final int a = Math.max(1, Integer.getInteger("rx3.buffer-size", 128).intValue());
}
