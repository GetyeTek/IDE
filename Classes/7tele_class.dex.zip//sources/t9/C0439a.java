package t9;

import n9.C0409a;

/* renamed from: t9.a  reason: case insensitive filesystem */
public interface C0439a<T> extends C0440b<T>, C0409a {
}
