package t9;

/* renamed from: t9.d  reason: case insensitive filesystem */
public interface C0442d<T> {
}
