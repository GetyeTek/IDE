package t9;

import bc.c;

/* renamed from: t9.c  reason: case insensitive filesystem */
public interface C0441c<T> extends C0440b<T>, c {
}
