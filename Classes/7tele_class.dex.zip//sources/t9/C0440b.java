package t9;

/* renamed from: t9.b  reason: case insensitive filesystem */
public interface C0440b<T> extends C0442d<T> {
    int requestFusion(int i);
}
