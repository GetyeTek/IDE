package P8;

public final class b {
    public com.onemdos.base.component.aace.handler.b a;
    public String b;
}
