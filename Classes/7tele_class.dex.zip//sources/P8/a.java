package P8;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public final class a {
    public final ReentrantLock a;
    public final Condition b;

    public a() {
        ReentrantLock reentrantLock = new ReentrantLock();
        this.a = reentrantLock;
        this.b = reentrantLock.newCondition();
    }

    public final void a() {
        this.a.lock();
    }

    public final void b() {
        this.a.unlock();
    }
}
