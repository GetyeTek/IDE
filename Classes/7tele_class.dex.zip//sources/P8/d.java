package P8;

public final class d {
    public int a;
    public byte[] b = null;

    public d(int i) {
        this.a = i;
    }
}
