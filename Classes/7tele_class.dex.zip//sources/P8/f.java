package P8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

public final class f<K> {
    public final HashMap<K, Long> a = new HashMap<>();
    public final TreeMap<Long, LinkedList<K>> b = new TreeMap<>();

    public final ArrayList<K> a(int i) {
        ArrayList<K> arrayList;
        long currentTimeMillis = System.currentTimeMillis();
        if (i > 0) {
            arrayList = new ArrayList<>(i);
        } else {
            arrayList = new ArrayList<>();
        }
        int i2 = 0;
        loop0:
        for (Map.Entry next : this.b.entrySet()) {
            if (((Long) next.getKey()).longValue() >= currentTimeMillis) {
                break;
            }
            LinkedList linkedList = (LinkedList) next.getValue();
            if (linkedList != null) {
                Iterator it = linkedList.iterator();
                while (it.hasNext()) {
                    arrayList.add(it.next());
                    i2++;
                    if (i > 0 && i2 >= i) {
                        break loop0;
                    }
                }
                continue;
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        Iterator<K> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            c(it2.next());
        }
        return arrayList;
    }

    public final void b(int i, Object obj) {
        long currentTimeMillis = System.currentTimeMillis() + ((long) i);
        HashMap<K, Long> hashMap = this.a;
        if (hashMap.containsKey(obj)) {
            c(obj);
        }
        hashMap.put(obj, Long.valueOf(currentTimeMillis));
        TreeMap<Long, LinkedList<K>> treeMap = this.b;
        LinkedList linkedList = treeMap.get(Long.valueOf(currentTimeMillis));
        if (linkedList == null) {
            LinkedList linkedList2 = new LinkedList();
            linkedList2.add(obj);
            treeMap.put(Long.valueOf(currentTimeMillis), linkedList2);
            return;
        }
        linkedList.add(obj);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x000b, code lost:
        r1 = r3.b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(java.lang.Object r4) {
        /*
            r3 = this;
            java.util.HashMap<K, java.lang.Long> r0 = r3.a
            java.lang.Object r0 = r0.remove(r4)
            java.lang.Long r0 = (java.lang.Long) r0
            if (r0 != 0) goto L_0x000b
            return
        L_0x000b:
            java.util.TreeMap<java.lang.Long, java.util.LinkedList<K>> r1 = r3.b
            java.lang.Object r2 = r1.get(r0)
            java.util.LinkedList r2 = (java.util.LinkedList) r2
            if (r2 != 0) goto L_0x0016
            return
        L_0x0016:
            boolean r4 = r2.remove(r4)
            if (r4 == 0) goto L_0x0025
            boolean r4 = r2.isEmpty()
            if (r4 == 0) goto L_0x0025
            r1.remove(r0)
        L_0x0025:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: P8.f.c(java.lang.Object):void");
    }
}
