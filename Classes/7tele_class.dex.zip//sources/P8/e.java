package P8;

import java.nio.channels.SocketChannel;

public final class e {
    public final int a;
    public final byte[] b;
    public final long c;
    public final boolean d;
    public SocketChannel e;

    public e() {
        this.a = 1;
        this.b = null;
        this.c = System.currentTimeMillis();
        this.d = true;
    }

    public e(int i) {
        this.a = i;
        this.b = null;
        this.c = System.currentTimeMillis();
        this.d = true;
    }

    public e(int i, byte[] bArr, boolean z) {
        this.a = i;
        this.b = bArr;
        this.c = System.currentTimeMillis();
        this.d = z;
    }
}
