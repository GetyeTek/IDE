package Ea;

import Da.a;
import Ub.c;
import Ub.d;
import V1.h;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.blankj.utilcode.util.J;
import com.huawei.kbz.base.BaseActivity;
import java.io.IOException;
import java.util.Hashtable;
import la.C0331E;
import la.C0336J;
import la.C0364g;
import la.C0394y;
import org.bouncycastle.util.g;

public final class b {
    public static String a;

    public static void a(StringBuffer stringBuffer, Da.b bVar, Hashtable hashtable) {
        boolean z = true;
        if (bVar.a.a.length > 1) {
            a[] i = bVar.i();
            for (int i2 = 0; i2 != i.length; i2++) {
                if (z) {
                    z = false;
                } else {
                    stringBuffer.append('+');
                }
                b(stringBuffer, i[i2], hashtable);
            }
        } else if (bVar.h() != null) {
            b(stringBuffer, bVar.h(), hashtable);
        }
    }

    public static void b(StringBuffer stringBuffer, a aVar, Hashtable hashtable) {
        String str = (String) hashtable.get(aVar.a);
        if (str == null) {
            str = aVar.a.a;
        }
        stringBuffer.append(str);
        stringBuffer.append('=');
        stringBuffer.append(i(aVar.b));
    }

    public static String c(C0364g gVar) {
        String i = i(gVar);
        if (i.length() > 0 && i.charAt(0) == '#') {
            try {
                C0394y m = C0394y.m(c.b(i.length() - 1, i));
                if (m instanceof C0331E) {
                    i = ((C0331E) m).c();
                }
            } catch (IOException e) {
                throw new IllegalStateException("unknown encoding in name: " + e);
            }
        }
        String c = g.c(i);
        int length = c.length();
        if (length < 2) {
            return c;
        }
        int i2 = length - 1;
        int i3 = 0;
        while (i3 < i2 && c.charAt(i3) == '\\' && c.charAt(i3 + 1) == ' ') {
            i3 += 2;
        }
        int i4 = i3 + 1;
        int i5 = i2;
        while (i5 > i4 && c.charAt(i5 - 1) == '\\' && c.charAt(i5) == ' ') {
            i5 -= 2;
        }
        if (i3 > 0 || i5 < i2) {
            c = c.substring(i3, i5 + 1);
        }
        if (c.indexOf("  ") < 0) {
            return c;
        }
        StringBuffer stringBuffer = new StringBuffer();
        char charAt = c.charAt(0);
        stringBuffer.append(charAt);
        for (int i6 = 1; i6 < c.length(); i6++) {
            char charAt2 = c.charAt(i6);
            if (charAt != ' ' || charAt2 != ' ') {
                stringBuffer.append(charAt2);
                charAt = charAt2;
            }
        }
        return stringBuffer.toString();
    }

    public static boolean d(Intent intent) {
        return J.a().getPackageManager().queryIntentActivities(intent, 65536).isEmpty();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(2:17|18) */
    /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
        V1.h.b();
        r5 = "error!";
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0069 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String e() {
        /*
            java.lang.String r0 = a
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 == 0) goto L_0x0089
            android.app.Application r0 = com.blankj.utilcode.util.J.a()
            android.app.Application r1 = com.blankj.utilcode.util.J.a()
            java.lang.String r1 = r1.getPackageName()
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            r3 = 0
            android.content.pm.PackageManager r0 = r0.getPackageManager()     // Catch:{ NameNotFoundException -> 0x0027 }
            r4 = 64
            android.content.pm.PackageInfo r0 = r0.getPackageInfo(r1, r4)     // Catch:{ NameNotFoundException -> 0x0027 }
            android.content.pm.Signature[] r0 = r0.signatures     // Catch:{ NameNotFoundException -> 0x0027 }
            goto L_0x002f
        L_0x0027:
            r0 = move-exception
            r0.getMessage()     // Catch:{ Exception -> 0x0074 }
            V1.h.b()     // Catch:{ Exception -> 0x0074 }
            r0 = 0
        L_0x002f:
            if (r0 == 0) goto L_0x007b
            int r1 = r0.length     // Catch:{ Exception -> 0x0074 }
            r4 = 0
        L_0x0033:
            if (r4 >= r1) goto L_0x007b
            r5 = r0[r4]     // Catch:{ Exception -> 0x0074 }
            java.lang.String r6 = "SHA256"
            byte[] r5 = r5.toByteArray()     // Catch:{ Exception -> 0x0074 }
            java.security.MessageDigest r6 = java.security.MessageDigest.getInstance(r6)     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            byte[] r5 = r6.digest(r5)     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            r6.<init>()     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            int r7 = r5.length     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            r8 = 0
        L_0x004c:
            if (r8 >= r7) goto L_0x0064
            byte r9 = r5[r8]     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            r9 = r9 & 255(0xff, float:3.57E-43)
            r9 = r9 | 256(0x100, float:3.59E-43)
            java.lang.String r9 = java.lang.Integer.toHexString(r9)     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            r10 = 3
            r11 = 1
            java.lang.String r9 = r9.substring(r11, r10)     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            r6.append(r9)     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            int r8 = r8 + 1
            goto L_0x004c
        L_0x0064:
            java.lang.String r5 = r6.toString()     // Catch:{ NoSuchAlgorithmException -> 0x0069 }
            goto L_0x006e
        L_0x0069:
            V1.h.b()     // Catch:{ Exception -> 0x0074 }
            java.lang.String r5 = "error!"
        L_0x006e:
            r2.add(r5)     // Catch:{ Exception -> 0x0074 }
            int r4 = r4 + 1
            goto L_0x0033
        L_0x0074:
            r0 = move-exception
            r0.getMessage()
            V1.h.b()
        L_0x007b:
            int r0 = r2.size()
            if (r0 <= 0) goto L_0x0089
            java.lang.Object r0 = r2.get(r3)
            java.lang.String r0 = (java.lang.String) r0
            a = r0
        L_0x0089:
            java.lang.String r0 = a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: Ea.b.e():java.lang.String");
    }

    public static void f(Activity activity) {
        Intent intent = new Intent();
        intent.addFlags(268435456);
        intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", activity.getPackageName(), (String) null));
        try {
            activity.startActivity(intent);
        } catch (Exception e) {
            e.toString();
            h.b();
        }
    }

    public static void g(Context context, String str, String str2, n6.a aVar, String str3, n6.b bVar) {
        m6.b bVar2 = new m6.b(context);
        bVar2.h = str;
        bVar2.g = 17;
        bVar2.i = str2;
        bVar2.r = aVar;
        bVar2.j = str3;
        bVar2.s = bVar;
        bVar2.a();
    }

    public static void h(BaseActivity baseActivity, String str, String str2) {
        m6.b bVar = new m6.b(baseActivity);
        bVar.h = str;
        bVar.g = 3;
        bVar.j = str2;
        bVar.s = null;
        bVar.a();
    }

    public static String i(C0364g gVar) {
        int i;
        int i2;
        StringBuffer stringBuffer = new StringBuffer();
        int i3 = 0;
        if (!(gVar instanceof C0331E) || (gVar instanceof C0336J)) {
            try {
                stringBuffer.append('#');
                byte[] g = gVar.b().g();
                d dVar = c.a;
                stringBuffer.append(g.a(c.d(0, g.length, g)));
            } catch (IOException unused) {
                throw new IllegalArgumentException("Other value has no encoded form");
            }
        } else {
            String c = ((C0331E) gVar).c();
            if (c.length() > 0 && c.charAt(0) == '#') {
                stringBuffer.append('\\');
            }
            stringBuffer.append(c);
        }
        int length = stringBuffer.length();
        if (stringBuffer.length() >= 2 && stringBuffer.charAt(0) == '\\' && stringBuffer.charAt(1) == '#') {
            i = 2;
        } else {
            i = 0;
        }
        while (i != length) {
            char charAt = stringBuffer.charAt(i);
            if (!(charAt == '\"' || charAt == '\\' || charAt == '+' || charAt == ',')) {
                switch (charAt) {
                    case ';':
                    case '<':
                    case '=':
                    case '>':
                        break;
                    default:
                        i2 = i + 1;
                        continue;
                }
            }
            stringBuffer.insert(i, "\\");
            i2 = i + 2;
            length++;
        }
        if (stringBuffer.length() > 0) {
            while (stringBuffer.length() > i3 && stringBuffer.charAt(i3) == ' ') {
                stringBuffer.insert(i3, "\\");
                i3 += 2;
            }
        }
        int length2 = stringBuffer.length() - 1;
        while (length2 >= i3 && stringBuffer.charAt(length2) == ' ') {
            stringBuffer.insert(length2, '\\');
            length2--;
        }
        return stringBuffer.toString();
    }
}
