package Ea;

import Ca.e;
import Da.b;
import Da.c;
import Fa.j;
import java.util.Hashtable;
import la.C0390u;
import ya.C0483c;
import ya.C0484d;

public final class a extends e {
    public static final Hashtable b;
    public static final Hashtable c;
    public static final a d = new a();
    public final Hashtable a = e.U(b);

    static {
        C0390u a2 = C0483c.a("2.5.4.6");
        C0390u a3 = C0483c.a("2.5.4.10");
        C0390u a4 = C0483c.a("2.5.4.11");
        C0390u a5 = C0483c.a("2.5.4.12");
        C0390u a6 = C0483c.a("2.5.4.3");
        new C0390u("2.5.4.5").u();
        C0390u u = new C0390u("2.5.4.9").u();
        C0390u a7 = C0483c.a("2.5.4.5");
        C0390u a8 = C0483c.a("2.5.4.7");
        C0390u a10 = C0483c.a("2.5.4.8");
        C0390u a11 = C0483c.a("2.5.4.4");
        C0390u a12 = C0483c.a("2.5.4.42");
        C0390u a13 = C0483c.a("2.5.4.43");
        C0390u a14 = C0483c.a("2.5.4.44");
        C0390u a15 = C0483c.a("2.5.4.45");
        C0390u a16 = C0483c.a("2.5.4.13");
        C0390u a17 = C0483c.a("2.5.4.15");
        C0390u a18 = C0483c.a("2.5.4.17");
        C0390u a19 = C0483c.a("2.5.4.46");
        C0390u a20 = C0483c.a("2.5.4.65");
        C0390u a21 = C0483c.a("2.5.4.72");
        C0390u uVar = a15;
        C0390u a22 = C0483c.a("1.3.6.1.5.5.7.9.1");
        C0390u a23 = C0483c.a("1.3.6.1.5.5.7.9.2");
        C0390u a24 = C0483c.a("1.3.6.1.5.5.7.9.3");
        C0390u a25 = C0483c.a("1.3.6.1.5.5.7.9.4");
        C0390u a26 = C0483c.a("1.3.6.1.5.5.7.9.5");
        C0390u a27 = C0483c.a("1.3.36.8.3.14");
        C0390u a28 = C0483c.a("2.5.4.16");
        C0390u uVar2 = a21;
        new C0390u("2.5.4.54").u();
        C0390u uVar3 = j.a;
        C0390u uVar4 = j.b;
        C0390u uVar5 = j.c;
        C0390u uVar6 = C0484d.x0;
        C0390u uVar7 = uVar3;
        C0390u uVar8 = C0484d.y0;
        C0390u uVar9 = C0484d.z0;
        C0390u uVar10 = a16;
        C0390u uVar11 = new C0390u("0.9.2342.19200300.100.1.25");
        C0390u uVar12 = a14;
        C0390u uVar13 = new C0390u("0.9.2342.19200300.100.1.1");
        Hashtable hashtable = new Hashtable();
        b = hashtable;
        C0390u uVar14 = a13;
        Hashtable hashtable2 = new Hashtable();
        c = hashtable2;
        hashtable.put(a2, "C");
        hashtable.put(a3, "O");
        hashtable.put(a5, "T");
        hashtable.put(a4, "OU");
        hashtable.put(a6, "CN");
        hashtable.put(a8, "L");
        hashtable.put(a10, "ST");
        hashtable.put(a7, "SERIALNUMBER");
        hashtable.put(uVar6, "E");
        hashtable.put(uVar11, "DC");
        hashtable.put(uVar13, "UID");
        hashtable.put(u, "STREET");
        hashtable.put(a11, "SURNAME");
        hashtable.put(a12, "GIVENNAME");
        C0390u uVar15 = a12;
        hashtable.put(uVar14, "INITIALS");
        hashtable.put(uVar12, "GENERATION");
        hashtable.put(uVar10, "DESCRIPTION");
        hashtable.put(uVar2, "ROLE");
        hashtable.put(uVar9, "unstructuredAddress");
        hashtable.put(uVar8, "unstructuredName");
        hashtable.put(uVar, "UniqueIdentifier");
        hashtable.put(a19, "DN");
        hashtable.put(a20, "Pseudonym");
        hashtable.put(a28, "PostalAddress");
        hashtable.put(a27, "NameAtBirth");
        hashtable.put(a25, "CountryOfCitizenship");
        hashtable.put(a26, "CountryOfResidence");
        hashtable.put(a24, "Gender");
        hashtable.put(a23, "PlaceOfBirth");
        hashtable.put(a22, "DateOfBirth");
        hashtable.put(a18, "PostalCode");
        hashtable.put(a17, "BusinessCategory");
        hashtable.put(uVar7, "TelephoneNumber");
        hashtable.put(uVar4, "Name");
        C0390u uVar16 = uVar5;
        hashtable.put(uVar16, "organizationIdentifier");
        Hashtable hashtable3 = hashtable2;
        hashtable3.put("c", a2);
        hashtable3.put("o", a3);
        hashtable3.put("t", a5);
        hashtable3.put("ou", a4);
        hashtable3.put("cn", a6);
        hashtable3.put("l", a8);
        hashtable3.put("st", a10);
        hashtable3.put("sn", a11);
        hashtable3.put("serialnumber", a7);
        hashtable3.put("street", u);
        hashtable3.put("emailaddress", uVar6);
        hashtable3.put("dc", uVar11);
        hashtable3.put("e", uVar6);
        hashtable3.put("uid", uVar13);
        hashtable3.put("surname", a11);
        hashtable3.put("givenname", uVar15);
        hashtable3.put("initials", uVar14);
        hashtable3.put("generation", uVar12);
        hashtable3.put("description", uVar10);
        hashtable3.put("role", uVar2);
        hashtable3.put("unstructuredaddress", uVar9);
        hashtable3.put("unstructuredname", uVar8);
        hashtable3.put("uniqueidentifier", uVar);
        hashtable3.put("dn", a19);
        hashtable3.put("pseudonym", a20);
        hashtable3.put("postaladdress", a28);
        hashtable3.put("nameatbirth", a27);
        hashtable3.put("countryofcitizenship", a25);
        hashtable3.put("countryofresidence", a26);
        hashtable3.put("gender", a24);
        hashtable3.put("placeofbirth", a23);
        hashtable3.put("dateofbirth", a22);
        hashtable3.put("postalcode", a18);
        hashtable3.put("businesscategory", a17);
        hashtable3.put("telephonenumber", uVar7);
        hashtable3.put("name", uVar4);
        hashtable3.put("organizationidentifier", uVar16);
    }

    public a() {
        e.U(c);
    }

    public final String W1(c cVar) {
        StringBuffer stringBuffer = new StringBuffer();
        b[] bVarArr = (b[]) cVar.d.clone();
        boolean z = true;
        for (b a2 : bVarArr) {
            if (z) {
                z = false;
            } else {
                stringBuffer.append(',');
            }
            b.a(stringBuffer, a2, this.a);
        }
        return stringBuffer.toString();
    }
}
