package pa;

import la.C0390u;
import na.C0410a;

/* renamed from: pa.a  reason: case insensitive filesystem */
public interface C0421a {
    public static final C0390u a;
    public static final C0390u b;
    public static final C0390u c;
    public static final C0390u d;
    public static final C0390u e;
    public static final C0390u f;
    public static final C0390u g;
    public static final C0390u h;
    public static final C0390u i;
    public static final C0390u j;
    public static final C0390u k;
    public static final C0390u l;

    static {
        C0390u uVar = new C0390u("1.2.643.2.2");
        a = new C0390u("9", uVar);
        C0410a.a(uVar, "10", "13.0", "13.1", "21");
        C0410a.a(uVar, "31.0", "31.1", "31.2", "31.3");
        uVar.p("31.4");
        b = new C0390u("20", uVar);
        c = new C0390u("19", uVar);
        uVar.p("4");
        uVar.p("3");
        d = new C0390u("30.1", uVar);
        e = new C0390u("32.2", uVar);
        f = new C0390u("32.3", uVar);
        uVar.p("32.4");
        uVar.p("32.5");
        g = new C0390u("33.1", uVar);
        uVar.p("33.2");
        uVar.p("33.3");
        h = new C0390u("35.1", uVar);
        i = new C0390u("35.2", uVar);
        j = new C0390u("35.3", uVar);
        k = new C0390u("36.0", uVar);
        l = new C0390u("36.1", uVar);
        C0410a.a(uVar, "36.0", "36.1", "96", "98");
    }
}
