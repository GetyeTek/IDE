package pa;

import Ga.i;
import Ga.j;
import ab.C0088a;
import ab.C0090c;
import ab.p;
import java.math.BigInteger;
import java.util.Hashtable;
import la.C0390u;
import za.C0494a;

public final class b {
    public static final Hashtable a = new Hashtable();
    public static final Hashtable b = new Hashtable();
    public static final Hashtable c = new Hashtable();

    public static class a extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD97"), b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD94"), b.a("A6"), b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6C611070995AD10045841B09B761B893"), C0088a.b, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, C0088a.b, b.a("8D91E471E0989CDA27DF505A453F2B7635294F2DDF23E3B122ACC99C9E9F1E14")), c.d, c.e, (byte[]) null);
        }
    }

    /* renamed from: pa.b$b  reason: collision with other inner class name */
    public static class C0049b extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("8000000000000000000000000000000000000000000000000000000000000C99"), b.a("8000000000000000000000000000000000000000000000000000000000000C96"), b.a("3E1AF419A269A5F866A7D3C25C3DF80AE979259373FF2B182F49D4CE7E1BBC8B"), b.a("800000000000000000000000000000015F700CFFF1A624E5E497161BCC8A198F"), C0088a.b, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, C0088a.b, b.a("3FA8124359F96680B83D1C3EB2C070E5C545C9858D03ECFB744BF8D717717EFC")), c.d, c.e, (byte[]) null);
        }
    }

    public static class c extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("9B9F605F5A858107AB1EC85E6B41C8AACF846E86789051D37998F7B9022D759B"), b.a("9B9F605F5A858107AB1EC85E6B41C8AACF846E86789051D37998F7B9022D7598"), b.a("805A"), b.a("9B9F605F5A858107AB1EC85E6B41C8AA582CA3511EDDFB74F02F3A6598980BB9"), C0088a.b, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, C0088a.a, b.a("41ECE55743711A8C3CBF3783CD08C0EE4D4DC440D4641A8F366E550DFDB3BB67")), c.d, c.e, (byte[]) null);
        }
    }

    public static class d extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("9B9F605F5A858107AB1EC85E6B41C8AACF846E86789051D37998F7B9022D759B"), b.a("9B9F605F5A858107AB1EC85E6B41C8AACF846E86789051D37998F7B9022D7598"), b.a("805A"), b.a("9B9F605F5A858107AB1EC85E6B41C8AA582CA3511EDDFB74F02F3A6598980BB9"), C0088a.b, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, C0088a.a, b.a("41ECE55743711A8C3CBF3783CD08C0EE4D4DC440D4641A8F366E550DFDB3BB67")), c.d, c.e, (byte[]) null);
        }
    }

    public static class e extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD97"), b.a("C2173F1513981673AF4892C23035A27CE25E2013BF95AA33B22C656F277E7335"), b.a("295F9BAE7428ED9CCC20E7C359A9D41A22FCCD9108E17BF7BA9337A6F8AE9513"), b.a("400000000000000000000000000000000FD8CDDFC87B6635C115AF556C360C67"), C0088a.e, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, b.a("91E38443A5E82C0D880923425712B2BB658B9196932E02C78B2582FE742DAA28"), b.a("32879423AB1A0375895786C4BB46E9565FDE0B5344766740AF268ADB32322E5C")), c.d, c.e, (byte[]) null);
        }
    }

    public static class f extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFDC7"), b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFDC4"), b.a("E8C2505DEDFC86DDC1BD0B2B6667F1DA34B82574761CB0E879BD081CFD0B6265EE3CB090F30D27614CB4574010DA90DD862EF9D4EBEE4761503190785A71C760"), b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF27E69532F48D89116FF22B8D4E0560609B4B38ABFAD2B85DCACDB1411F10B275"), C0088a.b, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, C0088a.d, b.a("7503CFE87A836AE3A61B8816E25450E6CE5E1C93ACF1ABC1778064FDCBEFA921DF1626BE4FD036E93D75E6A50E3A41E98028FE5FC235F5B889A589CB5215F2A4")), c.d, c.e, (byte[]) null);
        }
    }

    public static class g extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006F"), b.a("8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006C"), b.a("687D1B459DC841457E3E06CF6F5E2517B97C7D614AF138BCBF85DC806C4B289F3E965D2DB1416D217F8B276FAD1AB69C50F78BEE1FA3106EFB8CCBC7C5140116"), b.a("800000000000000000000000000000000000000000000000000000000000000149A1EC142565A545ACFDB77BD9D40CFA8B996712101BEA0EC6346C54374F25BD"), C0088a.b, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, C0088a.c, b.a("1A8F7EDA389B094C2C071E3647A8940F3C123B697578C213BE6DD9E6C8EC7335DCB228FD1EDF4A39152CBCAAF8C0398828041055F94CEEEC7E21340780FE41BD")), c.d, c.e, (byte[]) null);
        }
    }

    public static class h extends i {
        public final C0090c a() {
            return new C0090c.e(b.a("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFDC7"), b.a("DC9203E514A721875485A529D2C722FB187BC8980EB866644DE41C68E143064546E861C0E2C9EDD92ADE71F46FCF50FF2AD97F951FDA9F2A2EB6546F39689BD3"), b.a("B4C4EE28CEBC6C2C8AC12952CF37F16AC7EFB6A9F69F4B57FFDA2E4F0DE5ADE038CBC2FFF719D2C18DE0284B8BFEF3B52B8CC7A5F5BF0A3C8D2319A5312557E1"), b.a("3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC98CDBA46506AB004C33A9FF5147502CC8EDA9E7A769A12694623CEF47F023ED"), C0088a.e, true);
        }

        public final Ga.h b() {
            C0090c c = c();
            return new Ga.h(c, b.b(c, b.a("E2E31EDFC23DE7BDEBE241CE593EF5DE2295B7A9CBAEF021D385F7074CEA043AA27272A7AE602BF2A7B9033DB9ED3610C6FB85487EAE97AAC5BC7928C1950148"), b.a("F5CE40D95B5EB899ABBCCFF5911CB8577939804D6527378B8C108C3D2090FF9BE18E2D33E3021ED2EF32D85822423B6304F726AA854BAE07D0396E9A9ADDC40F")), c.d, c.e, (byte[]) null);
        }
    }

    static {
        i iVar = new i();
        i iVar2 = new i();
        i iVar3 = new i();
        i iVar4 = new i();
        i iVar5 = new i();
        i iVar6 = new i();
        i iVar7 = new i();
        i iVar8 = new i();
        c("GostR3410-2001-CryptoPro-A", C0421a.h, iVar);
        c("GostR3410-2001-CryptoPro-B", C0421a.i, iVar2);
        c("GostR3410-2001-CryptoPro-C", C0421a.j, iVar3);
        c("GostR3410-2001-CryptoPro-XchA", C0421a.k, iVar);
        c("GostR3410-2001-CryptoPro-XchB", C0421a.l, iVar4);
        c("Tc26-Gost-3410-12-256-paramSetA", C0494a.e, iVar5);
        c("Tc26-Gost-3410-12-512-paramSetA", C0494a.f, iVar6);
        c("Tc26-Gost-3410-12-512-paramSetB", C0494a.g, iVar7);
        c("Tc26-Gost-3410-12-512-paramSetC", C0494a.h, iVar8);
    }

    public static BigInteger a(String str) {
        return new BigInteger(1, Ub.c.c(str));
    }

    public static j b(C0090c cVar, BigInteger bigInteger, BigInteger bigInteger2) {
        ab.f c2 = cVar.c(bigInteger, bigInteger2);
        p.a(c2);
        return new j(c2, false);
    }

    public static void c(String str, C0390u uVar, i iVar) {
        a.put(str, uVar);
        c.put(uVar, str);
        b.put(uVar, iVar);
    }

    public static Ga.h d(C0390u uVar) {
        i iVar = (i) b.get(uVar);
        if (iVar == null) {
            return null;
        }
        return iVar.d();
    }

    public static String e(C0390u uVar) {
        return (String) c.get(uVar);
    }

    public static C0390u f(String str) {
        return (C0390u) a.get(str);
    }
}
