package pa;

import la.C0328B;
import la.C0366h;
import la.C0388s;
import la.C0390u;
import la.C0394y;
import la.s0;

public final class e extends C0388s {
    public C0390u a;
    public C0390u b;
    public C0390u c;

    public e(C0390u uVar, C0390u uVar2) {
        this.a = uVar;
        this.b = uVar2;
        this.c = null;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [la.s, pa.e] */
    public static e h(Object obj) {
        if (obj instanceof e) {
            return (e) obj;
        }
        if (obj == null) {
            return null;
        }
        C0328B r = C0328B.r(obj);
        ? sVar = new C0388s();
        sVar.a = (C0390u) r.s(0);
        sVar.b = (C0390u) r.s(1);
        if (r.size() > 2) {
            sVar.c = (C0390u) r.s(2);
        }
        return sVar;
    }

    public final C0394y b() {
        C0366h hVar = new C0366h(3);
        hVar.a(this.a);
        hVar.a(this.b);
        C0390u uVar = this.c;
        if (uVar != null) {
            hVar.a(uVar);
        }
        return new s0(hVar);
    }

    public e(C0390u uVar, C0390u uVar2, C0390u uVar3) {
        this.a = uVar;
        this.b = uVar2;
        this.c = uVar3;
    }
}
