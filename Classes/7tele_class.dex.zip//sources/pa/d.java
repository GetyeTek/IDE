package pa;

import java.math.BigInteger;
import la.C0366h;
import la.C0382p;
import la.C0388s;
import la.C0394y;
import la.s0;
import okio.Segment;

public final class d extends C0388s {
    public final int a = Segment.SHARE_MINIMUM;
    public final C0382p b;
    public final C0382p c;
    public final C0382p d;

    public d(BigInteger bigInteger, BigInteger bigInteger2, BigInteger bigInteger3) {
        this.b = new C0382p(bigInteger);
        this.c = new C0382p(bigInteger2);
        this.d = new C0382p(bigInteger3);
    }

    public final C0394y b() {
        C0366h hVar = new C0366h(4);
        hVar.a(new C0382p((long) this.a));
        hVar.a(this.b);
        hVar.a(this.c);
        hVar.a(this.d);
        return new s0(hVar);
    }
}
