package la;

import java.io.IOException;

public final class I0 extends C0329C {
    public int d = -1;

    public I0(boolean z, C0364g[] gVarArr) {
        super(z, gVarArr);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.m(49, z);
        F0 b = xVar.b();
        C0364g[] gVarArr = this.a;
        int length = gVarArr.length;
        int i = 0;
        if (this.d >= 0 || length > 16) {
            xVar.h(t());
            while (i < length) {
                b.n(gVarArr[i].b());
                i++;
            }
            return;
        }
        C0394y[] yVarArr = new C0394y[length];
        int i2 = 0;
        for (int i3 = 0; i3 < length; i3++) {
            C0394y o = gVarArr[i3].b().o();
            yVarArr[i3] = o;
            i2 += o.k(true);
        }
        this.d = i2;
        xVar.h(i2);
        while (i < length) {
            b.n(yVarArr[i]);
            i++;
        }
    }

    public final int k(boolean z) throws IOException {
        return C0393x.d(t(), z);
    }

    public final int t() throws IOException {
        if (this.d < 0) {
            int i = 0;
            for (C0364g b : this.a) {
                i += b.b().o().k(true);
            }
            this.d = i;
        }
        return this.d;
    }

    public final C0394y o() {
        return this;
    }
}
