package la;

import java.io.IOException;

/* renamed from: la.f0  reason: case insensitive filesystem */
public class C0363f0 extends C0356c {
    public C0363f0(byte[] bArr) {
        super(0, bArr);
    }

    public static C0363f0 t(Object obj) {
        if (obj == null || (obj instanceof C0363f0)) {
            return (C0363f0) obj;
        }
        if (obj instanceof C0356c) {
            return (C0363f0) ((C0356c) obj).n();
        }
        if (obj instanceof byte[]) {
            try {
                return (C0363f0) ((C0356c) C0394y.m((byte[]) obj)).n();
            } catch (Exception e) {
                throw new IllegalArgumentException("encoding error in getInstance: " + e.toString());
            }
        } else {
            throw new IllegalArgumentException("illegal object in getInstance: ".concat(obj.getClass().getName()));
        }
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        byte[] bArr = this.a;
        int length = bArr.length;
        int i = length - 1;
        byte b = bArr[i];
        byte b2 = (byte) ((255 << (bArr[0] & 255)) & b);
        if (b == b2) {
            xVar.j(3, bArr, z);
            return;
        }
        xVar.m(3, z);
        xVar.h(length);
        xVar.g(bArr, 0, i);
        xVar.f(b2);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final C0394y n() {
        return this;
    }

    public final C0394y o() {
        return this;
    }
}
