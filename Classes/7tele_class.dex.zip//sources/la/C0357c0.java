package la;

import java.io.IOException;
import java.io.InputStream;

/* renamed from: la.c0  reason: case insensitive filesystem */
public final class C0357c0 extends InputStream {
    public final C0330D a;
    public boolean b = true;
    public InputStream c;

    public C0357c0(C0330D d) {
        this.a = d;
    }

    public final C0392w a() throws IOException {
        C0364g gVar;
        C0330D d = this.a;
        int read = d.a.read();
        if (read < 0) {
            gVar = null;
        } else {
            gVar = d.a(read);
        }
        if (gVar == null) {
            return null;
        }
        if (gVar instanceof C0392w) {
            return (C0392w) gVar;
        }
        throw new IOException("unknown object encountered: " + gVar.getClass());
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0023  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int read() throws java.io.IOException {
        /*
            r3 = this;
            java.io.InputStream r0 = r3.c
            r1 = -1
            if (r0 != 0) goto L_0x001a
            boolean r0 = r3.b
            if (r0 != 0) goto L_0x000a
            return r1
        L_0x000a:
            la.w r0 = r3.a()
            if (r0 != 0) goto L_0x0011
            return r1
        L_0x0011:
            r2 = 0
            r3.b = r2
        L_0x0014:
            java.io.InputStream r0 = r0.a()
            r3.c = r0
        L_0x001a:
            java.io.InputStream r0 = r3.c
            int r0 = r0.read()
            if (r0 < 0) goto L_0x0023
            return r0
        L_0x0023:
            la.w r0 = r3.a()
            if (r0 != 0) goto L_0x0014
            r0 = 0
            r3.c = r0
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0357c0.read():int");
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
        	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
        */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x002a A[EDGE_INSN: B:20:0x002a->B:15:0x002a ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0029 A[SYNTHETIC] */
    public final int read(byte[] r6, int r7, int r8) throws java.io.IOException {
        /*
            r5 = this;
            java.io.InputStream r0 = r5.c
            r1 = 0
            r2 = -1
            if (r0 != 0) goto L_0x001a
            boolean r0 = r5.b
            if (r0 != 0) goto L_0x000b
            return r2
        L_0x000b:
            la.w r0 = r5.a()
            if (r0 != 0) goto L_0x0012
            return r2
        L_0x0012:
            r5.b = r1
        L_0x0014:
            java.io.InputStream r0 = r0.a()
            r5.c = r0
        L_0x001a:
            java.io.InputStream r0 = r5.c
            int r3 = r7 + r1
            int r4 = r8 - r1
            int r0 = r0.read(r6, r3, r4)
            if (r0 < 0) goto L_0x002a
            int r1 = r1 + r0
            if (r1 != r8) goto L_0x001a
            return r1
        L_0x002a:
            la.w r0 = r5.a()
            if (r0 != 0) goto L_0x0014
            r6 = 0
            r5.c = r6
            r6 = 1
            if (r1 >= r6) goto L_0x0037
            goto L_0x0038
        L_0x0037:
            r2 = r1
        L_0x0038:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0357c0.read(byte[], int, int):int");
    }
}
