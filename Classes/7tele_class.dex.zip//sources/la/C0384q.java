package la;

/* renamed from: la.q  reason: case insensitive filesystem */
public abstract class C0384q extends C0394y {

    /* renamed from: la.q$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            if (o0Var.a.length == 0) {
                return C0377m0.a;
            }
            throw new IllegalStateException("malformed NULL encoding encountered");
        }
    }

    static {
        new C0337K(C0384q.class);
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0384q)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return -1;
    }

    public final String toString() {
        return "NULL";
    }
}
