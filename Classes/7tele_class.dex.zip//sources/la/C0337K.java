package la;

import java.io.IOException;

/* renamed from: la.K  reason: case insensitive filesystem */
public abstract class C0337K {
    public final Class a;

    public C0337K(Class cls) {
        this.a = cls;
    }

    public final void a(C0394y yVar) {
        if (!this.a.isInstance(yVar)) {
            throw new IllegalStateException("unexpected object: ".concat(yVar.getClass().getName()));
        }
    }

    public final C0394y b(byte[] bArr) throws IOException {
        C0394y m = C0394y.m(bArr);
        a(m);
        return m;
    }

    public C0394y c(C0328B b) {
        throw new IllegalStateException("unexpected implicit constructed encoding");
    }

    public C0394y d(C0381o0 o0Var) {
        throw new IllegalStateException("unexpected implicit primitive encoding");
    }

    public final C0394y e(C0333G g, boolean z) {
        if (128 == g.b) {
            C0394y q = g.q(z, this);
            a(q);
            return q;
        }
        throw new IllegalStateException("this method only valid for CONTEXT_SPECIFIC tags");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return false;
    }
}
