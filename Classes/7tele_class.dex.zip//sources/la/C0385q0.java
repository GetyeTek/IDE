package la;

import java.io.IOException;

/* renamed from: la.q0  reason: case insensitive filesystem */
public final class C0385q0 extends F0 {
    public final void i(C0364g[] gVarArr) throws IOException {
        for (C0364g b : gVarArr) {
            b.b().n().i(this, true);
        }
    }

    public final void n(C0394y yVar) throws IOException {
        yVar.n().i(this, true);
    }

    public final void o(C0394y[] yVarArr) throws IOException {
        for (C0394y n : yVarArr) {
            n.n().i(this, true);
        }
    }

    public final C0385q0 a() {
        return this;
    }
}
