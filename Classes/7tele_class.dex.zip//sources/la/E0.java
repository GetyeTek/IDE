package la;

public final class E0 {
    public static final G0 a;
    public static final I0 b;

    /* JADX WARNING: type inference failed for: r0v0, types: [la.B, la.G0] */
    /* JADX WARNING: type inference failed for: r0v1, types: [la.C, la.I0] */
    static {
        ? b2 = new C0328B();
        b2.c = -1;
        a = b2;
        ? c = new C0329C();
        c.d = -1;
        b = c;
    }

    public static G0 a(C0366h hVar) {
        if (hVar.b < 1) {
            return a;
        }
        return new G0(hVar);
    }
}
