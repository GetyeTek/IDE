package la;

import Ca.e;
import android.support.v4.media.b;
import java.io.IOException;

/* renamed from: la.j  reason: case insensitive filesystem */
public abstract class C0370j extends C0394y {
    public final C0390u a;
    public final C0382p b;
    public final C0394y c;
    public final int d;
    public final C0394y e;

    /* renamed from: la.j$a */
    public static class a extends C0337K {
        public final C0394y c(C0328B b) {
            return b.v();
        }
    }

    static {
        new C0337K(C0370j.class);
    }

    public C0370j(C0390u uVar, C0382p pVar, C0394y yVar, int i, C0394y yVar2) {
        this.a = uVar;
        this.b = pVar;
        this.c = yVar;
        if (i < 0 || i > 2) {
            throw new IllegalArgumentException(b.a(i, "invalid encoding value: "));
        }
        this.d = i;
        if (i != 1) {
            if (i == 2 && !C0356c.class.isInstance(yVar2)) {
                throw new IllegalStateException("unexpected object: ".concat(yVar2.getClass().getName()));
            }
        } else if (!C0391v.class.isInstance(yVar2)) {
            throw new IllegalStateException("unexpected object: ".concat(yVar2.getClass().getName()));
        }
        this.e = yVar2;
    }

    public static C0394y q(C0328B b2, int i) {
        if (b2.size() > i) {
            return b2.s(i).b();
        }
        throw new IllegalArgumentException("too few objects in input sequence");
    }

    public final boolean h(C0394y yVar) {
        if (this == yVar) {
            return true;
        }
        if (!(yVar instanceof C0370j)) {
            return false;
        }
        C0370j jVar = (C0370j) yVar;
        if (!V9.a.a(this.a, jVar.a) || !V9.a.a(this.b, jVar.b) || !V9.a.a(this.c, jVar.c) || this.d != jVar.d || !this.e.l(jVar.e)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i;
        int i2;
        C0390u uVar = this.a;
        int i3 = 0;
        if (uVar == null) {
            i = 0;
        } else {
            i = uVar.hashCode();
        }
        C0382p pVar = this.b;
        if (pVar == null) {
            i2 = 0;
        } else {
            i2 = pVar.hashCode();
        }
        int i4 = i ^ i2;
        C0394y yVar = this.c;
        if (yVar != null) {
            i3 = yVar.hashCode();
        }
        return ((i4 ^ i3) ^ this.d) ^ this.e.hashCode();
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.m(40, z);
        p().i(xVar, false);
    }

    public final boolean j() {
        return true;
    }

    public final int k(boolean z) throws IOException {
        return p().k(z);
    }

    public C0394y n() {
        return new C0370j(this.a, this.b, this.c, this.d, this.e);
    }

    public C0394y o() {
        return new C0370j(this.a, this.b, this.c, this.d, this.e);
    }

    public abstract C0328B p();

    public C0370j(C0328B b2) {
        int i;
        C0394y yVar;
        C0394y q = q(b2, 0);
        if (q instanceof C0390u) {
            this.a = (C0390u) q;
            q = q(b2, 1);
            i = 1;
        } else {
            i = 0;
        }
        if (q instanceof C0382p) {
            this.b = (C0382p) q;
            i++;
            q = q(b2, i);
        }
        if (!(q instanceof C0333G)) {
            this.c = q;
            i++;
            q = q(b2, i);
        }
        if (b2.size() != i + 1) {
            throw new IllegalArgumentException("input sequence too large");
        } else if (q instanceof C0333G) {
            C0333G g = (C0333G) q;
            int i2 = g.c;
            if (i2 < 0 || i2 > 2) {
                throw new IllegalArgumentException(b.a(i2, "invalid encoding value: "));
            }
            this.d = i2;
            int i3 = g.b;
            if (128 == i3) {
                if (i2 != 0) {
                    if (i2 == 1) {
                        yVar = (C0391v) C0391v.b.e(g, false);
                    } else if (i2 == 2) {
                        yVar = (C0356c) C0356c.b.e(g, false);
                    } else {
                        throw new IllegalArgumentException("invalid tag: " + e.t0(i3, i2));
                    }
                } else if (g.u()) {
                    C0364g gVar = g.d;
                    yVar = (gVar instanceof C0388s ? (C0388s) gVar : gVar.b()).b();
                } else {
                    throw new IllegalStateException("object implicit - explicit expected.");
                }
                this.e = yVar;
                return;
            }
            throw new IllegalArgumentException("invalid tag: " + e.t0(i3, i2));
        } else {
            throw new IllegalArgumentException("No tagged object found in sequence. Structure doesn't seem to be of type External");
        }
    }
}
