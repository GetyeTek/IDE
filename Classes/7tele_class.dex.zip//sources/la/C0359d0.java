package la;

/* renamed from: la.d0  reason: case insensitive filesystem */
public final class C0359d0 extends C0352a {
    public final C0394y n() {
        return this;
    }

    public final C0394y o() {
        return this;
    }
}
