package la;

public final class A0 extends C0352a {
    public final C0394y o() {
        return this;
    }
}
