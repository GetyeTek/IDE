package la;

import java.io.IOException;
import java.util.Arrays;
import org.bouncycastle.util.g;

/* renamed from: la.F  reason: case insensitive filesystem */
public abstract class C0332F extends C0394y implements C0331E {
    public final byte[] a;

    /* renamed from: la.F$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0332F(o0Var.a);
        }
    }

    static {
        new C0337K(C0332F.class);
    }

    public C0332F(byte[] bArr) {
        this.a = bArr;
    }

    public final String c() {
        return g.a(this.a);
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0332F)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0332F) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(20, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final String toString() {
        return g.a(this.a);
    }
}
