package la;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.bouncycastle.util.c;

/* renamed from: la.s  reason: case insensitive filesystem */
public abstract class C0388s implements C0364g, c {
    public abstract C0394y b();

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0364g)) {
            return false;
        }
        return b().l(((C0364g) obj).b());
    }

    public final byte[] g() throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        C0394y b = b();
        b.getClass();
        new C0393x(byteArrayOutputStream).n(b);
        return byteArrayOutputStream.toByteArray();
    }

    public byte[] getEncoded() throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        C0394y b = b();
        b.getClass();
        b.i(new C0393x(byteArrayOutputStream), true);
        return byteArrayOutputStream.toByteArray();
    }

    public String getName() {
        return toString();
    }

    public int hashCode() {
        return b().hashCode();
    }
}
