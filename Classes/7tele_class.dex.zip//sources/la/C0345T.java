package la;

import com.shinemo.protocol.groupstruct.GroupstructMacro;
import java.io.IOException;

/* renamed from: la.T  reason: case insensitive filesystem */
public final class C0345T extends C0391v {
    public final int d = GroupstructMacro.MAX_GROUP_NUMBER_NUM;
    public final C0391v[] e;

    public C0345T(byte[] bArr, C0391v[] vVarArr) {
        super(bArr);
        this.e = vVarArr;
    }

    public static byte[] q(C0391v[] vVarArr) {
        if (r0 == 0) {
            return C0391v.c;
        }
        if (r0 == 1) {
            return vVarArr[0].a;
        }
        int i = 0;
        for (C0391v vVar : vVarArr) {
            i += vVar.a.length;
        }
        byte[] bArr = new byte[i];
        int i2 = 0;
        for (C0391v vVar2 : vVarArr) {
            byte[] bArr2 = vVar2.a;
            System.arraycopy(bArr2, 0, bArr, i2, bArr2.length);
            i2 += bArr2.length;
        }
        return bArr;
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        if (!j()) {
            byte[] bArr = this.a;
            int length = bArr.length;
            xVar.m(4, z);
            xVar.h(length);
            xVar.g(bArr, 0, length);
            return;
        }
        xVar.m(36, z);
        xVar.f(128);
        C0391v[] vVarArr = this.e;
        if (vVarArr == null) {
            int i = 0;
            while (true) {
                byte[] bArr2 = this.a;
                if (i >= bArr2.length) {
                    break;
                }
                int min = Math.min(bArr2.length - i, this.d);
                byte[] bArr3 = this.a;
                xVar.m(4, true);
                xVar.h(min);
                xVar.g(bArr3, i, min);
                i += min;
            }
        } else {
            xVar.o(vVarArr);
        }
        xVar.f(0);
        xVar.f(0);
    }

    public final boolean j() {
        if (this.e != null || this.a.length > this.d) {
            return true;
        }
        return false;
    }

    public final int k(boolean z) throws IOException {
        int i;
        boolean j = j();
        byte[] bArr = this.a;
        if (!j) {
            return C0393x.d(bArr.length, z);
        }
        if (z) {
            i = 4;
        } else {
            i = 3;
        }
        C0391v[] vVarArr = this.e;
        if (vVarArr != null) {
            for (C0391v k : vVarArr) {
                i += k.k(true);
            }
            return i;
        }
        int length = bArr.length;
        int i2 = this.d;
        int i3 = length / i2;
        int d2 = i + (C0393x.d(i2, true) * i3);
        int length2 = bArr.length - (i3 * i2);
        if (length2 > 0) {
            return d2 + C0393x.d(length2, true);
        }
        return d2;
    }
}
