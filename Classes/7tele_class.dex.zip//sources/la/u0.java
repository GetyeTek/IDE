package la;

public final class u0 extends C0332F {
}
