package la;

import java.io.IOException;

public class F0 extends C0393x {
    public void i(C0364g[] gVarArr) throws IOException {
        for (C0364g b : gVarArr) {
            b.b().o().i(this, true);
        }
    }

    public void n(C0394y yVar) throws IOException {
        yVar.o().i(this, true);
    }

    public void o(C0394y[] yVarArr) throws IOException {
        for (C0394y o : yVarArr) {
            o.o().i(this, true);
        }
    }

    public final F0 b() {
        return this;
    }
}
