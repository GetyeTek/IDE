package la;

import Vb.a;
import androidx.camera.camera2.internal.i1;
import androidx.sqlite.db.b;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1Exception;

/* renamed from: la.o  reason: case insensitive filesystem */
public final class C0380o extends FilterInputStream {
    public final int a;
    public final boolean b;
    public final byte[][] c;

    public C0380o(int i, byte[] bArr) {
        this(new ByteArrayInputStream(bArr), bArr.length, true);
    }

    /* JADX WARNING: type inference failed for: r11v1, types: [la.k0, la.m] */
    public static C0394y b(int i, M0 m0, byte[][] bArr) throws IOException {
        switch (i) {
            case 1:
                return C0360e.p(c(m0, bArr));
            case 2:
                return new C0382p(m0.b());
            case 3:
                return C0356c.p(m0.b());
            case 4:
                return new C0391v(m0.b());
            case 5:
                if (m0.b().length == 0) {
                    return C0377m0.a;
                }
                throw new IllegalStateException("malformed NULL encoding encountered");
            case 6:
                return C0390u.q(c(m0, bArr), true);
            case 7:
                return new C0389t(new C0376m(m0.b()));
            case 10:
                return C0368i.p(c(m0, bArr), true);
            case 12:
                return new C0335I(m0.b());
            case 13:
                return new C0327A(m0.b());
            case 18:
                return new C0386r(m0.b());
            case 19:
                return new C0395z(m0.b());
            case 20:
                return new C0332F(m0.b());
            case 21:
                return new C0338L(m0.b());
            case 22:
                return new C0378n(m0.b());
            case 23:
                return new C0334H(m0.b());
            case 24:
                return new C0374l(m0.b());
            case 25:
                return new C0376m(m0.b());
            case 26:
                return new C0339M(m0.b());
            case 27:
                return new C0372k(m0.b());
            case 28:
                return new C0336J(m0.b());
            case 30:
                int i2 = m0.d;
                if ((i2 & 1) == 0) {
                    int i3 = i2 / 2;
                    char[] cArr = new char[i3];
                    byte[] bArr2 = new byte[8];
                    int i4 = 0;
                    int i5 = 0;
                    while (i2 >= 8) {
                        if (a.b(m0, bArr2, 8) == 8) {
                            cArr[i5] = (char) ((bArr2[0] << 8) | (bArr2[1] & 255));
                            cArr[i5 + 1] = (char) ((bArr2[2] << 8) | (bArr2[3] & 255));
                            cArr[i5 + 2] = (char) ((bArr2[4] << 8) | (bArr2[5] & 255));
                            cArr[i5 + 3] = (char) ((bArr2[6] << 8) | (bArr2[7] & 255));
                            i5 += 4;
                            i2 -= 8;
                        } else {
                            throw new EOFException("EOF encountered in middle of BMPString");
                        }
                    }
                    if (i2 > 0) {
                        if (a.b(m0, bArr2, i2) == i2) {
                            do {
                                int i6 = i4 + 1;
                                i4 += 2;
                                cArr[i5] = (char) ((bArr2[i6] & 255) | (bArr2[i4] << 8));
                                i5++;
                            } while (i4 < i2);
                        } else {
                            throw new EOFException("EOF encountered in middle of BMPString");
                        }
                    }
                    if (m0.d == 0 && i3 == i5) {
                        return new C0354b(cArr);
                    }
                    throw new IllegalStateException();
                }
                throw new IOException("malformed BMPString encoding encountered");
            default:
                throw new IOException(i1.a(i, "unknown tag ", " encountered"));
        }
    }

    public static byte[] c(M0 m0, byte[][] bArr) throws IOException {
        int i = m0.d;
        if (i >= bArr.length) {
            return m0.b();
        }
        byte[] bArr2 = bArr[i];
        if (bArr2 == null) {
            bArr2 = new byte[i];
            bArr[i] = bArr2;
        }
        if (i == bArr2.length) {
            if (i != 0) {
                int i2 = m0.b;
                if (i < i2) {
                    int b2 = i - a.b(m0.a, bArr2, bArr2.length);
                    m0.d = b2;
                    if (b2 == 0) {
                        m0.a();
                    } else {
                        throw new EOFException("DEF length " + m0.c + " object truncated by " + m0.d);
                    }
                } else {
                    throw new IOException("corrupted stream - out of bounds length found: " + m0.d + " >= " + i2);
                }
            }
            return bArr2;
        }
        throw new IllegalArgumentException("buffer length not right for data");
    }

    public static int d(InputStream inputStream, int i, boolean z) throws IOException {
        int read = inputStream.read();
        if ((read >>> 7) == 0) {
            return read;
        }
        if (128 == read) {
            return -1;
        }
        if (read < 0) {
            throw new EOFException("EOF found when length expected");
        } else if (255 != read) {
            int i2 = read & 127;
            int i3 = 0;
            int i4 = 0;
            do {
                int read2 = inputStream.read();
                if (read2 < 0) {
                    throw new EOFException("EOF found reading length");
                } else if ((i3 >>> 23) == 0) {
                    i3 = (i3 << 8) + read2;
                    i4++;
                } else {
                    throw new IOException("long form definite-length more than 31 bits");
                }
            } while (i4 < i2);
            if (i3 < i || z) {
                return i3;
            }
            throw new IOException(b.a(i3, i, "corrupted stream - out of bounds length found: ", " >= "));
        } else {
            throw new IOException("invalid long form definite-length 0xFF");
        }
    }

    public static int f(InputStream inputStream, int i) throws IOException {
        int i2 = i & 31;
        if (i2 != 31) {
            return i2;
        }
        int read = inputStream.read();
        if (read >= 31) {
            int i3 = read & 127;
            if (i3 != 0) {
                while ((read & 128) != 0) {
                    if ((i3 >>> 24) == 0) {
                        int i4 = i3 << 7;
                        int read2 = inputStream.read();
                        if (read2 >= 0) {
                            int i5 = read2;
                            i3 = i4 | (read2 & 127);
                            read = i5;
                        } else {
                            throw new EOFException("EOF found inside tag value.");
                        }
                    } else {
                        throw new IOException("Tag number more than 31 bits");
                    }
                }
                return i3;
            }
            throw new IOException("corrupted stream - invalid high tag number found");
        } else if (read < 0) {
            throw new EOFException("EOF found inside tag value.");
        } else {
            throw new IOException("corrupted stream - high tag number < 31 found");
        }
    }

    /* JADX WARNING: type inference failed for: r5v16, types: [la.y, la.Q0, la.B] */
    /* JADX WARNING: type inference failed for: r6v13, types: [la.C, la.I0] */
    public final C0394y a(int i, int i2, int i3) throws IOException {
        M0 m0 = new M0(this, i3, this.a);
        if ((i & 224) == 0) {
            return b(i2, m0, this.c);
        }
        int i4 = i & 192;
        if (i4 == 0) {
            int i5 = 0;
            if (i2 == 3) {
                C0366h h = h(m0);
                int i6 = h.b;
                C0356c[] cVarArr = new C0356c[i6];
                while (i5 != i6) {
                    C0364g b2 = h.b(i5);
                    if (b2 instanceof C0356c) {
                        cVarArr[i5] = (C0356c) b2;
                        i5++;
                    } else {
                        throw new ASN1Exception("unknown object encountered in constructed BIT STRING: " + b2.getClass());
                    }
                }
                return new C0342P(cVarArr);
            } else if (i2 == 4) {
                C0366h h2 = h(m0);
                int i7 = h2.b;
                C0391v[] vVarArr = new C0391v[i7];
                while (i5 != i7) {
                    C0364g b3 = h2.b(i5);
                    if (b3 instanceof C0391v) {
                        vVarArr[i5] = (C0391v) b3;
                        i5++;
                    } else {
                        throw new ASN1Exception("unknown object encountered in constructed OCTET STRING: " + b3.getClass());
                    }
                }
                return new C0345T(C0345T.q(vVarArr), vVarArr);
            } else if (i2 == 8) {
                G0 a2 = E0.a(h(m0));
                a2.getClass();
                return new C0370j(a2);
            } else if (i2 != 16) {
                if (i2 == 17) {
                    C0366h h3 = h(m0);
                    G0 g0 = E0.a;
                    if (h3.b < 1) {
                        return E0.b;
                    }
                    ? c2 = new C0329C(h3, false);
                    c2.d = -1;
                    return c2;
                }
                throw new IOException(i1.a(i2, "unknown tag ", " encountered"));
            } else if (m0.d < 1) {
                return E0.a;
            } else {
                if (!this.b) {
                    return E0.a(h(m0));
                }
                byte[] b4 = m0.b();
                ? b5 = new C0328B();
                b5.c = b4;
                return b5;
            }
        } else if ((i & 32) != 0) {
            return C0333G.p(i4, i2, h(m0));
        } else {
            C0333G g = new C0333G(4, i4, i2, new C0391v(m0.b()));
            if (i4 != 64) {
                return g;
            }
            return new C0352a(g);
        }
    }

    public final C0394y e() throws IOException {
        int read = read();
        if (read > 0) {
            int f = f(this, read);
            int i = this.a;
            int d = d(this, i, false);
            if (d >= 0) {
                try {
                    return a(read, f, d);
                } catch (IllegalArgumentException e) {
                    throw new ASN1Exception("corrupted stream detected", e);
                }
            } else if ((read & 32) != 0) {
                C0330D d2 = new C0330D(new O0(this, i), i, this.c);
                int i2 = read & 192;
                if (i2 != 0) {
                    return d2.b(i2, f);
                }
                if (f == 3) {
                    return C0343Q.c(d2);
                }
                if (f == 4) {
                    return C0346U.c(d2);
                }
                if (f == 8) {
                    return C0367h0.c(d2);
                }
                if (f == 16) {
                    return new C0328B(d2.c());
                }
                if (f == 17) {
                    return new C0329C(d2.c(), false);
                }
                throw new IOException("unknown BER object encountered");
            } else {
                throw new IOException("indefinite-length primitive encoding encountered");
            }
        } else if (read != 0) {
            return null;
        } else {
            throw new IOException("unexpected end-of-contents marker");
        }
    }

    public final C0366h g() throws IOException {
        C0394y e = e();
        if (e == null) {
            return new C0366h(0);
        }
        C0366h hVar = new C0366h();
        do {
            hVar.a(e);
            e = e();
        } while (e != null);
        return hVar;
    }

    public final C0366h h(M0 m0) throws IOException {
        int i = m0.d;
        if (i < 1) {
            return new C0366h(0);
        }
        return new C0380o(m0, i, this.b, this.c).g();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003a, code lost:
        if (r3 < 2147483647L) goto L_0x003c;
     */
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0380o(java.io.InputStream r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof la.R0
            if (r0 == 0) goto L_0x000a
            r0 = r6
            la.R0 r0 = (la.R0) r0
            int r0 = r0.b
            goto L_0x004d
        L_0x000a:
            boolean r0 = r6 instanceof la.C0380o
            if (r0 == 0) goto L_0x0014
            r0 = r6
            la.o r0 = (la.C0380o) r0
            int r0 = r0.a
            goto L_0x004d
        L_0x0014:
            boolean r0 = r6 instanceof java.io.ByteArrayInputStream
            if (r0 == 0) goto L_0x0020
            r0 = r6
            java.io.ByteArrayInputStream r0 = (java.io.ByteArrayInputStream) r0
            int r0 = r0.available()
            goto L_0x004d
        L_0x0020:
            boolean r0 = r6 instanceof java.io.FileInputStream
            r1 = 2147483647(0x7fffffff, double:1.060997895E-314)
            if (r0 == 0) goto L_0x003e
            r0 = r6
            java.io.FileInputStream r0 = (java.io.FileInputStream) r0     // Catch:{ IOException -> 0x0035 }
            java.nio.channels.FileChannel r0 = r0.getChannel()     // Catch:{ IOException -> 0x0035 }
            if (r0 == 0) goto L_0x0037
            long r3 = r0.size()     // Catch:{ IOException -> 0x0035 }
            goto L_0x0038
        L_0x0035:
            goto L_0x003e
        L_0x0037:
            r3 = r1
        L_0x0038:
            int r0 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x003e
        L_0x003c:
            int r0 = (int) r3
            goto L_0x004d
        L_0x003e:
            java.lang.Runtime r0 = java.lang.Runtime.getRuntime()
            long r3 = r0.maxMemory()
            int r0 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x003c
            r0 = 2147483647(0x7fffffff, float:NaN)
        L_0x004d:
            r1 = 0
            r5.<init>(r6, r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0380o.<init>(java.io.InputStream):void");
    }

    public C0380o(InputStream inputStream, int i, boolean z) {
        this(inputStream, i, z, new byte[11][]);
    }

    public C0380o(InputStream inputStream, int i, boolean z, byte[][] bArr) {
        super(inputStream);
        this.a = i;
        this.b = z;
        this.c = bArr;
    }

    public C0380o(byte[] bArr) {
        this(new ByteArrayInputStream(bArr), bArr.length, false);
    }
}
