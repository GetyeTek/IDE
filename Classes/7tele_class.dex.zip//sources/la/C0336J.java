package la;

import java.io.IOException;
import java.util.Arrays;

/* renamed from: la.J  reason: case insensitive filesystem */
public abstract class C0336J extends C0394y implements C0331E {
    public static final char[] b = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    public final byte[] a;

    /* renamed from: la.J$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0336J(o0Var.a);
        }
    }

    static {
        new C0337K(C0336J.class);
    }

    public C0336J(byte[] bArr) {
        this.a = bArr;
    }

    public static void p(StringBuffer stringBuffer, int i) {
        char[] cArr = b;
        stringBuffer.append(cArr[(i >>> 4) & 15]);
        stringBuffer.append(cArr[i & 15]);
    }

    public final String c() {
        int i;
        StringBuffer stringBuffer = new StringBuffer(((C0393x.c(r1) + r1) * 2) + 3);
        stringBuffer.append("#1C");
        if (r1 < 128) {
            p(stringBuffer, r1);
        } else {
            byte[] bArr = new byte[5];
            int i2 = r1;
            int i3 = 5;
            while (true) {
                i = i3 - 1;
                bArr[i] = (byte) i2;
                i2 >>>= 8;
                if (i2 == 0) {
                    break;
                }
                i3 = i;
            }
            int i4 = i3 - 2;
            bArr[i4] = (byte) (128 | (5 - i));
            while (true) {
                int i5 = i4 + 1;
                p(stringBuffer, bArr[i4]);
                if (i5 >= 5) {
                    break;
                }
                i4 = i5;
            }
        }
        for (byte p : this.a) {
            p(stringBuffer, p);
        }
        return stringBuffer.toString();
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0336J)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0336J) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(28, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final String toString() {
        return c();
    }
}
