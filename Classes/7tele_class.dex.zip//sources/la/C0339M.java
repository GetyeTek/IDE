package la;

import java.io.IOException;
import java.util.Arrays;
import org.bouncycastle.util.g;

/* renamed from: la.M  reason: case insensitive filesystem */
public abstract class C0339M extends C0394y implements C0331E {
    public final byte[] a;

    /* renamed from: la.M$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0339M(o0Var.a);
        }
    }

    static {
        new C0337K(C0339M.class);
    }

    public C0339M(byte[] bArr) {
        this.a = bArr;
    }

    public final String c() {
        return g.a(this.a);
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0339M)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0339M) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(26, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final String toString() {
        return g.a(this.a);
    }
}
