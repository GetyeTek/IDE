package la;

import Bb.k;
import Ub.c;
import Ub.d;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import org.bouncycastle.util.g;

/* renamed from: la.v  reason: case insensitive filesystem */
public abstract class C0391v extends C0394y implements C0392w {
    public static final a b = new C0337K(C0391v.class);
    public static final byte[] c = new byte[0];
    public final byte[] a;

    public C0391v(byte[] bArr) {
        if (bArr != null) {
            this.a = bArr;
            return;
        }
        throw new NullPointerException("'string' cannot be null");
    }

    public static C0391v p(Object obj) {
        if (obj == null || (obj instanceof C0391v)) {
            return (C0391v) obj;
        }
        if (obj instanceof C0364g) {
            C0394y b2 = ((C0364g) obj).b();
            if (b2 instanceof C0391v) {
                return (C0391v) b2;
            }
        } else if (obj instanceof byte[]) {
            try {
                return (C0391v) b.b((byte[]) obj);
            } catch (IOException e) {
                throw new IllegalArgumentException(k.a(e, new StringBuilder("failed to construct OCTET STRING from byte[]: ")));
            }
        }
        throw new IllegalArgumentException("illegal object in getInstance: ".concat(obj.getClass().getName()));
    }

    public final InputStream a() {
        return new ByteArrayInputStream(this.a);
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0391v)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0391v) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public C0394y n() {
        return new C0391v(this.a);
    }

    public C0394y o() {
        return new C0391v(this.a);
    }

    public final String toString() {
        d dVar = c.a;
        byte[] bArr = this.a;
        return "#".concat(g.a(c.d(0, bArr.length, bArr)));
    }

    public final C0394y f() {
        return this;
    }

    /* renamed from: la.v$a */
    public static class a extends C0337K {
        public final C0394y c(C0328B b) {
            return b.w();
        }

        public final C0394y d(C0381o0 o0Var) {
            return o0Var;
        }
    }
}
