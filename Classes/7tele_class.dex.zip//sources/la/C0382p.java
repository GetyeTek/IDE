package la;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Arrays;
import org.bouncycastle.util.f;

/* renamed from: la.p  reason: case insensitive filesystem */
public final class C0382p extends C0394y {
    public static final a c = new C0337K(C0382p.class);
    public final byte[] a;
    public final int b;

    /* renamed from: la.p$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0382p(o0Var.a);
        }
    }

    public C0382p(long j) {
        this.a = BigInteger.valueOf(j).toByteArray();
        this.b = 0;
    }

    public static C0382p p(Object obj) {
        if (obj == null || (obj instanceof C0382p)) {
            return (C0382p) obj;
        }
        if (obj instanceof byte[]) {
            try {
                return (C0382p) c.b((byte[]) obj);
            } catch (Exception e) {
                throw new IllegalArgumentException("encoding error in getInstance: " + e.toString());
            }
        } else {
            throw new IllegalArgumentException("illegal object in getInstance: ".concat(obj.getClass().getName()));
        }
    }

    public static int u(int i, int i2, byte[] bArr) {
        int length = bArr.length;
        int max = Math.max(i, length - 4);
        byte b2 = i2 & bArr[max];
        while (true) {
            max++;
            if (max >= length) {
                return b2;
            }
            b2 = (b2 << 8) | (bArr[max] & 255);
        }
    }

    public static boolean w(byte[] bArr) {
        int length = bArr.length;
        if (length == 0) {
            return true;
        }
        if (length == 1 || bArr[0] != (bArr[1] >> 7) || f.b("org.bouncycastle.asn1.allow_unsafe_integer")) {
            return false;
        }
        return true;
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0382p)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0382p) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(2, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final BigInteger q() {
        return new BigInteger(1, this.a);
    }

    public final BigInteger r() {
        return new BigInteger(this.a);
    }

    public final boolean s(int i) {
        byte[] bArr = this.a;
        int length = bArr.length;
        int i2 = this.b;
        if (length - i2 > 4 || u(i2, -1, bArr) != i) {
            return false;
        }
        return true;
    }

    public final int t() {
        byte[] bArr = this.a;
        int length = bArr.length;
        int i = this.b;
        int i2 = length - i;
        if (i2 <= 4 && (i2 != 4 || (bArr[i] & 128) == 0)) {
            return u(i, 255, bArr);
        }
        throw new ArithmeticException("ASN.1 Integer out of positive int range");
    }

    public final String toString() {
        return r().toString();
    }

    public final int v() {
        byte[] bArr = this.a;
        int length = bArr.length;
        int i = this.b;
        if (length - i <= 4) {
            return u(i, -1, bArr);
        }
        throw new ArithmeticException("ASN.1 Integer out of int range");
    }

    public final long x() {
        byte[] bArr = this.a;
        int length = bArr.length;
        int i = this.b;
        if (length - i <= 8) {
            int length2 = bArr.length;
            int max = Math.max(i, length2 - 8);
            long j = (long) bArr[max];
            while (true) {
                max++;
                if (max >= length2) {
                    return j;
                }
                j = (j << 8) | ((long) (bArr[max] & 255));
            }
        } else {
            throw new ArithmeticException("ASN.1 Integer out of long range");
        }
    }

    public C0382p(BigInteger bigInteger) {
        this.a = bigInteger.toByteArray();
        this.b = 0;
    }

    public C0382p(byte[] bArr) {
        if (!w(bArr)) {
            this.a = bArr;
            int length = bArr.length - 1;
            int i = 0;
            while (i < length) {
                int i2 = i + 1;
                if (bArr[i] != (bArr[i2] >> 7)) {
                    break;
                }
                i = i2;
            }
            this.b = i;
            return;
        }
        throw new IllegalArgumentException("malformed integer");
    }
}
