package la;

import java.io.IOException;
import java.util.Arrays;

/* renamed from: la.b  reason: case insensitive filesystem */
public abstract class C0354b extends C0394y implements C0331E {
    public final char[] a;

    /* renamed from: la.b$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0354b(o0Var.a);
        }
    }

    static {
        new C0337K(C0354b.class);
    }

    public C0354b(byte[] bArr) {
        if (bArr != null) {
            int length = bArr.length;
            if ((length & 1) == 0) {
                int i = length / 2;
                char[] cArr = new char[i];
                for (int i2 = 0; i2 != i; i2++) {
                    int i3 = i2 * 2;
                    cArr[i2] = (char) ((bArr[i3 + 1] & 255) | (bArr[i3] << 8));
                }
                this.a = cArr;
                return;
            }
            throw new IllegalArgumentException("malformed BMPString encoding encountered");
        }
        throw new NullPointerException("'string' cannot be null");
    }

    public final String c() {
        return new String(this.a);
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0354b)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0354b) yVar).a);
    }

    public final int hashCode() {
        char[] cArr = this.a;
        if (cArr == null) {
            return 0;
        }
        int length = cArr.length;
        int i = length + 1;
        while (true) {
            length--;
            if (length < 0) {
                return i;
            }
            i = (i * 257) ^ cArr[length];
        }
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        char[] cArr = this.a;
        int length = cArr.length;
        xVar.m(30, z);
        xVar.h(length * 2);
        byte[] bArr = new byte[8];
        int i = length & -4;
        int i2 = 0;
        while (i2 < i) {
            char c = cArr[i2];
            char c2 = cArr[i2 + 1];
            char c3 = cArr[i2 + 2];
            char c4 = cArr[i2 + 3];
            i2 += 4;
            bArr[0] = (byte) (c >> 8);
            bArr[1] = (byte) c;
            bArr[2] = (byte) (c2 >> 8);
            bArr[3] = (byte) c2;
            bArr[4] = (byte) (c3 >> 8);
            bArr[5] = (byte) c3;
            bArr[6] = (byte) (c4 >> 8);
            bArr[7] = (byte) c4;
            xVar.g(bArr, 0, 8);
        }
        if (i2 < length) {
            int i3 = 0;
            do {
                char c5 = cArr[i2];
                i2++;
                int i4 = i3 + 1;
                bArr[i3] = (byte) (c5 >> 8);
                i3 += 2;
                bArr[i4] = (byte) c5;
            } while (i2 < length);
            xVar.g(bArr, 0, i3);
        }
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length * 2, z);
    }

    public final String toString() {
        return c();
    }

    public C0354b(char[] cArr) {
        this.a = cArr;
    }
}
