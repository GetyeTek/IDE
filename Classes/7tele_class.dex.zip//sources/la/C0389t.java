package la;

import java.io.IOException;

/* renamed from: la.t  reason: case insensitive filesystem */
public final class C0389t extends C0394y {
    public final C0373k0 a;

    /* renamed from: la.t$a */
    public static class a extends C0337K {
        public final C0394y c(C0328B b) {
            throw new IllegalStateException("unexpected implicit constructed encoding");
        }

        /* JADX WARNING: type inference failed for: r1v0, types: [la.k0, la.m] */
        public final C0394y d(C0381o0 o0Var) {
            return new C0389t(new C0376m(o0Var.a));
        }
    }

    static {
        new C0337K(C0389t.class);
    }

    public C0389t(C0373k0 k0Var) {
        this.a = k0Var;
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0389t)) {
            return false;
        }
        return this.a.h(((C0389t) yVar).a);
    }

    public final int hashCode() {
        return ~org.bouncycastle.util.a.h(this.a.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.m(7, z);
        xVar.j(25, this.a.a, false);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return this.a.k(z);
    }

    public final C0394y n() {
        this.a.getClass();
        return this;
    }

    public final C0394y o() {
        this.a.getClass();
        return this;
    }
}
