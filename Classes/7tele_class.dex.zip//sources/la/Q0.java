package la;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import la.C0328B;
import org.bouncycastle.asn1.ASN1ParsingException;

public final class Q0 extends C0328B {
    public byte[] c;

    public final int hashCode() {
        y();
        return super.hashCode();
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        byte[] bArr;
        synchronized (this) {
            bArr = this.c;
        }
        if (bArr != null) {
            xVar.j(48, bArr, z);
        } else {
            super.o().i(xVar, z);
        }
    }

    public final Iterator<C0364g> iterator() {
        y();
        return super.iterator();
    }

    public final int k(boolean z) throws IOException {
        byte[] bArr;
        synchronized (this) {
            bArr = this.c;
        }
        if (bArr != null) {
            return C0393x.d(bArr.length, z);
        }
        return super.o().k(z);
    }

    public final C0394y n() {
        y();
        return super.n();
    }

    public final C0394y o() {
        y();
        return super.o();
    }

    public final C0364g s(int i) {
        y();
        return this.a[i];
    }

    public final int size() {
        y();
        return this.a.length;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [java.util.Enumeration, la.P0, java.lang.Object] */
    public final Enumeration t() {
        byte[] bArr;
        synchronized (this) {
            bArr = this.c;
        }
        if (bArr == null) {
            return new C0328B.b();
        }
        ? obj = new Object();
        obj.a = new C0380o(0, bArr);
        obj.b = obj.a();
        return obj;
    }

    public final C0356c u() {
        return ((C0328B) o()).u();
    }

    public final C0370j v() {
        return ((C0328B) o()).v();
    }

    public final C0391v w() {
        return ((C0328B) o()).w();
    }

    public final C0329C x() {
        return ((C0328B) o()).x();
    }

    public final synchronized void y() {
        if (this.c != null) {
            C0380o oVar = new C0380o(0, this.c);
            try {
                C0366h g = oVar.g();
                oVar.close();
                this.a = g.c();
                this.c = null;
            } catch (IOException e) {
                throw new ASN1ParsingException("malformed ASN.1: " + e, e);
            }
        }
    }
}
