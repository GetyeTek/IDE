package la;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;

/* renamed from: la.A  reason: case insensitive filesystem */
public final class C0327A extends C0394y {
    public final String a;
    public byte[] b;

    /* renamed from: la.A$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0327A(o0Var.a);
        }
    }

    static {
        new C0337K(C0327A.class);
    }

    public C0327A(byte[] bArr) {
        byte[] bArr2 = bArr;
        StringBuffer stringBuffer = new StringBuffer();
        boolean z = true;
        BigInteger bigInteger = null;
        long j = 0;
        for (int i = 0; i != bArr2.length; i++) {
            byte b2 = bArr2[i];
            if (j <= 72057594037927808L) {
                long j2 = j + ((long) (b2 & Byte.MAX_VALUE));
                if ((b2 & 128) == 0) {
                    if (z) {
                        z = false;
                    } else {
                        stringBuffer.append('.');
                    }
                    stringBuffer.append(j2);
                } else {
                    j = j2 << 7;
                }
            } else {
                BigInteger or = (bigInteger == null ? BigInteger.valueOf(j) : bigInteger).or(BigInteger.valueOf((long) (b2 & Byte.MAX_VALUE)));
                if ((b2 & 128) == 0) {
                    if (z) {
                        z = false;
                    } else {
                        stringBuffer.append('.');
                    }
                    stringBuffer.append(or);
                    bigInteger = null;
                } else {
                    bigInteger = or.shiftLeft(7);
                }
            }
            j = 0;
        }
        this.a = stringBuffer.toString();
        this.b = bArr2;
    }

    public static boolean q(int i, String str) {
        int length = str.length();
        int i2 = 0;
        while (true) {
            int i3 = length - 1;
            if (i3 >= i) {
                char charAt = str.charAt(i3);
                if (charAt == '.') {
                    if (i2 == 0 || (i2 > 1 && str.charAt(length) == '0')) {
                        return false;
                    }
                    i2 = 0;
                } else if ('0' > charAt || charAt > '9') {
                    return false;
                } else {
                    i2++;
                }
                length = i3;
            } else if (i2 == 0 || (i2 > 1 && str.charAt(length) == '0')) {
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    public static void r(ByteArrayOutputStream byteArrayOutputStream, long j) {
        byte[] bArr = new byte[9];
        int i = 8;
        bArr[8] = (byte) (((int) j) & 127);
        while (j >= 128) {
            j >>= 7;
            i--;
            bArr[i] = (byte) (((int) j) | 128);
        }
        byteArrayOutputStream.write(bArr, i, 9 - i);
    }

    public static void s(ByteArrayOutputStream byteArrayOutputStream, BigInteger bigInteger) {
        int bitLength = (bigInteger.bitLength() + 6) / 7;
        if (bitLength == 0) {
            byteArrayOutputStream.write(0);
            return;
        }
        byte[] bArr = new byte[bitLength];
        int i = bitLength - 1;
        for (int i2 = i; i2 >= 0; i2--) {
            bArr[i2] = (byte) (bigInteger.intValue() | 128);
            bigInteger = bigInteger.shiftRight(7);
        }
        bArr[i] = (byte) (bArr[i] & Byte.MAX_VALUE);
        byteArrayOutputStream.write(bArr, 0, bitLength);
    }

    public final boolean h(C0394y yVar) {
        if (this == yVar) {
            return true;
        }
        if (!(yVar instanceof C0327A)) {
            return false;
        }
        return this.a.equals(((C0327A) yVar).a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(13, p(), z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(p().length, z);
    }

    public final synchronized byte[] p() {
        String str;
        try {
            if (this.b == null) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                int i = 0;
                while (i != -1) {
                    if (i == -1) {
                        str = null;
                    } else {
                        String str2 = this.a;
                        int indexOf = str2.indexOf(46, i);
                        if (indexOf == -1) {
                            str = str2.substring(i);
                            i = -1;
                        } else {
                            str = str2.substring(i, indexOf);
                            i = indexOf + 1;
                        }
                    }
                    if (str.length() <= 18) {
                        r(byteArrayOutputStream, Long.parseLong(str));
                    } else {
                        s(byteArrayOutputStream, new BigInteger(str));
                    }
                }
                this.b = byteArrayOutputStream.toByteArray();
            }
        } finally {
            while (true) {
            }
        }
        return this.b;
    }

    public final String toString() {
        return this.a;
    }
}
