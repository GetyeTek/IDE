package la;

import java.io.IOException;
import org.bouncycastle.util.g;

/* renamed from: la.j0  reason: case insensitive filesystem */
public final class C0371j0 extends C0374l {
    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(24, q(), z);
    }

    public final int k(boolean z) {
        return C0393x.d(q().length, z);
    }

    public final byte[] q() {
        boolean z;
        boolean z2;
        byte[] bArr = this.a;
        if (bArr[bArr.length - 1] == 90) {
            if (!p(10) || !p(11)) {
                z = false;
            } else {
                z = true;
            }
            if (!z) {
                byte[] bArr2 = new byte[(bArr.length + 4)];
                System.arraycopy(bArr, 0, bArr2, 0, bArr.length - 1);
                System.arraycopy(g.b("0000Z"), 0, bArr2, bArr.length - 1, 5);
                return bArr2;
            }
            if (!p(12) || !p(13)) {
                z2 = false;
            } else {
                z2 = true;
            }
            if (!z2) {
                byte[] bArr3 = new byte[(bArr.length + 2)];
                System.arraycopy(bArr, 0, bArr3, 0, bArr.length - 1);
                System.arraycopy(g.b("00Z"), 0, bArr3, bArr.length - 1, 3);
                return bArr3;
            }
            boolean z3 = false;
            int i = 0;
            while (true) {
                byte[] bArr4 = this.a;
                if (i != bArr4.length) {
                    if (bArr4[i] == 46 && i == 14) {
                        z3 = true;
                        break;
                    }
                    i++;
                } else {
                    break;
                }
            }
            if (z3) {
                int length = bArr.length - 2;
                while (length > 0 && bArr[length] == 48) {
                    length--;
                }
                if (bArr[length] == 46) {
                    byte[] bArr5 = new byte[(length + 1)];
                    System.arraycopy(bArr, 0, bArr5, 0, length);
                    bArr5[length] = 90;
                    return bArr5;
                }
                byte[] bArr6 = new byte[(length + 2)];
                int i2 = length + 1;
                System.arraycopy(bArr, 0, bArr6, 0, i2);
                bArr6[i2] = 90;
                return bArr6;
            }
        }
        return bArr;
    }

    public final C0394y n() {
        return this;
    }

    public final C0394y o() {
        return this;
    }
}
