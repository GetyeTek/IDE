package la;

import java.io.IOException;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import org.bouncycastle.asn1.ASN1ParsingException;

public final class P0 implements Enumeration {
    public C0380o a;
    public C0394y b;

    public final C0394y a() {
        try {
            return this.a.e();
        } catch (IOException e) {
            throw new ASN1ParsingException("malformed ASN.1: " + e, e);
        }
    }

    public final boolean hasMoreElements() {
        if (this.b != null) {
            return true;
        }
        return false;
    }

    public final Object nextElement() {
        C0394y yVar = this.b;
        if (yVar != null) {
            this.b = a();
            return yVar;
        }
        throw new NoSuchElementException();
    }
}
