package la;

import java.io.IOException;
import java.util.Arrays;

/* renamed from: la.i  reason: case insensitive filesystem */
public final class C0368i extends C0394y {
    public static final C0368i[] b = new C0368i[12];
    public final byte[] a;

    /* renamed from: la.i$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return C0368i.p(o0Var.a, false);
        }
    }

    static {
        new C0337K(C0368i.class);
    }

    public C0368i(byte[] bArr, boolean z) {
        byte[] bArr2;
        if (!C0382p.w(bArr)) {
            int i = 0;
            if ((bArr[0] & 128) == 0) {
                if (z) {
                    bArr2 = org.bouncycastle.util.a.a(bArr);
                } else {
                    bArr2 = bArr;
                }
                this.a = bArr2;
                int length = bArr.length - 1;
                while (i < length) {
                    byte b2 = bArr[i];
                    i++;
                    if (b2 != (bArr[i] >> 7)) {
                        return;
                    }
                }
                return;
            }
            throw new IllegalArgumentException("enumerated must be non-negative");
        }
        throw new IllegalArgumentException("malformed enumerated");
    }

    public static C0368i p(byte[] bArr, boolean z) {
        if (bArr.length > 1) {
            return new C0368i(bArr, z);
        }
        if (bArr.length != 0) {
            byte b2 = bArr[0] & 255;
            if (b2 >= 12) {
                return new C0368i(bArr, z);
            }
            C0368i[] iVarArr = b;
            C0368i iVar = iVarArr[b2];
            if (iVar != null) {
                return iVar;
            }
            C0368i iVar2 = new C0368i(bArr, z);
            iVarArr[b2] = iVar2;
            return iVar2;
        }
        throw new IllegalArgumentException("ENUMERATED has zero length");
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0368i)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0368i) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(10, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }
}
