package la;

/* renamed from: la.g  reason: case insensitive filesystem */
public interface C0364g {
    C0394y b();
}
