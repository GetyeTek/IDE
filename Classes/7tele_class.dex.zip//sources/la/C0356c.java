package la;

import Bb.k;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1ParsingException;

/* renamed from: la.c  reason: case insensitive filesystem */
public abstract class C0356c extends C0394y implements C0331E, C0358d {
    public static final a b = new C0337K(C0356c.class);
    public static final char[] c = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    public final byte[] a;

    /* renamed from: la.c$a */
    public static class a extends C0337K {
        public final C0394y c(C0328B b) {
            return b.u();
        }

        public final C0394y d(C0381o0 o0Var) {
            return C0356c.p(o0Var.a);
        }
    }

    public C0356c(int i, byte[] bArr) {
        if (bArr == null) {
            throw new NullPointerException("'data' cannot be null");
        } else if (bArr.length == 0 && i != 0) {
            throw new IllegalArgumentException("zero length data with non-zero pad bits");
        } else if (i > 7 || i < 0) {
            throw new IllegalArgumentException("pad bits cannot be greater than 7 or less than 0");
        } else {
            int length = bArr.length;
            byte[] bArr2 = new byte[(length + 1)];
            System.arraycopy(bArr, 0, bArr2, 1, length);
            bArr2[0] = (byte) i;
            this.a = bArr2;
        }
    }

    public static C0356c p(byte[] bArr) {
        int length = bArr.length;
        if (length >= 1) {
            byte b2 = bArr[0] & 255;
            if (b2 > 0) {
                if (b2 > 7 || length < 2) {
                    throw new IllegalArgumentException("invalid pad bits detected");
                }
                byte b3 = bArr[length - 1];
                if (b3 != ((byte) ((255 << b2) & b3))) {
                    return new C0356c(bArr, false);
                }
            }
            return new C0356c(bArr, false);
        }
        throw new IllegalArgumentException("truncated BIT STRING detected");
    }

    public static C0356c r(C0364g gVar) {
        if (gVar == null || (gVar instanceof C0356c)) {
            return (C0356c) gVar;
        }
        C0394y b2 = gVar.b();
        if (b2 instanceof C0356c) {
            return (C0356c) b2;
        }
        throw new IllegalArgumentException("illegal object in getInstance: ".concat(gVar.getClass().getName()));
    }

    public final String c() {
        try {
            byte[] encoded = getEncoded();
            StringBuffer stringBuffer = new StringBuffer((encoded.length * 2) + 1);
            stringBuffer.append('#');
            for (int i = 0; i != encoded.length; i++) {
                byte b2 = encoded[i];
                char[] cArr = c;
                stringBuffer.append(cArr[(b2 >>> 4) & 15]);
                stringBuffer.append(cArr[b2 & 15]);
            }
            return stringBuffer.toString();
        } catch (IOException e) {
            throw new ASN1ParsingException(k.a(e, new StringBuilder("Internal error encoding BitString: ")), e);
        }
    }

    public final InputStream d() throws IOException {
        byte[] bArr = this.a;
        return new ByteArrayInputStream(bArr, 1, bArr.length - 1);
    }

    public final int e() {
        return this.a[0] & 255;
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0356c)) {
            return false;
        }
        byte[] bArr = ((C0356c) yVar).a;
        byte[] bArr2 = this.a;
        int length = bArr2.length;
        if (bArr.length != length) {
            return false;
        }
        if (length == 1) {
            return true;
        }
        int i = length - 1;
        for (int i2 = 0; i2 < i; i2++) {
            if (bArr2[i2] != bArr[i2]) {
                return false;
            }
        }
        int i3 = 255 << (bArr2[0] & 255);
        if (((byte) (bArr2[i] & i3)) == ((byte) (bArr[i] & i3))) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        byte[] bArr = this.a;
        if (bArr.length < 2) {
            return 1;
        }
        byte b2 = 0;
        int length = bArr.length;
        int i = length - 1;
        byte b3 = (byte) ((255 << (bArr[0] & 255)) & bArr[i]);
        if (bArr != null) {
            b2 = length;
            while (true) {
                i--;
                if (i < 0) {
                    break;
                }
                b2 = (b2 * 257) ^ bArr[i];
            }
        }
        return (b2 * 257) ^ b3;
    }

    public C0394y n() {
        return new C0356c(this.a, false);
    }

    public C0394y o() {
        return new C0356c(this.a, false);
    }

    public final byte[] q() {
        byte[] bArr = this.a;
        if (bArr.length == 1) {
            return C0391v.c;
        }
        byte[] f = org.bouncycastle.util.a.f(1, bArr.length, bArr);
        int length = f.length - 1;
        f[length] = (byte) (((byte) (255 << (bArr[0] & 255))) & f[length]);
        return f;
    }

    public final byte[] s() {
        byte[] bArr = this.a;
        if (bArr[0] == 0) {
            return org.bouncycastle.util.a.f(1, bArr.length, bArr);
        }
        throw new IllegalStateException("attempt to get non-octet aligned data from BIT STRING");
    }

    public String toString() {
        return c();
    }

    public C0356c(byte[] bArr, boolean z) {
        if (z) {
            if (bArr == null) {
                throw new NullPointerException("'contents' cannot be null");
            } else if (bArr.length >= 1) {
                byte b2 = bArr[0] & 255;
                if (b2 > 0) {
                    if (bArr.length < 2) {
                        throw new IllegalArgumentException("zero length data with non-zero pad bits");
                    } else if (b2 > 7) {
                        throw new IllegalArgumentException("pad bits cannot be greater than 7 or less than 0");
                    }
                }
            } else {
                throw new IllegalArgumentException("'contents' cannot be empty");
            }
        }
        this.a = bArr;
    }

    public final C0394y f() {
        return this;
    }
}
