package la;

import java.io.IOException;

/* renamed from: la.o0  reason: case insensitive filesystem */
public final class C0381o0 extends C0391v {
    public C0381o0(byte[] bArr) {
        super(bArr);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(4, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final C0394y n() {
        return this;
    }

    public final C0394y o() {
        return this;
    }
}
