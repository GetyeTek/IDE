package la;

import java.io.IOException;
import java.io.InputStream;

/* renamed from: la.d  reason: case insensitive filesystem */
public interface C0358d extends C0364g, N0 {
    InputStream d() throws IOException;

    int e();
}
