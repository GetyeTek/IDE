package la;

import java.io.IOException;
import java.io.InputStream;

/* renamed from: la.b0  reason: case insensitive filesystem */
public final class C0355b0 extends InputStream {
    public final C0330D a;
    public boolean b = true;
    public int c = 0;
    public C0358d d;
    public InputStream e;

    public C0355b0(C0330D d2) {
        this.a = d2;
    }

    public final C0358d a() throws IOException {
        C0364g gVar;
        C0330D d2 = this.a;
        int read = d2.a.read();
        if (read < 0) {
            gVar = null;
        } else {
            gVar = d2.a(read);
        }
        if (gVar == null) {
            return null;
        }
        if (!(gVar instanceof C0358d)) {
            throw new IOException("unknown object encountered: " + gVar.getClass());
        } else if (this.c == 0) {
            return (C0358d) gVar;
        } else {
            throw new IOException("only the last nested bitstring can have padding");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int read() throws java.io.IOException {
        /*
            r3 = this;
            java.io.InputStream r0 = r3.e
            r1 = -1
            if (r0 != 0) goto L_0x001c
            boolean r0 = r3.b
            if (r0 != 0) goto L_0x000a
            return r1
        L_0x000a:
            la.d r0 = r3.a()
            r3.d = r0
            if (r0 != 0) goto L_0x0013
            return r1
        L_0x0013:
            r2 = 0
            r3.b = r2
        L_0x0016:
            java.io.InputStream r0 = r0.d()
            r3.e = r0
        L_0x001c:
            java.io.InputStream r0 = r3.e
            int r0 = r0.read()
            if (r0 < 0) goto L_0x0025
            return r0
        L_0x0025:
            la.d r0 = r3.d
            int r0 = r0.e()
            r3.c = r0
            la.d r0 = r3.a()
            r3.d = r0
            if (r0 != 0) goto L_0x0016
            r0 = 0
            r3.e = r0
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0355b0.read():int");
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
        	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
        */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0028  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x002c A[EDGE_INSN: B:20:0x002c->B:15:0x002c ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x002b A[SYNTHETIC] */
    public final int read(byte[] r6, int r7, int r8) throws java.io.IOException {
        /*
            r5 = this;
            java.io.InputStream r0 = r5.e
            r1 = 0
            r2 = -1
            if (r0 != 0) goto L_0x001c
            boolean r0 = r5.b
            if (r0 != 0) goto L_0x000b
            return r2
        L_0x000b:
            la.d r0 = r5.a()
            r5.d = r0
            if (r0 != 0) goto L_0x0014
            return r2
        L_0x0014:
            r5.b = r1
        L_0x0016:
            java.io.InputStream r0 = r0.d()
            r5.e = r0
        L_0x001c:
            java.io.InputStream r0 = r5.e
            int r3 = r7 + r1
            int r4 = r8 - r1
            int r0 = r0.read(r6, r3, r4)
            if (r0 < 0) goto L_0x002c
            int r1 = r1 + r0
            if (r1 != r8) goto L_0x001c
            return r1
        L_0x002c:
            la.d r0 = r5.d
            int r0 = r0.e()
            r5.c = r0
            la.d r0 = r5.a()
            r5.d = r0
            if (r0 != 0) goto L_0x0016
            r6 = 0
            r5.e = r6
            r6 = 1
            if (r1 >= r6) goto L_0x0043
            goto L_0x0044
        L_0x0043:
            r2 = r1
        L_0x0044:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0355b0.read(byte[], int, int):int");
    }
}
