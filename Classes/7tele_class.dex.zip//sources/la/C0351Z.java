package la;

import java.io.IOException;

/* renamed from: la.Z  reason: case insensitive filesystem */
public final class C0351Z extends C0333G {
    public final void i(C0393x xVar, boolean z) throws IOException {
        C0394y b = this.d.b();
        boolean u = u();
        if (z) {
            int i = this.b;
            if (u || b.j()) {
                i |= 32;
            }
            xVar.l(i, this.c);
        }
        if (u) {
            xVar.f(128);
            b.i(xVar, true);
            xVar.f(0);
            xVar.f(0);
            return;
        }
        b.i(xVar, false);
    }

    public final boolean j() {
        if (u() || this.d.b().j()) {
            return true;
        }
        return false;
    }

    public final int k(boolean z) throws IOException {
        int i;
        C0394y b = this.d.b();
        boolean u = u();
        int k = b.k(u);
        if (u) {
            k += 3;
        }
        if (z) {
            i = C0393x.e(this.c);
        } else {
            i = 0;
        }
        return k + i;
    }

    public final C0328B v(C0394y yVar) {
        return new C0328B(yVar);
    }
}
