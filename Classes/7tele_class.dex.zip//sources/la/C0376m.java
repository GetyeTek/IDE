package la;

import java.io.IOException;
import java.util.Arrays;
import org.bouncycastle.util.g;

/* renamed from: la.m  reason: case insensitive filesystem */
public abstract class C0376m extends C0394y implements C0331E {
    public final byte[] a;

    /* renamed from: la.m$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0376m(o0Var.a);
        }
    }

    static {
        new C0337K(C0376m.class);
    }

    public C0376m(byte[] bArr) {
        if (bArr != null) {
            this.a = bArr;
            return;
        }
        throw new NullPointerException("'contents' cannot be null");
    }

    public final String c() {
        return g.a(this.a);
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0376m)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0376m) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(25, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }
}
