package la;

public final class y0 extends C0338L {
}
