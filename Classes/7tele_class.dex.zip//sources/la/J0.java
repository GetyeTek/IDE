package la;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1ParsingException;

public final class J0 implements C0364g, N0 {
    public C0330D a;

    public final C0394y b() {
        try {
            return f();
        } catch (IOException e) {
            throw new ASN1ParsingException(e.getMessage(), e);
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [la.C, la.I0] */
    public final C0394y f() throws IOException {
        C0366h c = this.a.c();
        G0 g0 = E0.a;
        if (c.b < 1) {
            return E0.b;
        }
        ? c2 = new C0329C(c, false);
        c2.d = -1;
        return c2;
    }
}
