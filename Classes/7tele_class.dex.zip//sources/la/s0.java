package la;

import java.io.IOException;

public final class s0 extends C0328B {
    public int c = -1;

    public s0() {
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.m(48, z);
        C0385q0 a = xVar.a();
        int length = this.a.length;
        int i = 0;
        if (this.c >= 0 || length > 16) {
            xVar.h(y());
            while (i < length) {
                this.a[i].b().n().i(a, true);
                i++;
            }
            return;
        }
        C0394y[] yVarArr = new C0394y[length];
        int i2 = 0;
        for (int i3 = 0; i3 < length; i3++) {
            C0394y n = this.a[i3].b().n();
            yVarArr[i3] = n;
            i2 += n.k(true);
        }
        this.c = i2;
        xVar.h(i2);
        while (i < length) {
            yVarArr[i].i(a, true);
            i++;
        }
    }

    public final int k(boolean z) throws IOException {
        return C0393x.d(y(), z);
    }

    public final C0356c u() {
        return new C0356c(C0342P.t(p()), false);
    }

    public final C0370j v() {
        return new C0370j(this);
    }

    public final C0391v w() {
        return new C0391v(C0345T.q(q()));
    }

    public final C0329C x() {
        return new I0(false, this.a);
    }

    public final int y() throws IOException {
        if (this.c < 0) {
            int i = 0;
            for (C0364g b : this.a) {
                i += b.b().n().k(true);
            }
            this.c = i;
        }
        return this.c;
    }

    public s0(C0366h hVar) {
        super(hVar);
    }

    public s0(C0394y yVar) {
        super(yVar);
    }

    public final C0394y n() {
        return this;
    }

    public final C0394y o() {
        return this;
    }
}
