package la;

/* renamed from: la.f  reason: case insensitive filesystem */
public interface C0362f {
}
