package la;

import java.io.IOException;
import java.util.Arrays;
import org.bouncycastle.util.g;

/* renamed from: la.H  reason: case insensitive filesystem */
public final class C0334H extends C0394y {
    public final byte[] a;

    /* renamed from: la.H$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0334H(o0Var.a);
        }
    }

    static {
        new C0337K(C0334H.class);
    }

    public C0334H(byte[] bArr) {
        byte b;
        byte b2;
        if (bArr.length >= 2) {
            this.a = bArr;
            if (bArr.length <= 0 || (b = bArr[0]) < 48 || b > 57 || bArr.length <= 1 || (b2 = bArr[1]) < 48 || b2 > 57) {
                throw new IllegalArgumentException("illegal characters in UTCTime string");
            }
            return;
        }
        throw new IllegalArgumentException("UTCTime string too short");
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0334H)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0334H) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(23, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final String toString() {
        return g.a(this.a);
    }
}
