package la;

import java.io.IOException;

public final class v0 extends C0333G {
    public final void i(C0393x xVar, boolean z) throws IOException {
        C0394y n = this.d.b().n();
        boolean u = u();
        if (z) {
            int i = this.b;
            if (u || n.j()) {
                i |= 32;
            }
            xVar.l(i, this.c);
        }
        if (u) {
            xVar.h(n.k(true));
        }
        n.i(xVar.a(), u);
    }

    public final boolean j() {
        if (u() || this.d.b().n().j()) {
            return true;
        }
        return false;
    }

    public final int k(boolean z) throws IOException {
        int i;
        C0394y n = this.d.b().n();
        boolean u = u();
        int k = n.k(u);
        if (u) {
            k += C0393x.c(k);
        }
        if (z) {
            i = C0393x.e(this.c);
        } else {
            i = 0;
        }
        return k + i;
    }

    public final C0328B v(C0394y yVar) {
        return new s0(yVar);
    }

    public final C0394y n() {
        return this;
    }

    public final C0394y o() {
        return this;
    }
}
