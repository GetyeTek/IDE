package la;

import java.io.IOException;

/* renamed from: la.V  reason: case insensitive filesystem */
public final class C0347V extends C0328B {
    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.k(z, 48, this.a);
    }

    public final int k(boolean z) throws IOException {
        int i;
        if (z) {
            i = 4;
        } else {
            i = 3;
        }
        for (C0364g b : this.a) {
            i += b.b().k(true);
        }
        return i;
    }

    public final C0356c u() {
        return new C0342P(p());
    }

    public final C0370j v() {
        return ((C0328B) o()).v();
    }

    public final C0391v w() {
        C0391v[] q = q();
        return new C0345T(C0345T.q(q), q);
    }

    public final C0329C x() {
        return new C0329C(false, this.a);
    }
}
