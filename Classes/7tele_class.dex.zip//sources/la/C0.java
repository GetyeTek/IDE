package la;

import Bb.k;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1ParsingException;

public final class C0 implements C0358d {
    public final M0 a;
    public int b = 0;

    public C0(M0 m0) {
        this.a = m0;
    }

    public final C0394y b() {
        try {
            return f();
        } catch (IOException e) {
            throw new ASN1ParsingException(k.a(e, new StringBuilder("IOException converting stream to byte array: ")), e);
        }
    }

    public final InputStream d() throws IOException {
        M0 m0 = this.a;
        int i = m0.d;
        if (i >= 1) {
            int read = m0.read();
            this.b = read;
            if (read > 0) {
                if (i < 2) {
                    throw new IllegalStateException("zero length data with non-zero pad bits");
                } else if (read > 7) {
                    throw new IllegalStateException("pad bits cannot be greater than 7 or less than 0");
                }
            }
            return m0;
        }
        throw new IllegalStateException("content octets cannot be empty");
    }

    public final int e() {
        return this.b;
    }

    public final C0394y f() throws IOException {
        return C0356c.p(this.a.b());
    }
}
