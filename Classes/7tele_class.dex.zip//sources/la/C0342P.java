package la;

import com.shinemo.protocol.groupstruct.GroupstructMacro;
import java.io.IOException;

/* renamed from: la.P  reason: case insensitive filesystem */
public final class C0342P extends C0356c {
    public final int d;
    public final C0356c[] e;

    public C0342P(int i, byte[] bArr) {
        super(i, bArr);
        this.e = null;
        this.d = GroupstructMacro.MAX_GROUP_NUMBER_NUM;
    }

    public static byte[] t(C0356c[] cVarArr) {
        if (r2 == 0) {
            return new byte[]{0};
        } else if (r2 == 1) {
            return cVarArr[0].a;
        } else {
            int i = r2 - 1;
            int i2 = 0;
            int i3 = 0;
            while (i2 < i) {
                byte[] bArr = cVarArr[i2].a;
                if (bArr[0] == 0) {
                    i3 += bArr.length - 1;
                    i2++;
                } else {
                    throw new IllegalArgumentException("only the last nested bitstring can have padding");
                }
            }
            byte[] bArr2 = cVarArr[i].a;
            byte b = bArr2[0];
            byte[] bArr3 = new byte[(i3 + bArr2.length)];
            bArr3[0] = b;
            int i4 = 1;
            for (C0356c cVar : cVarArr) {
                byte[] bArr4 = cVar.a;
                int length = bArr4.length - 1;
                System.arraycopy(bArr4, 1, bArr3, i4, length);
                i4 += length;
            }
            return bArr3;
        }
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        boolean j = j();
        byte[] bArr = this.a;
        if (!j) {
            int length = bArr.length;
            xVar.m(3, z);
            xVar.h(length);
            xVar.g(bArr, 0, length);
            return;
        }
        xVar.m(35, z);
        xVar.f(128);
        C0356c[] cVarArr = this.e;
        if (cVarArr != null) {
            xVar.o(cVarArr);
        } else if (bArr.length >= 2) {
            byte b = bArr[0];
            int length2 = bArr.length;
            int i = length2 - 1;
            int i2 = this.d;
            int i3 = i2 - 1;
            while (i > i3) {
                xVar.m(3, true);
                xVar.h(i2);
                xVar.f(0);
                xVar.g(bArr, length2 - i, i3);
                i -= i3;
            }
            xVar.m(3, true);
            xVar.h(i + 1);
            xVar.f(b);
            xVar.g(bArr, length2 - i, i);
        }
        xVar.f(0);
        xVar.f(0);
    }

    public final boolean j() {
        if (this.e != null || this.a.length > this.d) {
            return true;
        }
        return false;
    }

    public final int k(boolean z) throws IOException {
        int i;
        boolean j = j();
        byte[] bArr = this.a;
        if (!j) {
            return C0393x.d(bArr.length, z);
        }
        if (z) {
            i = 4;
        } else {
            i = 3;
        }
        C0356c[] cVarArr = this.e;
        if (cVarArr != null) {
            for (C0356c k : cVarArr) {
                i += k.k(true);
            }
            return i;
        } else if (bArr.length < 2) {
            return i;
        } else {
            int i2 = this.d;
            int i3 = i2 - 1;
            int length = (bArr.length - 2) / i3;
            return C0393x.d(bArr.length - (i3 * length), true) + (C0393x.d(i2, true) * length) + i;
        }
    }

    public C0342P(C0356c[] cVarArr) {
        super(t(cVarArr), false);
        this.e = cVarArr;
        this.d = GroupstructMacro.MAX_GROUP_NUMBER_NUM;
    }
}
