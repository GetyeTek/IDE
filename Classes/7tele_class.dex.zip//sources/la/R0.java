package la;

import java.io.InputStream;

public abstract class R0 extends InputStream {
    public final InputStream a;
    public final int b;

    public R0(InputStream inputStream, int i) {
        this.a = inputStream;
        this.b = i;
    }

    public final void a() {
        InputStream inputStream = this.a;
        if (inputStream instanceof O0) {
            O0 o0 = (O0) inputStream;
            o0.f = true;
            o0.b();
        }
    }
}
