package la;

import Bb.k;
import F0.o;
import androidx.camera.camera2.internal.P;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: la.u  reason: case insensitive filesystem */
public final class C0390u extends C0394y {
    public static final a c = new C0337K(C0390u.class);
    public static final ConcurrentHashMap d = new ConcurrentHashMap();
    public final String a;
    public byte[] b;

    /* renamed from: la.u$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return C0390u.q(o0Var.a, false);
        }
    }

    /* renamed from: la.u$b */
    public static class b {
        public final int a;
        public final byte[] b;

        public b(byte[] bArr) {
            this.a = org.bouncycastle.util.a.h(bArr);
            this.b = bArr;
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof b)) {
                return false;
            }
            return Arrays.equals(this.b, ((b) obj).b);
        }

        public final int hashCode() {
            return this.a;
        }
    }

    public C0390u(String str) {
        char charAt;
        if (str != null) {
            boolean z = false;
            if (str.length() >= 3 && str.charAt(1) == '.' && (charAt = str.charAt(0)) >= '0' && charAt <= '2') {
                z = C0327A.q(2, str);
            }
            if (z) {
                this.a = str;
                return;
            }
            throw new IllegalArgumentException(P.a("string ", str, " not an OID"));
        }
        throw new NullPointerException("'identifier' cannot be null");
    }

    public static C0390u q(byte[] bArr, boolean z) {
        C0390u uVar = (C0390u) d.get(new b(bArr));
        if (uVar == null) {
            return new C0390u(bArr, z);
        }
        return uVar;
    }

    public static C0390u t(Object obj) {
        if (obj == null || (obj instanceof C0390u)) {
            return (C0390u) obj;
        }
        if (obj instanceof C0364g) {
            C0394y b2 = ((C0364g) obj).b();
            if (b2 instanceof C0390u) {
                return (C0390u) b2;
            }
        } else if (obj instanceof byte[]) {
            try {
                return (C0390u) c.b((byte[]) obj);
            } catch (IOException e) {
                throw new IllegalArgumentException(k.a(e, new StringBuilder("failed to construct object identifier from byte[]: ")));
            }
        }
        throw new IllegalArgumentException("illegal object in getInstance: ".concat(obj.getClass().getName()));
    }

    public final boolean h(C0394y yVar) {
        if (yVar == this) {
            return true;
        }
        if (!(yVar instanceof C0390u)) {
            return false;
        }
        return this.a.equals(((C0390u) yVar).a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(6, s(), z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(s().length, z);
    }

    public final void p(String str) {
        new C0390u(str, this);
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
        	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
        */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x005b  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x0087 A[SYNTHETIC] */
    public final void r(java.io.ByteArrayOutputStream r12) {
        /*
            r11 = this;
            java.lang.String r0 = r11.a
            r1 = 46
            r2 = 0
            int r3 = r0.indexOf(r1, r2)
            r4 = -1
            if (r3 != r4) goto L_0x0012
            java.lang.String r2 = r0.substring(r2)
            r3 = -1
            goto L_0x0018
        L_0x0012:
            java.lang.String r2 = r0.substring(r2, r3)
            int r3 = r3 + 1
        L_0x0018:
            int r2 = java.lang.Integer.parseInt(r2)
            int r2 = r2 * 40
            r5 = 0
            if (r3 != r4) goto L_0x0024
            r6 = r3
            r3 = r5
            goto L_0x0036
        L_0x0024:
            int r6 = r0.indexOf(r1, r3)
            if (r6 != r4) goto L_0x0030
            java.lang.String r3 = r0.substring(r3)
            r6 = -1
            goto L_0x0036
        L_0x0030:
            java.lang.String r3 = r0.substring(r3, r6)
            int r6 = r6 + 1
        L_0x0036:
            int r7 = r3.length()
            r8 = 18
            if (r7 > r8) goto L_0x0048
            long r9 = (long) r2
            long r2 = java.lang.Long.parseLong(r3)
            long r2 = r2 + r9
        L_0x0044:
            la.C0327A.r(r12, r2)
            goto L_0x0059
        L_0x0048:
            java.math.BigInteger r7 = new java.math.BigInteger
            r7.<init>(r3)
            long r2 = (long) r2
            java.math.BigInteger r2 = java.math.BigInteger.valueOf(r2)
            java.math.BigInteger r2 = r7.add(r2)
            la.C0327A.s(r12, r2)
        L_0x0059:
            if (r6 == r4) goto L_0x0087
            if (r6 != r4) goto L_0x005f
            r2 = r5
            goto L_0x0073
        L_0x005f:
            int r2 = r0.indexOf(r1, r6)
            if (r2 != r4) goto L_0x006b
            java.lang.String r2 = r0.substring(r6)
            r6 = -1
            goto L_0x0073
        L_0x006b:
            java.lang.String r3 = r0.substring(r6, r2)
            int r2 = r2 + 1
            r6 = r2
            r2 = r3
        L_0x0073:
            int r3 = r2.length()
            if (r3 > r8) goto L_0x007e
            long r2 = java.lang.Long.parseLong(r2)
            goto L_0x0044
        L_0x007e:
            java.math.BigInteger r3 = new java.math.BigInteger
            r3.<init>(r2)
            la.C0327A.s(r12, r3)
            goto L_0x0059
        L_0x0087:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0390u.r(java.io.ByteArrayOutputStream):void");
    }

    public final synchronized byte[] s() {
        try {
            if (this.b == null) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                r(byteArrayOutputStream);
                this.b = byteArrayOutputStream.toByteArray();
            }
        } catch (Throwable th) {
            while (true) {
                throw th;
            }
        }
        return this.b;
    }

    public final String toString() {
        return this.a;
    }

    public final C0390u u() {
        b bVar = new b(s());
        ConcurrentHashMap concurrentHashMap = d;
        C0390u uVar = (C0390u) concurrentHashMap.get(bVar);
        if (uVar != null) {
            return uVar;
        }
        C0390u uVar2 = (C0390u) concurrentHashMap.putIfAbsent(bVar, this);
        if (uVar2 == null) {
            return this;
        }
        return uVar2;
    }

    public final boolean v(C0390u uVar) {
        String str = uVar.a;
        String str2 = this.a;
        if (str2.length() <= str.length() || str2.charAt(str.length()) != '.' || !str2.startsWith(str)) {
            return false;
        }
        return true;
    }

    public C0390u(String str, C0390u uVar) {
        if (C0327A.q(0, str)) {
            this.a = o.a(new StringBuilder(), uVar.a, ".", str);
            return;
        }
        throw new IllegalArgumentException(P.a("string ", str, " not a valid OID branch"));
    }

    public C0390u(byte[] bArr, boolean z) {
        byte[] bArr2 = bArr;
        StringBuffer stringBuffer = new StringBuffer();
        boolean z2 = true;
        BigInteger bigInteger = null;
        long j = 0;
        for (int i = 0; i != bArr2.length; i++) {
            byte b2 = bArr2[i];
            if (j <= 72057594037927808L) {
                long j2 = j + ((long) (b2 & Byte.MAX_VALUE));
                if ((b2 & 128) == 0) {
                    if (z2) {
                        if (j2 < 40) {
                            stringBuffer.append('0');
                        } else if (j2 < 80) {
                            stringBuffer.append('1');
                            j2 -= 40;
                        } else {
                            stringBuffer.append('2');
                            j2 -= 80;
                        }
                        z2 = false;
                    }
                    stringBuffer.append('.');
                    stringBuffer.append(j2);
                } else {
                    j = j2 << 7;
                }
            } else {
                BigInteger or = (bigInteger == null ? BigInteger.valueOf(j) : bigInteger).or(BigInteger.valueOf((long) (b2 & Byte.MAX_VALUE)));
                if ((b2 & 128) == 0) {
                    if (z2) {
                        stringBuffer.append('2');
                        or = or.subtract(BigInteger.valueOf(80));
                        z2 = false;
                    }
                    stringBuffer.append('.');
                    stringBuffer.append(or);
                    bigInteger = null;
                } else {
                    bigInteger = or.shiftLeft(7);
                }
            }
            j = 0;
        }
        this.a = stringBuffer.toString();
        this.b = z ? org.bouncycastle.util.a.a(bArr) : bArr2;
    }
}
