package la;

import java.io.IOException;

/* renamed from: la.y  reason: case insensitive filesystem */
public abstract class C0394y extends C0388s {
    public static C0394y m(byte[] bArr) throws IOException {
        C0380o oVar = new C0380o(bArr);
        try {
            C0394y e = oVar.e();
            if (oVar.available() == 0) {
                return e;
            }
            throw new IOException("Extra data detected in stream");
        } catch (ClassCastException unused) {
            throw new IOException("cannot recognise object in stream");
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0364g) || !h(((C0364g) obj).b())) {
            return false;
        }
        return true;
    }

    public abstract boolean h(C0394y yVar);

    public abstract int hashCode();

    public abstract void i(C0393x xVar, boolean z) throws IOException;

    public abstract boolean j();

    public abstract int k(boolean z) throws IOException;

    public final boolean l(C0394y yVar) {
        if (this == yVar || h(yVar)) {
            return true;
        }
        return false;
    }

    public final C0394y b() {
        return this;
    }

    public C0394y n() {
        return this;
    }

    public C0394y o() {
        return this;
    }
}
