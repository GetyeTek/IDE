package la;

import java.io.IOException;

public final class L0 extends C0353a0 {
    public final boolean d;

    public L0(int i, int i2, boolean z, C0330D d2) {
        super(i, i2, d2);
        this.d = z;
    }

    public final C0394y f() throws IOException {
        C0330D d2 = this.c;
        int i = this.b;
        boolean z = this.d;
        int i2 = this.a;
        if (z) {
            return C0333G.p(i2, i, d2.c());
        }
        C0333G g = new C0333G(4, i2, i, new C0391v(((M0) d2.a).b()));
        if (i2 != 64) {
            return g;
        }
        return new C0352a(g);
    }
}
