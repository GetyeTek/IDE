package la;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public final class O0 extends R0 {
    public int c;
    public int d;
    public boolean e = false;
    public boolean f = true;

    public O0(InputStream inputStream, int i) throws IOException {
        super(inputStream, i);
        this.c = inputStream.read();
        int read = inputStream.read();
        this.d = read;
        if (read >= 0) {
            b();
            return;
        }
        throw new EOFException();
    }

    public final boolean b() {
        if (!this.e && this.f && this.c == 0 && this.d == 0) {
            this.e = true;
            a();
        }
        return this.e;
    }

    public final int read() throws IOException {
        if (b()) {
            return -1;
        }
        int read = this.a.read();
        if (read >= 0) {
            int i = this.c;
            this.c = this.d;
            this.d = read;
            return i;
        }
        throw new EOFException();
    }

    public final int read(byte[] bArr, int i, int i2) throws IOException {
        if (this.f || i2 < 3) {
            return super.read(bArr, i, i2);
        }
        if (this.e) {
            return -1;
        }
        InputStream inputStream = this.a;
        int read = inputStream.read(bArr, i + 2, i2 - 2);
        if (read >= 0) {
            bArr[i] = (byte) this.c;
            bArr[i + 1] = (byte) this.d;
            this.c = inputStream.read();
            int read2 = inputStream.read();
            this.d = read2;
            if (read2 >= 0) {
                return read + 2;
            }
            throw new EOFException();
        }
        throw new EOFException();
    }
}
