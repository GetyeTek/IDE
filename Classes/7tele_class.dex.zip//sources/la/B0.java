package la;

import java.io.IOException;

public final class B0 extends C0356c {
    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(3, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final C0394y o() {
        return this;
    }
}
