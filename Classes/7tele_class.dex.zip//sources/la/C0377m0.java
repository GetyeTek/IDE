package la;

import java.io.IOException;

/* renamed from: la.m0  reason: case insensitive filesystem */
public final class C0377m0 extends C0384q {
    public static final C0377m0 a = new C0384q();
    public static final byte[] b = new byte[0];

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(5, b, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(0, z);
    }
}
