package la;

import Ca.e;
import android.support.v4.media.b;

/* renamed from: la.G  reason: case insensitive filesystem */
public abstract class C0333G extends C0394y implements N0 {
    public final int a;
    public final int b;
    public final int c;
    public final C0364g d;

    public C0333G(int i, int i2, int i3, C0364g gVar) {
        if (gVar == null) {
            throw new NullPointerException("'obj' cannot be null");
        } else if (i2 == 0 || (i2 & 192) != i2) {
            throw new IllegalArgumentException(b.a(i2, "invalid tag class: "));
        } else {
            this.a = gVar instanceof C0362f ? 1 : i;
            this.b = i2;
            this.c = i3;
            this.d = gVar;
        }
    }

    public static C0333G p(int i, int i2, C0366h hVar) {
        C0333G g;
        if (hVar.b == 1) {
            g = new C0333G(3, i, i2, hVar.b(0));
        } else {
            g = new C0333G(4, i, i2, E0.a(hVar));
        }
        if (i != 64) {
            return g;
        }
        return new C0352a(g);
    }

    public static C0333G r(C0364g gVar) {
        if (gVar == null || (gVar instanceof C0333G)) {
            return (C0333G) gVar;
        }
        C0394y b2 = gVar.b();
        if (b2 instanceof C0333G) {
            return (C0333G) b2;
        }
        throw new IllegalArgumentException("unknown object in getInstance: ".concat(gVar.getClass().getName()));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0006, code lost:
        r5 = (la.C0333G) r5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean h(la.C0394y r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof la.C0333G
            r1 = 0
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            la.G r5 = (la.C0333G) r5
            int r0 = r5.c
            int r2 = r4.c
            if (r2 != r0) goto L_0x004f
            int r0 = r4.b
            int r2 = r5.b
            if (r0 == r2) goto L_0x0015
            goto L_0x004f
        L_0x0015:
            int r0 = r4.a
            int r2 = r5.a
            if (r0 == r2) goto L_0x0026
            boolean r0 = r4.u()
            boolean r2 = r5.u()
            if (r0 == r2) goto L_0x0026
            return r1
        L_0x0026:
            la.g r0 = r4.d
            la.y r0 = r0.b()
            la.g r2 = r5.d
            la.y r2 = r2.b()
            if (r0 != r2) goto L_0x0036
            r5 = 1
            return r5
        L_0x0036:
            boolean r3 = r4.u()
            if (r3 != 0) goto L_0x004a
            byte[] r0 = r4.getEncoded()     // Catch:{ IOException -> 0x0049 }
            byte[] r5 = r5.getEncoded()     // Catch:{ IOException -> 0x0049 }
            boolean r5 = java.util.Arrays.equals(r0, r5)     // Catch:{ IOException -> 0x0049 }
            return r5
        L_0x0049:
            return r1
        L_0x004a:
            boolean r5 = r0.h(r2)
            return r5
        L_0x004f:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0333G.h(la.y):boolean");
    }

    public final int hashCode() {
        int i;
        int i2 = (this.b * 7919) ^ this.c;
        if (u()) {
            i = 15;
        } else {
            i = 240;
        }
        return (i2 ^ i) ^ this.d.b().hashCode();
    }

    public C0394y n() {
        return new C0333G(this.a, this.b, this.c, this.d);
    }

    public C0394y o() {
        return new C0333G(this.a, this.b, this.c, this.d);
    }

    public final C0394y q(boolean z, C0337K k) {
        C0364g gVar = this.d;
        if (!z) {
            int i = this.a;
            if (1 != i) {
                C0394y b2 = gVar.b();
                if (i == 3) {
                    return k.c(v(b2));
                }
                if (i != 4) {
                    k.a(b2);
                    return b2;
                } else if (b2 instanceof C0328B) {
                    return k.c((C0328B) b2);
                } else {
                    return k.d((C0381o0) b2);
                }
            } else {
                throw new IllegalStateException("object explicit - implicit expected.");
            }
        } else if (u()) {
            C0394y b3 = gVar.b();
            k.a(b3);
            return b3;
        } else {
            throw new IllegalStateException("object explicit - implicit expected.");
        }
    }

    public final C0394y s() {
        if (128 == this.b) {
            return this.d.b();
        }
        throw new IllegalStateException("this method only valid for CONTEXT_SPECIFIC tags");
    }

    public boolean t() {
        if (this.b == 128 && this.c == 1) {
            return true;
        }
        return false;
    }

    public final String toString() {
        return e.t0(this.b, this.c) + this.d;
    }

    public final boolean u() {
        int i = this.a;
        if (i == 1 || i == 3) {
            return true;
        }
        return false;
    }

    public abstract C0328B v(C0394y yVar);

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public C0333G(boolean z, int i, C0364g gVar) {
        this(z ? 1 : 2, 128, i, gVar);
    }

    public final C0394y f() {
        return this;
    }
}
