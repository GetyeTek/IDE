package la;

import Bb.k;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;
import okhttp3.HttpUrl;
import org.bouncycastle.util.a;

/* renamed from: la.B  reason: case insensitive filesystem */
public abstract class C0328B extends C0394y implements Iterable {
    public static final a b = new C0337K(C0328B.class);
    public C0364g[] a;

    /* renamed from: la.B$b */
    public class b implements Enumeration {
        public int a = 0;

        public b() {
        }

        public final boolean hasMoreElements() {
            if (this.a < C0328B.this.a.length) {
                return true;
            }
            return false;
        }

        public final Object nextElement() {
            int i = this.a;
            C0364g[] gVarArr = C0328B.this.a;
            if (i < gVarArr.length) {
                this.a = i + 1;
                return gVarArr[i];
            }
            throw new NoSuchElementException();
        }
    }

    public C0328B() {
        this.a = C0366h.d;
    }

    public static C0328B r(Object obj) {
        if (obj == null || (obj instanceof C0328B)) {
            return (C0328B) obj;
        }
        if (obj instanceof C0364g) {
            C0394y b2 = ((C0364g) obj).b();
            if (b2 instanceof C0328B) {
                return (C0328B) b2;
            }
        } else if (obj instanceof byte[]) {
            try {
                return (C0328B) b.b((byte[]) obj);
            } catch (IOException e) {
                throw new IllegalArgumentException(k.a(e, new StringBuilder("failed to construct sequence from byte[]: ")));
            }
        }
        throw new IllegalArgumentException("unknown object in getInstance: ".concat(obj.getClass().getName()));
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0328B)) {
            return false;
        }
        C0328B b2 = (C0328B) yVar;
        int size = size();
        if (b2.size() != size) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            C0394y b3 = this.a[i].b();
            C0394y b4 = b2.a[i].b();
            if (b3 != b4 && !b3.h(b4)) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int length = this.a.length;
        int i = length + 1;
        while (true) {
            length--;
            if (length < 0) {
                return i;
            }
            i = (i * 257) ^ this.a[length].b().hashCode();
        }
    }

    public Iterator<C0364g> iterator() {
        return new a.C0048a(this.a);
    }

    public final boolean j() {
        return true;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [la.y, la.s0, la.B] */
    public C0394y n() {
        ? b2 = new C0328B(this.a);
        b2.c = -1;
        return b2;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [la.y, la.B, la.G0] */
    public C0394y o() {
        ? b2 = new C0328B(this.a);
        b2.c = -1;
        return b2;
    }

    public final C0356c[] p() {
        int size = size();
        C0356c[] cVarArr = new C0356c[size];
        for (int i = 0; i < size; i++) {
            cVarArr[i] = C0356c.r(this.a[i]);
        }
        return cVarArr;
    }

    public final C0391v[] q() {
        int size = size();
        C0391v[] vVarArr = new C0391v[size];
        for (int i = 0; i < size; i++) {
            vVarArr[i] = C0391v.p(this.a[i]);
        }
        return vVarArr;
    }

    public C0364g s(int i) {
        return this.a[i];
    }

    public int size() {
        return this.a.length;
    }

    public Enumeration t() {
        return new b();
    }

    public final String toString() {
        int size = size();
        if (size == 0) {
            return HttpUrl.PATH_SEGMENT_ENCODE_SET_URI;
        }
        StringBuffer stringBuffer = new StringBuffer("[");
        int i = 0;
        while (true) {
            stringBuffer.append(this.a[i]);
            i++;
            if (i >= size) {
                stringBuffer.append(']');
                return stringBuffer.toString();
            }
            stringBuffer.append(", ");
        }
    }

    public abstract C0356c u();

    public abstract C0370j v();

    public abstract C0391v w();

    public abstract C0329C x();

    public C0328B(C0366h hVar) {
        if (hVar != null) {
            this.a = hVar.c();
            return;
        }
        throw new NullPointerException("'elementVector' cannot be null");
    }

    public C0328B(C0394y yVar) {
        if (yVar != null) {
            this.a = new C0364g[]{yVar};
            return;
        }
        throw new NullPointerException("'element' cannot be null");
    }

    public C0328B(C0364g[] gVarArr) {
        this.a = gVarArr;
    }

    /* renamed from: la.B$a */
    public static class a extends C0337K {
        public final C0394y c(C0328B b) {
            return b;
        }
    }
}
