package la;

public final class D0 extends C0370j {
    public final C0328B p() {
        boolean z;
        C0366h hVar = new C0366h(4);
        C0390u uVar = this.a;
        if (uVar != null) {
            hVar.a(uVar);
        }
        C0382p pVar = this.b;
        if (pVar != null) {
            hVar.a(pVar);
        }
        C0394y yVar = this.c;
        if (yVar != null) {
            hVar.a(yVar.o());
        }
        int i = this.d;
        if (i == 0) {
            z = true;
        } else {
            z = false;
        }
        hVar.a(new C0333G(z, i, this.e));
        return new G0(hVar);
    }

    public final C0394y o() {
        return this;
    }
}
