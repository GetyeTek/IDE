package la;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/* renamed from: la.x  reason: case insensitive filesystem */
public class C0393x {
    public final ByteArrayOutputStream a;

    public C0393x(ByteArrayOutputStream byteArrayOutputStream) {
        this.a = byteArrayOutputStream;
    }

    public static int c(int i) {
        if (i < 128) {
            return 1;
        }
        int i2 = 2;
        while (true) {
            i >>>= 8;
            if (i == 0) {
                return i2;
            }
            i2++;
        }
    }

    public static int d(int i, boolean z) {
        return c(i) + (z ? 1 : 0) + i;
    }

    public static int e(int i) {
        if (i < 31) {
            return 1;
        }
        int i2 = 2;
        while (true) {
            i >>>= 7;
            if (i == 0) {
                return i2;
            }
            i2++;
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [la.q0, la.x] */
    public C0385q0 a() {
        return new C0393x(this.a);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [la.x, la.F0] */
    public F0 b() {
        return new C0393x(this.a);
    }

    public final void f(int i) throws IOException {
        this.a.write(i);
    }

    public final void g(byte[] bArr, int i, int i2) throws IOException {
        this.a.write(bArr, i, i2);
    }

    public final void h(int i) throws IOException {
        if (i < 128) {
            f(i);
            return;
        }
        int i2 = 5;
        byte[] bArr = new byte[5];
        while (true) {
            int i3 = i2 - 1;
            bArr[i3] = (byte) i;
            i >>>= 8;
            if (i == 0) {
                int i4 = i2 - 2;
                bArr[i4] = (byte) ((5 - i3) | 128);
                g(bArr, i4, 6 - i3);
                return;
            }
            i2 = i3;
        }
    }

    public void i(C0364g[] gVarArr) throws IOException {
        for (C0364g b : gVarArr) {
            b.b().i(this, true);
        }
    }

    public final void j(int i, byte[] bArr, boolean z) throws IOException {
        m(i, z);
        h(bArr.length);
        g(bArr, 0, bArr.length);
    }

    public final void k(boolean z, int i, C0364g[] gVarArr) throws IOException {
        m(i, z);
        f(128);
        i(gVarArr);
        f(0);
        f(0);
    }

    public final void l(int i, int i2) throws IOException {
        if (i2 < 31) {
            f(i | i2);
            return;
        }
        byte[] bArr = new byte[6];
        int i3 = 5;
        bArr[5] = (byte) (i2 & 127);
        while (i2 > 127) {
            i2 >>>= 7;
            i3--;
            bArr[i3] = (byte) ((i2 & 127) | 128);
        }
        int i4 = i3 - 1;
        bArr[i4] = (byte) (i | 31);
        g(bArr, i4, 6 - i4);
    }

    public final void m(int i, boolean z) throws IOException {
        if (z) {
            f(i);
        }
    }

    public void n(C0394y yVar) throws IOException {
        yVar.i(this, true);
    }

    public void o(C0394y[] yVarArr) throws IOException {
        for (C0394y i : yVarArr) {
            i.i(this, true);
        }
    }
}
