package la;

/* renamed from: la.h  reason: case insensitive filesystem */
public final class C0366h {
    public static final C0364g[] d = new C0364g[0];
    public C0364g[] a;
    public int b;
    public boolean c;

    public C0366h() {
        this(10);
    }

    public final void a(C0364g gVar) {
        if (gVar != null) {
            C0364g[] gVarArr = this.a;
            int length = gVarArr.length;
            boolean z = true;
            int i = this.b + 1;
            if (i <= length) {
                z = false;
            }
            if (this.c || z) {
                C0364g[] gVarArr2 = new C0364g[Math.max(gVarArr.length, (i >> 1) + i)];
                System.arraycopy(this.a, 0, gVarArr2, 0, this.b);
                this.a = gVarArr2;
                this.c = false;
            }
            this.a[this.b] = gVar;
            this.b = i;
            return;
        }
        throw new NullPointerException("'element' cannot be null");
    }

    public final C0364g b(int i) {
        if (i < this.b) {
            return this.a[i];
        }
        throw new ArrayIndexOutOfBoundsException(i + " >= " + this.b);
    }

    public final C0364g[] c() {
        int i = this.b;
        if (i == 0) {
            return d;
        }
        C0364g[] gVarArr = this.a;
        if (gVarArr.length == i) {
            this.c = true;
            return gVarArr;
        }
        C0364g[] gVarArr2 = new C0364g[i];
        System.arraycopy(gVarArr, 0, gVarArr2, 0, i);
        return gVarArr2;
    }

    public C0366h(int i) {
        if (i >= 0) {
            this.a = i == 0 ? d : new C0364g[i];
            this.b = 0;
            this.c = false;
            return;
        }
        throw new IllegalArgumentException("'initialCapacity' must not be negative");
    }
}
