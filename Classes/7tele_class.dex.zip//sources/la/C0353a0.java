package la;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1ParsingException;

/* renamed from: la.a0  reason: case insensitive filesystem */
public class C0353a0 implements C0364g, N0 {
    public final int a;
    public final int b;
    public final C0330D c;

    public C0353a0(int i, int i2, C0330D d) {
        this.a = i;
        this.b = i2;
        this.c = d;
    }

    public final C0394y b() {
        try {
            return f();
        } catch (IOException e) {
            throw new ASN1ParsingException(e.getMessage());
        }
    }

    public C0394y f() throws IOException {
        return this.c.b(this.a, this.b);
    }
}
