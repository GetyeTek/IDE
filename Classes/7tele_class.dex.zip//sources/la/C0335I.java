package la;

import Ub.e;
import java.io.IOException;
import java.util.Arrays;
import okio.Utf8;
import org.bouncycastle.util.g;

/* renamed from: la.I  reason: case insensitive filesystem */
public abstract class C0335I extends C0394y implements C0331E {
    public final byte[] a;

    /* renamed from: la.I$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0335I(o0Var.a);
        }
    }

    static {
        new C0337K(C0335I.class);
    }

    public C0335I(byte[] bArr) {
        this.a = bArr;
    }

    public final String c() {
        String str = g.a;
        byte[] bArr = this.a;
        int length = bArr.length;
        char[] cArr = new char[length];
        short[] sArr = e.a;
        int length2 = bArr.length;
        int i = 0;
        int i2 = 0;
        loop0:
        while (true) {
            if (i >= length2) {
                break;
            }
            int i3 = i + 1;
            byte b = bArr[i];
            if (b < 0) {
                short s = e.a[b & Byte.MAX_VALUE];
                int i4 = s >>> 8;
                byte b2 = (byte) s;
                while (true) {
                    if (b2 < 0) {
                        if (b2 == -2) {
                            break;
                        }
                        if (i4 <= 65535) {
                            if (i2 >= length) {
                                break;
                            }
                            cArr[i2] = (char) i4;
                            i2++;
                        } else if (i2 >= length - 1) {
                            break;
                        } else {
                            int i5 = i2 + 1;
                            cArr[i2] = (char) ((i4 >>> 10) + Utf8.HIGH_SURROGATE_HEADER);
                            i2 += 2;
                            cArr[i5] = (char) ((i4 & 1023) | Utf8.LOG_SURROGATE_HEADER);
                        }
                        i = i3;
                    } else if (i3 >= bArr.length) {
                        break loop0;
                    } else {
                        int i6 = i3 + 1;
                        byte b3 = bArr[i3];
                        i4 = (i4 << 6) | (b3 & Utf8.REPLACEMENT_BYTE);
                        b2 = e.b[b2 + ((b3 & 255) >>> 4)];
                        i3 = i6;
                    }
                }
            } else if (i2 >= length) {
                break;
            } else {
                cArr[i2] = (char) b;
                i = i3;
                i2++;
            }
        }
        i2 = -1;
        if (i2 >= 0) {
            return new String(cArr, 0, i2);
        }
        throw new IllegalArgumentException("Invalid UTF-8 input");
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0335I)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0335I) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(12, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public final String toString() {
        return c();
    }
}
