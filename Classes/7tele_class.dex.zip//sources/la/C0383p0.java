package la;

import Bb.k;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1ParsingException;

/* renamed from: la.p0  reason: case insensitive filesystem */
public final class C0383p0 implements C0392w {
    public M0 a;

    public final InputStream a() {
        return this.a;
    }

    public final C0394y b() {
        try {
            return f();
        } catch (IOException e) {
            throw new ASN1ParsingException(k.a(e, new StringBuilder("IOException converting stream to byte array: ")), e);
        }
    }

    public final C0394y f() throws IOException {
        return new C0391v(this.a.b());
    }
}
