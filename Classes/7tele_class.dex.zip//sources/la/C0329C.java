package la;

import Bb.k;
import java.io.IOException;
import java.util.Iterator;
import okhttp3.HttpUrl;
import org.bouncycastle.util.a;

/* renamed from: la.C  reason: case insensitive filesystem */
public abstract class C0329C extends C0394y implements Iterable {
    public static final a c = new C0337K(C0329C.class);
    public final C0364g[] a;
    public final boolean b;

    /* renamed from: la.C$a */
    public static class a extends C0337K {
        public final C0394y c(C0328B b) {
            return b.x();
        }
    }

    public C0329C() {
        this.a = C0366h.d;
        this.b = true;
    }

    public static byte[] p(C0364g gVar) {
        try {
            return gVar.b().g();
        } catch (IOException unused) {
            throw new IllegalArgumentException("cannot encode object added to SET");
        }
    }

    public static C0329C q(Object obj) {
        if (obj == null || (obj instanceof C0329C)) {
            return (C0329C) obj;
        }
        if (obj instanceof C0364g) {
            C0394y b2 = ((C0364g) obj).b();
            if (b2 instanceof C0329C) {
                return (C0329C) b2;
            }
        } else if (obj instanceof byte[]) {
            try {
                return (C0329C) c.b((byte[]) obj);
            } catch (IOException e) {
                throw new IllegalArgumentException(k.a(e, new StringBuilder("failed to construct set from byte[]: ")));
            }
        }
        throw new IllegalArgumentException("unknown object in getInstance: ".concat(obj.getClass().getName()));
    }

    public static boolean r(byte[] bArr, byte[] bArr2) {
        byte b2 = bArr[0] & -33;
        byte b3 = bArr2[0] & -33;
        if (b2 == b3) {
            int min = Math.min(bArr.length, bArr2.length) - 1;
            int i = 1;
            while (i < min) {
                byte b4 = bArr[i];
                byte b5 = bArr2[i];
                if (b4 == b5) {
                    i++;
                } else if ((b4 & 255) < (b5 & 255)) {
                    return true;
                } else {
                    return false;
                }
            }
            if ((bArr[min] & 255) <= (bArr2[min] & 255)) {
                return true;
            }
            return false;
        } else if (b2 < b3) {
            return true;
        } else {
            return false;
        }
    }

    public static void s(C0364g[] gVarArr) {
        int i;
        int length = gVarArr.length;
        if (length >= 2) {
            C0364g gVar = gVarArr[0];
            C0364g gVar2 = gVarArr[1];
            byte[] p = p(gVar);
            byte[] p2 = p(gVar2);
            if (r(p2, p)) {
                C0364g gVar3 = gVar2;
                gVar2 = gVar;
                gVar = gVar3;
                byte[] bArr = p2;
                p2 = p;
                p = bArr;
            }
            for (int i2 = 2; i2 < length; i2++) {
                C0364g gVar4 = gVarArr[i2];
                byte[] p3 = p(gVar4);
                if (r(p2, p3)) {
                    gVarArr[i2 - 2] = gVar;
                    gVar = gVar2;
                    p = p2;
                    gVar2 = gVar4;
                    p2 = p3;
                } else if (r(p, p3)) {
                    gVarArr[i2 - 2] = gVar;
                    gVar = gVar4;
                    p = p3;
                } else {
                    int i3 = i2 - 1;
                    while (true) {
                        i = i3 - 1;
                        if (i <= 0) {
                            break;
                        }
                        C0364g gVar5 = gVarArr[i3 - 2];
                        if (r(p(gVar5), p3)) {
                            break;
                        }
                        gVarArr[i] = gVar5;
                        i3 = i;
                    }
                    gVarArr[i] = gVar4;
                }
            }
            gVarArr[length - 2] = gVar;
            gVarArr[length - 1] = gVar2;
        }
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0329C)) {
            return false;
        }
        C0329C c2 = (C0329C) yVar;
        int length = this.a.length;
        if (c2.a.length != length) {
            return false;
        }
        t0 t0Var = (t0) n();
        t0 t0Var2 = (t0) c2.n();
        for (int i = 0; i < length; i++) {
            C0394y b2 = t0Var.a[i].b();
            C0394y b3 = t0Var2.a[i].b();
            if (b2 != b3 && !b2.h(b3)) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        C0364g[] gVarArr = this.a;
        int length = gVarArr.length;
        int i = length + 1;
        while (true) {
            length--;
            if (length < 0) {
                return i;
            }
            i += gVarArr[length].b().hashCode();
        }
    }

    public final Iterator<C0364g> iterator() {
        C0364g[] gVarArr;
        C0364g[] gVarArr2 = this.a;
        if (gVarArr2.length < 1) {
            gVarArr = C0366h.d;
        } else {
            gVarArr = (C0364g[]) gVarArr2.clone();
        }
        return new a.C0048a(gVarArr);
    }

    public final boolean j() {
        return true;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [la.y, la.C, la.t0] */
    public C0394y n() {
        boolean z = this.b;
        C0364g[] gVarArr = this.a;
        if (!z) {
            gVarArr = (C0364g[]) gVarArr.clone();
            s(gVarArr);
        }
        ? c2 = new C0329C(true, gVarArr);
        c2.d = -1;
        return c2;
    }

    public C0394y o() {
        return new I0(this.b, this.a);
    }

    public final String toString() {
        C0364g[] gVarArr = this.a;
        int length = gVarArr.length;
        if (length == 0) {
            return HttpUrl.PATH_SEGMENT_ENCODE_SET_URI;
        }
        StringBuffer stringBuffer = new StringBuffer("[");
        int i = 0;
        while (true) {
            stringBuffer.append(gVarArr[i]);
            i++;
            if (i >= length) {
                stringBuffer.append(']');
                return stringBuffer.toString();
            }
            stringBuffer.append(", ");
        }
    }

    public C0329C(C0366h hVar, boolean z) {
        C0364g[] gVarArr;
        int i;
        if (hVar != null) {
            boolean z2 = false;
            if (!z || (i = hVar.b) < 2) {
                gVarArr = hVar.c();
            } else {
                if (i == 0) {
                    gVarArr = C0366h.d;
                } else {
                    C0364g[] gVarArr2 = new C0364g[i];
                    System.arraycopy(hVar.a, 0, gVarArr2, 0, i);
                    gVarArr = gVarArr2;
                }
                s(gVarArr);
            }
            this.a = gVarArr;
            this.b = (z || gVarArr.length < 2) ? true : z2;
            return;
        }
        throw new NullPointerException("'elementVector' cannot be null");
    }

    public C0329C(boolean z, C0364g[] gVarArr) {
        this.a = gVarArr;
        this.b = z || gVarArr.length < 2;
    }
}
