package la;

import java.io.IOException;
import java.util.Arrays;

/* renamed from: la.l  reason: case insensitive filesystem */
public class C0374l extends C0394y {
    public final byte[] a;

    /* renamed from: la.l$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return new C0374l(o0Var.a);
        }
    }

    static {
        new C0337K(C0374l.class);
    }

    public C0374l(byte[] bArr) {
        if (bArr.length >= 4) {
            this.a = bArr;
            if (!p(0) || !p(1) || !p(2) || !p(3)) {
                throw new IllegalArgumentException("illegal characters in GeneralizedTime string");
            }
            return;
        }
        throw new IllegalArgumentException("GeneralizedTime string too short");
    }

    public final boolean h(C0394y yVar) {
        if (!(yVar instanceof C0374l)) {
            return false;
        }
        return Arrays.equals(this.a, ((C0374l) yVar).a);
    }

    public final int hashCode() {
        return org.bouncycastle.util.a.h(this.a);
    }

    public void i(C0393x xVar, boolean z) throws IOException {
        xVar.j(24, this.a, z);
    }

    public final boolean j() {
        return false;
    }

    public int k(boolean z) {
        return C0393x.d(this.a.length, z);
    }

    public C0394y n() {
        return new C0374l(this.a);
    }

    public final boolean p(int i) {
        byte b;
        byte[] bArr = this.a;
        if (bArr.length <= i || (b = bArr[i]) < 48 || b > 57) {
            return false;
        }
        return true;
    }
}
