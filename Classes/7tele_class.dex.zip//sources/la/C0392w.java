package la;

import java.io.InputStream;

/* renamed from: la.w  reason: case insensitive filesystem */
public interface C0392w extends C0364g, N0 {
    InputStream a();
}
