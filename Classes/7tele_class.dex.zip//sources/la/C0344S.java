package la;

/* renamed from: la.S  reason: case insensitive filesystem */
public final class C0344S {
    public static final C0347V a = new C0328B();

    /* JADX WARNING: type inference failed for: r0v0, types: [la.B, la.V] */
    static {
        new C0329C();
    }
}
