package la;

import java.io.IOException;

public final class H0 implements C0364g, N0 {
    public C0330D a;

    public final C0394y b() {
        try {
            return f();
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage());
        }
    }

    public final C0394y f() throws IOException {
        return E0.a(this.a.c());
    }
}
