package la;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Exception;

/* renamed from: la.D  reason: case insensitive filesystem */
public final class C0330D {
    public final R0 a;
    public final int b;
    public final byte[][] c;

    public C0330D(R0 r0, int i, byte[][] bArr) {
        this.a = r0;
        this.b = i;
        this.c = bArr;
    }

    /* JADX WARNING: type inference failed for: r15v4, types: [java.lang.Object, la.g, la.H0] */
    /* JADX WARNING: type inference failed for: r15v6, types: [la.J0, java.lang.Object, la.g] */
    /* JADX WARNING: type inference failed for: r15v13, types: [la.p0, java.lang.Object, la.g] */
    /* JADX WARNING: type inference failed for: r15v24, types: [java.lang.Object, la.W, la.g] */
    /* JADX WARNING: type inference failed for: r15v26, types: [la.Y, java.lang.Object, la.g] */
    public final C0364g a(int i) throws IOException {
        boolean z;
        C0333G g;
        R0 r0 = this.a;
        boolean z2 = false;
        if (r0 instanceof O0) {
            O0 o0 = (O0) r0;
            o0.f = false;
            o0.b();
        }
        int f = C0380o.f(r0, i);
        if (f == 3 || f == 4 || f == 16 || f == 17 || f == 8) {
            z = true;
        } else {
            z = false;
        }
        int i2 = this.b;
        int d = C0380o.d(r0, i2, z);
        byte[][] bArr = this.c;
        if (d >= 0) {
            M0 m0 = new M0(r0, d, i2);
            if ((i & 224) != 0) {
                C0330D d2 = new C0330D(m0, m0.b, bArr);
                int i3 = i & 192;
                if (i3 != 0) {
                    if ((i & 32) != 0) {
                        z2 = true;
                    }
                    if (64 != i3) {
                        return new L0(i3, f, z2, d2);
                    }
                    if (!z2) {
                        g = new C0333G(4, i3, f, new C0391v(m0.b()));
                        if (i3 == 64) {
                            g = new C0352a(g);
                        }
                    } else {
                        g = C0333G.p(i3, f, d2.c());
                    }
                    return (A0) g;
                } else if (f == 3) {
                    return new C0343Q(d2);
                } else {
                    if (f == 4) {
                        return new C0346U(d2);
                    }
                    if (f == 8) {
                        return new C0367h0(d2);
                    }
                    if (f == 16) {
                        ? obj = new Object();
                        obj.a = d2;
                        return obj;
                    } else if (f == 17) {
                        ? obj2 = new Object();
                        obj2.a = d2;
                        return obj2;
                    } else {
                        throw new ASN1Exception("unknown DL object encountered: 0x" + Integer.toHexString(f));
                    }
                }
            } else if (f == 3) {
                return new C0(m0);
            } else {
                if (f == 4) {
                    ? obj3 = new Object();
                    obj3.a = m0;
                    return obj3;
                } else if (f == 8) {
                    throw new ASN1Exception("externals must use constructed encoding (see X.690 8.18)");
                } else if (f == 16) {
                    throw new ASN1Exception("sets must use constructed encoding (see X.690 8.11.1/8.12.1)");
                } else if (f != 17) {
                    try {
                        return C0380o.b(f, m0, bArr);
                    } catch (IllegalArgumentException e) {
                        throw new ASN1Exception("corrupted stream detected", e);
                    }
                } else {
                    throw new ASN1Exception("sequences must use constructed encoding (see X.690 8.9.1/8.10.1)");
                }
            }
        } else if ((i & 32) != 0) {
            C0330D d3 = new C0330D(new O0(r0, i2), i2, bArr);
            int i4 = i & 192;
            if (i4 != 0) {
                if (64 == i4) {
                    return new C0353a0(64, f, d3);
                }
                return new C0353a0(i4, f, d3);
            } else if (f == 3) {
                return new C0343Q(d3);
            } else {
                if (f == 4) {
                    return new C0346U(d3);
                }
                if (f == 8) {
                    return new C0367h0(d3);
                }
                if (f == 16) {
                    ? obj4 = new Object();
                    obj4.a = d3;
                    return obj4;
                } else if (f == 17) {
                    ? obj5 = new Object();
                    obj5.a = d3;
                    return obj5;
                } else {
                    throw new ASN1Exception("unknown BER object encountered: 0x" + Integer.toHexString(f));
                }
            }
        } else {
            throw new IOException("indefinite-length primitive encoding encountered");
        }
    }

    public final C0333G b(int i, int i2) throws IOException {
        C0333G g;
        C0328B b2;
        C0366h c2 = c();
        int i3 = c2.b;
        if (i3 == 1) {
            g = new C0333G(3, i, i2, c2.b(0));
        } else {
            C0347V v = C0344S.a;
            if (i3 < 1) {
                b2 = C0344S.a;
            } else {
                b2 = new C0328B(c2);
            }
            g = new C0333G(4, i, i2, b2);
        }
        if (i != 64) {
            return g;
        }
        return new C0352a(g);
    }

    public final C0366h c() throws IOException {
        C0394y b2;
        R0 r0 = this.a;
        int read = r0.read();
        if (read < 0) {
            return new C0366h(0);
        }
        C0366h hVar = new C0366h();
        do {
            C0364g a2 = a(read);
            if (a2 instanceof N0) {
                b2 = ((N0) a2).f();
            } else {
                b2 = a2.b();
            }
            hVar.a(b2);
            read = r0.read();
        } while (read >= 0);
        return hVar;
    }
}
