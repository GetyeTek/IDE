package la;

import java.io.IOException;

public interface N0 {
    C0394y f() throws IOException;
}
