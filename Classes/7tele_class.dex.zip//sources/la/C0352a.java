package la;

import java.io.IOException;

/* renamed from: la.a  reason: case insensitive filesystem */
public abstract class C0352a extends C0333G {
    public final C0333G e;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0352a(la.C0333G r5) {
        /*
            r4 = this;
            int r0 = r5.a
            int r1 = r5.b
            r2 = 64
            if (r2 != r1) goto L_0x0012
            int r2 = r5.c
            la.g r3 = r5.d
            r4.<init>(r0, r1, r2, r3)
            r4.e = r5
            return
        L_0x0012:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            r5.<init>()
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: la.C0352a.<init>(la.G):void");
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        this.e.i(xVar, z);
    }

    public final boolean j() {
        return this.e.j();
    }

    public final int k(boolean z) throws IOException {
        return this.e.k(z);
    }

    public C0394y n() {
        return new C0352a((C0333G) this.e.n());
    }

    public C0394y o() {
        return new C0352a((C0333G) this.e.o());
    }

    public final boolean t() {
        return false;
    }

    public final C0328B v(C0394y yVar) {
        return this.e.v(yVar);
    }
}
