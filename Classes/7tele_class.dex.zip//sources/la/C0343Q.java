package la;

import Bb.k;
import Vb.a;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1ParsingException;

/* renamed from: la.Q  reason: case insensitive filesystem */
public final class C0343Q implements C0358d {
    public final C0330D a;
    public C0355b0 b;

    public C0343Q(C0330D d) {
        this.a = d;
    }

    public static C0342P c(C0330D d) throws IOException {
        C0355b0 b0Var = new C0355b0(d);
        return new C0342P(b0Var.c, a.a(b0Var));
    }

    public final C0394y b() {
        try {
            return c(this.a);
        } catch (IOException e) {
            throw new ASN1ParsingException(k.a(e, new StringBuilder("IOException converting stream to byte array: ")), e);
        }
    }

    public final InputStream d() throws IOException {
        C0355b0 b0Var = new C0355b0(this.a);
        this.b = b0Var;
        return b0Var;
    }

    public final int e() {
        return this.b.c;
    }

    public final C0394y f() throws IOException {
        return c(this.a);
    }
}
