package la;

import java.io.IOException;

/* renamed from: la.W  reason: case insensitive filesystem */
public final class C0348W implements C0364g, N0 {
    public C0330D a;

    public final C0394y b() {
        try {
            return new C0328B(this.a.c());
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage());
        }
    }

    public final C0394y f() throws IOException {
        return new C0328B(this.a.c());
    }
}
