package la;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1ParsingException;

/* renamed from: la.Y  reason: case insensitive filesystem */
public final class C0350Y implements C0364g, N0 {
    public C0330D a;

    public final C0394y b() {
        try {
            return new C0329C(this.a.c(), false);
        } catch (IOException e) {
            throw new ASN1ParsingException(e.getMessage(), e);
        }
    }

    public final C0394y f() throws IOException {
        return new C0329C(this.a.c(), false);
    }
}
