package la;

public final class x0 extends C0336J {
}
