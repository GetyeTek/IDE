package la;

import java.io.IOException;

public final class K0 extends C0333G {
    public final void i(C0393x xVar, boolean z) throws IOException {
        C0394y o = this.d.b().o();
        boolean u = u();
        if (z) {
            int i = this.b;
            if (u || o.j()) {
                i |= 32;
            }
            xVar.l(i, this.c);
        }
        if (u) {
            xVar.h(o.k(true));
        }
        o.i(xVar.b(), u);
    }

    public final boolean j() {
        if (u() || this.d.b().o().j()) {
            return true;
        }
        return false;
    }

    public final int k(boolean z) throws IOException {
        int i;
        C0394y o = this.d.b().o();
        boolean u = u();
        int k = o.k(u);
        if (u) {
            k += C0393x.c(k);
        }
        if (z) {
            i = C0393x.e(this.c);
        } else {
            i = 0;
        }
        return k + i;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [la.B, la.G0] */
    public final C0328B v(C0394y yVar) {
        ? b = new C0328B(yVar);
        b.c = -1;
        return b;
    }

    public final C0394y o() {
        return this;
    }
}
