package la;

import java.io.IOException;

/* renamed from: la.X  reason: case insensitive filesystem */
public final class C0349X extends C0329C {
    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.k(z, 49, this.a);
    }

    public final int k(boolean z) throws IOException {
        int i;
        if (z) {
            i = 4;
        } else {
            i = 3;
        }
        for (C0364g b : this.a) {
            i += b.b().k(true);
        }
        return i;
    }
}
