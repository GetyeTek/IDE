package la;

import java.io.IOException;

public final class t0 extends C0329C {
    public int d = -1;

    public t0() {
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.m(49, z);
        C0385q0 a = xVar.a();
        C0364g[] gVarArr = this.a;
        int length = gVarArr.length;
        int i = 0;
        if (this.d >= 0 || length > 16) {
            xVar.h(t());
            while (i < length) {
                gVarArr[i].b().n().i(a, true);
                i++;
            }
            return;
        }
        C0394y[] yVarArr = new C0394y[length];
        int i2 = 0;
        for (int i3 = 0; i3 < length; i3++) {
            C0394y n = gVarArr[i3].b().n();
            yVarArr[i3] = n;
            i2 += n.k(true);
        }
        this.d = i2;
        xVar.h(i2);
        while (i < length) {
            yVarArr[i].i(a, true);
            i++;
        }
    }

    public final int k(boolean z) throws IOException {
        return C0393x.d(t(), z);
    }

    public final C0394y n() {
        if (this.b) {
            return this;
        }
        return super.n();
    }

    public final int t() throws IOException {
        if (this.d < 0) {
            int i = 0;
            for (C0364g b : this.a) {
                i += b.b().n().k(true);
            }
            this.d = i;
        }
        return this.d;
    }

    public t0(C0366h hVar) {
        super(hVar, true);
    }

    public final C0394y o() {
        return this;
    }
}
