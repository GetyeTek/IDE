package la;

/* renamed from: la.g0  reason: case insensitive filesystem */
public final class C0365g0 extends C0370j {
    public final C0328B p() {
        boolean z;
        C0366h hVar = new C0366h(4);
        C0390u uVar = this.a;
        if (uVar != null) {
            hVar.a(uVar);
        }
        C0382p pVar = this.b;
        if (pVar != null) {
            hVar.a(pVar);
        }
        C0394y yVar = this.c;
        if (yVar != null) {
            hVar.a(yVar.n());
        }
        int i = this.d;
        if (i == 0) {
            z = true;
        } else {
            z = false;
        }
        hVar.a(new C0333G(z, i, this.e));
        return new s0(hVar);
    }

    public final C0394y n() {
        return this;
    }

    public final C0394y o() {
        return this;
    }
}
