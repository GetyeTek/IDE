package la;

import Bb.k;
import Vb.a;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1ParsingException;

/* renamed from: la.U  reason: case insensitive filesystem */
public final class C0346U implements C0392w {
    public final C0330D a;

    public C0346U(C0330D d) {
        this.a = d;
    }

    public static C0345T c(C0330D d) throws IOException {
        return new C0345T(a.a(new C0357c0(d)), (C0391v[]) null);
    }

    public final InputStream a() {
        return new C0357c0(this.a);
    }

    public final C0394y b() {
        try {
            return c(this.a);
        } catch (IOException e) {
            throw new ASN1ParsingException(k.a(e, new StringBuilder("IOException converting stream to byte array: ")), e);
        }
    }

    public final C0394y f() throws IOException {
        return c(this.a);
    }
}
