package la;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Exception;
import org.bouncycastle.asn1.ASN1ParsingException;

/* renamed from: la.h0  reason: case insensitive filesystem */
public final class C0367h0 implements C0364g, N0 {
    public final C0330D a;

    public C0367h0(C0330D d) {
        this.a = d;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [la.j, la.D0] */
    public static D0 c(C0330D d) throws IOException {
        try {
            return new C0370j(E0.a(d.c()));
        } catch (IllegalArgumentException e) {
            throw new ASN1Exception(e.getMessage(), e);
        }
    }

    public final C0394y b() {
        try {
            return c(this.a);
        } catch (IOException e) {
            throw new ASN1ParsingException("unable to get DER object", e);
        } catch (IllegalArgumentException e2) {
            throw new ASN1ParsingException("unable to get DER object", e2);
        }
    }

    public final C0394y f() throws IOException {
        return c(this.a);
    }
}
