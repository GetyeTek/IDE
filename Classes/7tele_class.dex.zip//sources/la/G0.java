package la;

import java.io.IOException;

public final class G0 extends C0328B {
    public int c = -1;

    public G0(C0366h hVar) {
        super(hVar);
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.m(48, z);
        F0 b = xVar.b();
        int length = this.a.length;
        int i = 0;
        if (this.c >= 0 || length > 16) {
            xVar.h(y());
            while (i < length) {
                b.n(this.a[i].b());
                i++;
            }
            return;
        }
        C0394y[] yVarArr = new C0394y[length];
        int i2 = 0;
        for (int i3 = 0; i3 < length; i3++) {
            C0394y o = this.a[i3].b().o();
            yVarArr[i3] = o;
            i2 += o.k(true);
        }
        this.c = i2;
        xVar.h(i2);
        while (i < length) {
            b.n(yVarArr[i]);
            i++;
        }
    }

    public final int k(boolean z) throws IOException {
        return C0393x.d(y(), z);
    }

    public final C0356c u() {
        return new C0356c(C0342P.t(p()), false);
    }

    public final C0370j v() {
        return new C0370j(this);
    }

    public final C0391v w() {
        return new C0391v(C0345T.q(q()));
    }

    public final C0329C x() {
        return new I0(false, this.a);
    }

    public final int y() throws IOException {
        if (this.c < 0) {
            int i = 0;
            for (C0364g b : this.a) {
                i += b.b().o().k(true);
            }
            this.c = i;
        }
        return this.c;
    }

    public final C0394y o() {
        return this;
    }
}
