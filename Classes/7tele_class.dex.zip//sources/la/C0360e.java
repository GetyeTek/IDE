package la;

import java.io.IOException;

/* renamed from: la.e  reason: case insensitive filesystem */
public final class C0360e extends C0394y {
    public static final a b = new C0337K(C0360e.class);
    public static final C0360e c = new C0360e((byte) 0);
    public static final C0360e d = new C0360e((byte) -1);
    public final byte a;

    /* renamed from: la.e$a */
    public static class a extends C0337K {
        public final C0394y d(C0381o0 o0Var) {
            return C0360e.p(o0Var.a);
        }
    }

    public C0360e(byte b2) {
        this.a = b2;
    }

    public static C0360e p(byte[] bArr) {
        if (bArr.length == 1) {
            byte b2 = bArr[0];
            if (b2 == -1) {
                return d;
            }
            if (b2 != 0) {
                return new C0360e(b2);
            }
            return c;
        }
        throw new IllegalArgumentException("BOOLEAN value should have 1 byte in it");
    }

    public final boolean h(C0394y yVar) {
        if ((yVar instanceof C0360e) && q() == ((C0360e) yVar).q()) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return q() ? 1 : 0;
    }

    public final void i(C0393x xVar, boolean z) throws IOException {
        xVar.m(1, z);
        xVar.h(1);
        xVar.f(this.a);
    }

    public final boolean j() {
        return false;
    }

    public final int k(boolean z) {
        return C0393x.d(1, z);
    }

    public final C0394y n() {
        if (q()) {
            return d;
        }
        return c;
    }

    public final boolean q() {
        if (this.a != 0) {
            return true;
        }
        return false;
    }

    public final String toString() {
        if (q()) {
            return "TRUE";
        }
        return "FALSE";
    }
}
