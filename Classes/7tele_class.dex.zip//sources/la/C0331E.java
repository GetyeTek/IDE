package la;

/* renamed from: la.E  reason: case insensitive filesystem */
public interface C0331E {
    String c();
}
