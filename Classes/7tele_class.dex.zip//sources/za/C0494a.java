package za;

import la.C0390u;

/* renamed from: za.a  reason: case insensitive filesystem */
public interface C0494a {
    public static final C0390u a;
    public static final C0390u b;
    public static final C0390u c;
    public static final C0390u d;
    public static final C0390u e;
    public static final C0390u f;
    public static final C0390u g;
    public static final C0390u h;

    static {
        C0390u uVar = new C0390u("1", new C0390u("1.2.643.7"));
        a = new C0390u("1.2.2", uVar);
        b = new C0390u("1.2.3", uVar);
        uVar.p("1.4.1");
        uVar.p("1.4.2");
        c = new C0390u("1.1.1", uVar);
        d = new C0390u("1.1.2", uVar);
        uVar.p("1.3.2");
        uVar.p("1.3.3");
        C0390u uVar2 = new C0390u("1.6", uVar);
        uVar2.p("1");
        uVar2.p("2");
        e = new C0390u("1", new C0390u("2.1.1", uVar));
        C0390u uVar3 = new C0390u("2.1.2", uVar);
        f = new C0390u("1", uVar3);
        g = new C0390u("2", uVar3);
        h = new C0390u("3", uVar3);
        uVar.p("2.5.1.1");
    }
}
