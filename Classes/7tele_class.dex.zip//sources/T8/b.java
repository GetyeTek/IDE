package T8;

import android.os.Handler;
import java.util.concurrent.FutureTask;

public final class b<Result> extends a<Result> {
    /* JADX WARNING: type inference failed for: r0v0, types: [T8.a, java.util.concurrent.FutureTask, java.lang.Object] */
    public static void a(Runnable runnable) {
        ? futureTask = new FutureTask(runnable, (Object) null);
        futureTask.a = "at";
        futureTask.b = "dg";
        futureTask.c = 1;
        futureTask.d = 0;
        Handler handler = h.e.a;
        handler.sendMessage(handler.obtainMessage(0, futureTask));
    }
}
