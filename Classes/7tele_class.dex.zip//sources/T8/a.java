package T8;

import java.util.concurrent.FutureTask;

public abstract class a<Result> extends FutureTask<Result> implements Runnable, c {
    public String a;
    public String b;
    public int c;
    public int d;
    public long e;
    public long f;
    public long g;

    public final int compareTo(Object obj) {
        return ((c) obj).d() - this.c;
    }

    public final int d() {
        return this.c;
    }

    public final void done() {
        this.g = System.currentTimeMillis();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        a aVar = (a) obj;
        if (!this.a.equals(aVar.a)) {
            return false;
        }
        return this.b.equals(aVar.b);
    }

    public final int hashCode() {
        return this.b.hashCode() + (this.a.hashCode() * 31);
    }

    public final void run() {
        this.f = System.currentTimeMillis();
        super.run();
    }

    public final void setException(Throwable th) {
        super.setException(th);
        this.g = System.currentTimeMillis();
    }

    public final String toString() {
        return "{waitTime=" + (this.f - this.e) + ", runTime=" + (this.g - this.f) + ", totalTime=" + (this.g - this.e) + ", \ntaskName='" + this.a + "', groupName='" + this.b + "', \nserialExecute=false, priority=" + this.c + ", status=" + this.d + '}';
    }
}
