package T8;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final class e implements ThreadFactory {
    public final AtomicInteger a = new AtomicInteger(1);
    public final String b = "work-pool-";
    public final int c = 10;

    public final Thread newThread(Runnable runnable) {
        d dVar = new d(runnable, this.b + this.a.getAndIncrement(), this.c);
        if (dVar.isDaemon()) {
            dVar.setDaemon(false);
        }
        return dVar;
    }
}
