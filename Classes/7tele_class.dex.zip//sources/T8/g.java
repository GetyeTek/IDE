package T8;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;

public final class g {
    public final ConcurrentHashMap a = new ConcurrentHashMap();
    public final PriorityBlockingQueue b;

    public g(PriorityBlockingQueue priorityBlockingQueue) {
        this.b = priorityBlockingQueue;
    }

    public final void a(a<?> aVar, int i) {
        PriorityBlockingQueue priorityBlockingQueue = this.b;
        if (!priorityBlockingQueue.isEmpty() && aVar.d == 2 && priorityBlockingQueue.remove(aVar)) {
            aVar.c = i;
            h hVar = h.e;
            hVar.getClass();
            aVar.d = 2;
            hVar.b.submit(aVar);
        }
    }
}
