package T8;

import android.os.Handler;
import android.os.HandlerThread;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;

public final class h {
    public static final int d = Runtime.getRuntime().availableProcessors();
    public static final h e;
    public final Handler a;
    public final f b;
    public final g c;

    public class a implements Comparator<Runnable> {
        public final /* bridge */ /* synthetic */ int compare(Object obj, Object obj2) {
            Runnable runnable = (Runnable) obj;
            Runnable runnable2 = (Runnable) obj2;
            return 0;
        }
    }

    public static final class b {
    }

    public static final class c implements Handler.Callback {
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v1, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v3, resolved type: T8.a} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v6, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v7, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v11, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v12, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v13, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v14, resolved type: java.util.List} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v15, resolved type: java.util.List} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final boolean handleMessage(android.os.Message r11) {
            /*
                r10 = this;
                int r0 = r11.what
                r1 = 5
                r2 = 1
                r3 = 0
                r4 = 2
                if (r0 == 0) goto L_0x0102
                if (r0 == r2) goto L_0x007e
                if (r0 == r4) goto L_0x000e
                goto L_0x0179
            L_0x000e:
                T8.h r0 = T8.h.e
                T8.g r0 = r0.c
                int r3 = r11.arg1
                java.lang.Object r11 = r11.obj
                java.lang.String r11 = (java.lang.String) r11
                java.util.concurrent.ConcurrentHashMap r5 = r0.a
                java.lang.Object r11 = r5.get(r11)
                java.util.List r11 = (java.util.List) r11
                if (r11 == 0) goto L_0x0179
                boolean r5 = r11.isEmpty()
                if (r5 == 0) goto L_0x002a
                goto L_0x0179
            L_0x002a:
                if (r3 == 0) goto L_0x0064
                if (r3 == r2) goto L_0x004d
                if (r3 == r4) goto L_0x0032
                goto L_0x0179
            L_0x0032:
                java.util.Iterator r11 = r11.iterator()
            L_0x0036:
                boolean r0 = r11.hasNext()
                if (r0 == 0) goto L_0x0179
                java.lang.Object r0 = r11.next()
                T8.a r0 = (T8.a) r0
                r0.cancel(r2)
                r0.d = r1
                T8.h r3 = T8.h.e
                r3.a(r0)
                goto L_0x0036
            L_0x004d:
                java.util.Iterator r11 = r11.iterator()
            L_0x0051:
                boolean r1 = r11.hasNext()
                if (r1 == 0) goto L_0x0179
                java.lang.Object r1 = r11.next()
                T8.a r1 = (T8.a) r1
                int r3 = r1.c
                int r3 = r3 - r2
                r0.a(r1, r3)
                goto L_0x0051
            L_0x0064:
                java.util.Iterator r11 = r11.iterator()
            L_0x0068:
                boolean r1 = r11.hasNext()
                if (r1 == 0) goto L_0x0179
                java.lang.Object r1 = r11.next()
                T8.a r1 = (T8.a) r1
                int r3 = r1.c
                if (r3 == r2) goto L_0x0068
                int r3 = r3 + 1
                r0.a(r1, r3)
                goto L_0x0068
            L_0x007e:
                T8.h r0 = T8.h.e
                java.lang.Object r11 = r11.obj
                T8.a r11 = (T8.a) r11
                r0.a(r11)
                T8.g r11 = r0.c
                java.util.concurrent.ConcurrentHashMap r11 = r11.a
                java.util.Collection r11 = r11.values()
                boolean r5 = r11.isEmpty()
                if (r5 == 0) goto L_0x0096
                goto L_0x00d5
            L_0x0096:
                double r5 = java.lang.Math.random()
                int r7 = r11.size()
                double r7 = (double) r7
                double r5 = r5 * r7
                int r5 = (int) r5
                java.util.Iterator r11 = r11.iterator()
                r6 = 0
                r6 = r3
                r7 = 0
            L_0x00a9:
                boolean r8 = r11.hasNext()
                if (r8 == 0) goto L_0x00cb
                java.lang.Object r8 = r11.next()
                java.util.List r8 = (java.util.List) r8
                if (r3 != 0) goto L_0x00c1
                int r9 = r8.size()
                if (r9 <= 0) goto L_0x00c1
                r3 = r8
                if (r6 == 0) goto L_0x00c1
                goto L_0x00cb
            L_0x00c1:
                int r9 = r7 + 1
                if (r5 != r7) goto L_0x00c9
                r6 = r8
                if (r3 == 0) goto L_0x00c9
                goto L_0x00cb
            L_0x00c9:
                r7 = r9
                goto L_0x00a9
            L_0x00cb:
                if (r6 == 0) goto L_0x00d5
                boolean r11 = r6.isEmpty()
                if (r11 == 0) goto L_0x00d4
                goto L_0x00d5
            L_0x00d4:
                r3 = r6
            L_0x00d5:
                if (r3 != 0) goto L_0x00d9
                goto L_0x0179
            L_0x00d9:
                java.util.Iterator r11 = r3.iterator()
            L_0x00dd:
                boolean r3 = r11.hasNext()
                if (r3 == 0) goto L_0x0179
                java.lang.Object r3 = r11.next()
                T8.a r3 = (T8.a) r3
                int r5 = r3.d
                if (r5 != r2) goto L_0x00dd
                T8.f r11 = r0.b
                java.util.concurrent.BlockingQueue r0 = r11.getQueue()
                int r0 = r0.size()
                if (r0 < r1) goto L_0x00fb
                goto L_0x0179
            L_0x00fb:
                r3.d = r4
                r11.submit(r3)
                goto L_0x0179
            L_0x0102:
                T8.h r0 = T8.h.e
                java.lang.Object r11 = r11.obj
                T8.a r11 = (T8.a) r11
                r0.getClass()
                java.lang.String r5 = r11.b
                java.lang.String r6 = "dg"
                boolean r5 = r6.equals(r5)
                T8.f r6 = r0.b
                if (r5 == 0) goto L_0x011d
                r11.d = r4
                r6.submit(r11)
                goto L_0x0173
            L_0x011d:
                T8.g r0 = r0.c
                java.util.concurrent.ConcurrentHashMap r5 = r0.a
                java.lang.String r7 = r11.b
                java.lang.Object r5 = r5.get(r7)
                java.util.List r5 = (java.util.List) r5
                if (r5 == 0) goto L_0x0149
                boolean r8 = r5.isEmpty()
                if (r8 == 0) goto L_0x0132
                goto L_0x0149
            L_0x0132:
                java.util.Iterator r5 = r5.iterator()
            L_0x0136:
                boolean r8 = r5.hasNext()
                if (r8 == 0) goto L_0x0149
                java.lang.Object r8 = r5.next()
                T8.a r8 = (T8.a) r8
                boolean r9 = r8.equals(r11)
                if (r9 == 0) goto L_0x0136
                r3 = r8
            L_0x0149:
                if (r3 == 0) goto L_0x014c
                goto L_0x0179
            L_0x014c:
                java.util.concurrent.ConcurrentHashMap r0 = r0.a
                java.lang.Object r3 = r0.get(r7)
                java.util.List r3 = (java.util.List) r3
                if (r3 != 0) goto L_0x015e
                java.util.concurrent.CopyOnWriteArrayList r3 = new java.util.concurrent.CopyOnWriteArrayList
                r3.<init>()
                r0.put(r7, r3)
            L_0x015e:
                r3.add(r11)
                java.util.concurrent.BlockingQueue r0 = r6.getQueue()
                int r0 = r0.size()
                if (r0 < r1) goto L_0x016e
                r11.d = r2
                goto L_0x0173
            L_0x016e:
                r11.d = r4
                r6.submit(r11)
            L_0x0173:
                long r0 = java.lang.System.currentTimeMillis()
                r11.e = r0
            L_0x0179:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: T8.h.c.handleMessage(android.os.Message):boolean");
        }
    }

    static {
        if (e == null) {
            synchronized (h.class) {
                try {
                    if (e == null) {
                        e = new h();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        e = e;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.os.Handler$Callback, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v2, types: [java.lang.Object, java.util.Comparator] */
    /* JADX WARNING: type inference failed for: r4v0, types: [java.lang.Object, T8.h$b] */
    public h() {
        HandlerThread handlerThread = new HandlerThread("task-handler-thread");
        handlerThread.start();
        this.a = new Handler(handlerThread.getLooper(), new Object());
        PriorityBlockingQueue priorityBlockingQueue = new PriorityBlockingQueue(5, new Object());
        this.b = new f((d * 16) + 1, TimeUnit.SECONDS, priorityBlockingQueue, new Object());
        this.c = new g(priorityBlockingQueue);
    }

    public final void a(a<?> aVar) {
        ConcurrentHashMap concurrentHashMap = this.c.a;
        List list = (List) concurrentHashMap.get(aVar.b);
        if (list != null && !list.isEmpty()) {
            list.remove(aVar);
            if (list.isEmpty()) {
                concurrentHashMap.remove(aVar.b);
            }
        }
    }
}
