package T8;

import T8.h;
import android.os.Handler;
import java.util.concurrent.Callable;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class f extends ThreadPoolExecutor {
    public final h.b a;

    public f(int i, TimeUnit timeUnit, PriorityBlockingQueue priorityBlockingQueue, h.b bVar) {
        super(4, i, 1, timeUnit, priorityBlockingQueue, new e());
        this.a = bVar;
    }

    public final void afterExecute(Runnable runnable, Throwable th) {
        this.a.getClass();
        if (runnable instanceof a) {
            ((a) runnable).d = 4;
            Handler handler = h.e.a;
            handler.sendMessage(handler.obtainMessage(1, runnable));
        }
        super.afterExecute(runnable, th);
    }

    public final void beforeExecute(Thread thread, Runnable runnable) {
        this.a.getClass();
        if (runnable instanceof a) {
            ((a) runnable).d = 3;
        }
        super.beforeExecute(thread, runnable);
    }

    public final <T> RunnableFuture<T> newTaskFor(Runnable runnable, T t) {
        if (runnable instanceof RunnableFuture) {
            return (RunnableFuture) runnable;
        }
        return super.newTaskFor(runnable, t);
    }

    public final <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
        if (callable instanceof RunnableFuture) {
            return (RunnableFuture) callable;
        }
        return super.newTaskFor(callable);
    }
}
