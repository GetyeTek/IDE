package T8;

public interface c extends Comparable<c> {
    int d();
}
