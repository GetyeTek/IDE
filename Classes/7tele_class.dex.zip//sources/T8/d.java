package T8;

import android.os.Process;

public final class d extends Thread {
    public final int a;

    public d(Runnable runnable, String str, int i) {
        super(runnable, str);
        this.a = i;
    }

    public final void run() {
        int i = this.a;
        if (i != 5) {
            Process.setThreadPriority(i);
        }
        super.run();
    }
}
