package ga;

import H9.j;
import L9.a;
import T9.p;
import fa.C0263i;
import kotlin.Result;

/* renamed from: ga.a  reason: case insensitive filesystem */
public final class C0273a {
    public static void a(p pVar, Object obj, a aVar) {
        try {
            C0263i.a(i3.a.d(i3.a.c(pVar, obj, aVar)), Result.m2constructorimpl(j.a));
        } catch (Throwable th) {
            aVar.resumeWith(Result.m2constructorimpl(kotlin.a.a(th)));
            throw th;
        }
    }
}
