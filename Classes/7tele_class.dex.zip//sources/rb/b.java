package rb;

import com.huawei.kbz.chat.chat_room.x;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class b extends g {
    public final int b;
    public final boolean c;
    public List<h> d;
    public List<j> e;
    public final long f;
    public long g = 0;

    public b(long j, long j2, ArrayList arrayList, ArrayList arrayList2, int i, boolean z) {
        super(true);
        this.b = i;
        this.d = Collections.unmodifiableList(arrayList);
        this.e = Collections.unmodifiableList(arrayList2);
        this.g = j;
        this.f = j2;
        this.c = z;
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x0078  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static rb.b c(java.lang.Object r11) throws java.io.IOException {
        /*
            boolean r0 = r11 instanceof rb.b
            if (r0 == 0) goto L_0x0007
            rb.b r11 = (rb.b) r11
            return r11
        L_0x0007:
            boolean r0 = r11 instanceof java.io.DataInputStream
            if (r0 == 0) goto L_0x0059
            r0 = r11
            java.io.DataInputStream r0 = (java.io.DataInputStream) r0
            int r1 = r0.readInt()
            if (r1 != 0) goto L_0x0051
            int r9 = r0.readInt()
            long r3 = r0.readLong()
            long r5 = r0.readLong()
            boolean r10 = r0.readBoolean()
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            r0 = 0
            r1 = 0
        L_0x0030:
            if (r1 >= r9) goto L_0x003c
            rb.h r2 = rb.h.e(r11)
            r7.add(r2)
            int r1 = r1 + 1
            goto L_0x0030
        L_0x003c:
            int r1 = r9 + -1
            if (r0 >= r1) goto L_0x004a
            rb.j r1 = rb.j.a(r11)
            r8.add(r1)
            int r0 = r0 + 1
            goto L_0x003c
        L_0x004a:
            rb.b r11 = new rb.b
            r2 = r11
            r2.<init>(r3, r5, r7, r8, r9, r10)
            return r11
        L_0x0051:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "unknown version for hss private key"
            r11.<init>(r0)
            throw r11
        L_0x0059:
            boolean r0 = r11 instanceof byte[]
            if (r0 == 0) goto L_0x007c
            r0 = 0
            java.io.DataInputStream r1 = new java.io.DataInputStream     // Catch:{ all -> 0x0075 }
            java.io.ByteArrayInputStream r2 = new java.io.ByteArrayInputStream     // Catch:{ all -> 0x0075 }
            byte[] r11 = (byte[]) r11     // Catch:{ all -> 0x0075 }
            r2.<init>(r11)     // Catch:{ all -> 0x0075 }
            r1.<init>(r2)     // Catch:{ all -> 0x0075 }
            rb.b r11 = c(r1)     // Catch:{ all -> 0x0072 }
            r1.close()
            return r11
        L_0x0072:
            r11 = move-exception
            r0 = r1
            goto L_0x0076
        L_0x0075:
            r11 = move-exception
        L_0x0076:
            if (r0 == 0) goto L_0x007b
            r0.close()
        L_0x007b:
            throw r11
        L_0x007c:
            boolean r0 = r11 instanceof java.io.InputStream
            if (r0 == 0) goto L_0x008b
            java.io.InputStream r11 = (java.io.InputStream) r11
            byte[] r11 = Vb.a.a(r11)
            rb.b r11 = c(r11)
            return r11
        L_0x008b:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "cannot parse "
            java.lang.String r11 = androidx.camera.view.l.a(r11, r1)
            r0.<init>(r11)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: rb.b.c(java.lang.Object):rb.b");
    }

    public final b a(int i) {
        b c2;
        synchronized (this) {
            try {
                long j = this.f;
                long j2 = this.g;
                long j3 = (long) i;
                if (j - j2 >= j3) {
                    long j4 = j3 + j2;
                    this.g = j4;
                    c2 = c(new b(j2, j4, new ArrayList(d()), new ArrayList(e()), this.b, true).getEncoded());
                    f();
                } else {
                    throw new IllegalArgumentException("usageCount exceeds usages remaining in current leaf");
                }
            } catch (Exception e2) {
                throw new RuntimeException(e2.getMessage(), e2);
            } catch (Throwable th) {
                throw th;
            }
        }
        return c2;
    }

    public final synchronized long b() {
        return this.g;
    }

    public final Object clone() throws CloneNotSupportedException {
        try {
            return c(getEncoded());
        } catch (Exception e2) {
            throw new RuntimeException(e2.getMessage(), e2);
        }
    }

    public final synchronized List<h> d() {
        return this.d;
    }

    public final synchronized List<j> e() {
        return this.e;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || b.class != obj.getClass()) {
            return false;
        }
        b bVar = (b) obj;
        if (this.b == bVar.b && this.c == bVar.c && this.f == bVar.f && this.g == bVar.g && this.d.equals(bVar.d)) {
            return this.e.equals(bVar.e);
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x00cc, code lost:
        if (r3[r11] == ((long) (r4[r11].d() - 1))) goto L_0x00ce;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x00d0, code lost:
        r1 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x00de, code lost:
        if (r3[r11] == ((long) r4[r11].d())) goto L_0x00ce;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f() {
        /*
            r29 = this;
            r1 = r29
            java.util.List r0 = r29.d()
            int r2 = r0.size()
            long[] r3 = new long[r2]
            long r4 = r29.b()
            int r6 = r0.size()
            r7 = 1
            int r6 = r6 - r7
        L_0x0016:
            if (r6 < 0) goto L_0x002d
            java.lang.Object r8 = r0.get(r6)
            rb.h r8 = (rb.h) r8
            rb.k r8 = r8.c
            int r8 = r8.b
            int r9 = r7 << r8
            int r9 = r9 - r7
            long r9 = (long) r9
            long r9 = r9 & r4
            r3[r6] = r9
            long r4 = r4 >>> r8
            int r6 = r6 + -1
            goto L_0x0016
        L_0x002d:
            int r4 = r0.size()
            rb.h[] r4 = new rb.h[r4]
            java.lang.Object[] r4 = r0.toArray(r4)
            rb.h[] r4 = (rb.h[]) r4
            java.util.List<rb.j> r5 = r1.e
            int r6 = r5.size()
            rb.j[] r6 = new rb.j[r6]
            java.lang.Object[] r5 = r5.toArray(r6)
            rb.j[] r5 = (rb.j[]) r5
            java.util.List<rb.h> r6 = r1.d
            r8 = 0
            java.lang.Object r6 = r6.get(r8)
            rb.h r6 = (rb.h) r6
            r9 = r4[r8]
            int r9 = r9.d()
            int r9 = r9 - r7
            long r9 = (long) r9
            r11 = r3[r8]
            int r13 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r13 == 0) goto L_0x0077
            rb.k r9 = r6.c
            rb.d r10 = r6.d
            int r12 = (int) r11
            byte[] r11 = r6.b
            byte[] r11 = org.bouncycastle.util.a.a(r11)
            byte[] r6 = r6.f
            byte[] r6 = org.bouncycastle.util.a.a(r6)
            rb.h r6 = rb.f.a(r9, r10, r12, r11, r6)
            r4[r8] = r6
            r6 = 1
            goto L_0x0078
        L_0x0077:
            r6 = 0
        L_0x0078:
            r9 = 1
        L_0x0079:
            if (r9 >= r2) goto L_0x0312
            int r10 = r9 + -1
            r11 = r4[r10]
            r12 = 16
            byte[] r13 = new byte[r12]
            r14 = 32
            byte[] r15 = new byte[r14]
            rb.l r12 = new rb.l
            byte[] r14 = r11.b
            byte[] r14 = org.bouncycastle.util.a.a(r14)
            byte[] r7 = r11.f
            byte[] r7 = org.bouncycastle.util.a.a(r7)
            rb.d r11 = r11.d
            la.u r11 = r11.e
            Ha.g r11 = rb.C0433a.a(r11)
            r12.<init>(r14, r7, r11)
            r11 = r9
            r8 = r3[r10]
            int r9 = (int) r8
            r12.d = r9
            r8 = -2
            r12.e = r8
            r7 = 1
            r8 = 0
            r12.a(r8, r15, r7)
            r7 = 32
            byte[] r9 = new byte[r7]
            r12.a(r8, r9, r8)
            r7 = 16
            java.lang.System.arraycopy(r9, r8, r13, r8, r7)
            int r8 = r2 + -1
            if (r11 >= r8) goto L_0x00d2
            r8 = r3[r11]
            r12 = r4[r11]
            int r12 = r12.d()
            r14 = 1
            int r12 = r12 - r14
            r14 = r2
            long r1 = (long) r12
            int r12 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
            if (r12 != 0) goto L_0x00d0
        L_0x00ce:
            r1 = 1
            goto L_0x00e1
        L_0x00d0:
            r1 = 0
            goto L_0x00e1
        L_0x00d2:
            r14 = r2
            r1 = r3[r11]
            r8 = r4[r11]
            int r8 = r8.d()
            long r8 = (long) r8
            int r12 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1))
            if (r12 != 0) goto L_0x00d0
            goto L_0x00ce
        L_0x00e1:
            r2 = r4[r11]
            byte[] r2 = r2.b
            byte[] r2 = org.bouncycastle.util.a.a(r2)
            boolean r2 = java.util.Arrays.equals(r13, r2)
            if (r2 == 0) goto L_0x0136
            r2 = r4[r11]
            byte[] r2 = r2.f
            byte[] r2 = org.bouncycastle.util.a.a(r2)
            boolean r2 = java.util.Arrays.equals(r15, r2)
            if (r2 == 0) goto L_0x0136
            if (r1 != 0) goto L_0x0129
            java.lang.Object r1 = r0.get(r11)
            rb.h r1 = (rb.h) r1
            rb.k r1 = r1.c
            java.lang.Object r2 = r0.get(r11)
            rb.h r2 = (rb.h) r2
            rb.d r2 = r2.d
            r8 = r3[r11]
            int r6 = (int) r8
            rb.h r1 = rb.f.a(r1, r2, r6, r13, r15)
            r4[r11] = r1
            r19 = r0
            r20 = r3
            r21 = r4
            r26 = r5
            r25 = r11
            r16 = r14
            r6 = 1
        L_0x0125:
            r17 = 1
            goto L_0x02e8
        L_0x0129:
            r19 = r0
            r20 = r3
            r21 = r4
            r26 = r5
            r25 = r11
            r16 = r14
            goto L_0x0125
        L_0x0136:
            java.lang.Object r1 = r0.get(r11)
            rb.h r1 = (rb.h) r1
            rb.k r1 = r1.c
            java.lang.Object r2 = r0.get(r11)
            rb.h r2 = (rb.h) r2
            rb.d r2 = r2.d
            r8 = r3[r11]
            int r6 = (int) r8
            rb.h r1 = rb.f.a(r1, r2, r6, r13, r15)
            r4[r11] = r1
            r2 = r4[r10]
            rb.i r1 = r1.f()
            byte[] r1 = r1.b()
            rb.k r6 = r2.c
            int r6 = r6.b
            int r8 = r2.d()
            monitor-enter(r2)
            int r9 = r2.j     // Catch:{ all -> 0x0306 }
            int r12 = r2.e     // Catch:{ all -> 0x0306 }
            if (r9 >= r12) goto L_0x0308
            rb.d r12 = r2.d     // Catch:{ all -> 0x0306 }
            byte[] r13 = r2.b     // Catch:{ all -> 0x0306 }
            byte[] r15 = r2.f     // Catch:{ all -> 0x0306 }
            r2.g()     // Catch:{ all -> 0x0306 }
            monitor-exit(r2)     // Catch:{ all -> 0x0306 }
            r16 = 1
            int r17 = r16 << r6
            int r8 = r17 + r8
            byte[][] r7 = new byte[r6][]
            r19 = r0
            r0 = 0
        L_0x017d:
            if (r0 >= r6) goto L_0x0194
            int r17 = r16 << r0
            int r17 = r8 / r17
            r20 = r3
            r3 = r17 ^ 1
            byte[] r3 = r2.b(r3)
            r7[r0] = r3
            int r0 = r0 + 1
            r3 = r20
            r16 = 1
            goto L_0x017d
        L_0x0194:
            r20 = r3
            rb.k r0 = r2.c
            r2 = 32
            byte[] r3 = new byte[r2]
            rb.l r2 = new rb.l
            la.u r6 = r12.e
            Ha.g r6 = rb.C0433a.a(r6)
            r2.<init>(r13, r15, r6)
            r2.d = r9
            r6 = -3
            r2.e = r6
            r6 = 0
            r2.a(r6, r3, r6)
            la.u r2 = r12.e
            Ha.g r2 = rb.C0433a.a(r2)
            int r8 = r13.length
            r2.d(r6, r8, r13)
            T6.a.b(r9, r2)
            r8 = 16777089(0xffff81, float:2.3509709E-38)
            byte r8 = (byte) r8
            r2.c(r8)
            r8 = -32383(0xffffffffffff8181, float:NaN)
            byte r8 = (byte) r8
            r2.c(r8)
            r8 = 32
            r2.d(r6, r8, r3)
            int r8 = r1.length
            r2.d(r6, r8, r1)
            r1 = 34
            byte[] r1 = new byte[r1]
            r2.b(r6, r1)
            int r6 = r12.c
            int r8 = r6 * 32
            byte[] r8 = new byte[r8]
            la.u r2 = r12.e
            Ha.g r2 = rb.C0433a.a(r2)
            r16 = r14
            rb.l r14 = new rb.l
            r21 = r4
            la.u r4 = r12.e
            Ha.g r4 = rb.C0433a.a(r4)
            r14.<init>(r13, r15, r4)
            r14.d = r9
            int r4 = r12.b
            r15 = 1
            int r17 = r15 << r4
            int r22 = r17 + -1
            r15 = 0
            r23 = 0
        L_0x0201:
            r24 = 256(0x100, float:3.59E-43)
            r25 = r11
            int r11 = r24 / r4
            r24 = 8
            if (r15 >= r11) goto L_0x022d
            int r23 = r23 + r22
            int r11 = r15 * r4
            int r11 = r11 / 8
            int r24 = r24 / r4
            r26 = r5
            int r5 = ~r15
            r17 = 1
            int r24 = r24 + -1
            r5 = r5 & r24
            int r5 = r5 * r4
            byte r11 = r1[r11]
            int r5 = r11 >>> r5
            r5 = r5 & r22
            int r23 = r23 - r5
            int r15 = r15 + 1
            r11 = r25
            r5 = r26
            goto L_0x0201
        L_0x022d:
            r26 = r5
            int r5 = r12.d
            int r5 = r23 << r5
            int r11 = r5 >>> 8
            r11 = r11 & 255(0xff, float:3.57E-43)
            byte r11 = (byte) r11
            r15 = 32
            r1[r15] = r11
            r11 = 33
            byte r5 = (byte) r5
            r1[r11] = r5
            java.io.ByteArrayOutputStream r5 = new java.io.ByteArrayOutputStream
            r5.<init>()
            r5.write(r13)     // Catch:{ Exception -> 0x02fa }
            int r11 = r9 >>> 24
            byte r11 = (byte) r11
            r5.write(r11)
            int r11 = r9 >>> 16
            byte r11 = (byte) r11
            r5.write(r11)
            int r11 = r9 >>> 8
            byte r11 = (byte) r11
            r5.write(r11)
            byte r11 = (byte) r9
            r5.write(r11)
        L_0x025f:
            int r11 = r5.size()
            r13 = 55
            if (r11 >= r13) goto L_0x026c
            r11 = 0
            r5.write(r11)
            goto L_0x025f
        L_0x026c:
            r11 = 0
            byte[] r5 = r5.toByteArray()
            r14.e = r11
            r15 = 0
        L_0x0274:
            if (r15 >= r6) goto L_0x02d9
            short r11 = (short) r15
            int r13 = r11 >>> 8
            byte r13 = (byte) r13
            r27 = 20
            r5[r27] = r13
            r13 = 21
            byte r11 = (byte) r11
            r5[r13] = r11
            int r11 = r6 + -1
            if (r15 >= r11) goto L_0x0289
            r11 = 1
            goto L_0x028a
        L_0x0289:
            r11 = 0
        L_0x028a:
            r13 = 23
            r14.a(r13, r5, r11)
            int r11 = r15 * r4
            int r11 = r11 / 8
            int r27 = r24 / r4
            int r13 = ~r15
            r17 = 1
            int r27 = r27 + -1
            r13 = r13 & r27
            int r13 = r13 * r4
            byte r11 = r1[r11]
            int r11 = r11 >>> r13
            r11 = r11 & r22
            r13 = 0
        L_0x02a4:
            if (r13 >= r11) goto L_0x02c1
            r27 = 22
            r28 = r1
            byte r1 = (byte) r13
            r5[r27] = r1
            r18 = r4
            r1 = 0
            r4 = 55
            r2.d(r1, r4, r5)
            r1 = 23
            r2.b(r1, r5)
            int r13 = r13 + 1
            r4 = r18
            r1 = r28
            goto L_0x02a4
        L_0x02c1:
            r28 = r1
            r18 = r4
            r1 = 23
            r4 = 55
            r13 = 32
            int r11 = r13 * r15
            java.lang.System.arraycopy(r5, r1, r8, r11, r13)
            int r15 = r15 + 1
            r4 = r18
            r1 = r28
            r13 = 55
            goto L_0x0274
        L_0x02d9:
            r17 = 1
            rb.e r1 = new rb.e
            r1.<init>(r12, r3, r8)
            rb.j r2 = new rb.j
            r2.<init>(r9, r1, r0, r7)
            r26[r10] = r2
            r6 = 1
        L_0x02e8:
            int r9 = r25 + 1
            r1 = r29
            r2 = r16
            r0 = r19
            r3 = r20
            r4 = r21
            r5 = r26
            r7 = 1
            r8 = 0
            goto L_0x0079
        L_0x02fa:
            r0 = move-exception
            r1 = r0
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r2 = r1.getMessage()
            r0.<init>(r2, r1)
            throw r0
        L_0x0306:
            r0 = move-exception
            goto L_0x0310
        L_0x0308:
            org.bouncycastle.pqc.crypto.ExhaustedPrivateKeyException r0 = new org.bouncycastle.pqc.crypto.ExhaustedPrivateKeyException     // Catch:{ all -> 0x0306 }
            java.lang.String r1 = "ots private key exhausted"
            r0.<init>(r1)     // Catch:{ all -> 0x0306 }
            throw r0     // Catch:{ all -> 0x0306 }
        L_0x0310:
            monitor-exit(r2)     // Catch:{ all -> 0x0306 }
            throw r0
        L_0x0312:
            r21 = r4
            r26 = r5
            r1 = r29
            if (r6 == 0) goto L_0x0321
            r4 = r21
            r5 = r26
            r1.g(r4, r5)
        L_0x0321:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: rb.b.f():void");
    }

    public final void g(h[] hVarArr, j[] jVarArr) {
        synchronized (this) {
            this.d = Collections.unmodifiableList(Arrays.asList(hVarArr));
            this.e = Collections.unmodifiableList(Arrays.asList(jVarArr));
        }
    }

    public final synchronized byte[] getEncoded() throws IOException {
        x xVar;
        try {
            xVar = new x();
            xVar.c(0);
            xVar.c(this.b);
            long j = this.g;
            xVar.c((int) (j >>> 32));
            xVar.c((int) j);
            long j2 = this.f;
            xVar.c((int) (j2 >>> 32));
            xVar.c((int) j2);
            ((ByteArrayOutputStream) xVar.a).write(this.c ? 1 : 0);
            for (h a : this.d) {
                xVar.a(a);
            }
            for (j a2 : this.e) {
                xVar.a(a2);
            }
        } catch (Throwable th) {
            while (true) {
                throw th;
            }
        }
        return ((ByteArrayOutputStream) xVar.a).toByteArray();
    }

    public final int hashCode() {
        int hashCode = this.d.hashCode();
        int hashCode2 = this.e.hashCode();
        long j = this.f;
        long j2 = this.g;
        return ((((hashCode2 + ((hashCode + (((this.b * 31) + (this.c ? 1 : 0)) * 31)) * 31)) * 31) + ((int) (j ^ (j >>> 32)))) * 31) + ((int) (j2 ^ (j2 >>> 32)));
    }
}
