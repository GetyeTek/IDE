package rb;

public final class f {
    public static h a(k kVar, d dVar, int i, byte[] bArr, byte[] bArr2) throws IllegalArgumentException {
        if (bArr2 != null) {
            int length = bArr2.length;
            kVar.getClass();
            if (length >= 32) {
                return new h(kVar, dVar, i, bArr, 1 << kVar.b, bArr2);
            }
        }
        kVar.getClass();
        throw new IllegalArgumentException("root seed is less than 32");
    }
}
