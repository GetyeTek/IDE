package rb;

import com.huawei.kbz.chat.chat_room.x;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import org.bouncycastle.util.c;

public final class j implements c {
    public final int a;
    public final e b;
    public final k c;
    public final byte[][] d;

    public j(int i, e eVar, k kVar, byte[][] bArr) {
        this.a = i;
        this.b = eVar;
        this.c = kVar;
        this.d = bArr;
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x005e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static rb.j a(java.lang.Object r7) throws java.io.IOException {
        /*
            boolean r0 = r7 instanceof rb.j
            if (r0 == 0) goto L_0x0007
            rb.j r7 = (rb.j) r7
            return r7
        L_0x0007:
            boolean r0 = r7 instanceof java.io.DataInputStream
            if (r0 == 0) goto L_0x003f
            r0 = r7
            java.io.DataInputStream r0 = (java.io.DataInputStream) r0
            int r1 = r0.readInt()
            rb.e r7 = rb.e.a(r7)
            int r2 = r0.readInt()
            rb.k$a r3 = rb.k.d
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            java.lang.Object r2 = r3.get(r2)
            rb.k r2 = (rb.k) r2
            int r3 = r2.b
            byte[][] r4 = new byte[r3][]
            r5 = 0
        L_0x002b:
            if (r5 >= r3) goto L_0x0039
            r6 = 32
            byte[] r6 = new byte[r6]
            r4[r5] = r6
            r0.readFully(r6)
            int r5 = r5 + 1
            goto L_0x002b
        L_0x0039:
            rb.j r0 = new rb.j
            r0.<init>(r1, r7, r2, r4)
            return r0
        L_0x003f:
            boolean r0 = r7 instanceof byte[]
            if (r0 == 0) goto L_0x0062
            r0 = 0
            java.io.DataInputStream r1 = new java.io.DataInputStream     // Catch:{ all -> 0x005b }
            java.io.ByteArrayInputStream r2 = new java.io.ByteArrayInputStream     // Catch:{ all -> 0x005b }
            byte[] r7 = (byte[]) r7     // Catch:{ all -> 0x005b }
            r2.<init>(r7)     // Catch:{ all -> 0x005b }
            r1.<init>(r2)     // Catch:{ all -> 0x005b }
            rb.j r7 = a(r1)     // Catch:{ all -> 0x0058 }
            r1.close()
            return r7
        L_0x0058:
            r7 = move-exception
            r0 = r1
            goto L_0x005c
        L_0x005b:
            r7 = move-exception
        L_0x005c:
            if (r0 == 0) goto L_0x0061
            r0.close()
        L_0x0061:
            throw r7
        L_0x0062:
            boolean r0 = r7 instanceof java.io.InputStream
            if (r0 == 0) goto L_0x0071
            java.io.InputStream r7 = (java.io.InputStream) r7
            byte[] r7 = Vb.a.a(r7)
            rb.j r7 = a(r7)
            return r7
        L_0x0071:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "cannot parse "
            java.lang.String r7 = androidx.camera.view.l.a(r7, r1)
            r0.<init>(r7)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: rb.j.a(java.lang.Object):rb.j");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || j.class != obj.getClass()) {
            return false;
        }
        j jVar = (j) obj;
        if (this.a != jVar.a) {
            return false;
        }
        e eVar = jVar.b;
        e eVar2 = this.b;
        if (eVar2 == null ? eVar != null : !eVar2.equals(eVar)) {
            return false;
        }
        k kVar = jVar.c;
        k kVar2 = this.c;
        if (kVar2 == null ? kVar == null : kVar2.equals(kVar)) {
            return Arrays.deepEquals(this.d, jVar.d);
        }
        return false;
    }

    public final byte[] getEncoded() throws IOException {
        x xVar = new x();
        xVar.c(this.a);
        xVar.b(this.b.getEncoded());
        xVar.c(this.c.a);
        byte[][] bArr = this.d;
        try {
            int length = bArr.length;
            int i = 0;
            while (true) {
                ByteArrayOutputStream byteArrayOutputStream = (ByteArrayOutputStream) xVar.a;
                if (i >= length) {
                    return byteArrayOutputStream.toByteArray();
                }
                byteArrayOutputStream.write(bArr[i]);
                i++;
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public final int hashCode() {
        int i;
        int i2 = this.a * 31;
        int i3 = 0;
        e eVar = this.b;
        if (eVar != null) {
            i = eVar.hashCode();
        } else {
            i = 0;
        }
        int i4 = (i2 + i) * 31;
        k kVar = this.c;
        if (kVar != null) {
            i3 = kVar.hashCode();
        }
        return Arrays.deepHashCode(this.d) + ((i4 + i3) * 31);
    }
}
