package rb;

import Ha.g;

public final class l {
    public final byte[] a;
    public final byte[] b;
    public final g c;
    public int d;
    public int e;

    public l(byte[] bArr, byte[] bArr2, g gVar) {
        this.a = bArr;
        this.b = bArr2;
        this.c = gVar;
    }

    public final void a(int i, byte[] bArr, boolean z) {
        int length = bArr.length;
        g gVar = this.c;
        if (length >= gVar.g()) {
            byte[] bArr2 = this.a;
            gVar.d(0, bArr2.length, bArr2);
            gVar.c((byte) (this.d >>> 24));
            gVar.c((byte) (this.d >>> 16));
            gVar.c((byte) (this.d >>> 8));
            gVar.c((byte) this.d);
            gVar.c((byte) (this.e >>> 8));
            gVar.c((byte) this.e);
            gVar.c((byte) -1);
            byte[] bArr3 = this.b;
            gVar.d(0, bArr3.length, bArr3);
            gVar.b(i, bArr);
            if (z) {
                this.e++;
                return;
            }
            return;
        }
        throw new IllegalArgumentException("target length is less than digest size.");
    }
}
