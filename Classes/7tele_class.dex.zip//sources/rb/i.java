package rb;

import com.huawei.kbz.chat.chat_room.x;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import org.bouncycastle.util.a;

public final class i extends g {
    public final k b;
    public final d c;
    public final byte[] d;
    public final byte[] e;

    public i(k kVar, d dVar, byte[] bArr, byte[] bArr2) {
        super(false);
        this.b = kVar;
        this.c = dVar;
        this.d = a.a(bArr2);
        this.e = a.a(bArr);
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0063  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static rb.i a(java.lang.Object r4) throws java.io.IOException {
        /*
            boolean r0 = r4 instanceof rb.i
            if (r0 == 0) goto L_0x0007
            rb.i r4 = (rb.i) r4
            return r4
        L_0x0007:
            boolean r0 = r4 instanceof java.io.DataInputStream
            if (r0 == 0) goto L_0x0044
            java.io.DataInputStream r4 = (java.io.DataInputStream) r4
            int r0 = r4.readInt()
            rb.k$a r1 = rb.k.d
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            java.lang.Object r0 = r1.get(r0)
            rb.k r0 = (rb.k) r0
            int r1 = r4.readInt()
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            rb.d$a r2 = rb.d.f
            java.lang.Object r1 = r2.get(r1)
            rb.d r1 = (rb.d) r1
            r2 = 16
            byte[] r2 = new byte[r2]
            r4.readFully(r2)
            r0.getClass()
            r3 = 32
            byte[] r3 = new byte[r3]
            r4.readFully(r3)
            rb.i r4 = new rb.i
            r4.<init>(r0, r1, r3, r2)
            return r4
        L_0x0044:
            boolean r0 = r4 instanceof byte[]
            if (r0 == 0) goto L_0x0067
            r0 = 0
            java.io.DataInputStream r1 = new java.io.DataInputStream     // Catch:{ all -> 0x0060 }
            java.io.ByteArrayInputStream r2 = new java.io.ByteArrayInputStream     // Catch:{ all -> 0x0060 }
            byte[] r4 = (byte[]) r4     // Catch:{ all -> 0x0060 }
            r2.<init>(r4)     // Catch:{ all -> 0x0060 }
            r1.<init>(r2)     // Catch:{ all -> 0x0060 }
            rb.i r4 = a(r1)     // Catch:{ all -> 0x005d }
            r1.close()
            return r4
        L_0x005d:
            r4 = move-exception
            r0 = r1
            goto L_0x0061
        L_0x0060:
            r4 = move-exception
        L_0x0061:
            if (r0 == 0) goto L_0x0066
            r0.close()
        L_0x0066:
            throw r4
        L_0x0067:
            boolean r0 = r4 instanceof java.io.InputStream
            if (r0 == 0) goto L_0x0076
            java.io.InputStream r4 = (java.io.InputStream) r4
            byte[] r4 = Vb.a.a(r4)
            rb.i r4 = a(r4)
            return r4
        L_0x0076:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "cannot parse "
            java.lang.String r4 = androidx.camera.view.l.a(r4, r1)
            r0.<init>(r4)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: rb.i.a(java.lang.Object):rb.i");
    }

    public final byte[] b() {
        x xVar = new x();
        xVar.c(this.b.a);
        xVar.c(this.c.a);
        xVar.b(this.d);
        xVar.b(this.e);
        return ((ByteArrayOutputStream) xVar.a).toByteArray();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || i.class != obj.getClass()) {
            return false;
        }
        i iVar = (i) obj;
        if (this.b.equals(iVar.b) && this.c.equals(iVar.c) && Arrays.equals(this.d, iVar.d)) {
            return Arrays.equals(this.e, iVar.e);
        }
        return false;
    }

    public final byte[] getEncoded() throws IOException {
        return b();
    }

    public final int hashCode() {
        int hashCode = this.c.hashCode();
        int h = a.h(this.d);
        return a.h(this.e) + ((h + ((hashCode + (this.b.hashCode() * 31)) * 31)) * 31);
    }
}
