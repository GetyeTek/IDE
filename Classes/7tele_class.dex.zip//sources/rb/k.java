package rb;

import java.util.HashMap;
import la.C0390u;
import wa.C0468b;

public final class k {
    public static final a d;
    public final int a;
    public final int b;
    public final C0390u c;

    public static class a extends HashMap<Object, k> {
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [java.util.AbstractMap, rb.k$a, java.util.HashMap] */
    static {
        C0390u uVar = C0468b.a;
        k kVar = new k(5, 5, uVar);
        k kVar2 = new k(6, 10, uVar);
        k kVar3 = new k(7, 15, uVar);
        k kVar4 = new k(8, 20, uVar);
        k kVar5 = new k(9, 25, uVar);
        ? hashMap = new HashMap();
        hashMap.put(5, kVar);
        hashMap.put(6, kVar2);
        hashMap.put(7, kVar3);
        hashMap.put(8, kVar4);
        hashMap.put(9, kVar5);
        d = hashMap;
    }

    public k(int i, int i2, C0390u uVar) {
        this.a = i;
        this.b = i2;
        this.c = uVar;
    }
}
