package rb;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import org.bouncycastle.util.c;

public final class e implements c {
    public final d a;
    public final byte[] b;
    public final byte[] c;

    public e(d dVar, byte[] bArr, byte[] bArr2) {
        this.a = dVar;
        this.b = bArr;
        this.c = bArr2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0055  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static rb.e a(java.lang.Object r4) throws java.io.IOException {
        /*
            boolean r0 = r4 instanceof rb.e
            if (r0 == 0) goto L_0x0007
            rb.e r4 = (rb.e) r4
            return r4
        L_0x0007:
            boolean r0 = r4 instanceof java.io.DataInputStream
            if (r0 == 0) goto L_0x0036
            java.io.DataInputStream r4 = (java.io.DataInputStream) r4
            int r0 = r4.readInt()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            rb.d$a r1 = rb.d.f
            java.lang.Object r0 = r1.get(r0)
            rb.d r0 = (rb.d) r0
            r0.getClass()
            r1 = 32
            byte[] r2 = new byte[r1]
            r4.readFully(r2)
            int r3 = r0.c
            int r3 = r3 * 32
            byte[] r1 = new byte[r3]
            r4.readFully(r1)
            rb.e r4 = new rb.e
            r4.<init>(r0, r2, r1)
            return r4
        L_0x0036:
            boolean r0 = r4 instanceof byte[]
            if (r0 == 0) goto L_0x0059
            r0 = 0
            java.io.DataInputStream r1 = new java.io.DataInputStream     // Catch:{ all -> 0x0052 }
            java.io.ByteArrayInputStream r2 = new java.io.ByteArrayInputStream     // Catch:{ all -> 0x0052 }
            byte[] r4 = (byte[]) r4     // Catch:{ all -> 0x0052 }
            r2.<init>(r4)     // Catch:{ all -> 0x0052 }
            r1.<init>(r2)     // Catch:{ all -> 0x0052 }
            rb.e r4 = a(r1)     // Catch:{ all -> 0x004f }
            r1.close()
            return r4
        L_0x004f:
            r4 = move-exception
            r0 = r1
            goto L_0x0053
        L_0x0052:
            r4 = move-exception
        L_0x0053:
            if (r0 == 0) goto L_0x0058
            r0.close()
        L_0x0058:
            throw r4
        L_0x0059:
            boolean r0 = r4 instanceof java.io.InputStream
            if (r0 == 0) goto L_0x0068
            java.io.InputStream r4 = (java.io.InputStream) r4
            byte[] r4 = Vb.a.a(r4)
            rb.e r4 = a(r4)
            return r4
        L_0x0068:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "cannot parse "
            java.lang.String r4 = androidx.camera.view.l.a(r4, r1)
            r0.<init>(r4)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: rb.e.a(java.lang.Object):rb.e");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || e.class != obj.getClass()) {
            return false;
        }
        e eVar = (e) obj;
        d dVar = eVar.a;
        d dVar2 = this.a;
        if (dVar2 == null ? dVar != null : !dVar2.equals(dVar)) {
            return false;
        }
        if (!Arrays.equals(this.b, eVar.b)) {
            return false;
        }
        return Arrays.equals(this.c, eVar.c);
    }

    public final byte[] getEncoded() throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int i = this.a.a;
        byteArrayOutputStream.write((byte) 0);
        byteArrayOutputStream.write((byte) 0);
        byteArrayOutputStream.write((byte) 0);
        byteArrayOutputStream.write((byte) i);
        try {
            byteArrayOutputStream.write(this.b);
            try {
                byteArrayOutputStream.write(this.c);
                return byteArrayOutputStream.toByteArray();
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage(), e);
            }
        } catch (Exception e2) {
            throw new RuntimeException(e2.getMessage(), e2);
        }
    }

    public final int hashCode() {
        int i;
        d dVar = this.a;
        if (dVar != null) {
            i = dVar.hashCode();
        } else {
            i = 0;
        }
        int hashCode = Arrays.hashCode(this.b);
        return Arrays.hashCode(this.c) + ((hashCode + (i * 31)) * 31);
    }
}
