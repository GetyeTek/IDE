package rb;

import java.util.HashMap;
import la.C0390u;
import wa.C0468b;

public final class d {
    public static final a f;
    public final int a;
    public final int b;
    public final int c;
    public final int d;
    public final C0390u e;

    public static class a extends HashMap<Object, d> {
    }

    /* JADX WARNING: type inference failed for: r0v4, types: [rb.d$a, java.util.AbstractMap, java.util.HashMap] */
    static {
        C0390u uVar = C0468b.a;
        d dVar = new d(1, 1, 265, 7, uVar);
        d dVar2 = new d(2, 2, 133, 6, uVar);
        d dVar3 = new d(3, 4, 67, 4, uVar);
        d dVar4 = new d(4, 8, 34, 0, uVar);
        ? hashMap = new HashMap();
        hashMap.put(1, dVar);
        hashMap.put(2, dVar2);
        hashMap.put(3, dVar3);
        hashMap.put(4, dVar4);
        f = hashMap;
    }

    public d(int i, int i2, int i3, int i4, C0390u uVar) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
        this.e = uVar;
    }
}
