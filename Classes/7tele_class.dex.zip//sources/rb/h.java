package rb;

import Ha.g;
import com.huawei.kbz.chat.chat_room.x;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.WeakHashMap;
import la.C0390u;

public final class h extends g {
    public static final a l;
    public static final a[] m;
    public final byte[] b;
    public final k c;
    public final d d;
    public final int e;
    public final byte[] f;
    public final WeakHashMap g;
    public final int h;
    public final g i;
    public int j;
    public i k;

    public static class a {
        public final int a;

        public a(int i) {
            this.a = i;
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof a) || ((a) obj).a != this.a) {
                return false;
            }
            return true;
        }

        public final int hashCode() {
            return this.a;
        }
    }

    static {
        a aVar = new a(1);
        l = aVar;
        a[] aVarArr = new a[129];
        m = aVarArr;
        aVarArr[1] = aVar;
        int i2 = 2;
        while (true) {
            a[] aVarArr2 = m;
            if (i2 < aVarArr2.length) {
                aVarArr2[i2] = new a(i2);
                i2++;
            } else {
                return;
            }
        }
    }

    public h(h hVar, int i2, int i3) {
        super(true);
        k kVar = hVar.c;
        this.c = kVar;
        this.d = hVar.d;
        this.j = i2;
        this.b = hVar.b;
        this.e = i3;
        this.f = hVar.f;
        this.h = 1 << kVar.b;
        this.g = hVar.g;
        this.i = C0433a.a(kVar.c);
        this.k = hVar.k;
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x00a3  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static rb.h e(java.lang.Object r8) throws java.io.IOException {
        /*
            boolean r0 = r8 instanceof rb.h
            if (r0 == 0) goto L_0x0007
            rb.h r8 = (rb.h) r8
            return r8
        L_0x0007:
            boolean r0 = r8 instanceof java.io.DataInputStream
            if (r0 == 0) goto L_0x0084
            java.io.DataInputStream r8 = (java.io.DataInputStream) r8
            int r0 = r8.readInt()
            if (r0 != 0) goto L_0x007c
            int r0 = r8.readInt()
            rb.k$a r1 = rb.k.d
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            java.lang.Object r0 = r1.get(r0)
            r2 = r0
            rb.k r2 = (rb.k) r2
            int r0 = r8.readInt()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            rb.d$a r1 = rb.d.f
            java.lang.Object r0 = r1.get(r0)
            r3 = r0
            rb.d r3 = (rb.d) r3
            r0 = 16
            byte[] r5 = new byte[r0]
            r8.readFully(r5)
            int r4 = r8.readInt()
            int r6 = r8.readInt()
            int r0 = r8.readInt()
            if (r0 < 0) goto L_0x0074
            int r1 = r8.available()
            if (r0 > r1) goto L_0x005c
            byte[] r7 = new byte[r0]
            r8.readFully(r7)
            rb.h r8 = new rb.h
            r1 = r8
            r1.<init>(r2, r3, r4, r5, r6, r7)
            return r8
        L_0x005c:
            java.io.IOException r0 = new java.io.IOException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "secret length exceeded "
            r1.<init>(r2)
            int r8 = r8.available()
            r1.append(r8)
            java.lang.String r8 = r1.toString()
            r0.<init>(r8)
            throw r0
        L_0x0074:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "secret length less than zero"
            r8.<init>(r0)
            throw r8
        L_0x007c:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "expected version 0 lms private key"
            r8.<init>(r0)
            throw r8
        L_0x0084:
            boolean r0 = r8 instanceof byte[]
            if (r0 == 0) goto L_0x00a7
            r0 = 0
            java.io.DataInputStream r1 = new java.io.DataInputStream     // Catch:{ all -> 0x00a0 }
            java.io.ByteArrayInputStream r2 = new java.io.ByteArrayInputStream     // Catch:{ all -> 0x00a0 }
            byte[] r8 = (byte[]) r8     // Catch:{ all -> 0x00a0 }
            r2.<init>(r8)     // Catch:{ all -> 0x00a0 }
            r1.<init>(r2)     // Catch:{ all -> 0x00a0 }
            rb.h r8 = e(r1)     // Catch:{ all -> 0x009d }
            r1.close()
            return r8
        L_0x009d:
            r8 = move-exception
            r0 = r1
            goto L_0x00a1
        L_0x00a0:
            r8 = move-exception
        L_0x00a1:
            if (r0 == 0) goto L_0x00a6
            r0.close()
        L_0x00a6:
            throw r8
        L_0x00a7:
            boolean r0 = r8 instanceof java.io.InputStream
            if (r0 == 0) goto L_0x00b6
            java.io.InputStream r8 = (java.io.InputStream) r8
            byte[] r8 = Vb.a.a(r8)
            rb.h r8 = e(r8)
            return r8
        L_0x00b6:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "cannot parse "
            java.lang.String r8 = androidx.camera.view.l.a(r8, r1)
            r0.<init>(r8)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: rb.h.e(java.lang.Object):rb.h");
    }

    public final byte[] a(int i2) {
        boolean z;
        int i3 = i2;
        int i4 = 1 << this.c.b;
        byte[] bArr = this.b;
        g gVar = this.i;
        if (i3 >= i4) {
            byte[] a2 = org.bouncycastle.util.a.a(bArr);
            gVar.d(0, a2.length, a2);
            T6.a.b(i3, gVar);
            gVar.c((byte) 16777090);
            gVar.c((byte) -32126);
            byte[] a3 = org.bouncycastle.util.a.a(bArr);
            int i5 = i3 - i4;
            byte[] a4 = org.bouncycastle.util.a.a(this.f);
            d dVar = this.d;
            g a5 = C0433a.a(dVar.e);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                byteArrayOutputStream.write(a3);
                byte b2 = (byte) (i5 >>> 24);
                byteArrayOutputStream.write(b2);
                byte b3 = (byte) (i5 >>> 16);
                byteArrayOutputStream.write(b3);
                byte b4 = (byte) (i5 >>> 8);
                byteArrayOutputStream.write(b4);
                byte b5 = (byte) i5;
                byteArrayOutputStream.write(b5);
                byteArrayOutputStream.write((byte) 128);
                byteArrayOutputStream.write((byte) 32896);
                while (byteArrayOutputStream.size() < 22) {
                    byteArrayOutputStream.write(0);
                }
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                a5.d(0, byteArray.length, byteArray);
                C0390u uVar = dVar.e;
                g a6 = C0433a.a(uVar);
                ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
                try {
                    byteArrayOutputStream2.write(a3);
                    byteArrayOutputStream2.write(b2);
                    byteArrayOutputStream2.write(b3);
                    byteArrayOutputStream2.write(b4);
                    byteArrayOutputStream2.write(b5);
                    int g2 = a6.g() + 23;
                    while (byteArrayOutputStream2.size() < g2) {
                        byteArrayOutputStream2.write(0);
                    }
                    byte[] byteArray2 = byteArrayOutputStream2.toByteArray();
                    l lVar = new l(a3, a4, C0433a.a(uVar));
                    lVar.d = i5;
                    lVar.e = 0;
                    int i6 = (1 << dVar.b) - 1;
                    int i7 = 0;
                    while (true) {
                        int i8 = dVar.c;
                        if (i7 < i8) {
                            if (i7 < i8 - 1) {
                                z = true;
                            } else {
                                z = false;
                            }
                            lVar.a(23, byteArray2, z);
                            short s = (short) i7;
                            byteArray2[20] = (byte) (s >>> 8);
                            byteArray2[21] = (byte) s;
                            for (int i10 = 0; i10 < i6; i10++) {
                                byteArray2[22] = (byte) i10;
                                a6.d(0, byteArray2.length, byteArray2);
                                a6.b(23, byteArray2);
                            }
                            a5.d(23, 32, byteArray2);
                            i7++;
                        } else {
                            int g3 = a5.g();
                            byte[] bArr2 = new byte[g3];
                            a5.b(0, bArr2);
                            gVar.d(0, g3, bArr2);
                            byte[] bArr3 = new byte[gVar.g()];
                            gVar.b(0, bArr3);
                            return bArr3;
                        }
                    }
                } catch (Exception e2) {
                    Exception exc = e2;
                    throw new RuntimeException(exc.getMessage(), exc);
                }
            } catch (Exception e3) {
                Exception exc2 = e3;
                throw new RuntimeException(exc2.getMessage(), exc2);
            }
        } else {
            int i11 = i3 * 2;
            byte[] b6 = b(i11);
            byte[] b7 = b(i11 + 1);
            byte[] a7 = org.bouncycastle.util.a.a(bArr);
            gVar.d(0, a7.length, a7);
            T6.a.b(i3, gVar);
            gVar.c((byte) 16777091);
            gVar.c((byte) -31869);
            gVar.d(0, b6.length, b6);
            gVar.d(0, b7.length, b7);
            byte[] bArr4 = new byte[gVar.g()];
            gVar.b(0, bArr4);
            return bArr4;
        }
    }

    public final byte[] b(int i2) {
        a aVar;
        if (i2 >= this.h) {
            return a(i2);
        }
        if (i2 < 129) {
            aVar = m[i2];
        } else {
            aVar = new a(i2);
        }
        return c(aVar);
    }

    public final byte[] c(a aVar) {
        synchronized (this.g) {
            try {
                byte[] bArr = (byte[]) this.g.get(aVar);
                if (bArr != null) {
                    return bArr;
                }
                byte[] a2 = a(aVar.a);
                this.g.put(aVar, a2);
                return a2;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final synchronized int d() {
        return this.j;
    }

    public final boolean equals(Object obj) {
        i iVar;
        if (this == obj) {
            return true;
        }
        if (obj == null || h.class != obj.getClass()) {
            return false;
        }
        h hVar = (h) obj;
        if (this.j != hVar.j || this.e != hVar.e || !Arrays.equals(this.b, hVar.b)) {
            return false;
        }
        k kVar = hVar.c;
        k kVar2 = this.c;
        if (kVar2 == null ? kVar != null : !kVar2.equals(kVar)) {
            return false;
        }
        d dVar = hVar.d;
        d dVar2 = this.d;
        if (dVar2 == null ? dVar != null : !dVar2.equals(dVar)) {
            return false;
        }
        if (!Arrays.equals(this.f, hVar.f)) {
            return false;
        }
        i iVar2 = this.k;
        if (iVar2 == null || (iVar = hVar.k) == null) {
            return true;
        }
        return iVar2.equals(iVar);
    }

    public final i f() {
        i iVar;
        synchronized (this) {
            try {
                if (this.k == null) {
                    this.k = new i(this.c, this.d, c(l), this.b);
                }
                iVar = this.k;
            } catch (Throwable th) {
                throw th;
            }
        }
        return iVar;
    }

    public final synchronized void g() {
        this.j++;
    }

    public final byte[] getEncoded() throws IOException {
        x xVar = new x();
        xVar.c(0);
        xVar.c(this.c.a);
        xVar.c(this.d.a);
        xVar.b(this.b);
        xVar.c(this.j);
        xVar.c(this.e);
        byte[] bArr = this.f;
        xVar.c(bArr.length);
        xVar.b(bArr);
        return ((ByteArrayOutputStream) xVar.a).toByteArray();
    }

    public final int hashCode() {
        int i2;
        int i3;
        int h2 = (org.bouncycastle.util.a.h(this.b) + (this.j * 31)) * 31;
        int i4 = 0;
        k kVar = this.c;
        if (kVar != null) {
            i2 = kVar.hashCode();
        } else {
            i2 = 0;
        }
        int i5 = (h2 + i2) * 31;
        d dVar = this.d;
        if (dVar != null) {
            i3 = dVar.hashCode();
        } else {
            i3 = 0;
        }
        int h3 = (org.bouncycastle.util.a.h(this.f) + ((((i5 + i3) * 31) + this.e) * 31)) * 31;
        i iVar = this.k;
        if (iVar != null) {
            i4 = iVar.hashCode();
        }
        return h3 + i4;
    }

    public h(k kVar, d dVar, int i2, byte[] bArr, int i3, byte[] bArr2) {
        super(true);
        this.c = kVar;
        this.d = dVar;
        this.j = i2;
        this.b = org.bouncycastle.util.a.a(bArr);
        this.e = i3;
        this.f = org.bouncycastle.util.a.a(bArr2);
        this.h = 1 << (kVar.b + 1);
        this.g = new WeakHashMap();
        this.i = C0433a.a(kVar.c);
    }
}
