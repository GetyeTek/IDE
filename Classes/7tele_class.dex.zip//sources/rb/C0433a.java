package rb;

import Ha.g;
import Ia.h;
import Ia.k;
import Ia.l;
import java.util.HashMap;
import la.C0390u;
import wa.C0468b;

/* renamed from: rb.a  reason: case insensitive filesystem */
public final class C0433a {
    static {
        HashMap hashMap = new HashMap();
        HashMap hashMap2 = new HashMap();
        C0390u uVar = C0468b.a;
        hashMap.put("SHA-256", uVar);
        C0390u uVar2 = C0468b.c;
        hashMap.put("SHA-512", uVar2);
        C0390u uVar3 = C0468b.k;
        hashMap.put("SHAKE128", uVar3);
        C0390u uVar4 = C0468b.l;
        hashMap.put("SHAKE256", uVar4);
        hashMap2.put(uVar, "SHA-256");
        hashMap2.put(uVar2, "SHA-512");
        hashMap2.put(uVar3, "SHAKE128");
        hashMap2.put(uVar4, "SHAKE256");
    }

    public static g a(C0390u uVar) {
        if (uVar.l(C0468b.a)) {
            return new h();
        }
        if (uVar.l(C0468b.c)) {
            return new k();
        }
        if (uVar.l(C0468b.k)) {
            return new l(128);
        }
        if (uVar.l(C0468b.l)) {
            return new l(256);
        }
        throw new IllegalArgumentException("unrecognized digest OID: " + uVar);
    }
}
