package M9;

public interface b {
    b getCallerFrame();

    StackTraceElement getStackTraceElement();
}
