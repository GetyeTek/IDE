package M9;

import kotlin.coroutines.d;

public final class a implements L9.a<Object> {
    public static final a a = new Object();

    public final d getContext() {
        throw new IllegalStateException("This continuation is already complete");
    }

    public final void resumeWith(Object obj) {
        throw new IllegalStateException("This continuation is already complete");
    }

    public final String toString() {
        return "This continuation is already complete";
    }
}
