package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

public final class n implements AlgorithmParameterSpec {
    public static final HashMap a = new HashMap();
}
