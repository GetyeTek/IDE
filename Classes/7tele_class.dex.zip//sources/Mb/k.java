package Mb;

import java.security.spec.AlgorithmParameterSpec;

public final class k implements AlgorithmParameterSpec {
}
