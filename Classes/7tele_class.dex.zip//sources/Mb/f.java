package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;
import qb.C0428b;

public final class f implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        f fVar = new f(C0428b.b);
        f fVar2 = new f(C0428b.c);
        f fVar3 = new f(C0428b.d);
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("hqc128", fVar);
        hashMap.put("hqc192", fVar2);
        hashMap.put("hqc256", fVar3);
    }

    public f(C0428b bVar) {
        bVar.getClass();
    }
}
