package Mb;

import java.security.spec.KeySpec;

public final class m implements KeySpec {
    public short[][] a;
    public short[][] b;
    public short[] c;
    public int d;
}
