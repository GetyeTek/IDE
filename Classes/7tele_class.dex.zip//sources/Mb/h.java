package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

public final class h implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        Object obj = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        Object obj4 = new Object();
        Object obj5 = new Object();
        Object obj6 = new Object();
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("ntrulpr653", obj);
        hashMap.put("ntrulpr761", obj2);
        hashMap.put("ntrulpr857", obj3);
        hashMap.put("ntrulpr953", obj4);
        hashMap.put("ntrulpr1013", obj5);
        hashMap.put("ntrulpr1277", obj6);
    }
}
