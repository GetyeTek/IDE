package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

public final class g implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        Object obj = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        Object obj4 = new Object();
        Object obj5 = new Object();
        Object obj6 = new Object();
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("kyber512", obj);
        hashMap.put("kyber768", obj2);
        hashMap.put("kyber1024", obj3);
        hashMap.put("kyber512-aes", obj4);
        hashMap.put("kyber768-aes", obj5);
        hashMap.put("kyber1024-aes", obj6);
    }
}
