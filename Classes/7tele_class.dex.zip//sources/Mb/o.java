package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;
import xb.f;

public final class o implements AlgorithmParameterSpec {
    public static final HashMap a = new HashMap();

    static {
        new o(f.b);
        new o(f.c);
        new o(f.d);
        new o(f.e);
        new o(f.f);
        new o(f.g);
        new o(f.h);
        new o(f.i);
    }

    public o(f fVar) {
        fVar.getClass();
    }
}
