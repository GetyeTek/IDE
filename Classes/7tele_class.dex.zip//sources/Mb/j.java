package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

public final class j implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        Object obj = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        Object obj4 = new Object();
        Object obj5 = new Object();
        Object obj6 = new Object();
        Object obj7 = new Object();
        Object obj8 = new Object();
        Object obj9 = new Object();
        Object obj10 = new Object();
        Object obj11 = new Object();
        Object obj12 = new Object();
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("picnicl1fs", obj);
        hashMap.put("picnicl1ur", obj2);
        hashMap.put("picnicl3fs", obj3);
        hashMap.put("picnicl3ur", obj4);
        hashMap.put("picnicl5fs", obj5);
        hashMap.put("picnicl5ur", obj6);
        hashMap.put("picnic3l1", obj7);
        hashMap.put("picnic3l3", obj8);
        hashMap.put("picnic3l5", obj9);
        hashMap.put("picnicl1full", obj10);
        hashMap.put("picnicl3full", obj11);
        hashMap.put("picnicl5full", obj12);
    }
}
