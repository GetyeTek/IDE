package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

public final class p implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        Object obj = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        Object obj4 = new Object();
        Object obj5 = new Object();
        Object obj6 = new Object();
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("sntrup653", obj);
        hashMap.put("sntrup761", obj2);
        hashMap.put("sntrup857", obj3);
        hashMap.put("sntrup953", obj4);
        hashMap.put("sntrup1013", obj5);
        hashMap.put("sntrup1277", obj6);
    }
}
