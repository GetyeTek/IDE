package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;
import pb.C0423b;

public final class e implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        e eVar = new e(C0423b.b);
        e eVar2 = new e(C0423b.c);
        e eVar3 = new e(C0423b.d);
        e eVar4 = new e(C0423b.e);
        e eVar5 = new e(C0423b.f);
        e eVar6 = new e(C0423b.g);
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("frodokem19888r3", eVar);
        hashMap.put("frodokem19888shaker3", eVar2);
        hashMap.put("frodokem31296r3", eVar3);
        hashMap.put("frodokem31296shaker3", eVar4);
        hashMap.put("frodokem43088r3", eVar5);
        hashMap.put("frodokem43088shaker3", eVar6);
        hashMap.put("frodokem640aes", eVar);
        hashMap.put("frodokem640shake", eVar2);
        hashMap.put("frodokem976aes", eVar3);
        hashMap.put("frodokem976shake", eVar4);
        hashMap.put("frodokem1344aes", eVar5);
        hashMap.put("frodokem1344shake", eVar6);
    }

    public e(C0423b bVar) {
        bVar.getClass();
    }
}
