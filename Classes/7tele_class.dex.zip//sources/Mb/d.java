package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;
import ob.C0417b;

public final class d implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        d dVar = new d(C0417b.c);
        d dVar2 = new d(C0417b.d);
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("falcon-512", dVar);
        hashMap.put("falcon-1024", dVar2);
    }

    public d(C0417b bVar) {
        bVar.getClass();
    }
}
