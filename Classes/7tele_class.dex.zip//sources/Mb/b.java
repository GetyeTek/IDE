package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;
import lb.C0398c;

public final class b implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        b bVar = new b(C0398c.d);
        b bVar2 = new b(C0398c.e);
        b bVar3 = new b(C0398c.f);
        b bVar4 = new b(C0398c.g);
        b bVar5 = new b(C0398c.h);
        b bVar6 = new b(C0398c.i);
        b bVar7 = new b(C0398c.j);
        b bVar8 = new b(C0398c.k);
        b bVar9 = new b(C0398c.l);
        b bVar10 = new b(C0398c.m);
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("mceliece348864", bVar);
        hashMap.put("mceliece348864f", bVar2);
        hashMap.put("mceliece460896", bVar3);
        hashMap.put("mceliece460896f", bVar4);
        hashMap.put("mceliece6688128", bVar5);
        hashMap.put("mceliece6688128f", bVar6);
        hashMap.put("mceliece6960119", bVar7);
        hashMap.put("mceliece6960119f", bVar8);
        hashMap.put("mceliece8192128", bVar9);
        hashMap.put("mceliece8192128f", bVar10);
    }

    public b(C0398c cVar) {
        cVar.getClass();
    }
}
