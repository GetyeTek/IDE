package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

public final class c implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        Object obj = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        Object obj4 = new Object();
        Object obj5 = new Object();
        Object obj6 = new Object();
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("dilithium2", obj);
        hashMap.put("dilithium3", obj2);
        hashMap.put("dilithium5", obj3);
        hashMap.put("dilithium2-aes", obj4);
        hashMap.put("dilithium3-aes", obj5);
        hashMap.put("dilithium5-aes", obj6);
    }
}
