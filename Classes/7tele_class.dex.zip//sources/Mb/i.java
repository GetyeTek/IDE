package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

public final class i implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        Object obj = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        Object obj4 = new Object();
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("ntruhps2048509", obj);
        hashMap.put("ntruhps2048677", obj2);
        hashMap.put("ntruhps4096821", obj3);
        hashMap.put("ntruhrss701", obj4);
    }
}
