package Mb;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;
import kb.b;

public final class a implements AlgorithmParameterSpec {
    public static final HashMap a;

    static {
        a aVar = new a(b.c);
        a aVar2 = new a(b.d);
        a aVar3 = new a(b.e);
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put("bike128", aVar);
        hashMap.put("bike192", aVar2);
        hashMap.put("bike256", aVar3);
    }

    public a(b bVar) {
        bVar.getClass();
    }
}
