package com.journeyapps.barcodescanner;

import H8.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.google.zxing.client.android.R;
import com.journeyapps.barcodescanner.a;
import com.journeyapps.barcodescanner.camera.CameraSettings;

public class DecoratedBarcodeView extends FrameLayout {
    public BarcodeView a;
    public ViewfinderView b;
    public TextView c;

    public interface a {
    }

    public class b {
        public final a.C0021a a;

        public b(a.C0021a aVar) {
            this.a = aVar;
        }
    }

    public DecoratedBarcodeView(Context context) {
        super(context);
        a((AttributeSet) null);
    }

    public final void a(AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.zxing_view);
        int resourceId = obtainStyledAttributes.getResourceId(R.styleable.zxing_view_zxing_scanner_layout, R.layout.zxing_barcode_scanner);
        obtainStyledAttributes.recycle();
        View.inflate(getContext(), resourceId, this);
        BarcodeView barcodeView = (BarcodeView) findViewById(R.id.zxing_barcode_surface);
        this.a = barcodeView;
        if (barcodeView != null) {
            barcodeView.c(attributeSet);
            ViewfinderView viewfinderView = (ViewfinderView) findViewById(R.id.zxing_viewfinder_view);
            this.b = viewfinderView;
            if (viewfinderView != null) {
                viewfinderView.setCameraPreview(this.a);
                this.c = (TextView) findViewById(R.id.zxing_status_view);
                return;
            }
            throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.ViewfinderView on provided layout with the id \"zxing_viewfinder_view\".");
        }
        throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.BarcodeView on provided layout with the id \"zxing_barcode_surface\".");
    }

    public BarcodeView getBarcodeView() {
        return (BarcodeView) findViewById(R.id.zxing_barcode_surface);
    }

    public CameraSettings getCameraSettings() {
        return this.a.getCameraSettings();
    }

    public j getDecoderFactory() {
        return this.a.getDecoderFactory();
    }

    public TextView getStatusView() {
        return this.c;
    }

    public ViewfinderView getViewFinder() {
        return this.b;
    }

    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 24) {
            this.a.setTorch(true);
            return true;
        } else if (i == 25) {
            this.a.setTorch(false);
            return true;
        } else if (i == 27 || i == 80) {
            return true;
        } else {
            return super.onKeyDown(i, keyEvent);
        }
    }

    public void setCameraSettings(CameraSettings cameraSettings) {
        this.a.setCameraSettings(cameraSettings);
    }

    public void setDecoderFactory(j jVar) {
        this.a.setDecoderFactory(jVar);
    }

    public void setStatusText(String str) {
        TextView textView = this.c;
        if (textView != null) {
            textView.setText(str);
        }
    }

    public void setTorchListener(a aVar) {
    }

    public DecoratedBarcodeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a(attributeSet);
    }

    public DecoratedBarcodeView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        a(attributeSet);
    }
}
