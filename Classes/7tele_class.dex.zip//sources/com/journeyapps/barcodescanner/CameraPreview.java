package com.journeyapps.barcodescanner;

import H8.q;
import H8.r;
import H8.u;
import I8.e;
import I8.f;
import I8.g;
import I8.h;
import I8.i;
import I8.j;
import I8.m;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.google.zxing.client.android.R;
import com.journeyapps.barcodescanner.camera.CameraSettings;
import java.util.ArrayList;
import java.util.Iterator;

public class CameraPreview extends ViewGroup {
    public static final /* synthetic */ int A = 0;
    public I8.e a;
    public WindowManager b;
    public Handler c;
    public boolean d = false;
    public SurfaceView e;
    public TextureView f;
    public boolean g = false;
    public r h;
    public int i = -1;
    public final ArrayList j = new ArrayList();
    public i k;
    public CameraSettings l = new CameraSettings();
    public u m;
    public u n;
    public Rect o;
    public u p;
    public Rect q = null;
    public Rect r = null;
    public u s = null;
    public double t = 0.1d;
    public m u = null;
    public boolean v = false;
    public final a w = new a();
    public final b x = new b();
    public final c y = new c();
    public final d z = new d();

    public class a implements SurfaceHolder.Callback {
        public a() {
        }

        public final void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
            if (surfaceHolder == null) {
                int i4 = CameraPreview.A;
                Log.e("CameraPreview", "*** WARNING *** surfaceChanged() gave us a null surface!");
                return;
            }
            u uVar = new u(i2, i3);
            CameraPreview cameraPreview = CameraPreview.this;
            cameraPreview.p = uVar;
            cameraPreview.h();
        }

        public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        }

        public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            CameraPreview.this.p = null;
        }
    }

    public class b implements Handler.Callback {
        public b() {
        }

        public final boolean handleMessage(Message message) {
            i iVar;
            int i = message.what;
            int i2 = R.id.zxing_prewiew_size_ready;
            CameraPreview cameraPreview = CameraPreview.this;
            d dVar = cameraPreview.z;
            if (i == i2) {
                u uVar = (u) message.obj;
                cameraPreview.n = uVar;
                u uVar2 = cameraPreview.m;
                if (uVar2 == null) {
                    return true;
                }
                if (uVar == null || (iVar = cameraPreview.k) == null) {
                    cameraPreview.r = null;
                    cameraPreview.q = null;
                    cameraPreview.o = null;
                    throw new IllegalStateException("containerSize or previewSize is not set yet");
                }
                Rect b = iVar.c.b(uVar, iVar.a);
                if (b.width() > 0 && b.height() > 0) {
                    cameraPreview.o = b;
                    Rect rect = new Rect(0, 0, uVar2.a, uVar2.b);
                    Rect rect2 = cameraPreview.o;
                    Rect rect3 = new Rect(rect);
                    rect3.intersect(rect2);
                    if (cameraPreview.s != null) {
                        rect3.inset(Math.max(0, (rect3.width() - cameraPreview.s.a) / 2), Math.max(0, (rect3.height() - cameraPreview.s.b) / 2));
                    } else {
                        int min = (int) Math.min(((double) rect3.width()) * cameraPreview.t, ((double) rect3.height()) * cameraPreview.t);
                        rect3.inset(min, min);
                        if (rect3.height() > rect3.width()) {
                            rect3.inset(0, (rect3.height() - rect3.width()) / 2);
                        }
                    }
                    cameraPreview.q = rect3;
                    Rect rect4 = new Rect(cameraPreview.q);
                    Rect rect5 = cameraPreview.o;
                    rect4.offset(-rect5.left, -rect5.top);
                    int i3 = rect4.left;
                    int i4 = uVar.a;
                    int width = (i3 * i4) / cameraPreview.o.width();
                    int i5 = rect4.top;
                    int i6 = uVar.b;
                    Rect rect6 = new Rect(width, (i5 * i6) / cameraPreview.o.height(), (rect4.right * i4) / cameraPreview.o.width(), (rect4.bottom * i6) / cameraPreview.o.height());
                    cameraPreview.r = rect6;
                    if (rect6.width() <= 0 || cameraPreview.r.height() <= 0) {
                        cameraPreview.r = null;
                        cameraPreview.q = null;
                        Log.w("CameraPreview", "Preview frame is too small");
                    } else {
                        dVar.a();
                    }
                }
                cameraPreview.requestLayout();
                cameraPreview.h();
                return true;
            }
            if (i == R.id.zxing_camera_error) {
                Exception exc = (Exception) message.obj;
                if (cameraPreview.a != null) {
                    cameraPreview.d();
                    dVar.b(exc);
                }
            } else if (i == R.id.zxing_camera_closed) {
                dVar.d();
            }
            return false;
        }
    }

    public class c {
        public c() {
        }
    }

    public class d implements e {
        public d() {
        }

        public final void a() {
            Iterator it = CameraPreview.this.j.iterator();
            while (it.hasNext()) {
                ((e) it.next()).a();
            }
        }

        public final void b(Exception exc) {
            Iterator it = CameraPreview.this.j.iterator();
            while (it.hasNext()) {
                ((e) it.next()).b(exc);
            }
        }

        public final void c() {
            Iterator it = CameraPreview.this.j.iterator();
            while (it.hasNext()) {
                ((e) it.next()).c();
            }
        }

        public final void d() {
            Iterator it = CameraPreview.this.j.iterator();
            while (it.hasNext()) {
                ((e) it.next()).d();
            }
        }

        public final void e() {
            Iterator it = CameraPreview.this.j.iterator();
            while (it.hasNext()) {
                ((e) it.next()).e();
            }
        }
    }

    public interface e {
        void a();

        void b(Exception exc);

        void c();

        void d();

        void e();
    }

    public CameraPreview(Context context) {
        super(context);
        b(context, (AttributeSet) null);
    }

    public static void a(CameraPreview cameraPreview) {
        if (cameraPreview.a != null && cameraPreview.getDisplayRotation() != cameraPreview.i) {
            cameraPreview.d();
            cameraPreview.f();
        }
    }

    private int getDisplayRotation() {
        return this.b.getDefaultDisplay().getRotation();
    }

    /* JADX WARNING: type inference failed for: r2v4, types: [H8.r, java.lang.Object] */
    public final void b(Context context, AttributeSet attributeSet) {
        if (getBackground() == null) {
            setBackgroundColor(-16777216);
        }
        c(attributeSet);
        this.b = (WindowManager) context.getSystemService("window");
        this.c = new Handler(this.x);
        this.h = new Object();
    }

    public final void c(AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.zxing_camera_preview);
        int dimension = (int) obtainStyledAttributes.getDimension(R.styleable.zxing_camera_preview_zxing_framing_rect_width, -1.0f);
        int dimension2 = (int) obtainStyledAttributes.getDimension(R.styleable.zxing_camera_preview_zxing_framing_rect_height, -1.0f);
        if (dimension > 0 && dimension2 > 0) {
            this.s = new u(dimension, dimension2);
        }
        this.d = obtainStyledAttributes.getBoolean(R.styleable.zxing_camera_preview_zxing_use_texture_view, true);
        int integer = obtainStyledAttributes.getInteger(R.styleable.zxing_camera_preview_zxing_preview_scaling_strategy, -1);
        if (integer == 1) {
            this.u = new h();
        } else if (integer == 2) {
            this.u = new j();
        } else if (integer == 3) {
            this.u = new m();
        }
        obtainStyledAttributes.recycle();
    }

    public void d() {
        TextureView textureView;
        SurfaceView surfaceView;
        C9.b.g();
        Log.d("CameraPreview", "pause()");
        this.i = -1;
        I8.e eVar = this.a;
        if (eVar != null) {
            C9.b.g();
            if (eVar.f) {
                eVar.a.b(eVar.l);
            } else {
                eVar.g = true;
            }
            eVar.f = false;
            this.a = null;
            this.g = false;
        } else {
            this.c.sendEmptyMessage(R.id.zxing_camera_closed);
        }
        if (this.p == null && (surfaceView = this.e) != null) {
            surfaceView.getHolder().removeCallback(this.w);
        }
        if (this.p == null && (textureView = this.f) != null) {
            textureView.setSurfaceTextureListener((TextureView.SurfaceTextureListener) null);
        }
        this.m = null;
        this.n = null;
        this.r = null;
        r rVar = this.h;
        q qVar = rVar.c;
        if (qVar != null) {
            qVar.disable();
        }
        rVar.c = null;
        rVar.b = null;
        rVar.d = null;
        this.z.c();
    }

    public void e() {
    }

    /* JADX WARNING: type inference failed for: r0v12, types: [I8.e, java.lang.Object] */
    public final void f() {
        C9.b.g();
        Log.d("CameraPreview", "resume()");
        if (this.a != null) {
            Log.w("CameraPreview", "initCamera called twice");
        } else {
            Context context = getContext();
            ? obj = new Object();
            obj.f = false;
            obj.g = true;
            obj.i = new CameraSettings();
            e.a aVar = new e.a();
            obj.j = new e.b();
            obj.k = new e.c();
            obj.l = new e.d();
            C9.b.g();
            if (g.e == null) {
                g.e = new g();
            }
            g gVar = g.e;
            obj.a = gVar;
            com.journeyapps.barcodescanner.camera.b bVar = new com.journeyapps.barcodescanner.camera.b(context);
            obj.c = bVar;
            bVar.g = obj.i;
            obj.h = new Handler();
            CameraSettings cameraSettings = this.l;
            if (!obj.f) {
                obj.i = cameraSettings;
                bVar.g = cameraSettings;
            }
            this.a = obj;
            obj.d = this.c;
            C9.b.g();
            obj.f = true;
            obj.g = false;
            synchronized (gVar.d) {
                gVar.c++;
                gVar.b(aVar);
            }
            this.i = getDisplayRotation();
        }
        if (this.p != null) {
            h();
        } else {
            SurfaceView surfaceView = this.e;
            if (surfaceView != null) {
                surfaceView.getHolder().addCallback(this.w);
            } else {
                TextureView textureView = this.f;
                if (textureView != null) {
                    if (textureView.isAvailable()) {
                        this.f.getSurfaceTexture();
                        this.p = new u(this.f.getWidth(), this.f.getHeight());
                        h();
                    } else {
                        this.f.setSurfaceTextureListener(new H8.b(this));
                    }
                }
            }
        }
        requestLayout();
        r rVar = this.h;
        Context context2 = getContext();
        c cVar = this.y;
        q qVar = rVar.c;
        if (qVar != null) {
            qVar.disable();
        }
        rVar.c = null;
        rVar.b = null;
        rVar.d = null;
        Context applicationContext = context2.getApplicationContext();
        rVar.d = cVar;
        rVar.b = (WindowManager) applicationContext.getSystemService("window");
        q qVar2 = new q(rVar, applicationContext);
        rVar.c = qVar2;
        qVar2.enable();
        rVar.a = rVar.b.getDefaultDisplay().getRotation();
    }

    public final void g(f fVar) {
        if (!this.g && this.a != null) {
            Log.i("CameraPreview", "Starting preview");
            I8.e eVar = this.a;
            eVar.b = fVar;
            C9.b.g();
            if (eVar.f) {
                eVar.a.b(eVar.k);
                this.g = true;
                e();
                this.z.e();
                return;
            }
            throw new IllegalStateException("CameraInstance is not open");
        }
    }

    public I8.e getCameraInstance() {
        return this.a;
    }

    public CameraSettings getCameraSettings() {
        return this.l;
    }

    public Rect getFramingRect() {
        return this.q;
    }

    public u getFramingRectSize() {
        return this.s;
    }

    public double getMarginFraction() {
        return this.t;
    }

    public Rect getPreviewFramingRect() {
        return this.r;
    }

    public m getPreviewScalingStrategy() {
        m mVar = this.u;
        if (mVar != null) {
            return mVar;
        }
        if (this.f != null) {
            return new h();
        }
        return new j();
    }

    public u getPreviewSize() {
        return this.n;
    }

    /* JADX WARNING: type inference failed for: r0v4, types: [I8.f, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v13, types: [I8.f, java.lang.Object] */
    public final void h() {
        Rect rect;
        float f2;
        u uVar = this.p;
        if (uVar != null && this.n != null && (rect = this.o) != null) {
            if (this.e == null || !uVar.equals(new u(rect.width(), this.o.height()))) {
                TextureView textureView = this.f;
                if (textureView != null && textureView.getSurfaceTexture() != null) {
                    if (this.n != null) {
                        int width = this.f.getWidth();
                        int height = this.f.getHeight();
                        u uVar2 = this.n;
                        float f3 = (float) height;
                        float f4 = ((float) width) / f3;
                        float f5 = ((float) uVar2.a) / ((float) uVar2.b);
                        float f6 = 1.0f;
                        if (f4 < f5) {
                            f6 = f5 / f4;
                            f2 = 1.0f;
                        } else {
                            f2 = f4 / f5;
                        }
                        Matrix matrix = new Matrix();
                        matrix.setScale(f6, f2);
                        float f7 = (float) width;
                        matrix.postTranslate((f7 - (f6 * f7)) / 2.0f, (f3 - (f2 * f3)) / 2.0f);
                        this.f.setTransform(matrix);
                    }
                    SurfaceTexture surfaceTexture = this.f.getSurfaceTexture();
                    ? obj = new Object();
                    if (surfaceTexture != null) {
                        obj.b = surfaceTexture;
                        g(obj);
                        return;
                    }
                    throw new IllegalArgumentException("surfaceTexture may not be null");
                }
                return;
            }
            SurfaceHolder holder = this.e.getHolder();
            ? obj2 = new Object();
            if (holder != null) {
                obj2.a = holder;
                g(obj2);
                return;
            }
            throw new IllegalArgumentException("surfaceHolder may not be null");
        }
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.d) {
            TextureView textureView = new TextureView(getContext());
            this.f = textureView;
            textureView.setSurfaceTextureListener(new H8.b(this));
            addView(this.f);
            return;
        }
        SurfaceView surfaceView = new SurfaceView(getContext());
        this.e = surfaceView;
        surfaceView.getHolder().addCallback(this.w);
        addView(this.e);
    }

    /* JADX WARNING: type inference failed for: r2v5, types: [I8.i, java.lang.Object] */
    @SuppressLint({"DrawAllocation"})
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        u uVar = new u(i4 - i2, i5 - i3);
        this.m = uVar;
        I8.e eVar = this.a;
        if (eVar != null && eVar.e == null) {
            int displayRotation = getDisplayRotation();
            ? obj = new Object();
            obj.c = new j();
            obj.b = displayRotation;
            obj.a = uVar;
            this.k = obj;
            obj.c = getPreviewScalingStrategy();
            I8.e eVar2 = this.a;
            i iVar = this.k;
            eVar2.e = iVar;
            eVar2.c.h = iVar;
            C9.b.g();
            if (eVar2.f) {
                eVar2.a.b(eVar2.j);
                boolean z3 = this.v;
                if (z3) {
                    I8.e eVar3 = this.a;
                    eVar3.getClass();
                    C9.b.g();
                    if (eVar3.f) {
                        eVar3.a.b(new I8.c(eVar3, z3));
                    }
                }
            } else {
                throw new IllegalStateException("CameraInstance is not open");
            }
        }
        SurfaceView surfaceView = this.e;
        if (surfaceView != null) {
            Rect rect = this.o;
            if (rect == null) {
                surfaceView.layout(0, 0, getWidth(), getHeight());
            } else {
                surfaceView.layout(rect.left, rect.top, rect.right, rect.bottom);
            }
        } else {
            TextureView textureView = this.f;
            if (textureView != null) {
                textureView.layout(0, 0, getWidth(), getHeight());
            }
        }
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof Bundle)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        Bundle bundle = (Bundle) parcelable;
        super.onRestoreInstanceState(bundle.getParcelable("super"));
        setTorch(bundle.getBoolean("torch"));
    }

    public final Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState = super.onSaveInstanceState();
        Bundle bundle = new Bundle();
        bundle.putParcelable("super", onSaveInstanceState);
        bundle.putBoolean("torch", this.v);
        return bundle;
    }

    public void setCameraSettings(CameraSettings cameraSettings) {
        this.l = cameraSettings;
    }

    public void setFramingRectSize(u uVar) {
        this.s = uVar;
    }

    public void setMarginFraction(double d2) {
        if (d2 < 0.5d) {
            this.t = d2;
            return;
        }
        throw new IllegalArgumentException("The margin fraction must be less than 0.5");
    }

    public void setPreviewScalingStrategy(m mVar) {
        this.u = mVar;
    }

    public void setTorch(boolean z2) {
        this.v = z2;
        I8.e eVar = this.a;
        if (eVar != null) {
            C9.b.g();
            if (eVar.f) {
                eVar.a.b(new I8.c(eVar, z2));
            }
        }
    }

    public void setUseTextureView(boolean z2) {
        this.d = z2;
    }

    public CameraPreview(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        b(context, attributeSet);
    }

    public CameraPreview(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        b(context, attributeSet);
    }
}
