package com.journeyapps.barcodescanner;

import H8.e;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.client.android.DecodeFormatManager;
import com.google.zxing.client.android.DecodeHintManager;
import com.google.zxing.client.android.R;
import com.journeyapps.barcodescanner.BarcodeView;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.a;
import com.journeyapps.barcodescanner.camera.CameraSettings;
import java.util.Map;
import java.util.Set;

public class CaptureActivity extends Activity {
    public a a;
    public DecoratedBarcodeView b;

    /* JADX WARNING: type inference failed for: r7v1, types: [java.lang.Object, H8.j, H8.m] */
    public final void onCreate(Bundle bundle) {
        int intExtra;
        int i;
        super.onCreate(bundle);
        setContentView(R.layout.zxing_capture);
        this.b = (DecoratedBarcodeView) findViewById(R.id.zxing_barcode_scanner);
        DecoratedBarcodeView decoratedBarcodeView = this.b;
        a aVar = new a(this, decoratedBarcodeView);
        this.a = aVar;
        Intent intent = getIntent();
        getWindow().addFlags(128);
        if (bundle != null) {
            aVar.c = bundle.getInt("SAVED_ORIENTATION_LOCK", -1);
        }
        if (intent != null) {
            if (intent.getBooleanExtra("SCAN_ORIENTATION_LOCKED", true)) {
                if (aVar.c == -1) {
                    int rotation = getWindowManager().getDefaultDisplay().getRotation();
                    int i2 = getResources().getConfiguration().orientation;
                    if (i2 == 2) {
                        if (!(rotation == 0 || rotation == 1)) {
                            i = 8;
                            aVar.c = i;
                        }
                    } else if (i2 == 1) {
                        if (rotation == 0 || rotation == 3) {
                            i = 1;
                        } else {
                            i = 9;
                        }
                        aVar.c = i;
                    }
                    i = 0;
                    aVar.c = i;
                }
                setRequestedOrientation(aVar.c);
            }
            if ("com.google.zxing.client.android.SCAN".equals(intent.getAction())) {
                Set parseDecodeFormats = DecodeFormatManager.parseDecodeFormats(intent);
                Map<DecodeHintType, ?> parseDecodeHints = DecodeHintManager.parseDecodeHints(intent);
                CameraSettings cameraSettings = new CameraSettings();
                if (intent.hasExtra("SCAN_CAMERA_ID") && (intExtra = intent.getIntExtra("SCAN_CAMERA_ID", -1)) >= 0) {
                    cameraSettings.a = intExtra;
                }
                if (intent.hasExtra("TORCH_ENABLED") && intent.getBooleanExtra("TORCH_ENABLED", false)) {
                    decoratedBarcodeView.a.setTorch(true);
                }
                String stringExtra = intent.getStringExtra("PROMPT_MESSAGE");
                if (stringExtra != null) {
                    decoratedBarcodeView.setStatusText(stringExtra);
                }
                int intExtra2 = intent.getIntExtra("SCAN_TYPE", 0);
                String stringExtra2 = intent.getStringExtra("CHARACTER_SET");
                new MultiFormatReader().setHints(parseDecodeHints);
                decoratedBarcodeView.a.setCameraSettings(cameraSettings);
                BarcodeView barcodeView = decoratedBarcodeView.a;
                ? obj = new Object();
                obj.a = parseDecodeFormats;
                obj.b = parseDecodeHints;
                obj.c = stringExtra2;
                obj.d = intExtra2;
                barcodeView.setDecoderFactory(obj);
            }
            if (!intent.getBooleanExtra("BEEP_ENABLED", true)) {
                aVar.i.setBeepEnabled(false);
            }
            if (intent.hasExtra("SHOW_MISSING_CAMERA_PERMISSION_DIALOG")) {
                boolean booleanExtra = intent.getBooleanExtra("SHOW_MISSING_CAMERA_PERMISSION_DIALOG", true);
                String stringExtra3 = intent.getStringExtra("MISSING_CAMERA_PERMISSION_DIALOG_MESSAGE");
                aVar.e = booleanExtra;
                if (stringExtra3 == null) {
                    stringExtra3 = "";
                }
                aVar.f = stringExtra3;
            }
            if (intent.hasExtra("TIMEOUT")) {
                aVar.j.postDelayed(new e(aVar), intent.getLongExtra("TIMEOUT", 0));
            }
            if (intent.getBooleanExtra("BARCODE_IMAGE_ENABLED", false)) {
                aVar.d = true;
            }
        }
        a aVar2 = this.a;
        a.C0021a aVar3 = aVar2.l;
        DecoratedBarcodeView decoratedBarcodeView2 = aVar2.b;
        BarcodeView barcodeView2 = decoratedBarcodeView2.a;
        DecoratedBarcodeView.b bVar = new DecoratedBarcodeView.b(aVar3);
        barcodeView2.B = BarcodeView.b.b;
        barcodeView2.C = bVar;
        barcodeView2.k();
    }

    public final void onDestroy() {
        super.onDestroy();
        a aVar = this.a;
        aVar.g = true;
        aVar.h.cancel();
        aVar.j.removeCallbacksAndMessages((Object) null);
    }

    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (this.b.onKeyDown(i, keyEvent) || super.onKeyDown(i, keyEvent)) {
            return true;
        }
        return false;
    }

    public final void onPause() {
        super.onPause();
        a aVar = this.a;
        aVar.h.cancel();
        BarcodeView barcodeView = aVar.b.a;
        I8.e cameraInstance = barcodeView.getCameraInstance();
        barcodeView.d();
        long nanoTime = System.nanoTime();
        while (cameraInstance != null && !cameraInstance.g && System.nanoTime() - nanoTime <= 2000000000) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException unused) {
                return;
            }
        }
    }

    public final void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        a aVar = this.a;
        aVar.getClass();
        if (i != 250) {
            return;
        }
        if (iArr.length <= 0 || iArr[0] != 0) {
            Intent intent = new Intent("com.google.zxing.client.android.SCAN");
            intent.putExtra("MISSING_CAMERA_PERMISSION", true);
            aVar.a.setResult(0, intent);
            if (aVar.e) {
                aVar.b(aVar.f);
            } else {
                aVar.a();
            }
        } else {
            aVar.b.a.f();
        }
    }

    public final void onResume() {
        super.onResume();
        a aVar = this.a;
        int i = Build.VERSION.SDK_INT;
        DecoratedBarcodeView decoratedBarcodeView = aVar.b;
        if (i >= 23) {
            CaptureActivity captureActivity = aVar.a;
            if (ContextCompat.checkSelfPermission(captureActivity, "android.permission.CAMERA") == 0) {
                decoratedBarcodeView.a.f();
            } else if (!aVar.m) {
                ActivityCompat.requestPermissions(captureActivity, new String[]{"android.permission.CAMERA"}, 250);
                aVar.m = true;
            }
        } else {
            decoratedBarcodeView.a.f();
        }
        aVar.h.start();
    }

    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("SAVED_ORIENTATION_LOCK", this.a.c);
    }
}
