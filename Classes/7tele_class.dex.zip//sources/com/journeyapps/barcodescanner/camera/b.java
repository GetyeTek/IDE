package com.journeyapps.barcodescanner.camera;

import H8.l;
import H8.u;
import H8.v;
import I8.i;
import I8.m;
import android.content.Context;
import android.hardware.Camera;
import android.os.Build;
import android.util.Log;
import com.google.zxing.client.android.AmbientLightManager;
import com.google.zxing.client.android.R;
import com.google.zxing.client.android.camera.open.OpenCameraInterface;
import com.journeyapps.barcodescanner.camera.CameraSettings;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import okhttp3.HttpUrl;

public final class b {
    public static final /* synthetic */ int n = 0;
    public Camera a;
    public Camera.CameraInfo b;
    public I8.a c;
    public AmbientLightManager d;
    public boolean e;
    public String f;
    public CameraSettings g = new CameraSettings();
    public i h;
    public u i;
    public u j;
    public int k = -1;
    public final Context l;
    public final a m;

    public final class a implements Camera.PreviewCallback {
        public l.b a;
        public u b;

        public a() {
        }

        public final void onPreviewFrame(byte[] bArr, Camera camera) {
            u uVar = this.b;
            l.b bVar = this.a;
            if (uVar == null || bVar == null) {
                Log.d("b", "Got preview callback, but no handler or resolution available");
                if (bVar != null) {
                    new Exception("No resolution available");
                    bVar.a();
                }
            } else if (bArr != null) {
                try {
                    byte[] bArr2 = bArr;
                    v vVar = new v(bArr2, uVar.a, uVar.b, camera.getParameters().getPreviewFormat(), b.this.k);
                    if (b.this.b.facing == 1) {
                        vVar.e = true;
                    }
                    synchronized (l.this.h) {
                        l lVar = l.this;
                        if (lVar.g) {
                            lVar.c.obtainMessage(R.id.zxing_decode, vVar).sendToTarget();
                        }
                    }
                } catch (RuntimeException e) {
                    Log.e("b", "Camera preview failed", e);
                    bVar.a();
                } catch (Throwable th) {
                    throw th;
                }
            } else {
                throw new NullPointerException("No preview data received");
            }
        }
    }

    public b(Context context) {
        this.l = context;
        this.m = new a();
    }

    public final int a() {
        int i2;
        int i3 = this.h.b;
        int i4 = 0;
        if (i3 != 0) {
            if (i3 == 1) {
                i4 = 90;
            } else if (i3 == 2) {
                i4 = 180;
            } else if (i3 == 3) {
                i4 = 270;
            }
        }
        Camera.CameraInfo cameraInfo = this.b;
        if (cameraInfo.facing == 1) {
            i2 = (360 - ((cameraInfo.orientation + i4) % 360)) % 360;
        } else {
            i2 = ((cameraInfo.orientation - i4) + 360) % 360;
        }
        Log.i("b", "Camera Display Orientation: " + i2);
        return i2;
    }

    public final void b() {
        if (this.a != null) {
            try {
                int a2 = a();
                this.k = a2;
                this.a.setDisplayOrientation(a2);
            } catch (Exception unused) {
                Log.w("b", "Failed to set rotation.");
            }
            try {
                d(false);
            } catch (Exception unused2) {
                try {
                    d(true);
                } catch (Exception unused3) {
                    Log.w("b", "Camera rejected even safe-mode parameters! No configuration");
                }
            }
            Camera.Size previewSize = this.a.getParameters().getPreviewSize();
            if (previewSize == null) {
                this.j = this.i;
            } else {
                this.j = new u(previewSize.width, previewSize.height);
            }
            this.m.b = this.j;
            return;
        }
        throw new RuntimeException("Camera not open");
    }

    public final void c() {
        Camera open = OpenCameraInterface.open(this.g.a);
        this.a = open;
        if (open != null) {
            int cameraId = OpenCameraInterface.getCameraId(this.g.a);
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            this.b = cameraInfo;
            Camera.getCameraInfo(cameraId, cameraInfo);
            return;
        }
        throw new RuntimeException("Failed to open camera");
    }

    public final void d(boolean z) {
        String str;
        String str2;
        boolean z2;
        Camera.Parameters parameters = this.a.getParameters();
        String str3 = this.f;
        if (str3 == null) {
            this.f = parameters.flatten();
        } else {
            parameters.unflatten(str3);
        }
        if (parameters == null) {
            Log.w("b", "Device error: no camera parameters are available. Proceeding without configuration.");
            return;
        }
        Log.i("b", "Initial camera parameters: " + parameters.flatten());
        if (z) {
            Log.w("b", "In camera config safe mode -- most settings will not be honored");
        }
        CameraSettings.FocusMode focusMode = this.g.b;
        int i2 = a.a;
        List<String> supportedFocusModes = parameters.getSupportedFocusModes();
        int[] iArr = null;
        if (z || focusMode == CameraSettings.FocusMode.AUTO) {
            str = a.a("focus mode", supportedFocusModes, "auto");
        } else if (focusMode == CameraSettings.FocusMode.CONTINUOUS) {
            str = a.a("focus mode", supportedFocusModes, "continuous-picture", "continuous-video", "auto");
        } else if (focusMode == CameraSettings.FocusMode.INFINITY) {
            str = a.a("focus mode", supportedFocusModes, "infinity");
        } else if (focusMode == CameraSettings.FocusMode.MACRO) {
            str = a.a("focus mode", supportedFocusModes, "macro");
        } else {
            str = null;
        }
        if (!z && str == null) {
            str = a.a("focus mode", supportedFocusModes, "macro", "edof");
        }
        if (str != null) {
            if (str.equals(parameters.getFocusMode())) {
                Log.i("CameraConfiguration", "Focus mode already set to ".concat(str));
            } else {
                parameters.setFocusMode(str);
            }
        }
        if (!z) {
            a.b(parameters, false);
            this.g.getClass();
            this.g.getClass();
            this.g.getClass();
        }
        List<Camera.Size> supportedPreviewSizes = parameters.getSupportedPreviewSizes();
        ArrayList arrayList = new ArrayList();
        if (supportedPreviewSizes == null) {
            Camera.Size previewSize = parameters.getPreviewSize();
            if (previewSize != null) {
                arrayList.add(new u(previewSize.width, previewSize.height));
            }
        } else {
            for (Camera.Size next : supportedPreviewSizes) {
                arrayList.add(new u(next.width, next.height));
            }
        }
        if (arrayList.size() == 0) {
            this.i = null;
        } else {
            i iVar = this.h;
            int i3 = this.k;
            if (i3 != -1) {
                if (i3 % 180 != 0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                u uVar = iVar.a;
                if (uVar == null) {
                    uVar = null;
                } else if (z2) {
                    uVar = new u(uVar.b, uVar.a);
                }
                m mVar = iVar.c;
                mVar.getClass();
                if (uVar != null) {
                    Collections.sort(arrayList, new I8.l(mVar, uVar));
                }
                Log.i("m", "Viewfinder size: " + uVar);
                Log.i("m", "Preview in order of preference: " + arrayList);
                u uVar2 = (u) arrayList.get(0);
                this.i = uVar2;
                parameters.setPreviewSize(uVar2.a, uVar2.b);
            } else {
                throw new IllegalStateException("Rotation not calculated yet. Call configure() first.");
            }
        }
        if (Build.DEVICE.equals("glass-1")) {
            List<int[]> supportedPreviewFpsRange = parameters.getSupportedPreviewFpsRange();
            StringBuilder sb2 = new StringBuilder("Supported FPS ranges: ");
            if (supportedPreviewFpsRange == null || supportedPreviewFpsRange.isEmpty()) {
                str2 = HttpUrl.PATH_SEGMENT_ENCODE_SET_URI;
            } else {
                StringBuilder sb3 = new StringBuilder("[");
                Iterator<int[]> it = supportedPreviewFpsRange.iterator();
                while (it.hasNext()) {
                    sb3.append(Arrays.toString(it.next()));
                    if (it.hasNext()) {
                        sb3.append(", ");
                    }
                }
                sb3.append(']');
                str2 = sb3.toString();
            }
            sb2.append(str2);
            Log.i("CameraConfiguration", sb2.toString());
            if (supportedPreviewFpsRange != null && !supportedPreviewFpsRange.isEmpty()) {
                Iterator<int[]> it2 = supportedPreviewFpsRange.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        break;
                    }
                    int[] next2 = it2.next();
                    int i4 = next2[0];
                    int i5 = next2[1];
                    if (i4 >= 10000 && i5 <= 20000) {
                        iArr = next2;
                        break;
                    }
                }
                if (iArr == null) {
                    Log.i("CameraConfiguration", "No suitable FPS range?");
                } else {
                    int[] iArr2 = new int[2];
                    parameters.getPreviewFpsRange(iArr2);
                    if (Arrays.equals(iArr2, iArr)) {
                        Log.i("CameraConfiguration", "FPS range already set to " + Arrays.toString(iArr));
                    } else {
                        Log.i("CameraConfiguration", "Setting FPS range to " + Arrays.toString(iArr));
                        parameters.setPreviewFpsRange(iArr[0], iArr[1]);
                    }
                }
            }
        }
        Log.i("b", "Final camera parameters: " + parameters.flatten());
        this.a.setParameters(parameters);
    }

    public final void e(boolean z) {
        boolean z2;
        String flashMode;
        Camera camera = this.a;
        if (camera != null) {
            try {
                Camera.Parameters parameters = camera.getParameters();
                if (parameters == null || (flashMode = parameters.getFlashMode()) == null || (!"on".equals(flashMode) && !"torch".equals(flashMode))) {
                    z2 = false;
                } else {
                    z2 = true;
                }
                if (z != z2) {
                    I8.a aVar = this.c;
                    if (aVar != null) {
                        aVar.c();
                    }
                    Camera.Parameters parameters2 = this.a.getParameters();
                    a.b(parameters2, z);
                    this.g.getClass();
                    this.a.setParameters(parameters2);
                    I8.a aVar2 = this.c;
                    if (aVar2 != null) {
                        aVar2.a = false;
                        aVar2.b();
                    }
                }
            } catch (RuntimeException e2) {
                Log.e("b", "Failed to set torch", e2);
            }
        }
    }

    public final void f() {
        Camera camera = this.a;
        if (camera != null && !this.e) {
            camera.startPreview();
            this.e = true;
            this.c = new I8.a(this.a, this.g);
            AmbientLightManager ambientLightManager = new AmbientLightManager(this.l, this, this.g);
            this.d = ambientLightManager;
            ambientLightManager.start();
        }
    }
}
