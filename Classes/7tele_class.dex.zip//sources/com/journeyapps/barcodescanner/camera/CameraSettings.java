package com.journeyapps.barcodescanner.camera;

public final class CameraSettings {
    public int a = -1;
    public final FocusMode b = FocusMode.AUTO;

    public enum FocusMode {
        AUTO,
        CONTINUOUS,
        INFINITY,
        MACRO
    }
}
