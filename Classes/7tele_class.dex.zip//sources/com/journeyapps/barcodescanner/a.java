package com.journeyapps.barcodescanner;

import H8.d;
import H8.f;
import H8.g;
import I8.e;
import android.app.AlertDialog;
import android.os.Handler;
import android.util.Log;
import com.google.zxing.client.android.BeepManager;
import com.google.zxing.client.android.InactivityTimer;
import com.google.zxing.client.android.R;
import com.journeyapps.barcodescanner.CameraPreview;

public final class a {
    public static final /* synthetic */ int n = 0;
    public final CaptureActivity a;
    public final DecoratedBarcodeView b;
    public int c = -1;
    public boolean d = false;
    public boolean e = true;
    public String f = "";
    public boolean g = false;
    public final InactivityTimer h;
    public final BeepManager i;
    public final Handler j;
    public boolean k = false;
    public final C0021a l = new C0021a();
    public boolean m;

    /* renamed from: com.journeyapps.barcodescanner.a$a  reason: collision with other inner class name */
    public class C0021a {
        public C0021a() {
        }
    }

    public class b implements CameraPreview.e {
        public b() {
        }

        public final void a() {
        }

        public final void b(Exception exc) {
            a aVar = a.this;
            aVar.b(aVar.a.getString(R.string.zxing_msg_camera_framework_bug));
        }

        public final void c() {
        }

        public final void d() {
            a aVar = a.this;
            if (aVar.k) {
                Log.d("a", "Camera closed; finishing activity");
                aVar.a.finish();
            }
        }

        public final void e() {
        }
    }

    public a(CaptureActivity captureActivity, DecoratedBarcodeView decoratedBarcodeView) {
        b bVar = new b();
        this.m = false;
        this.a = captureActivity;
        this.b = decoratedBarcodeView;
        decoratedBarcodeView.getBarcodeView().j.add(bVar);
        this.j = new Handler();
        this.h = new InactivityTimer(captureActivity, new d(this));
        this.i = new BeepManager(captureActivity);
    }

    public final void a() {
        DecoratedBarcodeView decoratedBarcodeView = this.b;
        e eVar = decoratedBarcodeView.getBarcodeView().a;
        if (eVar == null || eVar.g) {
            this.a.finish();
        } else {
            this.k = true;
        }
        decoratedBarcodeView.a.d();
        this.h.cancel();
    }

    public final void b(String str) {
        CaptureActivity captureActivity = this.a;
        if (!captureActivity.isFinishing() && !this.g && !this.k) {
            if (str.isEmpty()) {
                str = captureActivity.getString(R.string.zxing_msg_camera_framework_bug);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(captureActivity);
            builder.setTitle(captureActivity.getString(R.string.zxing_app_name));
            builder.setMessage(str);
            builder.setPositiveButton(R.string.zxing_button_ok, new f(this));
            builder.setOnCancelListener(new g(this));
            builder.show();
        }
    }
}
