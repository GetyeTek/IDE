package com.journeyapps.barcodescanner;

import H8.u;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.R;
import com.journeyapps.barcodescanner.CameraPreview;
import java.util.ArrayList;
import java.util.Iterator;

public class ViewfinderView extends View {
    public static final int[] l = {0, 64, 128, 192, 255, 192, 128, 64};
    public final Paint a = new Paint(1);
    public int b;
    public final int c;
    public final int d;
    public boolean e;
    public int f;
    public ArrayList g;
    public ArrayList h;
    public CameraPreview i;
    public Rect j;
    public u k;

    public class a implements CameraPreview.e {
        public a() {
        }

        public final void a() {
            ViewfinderView viewfinderView = ViewfinderView.this;
            CameraPreview cameraPreview = viewfinderView.i;
            if (cameraPreview != null) {
                Rect framingRect = cameraPreview.getFramingRect();
                u previewSize = viewfinderView.i.getPreviewSize();
                if (!(framingRect == null || previewSize == null)) {
                    viewfinderView.j = framingRect;
                    viewfinderView.k = previewSize;
                }
            }
            viewfinderView.invalidate();
        }

        public final void b(Exception exc) {
        }

        public final void c() {
        }

        public final void d() {
        }

        public final void e() {
        }
    }

    public ViewfinderView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Resources resources = getResources();
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.zxing_finder);
        this.b = obtainStyledAttributes.getColor(R.styleable.zxing_finder_zxing_viewfinder_mask, resources.getColor(R.color.zxing_viewfinder_mask));
        obtainStyledAttributes.getColor(R.styleable.zxing_finder_zxing_result_view, resources.getColor(R.color.zxing_result_view));
        this.c = obtainStyledAttributes.getColor(R.styleable.zxing_finder_zxing_viewfinder_laser, resources.getColor(R.color.zxing_viewfinder_laser));
        this.d = obtainStyledAttributes.getColor(R.styleable.zxing_finder_zxing_possible_result_points, resources.getColor(R.color.zxing_possible_result_points));
        this.e = obtainStyledAttributes.getBoolean(R.styleable.zxing_finder_zxing_viewfinder_laser_visibility, true);
        obtainStyledAttributes.recycle();
        this.f = 0;
        this.g = new ArrayList(20);
        this.h = new ArrayList(20);
    }

    public final void onDraw(Canvas canvas) {
        u uVar;
        CameraPreview cameraPreview = this.i;
        if (cameraPreview != null) {
            Rect framingRect = cameraPreview.getFramingRect();
            u previewSize = this.i.getPreviewSize();
            if (!(framingRect == null || previewSize == null)) {
                this.j = framingRect;
                this.k = previewSize;
            }
        }
        Rect rect = this.j;
        if (rect != null && (uVar = this.k) != null) {
            int width = getWidth();
            int height = getHeight();
            Paint paint = this.a;
            paint.setColor(this.b);
            float f2 = (float) width;
            Paint paint2 = paint;
            canvas.drawRect(0.0f, 0.0f, f2, (float) rect.top, paint2);
            canvas.drawRect(0.0f, (float) rect.top, (float) rect.left, (float) (rect.bottom + 1), paint2);
            float f3 = f2;
            canvas.drawRect((float) (rect.right + 1), (float) rect.top, f3, (float) (rect.bottom + 1), paint2);
            canvas.drawRect(0.0f, (float) (rect.bottom + 1), f3, (float) height, paint2);
            if (this.e) {
                paint.setColor(this.c);
                paint.setAlpha(l[this.f]);
                this.f = (this.f + 1) % 8;
                int height2 = (rect.height() / 2) + rect.top;
                canvas.drawRect((float) (rect.left + 2), (float) (height2 - 1), (float) (rect.right - 1), (float) (height2 + 2), paint);
            }
            float width2 = ((float) getWidth()) / ((float) uVar.a);
            float height3 = ((float) getHeight()) / ((float) uVar.b);
            boolean isEmpty = this.h.isEmpty();
            int i2 = this.d;
            if (!isEmpty) {
                paint.setAlpha(80);
                paint.setColor(i2);
                Iterator it = this.h.iterator();
                while (it.hasNext()) {
                    ResultPoint resultPoint = (ResultPoint) it.next();
                    canvas.drawCircle((float) ((int) (resultPoint.getX() * width2)), (float) ((int) (resultPoint.getY() * height3)), 3.0f, paint);
                }
                this.h.clear();
            }
            if (!this.g.isEmpty()) {
                paint.setAlpha(160);
                paint.setColor(i2);
                Iterator it2 = this.g.iterator();
                while (it2.hasNext()) {
                    ResultPoint resultPoint2 = (ResultPoint) it2.next();
                    canvas.drawCircle((float) ((int) (resultPoint2.getX() * width2)), (float) ((int) (resultPoint2.getY() * height3)), 6.0f, paint);
                }
                ArrayList arrayList = this.g;
                ArrayList arrayList2 = this.h;
                this.g = arrayList2;
                this.h = arrayList;
                arrayList2.clear();
            }
            postInvalidateDelayed(80, rect.left - 6, rect.top - 6, rect.right + 6, rect.bottom + 6);
        }
    }

    public void setCameraPreview(CameraPreview cameraPreview) {
        this.i = cameraPreview;
        cameraPreview.j.add(new a());
    }

    public void setLaserVisibility(boolean z) {
        this.e = z;
    }

    public void setMaskColor(int i2) {
        this.b = i2;
    }
}
