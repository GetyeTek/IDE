package com.journeyapps.barcodescanner;

import H8.h;
import H8.i;
import H8.j;
import H8.l;
import H8.m;
import I8.e;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.util.AttributeSet;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.R;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.a;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BarcodeView extends CameraPreview {
    public b B = b.a;
    public DecoratedBarcodeView.b C = null;
    public l H;
    public j L;
    public Handler M;
    public final a Q = new a();

    public class a implements Handler.Callback {
        public a() {
        }

        public final boolean handleMessage(Message message) {
            DecoratedBarcodeView.b bVar;
            int i = message.what;
            int i2 = R.id.zxing_decode_succeeded;
            b bVar2 = b.a;
            BarcodeView barcodeView = BarcodeView.this;
            if (i == i2) {
                H8.a aVar = (H8.a) message.obj;
                if (!(aVar == null || (bVar = barcodeView.C) == null || barcodeView.B == bVar2)) {
                    a.C0021a aVar2 = bVar.a;
                    a aVar3 = a.this;
                    aVar3.b.a.d();
                    aVar3.i.playBeepSoundAndVibrate();
                    aVar3.j.post(new h(0, aVar2, aVar));
                    if (barcodeView.B == b.b) {
                        barcodeView.B = bVar2;
                        barcodeView.C = null;
                        barcodeView.l();
                    }
                }
                return true;
            } else if (i == R.id.zxing_decode_failed) {
                return true;
            } else {
                if (i != R.id.zxing_possible_result_points) {
                    return false;
                }
                List<ResultPoint> list = (List) message.obj;
                DecoratedBarcodeView.b bVar3 = barcodeView.C;
                if (!(bVar3 == null || barcodeView.B == bVar2)) {
                    bVar3.getClass();
                    for (ResultPoint resultPoint : list) {
                        ViewfinderView viewfinderView = DecoratedBarcodeView.this.b;
                        if (viewfinderView.g.size() < 20) {
                            viewfinderView.g.add(resultPoint);
                        }
                    }
                }
                return true;
            }
        }
    }

    public enum b {
        ;

        /* access modifiers changed from: public */
        b() {
            throw null;
        }
    }

    public BarcodeView(Context context) {
        super(context);
        j();
    }

    public final void d() {
        l();
        super.d();
    }

    public final void e() {
        k();
    }

    public j getDecoderFactory() {
        return this.L;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, H8.k] */
    /* JADX WARNING: type inference failed for: r2v7, types: [H8.o, H8.i] */
    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, H8.j] */
    public final i i() {
        i iVar;
        if (this.L == null) {
            this.L = new Object();
        }
        ? obj = new Object();
        HashMap hashMap = new HashMap();
        hashMap.put(DecodeHintType.NEED_RESULT_POINT_CALLBACK, obj);
        m mVar = (m) this.L;
        mVar.getClass();
        EnumMap enumMap = new EnumMap(DecodeHintType.class);
        enumMap.putAll(hashMap);
        Map<DecodeHintType, ?> map = mVar.b;
        if (map != null) {
            enumMap.putAll(map);
        }
        Set set = mVar.a;
        if (set != null) {
            enumMap.put(DecodeHintType.POSSIBLE_FORMATS, set);
        }
        String str = mVar.c;
        if (str != null) {
            enumMap.put(DecodeHintType.CHARACTER_SET, str);
        }
        MultiFormatReader multiFormatReader = new MultiFormatReader();
        multiFormatReader.setHints(enumMap);
        int i = mVar.d;
        if (i == 0) {
            iVar = new i(multiFormatReader);
        } else if (i == 1) {
            iVar = new i(multiFormatReader);
        } else if (i != 2) {
            iVar = new i(multiFormatReader);
        } else {
            ? iVar2 = new i(multiFormatReader);
            iVar2.c = true;
            iVar = iVar2;
        }
        obj.a = iVar;
        return iVar;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, H8.j] */
    public final void j() {
        this.L = new Object();
        this.M = new Handler(this.Q);
    }

    public final void k() {
        l();
        if (this.B != b.a && this.g) {
            l lVar = new l(getCameraInstance(), i(), this.M);
            this.H = lVar;
            lVar.f = getPreviewFramingRect();
            l lVar2 = this.H;
            lVar2.getClass();
            C9.b.g();
            HandlerThread handlerThread = new HandlerThread("l");
            lVar2.b = handlerThread;
            handlerThread.start();
            lVar2.c = new Handler(lVar2.b.getLooper(), lVar2.i);
            lVar2.g = true;
            l.b bVar = lVar2.j;
            e eVar = lVar2.a;
            eVar.h.post(new I8.b(0, eVar, bVar));
        }
    }

    public final void l() {
        l lVar = this.H;
        if (lVar != null) {
            lVar.getClass();
            C9.b.g();
            synchronized (lVar.h) {
                lVar.g = false;
                lVar.c.removeCallbacksAndMessages((Object) null);
                lVar.b.quit();
            }
            this.H = null;
        }
    }

    public void setDecoderFactory(j jVar) {
        C9.b.g();
        this.L = jVar;
        l lVar = this.H;
        if (lVar != null) {
            lVar.d = i();
        }
    }

    public BarcodeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        j();
    }

    public BarcodeView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        j();
    }
}
