package com.journeyapps.barcodescanner;

import H8.s;
import H8.t;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.Map;

public class ScanContract extends ActivityResultContract<t, s> {
    @NonNull
    public final Intent createIntent(@NonNull Context context, Object obj) {
        t tVar = (t) obj;
        tVar.getClass();
        Intent intent = new Intent(context, CaptureActivity.class);
        intent.setAction("com.google.zxing.client.android.SCAN");
        intent.addFlags(67108864);
        intent.addFlags(524288);
        for (Map.Entry entry : tVar.a.entrySet()) {
            String str = (String) entry.getKey();
            Object value = entry.getValue();
            if (value instanceof Integer) {
                intent.putExtra(str, (Integer) value);
            } else if (value instanceof Long) {
                intent.putExtra(str, (Long) value);
            } else if (value instanceof Boolean) {
                intent.putExtra(str, (Boolean) value);
            } else if (value instanceof Double) {
                intent.putExtra(str, (Double) value);
            } else if (value instanceof Float) {
                intent.putExtra(str, (Float) value);
            } else if (value instanceof Bundle) {
                intent.putExtra(str, (Bundle) value);
            } else if (value instanceof int[]) {
                intent.putExtra(str, (int[]) value);
            } else if (value instanceof long[]) {
                intent.putExtra(str, (long[]) value);
            } else if (value instanceof boolean[]) {
                intent.putExtra(str, (boolean[]) value);
            } else if (value instanceof double[]) {
                intent.putExtra(str, (double[]) value);
            } else if (value instanceof float[]) {
                intent.putExtra(str, (float[]) value);
            } else if (value instanceof String[]) {
                intent.putExtra(str, (String[]) value);
            } else {
                intent.putExtra(str, value.toString());
            }
        }
        return intent;
    }

    public final Object parseResult(int i, @Nullable Intent intent) {
        Integer valueOf;
        if (i != -1) {
            return new s((String) null, (String) null, (byte[]) null, (Integer) null, (String) null, (String) null, intent);
        }
        String stringExtra = intent.getStringExtra("SCAN_RESULT");
        String stringExtra2 = intent.getStringExtra("SCAN_RESULT_FORMAT");
        byte[] byteArrayExtra = intent.getByteArrayExtra("SCAN_RESULT_BYTES");
        int intExtra = intent.getIntExtra("SCAN_RESULT_ORIENTATION", Integer.MIN_VALUE);
        if (intExtra == Integer.MIN_VALUE) {
            valueOf = null;
        } else {
            valueOf = Integer.valueOf(intExtra);
        }
        return new s(stringExtra, stringExtra2, byteArrayExtra, valueOf, intent.getStringExtra("SCAN_RESULT_ERROR_CORRECTION_LEVEL"), intent.getStringExtra("SCAN_RESULT_IMAGE_PATH"), intent);
    }
}
