package com.huawei.security.localauthentication;

public final class R$string {
    public static final int app_name = 2132017485;

    private R$string() {
    }
}
