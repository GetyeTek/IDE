package com.huawei.webview.repository;

import com.huawei.digitalpayment.customer.httplib.response.GetH5AccessTokenResp;
import com.huawei.http.b;

public class H5RequestPinRepository extends b<GetH5AccessTokenResp, GetH5AccessTokenResp> {
    public final String getApiPath() {
        return "v1/h5GetAccessToken";
    }
}
