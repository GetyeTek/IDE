package com.huawei.webview.repository;

import com.huawei.digitalpayment.customer.httplib.response.ChapaRetryResp;
import com.huawei.http.b;

public class ChapaRetryRepository extends b<ChapaRetryResp, ChapaRetryResp> {
    public final String getApiPath() {
        return "v1/ethiopia/chapa/retryOrder";
    }
}
