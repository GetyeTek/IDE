package com.huawei.webview;

import S1.d;
import V1.h;
import W2.n;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import androidx.camera.video.e;
import androidx.fragment.app.FragmentActivity;
import com.blankj.utilcode.util.k;
import com.google.android.gms.measurement.internal.c;
import com.google.gson.reflect.TypeToken;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class b {
    public final WebViewActivity a;
    public final FragmentActivity b;
    public final Map<String, List<String>> c;

    public class a extends TypeToken<Map<String, List<String>>> {
    }

    /* renamed from: com.huawei.webview.b$b  reason: collision with other inner class name */
    public static class C0020b extends Exception {
        private static final long serialVersionUID = 6648993793168623146L;
    }

    public b(FragmentActivity fragmentActivity) {
        this.b = fragmentActivity;
        if (fragmentActivity instanceof WebViewActivity) {
            this.a = (WebViewActivity) fragmentActivity;
        }
        String e = n.b("webview").e("h5InterfacePermission");
        h.b();
        if (!TextUtils.isEmpty(e)) {
            try {
                this.c = (Map) k.b(e, new TypeToken().getType());
            } catch (Exception e2) {
                e2.getMessage();
                h.b();
            }
        }
    }

    public final boolean a(String str) {
        try {
            this.a.i.a.b.getUrl();
            Map<String, List<String>> map = this.c;
            for (String str2 : map.keySet()) {
                if (map.get(str2).contains(str)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            e.getMessage();
            h.b();
            return false;
        }
    }

    /* JADX WARNING: type inference failed for: r0v5, types: [android.webkit.ValueCallback, java.lang.Object] */
    public final void b(String str) {
        if (!TextUtils.isEmpty(str)) {
            HashMap a2 = c.a("resultCode", "1", "result", "fail");
            a2.put("message", "No permission");
            String b2 = d.b("javascript:", str, "('", k.d(a2).replaceAll("'", "\\\\'"), "');");
            ? obj = new Object();
            WebView webView = this.a.i.a.b;
            webView.post(new f(webView, b2, obj));
        }
    }

    @JavascriptInterface
    @Deprecated
    public void closeWebView() {
        FragmentActivity fragmentActivity = this.b;
        if (fragmentActivity != null && !fragmentActivity.isDestroyed()) {
            fragmentActivity.finish();
        }
    }

    @JavascriptInterface
    public void disableKeyBack(boolean z) {
        h.b();
        WebViewActivity webViewActivity = this.a;
        if (webViewActivity != null) {
            webViewActivity.f = z;
        }
    }

    @JavascriptInterface
    public void evaluate(String str) {
        new Handler(Looper.getMainLooper()).post(new C1.k(2, this, str));
    }

    @JavascriptInterface
    @Deprecated
    public void shareLocal(String str) {
        if (!a("js_fun_shareLocal")) {
            h.b();
        } else {
            F8.d.b(this.b, str);
        }
    }

    @JavascriptInterface
    @Deprecated
    public void shareSocialNetwork(String str, String str2) {
        if (!a("js_fun_shareSocialNetwork")) {
            h.b();
            return;
        }
        boolean equals = "default".equals(str2);
        FragmentActivity fragmentActivity = this.b;
        if (equals) {
            fragmentActivity.runOnUiThread(new c2.b(1, this, str));
        } else {
            fragmentActivity.runOnUiThread(new e(this, str, 2, str2));
        }
    }
}
