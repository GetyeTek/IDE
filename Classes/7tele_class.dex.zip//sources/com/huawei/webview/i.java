package com.huawei.webview;

import T1.b;
import V1.h;
import android.net.Uri;
import android.text.TextUtils;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import androidx.annotation.RequiresApi;
import com.huawei.digitalpayment.customer.login_module.widget.H5PicSelectDialog;
import com.huawei.digitalpayment.customer.viewlib.view.dialog.PicSelectDialog;

public final class i extends WebChromeClient {
    public final /* synthetic */ WebViewFragment a;

    public class a implements PicSelectDialog.d {
        public final /* synthetic */ H5PicSelectDialog a;

        public a(H5PicSelectDialog h5PicSelectDialog) {
            this.a = h5PicSelectDialog;
        }

        public final void a() {
            WebViewFragment webViewFragment = i.this.a;
            T1.a.a(2, (b) null, webViewFragment.requireActivity(), webViewFragment.h);
            this.a.dismiss();
        }

        public final void b() {
            WebViewFragment webViewFragment = i.this.a;
            T1.a.a(1, (b) null, webViewFragment.requireActivity(), webViewFragment.h);
            this.a.dismiss();
        }

        public final void cancel() {
            ValueCallback<Uri[]> valueCallback = i.this.a.d;
            if (valueCallback != null) {
                valueCallback.onReceiveValue((Object) null);
            }
        }
    }

    public i(WebViewFragment webViewFragment) {
        this.a = webViewFragment;
    }

    public final void onGeolocationPermissionsShowPrompt(String str, GeolocationPermissions.Callback callback) {
        callback.invoke(str, true, false);
        super.onGeolocationPermissionsShowPrompt(str, callback);
    }

    @RequiresApi(api = 21)
    public final void onPermissionRequest(PermissionRequest permissionRequest) {
        c cVar = this.a.f;
        cVar.getClass();
        cVar.a.runOnUiThread(new androidx.camera.core.i(1, cVar, permissionRequest));
    }

    public final void onProgressChanged(WebView webView, int i) {
        super.onProgressChanged(webView, i);
        h.b();
        WebViewFragment webViewFragment = this.a;
        if (i == 100) {
            webViewFragment.a.a.setVisibility(8);
            return;
        }
        webViewFragment.a.a.setVisibility(0);
        webViewFragment.a.a.setProgress(i);
    }

    public final void onReceivedTitle(WebView webView, String str) {
        super.onReceivedTitle(webView, str);
        e eVar = this.a.e;
        if (eVar != null) {
            WebViewActivity webViewActivity = eVar.a;
            if (webViewActivity.h != null && !TextUtils.isEmpty(str) && !str.startsWith("http")) {
                String str2 = eVar.b;
                if (str2 == null || str2.length() == 0) {
                    webViewActivity.h.setText(str);
                }
            }
        }
    }

    public final boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
        WebViewFragment webViewFragment = this.a;
        webViewFragment.d = valueCallback;
        H5PicSelectDialog h5PicSelectDialog = new H5PicSelectDialog();
        h5PicSelectDialog.show(webViewFragment.requireActivity().getSupportFragmentManager(), "");
        h5PicSelectDialog.d = new a(h5PicSelectDialog);
        return true;
    }
}
