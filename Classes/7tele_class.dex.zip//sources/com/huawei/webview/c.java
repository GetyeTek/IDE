package com.huawei.webview;

import android.webkit.PermissionRequest;
import androidx.fragment.app.FragmentActivity;

public final class c {
    public FragmentActivity a;
    public PermissionRequest b;
}
