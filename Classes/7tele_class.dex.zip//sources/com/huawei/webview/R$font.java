package com.huawei.webview;

public final class R$font {
    public static final int poppins_light = 2131296256;
    public static final int poppins_medium = 2131296257;

    private R$font() {
    }
}
