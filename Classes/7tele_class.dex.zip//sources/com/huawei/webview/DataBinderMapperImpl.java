package com.huawei.webview;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.camera.view.l;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.webview.databinding.ActivityWebviewBinding;
import com.huawei.webview.databinding.FragmentWebviewBinding;
import com.huawei.webview.databinding.FragmentWebviewBindingImpl;
import com.huawei.webview.databinding.LayoutWebviewBindingImpl;
import com.huawei.webview.databinding.WebviewToolbarBinding;
import com.huawei.webview.databinding.WebviewToolbarBindingImpl;
import com.huawei.webview.view.TermsWebView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(4);
            a = hashMap;
            hashMap.put("layout/activity_webview_0", Integer.valueOf(R$layout.activity_webview));
            hashMap.put("layout/fragment_webview_0", Integer.valueOf(R$layout.fragment_webview));
            hashMap.put("layout/layout_webview_0", Integer.valueOf(R$layout.layout_webview));
            hashMap.put("layout/webview_toolbar_0", Integer.valueOf(R$layout.webview_toolbar));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(4);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_webview, 1);
        sparseIntArray.put(R$layout.fragment_webview, 2);
        sparseIntArray.put(R$layout.layout_webview, 3);
        sparseIntArray.put(R$layout.webview_toolbar, 4);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(9);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.login_module.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i) {
        int i2 = a.get(i);
        if (i2 > 0) {
            Object tag = view.getTag();
            if (tag == null) {
                throw new RuntimeException("view must have a tag");
            } else if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 3) {
                        if (i2 == 4) {
                            if ("layout/webview_toolbar_0".equals(tag)) {
                                Object[] mapBindings = ViewDataBinding.mapBindings(dataBindingComponent, view, 4, (ViewDataBinding.IncludedLayouts) null, WebviewToolbarBindingImpl.c);
                                ImageView imageView = (ImageView) mapBindings[1];
                                ImageView imageView2 = (ImageView) mapBindings[3];
                                TextView textView = (TextView) mapBindings[2];
                                ViewDataBinding webviewToolbarBinding = new WebviewToolbarBinding(dataBindingComponent, view, (ConstraintLayout) mapBindings[0]);
                                webviewToolbarBinding.b = -1;
                                webviewToolbarBinding.a.setTag((Object) null);
                                webviewToolbarBinding.setRootTag(view);
                                webviewToolbarBinding.invalidateAll();
                                return webviewToolbarBinding;
                            }
                            throw new IllegalArgumentException(l.a(tag, "The tag for webview_toolbar is invalid. Received: "));
                        }
                    } else if ("layout/layout_webview_0".equals(tag)) {
                        Object[] mapBindings2 = ViewDataBinding.mapBindings(dataBindingComponent, view, 3, (ViewDataBinding.IncludedLayouts) null, LayoutWebviewBindingImpl.b);
                        ProgressBar progressBar = (ProgressBar) mapBindings2[1];
                        TermsWebView termsWebView = (TermsWebView) mapBindings2[2];
                        ViewDataBinding viewDataBinding = new ViewDataBinding(dataBindingComponent, view, 0);
                        viewDataBinding.a = -1;
                        ((LinearLayout) mapBindings2[0]).setTag((Object) null);
                        viewDataBinding.setRootTag(view);
                        viewDataBinding.invalidateAll();
                        return viewDataBinding;
                    } else {
                        throw new IllegalArgumentException(l.a(tag, "The tag for layout_webview is invalid. Received: "));
                    }
                } else if ("layout/fragment_webview_0".equals(tag)) {
                    Object[] mapBindings3 = ViewDataBinding.mapBindings(dataBindingComponent, view, 3, (ViewDataBinding.IncludedLayouts) null, FragmentWebviewBindingImpl.d);
                    ViewDataBinding fragmentWebviewBinding = new FragmentWebviewBinding(dataBindingComponent, view, (ProgressBar) mapBindings3[2], (WebView) mapBindings3[1]);
                    fragmentWebviewBinding.c = -1;
                    ((ConstraintLayout) mapBindings3[0]).setTag((Object) null);
                    fragmentWebviewBinding.setRootTag(view);
                    fragmentWebviewBinding.invalidateAll();
                    return fragmentWebviewBinding;
                } else {
                    throw new IllegalArgumentException(l.a(tag, "The tag for fragment_webview is invalid. Received: "));
                }
            } else if ("layout/activity_webview_0".equals(tag)) {
                ViewDataBinding activityWebviewBinding = new ActivityWebviewBinding(dataBindingComponent, view, (LinearLayout) ViewDataBinding.mapBindings(dataBindingComponent, view, 1, (ViewDataBinding.IncludedLayouts) null, (SparseIntArray) null)[0]);
                activityWebviewBinding.b = -1;
                activityWebviewBinding.a.setTag((Object) null);
                activityWebviewBinding.setRootTag(view);
                activityWebviewBinding.invalidateAll();
                return activityWebviewBinding;
            } else {
                throw new IllegalArgumentException(l.a(tag, "The tag for activity_webview is invalid. Received: "));
            }
        }
        return null;
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
