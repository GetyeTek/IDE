package com.huawei.webview;

import G8.a;
import android.net.Uri;
import android.text.TextUtils;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity;
import com.huawei.digitalpayment.customer.baselib.databinding.LayoutTransparentBinding;
import com.huawei.digitalpayment.customer.httplib.request.H5CheckoutRequest;
import com.huawei.digitalpayment.customer.httplib.response.GetH5AccessTokenResp;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;

@Route(path = "/webViewModule/webViewDispatcher")
public class WebDispatcherActivity extends BaseTitleActivity implements a {
    public PayLoadingDialog i;
    public Uri j;
    @Autowired(name = "appId")
    String mAppId;
    @Autowired(name = "from")
    String mFrom;
    @Autowired(name = "tradeType")
    String mTradeType;
    @Autowired(name = "url")
    String mUrl;
    @Autowired(name = "pawParams")
    H5CheckoutRequest pawParams;
    @Autowired(name = "prepayId")
    String prepayId;
    @Autowired(name = "rawRequest")
    String rawRequest;
    @Autowired(name = "scheme_execute_key")
    String urlString;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: P2.a} */
    /* JADX WARNING: type inference failed for: r1v4, types: [A8.c, C8.d] */
    /* JADX WARNING: type inference failed for: r1v43, types: [A8.c, C8.d] */
    /* JADX WARNING: type inference failed for: r1v46, types: [A8.c, C8.d] */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Can't wrap try/catch for region: R(9:128|(1:130)|131|132|133|(1:135)|136|137|(1:139)) */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x011a, code lost:
        if (r6.equals("browser") == false) goto L_0x0107;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:136:0x0306 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x0310 A[Catch:{ Exception -> 0x031a }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void D0() {
        /*
            r16 = this;
            r0 = r16
            r1 = 2
            r2 = -1
            r4 = 1
            java.lang.String r5 = r0.urlString
            boolean r5 = android.text.TextUtils.isEmpty(r5)
            java.lang.String r6 = "from"
            if (r5 == 0) goto L_0x006b
            java.lang.String r1 = r0.mAppId
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 != 0) goto L_0x001f
            java.lang.String r1 = r0.mFrom
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 != 0) goto L_0x005f
        L_0x001f:
            java.lang.String r1 = "signOD"
            java.lang.String r2 = r0.mFrom
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x005f
            java.lang.String r1 = "viewOD"
            java.lang.String r2 = r0.mFrom
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0034
            goto L_0x005f
        L_0x0034:
            n.a r1 = n.a.b()
            r1.getClass()
            java.lang.String r1 = "/webViewModule/webview"
            com.alibaba.android.arouter.facade.Postcard r1 = n.a.a(r1)
            java.lang.String r2 = "url"
            java.lang.String r3 = r0.mUrl
            com.alibaba.android.arouter.facade.Postcard r1 = r1.withString(r2, r3)
            java.lang.String r2 = "appId"
            java.lang.String r3 = r0.mAppId
            com.alibaba.android.arouter.facade.Postcard r1 = r1.withString(r2, r3)
            java.lang.String r2 = r0.mFrom
            com.alibaba.android.arouter.facade.Postcard r1 = r1.withString(r6, r2)
            r1.navigation()
            r16.finish()
            goto L_0x031d
        L_0x005f:
            C8.d r1 = new C8.d
            r1.<init>(r0)
            java.lang.String r2 = r0.mAppId
            r1.b(r2)
            goto L_0x031d
        L_0x006b:
            java.lang.String r5 = r0.urlString
            boolean r5 = android.text.TextUtils.isEmpty(r5)
            if (r5 == 0) goto L_0x0075
            goto L_0x031d
        L_0x0075:
            r5 = 0
            java.lang.String r7 = r0.urlString     // Catch:{ Exception -> 0x007f }
            android.net.Uri r7 = android.net.Uri.parse(r7)     // Catch:{ Exception -> 0x007f }
            r0.j = r7     // Catch:{ Exception -> 0x007f }
            goto L_0x0081
        L_0x007f:
            r0.j = r5
        L_0x0081:
            android.net.Uri r7 = r0.j
            if (r7 != 0) goto L_0x0087
            goto L_0x031d
        L_0x0087:
            java.lang.String r7 = r7.getScheme()
            boolean r8 = android.text.TextUtils.isEmpty(r7)
            if (r8 == 0) goto L_0x0093
            goto L_0x031d
        L_0x0093:
            java.util.Locale r8 = java.util.Locale.ENGLISH
            java.lang.String r7 = r7.toLowerCase(r8)
            r7.getClass()
            int r8 = r7.hashCode()
            switch(r8) {
                case -1354573786: goto L_0x00bb;
                case -1008225784: goto L_0x00b0;
                case -505296440: goto L_0x00a5;
                default: goto L_0x00a3;
            }
        L_0x00a3:
            r7 = -1
            goto L_0x00c5
        L_0x00a5:
            java.lang.String r8 = "merchant"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00ae
            goto L_0x00a3
        L_0x00ae:
            r7 = 2
            goto L_0x00c5
        L_0x00b0:
            java.lang.String r8 = "nativefun"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00b9
            goto L_0x00a3
        L_0x00b9:
            r7 = 1
            goto L_0x00c5
        L_0x00bb:
            java.lang.String r8 = "coupon"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00c4
            goto L_0x00a3
        L_0x00c4:
            r7 = 0
        L_0x00c5:
            switch(r7) {
                case 0: goto L_0x02cb;
                case 1: goto L_0x00e9;
                case 2: goto L_0x00cd;
                default: goto L_0x00c8;
            }
        L_0x00c8:
            r16.finish()
            goto L_0x031d
        L_0x00cd:
            android.net.Uri r1 = r0.j
            java.lang.String r1 = r1.getHost()
            r0.mAppId = r1
            android.net.Uri r1 = r0.j
            java.lang.String r1 = r1.getQueryParameter(r6)
            r0.mFrom = r1
            C8.d r1 = new C8.d
            r1.<init>(r0)
            java.lang.String r2 = r0.mAppId
            r1.b(r2)
            goto L_0x031d
        L_0x00e9:
            android.net.Uri r6 = r0.j
            if (r6 != 0) goto L_0x00ef
            goto L_0x02c7
        L_0x00ef:
            java.lang.String r6 = r6.getHost()
            boolean r7 = android.text.TextUtils.isEmpty(r6)
            if (r7 == 0) goto L_0x00fb
            goto L_0x02c7
        L_0x00fb:
            r6.getClass()
            java.lang.String r7 = "execute="
            int r8 = r6.hashCode()
            switch(r8) {
                case -732377866: goto L_0x0128;
                case 109400031: goto L_0x011d;
                case 150940456: goto L_0x0114;
                case 1224424441: goto L_0x0109;
                default: goto L_0x0107;
            }
        L_0x0107:
            r1 = -1
            goto L_0x0132
        L_0x0109:
            java.lang.String r1 = "webview"
            boolean r1 = r6.equals(r1)
            if (r1 != 0) goto L_0x0112
            goto L_0x0107
        L_0x0112:
            r1 = 3
            goto L_0x0132
        L_0x0114:
            java.lang.String r8 = "browser"
            boolean r6 = r6.equals(r8)
            if (r6 != 0) goto L_0x0132
            goto L_0x0107
        L_0x011d:
            java.lang.String r1 = "share"
            boolean r1 = r6.equals(r1)
            if (r1 != 0) goto L_0x0126
            goto L_0x0107
        L_0x0126:
            r1 = 1
            goto L_0x0132
        L_0x0128:
            java.lang.String r1 = "article"
            boolean r1 = r6.equals(r1)
            if (r1 != 0) goto L_0x0131
            goto L_0x0107
        L_0x0131:
            r1 = 0
        L_0x0132:
            switch(r1) {
                case 0: goto L_0x02a9;
                case 1: goto L_0x0190;
                case 2: goto L_0x015e;
                case 3: goto L_0x0137;
                default: goto L_0x0135;
            }
        L_0x0135:
            goto L_0x02c7
        L_0x0137:
            java.lang.String r1 = r0.urlString
            int r1 = r1.indexOf(r7)
            if (r1 < 0) goto L_0x02c7
            java.lang.String r2 = r0.urlString
            int r2 = r2.length()
            int r2 = r2 + -8
            if (r1 <= r2) goto L_0x014b
            goto L_0x02c7
        L_0x014b:
            java.lang.String r2 = r0.urlString
            int r1 = r1 + 8
            java.lang.String r1 = r2.substring(r1)
            boolean r2 = android.text.TextUtils.isEmpty(r1)
            if (r2 != 0) goto L_0x02c7
            o0.b.d(r0, r1, r5, r5)
            goto L_0x02c7
        L_0x015e:
            java.lang.String r1 = r0.urlString
            int r1 = r1.indexOf(r7)
            if (r1 < 0) goto L_0x02c7
            java.lang.String r2 = r0.urlString
            int r2 = r2.length()
            int r2 = r2 + -8
            if (r1 <= r2) goto L_0x0172
            goto L_0x02c7
        L_0x0172:
            java.lang.String r2 = r0.urlString
            int r1 = r1 + 8
            java.lang.String r1 = r2.substring(r1)
            boolean r2 = android.text.TextUtils.isEmpty(r1)
            if (r2 != 0) goto L_0x02c7
            android.net.Uri r1 = android.net.Uri.parse(r1)
            android.content.Intent r2 = new android.content.Intent
            java.lang.String r3 = "android.intent.action.VIEW"
            r2.<init>(r3, r1)
            r0.startActivity(r2)
            goto L_0x02c7
        L_0x0190:
            android.net.Uri r1 = r0.j
            java.lang.String r2 = "share_url"
            java.lang.String r1 = r1.getQueryParameter(r2)
            android.net.Uri r2 = r0.j
            java.lang.String r6 = "enable_share_url"
            java.lang.String r2 = r2.getQueryParameter(r6)
            android.net.Uri r6 = r0.j
            java.lang.String r7 = "disable_share_app"
            java.lang.String r6 = r6.getQueryParameter(r7)
            boolean r7 = android.text.TextUtils.isEmpty(r1)
            if (r7 == 0) goto L_0x01b0
            goto L_0x02c7
        L_0x01b0:
            boolean r7 = android.text.TextUtils.isEmpty(r2)
            java.lang.String r8 = ","
            if (r7 != 0) goto L_0x01bd
            java.lang.String[] r2 = r2.split(r8)
            goto L_0x01be
        L_0x01bd:
            r2 = r5
        L_0x01be:
            boolean r7 = android.text.TextUtils.isEmpty(r6)
            if (r7 != 0) goto L_0x01c8
            java.lang.String[] r5 = r6.split(r8)
        L_0x01c8:
            android.content.Intent r6 = new android.content.Intent
            java.lang.String r7 = "android.intent.action.SEND"
            r6.<init>(r7)
            java.lang.String r8 = "text/plain"
            r6.setType(r8)
            android.content.pm.PackageManager r9 = r16.getPackageManager()
            r10 = 65536(0x10000, float:9.18355E-41)
            java.util.List r6 = r9.queryIntentActivities(r6, r10)
            boolean r9 = r6.isEmpty()
            if (r9 != 0) goto L_0x02c7
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            java.util.Iterator r6 = r6.iterator()
        L_0x01ed:
            boolean r10 = r6.hasNext()
            if (r10 == 0) goto L_0x0279
            java.lang.Object r10 = r6.next()
            android.content.pm.ResolveInfo r10 = (android.content.pm.ResolveInfo) r10
            android.content.Intent r11 = new android.content.Intent
            r11.<init>(r7)
            r11.setType(r8)
            android.content.pm.ActivityInfo r12 = r10.activityInfo
            java.lang.String r13 = r12.packageName
            V1.h.b()
            java.lang.String r13 = "android.intent.extra.TEXT"
            r11.putExtra(r13, r1)
            java.lang.String r13 = r12.packageName
            r11.setPackage(r13)
            java.lang.String r12 = r12.packageName
            android.content.pm.ActivityInfo r13 = r10.activityInfo
            java.lang.String r13 = r13.name
            r11.setClassName(r12, r13)
            android.content.pm.PackageManager r12 = r16.getPackageManager()
            android.content.pm.ActivityInfo r13 = r10.activityInfo
            android.content.pm.ApplicationInfo r13 = r13.applicationInfo
            java.lang.CharSequence r13 = r13.loadLabel(r12)
            r13.toString()
            V1.h.b()
            if (r2 == 0) goto L_0x024f
            int r13 = r2.length
            if (r13 <= 0) goto L_0x024f
            int r13 = r2.length
            r14 = 0
        L_0x0234:
            if (r14 >= r13) goto L_0x01ed
            r15 = r2[r14]
            android.content.pm.ActivityInfo r3 = r10.activityInfo
            android.content.pm.ApplicationInfo r3 = r3.applicationInfo
            java.lang.CharSequence r3 = r3.loadLabel(r12)
            java.lang.String r3 = r3.toString()
            boolean r3 = r3.equals(r15)
            if (r3 == 0) goto L_0x024d
            r9.add(r11)
        L_0x024d:
            int r14 = r14 + r4
            goto L_0x0234
        L_0x024f:
            if (r5 == 0) goto L_0x0274
            int r3 = r5.length
            if (r3 <= 0) goto L_0x0274
            int r3 = r5.length
            r13 = 0
        L_0x0256:
            if (r13 >= r3) goto L_0x026f
            r14 = r5[r13]
            android.content.pm.ActivityInfo r15 = r10.activityInfo
            android.content.pm.ApplicationInfo r15 = r15.applicationInfo
            java.lang.CharSequence r15 = r15.loadLabel(r12)
            java.lang.String r15 = r15.toString()
            boolean r14 = r15.equals(r14)
            if (r14 == 0) goto L_0x026d
            goto L_0x01ed
        L_0x026d:
            int r13 = r13 + r4
            goto L_0x0256
        L_0x026f:
            r9.add(r11)
            goto L_0x01ed
        L_0x0274:
            r9.add(r11)
            goto L_0x01ed
        L_0x0279:
            int r1 = r9.size()
            if (r1 != 0) goto L_0x0285
            int r1 = com.huawei.webview.R$string.designstandard_the_shared_application_component_could_not_be_found
            V1.k.a(r1)
            goto L_0x02c7
        L_0x0285:
            r1 = 0
            java.lang.Object r2 = r9.remove(r1)
            android.content.Intent r2 = (android.content.Intent) r2
            java.lang.String r3 = "Share"
            android.content.Intent r2 = android.content.Intent.createChooser(r2, r3)
            android.os.Parcelable[] r1 = new android.os.Parcelable[r1]
            java.lang.Object[] r1 = r9.toArray(r1)
            android.os.Parcelable[] r1 = (android.os.Parcelable[]) r1
            java.lang.String r3 = "android.intent.extra.INITIAL_INTENTS"
            r2.putExtra(r3, r1)
            r0.startActivity(r2)     // Catch:{ Exception -> 0x02a3 }
            goto L_0x02c7
        L_0x02a3:
            int r1 = com.huawei.webview.R$string.designstandard_the_shared_application_component_could_not_be_found
            V1.k.a(r1)
            goto L_0x02c7
        L_0x02a9:
            java.lang.String r1 = r0.urlString
            int r1 = r1.indexOf(r7)
            if (r1 < 0) goto L_0x02c7
            java.lang.String r2 = r0.urlString
            int r2 = r2.length()
            int r2 = r2 + -8
            if (r1 <= r2) goto L_0x02bc
            goto L_0x02c7
        L_0x02bc:
            java.lang.String r2 = r0.urlString
            int r1 = r1 + 8
            java.lang.String r1 = r2.substring(r1)
            android.text.TextUtils.isEmpty(r1)
        L_0x02c7:
            r16.finish()
            goto L_0x031d
        L_0x02cb:
            android.net.Uri r1 = r0.j
            if (r1 != 0) goto L_0x02d0
            goto L_0x031a
        L_0x02d0:
            com.huawei.digitalpayment.customer.cache.BasicConfig r2 = com.huawei.digitalpayment.customer.cache.BasicConfig.getInstance()     // Catch:{ Exception -> 0x031a }
            com.huawei.digitalpayment.customer.httplib.bean.MerchantAppIdBean r2 = r2.getMerchantAppIdConfig()     // Catch:{ Exception -> 0x031a }
            if (r2 != 0) goto L_0x02db
            goto L_0x031a
        L_0x02db:
            com.huawei.digitalpayment.customer.httplib.bean.MerchantAppIdBean$FeedbackBean r2 = r2.getCoupon()     // Catch:{ Exception -> 0x031a }
            if (r2 != 0) goto L_0x02e2
            goto L_0x031a
        L_0x02e2:
            java.lang.String r3 = r2.getAppId()     // Catch:{ Exception -> 0x031a }
            boolean r3 = android.text.TextUtils.isEmpty(r3)     // Catch:{ Exception -> 0x031a }
            if (r3 != 0) goto L_0x02f2
            java.lang.String r3 = r2.getAppId()     // Catch:{ Exception -> 0x031a }
            r0.mAppId = r3     // Catch:{ Exception -> 0x031a }
        L_0x02f2:
            java.lang.String r2 = r2.getH5Url()     // Catch:{ Exception -> 0x031a }
            java.lang.String r3 = "%couponInventoryId%"
            java.lang.String r1 = r1.getHost()     // Catch:{ Exception -> 0x0306 }
            boolean r4 = r2.contains(r3)     // Catch:{ Exception -> 0x0306 }
            if (r4 == 0) goto L_0x0306
            java.lang.String r2 = r2.replace(r3, r1)     // Catch:{ Exception -> 0x0306 }
        L_0x0306:
            r0.mUrl = r2     // Catch:{ Exception -> 0x031a }
            java.lang.String r1 = r0.mAppId     // Catch:{ Exception -> 0x031a }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ Exception -> 0x031a }
            if (r1 != 0) goto L_0x031a
            C8.d r1 = new C8.d     // Catch:{ Exception -> 0x031a }
            r1.<init>(r0)     // Catch:{ Exception -> 0x031a }
            java.lang.String r2 = r0.mAppId     // Catch:{ Exception -> 0x031a }
            r1.b(r2)     // Catch:{ Exception -> 0x031a }
        L_0x031a:
            r16.finish()
        L_0x031d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.webview.WebDispatcherActivity.D0():void");
    }

    public final void G(String str) {
        this.i.dismiss();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.webview.WebDispatcherActivity, com.huawei.digitalpayment.customer.baselib.base.BaseTitleActivity, android.app.Activity] */
    public final void G0() {
        WebDispatcherActivity.super.G0();
        f.g(getWindow());
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.webview.WebDispatcherActivity, android.app.Activity] */
    public final ViewBinding K0() {
        return LayoutTransparentBinding.a(getLayoutInflater());
    }

    public final boolean M0() {
        return true;
    }

    public final void V(String str) {
        PayLoadingDialog payLoadingDialog = new PayLoadingDialog();
        this.i = payLoadingDialog;
        payLoadingDialog.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [com.huawei.webview.WebDispatcherActivity, android.app.Activity] */
    public final void g(GetH5AccessTokenResp getH5AccessTokenResp) {
        String accessToken = getH5AccessTokenResp.getAccessToken();
        String tradeType = getH5AccessTokenResp.getTradeType();
        String url = getH5AccessTokenResp.getUrl();
        if (this.j == null) {
            try {
                this.j = Uri.parse(this.urlString);
            } catch (Exception unused) {
            }
        }
        if (TextUtils.isEmpty(accessToken)) {
            finish();
            return;
        }
        if (TextUtils.isEmpty(this.mUrl)) {
            this.mUrl = url;
        }
        if (!TextUtils.isEmpty(tradeType)) {
            this.mTradeType = tradeType;
        }
        n.a.b().getClass();
        n.a.a("/webViewModule/webview").withString("accessToken", accessToken).withString("tradeType", this.mTradeType).withString("url", this.mUrl).withString("appId", this.mAppId).withString("prepayId", this.prepayId).withString("rawRequest", this.rawRequest).withString("from", this.mFrom).navigation();
        finish();
    }
}
