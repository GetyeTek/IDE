package com.huawei.webview;

import A8.C0054c;
import G8.a;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.h;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.base.BaseActivity;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseMvvmActivity;
import com.huawei.digitalpayment.customer.httplib.response.GetH5AccessTokenResp;
import com.huawei.digitalpayment.customer.viewlib.view.PayLoadingDialog;
import java.util.HashMap;
import o0.b;

@Route(path = "/webViewModule/merchantDispatcher")
public class MerchantDispatcherActivity extends BaseActivity implements a {
    public PayLoadingDialog d;
    public String e;
    @Autowired(name = "scheme_execute_key")
    String urlString;

    public final ViewBinding C0() {
        return null;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [A8.c, C8.d] */
    public final void D0() {
        if (TextUtils.isEmpty(this.urlString)) {
            finish();
        }
        try {
            String host = Uri.parse(this.urlString).getHost();
            this.e = host;
            new C0054c(this).b(host);
        } catch (Exception unused) {
            finish();
        }
    }

    public final void G(String str) {
        this.d.dismiss();
    }

    public final void V(String str) {
        PayLoadingDialog payLoadingDialog = new PayLoadingDialog();
        this.d = payLoadingDialog;
        payLoadingDialog.show(getSupportFragmentManager(), "");
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [com.huawei.webview.MerchantDispatcherActivity, android.app.Activity] */
    public final void g(GetH5AccessTokenResp getH5AccessTokenResp) {
        String url = getH5AccessTokenResp.getUrl();
        String accessToken = getH5AccessTokenResp.getAccessToken();
        HashMap hashMap = new HashMap();
        hashMap.put("appId", this.e);
        hashMap.put("token", accessToken);
        hashMap.put("deviceId", h.a());
        b.d(this, url, getIntent().getExtras(), hashMap);
        finish();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.webview.MerchantDispatcherActivity, com.huawei.digitalpayment.customer.baselib.base.BaseActivity, androidx.appcompat.app.AppCompatActivity, android.app.Activity] */
    public final void onCreate(@Nullable Bundle bundle) {
        MerchantDispatcherActivity.super.onCreate(bundle);
        setContentView(R$layout.layout_transparent);
        f.g(getWindow());
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [com.huawei.webview.MerchantDispatcherActivity, android.app.Activity] */
    public final void v(BaseResp baseResp) {
        BaseMvvmActivity.V0(new BaseException(baseResp.getResponseCode(), baseResp.getResponseDesc()));
        finish();
    }

    public final void G0() {
    }
}
