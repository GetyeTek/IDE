package com.huawei.webview;

public final /* synthetic */ class e {
    public final /* synthetic */ WebViewActivity a;
    public final /* synthetic */ String b;

    public /* synthetic */ e(WebViewActivity webViewActivity, String str) {
        this.a = webViewActivity;
        this.b = str;
    }
}
