package com.huawei.webview;

import F8.d;
import L2.c;
import V1.k;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.J;
import com.blankj.utilcode.util.e;
import com.blankj.utilcode.util.f;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.ethiopia.component.service.WebViewCallBackService;
import com.huawei.webview.databinding.FragmentWebviewBinding;
import java.util.HashMap;
import java.util.Locale;
import o0.b;

@Route(path = "/webViewModule/webviewFragment")
public class WebViewFragment extends Fragment {
    public FragmentWebviewBinding a;
    public String b;
    public WebSettings c;
    public ValueCallback<Uri[]> d;
    public e e;
    public c f;
    public String g;
    public final a h = new a();

    public class a implements R1.a<Uri> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            k.b(1, baseException.getResponseDesc());
            ValueCallback<Uri[]> valueCallback = WebViewFragment.this.d;
            if (valueCallback != null) {
                valueCallback.onReceiveValue((Object) null);
            }
            if (baseException.getCode() == 5 || baseException.getCode() == 6) {
                e.b();
            }
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            Uri[] uriArr = {(Uri) obj};
            ValueCallback<Uri[]> valueCallback = WebViewFragment.this.d;
            if (valueCallback != null) {
                valueCallback.onReceiveValue(uriArr);
            }
        }
    }

    public static boolean v0(WebViewFragment webViewFragment, String str) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(webViewFragment.g) || !str.startsWith(webViewFragment.g)) {
            return false;
        }
        Intent intent = new Intent();
        intent.putExtra("callbackUrl", str);
        webViewFragment.requireActivity().setResult(-1, intent);
        webViewFragment.requireActivity().finish();
        return true;
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        FragmentWebviewBinding inflate = DataBindingUtil.inflate(layoutInflater, R$layout.fragment_webview, viewGroup, false);
        this.a = inflate;
        return inflate.getRoot();
    }

    public final void onPause() {
        WebViewFragment.super.onPause();
        this.a.b.onPause();
    }

    public final void onResume() {
        WebViewFragment.super.onResume();
        this.a.b.onResume();
    }

    /* JADX WARNING: type inference failed for: r5v66, types: [com.huawei.webview.c, java.lang.Object] */
    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        WebViewClient webViewClient;
        e.a aVar;
        WebViewFragment.super.onViewCreated(view, bundle);
        LanguageUtils.getInstance().setLanguage(requireActivity(), LanguageUtils.getInstance().getCurrentLang());
        WebViewFragment.super.onCreate(bundle);
        f.e(requireActivity(), ContextCompat.getColor(requireActivity(), R$color.color_F4F4F4), false);
        this.b = getArguments().getString("url");
        this.g = getArguments().getString("callbackUrl");
        WebSettings settings = this.a.b.getSettings();
        this.c = settings;
        settings.setJavaScriptEnabled(true);
        this.c.setMediaPlaybackRequiresUserGesture(false);
        this.c.setLoadWithOverviewMode(false);
        this.c.setSaveFormData(true);
        this.c.setSupportZoom(true);
        this.c.setBuiltInZoomControls(false);
        this.c.setDatabaseEnabled(true);
        this.c.setCacheMode(-1);
        this.c.setBlockNetworkImage(false);
        this.c.setDomStorageEnabled(true);
        this.c.setDefaultFontSize(16);
        this.c.setMinimumFontSize(12);
        this.c.setAllowFileAccessFromFileURLs(false);
        this.c.setAllowUniversalAccessFromFileURLs(false);
        this.c.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        this.c.setMixedContentMode(0);
        this.a.b.setLayerType(2, (Paint) null);
        this.c.setAllowContentAccess(false);
        this.c.setTextZoom(100);
        this.c.setUseWideViewPort(false);
        this.c.setPluginState(WebSettings.PluginState.ON);
        this.c.setLoadsImagesAutomatically(true);
        this.c.setSupportMultipleWindows(false);
        this.c.setAllowFileAccess(false);
        this.c.setNeedInitialFocus(true);
        this.c.setDefaultTextEncodingName("utf-8");
        this.c.setGeolocationEnabled(true);
        this.c.setGeolocationDatabasePath(requireActivity().getApplicationContext().getDir("database", 0).getPath());
        c.a.getClass();
        WebView.setWebContentsDebuggingEnabled(false);
        this.a.b.setHorizontalScrollBarEnabled(false);
        WebView webView = this.a.b;
        if (TextUtils.isEmpty(this.g)) {
            webViewClient = b.c(WebViewCallBackService.class).w();
        } else {
            webViewClient = new h(this);
        }
        webView.setWebViewClient(webViewClient);
        this.a.b.setWebChromeClient(new i(this));
        this.a.b.addJavascriptInterface(new b(requireActivity()), "consumerapp");
        this.a.b.getSettings().setDefaultTextEncodingName("utf-8");
        this.a.b.addJavascriptInterface(new F8.b(requireActivity()), "Android");
        this.a.b.setDownloadListener(new g(this));
        if ("h5".equals(Uri.parse(this.b).getScheme().toLowerCase(Locale.ENGLISH))) {
            StringBuilder sb2 = new StringBuilder("https://www.superapp.ethiomobilemoney.et:38443");
            c.a.getClass();
            sb2.append(this.b.replace("h5://", "/"));
            this.b = sb2.toString();
        }
        HashMap a2 = com.google.android.gms.ads.identifier.a.a("platform", "android");
        a2.put("language", LanguageUtils.getInstance().getCurrentLang());
        String packageName = J.a().getPackageName();
        try {
            PackageManager packageManager = J.a().getPackageManager();
            if (packageManager != null) {
                aVar = e.a(packageManager, packageManager.getPackageInfo(packageName, 0));
                a2.put("version", aVar.e);
                a2.put("apkSign", Ea.b.e());
                this.a.b.loadUrl(d.a(this.b, a2));
                CookieManager.getInstance().removeAllCookies((ValueCallback) null);
                FragmentActivity requireActivity = requireActivity();
                ? obj = new Object();
                obj.a = requireActivity;
                this.f = obj;
            }
        } catch (PackageManager.NameNotFoundException e2) {
            e2.printStackTrace();
        }
        aVar = null;
        a2.put("version", aVar.e);
        a2.put("apkSign", Ea.b.e());
        this.a.b.loadUrl(d.a(this.b, a2));
        CookieManager.getInstance().removeAllCookies((ValueCallback) null);
        FragmentActivity requireActivity2 = requireActivity();
        ? obj2 = new Object();
        obj2.a = requireActivity2;
        this.f = obj2;
    }
}
