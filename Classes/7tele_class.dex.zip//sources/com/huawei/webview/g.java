package com.huawei.webview;

import F8.b;
import V1.h;
import android.content.Intent;
import android.net.Uri;
import android.webkit.DownloadListener;

public final /* synthetic */ class g implements DownloadListener {
    public final /* synthetic */ WebViewFragment a;

    public /* synthetic */ g(WebViewFragment webViewFragment) {
        this.a = webViewFragment;
    }

    public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
        String str5;
        WebViewFragment webViewFragment = this.a;
        try {
            if (str.startsWith("blob:")) {
                if (str.startsWith("blob")) {
                    b.b = str4;
                    str5 = "javascript: var xhr = new XMLHttpRequest();xhr.open('GET', '" + str + "', true);xhr.setRequestHeader('Content-type','" + str4 + ";charset=UTF-8');xhr.responseType = 'blob';xhr.onload = function(e) {    if (this.status == 200) {        var blobFile = this.response;        var reader = new FileReader();        reader.readAsDataURL(blobFile);        reader.onloadend = function() {            base64data = reader.result;            Android.getBase64FromBlobData(base64data);        }    }};xhr.send();";
                } else {
                    str5 = "javascript: console.log('It is not a Blob URL');";
                }
                webViewFragment.a.b.loadUrl(str5);
                return;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addCategory("android.intent.category.BROWSABLE");
            intent.setData(Uri.parse(str));
            webViewFragment.startActivity(intent);
        } catch (Exception e) {
            e.getMessage();
            h.b();
        }
    }
}
