package com.huawei.webview;

import A8.C0058g;
import A8.l;
import Bb.h;
import D6.k;
import F8.c;
import J2.a;
import V7.e;
import Yb.j;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.camera.camera2.internal.P;
import androidx.core.content.ContextCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.lifecycle.ViewModel;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.f;
import com.huawei.digitalpayment.customer.baselib.utils.language.LanguageUtils;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.webview.databinding.ActivityWebviewBinding;
import i3.b;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.ThreadMode;
import z8.C0493b;

@a
@Route(path = "/webViewModule/webview")
public class WebViewActivity extends DataBindingActivity<ActivityWebviewBinding, ViewModel> {
    public static final /* synthetic */ int j = 0;
    public String d;
    public boolean e;
    public boolean f;
    public final h g;
    public TextView h;
    public WebViewFragment i;

    public WebViewActivity() {
        h hVar = new h();
        hVar.b = new ArrayList();
        this.g = hVar;
    }

    public final int C0() {
        return R$layout.activity_webview;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [android.webkit.ValueCallback, java.lang.Object] */
    public final void E0(String str, String str2) {
        this.i.a.b.evaluateJavascript(P.a("javascript:shareSocialNetworkCallback('", str2, "');"), new Object());
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.webview.WebViewActivity, androidx.fragment.app.FragmentActivity] */
    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        WebViewActivity.super.onActivityResult(i2, i3, intent);
        if (i2 != 111) {
            if (i2 == 56) {
                E0("shareSocialNetworkCallback", getString(R$string.designstandard_open_share_app_successfully));
            }
            Iterator it = ((ArrayList) this.g.b).iterator();
            while (it.hasNext()) {
                ((C0493b) it.next()).K(i2, i3, intent);
            }
        }
    }

    public final void onBackPressed() {
        if (this.i.a.b.canGoBack()) {
            this.i.a.b.goBack();
        } else {
            WebViewActivity.super.onBackPressed();
        }
    }

    /* JADX WARNING: type inference failed for: r0v16, types: [C8.c, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v5, types: [A8.m, z8.b, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v6, types: [z8.b, A8.k, java.lang.Object] */
    public final void onCreate(@Nullable Bundle bundle) {
        TextView textView;
        LanguageUtils.getInstance().setLanguage(this, LanguageUtils.getInstance().getCurrentLang());
        WebViewActivity.super.onCreate(bundle);
        boolean z = false;
        f.e(this, ContextCompat.getColor(this, R$color.color_F4F4F4), false);
        this.d = getIntent().getStringExtra("url");
        String stringExtra = getIntent().getStringExtra("callbackUrl");
        this.e = getIntent().getBooleanExtra("needCallbackNative", false);
        String str = this.d;
        if (str != null) {
            int indexOf = str.indexOf("?");
            int indexOf2 = str.indexOf("#");
            if (!(indexOf == -1 || indexOf2 == -1 || indexOf <= indexOf2)) {
                str = str.replaceFirst("#", "");
            }
            Uri parse = Uri.parse(str);
            if (parse != null) {
                z = Boolean.parseBoolean(parse.getQueryParameter("notoolbar"));
            }
        }
        if (!z) {
            e.a(this, "", R$layout.webview_toolbar);
            this.h = (TextView) findViewById(R$id.tvTitle);
            findViewById(R$id.ivBack).setOnClickListener(new O7.a(this, 4));
            findViewById(R$id.ivClose).setOnClickListener(new k(this, 4));
        } else {
            View root = this.b.getRoot();
            root.setFitsSystemWindows(true);
            if (Build.VERSION.SDK_INT >= 35) {
                ViewCompat.setOnApplyWindowInsetsListener(root, (OnApplyWindowInsetsListener) null);
            }
        }
        String stringExtra2 = getIntent().getStringExtra("title");
        if (!(stringExtra2 == null || stringExtra2.length() == 0 || (textView = this.h) == null)) {
            textView.setText(stringExtra2);
        }
        Bundle bundle2 = new Bundle();
        bundle2.putString("url", this.d);
        bundle2.putString("callbackUrl", stringExtra);
        n.a.b().getClass();
        WebViewFragment webViewFragment = (WebViewFragment) n.a.a("/webViewModule/webviewFragment").with(bundle2).navigation();
        this.i = webViewFragment;
        webViewFragment.e = new e(this, stringExtra2);
        getSupportFragmentManager().beginTransaction().add(R$id.ll_container, this.i).commit();
        ArrayList arrayList = (ArrayList) this.g.b;
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        ? obj = new Object();
        obj.f = true;
        obj.b = this;
        obj.a = this;
        ? bVar = new C0493b();
        bVar.d = obj;
        arrayList.add(bVar);
        ? bVar2 = new C0493b();
        bVar2.d = obj;
        arrayList.add(bVar2);
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0058g());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        arrayList.add(new C0493b());
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((C0493b) it.next()).c = this;
        }
    }

    public final void onDestroy() {
        this.i.a.b.destroy();
        if (!this.e) {
            c.b.a = null;
        }
        WebViewActivity.super.onDestroy();
        Iterator it = ((ArrayList) this.g.b).iterator();
        while (it.hasNext()) {
            try {
                ((C0493b) it.next()).v0();
            } catch (Exception e2) {
                e2.toString();
                V1.h.b();
            }
        }
    }

    @j(sticky = true, threadMode = ThreadMode.MAIN)
    public void onEvent(b bVar) {
        Yb.c.b().k(bVar);
        throw null;
    }

    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 4) {
            if (this.f) {
                return true;
            }
            WebView webView = this.i.a.b;
            if (webView == null || !webView.canGoBack()) {
                finish();
            } else {
                this.i.a.b.goBack();
                return true;
            }
        }
        return WebViewActivity.super.onKeyDown(i2, keyEvent);
    }

    public final void onRequestPermissionsResult(int i2, @NonNull String[] strArr, @NonNull int[] iArr) {
        int i3;
        WebViewActivity.super.onRequestPermissionsResult(i2, strArr, iArr);
        Iterator it = ((ArrayList) this.g.b).iterator();
        while (true) {
            i3 = 0;
            if (!it.hasNext()) {
                break;
            }
            C0493b bVar = (C0493b) it.next();
            if (i2 == bVar.a) {
                while (i3 < iArr.length && iArr[i3] == 0) {
                    i3++;
                }
                l lVar = bVar.b;
                if (lVar != null) {
                    lVar.a();
                }
            }
        }
        c cVar = this.i.f;
        cVar.getClass();
        if (i2 == 30) {
            if (iArr.length > 0) {
                while (i3 < iArr.length) {
                    if (iArr[i3] == 0) {
                        i3++;
                    }
                }
                PermissionRequest permissionRequest = cVar.b;
                permissionRequest.grant(permissionRequest.getResources());
                return;
            }
            cVar.b.deny();
        }
    }

    public final void onStart() {
        WebViewActivity.super.onStart();
        Iterator it = ((ArrayList) this.g.b).iterator();
        while (it.hasNext()) {
            try {
                ((C0493b) it.next()).w0();
            } catch (Exception e2) {
                e2.toString();
                V1.h.b();
            }
        }
    }

    public final void onStop() {
        WebViewActivity.super.onStop();
        Iterator it = ((ArrayList) this.g.b).iterator();
        while (it.hasNext()) {
            try {
                ((C0493b) it.next()).getClass();
            } catch (Exception e2) {
                e2.toString();
                V1.h.b();
            }
        }
    }
}
