package com.huawei.webview.view;

import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebView;

public class TermsWebView extends WebView {

    public interface a {
    }

    public TermsWebView(Context context) {
        super(context);
    }

    public final boolean canScrollHorizontally(int i) {
        int computeHorizontalScrollOffset = computeHorizontalScrollOffset();
        int computeHorizontalScrollRange = computeHorizontalScrollRange() - computeHorizontalScrollExtent();
        if (computeHorizontalScrollRange == 0) {
            return false;
        }
        if (i < 0) {
            if (computeHorizontalScrollOffset > 0) {
                return true;
            }
            return false;
        } else if (computeHorizontalScrollOffset < computeHorizontalScrollRange - 1) {
            return true;
        } else {
            return false;
        }
    }

    public final boolean canScrollVertically(int i) {
        int computeVerticalScrollOffset = computeVerticalScrollOffset();
        int computeVerticalScrollRange = computeVerticalScrollRange() - computeVerticalScrollExtent();
        if (computeVerticalScrollRange == 0) {
            return false;
        }
        if (i < 0) {
            if (computeVerticalScrollOffset > 0) {
                return true;
            }
            return false;
        } else if (computeVerticalScrollOffset < computeVerticalScrollRange - 1) {
            return true;
        } else {
            return false;
        }
    }

    public final void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
    }

    public void setOnCustomScrollChangeListener(a aVar) {
    }

    public TermsWebView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public TermsWebView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }
}
