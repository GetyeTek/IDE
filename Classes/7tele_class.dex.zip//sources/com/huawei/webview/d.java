package com.huawei.webview;

import V1.h;
import android.webkit.ValueCallback;

public final /* synthetic */ class d implements ValueCallback {
    public final void onReceiveValue(Object obj) {
        String str = (String) obj;
        int i = WebViewActivity.j;
        h.b();
    }
}
