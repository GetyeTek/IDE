package com.huawei.webview;

import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public final class h extends WebViewClient {
    public final /* synthetic */ WebViewFragment a;

    public h(WebViewFragment webViewFragment) {
        this.a = webViewFragment;
    }

    public final boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        String uri = webResourceRequest.getUrl().toString();
        if (WebViewFragment.v0(this.a, uri)) {
            return true;
        }
        webView.loadUrl(uri);
        return true;
    }

    public final boolean shouldOverrideUrlLoading(WebView webView, String str) {
        if (WebViewFragment.v0(this.a, str)) {
            return true;
        }
        webView.loadUrl(str);
        return true;
    }
}
