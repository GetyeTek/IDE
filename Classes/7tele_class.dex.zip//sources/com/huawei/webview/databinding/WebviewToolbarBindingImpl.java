package com.huawei.webview.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.webview.R$id;

public class WebviewToolbarBindingImpl extends WebviewToolbarBinding {
    @Nullable
    public static final SparseIntArray c;
    public long b;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        c = sparseIntArray;
        sparseIntArray.put(R$id.ivBack, 1);
        sparseIntArray.put(R$id.tvTitle, 2);
        sparseIntArray.put(R$id.ivClose, 3);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.b = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.b != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.b = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
