package com.huawei.webview.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class LayoutWebviewBinding extends ViewDataBinding {
}
