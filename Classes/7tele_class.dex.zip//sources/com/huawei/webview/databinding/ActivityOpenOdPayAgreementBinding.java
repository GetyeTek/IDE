package com.huawei.webview.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class ActivityOpenOdPayAgreementBinding implements ViewBinding {
    @NonNull
    public final /* bridge */ /* synthetic */ View getRoot() {
        return null;
    }
}
