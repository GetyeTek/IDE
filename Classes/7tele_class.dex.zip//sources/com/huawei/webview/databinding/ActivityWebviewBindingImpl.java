package com.huawei.webview.databinding;

import androidx.annotation.Nullable;

public class ActivityWebviewBindingImpl extends ActivityWebviewBinding {
    public long b;

    public final void executeBindings() {
        synchronized (this) {
            this.b = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.b != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.b = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
