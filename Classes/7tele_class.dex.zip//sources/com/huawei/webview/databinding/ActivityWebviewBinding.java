package com.huawei.webview.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class ActivityWebviewBinding extends ViewDataBinding {
    @NonNull
    public final LinearLayout a;

    public ActivityWebviewBinding(DataBindingComponent dataBindingComponent, View view, LinearLayout linearLayout) {
        super(dataBindingComponent, view, 0);
        this.a = linearLayout;
    }
}
