package com.huawei.webview.databinding;

import android.view.View;
import android.webkit.WebView;
import android.widget.ProgressBar;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;

public abstract class FragmentWebviewBinding extends ViewDataBinding {
    @NonNull
    public final ProgressBar a;
    @NonNull
    public final WebView b;

    public FragmentWebviewBinding(DataBindingComponent dataBindingComponent, View view, ProgressBar progressBar, WebView webView) {
        super(dataBindingComponent, view, 0);
        this.a = progressBar;
        this.b = webView;
    }
}
