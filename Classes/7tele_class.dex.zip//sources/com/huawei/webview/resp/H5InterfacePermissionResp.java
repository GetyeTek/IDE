package com.huawei.webview.resp;

import com.huawei.http.BaseResp;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.h;

public final class H5InterfacePermissionResp extends BaseResp {
    private final Map<String, List<String>> map;

    public H5InterfacePermissionResp(Map<String, ? extends List<String>> map2) {
        this.map = map2;
    }

    public static /* synthetic */ H5InterfacePermissionResp copy$default(H5InterfacePermissionResp h5InterfacePermissionResp, Map<String, List<String>> map2, int i, Object obj) {
        if ((i & 1) != 0) {
            map2 = h5InterfacePermissionResp.map;
        }
        return h5InterfacePermissionResp.copy(map2);
    }

    public final Map<String, List<String>> component1() {
        return this.map;
    }

    public final H5InterfacePermissionResp copy(Map<String, ? extends List<String>> map2) {
        return new H5InterfacePermissionResp(map2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof H5InterfacePermissionResp) && h.a(this.map, ((H5InterfacePermissionResp) obj).map);
    }

    public final Map<String, List<String>> getMap() {
        return this.map;
    }

    public int hashCode() {
        Map<String, List<String>> map2 = this.map;
        if (map2 == null) {
            return 0;
        }
        return map2.hashCode();
    }

    public String toString() {
        Map<String, List<String>> map2 = this.map;
        return "H5InterfacePermissionResp(map=" + map2 + ")";
    }
}
