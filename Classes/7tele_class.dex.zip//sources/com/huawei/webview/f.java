package com.huawei.webview;

import android.webkit.ValueCallback;
import android.webkit.WebView;

public final /* synthetic */ class f implements Runnable {
    public final /* synthetic */ WebView a;
    public final /* synthetic */ String b;
    public final /* synthetic */ ValueCallback c;

    public /* synthetic */ f(WebView webView, String str, ValueCallback valueCallback) {
        this.a = webView;
        this.b = str;
        this.c = valueCallback;
    }

    public final void run() {
        int i = WebViewActivity.j;
        this.a.evaluateJavascript(this.b, this.c);
    }
}
