package com.huawei.webview;

import V1.h;
import android.webkit.ValueCallback;

public final /* synthetic */ class a implements ValueCallback {
    public final void onReceiveValue(Object obj) {
        String str = (String) obj;
        h.b();
    }
}
