package com.huawei.webview;

import android.util.Log;
import com.alibaba.android.arouter.facade.model.TypeWrapper;
import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;
import com.huawei.digitalpayment.customer.httplib.request.H5CheckoutRequest;

public class WebDispatcherActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    public class a extends TypeWrapper<H5CheckoutRequest> {
    }

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.webview.WebDispatcherActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (WebDispatcherActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.mUrl;
        } else {
            str = r4.getIntent().getExtras().getString("url", r4.mUrl);
        }
        r4.mUrl = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.mAppId;
        } else {
            str2 = r4.getIntent().getExtras().getString("appId", r4.mAppId);
        }
        r4.mAppId = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.mFrom;
        } else {
            str3 = r4.getIntent().getExtras().getString("from", r4.mFrom);
        }
        r4.mFrom = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.rawRequest;
        } else {
            str4 = r4.getIntent().getExtras().getString("rawRequest", r4.rawRequest);
        }
        r4.rawRequest = str4;
        if (r4.getIntent().getExtras() == null) {
            str5 = r4.prepayId;
        } else {
            str5 = r4.getIntent().getExtras().getString("prepayId", r4.prepayId);
        }
        r4.prepayId = str5;
        if (r4.getIntent().getExtras() == null) {
            str6 = r4.mTradeType;
        } else {
            str6 = r4.getIntent().getExtras().getString("tradeType", r4.mTradeType);
        }
        r4.mTradeType = str6;
        SerializationService serializationService2 = this.serializationService;
        if (serializationService2 != null) {
            r4.pawParams = (H5CheckoutRequest) serializationService2.parseObject(r4.getIntent().getStringExtra("pawParams"), new TypeWrapper().getType());
        } else {
            Log.e("ARouter::", "You want automatic inject the field 'pawParams' in class 'WebDispatcherActivity' , then you should implement 'SerializationService' to support object auto inject!");
        }
        if (r4.getIntent().getExtras() == null) {
            str7 = r4.urlString;
        } else {
            str7 = r4.getIntent().getExtras().getString("scheme_execute_key", r4.urlString);
        }
        r4.urlString = str7;
    }
}
