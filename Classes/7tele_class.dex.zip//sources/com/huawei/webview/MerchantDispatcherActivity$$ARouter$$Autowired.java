package com.huawei.webview;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class MerchantDispatcherActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.webview.MerchantDispatcherActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (MerchantDispatcherActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.urlString;
        } else {
            str = r4.getIntent().getExtras().getString("scheme_execute_key", r4.urlString);
        }
        r4.urlString = str;
    }
}
