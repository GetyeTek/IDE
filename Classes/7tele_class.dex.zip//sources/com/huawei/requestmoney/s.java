package com.huawei.requestmoney;

import R1.a;
import com.google.gson.Gson;
import com.huawei.common.exception.BaseException;
import com.huawei.customer.digitalpayment.miniapp.macle.MacleDispatcherActivity;
import com.huawei.customer.digitalpayment.miniapp.macle.maclemanager.entity.MacleAppInfo;
import com.huawei.module_checkout.checkstand.PaySceneEnum;
import fc.A;
import fc.C0267b;
import fc.C0269d;
import i7.a;
import java.util.HashMap;
import okhttp3.ResponseBody;
import org.json.JSONObject;

public final class s implements a, C0269d {
    public final /* synthetic */ Object a;

    public /* synthetic */ s(Object obj) {
        this.a = obj;
    }

    public void a(C0267b bVar, A a2) {
        MacleDispatcherActivity.a aVar = (MacleDispatcherActivity.a) this.a;
        T t = a2.b;
        if (t != null) {
            try {
                aVar.b((MacleAppInfo) new Gson().fromJson(new JSONObject(((ResponseBody) t).string()).optJSONObject("data").toString(), MacleAppInfo.class));
            } catch (Exception unused) {
                aVar.a((String) null);
            }
        }
    }

    public void b(C0267b bVar, Throwable th) {
        ((MacleDispatcherActivity.a) this.a).a(th.toString());
    }

    public /* synthetic */ void onComplete() {
    }

    public /* synthetic */ void onError(BaseException baseException) {
    }

    public /* synthetic */ void onLoading(Object obj) {
    }

    public void onSuccess(Object obj) {
        Boolean bool = (Boolean) obj;
        RequestMoneyDetailActivity requestMoneyDetailActivity = (RequestMoneyDetailActivity) this.a;
        if (requestMoneyDetailActivity.f != null) {
            HashMap hashMap = new HashMap();
            hashMap.put("requestMoneyOrderId", requestMoneyDetailActivity.f.getRequestMoneyOrderId());
            hashMap.put("amount", String.valueOf(requestMoneyDetailActivity.f.getAmount()));
            hashMap.put("tradeType", "NativeApp");
            a.a.a.c(requestMoneyDetailActivity, (String) null, PaySceneEnum.REQUEST_MONEY, hashMap, new t(requestMoneyDetailActivity));
        }
    }
}
