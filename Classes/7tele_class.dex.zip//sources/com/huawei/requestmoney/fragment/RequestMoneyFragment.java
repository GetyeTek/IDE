package com.huawei.requestmoney.fragment;

import I4.e;
import V1.k;
import V7.c;
import V7.f;
import W1.b;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.requestmoney.R$layout;
import com.huawei.requestmoney.R$string;
import com.huawei.requestmoney.adapter.RequestMoneyAdapter;
import com.huawei.requestmoney.bean.RequestMoneyResp;
import com.huawei.requestmoney.databinding.RequestMoneyFragmentLayoutBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import java.util.ArrayList;
import java.util.List;
import u8.C0449c;
import u8.C0450d;
import u8.C0453g;

public class RequestMoneyFragment extends Fragment {
    public int a = 1;
    public RequestMoneyFragmentLayoutBinding b;
    public RequestMoneyViewModel c;
    public RequestMoneyAdapter d;
    public String e;
    public boolean f;
    public boolean g;
    public b.b h;
    public ArrayList i = new ArrayList();
    public b j;

    public class a implements Observer<c<RequestMoneyResp>> {
        public a() {
        }

        public final void onChanged(Object obj) {
            List<RequestMoneyResp.RequestMoneyOrderInfosBean> requestMoneyOrderInfos;
            c cVar = (c) obj;
            boolean d = cVar.d();
            RequestMoneyFragment requestMoneyFragment = RequestMoneyFragment.this;
            if (d && !requestMoneyFragment.g && !requestMoneyFragment.f) {
                requestMoneyFragment.h.a(1);
            } else if (cVar.b()) {
                requestMoneyFragment.h.a(3);
                f.c(cVar);
            } else if (cVar.f()) {
                requestMoneyFragment.h.a(2);
                boolean z = requestMoneyFragment.f;
                ArrayList arrayList = requestMoneyFragment.i;
                if (!z) {
                    arrayList.clear();
                    requestMoneyFragment.a = 1;
                }
                SmartRefreshLayout smartRefreshLayout = requestMoneyFragment.b.c;
                smartRefreshLayout.getClass();
                smartRefreshLayout.h(Math.min(Math.max(0, 300 - ((int) (System.currentTimeMillis() - smartRefreshLayout.s1))), 300) << 16, false);
                RequestMoneyResp requestMoneyResp = (RequestMoneyResp) cVar.c;
                if (requestMoneyResp != null && (requestMoneyOrderInfos = requestMoneyResp.getRequestMoneyOrderInfos()) != null) {
                    if (!requestMoneyFragment.f || requestMoneyOrderInfos.size() != 0) {
                        requestMoneyFragment.a++;
                        arrayList.addAll(requestMoneyOrderInfos);
                        requestMoneyFragment.d.setList(arrayList);
                        b bVar = requestMoneyFragment.j;
                        if (bVar != null) {
                            bVar.b(requestMoneyResp.getTotalCount());
                            if (TextUtils.equals("0", requestMoneyResp.getTotalCount())) {
                                requestMoneyFragment.b.a.setVisibility(0);
                            } else {
                                requestMoneyFragment.b.a.setVisibility(8);
                            }
                        }
                    } else {
                        k.b(1, requestMoneyFragment.getString(R$string.no_more_data));
                    }
                }
            }
        }
    }

    public interface b {
        void b(String str);
    }

    public static RequestMoneyFragment v0(String str, b bVar) {
        Bundle a2 = com.google.android.gms.auth.api.a.a("type", str);
        Fragment fragment = new Fragment();
        fragment.a = 1;
        fragment.i = new ArrayList();
        fragment.j = bVar;
        fragment.setArguments(a2);
        return fragment;
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        RequestMoneyFragmentLayoutBinding inflate = DataBindingUtil.inflate(layoutInflater, R$layout.request_money_fragment_layout, viewGroup, false);
        this.b = inflate;
        return inflate.getRoot();
    }

    /* JADX WARNING: type inference failed for: r3v17, types: [java.lang.Object, java.lang.Runnable] */
    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        boolean z;
        RequestMoneyFragment.super.onViewCreated(view, bundle);
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.e = arguments.getString("type");
        }
        RequestMoneyViewModel requestMoneyViewModel = new ViewModelProvider(this).get(RequestMoneyViewModel.class);
        this.c = requestMoneyViewModel;
        requestMoneyViewModel.h(this.e, "1");
        String str = this.e;
        BaseQuickAdapter baseQuickAdapter = new BaseQuickAdapter(R$layout.item_layout_request_money);
        baseQuickAdapter.a = str;
        baseQuickAdapter.b = o0.b.c(AppService.class).l();
        this.d = baseQuickAdapter;
        this.b.b.setAdapter(baseQuickAdapter);
        this.d.setOnItemClickListener(new C0453g(this));
        SmartRefreshLayout smartRefreshLayout = this.b.c;
        smartRefreshLayout.S0 = new C0450d(this);
        smartRefreshLayout.T0 = new e(this, 4);
        if (smartRefreshLayout.C || !smartRefreshLayout.P0) {
            z = true;
        } else {
            z = false;
        }
        smartRefreshLayout.C = z;
        b.b c2 = W1.b.b().c(this.b.b);
        c2.b = new Object();
        this.h = c2;
        this.c.g.observe(getViewLifecycleOwner(), new a());
        this.d.setOnItemClickListener(new C0449c(this));
    }
}
