package com.huawei.requestmoney.fragment;

import V1.k;
import V7.c;
import V7.f;
import W2.h;
import a5.j;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.exception.BaseException;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.digitalpayment.customer.baselib.utils.exception.PhoneNumberException;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.module_checkout.R;
import com.huawei.requestmoney.R$id;
import com.huawei.requestmoney.R$layout;
import com.huawei.requestmoney.R$string;
import com.huawei.requestmoney.bean.CreateRequestMoneyResp;
import com.huawei.requestmoney.databinding.CreateRequestMoneyFragmentLayoutBinding;
import com.huawei.requestmoney.view.TypeSelectView;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import java.util.ArrayList;
import java.util.Map;
import o0.b;
import u8.C0447a;
import u8.C0448b;

public class CreateRequestMoneyFragment extends Fragment {
    public CreateRequestMoneyFragmentLayoutBinding a;
    public RequestMoneyViewModel b;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;

    public class a implements Observer<c<CreateRequestMoneyResp>> {
        public a() {
        }

        public final void onChanged(Object obj) {
            Object obj2;
            c cVar = (c) obj;
            CreateRequestMoneyFragment createRequestMoneyFragment = CreateRequestMoneyFragment.this;
            f.b(createRequestMoneyFragment.requireActivity(), cVar);
            if (cVar.b()) {
                BaseException baseException = cVar.b;
                if (baseException == null || !"60500073".equals(baseException.getResponseCode())) {
                    f.c(cVar);
                } else {
                    createRequestMoneyFragment.w0(baseException.getMessage());
                }
            } else if (cVar.f() && (obj2 = cVar.c) != null) {
                CreateRequestMoneyResp createRequestMoneyResp = (CreateRequestMoneyResp) obj2;
                if (!TextUtils.isEmpty(createRequestMoneyResp.getQrCode())) {
                    Bundle bundle = new Bundle();
                    bundle.putString("qrCode", createRequestMoneyResp.getQrCode());
                    bundle.putString("amount", createRequestMoneyFragment.e);
                    bundle.putString("mobileNumber", createRequestMoneyFragment.f);
                    bundle.putString("currencyUnit", createRequestMoneyFragment.i);
                    b.d((Activity) null, "/requestMoneyModule/requestMoneyQR", bundle, (Map) null);
                    return;
                }
                Intent intent = new Intent();
                intent.putExtra("type", createRequestMoneyFragment.c);
                createRequestMoneyFragment.requireActivity().setResult(17, intent);
                createRequestMoneyFragment.requireActivity().finish();
                TransferResp transferResp = new TransferResp();
                transferResp.setActualAmountDisplay(createRequestMoneyFragment.e);
                transferResp.setActualAmount(createRequestMoneyFragment.e);
                transferResp.setUnit(createRequestMoneyFragment.i);
                if (createRequestMoneyResp.getDisplayItems() == null) {
                    ArrayList arrayList = new ArrayList();
                    int i = R$string.request_money_from;
                    String string = createRequestMoneyFragment.getString(i);
                    String string2 = createRequestMoneyFragment.getString(i);
                    arrayList.add(new TransferResp.DisplayItemBean(string, string2, "251" + createRequestMoneyFragment.f));
                    transferResp.setDisplayItems(arrayList);
                } else {
                    transferResp.setDisplayItems(createRequestMoneyResp.getDisplayItems());
                }
                if (TextUtils.equals(createRequestMoneyFragment.h, "Ussd")) {
                    String paymentOrderId = createRequestMoneyResp.getPaymentOrderId();
                    transferResp.setOrderStatus("Processing");
                    int i2 = R$string.processing;
                    transferResp.setSubTitle(createRequestMoneyFragment.getString(i2));
                    transferResp.setTitle(createRequestMoneyFragment.getString(i2));
                    Bundle bundle2 = new Bundle();
                    bundle2.putSerializable("TransferResp", transferResp);
                    bundle2.putString("paymentOrderId", paymentOrderId);
                    b.d((Activity) null, "/requestMoneyModule/requestMoneySuccess", bundle2, (Map) null);
                    return;
                }
                TransferResp transferResp2 = new TransferResp();
                transferResp2.setOrderStatus("Success");
                transferResp2.setTitle(createRequestMoneyFragment.getString(R$string.request_money_sent_successfully));
                Bundle bundle3 = new Bundle();
                bundle3.putSerializable("TransferResp", transferResp2);
                bundle3.putString("buttonText", createRequestMoneyFragment.getString(R$string.done));
                b.d((Activity) null, "/requestMoneyModule/requestMoneySuccess", bundle3, (Map) null);
            }
        }
    }

    @Nullable
    public final View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        CreateRequestMoneyFragmentLayoutBinding inflate = DataBindingUtil.inflate(layoutInflater, R$layout.create_request_money_fragment_layout, viewGroup, false);
        this.a = inflate;
        return inflate.getRoot();
    }

    /* JADX WARNING: type inference failed for: r8v10, types: [u8.b, android.text.TextWatcher] */
    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        CreateRequestMoneyFragment.super.onViewCreated(view, bundle);
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.c = arguments.getString("type");
        }
        this.b = new ViewModelProvider(this).get(RequestMoneyViewModel.class);
        TypeSelectView typeSelectView = this.a.e;
        DisplayItem displayItem = new DisplayItem(getString(R$string.app), "App");
        DisplayItem displayItem2 = new DisplayItem(getString(R$string.qr), "QRCode");
        DisplayItem displayItem3 = new DisplayItem(getString(R$string.ussd), "Ussd");
        typeSelectView.getClass();
        typeSelectView.y.setText(displayItem.getContent());
        typeSelectView.A.setText(displayItem2.getContent());
        typeSelectView.z.setText(displayItem3.getContent());
        typeSelectView.L = displayItem;
        typeSelectView.M = displayItem2;
        typeSelectView.Q = displayItem3;
        this.a.e.c();
        if (!TextUtils.isEmpty(this.c) && TextUtils.equals(this.c, "FOR_SELF")) {
            this.a.d.setVisibility(8);
        }
        this.a.b.getEditText().setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        String l = b.c(AppService.class).l();
        this.i = l;
        ((TextView) this.a.a.findViewById(R$id.tv_unit)).setText(l);
        this.a.a.getEditText().setFilters(new InputFilter[]{new t4.a()});
        this.a.c.getEditText().addTextChangedListener(new C0448b(this));
        this.a.b.setOnIconListener(new P6.b(this, 7));
        this.b.h.observe(getViewLifecycleOwner(), new a());
        this.b.m.observe(getViewLifecycleOwner(), new C0447a(this));
    }

    public final void v0(String str) {
        DisplayItem selectItem = this.a.e.getSelectItem();
        if (selectItem == null) {
            k.b(1, getString(R$string.please_choose_payment_type));
            return;
        }
        this.h = selectItem.getContent();
        String text = this.a.b.getText();
        this.f = text;
        if (TextUtils.isEmpty(text)) {
            k.b(1, getString(R$string.designstandard_please_input_phone_number));
            return;
        }
        String b2 = h.b(this.f);
        this.f = b2;
        try {
            this.f = h.a(b2, (Integer) null);
            String text2 = this.a.a.getText();
            this.e = text2;
            if (TextUtils.isEmpty(text2)) {
                k.b(1, getString(R$string.please_input_amount));
                return;
            }
            this.g = this.a.c.getText();
            this.d = this.a.d.getText();
            if (!TextUtils.equals(str, "FOR_MERCHANT")) {
                b.e(requireActivity(), "/requestMoneyModule/requestMoneyInputPin", (Bundle) null, (Map) null, 0, 1);
            } else if (TextUtils.isEmpty(this.d)) {
                k.b(1, getString(R$string.please_input_short_code));
            } else {
                RequestMoneyViewModel requestMoneyViewModel = this.b;
                String str2 = this.d;
                requestMoneyViewModel.m.setValue(c.c());
                com.huawei.http.b bVar = new com.huawei.http.b();
                bVar.addParams("receiverShortCode", str2);
                bVar.addParams("receiverMsisdn", "251" + this.f);
                bVar.sendRequest(new j(requestMoneyViewModel, 3));
            }
        } catch (PhoneNumberException unused) {
            k.a(R.string.checkout_invalid_phone_number_please_check);
        }
    }

    public final void w0(String str) {
        String string = getString(R$string.ok);
        BaseDialog baseDialog = new BaseDialog();
        baseDialog.g = null;
        baseDialog.h = str;
        baseDialog.i = null;
        baseDialog.j = string;
        baseDialog.k = null;
        baseDialog.l = null;
        baseDialog.show(requireFragmentManager(), "");
    }
}
