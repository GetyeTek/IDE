package com.huawei.requestmoney;

import W2.r;
import android.text.Html;
import android.text.TextUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_basic_ui.R;

public final class u extends BaseQuickAdapter<TransferResp.DisplayItemBean, BaseViewHolder> {
    public final void convert(BaseViewHolder baseViewHolder, Object obj) {
        TransferResp.DisplayItemBean displayItemBean = (TransferResp.DisplayItemBean) obj;
        if (!TextUtils.isEmpty(displayItemBean.getValue())) {
            String obj2 = Html.fromHtml(displayItemBean.getValue()).toString();
            if ("TransactionTime".equals(displayItemBean.getKey())) {
                obj2 = r.a(displayItemBean.getValue());
            }
            baseViewHolder.setText(R.id.tv_label, displayItemBean.getLabel()).setText(R.id.tv_value, obj2);
        }
    }
}
