package com.huawei.requestmoney;

import android.widget.CompoundButton;

/* renamed from: com.huawei.requestmoney.a  reason: case insensitive filesystem */
public final /* synthetic */ class C0139a implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ AddBlackOrFavorActivity a;

    public /* synthetic */ C0139a(AddBlackOrFavorActivity addBlackOrFavorActivity) {
        this.a = addBlackOrFavorActivity;
    }

    /* JADX WARNING: type inference failed for: r4v3, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v6, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v9, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v12, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        int i = AddBlackOrFavorActivity.e;
        AddBlackOrFavorActivity addBlackOrFavorActivity = this.a;
        if (z) {
            addBlackOrFavorActivity.b.f.setChecked(false);
            addBlackOrFavorActivity.b.f.setClickable(true);
            addBlackOrFavorActivity.b.e.setChecked(true);
            addBlackOrFavorActivity.b.e.setClickable(false);
            addBlackOrFavorActivity.b.b.setVisibility(0);
            addBlackOrFavorActivity.b.c.setVisibility(8);
            return;
        }
        addBlackOrFavorActivity.getClass();
    }
}
