package com.huawei.requestmoney;

import N.c;
import O.b;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class z extends c<Bitmap> {
    public final /* synthetic */ RequestMoneyQRActivity a;

    public z(RequestMoneyQRActivity requestMoneyQRActivity) {
        this.a = requestMoneyQRActivity;
    }

    public final void onLoadCleared(@Nullable Drawable drawable) {
    }

    public final void onResourceReady(@NonNull Object obj, @Nullable b bVar) {
        RequestMoneyQRActivity requestMoneyQRActivity = this.a;
        requestMoneyQRActivity.d = (Bitmap) obj;
        requestMoneyQRActivity.E0();
    }
}
