package com.huawei.requestmoney;

import W2.q;
import com.huawei.payment.mvvm.DataBindingActivity;

public final class x implements q.b {
    public final /* synthetic */ RequestMoneyPartialAmountActivity a;

    public x(RequestMoneyPartialAmountActivity requestMoneyPartialAmountActivity) {
        this.a = requestMoneyPartialAmountActivity;
    }

    public final void a() {
        int i = RequestMoneyPartialAmountActivity.g;
        DataBindingActivity dataBindingActivity = this.a;
        q.b(dataBindingActivity, dataBindingActivity.b.getRoot(), 150);
    }

    public final void b() {
        int i = RequestMoneyPartialAmountActivity.g;
        DataBindingActivity dataBindingActivity = this.a;
        q.b(dataBindingActivity, dataBindingActivity.b.getRoot(), -150);
    }
}
