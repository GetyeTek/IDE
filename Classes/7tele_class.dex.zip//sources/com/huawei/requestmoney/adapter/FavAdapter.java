package com.huawei.requestmoney.adapter;

import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.image.glide.Base64Mode;
import com.huawei.requestmoney.R$id;
import com.huawei.requestmoney.R$layout;
import com.huawei.requestmoney.R$mipmap;
import com.huawei.requestmoney.bean.BlackOrFavResp;
import y5.b;

public class FavAdapter extends BaseQuickAdapter<BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean, BaseViewHolder> {
    public FavAdapter() {
        super(R$layout.item_fav_contact_layout);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean paymentConsumerRelateIdentityModelListBean = (BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean) obj;
        Base64Mode consumerMode = Base64Mode.getConsumerMode(paymentConsumerRelateIdentityModelListBean.getRelateIdentityAvatar());
        int i = R$mipmap.icon_drawer_head;
        b.a(consumerMode, baseViewHolder.getView(R$id.ivHead), i, i);
        baseViewHolder.setText(R$id.tvFavName, paymentConsumerRelateIdentityModelListBean.getRelateIdentityName());
    }
}
