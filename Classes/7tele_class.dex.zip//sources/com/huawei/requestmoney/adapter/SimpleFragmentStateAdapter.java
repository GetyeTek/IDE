package com.huawei.requestmoney.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import java.util.ArrayList;

public class SimpleFragmentStateAdapter<T extends Fragment> extends FragmentStateAdapter {
    public ArrayList a;

    @NonNull
    public final T createFragment(int i) {
        return (Fragment) this.a.get(i);
    }

    public final int getItemCount() {
        ArrayList arrayList = this.a;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }
}
