package com.huawei.requestmoney.adapter;

import H5.b;
import W2.h;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.camera.core.processing.util.a;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.image.glide.Base64Mode;
import com.huawei.requestmoney.R$id;
import com.huawei.requestmoney.R$layout;
import com.huawei.requestmoney.R$mipmap;
import com.huawei.requestmoney.R$string;
import com.huawei.requestmoney.bean.RequestMoneyResp;

public class RequestMoneyAdapter extends BaseQuickAdapter<RequestMoneyResp.RequestMoneyOrderInfosBean, BaseViewHolder> {
    public String a;
    public String b;

    public RequestMoneyAdapter() {
        super(R$layout.item_layout_request_money);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        RequestMoneyResp.RequestMoneyOrderInfosBean requestMoneyOrderInfosBean = (RequestMoneyResp.RequestMoneyOrderInfosBean) obj;
        int i = R$id.tvStatus;
        baseViewHolder.setTextColor(i, b.b(getContext(), requestMoneyOrderInfosBean.getStatus()));
        RoundImageView view = baseViewHolder.getView(R$id.roundImageView);
        int i2 = R$id.tvCurrency;
        String str = this.b;
        baseViewHolder.setText(i2, str);
        baseViewHolder.setText(R$id.tvAmount, String.valueOf(requestMoneyOrderInfosBean.getAmount()));
        baseViewHolder.setText(i, requestMoneyOrderInfosBean.getStatusDisplay());
        if (TextUtils.equals(this.a, "sender")) {
            baseViewHolder.setText(R$id.textView, requestMoneyOrderInfosBean.getPayerName());
            Base64Mode consumerMode = Base64Mode.getConsumerMode(requestMoneyOrderInfosBean.getPayerAvatar());
            int i3 = R$mipmap.icon_drawer_head;
            y5.b.a(consumerMode, view, i3, i3);
            String payerIdentifier = requestMoneyOrderInfosBean.getPayerIdentifier();
            if (TextUtils.isEmpty(requestMoneyOrderInfosBean.getPayAmount())) {
                baseViewHolder.setVisible(R$id.tv_real_receive_sent_amount, false);
            } else {
                int i4 = R$id.tv_real_receive_sent_amount;
                baseViewHolder.setVisible(i4, true);
                StringBuilder a2 = a.a(getContext().getString(R$string.received), ": ");
                a2.append(requestMoneyOrderInfosBean.getPayAmount());
                a2.append(" ");
                a2.append(str);
                baseViewHolder.setText(i4, a2.toString());
            }
            if (!TextUtils.isEmpty(payerIdentifier)) {
                if (payerIdentifier.startsWith("251")) {
                    int i5 = R$id.tvPhoneNumber;
                    baseViewHolder.setText(i5, "+251 " + h.b(payerIdentifier));
                    return;
                }
                baseViewHolder.setText(R$id.tvPhoneNumber, payerIdentifier);
                return;
            }
            return;
        }
        baseViewHolder.setText(R$id.textView, requestMoneyOrderInfosBean.getPayeeName());
        Base64Mode consumerMode2 = Base64Mode.getConsumerMode(requestMoneyOrderInfosBean.getPayeeAvatar());
        int i6 = R$mipmap.icon_drawer_head;
        y5.b.a(consumerMode2, view, i6, i6);
        String payeeIdentifier = requestMoneyOrderInfosBean.getPayeeIdentifier();
        if (TextUtils.isEmpty(requestMoneyOrderInfosBean.getPayAmount())) {
            baseViewHolder.setVisible(R$id.tv_real_receive_sent_amount, false);
        } else {
            int i7 = R$id.tv_real_receive_sent_amount;
            baseViewHolder.setVisible(i7, true);
            StringBuilder a3 = a.a(getContext().getString(R$string.sent), ": ");
            a3.append(requestMoneyOrderInfosBean.getPayAmount());
            a3.append(" ");
            a3.append(str);
            baseViewHolder.setText(i7, a3.toString());
        }
        if (!TextUtils.isEmpty(payeeIdentifier)) {
            if (payeeIdentifier.startsWith("251")) {
                int i8 = R$id.tvPhoneNumber;
                baseViewHolder.setText(i8, "+251 " + h.b(payeeIdentifier));
                return;
            }
            baseViewHolder.setText(R$id.tvPhoneNumber, payeeIdentifier);
        }
    }
}
