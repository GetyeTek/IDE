package com.huawei.requestmoney.adapter;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.huawei.image.glide.Base64Mode;
import com.huawei.requestmoney.R$id;
import com.huawei.requestmoney.R$layout;
import com.huawei.requestmoney.R$mipmap;
import com.huawei.requestmoney.bean.BlackOrFavResp;
import com.huawei.requestmoney.d;
import t8.C0437a;
import t8.C0438b;
import y5.b;

public class BlackOrFavAdapter extends BaseQuickAdapter<BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean, BaseViewHolder> {
    public String a;
    public d b;

    public BlackOrFavAdapter() {
        super(R$layout.item_black_or_fav_layout);
    }

    public final void convert(@NonNull BaseViewHolder baseViewHolder, Object obj) {
        BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean paymentConsumerRelateIdentityModelListBean = (BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean) obj;
        Base64Mode consumerMode = Base64Mode.getConsumerMode(paymentConsumerRelateIdentityModelListBean.getRelateIdentityAvatar());
        int i = R$mipmap.icon_drawer_head;
        b.a(consumerMode, baseViewHolder.getView(R$id.ivHead), i, i);
        if (TextUtils.isEmpty(this.a) || !TextUtils.equals(this.a, "BLACK")) {
            baseViewHolder.setVisible(R$id.tvUnBlock, false);
            int i2 = R$id.tvRemove;
            baseViewHolder.setVisible(i2, true);
            baseViewHolder.getView(i2).setOnClickListener(new C0438b(this, paymentConsumerRelateIdentityModelListBean));
        } else {
            int i3 = R$id.tvUnBlock;
            baseViewHolder.setVisible(i3, true);
            baseViewHolder.setVisible(R$id.tvRemove, false);
            baseViewHolder.getView(i3).setOnClickListener(new C0437a(this, paymentConsumerRelateIdentityModelListBean));
        }
        baseViewHolder.setText(R$id.tvFavName, paymentConsumerRelateIdentityModelListBean.getRelateIdentityName());
        baseViewHolder.setText(R$id.tvMisidn, paymentConsumerRelateIdentityModelListBean.getRelateIdentifier());
    }
}
