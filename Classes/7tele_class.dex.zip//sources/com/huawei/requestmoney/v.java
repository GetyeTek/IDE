package com.huawei.requestmoney;

import R1.a;
import V1.h;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import com.blankj.utilcode.util.A;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.digitalpayment.customer.login_module.widget.helpdialog.HelpChildRecyclerAdapter;
import com.huawei.digitalpayment.customer.login_module.widget.helpdialog.HelpRecyclerAdapter;
import com.huawei.module_basic_ui.R;
import com.huawei.module_basic_ui.successpage.CommonSuccessActivity;
import com.huawei.module_basic_ui.successpage.f;
import g1.i;
import java.util.List;
import org.json.JSONObject;

public final class v implements a, OnItemClickListener {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ v(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    private final /* synthetic */ void a() {
    }

    private final /* synthetic */ void b() {
    }

    private final /* synthetic */ void d(Object obj) {
    }

    private final /* synthetic */ void e(Object obj) {
    }

    public /* synthetic */ void onComplete() {
        int i = this.a;
    }

    /* JADX WARNING: type inference failed for: r3v3, types: [com.huawei.requestmoney.RequestMoneyFinishSuccessActivity, java.lang.Runnable] */
    public void onError(BaseException baseException) {
        switch (this.a) {
            case 0:
                A.h((RequestMoneyFinishSuccessActivity) this.b, 5000);
                return;
            default:
                return;
        }
    }

    public void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
        int i2 = HelpRecyclerAdapter.a;
        ((HelpRecyclerAdapter) this.b).getClass();
    }

    public /* synthetic */ void onLoading(Object obj) {
        int i = this.a;
    }

    public void onSuccess(Object obj) {
        JSONObject optJSONObject;
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                TransferResp transferResp = (TransferResp) obj;
                String orderStatus = transferResp.getOrderStatus();
                int i = RequestMoneyFinishSuccessActivity.o;
                CommonSuccessActivity commonSuccessActivity = (RequestMoneyFinishSuccessActivity) obj2;
                commonSuccessActivity.O0(orderStatus, transferResp);
                if (!TextUtils.isEmpty(transferResp.getTitle())) {
                    commonSuccessActivity.i.L.setText(Html.fromHtml(transferResp.getTitle()));
                }
                if (commonSuccessActivity.m != null) {
                    if (!TextUtils.isEmpty(transferResp.getTransId())) {
                        TransferResp.DisplayItemBean displayItemBean = new TransferResp.DisplayItemBean();
                        displayItemBean.setKey("transId");
                        displayItemBean.setLabel(commonSuccessActivity.getString(R.string.transaction_number));
                        displayItemBean.setValue(transferResp.getTransId());
                        if (!commonSuccessActivity.m.getData().contains(displayItemBean)) {
                            commonSuccessActivity.m.addData(0, displayItemBean);
                        }
                    }
                    if (!TextUtils.isEmpty(transferResp.getServiceNumber())) {
                        TransferResp.DisplayItemBean displayItemBean2 = new TransferResp.DisplayItemBean();
                        displayItemBean2.setKey("serviceNumber");
                        displayItemBean2.setLabel(commonSuccessActivity.getString(R.string.service_number));
                        displayItemBean2.setValue(transferResp.getServiceNumber());
                        if (!commonSuccessActivity.m.getData().contains(displayItemBean2)) {
                            commonSuccessActivity.m.addData(0, displayItemBean2);
                        }
                    }
                }
                if ("Success".equals(transferResp.getOrderStatus())) {
                    commonSuccessActivity.i.c.setText(commonSuccessActivity.getString(R$string.done));
                }
                if ("Processing".equals(transferResp.getOrderStatus())) {
                    A.h(commonSuccessActivity, 5000);
                }
                List displayItems = transferResp.getDisplayItems();
                f fVar = commonSuccessActivity.m;
                if (fVar != null) {
                    fVar.setList(displayItems);
                    return;
                }
                return;
            default:
                JSONObject jSONObject = (JSONObject) obj;
                jSONObject.toString();
                h.b();
                if (TextUtils.equals(jSONObject.optString("businessType"), "js_fun_mandate_success") && (optJSONObject = jSONObject.optJSONObject("mandateResponse")) != null) {
                    ((i) obj2).success(optJSONObject);
                    return;
                }
                return;
        }
    }

    public v(HelpRecyclerAdapter helpRecyclerAdapter, HelpChildRecyclerAdapter helpChildRecyclerAdapter) {
        this.a = 2;
        this.b = helpRecyclerAdapter;
    }

    private final void c(BaseException baseException) {
    }
}
