package com.huawei.requestmoney;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.huawei.digitalpayment.customer.httplib.response.CheckoutResp;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.module_checkout.R;
import com.huawei.payment.mvvm.DataBindingActivity;
import i7.a;
import java.util.Map;
import o0.b;

public final class q implements a.b<TransferResp> {
    public final /* synthetic */ RequestMoneyConfirmActivity a;

    public q(RequestMoneyConfirmActivity requestMoneyConfirmActivity) {
        this.a = requestMoneyConfirmActivity;
    }

    public final /* synthetic */ void a(int i, String str) {
    }

    public final /* synthetic */ void b(CheckoutResp checkoutResp) {
    }

    public final void onCancel() {
    }

    public final void onSuccess(Object obj) {
        TransferResp transferResp = (TransferResp) obj;
        DataBindingActivity dataBindingActivity = this.a;
        Bundle bundle = new Bundle();
        bundle.putString("buttonText", dataBindingActivity.getString(R.string.baselib_finished));
        bundle.putSerializable("TransferResp", transferResp);
        b.d((Activity) null, "/basicUiModule/commonFinishSuccess", bundle, (Map) null);
        dataBindingActivity.setResult(17, new Intent());
        x7.a aVar = x7.a.g;
        R1.a aVar2 = aVar.c;
        if (aVar2 != null) {
            aVar2.onSuccess(transferResp);
            aVar.b = null;
        }
        dataBindingActivity.finish();
    }
}
