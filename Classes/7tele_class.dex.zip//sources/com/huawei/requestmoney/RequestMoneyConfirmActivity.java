package com.huawei.requestmoney;

import M1.d;
import V1.h;
import V7.e;
import Y1.a;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.blankj.utilcode.util.k;
import com.huawei.common.display.DisplayAdapter;
import com.huawei.common.display.DisplayItem;
import com.huawei.digitalpayment.customer.httplib.response.ScanQrResp;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import com.huawei.requestmoney.bean.MerchantInfoResp;
import com.huawei.requestmoney.databinding.ActivityRequestMoneyConfirmBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import o0.b;

@Route(path = "/requestMoneyModule/requestMoneyConfirm")
public class RequestMoneyConfirmActivity extends DataBindingActivity<ActivityRequestMoneyConfirmBinding, RequestMoneyViewModel> {
    public static final /* synthetic */ int h = 0;
    public String d;
    public Map<String, String> e;
    public final String[] f = {"shortCode", "msisdn", "operatorId", "notes", "publicName"};
    public MerchantInfoResp g;

    public final int C0() {
        return R$layout.activity_request_money_confirm;
    }

    public final ArrayList E0(ScanQrResp scanQrResp) {
        if (scanQrResp == null) {
            return new ArrayList();
        }
        String[] strArr = {getResources().getString(R$string.amount), getResources().getString(R$string.short_code), getResources().getString(R$string.receiver_msisdn), getResources().getString(R$string.request_operator), getResources().getString(R$string.note), getResources().getString(R$string.receive_name)};
        Map params = scanQrResp.getParams();
        ArrayList arrayList = new ArrayList();
        for (String str : params.keySet()) {
            int i = 0;
            while (true) {
                String[] strArr2 = this.f;
                if (i < strArr2.length) {
                    if (TextUtils.equals(str, strArr2[i])) {
                        arrayList.add(new DisplayItem(strArr[i], (String) params.get(str)));
                    }
                    i++;
                }
            }
        }
        return arrayList;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.requestmoney.RequestMoneyConfirmActivity, android.app.Activity, com.huawei.payment.mvvm.DataBindingActivity, androidx.fragment.app.FragmentActivity] */
    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        RequestMoneyConfirmActivity.super.onActivityResult(i, i2, intent);
        if (i2 == -1 && intent != null) {
            setResult(-1, intent);
            finish();
        }
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [android.content.Context, com.huawei.requestmoney.RequestMoneyConfirmActivity, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        RequestMoneyConfirmActivity.super.onCreate(bundle);
        MerchantInfoResp merchantInfoResp = (MerchantInfoResp) getIntent().getSerializableExtra("merchantInfoResp");
        this.g = merchantInfoResp;
        Class<AppService> cls = AppService.class;
        if (merchantInfoResp == null) {
            e.a(this, getString(R$string.payment), R.layout.common_toolbar);
            Intent intent = getIntent();
            if (intent != null) {
                try {
                    ScanQrResp scanQrResp = (ScanQrResp) k.a(intent.getStringExtra("params"), ScanQrResp.class);
                    this.b.b.setLayoutManager(new LinearLayoutManager(this));
                    DisplayAdapter displayAdapter = new DisplayAdapter();
                    this.b.b.setAdapter(displayAdapter);
                    this.b.a.setOnClickListener(new a(this, 3));
                    String l = b.c(cls).l();
                    TextView textView = this.b.c;
                    Locale locale = Locale.ENGLISH;
                    textView.setText("(" + l + ")");
                    displayAdapter.setList(E0(scanQrResp));
                    Map<String, String> params = scanQrResp.getParams();
                    this.e = params;
                    if (params != null) {
                        String str = params.get("amount");
                        this.d = str;
                        this.b.d.setText(str);
                    }
                } catch (Exception e2) {
                    e2.getMessage();
                    h.b();
                }
            }
        } else {
            e.a(this, getString(R$string.confirmation), R.layout.common_toolbar);
            this.b.c.setText(b.c(cls).l());
            this.b.d.setText(this.g.getAmount());
            this.b.e.setText(R$string.amount);
            List<DisplayItem> displayList = this.g.getDisplayList(this);
            this.b.b.setLayoutManager(new LinearLayoutManager(this));
            DisplayAdapter displayAdapter2 = new DisplayAdapter();
            this.b.b.setAdapter(displayAdapter2);
            displayAdapter2.setList(displayList);
            this.b.a.setOnClickListener(new Z7.a(this, 3));
            if (Build.VERSION.SDK_INT >= 23) {
                this.b.a.setBackgroundColor(d.a(this, R$color.colorPrimary));
            } else {
                this.b.a.setBackgroundColor(getResources().getColor(R$color.colorPrimary));
            }
            this.b.a.setText(getString(R$string.confirm));
        }
    }
}
