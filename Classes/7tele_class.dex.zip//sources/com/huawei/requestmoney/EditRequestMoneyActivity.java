package com.huawei.requestmoney;

import L3.a;
import S3.j;
import V1.k;
import V7.c;
import V7.e;
import W2.h;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.http.b;
import com.huawei.image.glide.Base64Mode;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import com.huawei.requestmoney.bean.RequestMoneyResp;
import com.huawei.requestmoney.databinding.ActivityEditRequestMoneyBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;

@Route(path = "/requestMoneyModule/editRequestMoney")
public class EditRequestMoneyActivity extends DataBindingActivity<ActivityEditRequestMoneyBinding, RequestMoneyViewModel> {
    public static final /* synthetic */ int i = 0;
    public RequestMoneyResp.RequestMoneyOrderInfoBean d;
    public String e;
    public String f;
    public String g;
    public String h;

    public final int C0() {
        return R$layout.activity_edit_request_money;
    }

    public final void E0(String str) {
        TextView textView;
        String str2;
        View rootView = this.b.d.getRootView();
        if (rootView != null && (textView = (TextView) rootView.findViewById(R$id.tv_length)) != null) {
            if (TextUtils.isEmpty(str)) {
                str2 = "0";
            } else {
                str2 = str.length() + "/50";
            }
            textView.setText(str2);
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, com.huawei.requestmoney.EditRequestMoneyActivity, com.huawei.payment.mvvm.DataBindingActivity, androidx.fragment.app.FragmentActivity] */
    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        byte[] byteArrayExtra;
        EditRequestMoneyActivity.super.onActivityResult(i2, i3, intent);
        if (i3 == -1 && intent != null && (byteArrayExtra = intent.getByteArrayExtra("pin")) != null) {
            String text = this.b.d.getText();
            this.f = this.b.b.getText();
            String text2 = this.b.c.getText();
            this.g = text2;
            this.g = h.b(text2);
            if (TextUtils.isEmpty(this.f)) {
                k.b(1, getString(R$string.please_enter_amount));
            } else if (TextUtils.isEmpty(this.g)) {
                k.b(1, getString(R$string.please_enter_phone_number));
            } else {
                HashMap hashMap = new HashMap();
                hashMap.put("requestMoneyOrderId", this.d.getRequestMoneyOrderId());
                hashMap.put("amount", this.f);
                hashMap.put("note", text);
                hashMap.put("initiatorPin", a.g(new String(byteArrayExtra, StandardCharsets.UTF_8)));
                hashMap.put("pinVersion", a.b.getPinKeyVersion());
                RequestMoneyViewModel requestMoneyViewModel = this.c;
                requestMoneyViewModel.j.setValue(c.c());
                b bVar = new b();
                bVar.addParams(hashMap);
                bVar.sendRequest(new j(requestMoneyViewModel, 4));
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v7, types: [com.huawei.requestmoney.k, android.text.TextWatcher] */
    public final void onCreate(@Nullable Bundle bundle) {
        EditRequestMoneyActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.edit_request), R.layout.common_toolbar);
        Intent intent = getIntent();
        if (intent != null) {
            this.d = (RequestMoneyResp.RequestMoneyOrderInfoBean) intent.getSerializableExtra("requestMoneyInfo");
            this.e = intent.getStringExtra("type");
        }
        if (this.d != null) {
            this.b.b.getEditText().setText(this.d.getAmount());
            EditText editText = this.b.c.getEditText();
            Locale locale = Locale.ENGLISH;
            String b = h.b(this.d.getPayerIdentifier());
            editText.setText("(251 " + b + ")");
            this.b.d.getEditText().setText(this.d.getSendRemark());
            E0(this.d.getSendRemark());
        }
        this.b.c.setOnIconListener(new X6.c(this, 3));
        this.b.a.setOnClickListener(new F0.h(this, 6));
        this.b.c.getEditText().setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        this.b.c.getEditText().setEnabled(false);
        this.b.c.getEditText().setClickable(false);
        View rootView = this.b.c.getRootView();
        TextView textView = (TextView) rootView.findViewById(R$id.tv_name);
        textView.setVisibility(0);
        textView.setText(this.d.getPayerName());
        Base64Mode consumerMode = Base64Mode.getConsumerMode(this.d.getPayerAvatar());
        int i2 = R$mipmap.icon_drawer_head;
        y5.b.a(consumerMode, (ImageView) rootView.findViewById(R$id.iv_icon_left), i2, i2);
        this.b.b.getEditText().setFilters(new InputFilter[]{new t4.a()});
        String l = o0.b.c(AppService.class).l();
        this.h = l;
        ((TextView) this.b.b.findViewById(R$id.tv_unit)).setText(l);
        this.b.d.getEditText().addTextChangedListener(new k(this));
        this.c.j.observe(this, new N4.h(this, 2));
    }
}
