package com.huawei.requestmoney.view;

import V6.b;
import V6.d;
import Y1.a;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.huawei.common.display.DisplayItem;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.ethiopia.finance.loan.activity.f;
import com.huawei.requestmoney.R$id;
import com.huawei.requestmoney.R$mipmap;
import kotlin.jvm.internal.h;

public final class TypeSelectView extends CommonInputView {
    public static final /* synthetic */ int C0 = 0;
    public TextView A;
    public ImageView B;
    public DisplayItem B0;
    public ImageView C;
    public ImageView H;
    public DisplayItem L;
    public DisplayItem M;
    public DisplayItem Q;
    public TextView y;
    public TextView z;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public TypeSelectView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
        h.f(context, "context");
    }

    public final void c() {
        DisplayItem displayItem = this.L;
        String str = null;
        if (displayItem != null) {
            this.B0 = displayItem;
            EditText editText = getEditText();
            DisplayItem displayItem2 = this.B0;
            if (displayItem2 != null) {
                str = displayItem2.getTitle();
            }
            editText.setText(str);
            this.B.setImageResource(R$mipmap.standard_checkbox_selected);
            ImageView imageView = this.H;
            int i = R$mipmap.standard_checkbox_unselected;
            imageView.setImageResource(i);
            this.C.setImageResource(i);
            return;
        }
        h.m("leftItem");
        throw null;
    }

    public final void d() {
        DisplayItem displayItem = this.M;
        String str = null;
        if (displayItem != null) {
            this.B0 = displayItem;
            EditText editText = getEditText();
            DisplayItem displayItem2 = this.B0;
            if (displayItem2 != null) {
                str = displayItem2.getTitle();
            }
            editText.setText(str);
            this.C.setImageResource(R$mipmap.standard_checkbox_selected);
            ImageView imageView = this.H;
            int i = R$mipmap.standard_checkbox_unselected;
            imageView.setImageResource(i);
            this.B.setImageResource(i);
            return;
        }
        h.m("midItem");
        throw null;
    }

    public final void e() {
        DisplayItem displayItem = this.Q;
        String str = null;
        if (displayItem != null) {
            this.B0 = displayItem;
            EditText editText = getEditText();
            DisplayItem displayItem2 = this.B0;
            if (displayItem2 != null) {
                str = displayItem2.getTitle();
            }
            editText.setText(str);
            this.H.setImageResource(R$mipmap.standard_checkbox_selected);
            ImageView imageView = this.B;
            int i = R$mipmap.standard_checkbox_unselected;
            imageView.setImageResource(i);
            this.C.setImageResource(i);
            return;
        }
        h.m("rightItem");
        throw null;
    }

    public final ImageView getIvLeft() {
        return this.B;
    }

    public final ImageView getIvMid() {
        return this.C;
    }

    public final ImageView getIvRight() {
        return this.H;
    }

    public final DisplayItem getSelectItem() {
        return this.B0;
    }

    public final TextView getTvLeft() {
        return this.y;
    }

    public final TextView getTvMid() {
        return this.A;
    }

    public final TextView getTvRight() {
        return this.z;
    }

    public final void setIvLeft(ImageView imageView) {
        h.f(imageView, "<set-?>");
        this.B = imageView;
    }

    public final void setIvMid(ImageView imageView) {
        h.f(imageView, "<set-?>");
        this.C = imageView;
    }

    public final void setIvRight(ImageView imageView) {
        h.f(imageView, "<set-?>");
        this.H = imageView;
    }

    public final void setTvLeft(TextView textView) {
        h.f(textView, "<set-?>");
        this.y = textView;
    }

    public final void setTvMid(TextView textView) {
        h.f(textView, "<set-?>");
        this.A = textView;
    }

    public final void setTvRight(TextView textView) {
        h.f(textView, "<set-?>");
        this.z = textView;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.requestmoney.view.TypeSelectView, android.view.View, java.lang.Object] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TypeSelectView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        h.f(context, "context");
        View findViewById = findViewById(R$id.tvLeft);
        h.e(findViewById, "findViewById(...)");
        this.y = (TextView) findViewById;
        View findViewById2 = findViewById(R$id.tvRight);
        h.e(findViewById2, "findViewById(...)");
        this.z = (TextView) findViewById2;
        View findViewById3 = findViewById(R$id.tvMid);
        h.e(findViewById3, "findViewById(...)");
        this.A = (TextView) findViewById3;
        View findViewById4 = findViewById(R$id.ivLeft);
        h.e(findViewById4, "findViewById(...)");
        this.B = (ImageView) findViewById4;
        View findViewById5 = findViewById(R$id.ivMid);
        h.e(findViewById5, "findViewById(...)");
        this.C = (ImageView) findViewById5;
        View findViewById6 = findViewById(R$id.ivRight);
        h.e(findViewById6, "findViewById(...)");
        this.H = (ImageView) findViewById6;
        this.y.setOnClickListener(new a(this, 4));
        this.B.setOnClickListener(new b(this, 7));
        this.A.setOnClickListener(new com.huawei.common.widget.banner.b(this, 8));
        this.C.setOnClickListener(new D4.h(this, 4));
        this.z.setOnClickListener(new d(this, 5));
        this.H.setOnClickListener(new f(this, 6));
    }
}
