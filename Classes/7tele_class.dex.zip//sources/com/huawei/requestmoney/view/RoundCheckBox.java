package com.huawei.requestmoney.view;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatCheckBox;
import d2.a;

public class RoundCheckBox extends AppCompatCheckBox {
    public final a a;

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public RoundCheckBox(Context context) {
        super(context);
        this.a = new a(this, (AttributeSet) null);
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CheckBox] */
    public final void draw(Canvas canvas) {
        this.a.getClass();
        a.a(canvas);
        RoundCheckBox.super.draw(canvas);
        this.a.b(canvas);
    }

    public a getBaseFilletView() {
        return this.a;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CheckBox] */
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        RoundCheckBox.super.onSizeChanged(i, i2, i3, i4);
        this.a.c(i, i2);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public RoundCheckBox(Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = new a(this, attributeSet);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public RoundCheckBox(Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = new a(this, attributeSet);
    }
}
