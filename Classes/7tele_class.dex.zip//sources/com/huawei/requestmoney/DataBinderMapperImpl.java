package com.huawei.requestmoney;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataBinderMapperImpl extends DataBinderMapper {
    public static final SparseIntArray a;

    public static class a {
        public static final SparseArray<String> a;

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            a = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    public static class b {
        public static final HashMap<String, Integer> a;

        static {
            HashMap<String, Integer> hashMap = new HashMap<>(13);
            a = hashMap;
            hashMap.put("layout/activity_add_black_or_favor_0", Integer.valueOf(R$layout.activity_add_black_or_favor));
            hashMap.put("layout/activity_black_or_favor_list_0", Integer.valueOf(R$layout.activity_black_or_favor_list));
            hashMap.put("layout/activity_create_request_money_0", Integer.valueOf(R$layout.activity_create_request_money));
            hashMap.put("layout/activity_edit_request_money_0", Integer.valueOf(R$layout.activity_edit_request_money));
            hashMap.put("layout/activity_request_money_0", Integer.valueOf(R$layout.activity_request_money));
            hashMap.put("layout/activity_request_money_confirm_0", Integer.valueOf(R$layout.activity_request_money_confirm));
            hashMap.put("layout/activity_request_money_detail_0", Integer.valueOf(R$layout.activity_request_money_detail));
            hashMap.put("layout/activity_request_money_partial_amount_0", Integer.valueOf(R$layout.activity_request_money_partial_amount));
            hashMap.put("layout/activity_request_money_qr_0", Integer.valueOf(R$layout.activity_request_money_qr));
            hashMap.put("layout/activity_setting_request_money_0", Integer.valueOf(R$layout.activity_setting_request_money));
            hashMap.put("layout/create_request_money_fragment_layout_0", Integer.valueOf(R$layout.create_request_money_fragment_layout));
            hashMap.put("layout/request_money_fragment_layout_0", Integer.valueOf(R$layout.request_money_fragment_layout));
            hashMap.put("layout/request_money_qr_pop_0", Integer.valueOf(R$layout.request_money_qr_pop));
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(13);
        a = sparseIntArray;
        sparseIntArray.put(R$layout.activity_add_black_or_favor, 1);
        sparseIntArray.put(R$layout.activity_black_or_favor_list, 2);
        sparseIntArray.put(R$layout.activity_create_request_money, 3);
        sparseIntArray.put(R$layout.activity_edit_request_money, 4);
        sparseIntArray.put(R$layout.activity_request_money, 5);
        sparseIntArray.put(R$layout.activity_request_money_confirm, 6);
        sparseIntArray.put(R$layout.activity_request_money_detail, 7);
        sparseIntArray.put(R$layout.activity_request_money_partial_amount, 8);
        sparseIntArray.put(R$layout.activity_request_money_qr, 9);
        sparseIntArray.put(R$layout.activity_setting_request_money, 10);
        sparseIntArray.put(R$layout.create_request_money_fragment_layout, 11);
        sparseIntArray.put(R$layout.request_money_fragment_layout, 12);
        sparseIntArray.put(R$layout.request_money_qr_pop, 13);
    }

    public final List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(9);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.huawei.biometric.DataBinderMapperImpl());
        arrayList.add(new com.huawei.common.DataBinderMapperImpl());
        arrayList.add(new com.huawei.digitalpayment.customer.baselib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.ethiopia.ethiopialib.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_basic_ui.DataBinderMapperImpl());
        arrayList.add(new com.huawei.module_checkout.DataBinderMapperImpl());
        arrayList.add(new com.huawei.payment.mvvm.DataBinderMapperImpl());
        return arrayList;
    }

    public final String convertBrIdToString(int i) {
        return a.a.get(i);
    }

    /* JADX WARNING: type inference failed for: r0v181, types: [com.huawei.requestmoney.databinding.ActivityRequestMoneyPartialAmountBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r8v19, types: [com.huawei.requestmoney.databinding.ActivityRequestMoneyQrBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: type inference failed for: r8v22, types: [com.huawei.requestmoney.databinding.CreateRequestMoneyFragmentLayoutBindingImpl, androidx.databinding.ViewDataBinding] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 3 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.databinding.ViewDataBinding getDataBinder(androidx.databinding.DataBindingComponent r27, android.view.View r28, int r29) {
        /*
            r26 = this;
            r1 = r27
            r14 = r28
            android.util.SparseIntArray r0 = a
            r2 = r29
            int r0 = r0.get(r2)
            r15 = 0
            if (r0 <= 0) goto L_0x002a
            java.lang.Object r2 = r28.getTag()
            if (r2 == 0) goto L_0x0550
            r5 = 13
            r6 = 14
            r7 = 16
            r12 = 6
            r13 = 7
            r3 = 5
            r8 = 4
            r9 = -1
            r11 = 0
            r20 = 2
            r21 = 1
            r4 = 3
            switch(r0) {
                case 1: goto L_0x04da;
                case 2: goto L_0x0479;
                case 3: goto L_0x0402;
                case 4: goto L_0x03b2;
                case 5: goto L_0x0354;
                case 6: goto L_0x02f3;
                case 7: goto L_0x025a;
                case 8: goto L_0x01a0;
                case 9: goto L_0x013e;
                case 10: goto L_0x00ff;
                case 11: goto L_0x00a9;
                case 12: goto L_0x0068;
                case 13: goto L_0x002d;
                default: goto L_0x002a;
            }
        L_0x002a:
            r0 = r15
            goto L_0x0558
        L_0x002d:
            java.lang.String r0 = "layout/request_money_qr_pop_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x005c
            com.huawei.requestmoney.databinding.RequestMoneyQrPopBindingImpl r0 = new com.huawei.requestmoney.databinding.RequestMoneyQrPopBindingImpl
            android.util.SparseIntArray r2 = com.huawei.requestmoney.databinding.RequestMoneyQrPopBindingImpl.b
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r8, r15, r2)
            r3 = r2[r4]
            com.huawei.common.widget.round.RoundImageView r3 = (com.huawei.common.widget.round.RoundImageView) r3
            r3 = r2[r21]
            com.huawei.common.widget.round.RoundTextView r3 = (com.huawei.common.widget.round.RoundTextView) r3
            r3 = r2[r20]
            android.widget.TextView r3 = (android.widget.TextView) r3
            r0.<init>(r1, r14, r11)
            r0.a = r9
            r1 = r2[r11]
            com.huawei.common.widget.round.RoundLinearLayout r1 = (com.huawei.common.widget.round.RoundLinearLayout) r1
            r1.setTag(r15)
            r0.setRootTag(r14)
            r0.invalidateAll()
            return r0
        L_0x005c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for request_money_qr_pop is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0068:
            java.lang.String r0 = "layout/request_money_fragment_layout_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x009d
            com.huawei.requestmoney.databinding.RequestMoneyFragmentLayoutBindingImpl r6 = new com.huawei.requestmoney.databinding.RequestMoneyFragmentLayoutBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.RequestMoneyFragmentLayoutBindingImpl.e
            java.lang.Object[] r0 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r4, r15, r0)
            r2 = r0[r20]
            r3 = r2
            android.widget.LinearLayout r3 = (android.widget.LinearLayout) r3
            r2 = r0[r21]
            r4 = r2
            com.huawei.common.widget.round.RoundRecyclerView r4 = (com.huawei.common.widget.round.RoundRecyclerView) r4
            r0 = r0[r11]
            r5 = r0
            com.scwang.smart.refresh.layout.SmartRefreshLayout r5 = (com.scwang.smart.refresh.layout.SmartRefreshLayout) r5
            r0 = r6
            r1 = r27
            r2 = r28
            r0.<init>(r1, r2, r3, r4, r5)
            r6.d = r9
            com.scwang.smart.refresh.layout.SmartRefreshLayout r0 = r6.c
            r0.setTag(r15)
            r6.setRootTag(r14)
            r6.invalidateAll()
            return r6
        L_0x009d:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for request_money_fragment_layout is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x00a9:
            java.lang.String r0 = "layout/create_request_money_fragment_layout_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x00f3
            com.huawei.requestmoney.databinding.CreateRequestMoneyFragmentLayoutBindingImpl r7 = new com.huawei.requestmoney.databinding.CreateRequestMoneyFragmentLayoutBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.CreateRequestMoneyFragmentLayoutBindingImpl.g
            java.lang.Object[] r13 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r13, r15, r0)
            r0 = r13[r8]
            r5 = r0
            com.huawei.common.widget.input.CommonInputView r5 = (com.huawei.common.widget.input.CommonInputView) r5
            r0 = r13[r4]
            r4 = r0
            com.huawei.common.widget.input.CommonInputView r4 = (com.huawei.common.widget.input.CommonInputView) r4
            r0 = r13[r12]
            r6 = r0
            com.huawei.common.widget.input.CommonInputView r6 = (com.huawei.common.widget.input.CommonInputView) r6
            r0 = r13[r3]
            r8 = r0
            com.huawei.common.widget.input.CommonInputView r8 = (com.huawei.common.widget.input.CommonInputView) r8
            r0 = r13[r20]
            r12 = r0
            com.huawei.requestmoney.view.TypeSelectView r12 = (com.huawei.requestmoney.view.TypeSelectView) r12
            r0 = r13[r21]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r7
            r1 = r27
            r2 = r28
            r3 = r5
            r5 = r6
            r6 = r8
            r8 = r7
            r7 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r8.f = r9
            r0 = r13[r11]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r15)
            r8.setRootTag(r14)
            r8.invalidateAll()
            return r8
        L_0x00f3:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for create_request_money_fragment_layout is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x00ff:
            java.lang.String r0 = "layout/activity_setting_request_money_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0132
            com.huawei.requestmoney.databinding.ActivitySettingRequestMoneyBindingImpl r0 = new com.huawei.requestmoney.databinding.ActivitySettingRequestMoneyBindingImpl
            android.util.SparseIntArray r2 = com.huawei.requestmoney.databinding.ActivitySettingRequestMoneyBindingImpl.d
            java.lang.Object[] r2 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r3, r15, r2)
            r3 = r2[r21]
            com.huawei.common.widget.round.RoundLinearLayout r3 = (com.huawei.common.widget.round.RoundLinearLayout) r3
            r4 = r2[r4]
            com.huawei.common.widget.round.RoundLinearLayout r4 = (com.huawei.common.widget.round.RoundLinearLayout) r4
            r5 = r2[r20]
            android.widget.TextView r5 = (android.widget.TextView) r5
            r5 = r2[r8]
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0.<init>(r1, r14, r3, r4)
            r0.c = r9
            r1 = r2[r11]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r1.setTag(r15)
            r0.setRootTag(r14)
            r0.invalidateAll()
            return r0
        L_0x0132:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_setting_request_money is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x013e:
            java.lang.String r0 = "layout/activity_request_money_qr_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0194
            com.huawei.requestmoney.databinding.ActivityRequestMoneyQrBindingImpl r7 = new com.huawei.requestmoney.databinding.ActivityRequestMoneyQrBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityRequestMoneyQrBindingImpl.g
            r2 = 9
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r2, r15, r0)
            r0 = r16[r13]
            r5 = r0
            com.huawei.common.widget.round.RoundImageView r5 = (com.huawei.common.widget.round.RoundImageView) r5
            r0 = r16[r4]
            r4 = r0
            android.widget.LinearLayout r4 = (android.widget.LinearLayout) r4
            r0 = r16[r21]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = r16[r8]
            r6 = r0
            android.widget.TextView r6 = (android.widget.TextView) r6
            r0 = r16[r3]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = 8
            r0 = r16[r0]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r16[r12]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r16[r20]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r7
            r1 = r27
            r2 = r28
            r3 = r5
            r5 = r6
            r6 = r8
            r8 = r7
            r7 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r8.f = r9
            r0 = r16[r11]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0.setTag(r15)
            r8.setRootTag(r14)
            r8.invalidateAll()
            return r8
        L_0x0194:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_request_money_qr is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x01a0:
            java.lang.String r0 = "layout/activity_request_money_partial_amount_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x024e
            com.huawei.requestmoney.databinding.ActivityRequestMoneyPartialAmountBindingImpl r2 = new com.huawei.requestmoney.databinding.ActivityRequestMoneyPartialAmountBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityRequestMoneyPartialAmountBindingImpl.m
            r9 = 19
            java.lang.Object[] r24 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r9, r15, r0)
            r0 = 18
            r0 = r24[r0]
            r9 = r0
            com.huawei.common.widget.LoadingButton r9 = (com.huawei.common.widget.LoadingButton) r9
            r0 = r24[r3]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0 = r24[r7]
            r7 = r0
            com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText r7 = (com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText) r7
            r0 = r24[r4]
            r10 = r0
            com.huawei.common.widget.round.RoundImageView r10 = (com.huawei.common.widget.round.RoundImageView) r10
            r0 = r24[r6]
            r6 = r0
            android.widget.ImageView r6 = (android.widget.ImageView) r6
            r0 = 10
            r0 = r24[r0]
            r17 = r0
            android.widget.ImageView r17 = (android.widget.ImageView) r17
            r0 = 17
            r0 = r24[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = r24[r21]
            androidx.core.widget.NestedScrollView r0 = (androidx.core.widget.NestedScrollView) r0
            r0 = 8
            r0 = r24[r0]
            r19 = r0
            androidx.recyclerview.widget.RecyclerView r19 = (androidx.recyclerview.widget.RecyclerView) r19
            r0 = r24[r20]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = r24[r5]
            r20 = r0
            com.huawei.common.widget.round.RoundConstraintLayout r20 = (com.huawei.common.widget.round.RoundConstraintLayout) r20
            r0 = 9
            r0 = r24[r0]
            r18 = r0
            com.huawei.common.widget.round.RoundConstraintLayout r18 = (com.huawei.common.widget.round.RoundConstraintLayout) r18
            r0 = r24[r12]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r24[r13]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r24[r8]
            r21 = r0
            android.widget.TextView r21 = (android.widget.TextView) r21
            r0 = 15
            r0 = r24[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 11
            r0 = r24[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = 12
            r0 = r24[r0]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r2
            r1 = r27
            r8 = r2
            r2 = r28
            r3 = r9
            r4 = r7
            r5 = r10
            r7 = r17
            r10 = r8
            r8 = r19
            r14 = -1
            r9 = r20
            r25 = r10
            r10 = r18
            r22 = 0
            r11 = r12
            r12 = r13
            r13 = r21
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            r0 = r25
            r0.l = r14
            r1 = r24[r22]
            androidx.constraintlayout.widget.ConstraintLayout r1 = (androidx.constraintlayout.widget.ConstraintLayout) r1
            r2 = 0
            r1.setTag(r2)
            r14 = r28
            r0.setRootTag(r14)
            r0.invalidateAll()
            return r0
        L_0x024e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_request_money_partial_amount is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x025a:
            r10 = r9
            r22 = 0
            java.lang.String r0 = "layout/activity_request_money_detail_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x02e7
            com.huawei.requestmoney.databinding.ActivityRequestMoneyDetailBindingImpl r15 = new com.huawei.requestmoney.databinding.ActivityRequestMoneyDetailBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityRequestMoneyDetailBindingImpl.k
            r2 = 0
            java.lang.Object[] r23 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r7, r2, r0)
            r0 = r23[r6]
            r6 = r0
            android.widget.Button r6 = (android.widget.Button) r6
            r0 = 15
            r0 = r23[r0]
            r7 = r0
            android.widget.Button r7 = (android.widget.Button) r7
            r0 = r23[r5]
            r5 = r0
            android.widget.Button r5 = (android.widget.Button) r5
            r0 = 9
            r0 = r23[r0]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0 = r23[r3]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r0 = 10
            r0 = r23[r0]
            android.view.View r0 = (android.view.View) r0
            r0 = r23[r20]
            r9 = r0
            com.huawei.common.widget.round.RoundImageView r9 = (com.huawei.common.widget.round.RoundImageView) r9
            r0 = 12
            r0 = r23[r0]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = r23[r21]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = 11
            r0 = r23[r0]
            r16 = r0
            com.huawei.common.widget.recyclerview.HFRecyclerView r16 = (com.huawei.common.widget.recyclerview.HFRecyclerView) r16
            r0 = r23[r12]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r23[r8]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r23[r13]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r23[r4]
            r17 = r0
            android.widget.TextView r17 = (android.widget.TextView) r17
            r0 = 8
            r0 = r23[r0]
            r18 = r0
            android.widget.TextView r18 = (android.widget.TextView) r18
            r0 = r15
            r1 = r27
            r2 = r28
            r3 = r6
            r4 = r7
            r6 = r9
            r7 = r16
            r8 = r12
            r9 = r13
            r12 = r10
            r10 = r17
            r11 = r18
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            r15.j = r12
            r0 = r23[r22]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r15.setRootTag(r14)
            r15.invalidateAll()
            return r15
        L_0x02e7:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_request_money_detail is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x02f3:
            r10 = r9
            r22 = 0
            java.lang.String r0 = "layout/activity_request_money_confirm_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0348
            com.huawei.requestmoney.databinding.ActivityRequestMoneyConfirmBindingImpl r9 = new com.huawei.requestmoney.databinding.ActivityRequestMoneyConfirmBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityRequestMoneyConfirmBindingImpl.g
            r2 = 0
            r5 = 8
            java.lang.Object[] r15 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r5, r2, r0)
            r0 = r15[r13]
            r5 = r0
            com.huawei.common.widget.LoadingButton r5 = (com.huawei.common.widget.LoadingButton) r5
            r0 = r15[r20]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r0 = r15[r12]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = r15[r3]
            r6 = r0
            androidx.recyclerview.widget.RecyclerView r6 = (androidx.recyclerview.widget.RecyclerView) r6
            r0 = r15[r8]
            r7 = r0
            android.widget.TextView r7 = (android.widget.TextView) r7
            r0 = r15[r4]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r15[r21]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r9
            r1 = r27
            r2 = r28
            r3 = r5
            r4 = r6
            r5 = r7
            r6 = r8
            r7 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            r9.f = r10
            r0 = r15[r22]
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            r1 = 0
            r0.setTag(r1)
            r9.setRootTag(r14)
            r9.invalidateAll()
            return r9
        L_0x0348:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_request_money_confirm is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0354:
            r10 = r9
            r22 = 0
            java.lang.String r0 = "layout/activity_request_money_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x03a6
            com.huawei.requestmoney.databinding.ActivityRequestMoneyBindingImpl r7 = new com.huawei.requestmoney.databinding.ActivityRequestMoneyBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityRequestMoneyBindingImpl.f
            r2 = 0
            r5 = 8
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r5, r2, r0)
            r0 = r9[r13]
            r5 = r0
            android.widget.Button r5 = (android.widget.Button) r5
            r0 = r9[r21]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = r9[r20]
            androidx.constraintlayout.widget.Guideline r0 = (androidx.constraintlayout.widget.Guideline) r0
            r0 = r9[r12]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = r9[r4]
            r4 = r0
            com.huawei.requestmoney.view.RoundCheckBox r4 = (com.huawei.requestmoney.view.RoundCheckBox) r4
            r0 = r9[r8]
            r6 = r0
            com.huawei.requestmoney.view.RoundCheckBox r6 = (com.huawei.requestmoney.view.RoundCheckBox) r6
            r0 = r9[r3]
            r8 = r0
            androidx.viewpager2.widget.ViewPager2 r8 = (androidx.viewpager2.widget.ViewPager2) r8
            r0 = r7
            r1 = r27
            r2 = r28
            r3 = r5
            r5 = r6
            r6 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r10
            r0 = r9[r22]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r7.setRootTag(r14)
            r7.invalidateAll()
            return r7
        L_0x03a6:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_request_money is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x03b2:
            r10 = r9
            r22 = 0
            java.lang.String r0 = "layout/activity_edit_request_money_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x03f6
            com.huawei.requestmoney.databinding.ActivityEditRequestMoneyBindingImpl r7 = new com.huawei.requestmoney.databinding.ActivityEditRequestMoneyBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityEditRequestMoneyBindingImpl.f
            r2 = 0
            java.lang.Object[] r9 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r3, r2, r0)
            r0 = r9[r8]
            r3 = r0
            android.widget.Button r3 = (android.widget.Button) r3
            r0 = r9[r20]
            r5 = r0
            com.huawei.common.widget.input.CommonInputView r5 = (com.huawei.common.widget.input.CommonInputView) r5
            r0 = r9[r21]
            r6 = r0
            com.huawei.common.widget.input.CommonInputView r6 = (com.huawei.common.widget.input.CommonInputView) r6
            r0 = r9[r4]
            r8 = r0
            com.huawei.common.widget.input.CommonInputView r8 = (com.huawei.common.widget.input.CommonInputView) r8
            r0 = r7
            r1 = r27
            r2 = r28
            r4 = r5
            r5 = r6
            r6 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r7.e = r10
            r0 = r9[r22]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r7.setRootTag(r14)
            r7.invalidateAll()
            return r7
        L_0x03f6:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_edit_request_money is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0402:
            r10 = r9
            r22 = 0
            java.lang.String r0 = "layout/activity_create_request_money_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x046d
            com.huawei.requestmoney.databinding.ActivityCreateRequestMoneyBindingImpl r15 = new com.huawei.requestmoney.databinding.ActivityCreateRequestMoneyBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityCreateRequestMoneyBindingImpl.i
            r2 = 0
            r5 = 11
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r5, r2, r0)
            r0 = 10
            r0 = r16[r0]
            r5 = r0
            android.widget.Button r5 = (android.widget.Button) r5
            r0 = r16[r8]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = r16[r3]
            androidx.constraintlayout.widget.Guideline r0 = (androidx.constraintlayout.widget.Guideline) r0
            r0 = 9
            r0 = r16[r0]
            com.huawei.common.widget.round.RoundLinearLayout r0 = (com.huawei.common.widget.round.RoundLinearLayout) r0
            r0 = r16[r12]
            r6 = r0
            com.huawei.requestmoney.view.RoundCheckBox r6 = (com.huawei.requestmoney.view.RoundCheckBox) r6
            r0 = r16[r13]
            r7 = r0
            com.huawei.requestmoney.view.RoundCheckBox r7 = (com.huawei.requestmoney.view.RoundCheckBox) r7
            r0 = r16[r4]
            r8 = r0
            com.huawei.common.widget.round.RoundRecyclerView r8 = (com.huawei.common.widget.round.RoundRecyclerView) r8
            r0 = r16[r21]
            r9 = r0
            android.widget.TextView r9 = (android.widget.TextView) r9
            r0 = r16[r20]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = 8
            r0 = r16[r0]
            r13 = r0
            androidx.viewpager2.widget.ViewPager2 r13 = (androidx.viewpager2.widget.ViewPager2) r13
            r0 = r15
            r1 = r27
            r2 = r28
            r3 = r5
            r4 = r6
            r5 = r7
            r6 = r8
            r7 = r9
            r8 = r12
            r9 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r15.h = r10
            r0 = r16[r22]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r15.setRootTag(r14)
            r15.invalidateAll()
            return r15
        L_0x046d:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_create_request_money is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0479:
            r10 = r9
            r22 = 0
            java.lang.String r0 = "layout/activity_black_or_favor_list_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x04ce
            com.huawei.requestmoney.databinding.ActivityBlackOrFavorListBindingImpl r9 = new com.huawei.requestmoney.databinding.ActivityBlackOrFavorListBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityBlackOrFavorListBindingImpl.h
            r2 = 0
            r5 = 8
            java.lang.Object[] r15 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r5, r2, r0)
            r0 = r15[r21]
            r5 = r0
            androidx.constraintlayout.widget.ConstraintLayout r5 = (androidx.constraintlayout.widget.ConstraintLayout) r5
            r0 = r15[r4]
            r4 = r0
            android.widget.ImageView r4 = (android.widget.ImageView) r4
            r0 = r15[r13]
            r6 = r0
            android.widget.LinearLayout r6 = (android.widget.LinearLayout) r6
            r0 = r15[r12]
            r7 = r0
            com.huawei.common.widget.round.RoundRecyclerView r7 = (com.huawei.common.widget.round.RoundRecyclerView) r7
            r0 = r15[r3]
            r12 = r0
            android.widget.TextView r12 = (android.widget.TextView) r12
            r0 = r15[r20]
            android.widget.TextView r0 = (android.widget.TextView) r0
            r0 = r15[r8]
            r8 = r0
            android.widget.TextView r8 = (android.widget.TextView) r8
            r0 = r9
            r1 = r27
            r2 = r28
            r3 = r5
            r5 = r6
            r6 = r7
            r7 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r9.g = r10
            r0 = r15[r22]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r9.setRootTag(r14)
            r9.invalidateAll()
            return r9
        L_0x04ce:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_black_or_favor_list is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x04da:
            r10 = r9
            r22 = 0
            java.lang.String r0 = "layout/activity_add_black_or_favor_0"
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x0544
            com.huawei.requestmoney.databinding.ActivityAddBlackOrFavorBindingImpl r15 = new com.huawei.requestmoney.databinding.ActivityAddBlackOrFavorBindingImpl
            android.util.SparseIntArray r0 = com.huawei.requestmoney.databinding.ActivityAddBlackOrFavorBindingImpl.i
            r2 = 0
            r5 = 11
            java.lang.Object[] r16 = androidx.databinding.ViewDataBinding.mapBindings(r1, r14, r5, r2, r0)
            r0 = 10
            r0 = r16[r0]
            r5 = r0
            android.widget.Button r5 = (android.widget.Button) r5
            r0 = r16[r21]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = r16[r3]
            com.huawei.common.widget.round.RoundConstraintLayout r0 = (com.huawei.common.widget.round.RoundConstraintLayout) r0
            r0 = 8
            r0 = r16[r0]
            r6 = r0
            com.huawei.common.widget.input.CommonInputView r6 = (com.huawei.common.widget.input.CommonInputView) r6
            r0 = 9
            r0 = r16[r0]
            r7 = r0
            com.huawei.common.widget.input.CommonInputView r7 = (com.huawei.common.widget.input.CommonInputView) r7
            r0 = r16[r12]
            r9 = r0
            android.widget.ImageView r9 = (android.widget.ImageView) r9
            r0 = r16[r20]
            androidx.constraintlayout.widget.Guideline r0 = (androidx.constraintlayout.widget.Guideline) r0
            r0 = r16[r4]
            r12 = r0
            com.huawei.requestmoney.view.RoundCheckBox r12 = (com.huawei.requestmoney.view.RoundCheckBox) r12
            r0 = r16[r8]
            r8 = r0
            com.huawei.requestmoney.view.RoundCheckBox r8 = (com.huawei.requestmoney.view.RoundCheckBox) r8
            r0 = r16[r13]
            r13 = r0
            android.widget.TextView r13 = (android.widget.TextView) r13
            r0 = r15
            r1 = r27
            r2 = r28
            r3 = r5
            r4 = r6
            r5 = r7
            r6 = r9
            r7 = r12
            r9 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            r15.h = r10
            r0 = r16[r22]
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            r1 = 0
            r0.setTag(r1)
            r15.setRootTag(r14)
            r15.invalidateAll()
            return r15
        L_0x0544:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "The tag for activity_add_black_or_favor is invalid. Received: "
            java.lang.String r1 = androidx.camera.view.l.a(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0550:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "view must have a tag"
            r0.<init>(r1)
            throw r0
        L_0x0558:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.requestmoney.DataBinderMapperImpl.getDataBinder(androidx.databinding.DataBindingComponent, android.view.View, int):androidx.databinding.ViewDataBinding");
    }

    public final int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = b.a.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    public final ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i) {
        if (viewArr == null || viewArr.length == 0 || a.get(i) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}
