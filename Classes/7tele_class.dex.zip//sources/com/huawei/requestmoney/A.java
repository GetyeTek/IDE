package com.huawei.requestmoney;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import java.util.Map;
import o0.b;

public final /* synthetic */ class A implements View.OnClickListener {
    public final void onClick(View view) {
        int i = RequestMoneySettingActivity.d;
        Bundle bundle = new Bundle();
        bundle.putString("type", "BLACK");
        b.d((Activity) null, "/requestMoneyModule/blackOrFavorList", bundle, (Map) null);
    }
}
