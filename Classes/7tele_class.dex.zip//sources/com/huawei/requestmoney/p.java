package com.huawei.requestmoney;

import androidx.viewpager2.widget.ViewPager2;

public final class p extends ViewPager2.OnPageChangeCallback {
    public final /* synthetic */ RequestMoneyActivity a;

    public p(RequestMoneyActivity requestMoneyActivity) {
        this.a = requestMoneyActivity;
    }

    /* JADX WARNING: type inference failed for: r4v3, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v6, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v9, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v12, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v15, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v18, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v21, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v24, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public final void onPageSelected(int i) {
        int i2 = RequestMoneyActivity.f;
        RequestMoneyActivity requestMoneyActivity = this.a;
        requestMoneyActivity.b.d.setCurrentItem(i);
        if (i == 0) {
            requestMoneyActivity.b.c.setChecked(false);
            requestMoneyActivity.b.c.setClickable(true);
            requestMoneyActivity.b.b.setChecked(true);
            requestMoneyActivity.b.b.setClickable(false);
            return;
        }
        requestMoneyActivity.b.b.setChecked(false);
        requestMoneyActivity.b.b.setClickable(true);
        requestMoneyActivity.b.c.setChecked(true);
        requestMoneyActivity.b.c.setClickable(false);
    }
}
