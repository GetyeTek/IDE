package com.huawei.requestmoney;

import D1.i;
import V1.k;
import V7.c;
import V7.e;
import V7.f;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.http.BaseResp;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import com.huawei.requestmoney.databinding.ActivityAddBlackOrFavorBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;

@Route(path = "/requestMoneyModule/addBlackOrFavorList")
public class AddBlackOrFavorActivity extends DataBindingActivity<ActivityAddBlackOrFavorBinding, RequestMoneyViewModel> {
    public static final /* synthetic */ int e = 0;
    public String d;

    public class a implements Observer<c<BaseResp>> {
        public a() {
        }

        public final void onChanged(Object obj) {
            c cVar = (c) obj;
            FragmentActivity fragmentActivity = AddBlackOrFavorActivity.this;
            f.b(fragmentActivity, cVar);
            if (!cVar.d()) {
                if (cVar.b()) {
                    f.c(cVar);
                } else if (cVar.f()) {
                    fragmentActivity.setResult(-1);
                    k.a(R$string.success);
                    fragmentActivity.finish();
                }
            }
        }
    }

    public final int C0() {
        return R$layout.activity_add_black_or_favor;
    }

    /* JADX WARNING: type inference failed for: r5v4, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r5v7, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r5v20, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    public final void onCreate(@Nullable Bundle bundle) {
        AddBlackOrFavorActivity.super.onCreate(bundle);
        Intent intent = getIntent();
        if (intent != null) {
            String stringExtra = intent.getStringExtra("type");
            this.d = stringExtra;
            if (TextUtils.equals(stringExtra, "BLACK")) {
                e.a(this, getString(R$string.block_user), R.layout.common_toolbar);
                this.b.d.setVisibility(0);
                this.b.g.setVisibility(0);
            } else {
                e.a(this, getString(R$string.add_favorite), R.layout.common_toolbar);
            }
        }
        this.b.e.setOnCheckedChangeListener(new C0139a(this));
        this.b.f.setOnCheckedChangeListener(new C0140b(this));
        this.b.a.setOnClickListener(new P7.a(this, 7));
        this.b.b.setOnIconListener(new i(this, 6));
        this.b.b.getEditText().setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        this.b.e.setChecked(true);
        this.c.p.observe(this, new a());
    }
}
