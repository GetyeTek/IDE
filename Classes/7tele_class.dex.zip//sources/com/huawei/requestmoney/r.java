package com.huawei.requestmoney;

import android.text.TextUtils;
import android.view.View;
import com.google.android.gms.measurement.internal.c;
import com.huawei.requestmoney.bean.RequestMoneyResp;

public final /* synthetic */ class r implements View.OnClickListener {
    public final /* synthetic */ RequestMoneyDetailActivity a;
    public final /* synthetic */ View b;

    public /* synthetic */ r(RequestMoneyDetailActivity requestMoneyDetailActivity, View view) {
        this.a = requestMoneyDetailActivity;
        this.b = view;
    }

    public final void onClick(View view) {
        RequestMoneyResp.RequestMoneyOrderInfoBean requestMoneyOrderInfoBean;
        int i = RequestMoneyDetailActivity.i;
        RequestMoneyDetailActivity requestMoneyDetailActivity = this.a;
        requestMoneyDetailActivity.getClass();
        int i2 = R$id.tvBlock;
        View view2 = this.b;
        if (i2 == view2.getId()) {
            if (TextUtils.equals("1000", requestMoneyDetailActivity.f.getInitiatorIdentityType())) {
                requestMoneyDetailActivity.c.d(c.a("relateMsisdn", requestMoneyDetailActivity.f.getInitiatorIdentifier(), "relateType", "BLACK"));
                return;
            }
            requestMoneyDetailActivity.c.d(c.a("relateShortCode", requestMoneyDetailActivity.f.getInitiatorIdentifier(), "relateType", "BLACK"));
        } else if (R$id.btn_cancel == view2.getId()) {
            RequestMoneyResp.RequestMoneyOrderInfoBean requestMoneyOrderInfoBean2 = requestMoneyDetailActivity.f;
            if (requestMoneyOrderInfoBean2 != null) {
                requestMoneyDetailActivity.c.e(requestMoneyOrderInfoBean2.getRequestMoneyOrderId(), "cancel");
            }
        } else if (R$id.btn_reject == view2.getId() && (requestMoneyOrderInfoBean = requestMoneyDetailActivity.f) != null) {
            requestMoneyDetailActivity.c.e(requestMoneyOrderInfoBean.getRequestMoneyOrderId(), "rejected");
        }
    }
}
