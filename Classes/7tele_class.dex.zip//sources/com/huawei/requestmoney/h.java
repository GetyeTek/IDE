package com.huawei.requestmoney;

import android.view.View;

public final class h implements View.OnClickListener {
    public final /* synthetic */ CreateRequestMoneyActivity a;

    public h(CreateRequestMoneyActivity createRequestMoneyActivity) {
        this.a = createRequestMoneyActivity;
    }

    public final void onClick(View view) {
        int i = CreateRequestMoneyActivity.i;
        CreateRequestMoneyActivity createRequestMoneyActivity = this.a;
        if (createRequestMoneyActivity.b.g.getCurrentItem() == 0) {
            createRequestMoneyActivity.d.v0("FOR_SELF");
        } else {
            createRequestMoneyActivity.e.v0("FOR_MERCHANT");
        }
    }
}
