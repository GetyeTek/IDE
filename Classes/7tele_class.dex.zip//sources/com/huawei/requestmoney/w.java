package com.huawei.requestmoney;

import O2.a;
import android.text.Editable;
import android.text.TextUtils;

public final class w extends a {
    public final /* synthetic */ RequestMoneyPartialAmountActivity b;

    public w(RequestMoneyPartialAmountActivity requestMoneyPartialAmountActivity) {
        super(0);
        this.b = requestMoneyPartialAmountActivity;
    }

    public final void afterTextChanged(Editable editable) {
        int i = RequestMoneyPartialAmountActivity.g;
        RequestMoneyPartialAmountActivity requestMoneyPartialAmountActivity = this.b;
        requestMoneyPartialAmountActivity.b.a.setEnabled(!TextUtils.isEmpty(requestMoneyPartialAmountActivity.b.b.getText().toString().trim()));
    }
}
