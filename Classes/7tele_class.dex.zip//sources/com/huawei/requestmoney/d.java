package com.huawei.requestmoney;

import android.view.View;
import com.huawei.requestmoney.bean.BlackOrFavResp;

public final class d {
    public final /* synthetic */ BlackOrFavorListActivity a;

    public d(BlackOrFavorListActivity blackOrFavorListActivity) {
        this.a = blackOrFavorListActivity;
    }

    public final void a(View view, BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean paymentConsumerRelateIdentityModelListBean) {
        int i = R$id.tvUnBlock;
        int id = view.getId();
        BlackOrFavorListActivity blackOrFavorListActivity = this.a;
        if (i == id) {
            BlackOrFavorListActivity.E0(blackOrFavorListActivity, view, blackOrFavorListActivity.getResources().getString(R$string.do_you_want_to_unblock_the_requester), paymentConsumerRelateIdentityModelListBean);
        } else if (R$id.tvRemove == view.getId()) {
            BlackOrFavorListActivity.E0(blackOrFavorListActivity, view, blackOrFavorListActivity.getResources().getString(R$string.do_you_want_to_remove_the_favorite_user), paymentConsumerRelateIdentityModelListBean);
        }
    }
}
