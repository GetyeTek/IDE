package com.huawei.requestmoney;

import androidx.viewpager2.widget.ViewPager2;

public final class j extends ViewPager2.OnPageChangeCallback {
    public final /* synthetic */ CreateRequestMoneyActivity a;

    public j(CreateRequestMoneyActivity createRequestMoneyActivity) {
        this.a = createRequestMoneyActivity;
    }

    public final void onPageSelected(int i) {
        int i2 = CreateRequestMoneyActivity.i;
        this.a.b.g.setCurrentItem(i);
    }
}
