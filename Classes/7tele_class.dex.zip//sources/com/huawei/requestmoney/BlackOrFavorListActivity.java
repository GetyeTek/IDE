package com.huawei.requestmoney;

import D1.l;
import D1.o;
import G5.a;
import V7.c;
import V7.e;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.digitalpayment.schedule.activity.n;
import com.huawei.http.b;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import com.huawei.requestmoney.adapter.BlackOrFavAdapter;
import com.huawei.requestmoney.databinding.ActivityBlackOrFavorListBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import java.util.HashMap;

@Route(path = "/requestMoneyModule/blackOrFavorList")
public class BlackOrFavorListActivity extends DataBindingActivity<ActivityBlackOrFavorListBinding, RequestMoneyViewModel> {
    public static final /* synthetic */ int g = 0;
    public String d;
    public BlackOrFavAdapter e;
    public boolean f;

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.requestmoney.BlackOrFavorListActivity, androidx.fragment.app.FragmentActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void E0(com.huawei.requestmoney.BlackOrFavorListActivity r3, android.view.View r4, java.lang.String r5, com.huawei.requestmoney.bean.BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean r6) {
        /*
            int r0 = com.huawei.requestmoney.R$string.cancel
            java.lang.String r0 = r3.getString(r0)
            int r1 = com.huawei.requestmoney.R$string.confirm
            java.lang.String r1 = r3.getString(r1)
            com.huawei.requestmoney.c r2 = new com.huawei.requestmoney.c
            r2.<init>(r3, r4, r6)
            com.huawei.common.widget.dialog.TipsDialog r4 = new com.huawei.common.widget.dialog.TipsDialog
            r4.<init>()
            r6 = 0
            r4.g = r6
            r4.h = r5
            r4.i = r0
            r4.j = r1
            r4.k = r6
            r4.l = r2
            androidx.fragment.app.FragmentManager r3 = r3.getSupportFragmentManager()
            java.lang.String r5 = "tipsDialog"
            r4.show(r3, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.huawei.requestmoney.BlackOrFavorListActivity.E0(com.huawei.requestmoney.BlackOrFavorListActivity, android.view.View, java.lang.String, com.huawei.requestmoney.bean.BlackOrFavResp$PaymentConsumerRelateIdentityModelListBean):void");
    }

    public final int C0() {
        return R$layout.activity_black_or_favor_list;
    }

    public final void F0() {
        HashMap hashMap = new HashMap();
        hashMap.put("relateType", this.d);
        RequestMoneyViewModel requestMoneyViewModel = this.c;
        requestMoneyViewModel.n.setValue(c.c());
        b bVar = new b();
        bVar.addParams(hashMap);
        bVar.sendRequest(new Y6.b(requestMoneyViewModel, 3));
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        BlackOrFavorListActivity.super.onActivityResult(i, i2, intent);
        if (i2 == -1 && i == 4 && this.c != null) {
            F0();
        }
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [android.content.Context, com.huawei.requestmoney.BlackOrFavorListActivity, androidx.lifecycle.LifecycleOwner, java.lang.Object, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        BlackOrFavorListActivity.super.onCreate(bundle);
        Intent intent = getIntent();
        if (intent != null) {
            String stringExtra = intent.getStringExtra("type");
            this.d = stringExtra;
            if (TextUtils.isEmpty(stringExtra) || !TextUtils.equals(this.d, "BLACK")) {
                this.b.e.setText(getString(R$string.add_user));
                e.a(this, getString(R$string.add_favorite), R.layout.common_toolbar);
                this.b.a.setVisibility(8);
                this.b.e.setOnClickListener(new o(this, 7));
            } else {
                int i = R$string.block_user;
                e.a(this, getString(i), R.layout.common_toolbar);
                this.b.e.setText(getString(i));
                this.b.e.setOnClickListener(new a(this, 6));
            }
        }
        if (TextUtils.isEmpty(this.d) || !TextUtils.equals(this.d, "BLACK")) {
            this.b.f.setText("0 Favorite");
        } else {
            this.b.f.setText("0 Blocked");
        }
        BlackOrFavAdapter blackOrFavAdapter = new BlackOrFavAdapter();
        this.e = blackOrFavAdapter;
        blackOrFavAdapter.a = this.d;
        blackOrFavAdapter.b = new d(this);
        this.b.d.setAdapter(blackOrFavAdapter);
        this.b.b.setOnClickListener(new n(this, 3));
        this.c.n.observe(this, new com.huawei.bank.transfer.activity.c(this, 1));
        this.c.o.observe(this, new l(this, 4));
        this.c.p.observe(this, new b4.a(this, 2));
        F0();
    }
}
