package com.huawei.requestmoney;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.huawei.csm.viewmodel.ReportViewModel;
import com.huawei.digitalpayment.customer.homev6.activity.HomeActivity;
import f2.c;
import java.util.Map;
import o0.b;

public final /* synthetic */ class l implements View.OnClickListener {
    public final /* synthetic */ int a = 1;

    public /* synthetic */ l() {
    }

    public final void onClick(View view) {
        switch (this.a) {
            case 0:
                int i = RequestMoneyActivity.f;
                b.d((Activity) null, "/requestMoneyModule/settingRequestMoney", (Bundle) null, (Map) null);
                return;
            default:
                int i2 = HomeActivity.l;
                ReportViewModel reportViewModel = c.b;
                c.a.a.c("click_Lv1HomePg_specific_app", new String[]{"Nearby_fuel_station"});
                b.d((Activity) null, "merchant://1000000002", (Bundle) null, (Map) null);
                return;
        }
    }

    public /* synthetic */ l(RequestMoneyActivity requestMoneyActivity) {
    }
}
