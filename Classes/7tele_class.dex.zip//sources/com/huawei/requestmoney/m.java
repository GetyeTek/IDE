package com.huawei.requestmoney;

import android.widget.CompoundButton;

public final /* synthetic */ class m implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ RequestMoneyActivity a;

    public /* synthetic */ m(RequestMoneyActivity requestMoneyActivity) {
        this.a = requestMoneyActivity;
    }

    /* JADX WARNING: type inference failed for: r4v3, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v6, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v9, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v12, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        int i = RequestMoneyActivity.f;
        RequestMoneyActivity requestMoneyActivity = this.a;
        if (z) {
            requestMoneyActivity.b.c.setChecked(false);
            requestMoneyActivity.b.c.setClickable(true);
            requestMoneyActivity.b.b.setChecked(true);
            requestMoneyActivity.b.b.setClickable(false);
            requestMoneyActivity.b.d.setCurrentItem(0);
        }
    }
}
