package com.huawei.requestmoney;

import V7.e;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import androidx.annotation.Nullable;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import c6.o;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.d;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.requestmoney.databinding.ActivityRequestMoneyBinding;
import com.huawei.requestmoney.fragment.RequestMoneyFragment;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import java.util.ArrayList;

@Route(path = "/requestMoneyModule/requestMoney")
public class RequestMoneyActivity extends DataBindingActivity<ActivityRequestMoneyBinding, RequestMoneyViewModel> {
    public static final /* synthetic */ int f = 0;
    public RequestMoneyFragment d;
    public RequestMoneyFragment e;

    public final int C0() {
        return R$layout.activity_request_money;
    }

    public final void onActivityResult(int i, int i2, @Nullable Intent intent) {
        RequestMoneyViewModel requestMoneyViewModel;
        RequestMoneyViewModel requestMoneyViewModel2;
        RequestMoneyActivity.super.onActivityResult(i, i2, intent);
        if ((i != 1 && i != 3 && i2 != 17) || intent == null) {
            return;
        }
        if (this.b.d.getCurrentItem() == 0) {
            RequestMoneyFragment requestMoneyFragment = this.d;
            if (requestMoneyFragment != null && (requestMoneyViewModel2 = requestMoneyFragment.c) != null) {
                requestMoneyFragment.f = false;
                requestMoneyFragment.g = false;
                requestMoneyViewModel2.h("sender", "1");
                return;
            }
            return;
        }
        RequestMoneyFragment requestMoneyFragment2 = this.e;
        if (requestMoneyFragment2 != null && (requestMoneyViewModel = requestMoneyFragment2.c) != null) {
            requestMoneyFragment2.f = false;
            requestMoneyFragment2.g = false;
            requestMoneyViewModel.h("receiver", "1");
        }
    }

    /* JADX WARNING: type inference failed for: r5v8, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r5v11, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r5v27, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.TextView] */
    /* JADX WARNING: type inference failed for: r5v30, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.TextView] */
    public final void onCreate(@Nullable Bundle bundle) {
        RequestMoneyActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.request_money), R$layout.request_money_common_toolbar);
        ViewGroup viewGroup = (ViewGroup) this.a.findViewById(16908290);
        if (viewGroup != null) {
            int i = R$id.imageSetting;
            viewGroup.findViewById(i).setVisibility(0);
            viewGroup.findViewById(i).setOnClickListener(new l(this));
        }
        this.b.b.setOnCheckedChangeListener(new m(this));
        this.b.c.setOnCheckedChangeListener(new n(this));
        this.b.a.setOnClickListener(new o(this, 3));
        FragmentStateAdapter fragmentStateAdapter = new FragmentStateAdapter(this);
        ArrayList arrayList = new ArrayList();
        this.d = RequestMoneyFragment.v0("sender", new o(this));
        this.e = RequestMoneyFragment.v0("receiver", new d(this));
        arrayList.add(this.d);
        arrayList.add(this.e);
        fragmentStateAdapter.a = arrayList;
        fragmentStateAdapter.notifyDataSetChanged();
        this.b.d.setAdapter(fragmentStateAdapter);
        this.b.d.registerOnPageChangeCallback(new p(this));
        this.b.d.setOffscreenPageLimit(2);
        this.b.d.setCurrentItem(0);
        ? r5 = this.b.c;
        String string = getString(R$string.received);
        r5.setText(string + "(0)");
        ? r52 = this.b.b;
        String string2 = getString(R$string.sent);
        r52.setText(string2 + "(0)");
    }
}
