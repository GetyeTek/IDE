package com.huawei.requestmoney.bean;

import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class BlackOrFavResp extends BaseResp {
    private boolean blockAll;
    private List<PaymentConsumerRelateIdentityModelListBean> paymentConsumerRelateIdentityModelList;

    public static class PaymentConsumerRelateIdentityModelListBean implements Serializable {
        private String consumerId;
        private String consumerMsisdn;
        private String createOper;
        private long createTime;
        private long lastUpdateTime;
        private String relateIdentifier;
        private String relateIdentityAvatar;
        private String relateIdentityId;
        private String relateIdentityName;
        private String relateIdentityType;
        private String type;

        public String getConsumerId() {
            return this.consumerId;
        }

        public String getConsumerMsisdn() {
            return this.consumerMsisdn;
        }

        public String getCreateOper() {
            return this.createOper;
        }

        public long getCreateTime() {
            return this.createTime;
        }

        public long getLastUpdateTime() {
            return this.lastUpdateTime;
        }

        public String getRelateIdentifier() {
            return this.relateIdentifier;
        }

        public String getRelateIdentityAvatar() {
            return this.relateIdentityAvatar;
        }

        public String getRelateIdentityId() {
            return this.relateIdentityId;
        }

        public String getRelateIdentityName() {
            return this.relateIdentityName;
        }

        public String getRelateIdentityType() {
            return this.relateIdentityType;
        }

        public String getType() {
            return this.type;
        }

        public void setConsumerId(String str) {
            this.consumerId = str;
        }

        public void setConsumerMsisdn(String str) {
            this.consumerMsisdn = str;
        }

        public void setCreateOper(String str) {
            this.createOper = str;
        }

        public void setCreateTime(long j) {
            this.createTime = j;
        }

        public void setLastUpdateTime(long j) {
            this.lastUpdateTime = j;
        }

        public void setRelateIdentifier(String str) {
            this.relateIdentifier = str;
        }

        public void setRelateIdentityAvatar(String str) {
            this.relateIdentityAvatar = str;
        }

        public void setRelateIdentityId(String str) {
            this.relateIdentityId = str;
        }

        public void setRelateIdentityName(String str) {
            this.relateIdentityName = str;
        }

        public void setRelateIdentityType(String str) {
            this.relateIdentityType = str;
        }

        public void setType(String str) {
            this.type = str;
        }
    }

    public List<PaymentConsumerRelateIdentityModelListBean> getPaymentConsumerRelateIdentityModelList() {
        return this.paymentConsumerRelateIdentityModelList;
    }

    public boolean isBlockAll() {
        return this.blockAll;
    }

    public void setBlockAllFlag(boolean z) {
        this.blockAll = z;
    }

    public void setPaymentConsumerRelateIdentityModelList(List<PaymentConsumerRelateIdentityModelListBean> list) {
        this.paymentConsumerRelateIdentityModelList = list;
    }
}
