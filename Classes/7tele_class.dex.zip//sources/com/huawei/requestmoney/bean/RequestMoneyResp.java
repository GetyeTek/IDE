package com.huawei.requestmoney.bean;

import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.http.BaseResp;
import java.io.Serializable;
import java.util.List;

public class RequestMoneyResp extends BaseResp {
    private List<TransferResp.DisplayItemBean> displayItems;
    private RequestMoneyOrderInfoBean requestMoneyOrderInfo;
    private List<RequestMoneyOrderInfosBean> requestMoneyOrderInfos;
    private String totalCount;

    public static class RequestMoneyOrderInfoBean implements Serializable {
        private String amount;
        private String createTime;
        private String currency;
        private String initiatorIdentifier;
        private String initiatorIdentityId;
        private String initiatorIdentityType;
        private String note;
        private String payAmount;
        private String payeeAvatar;
        private String payeeIdentifier;
        private String payeeIdentityId;
        private String payeeIdentityType;
        private String payeeName;
        private String payerAvatar;
        private String payerIdentifier;
        private String payerIdentityId;
        private String payerIdentityType;
        private String payerName;
        private String paymentMethod;
        private String requestMoneyOrderId;
        private String sendRemark;
        private String status;
        private String statusDisplay;

        public String getAmount() {
            return this.amount;
        }

        public String getCreateTime() {
            return this.createTime;
        }

        public String getCurrency() {
            return this.currency;
        }

        public String getInitiatorIdentifier() {
            return this.initiatorIdentifier;
        }

        public String getInitiatorIdentityId() {
            return this.initiatorIdentityId;
        }

        public String getInitiatorIdentityType() {
            return this.initiatorIdentityType;
        }

        public String getNote() {
            return this.note;
        }

        public String getPayAmount() {
            return this.payAmount;
        }

        public String getPayeeAvatar() {
            return this.payeeAvatar;
        }

        public String getPayeeIdentifier() {
            return this.payeeIdentifier;
        }

        public String getPayeeIdentityId() {
            return this.payeeIdentityId;
        }

        public String getPayeeIdentityType() {
            return this.payeeIdentityType;
        }

        public String getPayeeName() {
            return this.payeeName;
        }

        public String getPayerAvatar() {
            return this.payerAvatar;
        }

        public String getPayerIdentifier() {
            return this.payerIdentifier;
        }

        public String getPayerIdentityId() {
            return this.payerIdentityId;
        }

        public String getPayerIdentityType() {
            return this.payerIdentityType;
        }

        public String getPayerName() {
            return this.payerName;
        }

        public String getPaymentMethod() {
            return this.paymentMethod;
        }

        public String getRequestMoneyOrderId() {
            return this.requestMoneyOrderId;
        }

        public String getSendRemark() {
            return this.sendRemark;
        }

        public String getStatus() {
            return this.status;
        }

        public String getStatusDisplay() {
            return this.statusDisplay;
        }

        public void setAmount(String str) {
            this.amount = str;
        }

        public void setCreateTime(String str) {
            this.createTime = str;
        }

        public void setCurrency(String str) {
            this.currency = str;
        }

        public void setInitiatorIdentifier(String str) {
            this.initiatorIdentifier = str;
        }

        public void setInitiatorIdentityId(String str) {
            this.initiatorIdentityId = str;
        }

        public void setInitiatorIdentityType(String str) {
            this.initiatorIdentityType = str;
        }

        public void setNote(String str) {
            this.note = str;
        }

        public void setPayAmount(String str) {
            this.payAmount = str;
        }

        public void setPayeeAvatar(String str) {
            this.payeeAvatar = str;
        }

        public void setPayeeIdentifier(String str) {
            this.payeeIdentifier = str;
        }

        public void setPayeeIdentityId(String str) {
            this.payeeIdentityId = str;
        }

        public void setPayeeIdentityType(String str) {
            this.payeeIdentityType = str;
        }

        public void setPayeeName(String str) {
            this.payeeName = str;
        }

        public void setPayerAvatar(String str) {
            this.payerAvatar = str;
        }

        public void setPayerIdentifier(String str) {
            this.payerIdentifier = str;
        }

        public void setPayerIdentityId(String str) {
            this.payerIdentityId = str;
        }

        public void setPayerIdentityType(String str) {
            this.payerIdentityType = str;
        }

        public void setPayerName(String str) {
            this.payerName = str;
        }

        public void setPaymentMethod(String str) {
            this.paymentMethod = str;
        }

        public void setRequestMoneyOrderId(String str) {
            this.requestMoneyOrderId = str;
        }

        public void setSendRemark(String str) {
            this.sendRemark = str;
        }

        public void setStatus(String str) {
            this.status = str;
        }

        public void setStatusDisplay(String str) {
            this.statusDisplay = str;
        }
    }

    public static class RequestMoneyOrderInfosBean implements Serializable {
        private String amount;
        private String currency;
        private String payAmount;
        private String payeeAvatar;
        private String payeeIdentifier;
        private String payeeIdentityId;
        private String payeeIdentityType;
        private String payeeName;
        private String payerAvatar;
        private String payerIdentifier;
        private String payerIdentityId;
        private String payerIdentityType;
        private String payerName;
        private String paymentMethod;
        private String requestMoneyOrderId;
        private String status;
        private String statusDisplay;

        public String getAmount() {
            return this.amount;
        }

        public String getCurrency() {
            return this.currency;
        }

        public String getPayAmount() {
            return this.payAmount;
        }

        public String getPayeeAvatar() {
            return this.payeeAvatar;
        }

        public String getPayeeIdentifier() {
            return this.payeeIdentifier;
        }

        public String getPayeeIdentityId() {
            return this.payeeIdentityId;
        }

        public String getPayeeIdentityType() {
            return this.payeeIdentityType;
        }

        public String getPayeeName() {
            return this.payeeName;
        }

        public String getPayerAvatar() {
            return this.payerAvatar;
        }

        public String getPayerIdentifier() {
            return this.payerIdentifier;
        }

        public String getPayerIdentityId() {
            return this.payerIdentityId;
        }

        public String getPayerIdentityType() {
            return this.payerIdentityType;
        }

        public String getPayerName() {
            return this.payerName;
        }

        public String getPaymentMethod() {
            return this.paymentMethod;
        }

        public String getRequestMoneyOrderId() {
            return this.requestMoneyOrderId;
        }

        public String getStatus() {
            return this.status;
        }

        public String getStatusDisplay() {
            return this.statusDisplay;
        }

        public void setAmount(String str) {
            this.amount = str;
        }

        public void setCurrency(String str) {
            this.currency = str;
        }

        public void setPayAmount(String str) {
            this.payAmount = str;
        }

        public void setPayeeAvatar(String str) {
            this.payeeAvatar = str;
        }

        public void setPayeeIdentifier(String str) {
            this.payeeIdentifier = str;
        }

        public void setPayeeIdentityId(String str) {
            this.payeeIdentityId = str;
        }

        public void setPayeeIdentityType(String str) {
            this.payeeIdentityType = str;
        }

        public void setPayeeName(String str) {
            this.payeeName = str;
        }

        public void setPayerAvatar(String str) {
            this.payerAvatar = str;
        }

        public void setPayerIdentifier(String str) {
            this.payerIdentifier = str;
        }

        public void setPayerIdentityId(String str) {
            this.payerIdentityId = str;
        }

        public void setPayerIdentityType(String str) {
            this.payerIdentityType = str;
        }

        public void setPayerName(String str) {
            this.payerName = str;
        }

        public void setPaymentMethod(String str) {
            this.paymentMethod = str;
        }

        public void setRequestMoneyOrderId(String str) {
            this.requestMoneyOrderId = str;
        }

        public void setStatus(String str) {
            this.status = str;
        }

        public void setStatusDisplay(String str) {
            this.statusDisplay = str;
        }
    }

    public List<TransferResp.DisplayItemBean> getDisplayItems() {
        return this.displayItems;
    }

    public RequestMoneyOrderInfoBean getRequestMoneyOrderInfo() {
        return this.requestMoneyOrderInfo;
    }

    public List<RequestMoneyOrderInfosBean> getRequestMoneyOrderInfos() {
        return this.requestMoneyOrderInfos;
    }

    public String getTotalCount() {
        return this.totalCount;
    }

    public void setDisplayItems(List<TransferResp.DisplayItemBean> list) {
        this.displayItems = list;
    }

    public void setRequestMoneyOrderInfo(RequestMoneyOrderInfoBean requestMoneyOrderInfoBean) {
        this.requestMoneyOrderInfo = requestMoneyOrderInfoBean;
    }

    public void setRequestMoneyOrderInfos(List<RequestMoneyOrderInfosBean> list) {
        this.requestMoneyOrderInfos = list;
    }

    public void setTotalCount(String str) {
        this.totalCount = str;
    }
}
