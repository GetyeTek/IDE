package com.huawei.requestmoney.bean;

import android.content.Context;
import com.huawei.common.display.DisplayItem;
import com.huawei.http.BaseResp;
import com.huawei.requestmoney.R$string;
import java.util.ArrayList;
import java.util.List;

public class MerchantInfoResp extends BaseResp {
    private String amount;
    private String merchantName;
    private String note;
    private String paymentMethod;
    private String receiver;
    private String receiverName;
    private String shortCode;

    public String getAmount() {
        return this.amount;
    }

    public List<DisplayItem> getDisplayList(Context context) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DisplayItem(context.getString(R$string.receiver), this.receiver));
        arrayList.add(new DisplayItem(context.getString(R$string.receiver_name), this.receiverName));
        arrayList.add(new DisplayItem(context.getString(R$string.merchant_name), this.merchantName));
        arrayList.add(new DisplayItem(context.getString(R$string.payment_method), this.paymentMethod));
        arrayList.add(new DisplayItem(context.getString(R$string.short_code), this.shortCode));
        arrayList.add(new DisplayItem(context.getString(R$string.note), this.note));
        return arrayList;
    }

    public String getMerchantName() {
        return this.merchantName;
    }

    public String getNote() {
        return this.note;
    }

    public String getPaymentMethod() {
        return this.paymentMethod;
    }

    public String getReceiver() {
        return this.receiver;
    }

    public String getReceiverName() {
        return this.receiverName;
    }

    public String getShortCode() {
        return this.shortCode;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setMerchantName(String str) {
        this.merchantName = str;
    }

    public void setNote(String str) {
        this.note = str;
    }

    public void setPaymentMethod(String str) {
        this.paymentMethod = str;
    }

    public void setReceiver(String str) {
        this.receiver = str;
    }

    public void setReceiverName(String str) {
        this.receiverName = str;
    }

    public void setShortCode(String str) {
        this.shortCode = str;
    }
}
