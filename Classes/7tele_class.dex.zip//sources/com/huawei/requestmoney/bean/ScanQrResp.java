package com.huawei.requestmoney.bean;

import com.huawei.http.BaseResp;
import java.util.HashMap;
import java.util.Map;

public class ScanQrResp extends BaseResp {
    private String amount;
    private String barCode;
    private String businessType;
    private String execute;
    private String expiredTime;
    private String fuelType;
    private String ownerIdentityId;
    private String ownerMsisdn;
    private Map<String, String> params;
    private String plateNumber;

    public void addParams(String str) {
        if (this.params == null) {
            this.params = new HashMap();
        }
        this.params.put("operationNumber", str);
    }

    public String getAmount() {
        return this.amount;
    }

    public String getBarCode() {
        return this.barCode;
    }

    public String getBusinessType() {
        return this.businessType;
    }

    public String getExecute() {
        return this.execute;
    }

    public String getExpiredTime() {
        return this.expiredTime;
    }

    public String getFuelType() {
        return this.fuelType;
    }

    public String getOwnerIdentityId() {
        return this.ownerIdentityId;
    }

    public String getOwnerMsisdn() {
        return this.ownerMsisdn;
    }

    public Map<String, String> getParams() {
        return this.params;
    }

    public String getPlateNumber() {
        return this.plateNumber;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setBarCode(String str) {
        this.barCode = str;
    }

    public void setBusinessType(String str) {
        this.businessType = str;
    }

    public void setExecute(String str) {
        this.execute = str;
    }

    public void setExpiredTime(String str) {
        this.expiredTime = str;
    }

    public void setFuelType(String str) {
        this.fuelType = str;
    }

    public void setOwnerIdentityId(String str) {
        this.ownerIdentityId = str;
    }

    public void setOwnerMsisdn(String str) {
        this.ownerMsisdn = str;
    }

    public void setParams(Map<String, String> map) {
        this.params = map;
    }

    public void setPlateNumber(String str) {
        this.plateNumber = str;
    }
}
