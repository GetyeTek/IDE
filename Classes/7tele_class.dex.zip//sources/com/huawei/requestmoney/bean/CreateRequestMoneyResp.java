package com.huawei.requestmoney.bean;

import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.http.BaseResp;
import java.util.List;

public class CreateRequestMoneyResp extends BaseResp {
    private List<TransferResp.DisplayItemBean> displayItems;
    private String paymentOrderId;
    private String qrCode;
    private String requestMoneyOrderId;

    public List<TransferResp.DisplayItemBean> getDisplayItems() {
        return this.displayItems;
    }

    public String getPaymentOrderId() {
        return this.paymentOrderId;
    }

    public String getQrCode() {
        return this.qrCode;
    }

    public String getRequestMoneyOrderId() {
        return this.requestMoneyOrderId;
    }

    public void setDisplayItems(List<TransferResp.DisplayItemBean> list) {
        this.displayItems = list;
    }

    public void setPaymentOrderId(String str) {
        this.paymentOrderId = str;
    }

    public void setQrCode(String str) {
        this.qrCode = str;
    }

    public void setRequestMoneyOrderId(String str) {
        this.requestMoneyOrderId = str;
    }
}
