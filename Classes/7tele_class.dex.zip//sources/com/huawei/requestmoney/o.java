package com.huawei.requestmoney;

import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.requestmoney.fragment.RequestMoneyFragment;

public final /* synthetic */ class o implements RequestMoneyFragment.b {
    public final /* synthetic */ RequestMoneyActivity a;

    public /* synthetic */ o(RequestMoneyActivity requestMoneyActivity) {
        this.a = requestMoneyActivity;
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.TextView] */
    public final void b(String str) {
        int i = RequestMoneyActivity.f;
        DataBindingActivity dataBindingActivity = this.a;
        ? r1 = dataBindingActivity.b.b;
        String string = dataBindingActivity.getString(R$string.sent);
        r1.setText(string + "(" + str + ")");
    }
}
