package com.huawei.requestmoney.viewmodel;

import S3.k;
import V7.c;
import a5.g;
import androidx.lifecycle.MutableLiveData;
import com.huawei.common.exception.BaseException;
import com.huawei.digitalpayment.customer.baselib.mvvm.BaseViewModel;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.http.BaseResp;
import com.huawei.requestmoney.bean.BlackOrFavResp;
import com.huawei.requestmoney.bean.CreateRequestMoneyResp;
import com.huawei.requestmoney.bean.MerchantInfoResp;
import com.huawei.requestmoney.bean.RequestMoneyResp;
import com.huawei.requestmoney.repository.RequestMoneyRepository;
import java.util.HashMap;

public class RequestMoneyViewModel extends BaseViewModel {
    public final MutableLiveData<c<RequestMoneyResp>> g = new MutableLiveData<>();
    public final MutableLiveData<c<CreateRequestMoneyResp>> h = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> i = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> j = new MutableLiveData<>();
    public final MutableLiveData<c<TransferResp>> k = new MutableLiveData<>();
    public final MutableLiveData<c<RequestMoneyResp>> l = new MutableLiveData<>();
    public final MutableLiveData<c<MerchantInfoResp>> m = new MutableLiveData<>();
    public final MutableLiveData<c<BlackOrFavResp>> n = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> o = new MutableLiveData<>();
    public final MutableLiveData<c<BaseResp>> p = new MutableLiveData<>();

    public class a implements R1.a<RequestMoneyResp> {
        public a() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            RequestMoneyViewModel.this.l.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            RequestMoneyViewModel.this.l.setValue(c.e((RequestMoneyResp) obj));
        }
    }

    public class b implements R1.a<BaseResp> {
        public b() {
        }

        public final /* synthetic */ void onComplete() {
        }

        public final void onError(BaseException baseException) {
            RequestMoneyViewModel.this.i.setValue(c.a(baseException));
        }

        public final /* synthetic */ void onLoading(Object obj) {
        }

        public final void onSuccess(Object obj) {
            RequestMoneyViewModel.this.i.setValue(c.e((BaseResp) obj));
        }
    }

    public final void d(HashMap hashMap) {
        this.p.setValue(c.c());
        com.huawei.http.b bVar = new com.huawei.http.b();
        bVar.addParams(hashMap);
        bVar.sendRequest(new k(this, 3));
    }

    public final void e(String str, String str2) {
        this.i.setValue(c.c());
        HashMap hashMap = new HashMap();
        hashMap.put("requestMoneyOrderId", str);
        hashMap.put("orderStatus", str2);
        com.huawei.http.b bVar = new com.huawei.http.b();
        bVar.addParams(hashMap);
        bVar.sendRequest(new b());
    }

    public final void f(HashMap hashMap) {
        this.o.setValue(c.c());
        com.huawei.http.b bVar = new com.huawei.http.b();
        bVar.addParams(hashMap);
        bVar.sendRequest(new W6.a(this, 2));
    }

    public final void g(String str, String str2) {
        this.l.setValue(c.c());
        HashMap hashMap = new HashMap();
        hashMap.put("requestType", str);
        hashMap.put("requestMoneyOrderId", str2);
        new RequestMoneyRepository(hashMap).sendRequest(new a());
    }

    public final void h(String str, String str2) {
        this.g.setValue(c.c());
        HashMap hashMap = new HashMap();
        hashMap.put("requestType", str);
        hashMap.put("startPage", str2);
        hashMap.put("pageLimit", "20");
        new RequestMoneyRepository(hashMap).sendRequest(new g(this, 1));
    }
}
