package com.huawei.requestmoney;

import android.widget.CompoundButton;

public final /* synthetic */ class n implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ RequestMoneyActivity a;

    public /* synthetic */ n(RequestMoneyActivity requestMoneyActivity) {
        this.a = requestMoneyActivity;
    }

    /* JADX WARNING: type inference failed for: r4v3, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v6, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v9, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v12, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        int i = RequestMoneyActivity.f;
        RequestMoneyActivity requestMoneyActivity = this.a;
        if (z) {
            requestMoneyActivity.b.b.setChecked(false);
            requestMoneyActivity.b.b.setClickable(true);
            requestMoneyActivity.b.c.setChecked(true);
            requestMoneyActivity.b.c.setClickable(false);
            requestMoneyActivity.b.d.setCurrentItem(1);
        }
    }
}
