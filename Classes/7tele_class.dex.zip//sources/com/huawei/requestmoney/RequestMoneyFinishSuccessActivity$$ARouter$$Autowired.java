package com.huawei.requestmoney;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class RequestMoneyFinishSuccessActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.requestmoney.RequestMoneyFinishSuccessActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (RequestMoneyFinishSuccessActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.paymentOrderId;
        } else {
            str = r4.getIntent().getExtras().getString("paymentOrderId", r4.paymentOrderId);
        }
        r4.paymentOrderId = str;
    }
}
