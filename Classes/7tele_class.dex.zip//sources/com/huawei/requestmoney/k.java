package com.huawei.requestmoney;

import O2.a;
import android.annotation.SuppressLint;
import android.text.Editable;

public final class k extends a {
    public final /* synthetic */ EditRequestMoneyActivity b;

    public k(EditRequestMoneyActivity editRequestMoneyActivity) {
        super(1);
        this.b = editRequestMoneyActivity;
    }

    @SuppressLint({"DefaultLocale"})
    public final void afterTextChanged(Editable editable) {
        String obj = editable.toString();
        int i = EditRequestMoneyActivity.i;
        this.b.E0(obj);
    }
}
