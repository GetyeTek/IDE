package com.huawei.requestmoney;

import W2.h;
import android.view.View;
import androidx.annotation.NonNull;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.huawei.requestmoney.bean.BlackOrFavResp;
import java.util.List;

public final class i implements OnItemClickListener {
    public final /* synthetic */ CreateRequestMoneyActivity a;

    public i(CreateRequestMoneyActivity createRequestMoneyActivity) {
        this.a = createRequestMoneyActivity;
    }

    public final void onItemClick(@NonNull BaseQuickAdapter<?, ?> baseQuickAdapter, @NonNull View view, int i) {
        CreateRequestMoneyActivity createRequestMoneyActivity = this.a;
        List data = createRequestMoneyActivity.f.getData();
        if (createRequestMoneyActivity.b.g.getCurrentItem() == 0) {
            createRequestMoneyActivity.d.a.b.getEditText().setText(h.b(((BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean) data.get(i)).getRelateIdentifier()));
            return;
        }
        createRequestMoneyActivity.e.a.d.getEditText().setText(((BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean) data.get(i)).getRelateIdentifier());
    }
}
