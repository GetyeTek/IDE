package com.huawei.requestmoney;

import V7.c;
import V7.f;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.lifecycle.Observer;
import com.huawei.digitalpayment.customer.baselib.http.BaseResp;
import com.huawei.digitalpayment.customer.homev6.R;
import com.huawei.digitalpayment.customer.homev6.databinding.Homev6HomeHeaderBinding;
import com.huawei.digitalpayment.customer.homev6.fragment.HomeFragment;
import com.huawei.digitalpayment.customer.homev6.model.HomeBalance;
import com.huawei.digitalpayment.fuel.activity.FuelPaymentVehicleManageActivity;
import com.huawei.digitalpayment.fuel.viewmodel.FuelPaymentVehicleMangeViewModel;
import com.huawei.digitalpayment.topup.adapter.VehicleManageAdapter;
import com.huawei.ethiopia.component.service.AppService;
import com.huawei.kbz.chat.contact.P;
import com.huawei.requestmoney.bean.BlackOrFavResp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import m3.d;
import o0.b;
import y4.e;

public final /* synthetic */ class g implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ g(Object obj, int i) {
        this.a = i;
        this.b = obj;
    }

    public final void onChanged(Object obj) {
        Object obj2 = this.b;
        switch (this.a) {
            case 0:
                c cVar = (c) obj;
                int i = CreateRequestMoneyActivity.i;
                CreateRequestMoneyActivity createRequestMoneyActivity = (CreateRequestMoneyActivity) obj2;
                f.b(createRequestMoneyActivity, cVar);
                if (!cVar.d()) {
                    if (cVar.b()) {
                        f.c(cVar);
                        return;
                    } else if (cVar.f()) {
                        List<BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean> paymentConsumerRelateIdentityModelList = ((BlackOrFavResp) cVar.c).getPaymentConsumerRelateIdentityModelList();
                        createRequestMoneyActivity.g = paymentConsumerRelateIdentityModelList;
                        ArrayList E0 = createRequestMoneyActivity.E0(paymentConsumerRelateIdentityModelList);
                        createRequestMoneyActivity.h = E0;
                        if (E0.size() == 0) {
                            createRequestMoneyActivity.F0(8);
                            return;
                        }
                        createRequestMoneyActivity.F0(0);
                        createRequestMoneyActivity.f.setList(createRequestMoneyActivity.h);
                        return;
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            case 1:
                HomeBalance homeBalance = (HomeBalance) obj;
                HomeFragment homeFragment = (HomeFragment) obj2;
                homeFragment.e = homeBalance;
                TextView textView = homeFragment.b.b.n;
                textView.setText(homeFragment.getString(R.string.endekise) + (" (" + b.c(AppService.class).l() + ")"));
                if (homeBalance != null) {
                    homeFragment.b.b.o.setOnClickListener(new d(1));
                    homeBalance.setForward("native://ethio/customer/financialService?bankCode=Dashen&selectOverDraft=true");
                    Homev6HomeHeaderBinding homev6HomeHeaderBinding = homeFragment.b.b;
                    TextView textView2 = homev6HomeHeaderBinding.o;
                    boolean b2 = homeFragment.d.b(homeBalance);
                    ImageView imageView = homev6HomeHeaderBinding.c;
                    if (b2) {
                        textView2.setText("******");
                        imageView.setImageResource(R.mipmap.homev6_icon_eyes_close);
                    } else {
                        textView2.setText(homeBalance.getAmountDisplay());
                        imageView.setImageResource(R.mipmap.homev6_icon_eyes_open);
                    }
                    imageView.setOnClickListener(new t3.f(homeFragment, b2, homeBalance));
                    homeFragment.b.b.n.setOnClickListener(new P(homeFragment, homeBalance, 1));
                    return;
                }
                return;
            default:
                BaseResp baseResp = (BaseResp) obj;
                FuelPaymentVehicleManageActivity fuelPaymentVehicleManageActivity = (FuelPaymentVehicleManageActivity) obj2;
                VehicleManageAdapter vehicleManageAdapter = fuelPaymentVehicleManageActivity.j;
                if (vehicleManageAdapter != null) {
                    vehicleManageAdapter.addData(0, fuelPaymentVehicleManageActivity.n);
                    fuelPaymentVehicleManageActivity.i.c.setVisibility(8);
                    FuelPaymentVehicleMangeViewModel fuelPaymentVehicleMangeViewModel = fuelPaymentVehicleManageActivity.l;
                    e eVar = fuelPaymentVehicleMangeViewModel.g;
                    eVar.getClass();
                    fuelPaymentVehicleMangeViewModel.b(new y4.b(eVar).a, new z4.d(fuelPaymentVehicleMangeViewModel));
                }
                Bundle bundle = new Bundle(1);
                bundle.putSerializable("vehicleBean", fuelPaymentVehicleManageActivity.n);
                b.d(fuelPaymentVehicleManageActivity, "/topUpModule/fuelPaymentVehicleAmount", bundle, (Map) null);
                return;
        }
    }
}
