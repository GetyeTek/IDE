package com.huawei.requestmoney;

import android.widget.CompoundButton;

/* renamed from: com.huawei.requestmoney.b  reason: case insensitive filesystem */
public final /* synthetic */ class C0140b implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ AddBlackOrFavorActivity a;

    public /* synthetic */ C0140b(AddBlackOrFavorActivity addBlackOrFavorActivity) {
        this.a = addBlackOrFavorActivity;
    }

    /* JADX WARNING: type inference failed for: r4v3, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v6, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v9, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v12, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        int i = AddBlackOrFavorActivity.e;
        AddBlackOrFavorActivity addBlackOrFavorActivity = this.a;
        if (z) {
            addBlackOrFavorActivity.b.e.setChecked(false);
            addBlackOrFavorActivity.b.e.setClickable(true);
            addBlackOrFavorActivity.b.f.setChecked(true);
            addBlackOrFavorActivity.b.f.setClickable(false);
            addBlackOrFavorActivity.b.b.setVisibility(8);
            addBlackOrFavorActivity.b.c.setVisibility(0);
            return;
        }
        addBlackOrFavorActivity.getClass();
    }
}
