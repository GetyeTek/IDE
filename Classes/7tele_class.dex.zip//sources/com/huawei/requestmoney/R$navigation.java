package com.huawei.requestmoney;

public final class R$navigation {
    public static final int in_app_nav = 2131820544;

    private R$navigation() {
    }
}
