package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.huawei.common.widget.LoadingButton;
import com.huawei.common.widget.round.RoundConstraintLayout;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.viewlib.view.InputItemEditText;

public abstract class ActivityRequestMoneyPartialAmountBinding extends ViewDataBinding {
    @NonNull
    public final LoadingButton a;
    @NonNull
    public final InputItemEditText b;
    @NonNull
    public final RoundImageView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final ImageView e;
    @NonNull
    public final RecyclerView f;
    @NonNull
    public final RoundConstraintLayout g;
    @NonNull
    public final RoundConstraintLayout h;
    @NonNull
    public final TextView i;
    @NonNull
    public final TextView j;
    @NonNull
    public final TextView k;

    public ActivityRequestMoneyPartialAmountBinding(DataBindingComponent dataBindingComponent, View view, LoadingButton loadingButton, InputItemEditText inputItemEditText, RoundImageView roundImageView, ImageView imageView, ImageView imageView2, RecyclerView recyclerView, RoundConstraintLayout roundConstraintLayout, RoundConstraintLayout roundConstraintLayout2, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = loadingButton;
        this.b = inputItemEditText;
        this.c = roundImageView;
        this.d = imageView;
        this.e = imageView2;
        this.f = recyclerView;
        this.g = roundConstraintLayout;
        this.h = roundConstraintLayout2;
        this.i = textView;
        this.j = textView2;
        this.k = textView3;
    }
}
