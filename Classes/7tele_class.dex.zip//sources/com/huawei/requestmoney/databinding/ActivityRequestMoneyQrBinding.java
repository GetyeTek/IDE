package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundImageView;

public abstract class ActivityRequestMoneyQrBinding extends ViewDataBinding {
    @NonNull
    public final RoundImageView a;
    @NonNull
    public final LinearLayout b;
    @NonNull
    public final TextView c;
    @NonNull
    public final TextView d;
    @NonNull
    public final TextView e;

    public ActivityRequestMoneyQrBinding(DataBindingComponent dataBindingComponent, View view, RoundImageView roundImageView, LinearLayout linearLayout, TextView textView, TextView textView2, TextView textView3) {
        super(dataBindingComponent, view, 0);
        this.a = roundImageView;
        this.b = linearLayout;
        this.c = textView;
        this.d = textView2;
        this.e = textView3;
    }
}
