package com.huawei.requestmoney.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.requestmoney.R$id;

public class ActivitySettingRequestMoneyBindingImpl extends ActivitySettingRequestMoneyBinding {
    @Nullable
    public static final SparseIntArray d;
    public long c;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        d = sparseIntArray;
        sparseIntArray.put(R$id.ll_block_user, 1);
        sparseIntArray.put(R$id.tv_block_user, 2);
        sparseIntArray.put(R$id.ll_favor_list, 3);
        sparseIntArray.put(R$id.tv_favor_list, 4);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.c = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.c != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.c = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
