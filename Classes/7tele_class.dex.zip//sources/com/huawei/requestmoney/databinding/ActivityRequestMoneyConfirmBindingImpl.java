package com.huawei.requestmoney.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.requestmoney.R$id;

public class ActivityRequestMoneyConfirmBindingImpl extends ActivityRequestMoneyConfirmBinding {
    @Nullable
    public static final SparseIntArray g;
    public long f;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        g = sparseIntArray;
        sparseIntArray.put(R$id.tv_title, 1);
        sparseIntArray.put(R$id.ll_amount, 2);
        sparseIntArray.put(R$id.tvReceiveNum, 3);
        sparseIntArray.put(R$id.tvCurrency, 4);
        sparseIntArray.put(R$id.recyclerview, 5);
        sparseIntArray.put(R$id.ll_btn, 6);
        sparseIntArray.put(R$id.btnNext, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.f = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.f != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.f = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
