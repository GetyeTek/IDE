package com.huawei.requestmoney.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

public final class PaymentCommonTypeSelectBinding implements ViewBinding {
    @NonNull
    public final View getRoot() {
        return null;
    }
}
