package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.requestmoney.view.RoundCheckBox;

public abstract class ActivityAddBlackOrFavorBinding extends ViewDataBinding {
    @NonNull
    public final Button a;
    @NonNull
    public final CommonInputView b;
    @NonNull
    public final CommonInputView c;
    @NonNull
    public final ImageView d;
    @NonNull
    public final RoundCheckBox e;
    @NonNull
    public final RoundCheckBox f;
    @NonNull
    public final TextView g;

    public ActivityAddBlackOrFavorBinding(DataBindingComponent dataBindingComponent, View view, Button button, CommonInputView commonInputView, CommonInputView commonInputView2, ImageView imageView, RoundCheckBox roundCheckBox, RoundCheckBox roundCheckBox2, TextView textView) {
        super(dataBindingComponent, view, 0);
        this.a = button;
        this.b = commonInputView;
        this.c = commonInputView2;
        this.d = imageView;
        this.e = roundCheckBox;
        this.f = roundCheckBox2;
        this.g = textView;
    }
}
