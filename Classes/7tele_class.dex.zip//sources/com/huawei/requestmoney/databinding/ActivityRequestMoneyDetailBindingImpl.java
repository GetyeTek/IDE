package com.huawei.requestmoney.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.requestmoney.R$id;

public class ActivityRequestMoneyDetailBindingImpl extends ActivityRequestMoneyDetailBinding {
    @Nullable
    public static final SparseIntArray k;
    public long j;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        k = sparseIntArray;
        sparseIntArray.put(R$id.roundConstraintLayout2, 1);
        sparseIntArray.put(R$id.iv_head, 2);
        sparseIntArray.put(R$id.tv_name, 3);
        sparseIntArray.put(R$id.tvCurrency, 4);
        sparseIntArray.put(R$id.currencylayout, 5);
        sparseIntArray.put(R$id.tv_amount, 6);
        sparseIntArray.put(R$id.tv_currency_pre, 7);
        sparseIntArray.put(R$id.tv_title, 8);
        sparseIntArray.put(R$id.cl_other_info, 9);
        sparseIntArray.put(R$id.id_view, 10);
        sparseIntArray.put(R$id.rv_other_info, 11);
        sparseIntArray.put(R$id.linearLayout, 12);
        sparseIntArray.put(R$id.btn_reject, 13);
        sparseIntArray.put(R$id.btn_accept, 14);
        sparseIntArray.put(R$id.btn_cancel, 15);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.j = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.j != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.j = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
