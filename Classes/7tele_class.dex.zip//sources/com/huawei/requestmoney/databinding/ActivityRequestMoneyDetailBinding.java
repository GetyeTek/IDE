package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.recyclerview.HFRecyclerView;
import com.huawei.common.widget.round.RoundImageView;

public abstract class ActivityRequestMoneyDetailBinding extends ViewDataBinding {
    @NonNull
    public final Button a;
    @NonNull
    public final Button b;
    @NonNull
    public final Button c;
    @NonNull
    public final RoundImageView d;
    @NonNull
    public final HFRecyclerView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final TextView g;
    @NonNull
    public final TextView h;
    @NonNull
    public final TextView i;

    public ActivityRequestMoneyDetailBinding(DataBindingComponent dataBindingComponent, View view, Button button, Button button2, Button button3, RoundImageView roundImageView, HFRecyclerView hFRecyclerView, TextView textView, TextView textView2, TextView textView3, TextView textView4) {
        super(dataBindingComponent, view, 0);
        this.a = button;
        this.b = button2;
        this.c = button3;
        this.d = roundImageView;
        this.e = hFRecyclerView;
        this.f = textView;
        this.g = textView2;
        this.h = textView3;
        this.i = textView4;
    }
}
