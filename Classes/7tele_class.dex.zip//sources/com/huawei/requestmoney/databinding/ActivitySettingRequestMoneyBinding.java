package com.huawei.requestmoney.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundLinearLayout;

public abstract class ActivitySettingRequestMoneyBinding extends ViewDataBinding {
    @NonNull
    public final RoundLinearLayout a;
    @NonNull
    public final RoundLinearLayout b;

    public ActivitySettingRequestMoneyBinding(DataBindingComponent dataBindingComponent, View view, RoundLinearLayout roundLinearLayout, RoundLinearLayout roundLinearLayout2) {
        super(dataBindingComponent, view, 0);
        this.a = roundLinearLayout;
        this.b = roundLinearLayout2;
    }
}
