package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;

public abstract class RequestMoneyFragmentLayoutBinding extends ViewDataBinding {
    @NonNull
    public final LinearLayout a;
    @NonNull
    public final RoundRecyclerView b;
    @NonNull
    public final SmartRefreshLayout c;

    public RequestMoneyFragmentLayoutBinding(DataBindingComponent dataBindingComponent, View view, LinearLayout linearLayout, RoundRecyclerView roundRecyclerView, SmartRefreshLayout smartRefreshLayout) {
        super(dataBindingComponent, view, 0);
        this.a = linearLayout;
        this.b = roundRecyclerView;
        this.c = smartRefreshLayout;
    }
}
