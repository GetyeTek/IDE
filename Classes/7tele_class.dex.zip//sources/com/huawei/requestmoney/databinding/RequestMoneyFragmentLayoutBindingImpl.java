package com.huawei.requestmoney.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.requestmoney.R$id;

public class RequestMoneyFragmentLayoutBindingImpl extends RequestMoneyFragmentLayoutBinding {
    @Nullable
    public static final SparseIntArray e;
    public long d;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        e = sparseIntArray;
        sparseIntArray.put(R$id.recycler_view, 1);
        sparseIntArray.put(R$id.ll_no_request_money_history, 2);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.d = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.d != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.d = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
