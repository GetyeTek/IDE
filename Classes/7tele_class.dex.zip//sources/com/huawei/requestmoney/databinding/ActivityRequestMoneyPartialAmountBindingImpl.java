package com.huawei.requestmoney.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.requestmoney.R$id;

public class ActivityRequestMoneyPartialAmountBindingImpl extends ActivityRequestMoneyPartialAmountBinding {
    @Nullable
    public static final SparseIntArray m;
    public long l;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        m = sparseIntArray;
        sparseIntArray.put(R$id.nl_scroll, 1);
        sparseIntArray.put(R$id.rl_amount_container, 2);
        sparseIntArray.put(R$id.ivAvatar, 3);
        sparseIntArray.put(R$id.tvName, 4);
        sparseIntArray.put(R$id.cl_amount_container, 5);
        sparseIntArray.put(R$id.tvAmount, 6);
        sparseIntArray.put(R$id.tvCurrency, 7);
        sparseIntArray.put(R$id.recycler_view, 8);
        sparseIntArray.put(R$id.rl_total_amount_container, 9);
        sparseIntArray.put(R$id.iv_total_amount, 10);
        sparseIntArray.put(R$id.tv_total_amount_tips, 11);
        sparseIntArray.put(R$id.tv_total_amount_value, 12);
        sparseIntArray.put(R$id.rl_partial_amount_container, 13);
        sparseIntArray.put(R$id.iv_partial_amount, 14);
        sparseIntArray.put(R$id.tv_partial_amount_tips, 15);
        sparseIntArray.put(R$id.et_amount, 16);
        sparseIntArray.put(R$id.ll_button, 17);
        sparseIntArray.put(R$id.btn_confirm, 18);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.l = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.l != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.l = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
