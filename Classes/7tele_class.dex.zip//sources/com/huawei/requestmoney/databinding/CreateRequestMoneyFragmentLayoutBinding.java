package com.huawei.requestmoney.databinding;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.input.CommonInputView;
import com.huawei.requestmoney.view.TypeSelectView;

public abstract class CreateRequestMoneyFragmentLayoutBinding extends ViewDataBinding {
    @NonNull
    public final CommonInputView a;
    @NonNull
    public final CommonInputView b;
    @NonNull
    public final CommonInputView c;
    @NonNull
    public final CommonInputView d;
    @NonNull
    public final TypeSelectView e;

    public CreateRequestMoneyFragmentLayoutBinding(DataBindingComponent dataBindingComponent, View view, CommonInputView commonInputView, CommonInputView commonInputView2, CommonInputView commonInputView3, CommonInputView commonInputView4, TypeSelectView typeSelectView) {
        super(dataBindingComponent, view, 0);
        this.a = commonInputView;
        this.b = commonInputView2;
        this.c = commonInputView3;
        this.d = commonInputView4;
        this.e = typeSelectView;
    }
}
