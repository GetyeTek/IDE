package com.huawei.requestmoney.databinding;

import androidx.databinding.ViewDataBinding;

public abstract class RequestMoneyQrPopBinding extends ViewDataBinding {
}
