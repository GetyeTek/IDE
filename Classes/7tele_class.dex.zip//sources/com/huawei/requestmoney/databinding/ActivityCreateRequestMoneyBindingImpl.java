package com.huawei.requestmoney.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.requestmoney.R$id;

public class ActivityCreateRequestMoneyBindingImpl extends ActivityCreateRequestMoneyBinding {
    @Nullable
    public static final SparseIntArray i;
    public long h;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        i = sparseIntArray;
        sparseIntArray.put(R$id.tvFavTitle, 1);
        sparseIntArray.put(R$id.tvMore, 2);
        sparseIntArray.put(R$id.rvFav, 3);
        sparseIntArray.put(R$id.cl_select, 4);
        sparseIntArray.put(R$id.line_middle, 5);
        sparseIntArray.put(R$id.rcbLeft, 6);
        sparseIntArray.put(R$id.rcbRight, 7);
        sparseIntArray.put(R$id.viewPager, 8);
        sparseIntArray.put(R$id.linearLayout, 9);
        sparseIntArray.put(R$id.btn_send, 10);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.h = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.h != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.h = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i2, Object obj, int i3) {
        return false;
    }

    public final boolean setVariable(int i2, @Nullable Object obj) {
        return true;
    }
}
