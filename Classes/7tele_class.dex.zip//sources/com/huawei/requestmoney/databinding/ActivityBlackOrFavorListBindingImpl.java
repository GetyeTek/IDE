package com.huawei.requestmoney.databinding;

import android.util.SparseIntArray;
import androidx.annotation.Nullable;
import com.huawei.requestmoney.R$id;

public class ActivityBlackOrFavorListBindingImpl extends ActivityBlackOrFavorListBinding {
    @Nullable
    public static final SparseIntArray h;
    public long g;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        h = sparseIntArray;
        sparseIntArray.put(R$id.cl_block_all, 1);
        sparseIntArray.put(R$id.tv_block_all, 2);
        sparseIntArray.put(R$id.iv_switch, 3);
        sparseIntArray.put(R$id.tv_count, 4);
        sparseIntArray.put(R$id.tv_add_options, 5);
        sparseIntArray.put(R$id.rv_list, 6);
        sparseIntArray.put(R$id.ll_no_request_money_history, 7);
    }

    public final void executeBindings() {
        synchronized (this) {
            this.g = 0;
        }
    }

    public final boolean hasPendingBindings() {
        synchronized (this) {
            try {
                if (this.g != 0) {
                    return true;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void invalidateAll() {
        synchronized (this) {
            this.g = 1;
        }
        requestRebind();
    }

    public final boolean onFieldChange(int i, Object obj, int i2) {
        return false;
    }

    public final boolean setVariable(int i, @Nullable Object obj) {
        return true;
    }
}
