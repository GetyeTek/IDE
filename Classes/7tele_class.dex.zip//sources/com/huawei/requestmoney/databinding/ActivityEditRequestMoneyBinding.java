package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.input.CommonInputView;

public abstract class ActivityEditRequestMoneyBinding extends ViewDataBinding {
    @NonNull
    public final Button a;
    @NonNull
    public final CommonInputView b;
    @NonNull
    public final CommonInputView c;
    @NonNull
    public final CommonInputView d;

    public ActivityEditRequestMoneyBinding(DataBindingComponent dataBindingComponent, View view, Button button, CommonInputView commonInputView, CommonInputView commonInputView2, CommonInputView commonInputView3) {
        super(dataBindingComponent, view, 0);
        this.a = button;
        this.b = commonInputView;
        this.c = commonInputView2;
        this.d = commonInputView3;
    }
}
