package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.common.widget.round.RoundRecyclerView;
import com.huawei.requestmoney.view.RoundCheckBox;

public abstract class ActivityCreateRequestMoneyBinding extends ViewDataBinding {
    @NonNull
    public final Button a;
    @NonNull
    public final RoundCheckBox b;
    @NonNull
    public final RoundCheckBox c;
    @NonNull
    public final RoundRecyclerView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;
    @NonNull
    public final ViewPager2 g;

    public ActivityCreateRequestMoneyBinding(DataBindingComponent dataBindingComponent, View view, Button button, RoundCheckBox roundCheckBox, RoundCheckBox roundCheckBox2, RoundRecyclerView roundRecyclerView, TextView textView, TextView textView2, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 0);
        this.a = button;
        this.b = roundCheckBox;
        this.c = roundCheckBox2;
        this.d = roundRecyclerView;
        this.e = textView;
        this.f = textView2;
        this.g = viewPager2;
    }
}
