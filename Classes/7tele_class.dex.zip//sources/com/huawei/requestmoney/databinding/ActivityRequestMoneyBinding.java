package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import androidx.viewpager2.widget.ViewPager2;
import com.huawei.requestmoney.view.RoundCheckBox;

public abstract class ActivityRequestMoneyBinding extends ViewDataBinding {
    @NonNull
    public final Button a;
    @NonNull
    public final RoundCheckBox b;
    @NonNull
    public final RoundCheckBox c;
    @NonNull
    public final ViewPager2 d;

    public ActivityRequestMoneyBinding(DataBindingComponent dataBindingComponent, View view, Button button, RoundCheckBox roundCheckBox, RoundCheckBox roundCheckBox2, ViewPager2 viewPager2) {
        super(dataBindingComponent, view, 0);
        this.a = button;
        this.b = roundCheckBox;
        this.c = roundCheckBox2;
        this.d = viewPager2;
    }
}
