package com.huawei.requestmoney.databinding;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.huawei.common.widget.round.RoundRecyclerView;

public abstract class ActivityBlackOrFavorListBinding extends ViewDataBinding {
    @NonNull
    public final ConstraintLayout a;
    @NonNull
    public final ImageView b;
    @NonNull
    public final LinearLayout c;
    @NonNull
    public final RoundRecyclerView d;
    @NonNull
    public final TextView e;
    @NonNull
    public final TextView f;

    public ActivityBlackOrFavorListBinding(DataBindingComponent dataBindingComponent, View view, ConstraintLayout constraintLayout, ImageView imageView, LinearLayout linearLayout, RoundRecyclerView roundRecyclerView, TextView textView, TextView textView2) {
        super(dataBindingComponent, view, 0);
        this.a = constraintLayout;
        this.b = imageView;
        this.c = linearLayout;
        this.d = roundRecyclerView;
        this.e = textView;
        this.f = textView2;
    }
}
