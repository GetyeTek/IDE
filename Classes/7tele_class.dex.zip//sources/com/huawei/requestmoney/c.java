package com.huawei.requestmoney;

import android.text.TextUtils;
import android.view.View;
import com.google.android.gms.ads.identifier.a;
import com.huawei.requestmoney.bean.BlackOrFavResp;
import java.util.HashMap;

public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ BlackOrFavorListActivity a;
    public final /* synthetic */ View b;
    public final /* synthetic */ BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean c;

    public /* synthetic */ c(BlackOrFavorListActivity blackOrFavorListActivity, View view, BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean paymentConsumerRelateIdentityModelListBean) {
        this.a = blackOrFavorListActivity;
        this.b = view;
        this.c = paymentConsumerRelateIdentityModelListBean;
    }

    public final void onClick(View view) {
        int i = BlackOrFavorListActivity.g;
        BlackOrFavorListActivity blackOrFavorListActivity = this.a;
        int i2 = R$id.tvRemove;
        View view2 = this.b;
        int id = view2.getId();
        BlackOrFavResp.PaymentConsumerRelateIdentityModelListBean paymentConsumerRelateIdentityModelListBean = this.c;
        if (i2 == id) {
            HashMap a2 = a.a("relateType", "FAVOR");
            if (TextUtils.equals(paymentConsumerRelateIdentityModelListBean.getRelateIdentityType(), "1000")) {
                a2.put("relateMsisdn", paymentConsumerRelateIdentityModelListBean.getRelateIdentifier());
            } else {
                a2.put("relateShortCode", paymentConsumerRelateIdentityModelListBean.getRelateIdentifier());
            }
            blackOrFavorListActivity.c.f(a2);
        } else if (R$id.tvUnBlock == view2.getId()) {
            HashMap a3 = a.a("relateType", "BLACK");
            if (TextUtils.equals(paymentConsumerRelateIdentityModelListBean.getRelateIdentityType(), "1000")) {
                a3.put("relateMsisdn", paymentConsumerRelateIdentityModelListBean.getRelateIdentifier());
            } else {
                a3.put("relateShortCode", paymentConsumerRelateIdentityModelListBean.getRelateIdentifier());
            }
            blackOrFavorListActivity.c.f(a3);
        }
    }
}
