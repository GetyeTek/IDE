package com.huawei.requestmoney;

import android.widget.CompoundButton;
import java.util.ArrayList;

public final /* synthetic */ class f implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ CreateRequestMoneyActivity a;

    public /* synthetic */ f(CreateRequestMoneyActivity createRequestMoneyActivity) {
        this.a = createRequestMoneyActivity;
    }

    /* JADX WARNING: type inference failed for: r4v3, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v6, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    /* JADX WARNING: type inference failed for: r4v9, types: [com.huawei.requestmoney.view.RoundCheckBox, android.widget.CompoundButton] */
    /* JADX WARNING: type inference failed for: r4v12, types: [com.huawei.requestmoney.view.RoundCheckBox, android.view.View] */
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        int i = CreateRequestMoneyActivity.i;
        CreateRequestMoneyActivity createRequestMoneyActivity = this.a;
        if (z) {
            int i2 = 0;
            createRequestMoneyActivity.b.b.setChecked(false);
            createRequestMoneyActivity.b.b.setClickable(true);
            createRequestMoneyActivity.b.c.setChecked(true);
            createRequestMoneyActivity.b.c.setClickable(false);
            createRequestMoneyActivity.b.g.setCurrentItem(1);
            ArrayList E0 = createRequestMoneyActivity.E0(createRequestMoneyActivity.g);
            if (E0.size() == 0) {
                i2 = 8;
            }
            createRequestMoneyActivity.F0(i2);
            createRequestMoneyActivity.f.setList(E0);
        }
    }
}
