package com.huawei.requestmoney;

public final class R$menu {
    public static final int main = 2131689473;
    public static final int menu_request_money_edit = 2131689476;
    public static final int menu_request_money_setting = 2131689477;
    public static final int ucrop_menu = 2131689479;

    private R$menu() {
    }
}
