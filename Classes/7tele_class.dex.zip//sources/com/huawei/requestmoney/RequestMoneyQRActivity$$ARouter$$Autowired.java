package com.huawei.requestmoney;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.huawei.astp.macle.ui.e;

public class RequestMoneyQRActivity$$ARouter$$Autowired implements ISyringe {
    private SerializationService serializationService;

    /* JADX WARNING: type inference failed for: r4v1, types: [com.huawei.requestmoney.RequestMoneyQRActivity, android.app.Activity] */
    public void inject(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        this.serializationService = e.c(SerializationService.class);
        ? r4 = (RequestMoneyQRActivity) obj;
        if (r4.getIntent().getExtras() == null) {
            str = r4.qrCode;
        } else {
            str = r4.getIntent().getExtras().getString("qrCode", r4.qrCode);
        }
        r4.qrCode = str;
        if (r4.getIntent().getExtras() == null) {
            str2 = r4.amount;
        } else {
            str2 = r4.getIntent().getExtras().getString("amount", r4.amount);
        }
        r4.amount = str2;
        if (r4.getIntent().getExtras() == null) {
            str3 = r4.mobileNumber;
        } else {
            str3 = r4.getIntent().getExtras().getString("mobileNumber", r4.mobileNumber);
        }
        r4.mobileNumber = str3;
        if (r4.getIntent().getExtras() == null) {
            str4 = r4.currencyUnit;
        } else {
            str4 = r4.getIntent().getExtras().getString("currencyUnit", r4.currencyUnit);
        }
        r4.currencyUnit = str4;
    }
}
