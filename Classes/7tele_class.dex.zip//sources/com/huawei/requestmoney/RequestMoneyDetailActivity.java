package com.huawei.requestmoney;

import D4.g;
import V1.k;
import V6.d;
import V7.e;
import V7.f;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.common.widget.round.RoundImageView;
import com.huawei.digitalpayment.customer.httplib.response.TransferResp;
import com.huawei.http.BaseResp;
import com.huawei.image.glide.Base64Mode;
import com.huawei.module_basic_ui.R;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.requestmoney.bean.RequestMoneyResp;
import com.huawei.requestmoney.databinding.ActivityRequestMoneyDetailBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;
import java.util.List;
import java.util.Map;

@Route(path = "/requestMoneyModule/requestMoneyDetail")
public class RequestMoneyDetailActivity extends DataBindingActivity<ActivityRequestMoneyDetailBinding, RequestMoneyViewModel> {
    public static final /* synthetic */ int i = 0;
    public String d;
    public u e;
    public RequestMoneyResp.RequestMoneyOrderInfoBean f;
    public String g;
    public RequestMoneyResp h;

    public class a implements Observer<V7.c<TransferResp>> {
        public a() {
        }

        public final void onChanged(Object obj) {
            TransferResp transferResp;
            V7.c cVar = (V7.c) obj;
            f.b(RequestMoneyDetailActivity.this, cVar);
            if (cVar.b()) {
                f.c(cVar);
            } else if (cVar.f() && (transferResp = (TransferResp) cVar.c) != null) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("transferResp", transferResp);
                o0.b.d((Activity) null, "/basicUiModule/commonSuccess", bundle, (Map) null);
            }
        }
    }

    public class b implements Observer<V7.c<RequestMoneyResp>> {
        public b() {
        }

        public final void onChanged(Object obj) {
            String str;
            String str2;
            V7.c cVar = (V7.c) obj;
            FragmentActivity fragmentActivity = RequestMoneyDetailActivity.this;
            f.b(fragmentActivity, cVar);
            if (!cVar.d()) {
                if (cVar.b()) {
                    f.c(cVar);
                } else if (cVar.f()) {
                    RequestMoneyResp requestMoneyResp = (RequestMoneyResp) cVar.c;
                    fragmentActivity.h = requestMoneyResp;
                    if (requestMoneyResp != null) {
                        RequestMoneyResp.RequestMoneyOrderInfoBean requestMoneyOrderInfo = requestMoneyResp.getRequestMoneyOrderInfo();
                        fragmentActivity.f = requestMoneyOrderInfo;
                        if (requestMoneyOrderInfo != null) {
                            if (TextUtils.isEmpty(requestMoneyOrderInfo.getPayAmount())) {
                                fragmentActivity.b.f.setText(String.valueOf(requestMoneyOrderInfo.getAmount()));
                            } else {
                                fragmentActivity.b.f.setText(String.valueOf(requestMoneyOrderInfo.getPayAmount()));
                            }
                            fragmentActivity.b.i.setText(requestMoneyOrderInfo.getStatusDisplay());
                            if (requestMoneyOrderInfo.getStatus().equals("paid")) {
                                fragmentActivity.b.i.setText(fragmentActivity.getString(R$string.paid_amount));
                            }
                            fragmentActivity.b.i.setTextColor(H5.b.b(fragmentActivity, requestMoneyOrderInfo.getStatus()));
                            TextView textView = fragmentActivity.b.g;
                            textView.setText("(" + requestMoneyOrderInfo.getCurrency() + ")");
                            if (TextUtils.equals(fragmentActivity.d, "receiver") && TextUtils.equals(requestMoneyOrderInfo.getStatus(), "initial")) {
                                fragmentActivity.b.a.setVisibility(0);
                                fragmentActivity.b.a.setOnClickListener(new Z7.c(1, fragmentActivity, requestMoneyOrderInfo));
                            }
                            if (TextUtils.equals(fragmentActivity.d, "sender") && TextUtils.equals(requestMoneyOrderInfo.getStatus(), "initial")) {
                                fragmentActivity.b.b.setVisibility(0);
                                fragmentActivity.b.b.setText(fragmentActivity.getString(R$string.cancel));
                                fragmentActivity.b.b.setTextColor(Color.parseColor("#ED1C24"));
                                fragmentActivity.b.b.setOnClickListener(new d(fragmentActivity, 3));
                            }
                            if (TextUtils.equals(fragmentActivity.d, "sender")) {
                                str = requestMoneyOrderInfo.getPayerAvatar();
                            } else {
                                str = requestMoneyOrderInfo.getPayeeAvatar();
                            }
                            Base64Mode consumerMode = Base64Mode.getConsumerMode(str);
                            RoundImageView roundImageView = fragmentActivity.b.d;
                            int i = R$mipmap.icon_drawer_head;
                            y5.b.a(consumerMode, roundImageView, i, i);
                            TextView textView2 = fragmentActivity.b.h;
                            if (TextUtils.equals(fragmentActivity.d, "sender")) {
                                str2 = requestMoneyOrderInfo.getPayerName();
                            } else {
                                str2 = requestMoneyOrderInfo.getPayeeName();
                            }
                            textView2.setText(str2);
                            ViewGroup viewGroup = (ViewGroup) fragmentActivity.a.findViewById(16908290);
                            if (viewGroup != null && TextUtils.equals(fragmentActivity.d, "sender") && TextUtils.equals(fragmentActivity.f.getPaymentMethod(), "App") && TextUtils.equals(requestMoneyOrderInfo.getStatus(), "initial")) {
                                int i2 = R$id.clEdit;
                                viewGroup.findViewById(i2).setVisibility(0);
                                viewGroup.findViewById(i2).setOnClickListener(new com.huawei.ethiopia.finance.loan.activity.f(fragmentActivity, 2));
                            }
                            if (viewGroup != null && TextUtils.equals(fragmentActivity.d, "receiver")) {
                                int i3 = R$id.tvBlock;
                                viewGroup.findViewById(i3).setVisibility(0);
                                viewGroup.findViewById(i3).setOnClickListener(new H1.a(fragmentActivity, 5));
                                if (TextUtils.equals(requestMoneyOrderInfo.getStatus(), "initial")) {
                                    fragmentActivity.b.c.setVisibility(0);
                                    fragmentActivity.b.c.setOnClickListener(new M5.c(fragmentActivity, 4));
                                }
                            }
                            List<TransferResp.DisplayItemBean> displayItems = fragmentActivity.h.getDisplayItems();
                            if (displayItems != null) {
                                u uVar = fragmentActivity.e;
                                if (uVar != null) {
                                    uVar.setList(displayItems);
                                    return;
                                }
                                fragmentActivity.e = new BaseQuickAdapter(R.layout.item_common_success, displayItems);
                                fragmentActivity.b.e.setLayoutManager(new LinearLayoutManager(fragmentActivity));
                                fragmentActivity.b.e.setAdapter(fragmentActivity.e);
                            }
                        }
                    }
                }
            }
        }
    }

    public class c implements Observer<V7.c<BaseResp>> {
        public c() {
        }

        public final void onChanged(Object obj) {
            V7.c cVar = (V7.c) obj;
            RequestMoneyDetailActivity requestMoneyDetailActivity = RequestMoneyDetailActivity.this;
            f.b(requestMoneyDetailActivity, cVar);
            if (!cVar.d()) {
                if (cVar.b()) {
                    f.c(cVar);
                } else if (cVar.f()) {
                    k.a(R$string.saved_successfully);
                    requestMoneyDetailActivity.finish();
                }
            }
        }
    }

    public final int C0() {
        return R$layout.activity_request_money_detail;
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [android.content.Context, com.huawei.requestmoney.RequestMoneyDetailActivity, androidx.fragment.app.FragmentActivity] */
    public final void E0(View view, String str) {
        String string = getString(R$string.cancel);
        String string2 = getString(R$string.confirm);
        r rVar = new r(this, view);
        BaseDialog baseDialog = new BaseDialog();
        baseDialog.g = null;
        baseDialog.h = str;
        baseDialog.i = string;
        baseDialog.j = string2;
        baseDialog.k = null;
        baseDialog.l = rVar;
        baseDialog.show(getSupportFragmentManager(), "tipsDialog");
    }

    public final void onActivityResult(int i2, int i3, @Nullable Intent intent) {
        RequestMoneyDetailActivity.super.onActivityResult(i2, i3, intent);
        if (i2 == 3 && intent != null) {
            this.c.g(this.d, this.g);
        }
        if (i2 == 1 && intent != null) {
            this.f.setAmount(intent.getStringExtra("amount"));
            r4.f.b.a(this, new s(this));
        }
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [android.content.Context, androidx.lifecycle.LifecycleOwner, com.huawei.payment.mvvm.DataBindingActivity, android.app.Activity, androidx.appcompat.app.AppCompatActivity, com.huawei.requestmoney.RequestMoneyDetailActivity, androidx.fragment.app.FragmentActivity] */
    public final void onCreate(@Nullable Bundle bundle) {
        RequestMoneyDetailActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.request_detail), R$layout.request_money_common_toolbar);
        Intent intent = getIntent();
        if (intent != null) {
            this.d = intent.getStringExtra("type");
            String stringExtra = intent.getStringExtra("requestMoneyOrderId");
            this.g = stringExtra;
            if (!TextUtils.isEmpty(stringExtra)) {
                this.c.g(this.d, this.g);
            }
        }
        this.c.k.observe(this, new a());
        this.c.l.observe(this, new b());
        this.c.i.observe(this, new g(this, 2));
        this.c.p.observe(this, new c());
    }
}
