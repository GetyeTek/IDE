package com.huawei.requestmoney;

import V7.e;
import android.os.Bundle;
import androidx.annotation.Nullable;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.huawei.payment.mvvm.DataBindingActivity;
import com.huawei.payment.mvvm.R;
import com.huawei.requestmoney.databinding.ActivitySettingRequestMoneyBinding;
import com.huawei.requestmoney.viewmodel.RequestMoneyViewModel;

@Route(path = "/requestMoneyModule/settingRequestMoney")
public class RequestMoneySettingActivity extends DataBindingActivity<ActivitySettingRequestMoneyBinding, RequestMoneyViewModel> {
    public static final /* synthetic */ int d = 0;

    public final int C0() {
        return R$layout.activity_setting_request_money;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [android.view.View$OnClickListener, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v2, types: [android.view.View$OnClickListener, java.lang.Object] */
    public final void onCreate(@Nullable Bundle bundle) {
        RequestMoneySettingActivity.super.onCreate(bundle);
        e.a(this, getString(R$string.setting), R.layout.common_toolbar);
        this.b.a.setOnClickListener(new Object());
        this.b.b.setOnClickListener(new Object());
    }
}
