package com.huawei.requestmoney.pop;

import H1.c;
import N4.n;
import R9.h;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import com.blankj.utilcode.util.f;
import com.huawei.common.widget.dialog.BaseDialog;
import com.huawei.requestmoney.R$layout;
import com.huawei.requestmoney.R$style;

public class RequestMoneyQRDialog extends BaseDialog {
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return DataBindingUtil.inflate(layoutInflater, R$layout.request_money_qr_pop, viewGroup, false).getRoot();
    }

    public final void onStart() {
        Window window;
        RequestMoneyQRDialog.super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && (window = dialog.getWindow()) != null) {
            window.setGravity(80);
            window.setLayout(-1, -2);
            c.b(window, R$style.BottomAnimation, dialog, true, true);
        }
    }

    public final void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        RequestMoneyQRDialog.super.onViewCreated(view, bundle);
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        viewGroup.setPadding(viewGroup.getPaddingLeft(), f.a() + viewGroup.getPaddingTop(), viewGroup.getPaddingRight(), viewGroup.getPaddingBottom());
        viewGroup.setOnClickListener(new n(this, 7));
        h.a((Context) null, 213.0f);
        throw null;
    }

    public final int v0() {
        return R$layout.request_money_qr_pop;
    }
}
