package q9;

public interface g<T> {
    boolean a() throws Exception;
}
