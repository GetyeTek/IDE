package q9;

public interface c<T1, T2, R> {
}
