package q9;

public interface d {
    void cancel() throws Exception;
}
