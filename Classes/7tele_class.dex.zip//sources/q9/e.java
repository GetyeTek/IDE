package q9;

public interface e<T> {
    void accept(T t) throws Exception;
}
