package q9;

public interface f<T, R> {
    R apply(T t) throws Exception;
}
