package q9;

/* renamed from: q9.a  reason: case insensitive filesystem */
public interface C0425a {
}
