package q9;

public interface b<T1, T2> {
}
