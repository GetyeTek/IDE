package Z9;

public interface d {
}
