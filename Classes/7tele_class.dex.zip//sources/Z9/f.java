package Z9;

import H9.j;

public interface f<V> extends e<j> {
}
