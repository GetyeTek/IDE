package Z9;

import Z9.j;

public interface k<V> extends j<V>, T9.a<V> {

    public interface a<V> extends j.a<V>, T9.a<V> {
    }

    Object getDelegate();

    a<V> getGetter();
}
