package Z9;

public interface n extends a {
}
