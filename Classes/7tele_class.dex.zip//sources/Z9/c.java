package Z9;

public interface c<T> extends d, a {
    String a();

    boolean b(Object obj);
}
