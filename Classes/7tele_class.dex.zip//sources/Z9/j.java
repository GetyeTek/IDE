package Z9;

public interface j<V> extends b<V> {

    public interface a<V> extends e<V> {
    }

    boolean isConst();

    boolean isLateinit();
}
