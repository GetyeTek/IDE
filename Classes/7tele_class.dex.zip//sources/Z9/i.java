package Z9;

import H9.j;
import T9.q;

public interface i<D, E, V> extends m<D, E, V>, j {

    public interface a<D, E, V> extends f<V>, q<D, E, V, j> {
    }

    a<D, E, V> getSetter();
}
