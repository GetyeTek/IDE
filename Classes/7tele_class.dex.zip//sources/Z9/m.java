package Z9;

import T9.p;
import Z9.j;

public interface m<D, E, V> extends j<V>, p<D, E, V> {

    public interface a<D, E, V> extends j.a<V>, p<D, E, V> {
    }

    Object getDelegate(D d, E e);

    a<D, E, V> getGetter();
}
