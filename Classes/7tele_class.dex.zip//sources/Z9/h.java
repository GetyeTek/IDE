package Z9;

import H9.j;
import T9.p;

public interface h<T, V> extends l<T, V>, j {

    public interface a<T, V> extends f<V>, p<T, V, j> {
    }

    a<T, V> getSetter();
}
