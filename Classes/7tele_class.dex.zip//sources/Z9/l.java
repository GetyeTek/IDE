package Z9;

import Z9.j;

public interface l<T, V> extends j<V>, T9.l<T, V> {

    public interface a<T, V> extends j.a<V>, T9.l<T, V> {
    }

    Object getDelegate(T t);

    a<T, V> getGetter();
}
