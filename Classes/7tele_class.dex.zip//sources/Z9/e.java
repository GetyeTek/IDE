package Z9;

import H9.b;

public interface e<R> extends b<R>, b<R> {
    boolean isExternal();

    boolean isInfix();

    boolean isInline();

    boolean isOperator();

    boolean isSuspend();
}
