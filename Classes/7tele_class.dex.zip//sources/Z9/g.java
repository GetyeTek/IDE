package Z9;

import H9.j;
import T9.l;

public interface g<V> extends k<V>, j {

    public interface a<V> extends f<V>, l<V, j> {
    }

    a<V> getSetter();
}
