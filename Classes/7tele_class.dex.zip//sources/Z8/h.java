package Z8;

public final class h<T, K, R> {
    public String a;
    public String b;
    public String c;

    public h() {
        throw null;
    }

    public final String toString() {
        return "ThreeContainer{first=" + this.a + ", second=" + this.b + ", third=" + this.c + '}';
    }
}
