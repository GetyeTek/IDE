package Z8;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import androidx.camera.video.B;
import java.io.File;

public final class c {
    public static void a(String str) {
        try {
            File file = new File(str);
            if (file.isDirectory()) {
                File[] listFiles = file.listFiles();
                if (listFiles != null) {
                    for (File file2 : listFiles) {
                        a(file2.toString());
                        file2.delete();
                    }
                    return;
                }
                return;
            }
            file.delete();
        } catch (Exception unused) {
        }
    }

    public static String b(Context context) {
        String externalStorageState = Environment.getExternalStorageState();
        String str = "";
        if (externalStorageState != null && externalStorageState.equals("mounted")) {
            Log.e("aaaaa", "getCachePath state.equals(android.os.Environment.MEDIA_MOUNTED)");
            File externalCacheDir = context.getExternalCacheDir();
            if (externalCacheDir != null) {
                str = externalCacheDir.getAbsolutePath();
            }
            Log.e("aaaaa", "getCachePath path1=" + str);
            if (TextUtils.isEmpty(str)) {
                str = Environment.getExternalStorageDirectory().getAbsolutePath();
            }
            Log.e("aaaaa", "getCachePath path2=" + str);
        } else if (context.getCacheDir() != null) {
            str = context.getCacheDir().getAbsolutePath();
            Log.e("aaaaa", "getCachePath path3=" + str);
        }
        Log.e("aaaaa", "getCachePath path final=" + str);
        File file = new File(str);
        if (!file.exists()) {
            Log.e("aaaaa", "getCachePath path final mkdirs=" + str);
            file.mkdirs();
        }
        return str;
    }

    public static String c(Context context, String str) {
        String b = b(context);
        if (TextUtils.isEmpty(b)) {
            return null;
        }
        File file = new File(new File(b).getParentFile(), str);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file.getAbsolutePath();
    }

    public static String d(String str) {
        int lastIndexOf;
        if (!TextUtils.isEmpty(str) && (lastIndexOf = str.lastIndexOf(46)) != -1) {
            return str.substring(lastIndexOf + 1, str.length()).toLowerCase();
        }
        return "";
    }

    public static long e(File file) {
        if (file.exists()) {
            return file.length();
        }
        return 0;
    }

    public static void f(String str, String str2) {
        File file = new File(str);
        if (file.exists() && file.isDirectory()) {
            File file2 = new File(str2);
            if (!file2.exists()) {
                file2.mkdirs();
            }
            File[] listFiles = file.listFiles();
            if (listFiles != null && listFiles.length > 0) {
                for (File file3 : listFiles) {
                    if (file3.isFile()) {
                        String absolutePath = file3.getAbsolutePath();
                        String absolutePath2 = file2.getAbsolutePath();
                        File file4 = new File(absolutePath);
                        if (file4.exists() && file4.isFile()) {
                            File file5 = new File(absolutePath2);
                            if (!file5.exists()) {
                                file5.mkdirs();
                            }
                            StringBuilder b = B.b(absolutePath2);
                            b.append(File.separator);
                            b.append(file4.getName());
                            file4.renameTo(new File(b.toString()));
                        }
                    } else if (file3.isDirectory()) {
                        f(file3.getAbsolutePath(), file2.getAbsolutePath() + File.separator + file3.getName());
                    }
                }
            }
            a(str);
        }
    }
}
