package Z8;

import J8.b;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.huawei.payment.base.App;

public final class f {
    public static boolean a() {
        NetworkInfo activeNetworkInfo;
        App app = b.a().a;
        if (app == null || (activeNetworkInfo = ((ConnectivityManager) app.getSystemService("connectivity")).getActiveNetworkInfo()) == null || !activeNetworkInfo.isConnectedOrConnecting()) {
            return false;
        }
        return true;
    }
}
