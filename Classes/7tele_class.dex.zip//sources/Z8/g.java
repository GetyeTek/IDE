package Z8;

import J8.b;
import android.content.SharedPreferences;

public final class g {
    public static g b;
    public SharedPreferences a;

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, Z8.g] */
    public static g b() {
        if (b == null) {
            b = new Object();
        }
        return b;
    }

    public final boolean a() {
        if (this.a == null && b.a().a != null) {
            this.a = b.a().a.getSharedPreferences("onemdos", 0);
        }
        if (this.a == null) {
            return true;
        }
        return false;
    }

    public final String c(String str) {
        if (a()) {
            return "";
        }
        return this.a.getString(str, "");
    }

    public final void d(String str, long j) {
        if (!a()) {
            this.a.edit().putLong(str, j).apply();
        }
    }

    public final void e(String str, String str2) {
        if (!a()) {
            this.a.edit().putString(str, str2).commit();
        }
    }
}
