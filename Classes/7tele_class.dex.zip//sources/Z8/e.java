package Z8;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public final class e {
    public static final Gson a = new GsonBuilder().disableHtmlEscaping().create();

    static {
        new GsonBuilder().enableComplexMapKeySerialization().create();
    }

    public static synchronized <T> T a(String str, Class<T> cls) {
        T fromJson;
        synchronized (e.class) {
            try {
                fromJson = a.fromJson(str, cls);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        return fromJson;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockFinish
        jadx.core.utils.exceptions.JadxRuntimeException: Dominance frontier not set for block: B:6:0x000b
        	at jadx.core.dex.nodes.BlockNode.lock(BlockNode.java:75)
        	at jadx.core.utils.ImmutableList.forEach(ImmutableList.java:108)
        	at jadx.core.dex.nodes.MethodNode.finishBasicBlocks(MethodNode.java:472)
        	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:27)
        */
    public static synchronized <T> T b(java.lang.String r2, java.lang.reflect.Type r3) {
        /*
            java.lang.Class<Z8.e> r0 = Z8.e.class
            monitor-enter(r0)
            com.google.gson.Gson r1 = a     // Catch:{ Exception -> 0x000e }
            java.lang.Object r2 = r1.fromJson(r2, r3)     // Catch:{ Exception -> 0x000e }
            monitor-exit(r0)
            return r2
        L_0x000b:
            r2 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x000b }
            throw r2
        L_0x000e:
            monitor-exit(r0)
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: Z8.e.b(java.lang.String, java.lang.reflect.Type):java.lang.Object");
    }

    public static synchronized String c(Object obj) {
        String json;
        synchronized (e.class) {
            json = a.toJson(obj);
        }
        return json;
    }
}
