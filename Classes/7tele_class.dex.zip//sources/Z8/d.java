package Z8;

import android.os.Handler;
import android.os.Looper;

public final class d {
    public static final Handler a = new Handler(Looper.getMainLooper());

    public static void a(Runnable runnable) {
        a.post(runnable);
    }
}
