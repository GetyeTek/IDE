package Z8;

public abstract class b<T> {

    public class a implements Runnable {
        public a() {
        }

        public final void run() {
            b.this.onStart();
        }
    }

    /* renamed from: Z8.b$b  reason: collision with other inner class name */
    public class C0017b implements Runnable {
        public final /* synthetic */ Object a;

        public C0017b(Object obj) {
            this.a = obj;
        }

        public final void run() {
            b bVar = b.this;
            bVar.onFinally();
            bVar.onSuccess(this.a);
        }
    }

    public class c implements Runnable {
        public final /* synthetic */ Exception a;

        public c(Exception exc) {
            this.a = exc;
        }

        public final void run() {
            b bVar = b.this;
            bVar.onFinally();
            bVar.onException(this.a);
        }
    }

    public b() {
        d.a(new a());
    }

    public void onApiException(Exception exc) {
        d.a(new c(exc));
    }

    public void onApiReceived(T t) {
        d.a(new C0017b(t));
    }

    public abstract void onException(Exception exc);

    public abstract void onSuccess(T t);

    public void onFinally() {
    }

    public void onStart() {
    }
}
