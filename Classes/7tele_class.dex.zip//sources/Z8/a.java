package Z8;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

public final class a {
    public static String a(Throwable th) {
        PrintWriter printWriter;
        StringWriter stringWriter = new StringWriter();
        try {
            printWriter = new PrintWriter(stringWriter);
            th.printStackTrace(printWriter);
            printWriter.flush();
            stringWriter.flush();
            printWriter.close();
            try {
                stringWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return stringWriter.toString();
        } catch (Throwable th2) {
            try {
                stringWriter.close();
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            throw th2;
        }
        throw th;
    }
}
