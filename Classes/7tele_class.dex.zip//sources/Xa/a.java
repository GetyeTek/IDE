package Xa;

public interface a {
}
