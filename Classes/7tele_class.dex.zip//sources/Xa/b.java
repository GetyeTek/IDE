package Xa;

import java.util.Enumeration;
import la.C0364g;
import la.C0390u;

public interface b {
    C0364g getBagAttribute(C0390u uVar);

    Enumeration getBagAttributeKeys();

    void setBagAttribute(C0390u uVar, C0364g gVar);
}
