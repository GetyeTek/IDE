package fc;

public final /* synthetic */ class g {
}
