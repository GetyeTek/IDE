package fc;

import androidx.appcompat.widget.L;
import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import javax.annotation.Nullable;
import okhttp3.HttpUrl;

public final class F {
    public static final Type[] a = new Type[0];

    public static final class a implements GenericArrayType {
        public final Type a;

        public a(Type type) {
            this.a = type;
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof GenericArrayType) || !F.b(this, (GenericArrayType) obj)) {
                return false;
            }
            return true;
        }

        public final Type getGenericComponentType() {
            return this.a;
        }

        public final int hashCode() {
            return this.a.hashCode();
        }

        public final String toString() {
            return F.n(this.a) + HttpUrl.PATH_SEGMENT_ENCODE_SET_URI;
        }
    }

    public static final class b implements ParameterizedType {
        @Nullable
        public final Type a;
        public final Type b;
        public final Type[] c;

        public b(@Nullable Type type, Type type2, Type... typeArr) {
            boolean z;
            if (type2 instanceof Class) {
                boolean z2 = true;
                if (type == null) {
                    z = true;
                } else {
                    z = false;
                }
                if (z != (((Class) type2).getEnclosingClass() != null ? false : z2)) {
                    throw new IllegalArgumentException();
                }
            }
            for (Type type3 : typeArr) {
                Objects.requireNonNull(type3, "typeArgument == null");
                F.a(type3);
            }
            this.a = type;
            this.b = type2;
            this.c = (Type[]) typeArr.clone();
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof ParameterizedType) || !F.b(this, (ParameterizedType) obj)) {
                return false;
            }
            return true;
        }

        public final Type[] getActualTypeArguments() {
            return (Type[]) this.c.clone();
        }

        @Nullable
        public final Type getOwnerType() {
            return this.a;
        }

        public final Type getRawType() {
            return this.b;
        }

        public final int hashCode() {
            int i;
            int hashCode = Arrays.hashCode(this.c) ^ this.b.hashCode();
            Type type = this.a;
            if (type != null) {
                i = type.hashCode();
            } else {
                i = 0;
            }
            return hashCode ^ i;
        }

        public final String toString() {
            Type[] typeArr = this.c;
            int length = typeArr.length;
            Type type = this.b;
            if (length == 0) {
                return F.n(type);
            }
            StringBuilder sb2 = new StringBuilder((typeArr.length + 1) * 30);
            sb2.append(F.n(type));
            sb2.append("<");
            sb2.append(F.n(typeArr[0]));
            for (int i = 1; i < typeArr.length; i++) {
                sb2.append(", ");
                sb2.append(F.n(typeArr[i]));
            }
            sb2.append(">");
            return sb2.toString();
        }
    }

    public static final class c implements WildcardType {
        public final Type a;
        @Nullable
        public final Type b;

        public c(Type[] typeArr, Type[] typeArr2) {
            if (typeArr2.length > 1) {
                throw new IllegalArgumentException();
            } else if (typeArr.length != 1) {
                throw new IllegalArgumentException();
            } else if (typeArr2.length == 1) {
                typeArr2[0].getClass();
                F.a(typeArr2[0]);
                Class<Object> cls = Object.class;
                if (typeArr[0] == cls) {
                    this.b = typeArr2[0];
                    this.a = cls;
                    return;
                }
                throw new IllegalArgumentException();
            } else {
                typeArr[0].getClass();
                F.a(typeArr[0]);
                this.b = null;
                this.a = typeArr[0];
            }
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof WildcardType) || !F.b(this, (WildcardType) obj)) {
                return false;
            }
            return true;
        }

        public final Type[] getLowerBounds() {
            Type type = this.b;
            if (type == null) {
                return F.a;
            }
            return new Type[]{type};
        }

        public final Type[] getUpperBounds() {
            return new Type[]{this.a};
        }

        public final int hashCode() {
            int i;
            Type type = this.b;
            if (type != null) {
                i = type.hashCode() + 31;
            } else {
                i = 1;
            }
            return i ^ (this.a.hashCode() + 31);
        }

        public final String toString() {
            Type type = this.b;
            if (type != null) {
                return "? super " + F.n(type);
            }
            Class<Object> cls = Object.class;
            Type type2 = this.a;
            if (type2 == cls) {
                return "?";
            }
            return "? extends " + F.n(type2);
        }
    }

    public static void a(Type type) {
        if ((type instanceof Class) && ((Class) type).isPrimitive()) {
            throw new IllegalArgumentException();
        }
    }

    public static boolean b(Type type, Type type2) {
        if (type == type2) {
            return true;
        }
        if (type instanceof Class) {
            return type.equals(type2);
        }
        if (type instanceof ParameterizedType) {
            if (!(type2 instanceof ParameterizedType)) {
                return false;
            }
            ParameterizedType parameterizedType = (ParameterizedType) type;
            ParameterizedType parameterizedType2 = (ParameterizedType) type2;
            Type ownerType = parameterizedType.getOwnerType();
            Type ownerType2 = parameterizedType2.getOwnerType();
            if ((ownerType == ownerType2 || (ownerType != null && ownerType.equals(ownerType2))) && parameterizedType.getRawType().equals(parameterizedType2.getRawType()) && Arrays.equals(parameterizedType.getActualTypeArguments(), parameterizedType2.getActualTypeArguments())) {
                return true;
            }
            return false;
        } else if (type instanceof GenericArrayType) {
            if (!(type2 instanceof GenericArrayType)) {
                return false;
            }
            return b(((GenericArrayType) type).getGenericComponentType(), ((GenericArrayType) type2).getGenericComponentType());
        } else if (type instanceof WildcardType) {
            if (!(type2 instanceof WildcardType)) {
                return false;
            }
            WildcardType wildcardType = (WildcardType) type;
            WildcardType wildcardType2 = (WildcardType) type2;
            if (!Arrays.equals(wildcardType.getUpperBounds(), wildcardType2.getUpperBounds()) || !Arrays.equals(wildcardType.getLowerBounds(), wildcardType2.getLowerBounds())) {
                return false;
            }
            return true;
        } else if (!(type instanceof TypeVariable) || !(type2 instanceof TypeVariable)) {
            return false;
        } else {
            TypeVariable typeVariable = (TypeVariable) type;
            TypeVariable typeVariable2 = (TypeVariable) type2;
            if (typeVariable.getGenericDeclaration() != typeVariable2.getGenericDeclaration() || !typeVariable.getName().equals(typeVariable2.getName())) {
                return false;
            }
            return true;
        }
    }

    public static Type c(Type type, Class<?> cls, Class<?> cls2) {
        if (cls2 == cls) {
            return type;
        }
        if (cls2.isInterface()) {
            Class<?>[] interfaces = cls.getInterfaces();
            int length = interfaces.length;
            for (int i = 0; i < length; i++) {
                Class<?> cls3 = interfaces[i];
                if (cls3 == cls2) {
                    return cls.getGenericInterfaces()[i];
                }
                if (cls2.isAssignableFrom(cls3)) {
                    return c(cls.getGenericInterfaces()[i], interfaces[i], cls2);
                }
            }
        }
        if (!cls.isInterface()) {
            while (cls != Object.class) {
                Class<? super Object> superclass = cls.getSuperclass();
                if (superclass == cls2) {
                    return cls.getGenericSuperclass();
                }
                if (cls2.isAssignableFrom(superclass)) {
                    return c(cls.getGenericSuperclass(), superclass, cls2);
                }
                cls = superclass;
            }
        }
        return cls2;
    }

    public static Type d(int i, ParameterizedType parameterizedType) {
        Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
        if (i < 0 || i >= actualTypeArguments.length) {
            StringBuilder a2 = L.a(i, "Index ", " not in range [0,");
            a2.append(actualTypeArguments.length);
            a2.append(") for ");
            a2.append(parameterizedType);
            throw new IllegalArgumentException(a2.toString());
        }
        Type type = actualTypeArguments[i];
        if (type instanceof WildcardType) {
            return ((WildcardType) type).getUpperBounds()[0];
        }
        return type;
    }

    public static Class<?> e(Type type) {
        Objects.requireNonNull(type, "type == null");
        if (type instanceof Class) {
            return (Class) type;
        }
        if (type instanceof ParameterizedType) {
            Type rawType = ((ParameterizedType) type).getRawType();
            if (rawType instanceof Class) {
                return (Class) rawType;
            }
            throw new IllegalArgumentException();
        } else if (type instanceof GenericArrayType) {
            return Array.newInstance(e(((GenericArrayType) type).getGenericComponentType()), 0).getClass();
        } else {
            if (type instanceof TypeVariable) {
                return Object.class;
            }
            if (type instanceof WildcardType) {
                return e(((WildcardType) type).getUpperBounds()[0]);
            }
            throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + type.getClass().getName());
        }
    }

    public static Type f(Type type, Class cls) {
        Class<Map> cls2 = Map.class;
        if (cls2.isAssignableFrom(cls)) {
            return l(type, cls, c(type, cls, cls2));
        }
        throw new IllegalArgumentException();
    }

    public static boolean g(@Nullable Type type) {
        String str;
        if (type instanceof Class) {
            return false;
        }
        if (type instanceof ParameterizedType) {
            for (Type g : ((ParameterizedType) type).getActualTypeArguments()) {
                if (g(g)) {
                    return true;
                }
            }
            return false;
        } else if (type instanceof GenericArrayType) {
            return g(((GenericArrayType) type).getGenericComponentType());
        } else {
            if ((type instanceof TypeVariable) || (type instanceof WildcardType)) {
                return true;
            }
            if (type == null) {
                str = "null";
            } else {
                str = type.getClass().getName();
            }
            throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + str);
        }
    }

    public static boolean h(Annotation[] annotationArr, Class<? extends Annotation> cls) {
        for (Annotation isInstance : annotationArr) {
            if (cls.isInstance(isInstance)) {
                return true;
            }
        }
        return false;
    }

    public static IllegalArgumentException i(Method method, @Nullable Exception exc, String str, Object... objArr) {
        StringBuilder a2 = androidx.camera.core.processing.util.a.a(String.format(str, objArr), "\n    for method ");
        a2.append(method.getDeclaringClass().getSimpleName());
        a2.append(".");
        a2.append(method.getName());
        return new IllegalArgumentException(a2.toString(), exc);
    }

    public static IllegalArgumentException j(Method method, int i, String str, Object... objArr) {
        StringBuilder a2 = androidx.camera.core.processing.util.a.a(str, " (parameter #");
        a2.append(i + 1);
        a2.append(")");
        return i(method, (Exception) null, a2.toString(), objArr);
    }

    public static IllegalArgumentException k(Method method, Exception exc, int i, String str, Object... objArr) {
        StringBuilder a2 = androidx.camera.core.processing.util.a.a(str, " (parameter #");
        a2.append(i + 1);
        a2.append(")");
        return i(method, exc, a2.toString(), objArr);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v14, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v5, resolved type: java.lang.reflect.Type[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v27, resolved type: java.lang.reflect.TypeVariable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v15, resolved type: java.lang.reflect.WildcardType} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v16, resolved type: java.lang.reflect.WildcardType} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v17, resolved type: java.lang.reflect.WildcardType} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0044 A[LOOP:0: B:1:0x0002->B:22:0x0044, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x0043 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.reflect.Type l(java.lang.reflect.Type r8, java.lang.Class<?> r9, java.lang.reflect.Type r10) {
        /*
            r0 = 0
            r1 = 1
        L_0x0002:
            boolean r2 = r10 instanceof java.lang.reflect.TypeVariable
            if (r2 == 0) goto L_0x0046
            java.lang.reflect.TypeVariable r10 = (java.lang.reflect.TypeVariable) r10
            java.lang.reflect.GenericDeclaration r2 = r10.getGenericDeclaration()
            boolean r3 = r2 instanceof java.lang.Class
            if (r3 == 0) goto L_0x0013
            java.lang.Class r2 = (java.lang.Class) r2
            goto L_0x0014
        L_0x0013:
            r2 = 0
        L_0x0014:
            if (r2 != 0) goto L_0x0018
        L_0x0016:
            r2 = r10
            goto L_0x0041
        L_0x0018:
            java.lang.reflect.Type r3 = c(r8, r9, r2)
            boolean r4 = r3 instanceof java.lang.reflect.ParameterizedType
            if (r4 == 0) goto L_0x0016
            java.lang.reflect.TypeVariable[] r2 = r2.getTypeParameters()
            r4 = 0
        L_0x0025:
            int r5 = r2.length
            if (r4 >= r5) goto L_0x003b
            r5 = r2[r4]
            boolean r5 = r10.equals(r5)
            if (r5 == 0) goto L_0x0039
            java.lang.reflect.ParameterizedType r3 = (java.lang.reflect.ParameterizedType) r3
            java.lang.reflect.Type[] r2 = r3.getActualTypeArguments()
            r2 = r2[r4]
            goto L_0x0041
        L_0x0039:
            int r4 = r4 + r1
            goto L_0x0025
        L_0x003b:
            java.util.NoSuchElementException r8 = new java.util.NoSuchElementException
            r8.<init>()
            throw r8
        L_0x0041:
            if (r2 != r10) goto L_0x0044
            return r2
        L_0x0044:
            r10 = r2
            goto L_0x0002
        L_0x0046:
            boolean r2 = r10 instanceof java.lang.Class
            if (r2 == 0) goto L_0x0064
            r2 = r10
            java.lang.Class r2 = (java.lang.Class) r2
            boolean r3 = r2.isArray()
            if (r3 == 0) goto L_0x0064
            java.lang.Class r10 = r2.getComponentType()
            java.lang.reflect.Type r8 = l(r8, r9, r10)
            if (r10 != r8) goto L_0x005e
            goto L_0x0063
        L_0x005e:
            fc.F$a r2 = new fc.F$a
            r2.<init>(r8)
        L_0x0063:
            return r2
        L_0x0064:
            boolean r2 = r10 instanceof java.lang.reflect.GenericArrayType
            if (r2 == 0) goto L_0x007b
            java.lang.reflect.GenericArrayType r10 = (java.lang.reflect.GenericArrayType) r10
            java.lang.reflect.Type r0 = r10.getGenericComponentType()
            java.lang.reflect.Type r8 = l(r8, r9, r0)
            if (r0 != r8) goto L_0x0075
            goto L_0x007a
        L_0x0075:
            fc.F$a r10 = new fc.F$a
            r10.<init>(r8)
        L_0x007a:
            return r10
        L_0x007b:
            boolean r2 = r10 instanceof java.lang.reflect.ParameterizedType
            if (r2 == 0) goto L_0x00ba
            java.lang.reflect.ParameterizedType r10 = (java.lang.reflect.ParameterizedType) r10
            java.lang.reflect.Type r2 = r10.getOwnerType()
            java.lang.reflect.Type r3 = l(r8, r9, r2)
            if (r3 == r2) goto L_0x008d
            r2 = 1
            goto L_0x008e
        L_0x008d:
            r2 = 0
        L_0x008e:
            java.lang.reflect.Type[] r4 = r10.getActualTypeArguments()
            int r5 = r4.length
        L_0x0093:
            if (r0 >= r5) goto L_0x00ad
            r6 = r4[r0]
            java.lang.reflect.Type r6 = l(r8, r9, r6)
            r7 = r4[r0]
            if (r6 == r7) goto L_0x00ab
            if (r2 != 0) goto L_0x00a9
            java.lang.Object r2 = r4.clone()
            r4 = r2
            java.lang.reflect.Type[] r4 = (java.lang.reflect.Type[]) r4
            r2 = 1
        L_0x00a9:
            r4[r0] = r6
        L_0x00ab:
            int r0 = r0 + r1
            goto L_0x0093
        L_0x00ad:
            if (r2 == 0) goto L_0x00b9
            fc.F$b r8 = new fc.F$b
            java.lang.reflect.Type r9 = r10.getRawType()
            r8.<init>(r3, r9, r4)
            r10 = r8
        L_0x00b9:
            return r10
        L_0x00ba:
            boolean r2 = r10 instanceof java.lang.reflect.WildcardType
            if (r2 == 0) goto L_0x0100
            java.lang.reflect.WildcardType r10 = (java.lang.reflect.WildcardType) r10
            java.lang.reflect.Type[] r2 = r10.getLowerBounds()
            java.lang.reflect.Type[] r3 = r10.getUpperBounds()
            int r4 = r2.length
            if (r4 != r1) goto L_0x00e5
            r3 = r2[r0]
            java.lang.reflect.Type r8 = l(r8, r9, r3)
            r9 = r2[r0]
            if (r8 == r9) goto L_0x0100
            fc.F$c r9 = new fc.F$c
            java.lang.reflect.Type[] r10 = new java.lang.reflect.Type[r1]
            java.lang.Class<java.lang.Object> r2 = java.lang.Object.class
            r10[r0] = r2
            java.lang.reflect.Type[] r1 = new java.lang.reflect.Type[r1]
            r1[r0] = r8
            r9.<init>(r10, r1)
            return r9
        L_0x00e5:
            int r2 = r3.length
            if (r2 != r1) goto L_0x0100
            r2 = r3[r0]
            java.lang.reflect.Type r8 = l(r8, r9, r2)     // Catch:{ all -> 0x00fe }
            r9 = r3[r0]
            if (r8 == r9) goto L_0x0100
            fc.F$c r9 = new fc.F$c
            java.lang.reflect.Type[] r10 = new java.lang.reflect.Type[r1]
            r10[r0] = r8
            java.lang.reflect.Type[] r8 = a
            r9.<init>(r10, r8)
            return r9
        L_0x00fe:
            r8 = move-exception
            throw r8
        L_0x0100:
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: fc.F.l(java.lang.reflect.Type, java.lang.Class, java.lang.reflect.Type):java.lang.reflect.Type");
    }

    public static void m(Throwable th) {
        if (th instanceof VirtualMachineError) {
            throw ((VirtualMachineError) th);
        } else if (th instanceof ThreadDeath) {
            throw ((ThreadDeath) th);
        } else if (th instanceof LinkageError) {
            throw ((LinkageError) th);
        }
    }

    public static String n(Type type) {
        if (type instanceof Class) {
            return ((Class) type).getName();
        }
        return type.toString();
    }
}
