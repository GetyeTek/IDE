package fc;

import java.io.IOException;
import javax.annotation.Nullable;

public final class u extends w<Iterable<Object>> {
    public final /* synthetic */ w a;

    public u(w wVar) {
        this.a = wVar;
    }

    public final void a(y yVar, @Nullable Object obj) throws IOException {
        Iterable<Object> iterable = (Iterable) obj;
        if (iterable != null) {
            for (Object a2 : iterable) {
                this.a.a(yVar, a2);
            }
        }
    }
}
