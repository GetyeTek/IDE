package fc;

import fc.l;
import java.lang.reflect.Type;
import java.util.concurrent.Executor;

public final class j implements C0268c<Object, C0267b<?>> {
    public final /* synthetic */ Type a;
    public final /* synthetic */ Executor b;

    public j(Type type, Executor executor) {
        this.a = type;
        this.b = executor;
    }

    public final Type a() {
        return this.a;
    }

    public final Object b(r rVar) {
        Executor executor = this.b;
        if (executor == null) {
            return rVar;
        }
        return new l.a(executor, rVar);
    }
}
