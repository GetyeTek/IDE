package fc;

import androidx.appcompat.widget.L;
import androidx.camera.camera2.internal.R0;
import fc.y;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSource;
import okio.ForwardingSource;
import okio.Okio;
import okio.Source;

public final class r<T> implements C0267b<T> {
    public final z a;
    public final Object[] b;
    public final Call.Factory c;
    public final i<ResponseBody, T> d;
    public volatile boolean e;
    @GuardedBy("this")
    @Nullable
    public Call f;
    @GuardedBy("this")
    @Nullable
    public Throwable g;
    @GuardedBy("this")
    public boolean h;

    public class a implements Callback {
        public final /* synthetic */ C0269d a;

        public a(C0269d dVar) {
            this.a = dVar;
        }

        public final void onFailure(Call call, IOException iOException) {
            try {
                this.a.b(r.this, iOException);
            } catch (Throwable th) {
                F.m(th);
                th.printStackTrace();
            }
        }

        public final void onResponse(Call call, Response response) {
            C0269d dVar = this.a;
            r rVar = r.this;
            try {
                try {
                    dVar.a(rVar, rVar.e(response));
                } catch (Throwable th) {
                    F.m(th);
                    th.printStackTrace();
                }
            } catch (Throwable th2) {
                F.m(th2);
                th2.printStackTrace();
            }
        }
    }

    public static final class b extends ResponseBody {
        public final ResponseBody a;
        public final BufferedSource b;
        @Nullable
        public IOException c;

        public class a extends ForwardingSource {
            public a(BufferedSource bufferedSource) {
                super(bufferedSource);
            }

            public final long read(Buffer buffer, long j) throws IOException {
                try {
                    return super.read(buffer, j);
                } catch (IOException e) {
                    b.this.c = e;
                    throw e;
                }
            }
        }

        public b(ResponseBody responseBody) {
            this.a = responseBody;
            this.b = Okio.buffer((Source) new a(responseBody.source()));
        }

        public final void close() {
            this.a.close();
        }

        public final long contentLength() {
            return this.a.contentLength();
        }

        public final MediaType contentType() {
            return this.a.contentType();
        }

        public final BufferedSource source() {
            return this.b;
        }
    }

    public static final class c extends ResponseBody {
        @Nullable
        public final MediaType a;
        public final long b;

        public c(@Nullable MediaType mediaType, long j) {
            this.a = mediaType;
            this.b = j;
        }

        public final long contentLength() {
            return this.b;
        }

        public final MediaType contentType() {
            return this.a;
        }

        public final BufferedSource source() {
            throw new IllegalStateException("Cannot read raw response body of a converted body.");
        }
    }

    public r(z zVar, Object[] objArr, Call.Factory factory, i<ResponseBody, T> iVar) {
        this.a = zVar;
        this.b = objArr;
        this.c = factory;
        this.d = iVar;
    }

    public final void a(C0269d<T> dVar) {
        Call call;
        Throwable th;
        synchronized (this) {
            try {
                if (!this.h) {
                    this.h = true;
                    call = this.f;
                    th = this.g;
                    if (call == null && th == null) {
                        Call b2 = b();
                        this.f = b2;
                        call = b2;
                    }
                } else {
                    throw new IllegalStateException("Already executed.");
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (th != null) {
            dVar.b(this, th);
            return;
        }
        if (this.e) {
            call.cancel();
        }
        call.enqueue(new a(dVar));
    }

    public final Call b() throws IOException {
        HttpUrl httpUrl;
        z zVar = this.a;
        zVar.getClass();
        Object[] objArr = this.b;
        int length = objArr.length;
        w<?>[] wVarArr = zVar.j;
        if (length == wVarArr.length) {
            y yVar = new y(zVar.c, zVar.b, zVar.d, zVar.e, zVar.f, zVar.g, zVar.h, zVar.i);
            if (zVar.k) {
                length--;
            }
            ArrayList arrayList = new ArrayList(length);
            for (int i = 0; i < length; i++) {
                arrayList.add(objArr[i]);
                wVarArr[i].a(yVar, objArr[i]);
            }
            HttpUrl.Builder builder = yVar.d;
            if (builder != null) {
                httpUrl = builder.build();
            } else {
                String str = yVar.c;
                HttpUrl httpUrl2 = yVar.b;
                httpUrl = httpUrl2.resolve(str);
                if (httpUrl == null) {
                    throw new IllegalArgumentException("Malformed URL. Base: " + httpUrl2 + ", Relative: " + yVar.c);
                }
            }
            y.a aVar = yVar.k;
            if (aVar == null) {
                FormBody.Builder builder2 = yVar.j;
                if (builder2 != null) {
                    aVar = builder2.build();
                } else {
                    MultipartBody.Builder builder3 = yVar.i;
                    if (builder3 != null) {
                        aVar = builder3.build();
                    } else if (yVar.h) {
                        aVar = RequestBody.create((MediaType) null, new byte[0]);
                    }
                }
            }
            MediaType mediaType = yVar.g;
            Headers.Builder builder4 = yVar.f;
            if (mediaType != null) {
                if (aVar != null) {
                    aVar = new y.a(aVar, mediaType);
                } else {
                    builder4.add("Content-Type", mediaType.toString());
                }
            }
            Call newCall = this.c.newCall(yVar.e.url(httpUrl).headers(builder4.build()).method(yVar.a, aVar).tag(n.class, new n(zVar.a, arrayList)).build());
            if (newCall != null) {
                return newCall;
            }
            throw new NullPointerException("Call.Factory returned null.");
        }
        throw new IllegalArgumentException(R0.a(L.a(length, "Argument count (", ") doesn't match expected count ("), ")", wVarArr.length));
    }

    public final A<T> c() throws IOException {
        Call d2;
        synchronized (this) {
            if (!this.h) {
                this.h = true;
                d2 = d();
            } else {
                throw new IllegalStateException("Already executed.");
            }
        }
        if (this.e) {
            d2.cancel();
        }
        return e(d2.execute());
    }

    public final void cancel() {
        Call call;
        this.e = true;
        synchronized (this) {
            call = this.f;
        }
        if (call != null) {
            call.cancel();
        }
    }

    public final C0267b clone() {
        return new r(this.a, this.b, this.c, this.d);
    }

    @GuardedBy("this")
    public final Call d() throws IOException {
        Call call = this.f;
        if (call != null) {
            return call;
        }
        Throwable th = this.g;
        if (th == null) {
            try {
                Call b2 = b();
                this.f = b2;
                return b2;
            } catch (IOException | Error | RuntimeException e2) {
                F.m(e2);
                this.g = e2;
                throw e2;
            }
        } else if (th instanceof IOException) {
            throw ((IOException) th);
        } else if (th instanceof RuntimeException) {
            throw ((RuntimeException) th);
        } else {
            throw ((Error) th);
        }
    }

    public final A<T> e(Response response) throws IOException {
        ResponseBody body = response.body();
        Response build = response.newBuilder().body(new c(body.contentType(), body.contentLength())).build();
        int code = build.code();
        if (code < 200 || code >= 300) {
            try {
                Buffer buffer = new Buffer();
                body.source().readAll(buffer);
                ResponseBody create = ResponseBody.create(body.contentType(), body.contentLength(), (BufferedSource) buffer);
                Objects.requireNonNull(create, "body == null");
                if (!build.isSuccessful()) {
                    return new A<>(build, null, create);
                }
                throw new IllegalArgumentException("rawResponse should not be successful response");
            } finally {
                body.close();
            }
        } else if (code == 204 || code == 205) {
            body.close();
            if (build.isSuccessful()) {
                return new A<>(build, null, (ResponseBody) null);
            }
            throw new IllegalArgumentException("rawResponse must be successful response");
        } else {
            b bVar = new b(body);
            try {
                T a2 = this.d.a(bVar);
                if (build.isSuccessful()) {
                    return new A<>(build, a2, (ResponseBody) null);
                }
                throw new IllegalArgumentException("rawResponse must be successful response");
            } catch (RuntimeException e2) {
                IOException iOException = bVar.c;
                if (iOException == null) {
                    throw e2;
                }
                throw iOException;
            }
        }
    }

    public final boolean isCanceled() {
        boolean z = true;
        if (this.e) {
            return true;
        }
        synchronized (this) {
            try {
                Call call = this.f;
                if (call == null || !call.isCanceled()) {
                    z = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return z;
    }

    public final synchronized Request request() {
        try {
        } catch (IOException e2) {
            throw new RuntimeException("Unable to create request.", e2);
        }
        return d().request();
    }

    /* renamed from: clone  reason: collision with other method in class */
    public final Object m0clone() throws CloneNotSupportedException {
        return new r(this.a, this.b, this.c, this.d);
    }
}
