package fc;

import okhttp3.Request;

/* renamed from: fc.b  reason: case insensitive filesystem */
public interface C0267b<T> extends Cloneable {
    void a(C0269d<T> dVar);

    void cancel();

    C0267b<T> clone();

    boolean isCanceled();

    Request request();
}
