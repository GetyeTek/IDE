package fc;

import androidx.camera.camera2.internal.P;
import fc.C0266a;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Objects;
import javax.annotation.Nullable;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okio.Buffer;

public abstract class w<T> {

    public static final class a<T> extends w<T> {
        public final Method a;
        public final int b;
        public final i<T, RequestBody> c;

        public a(Method method, int i, i<T, RequestBody> iVar) {
            this.a = method;
            this.b = i;
            this.c = iVar;
        }

        public final void a(y yVar, @Nullable T t) {
            Method method = this.a;
            int i = this.b;
            if (t != null) {
                try {
                    yVar.k = this.c.a(t);
                } catch (IOException e) {
                    throw F.k(method, e, i, "Unable to convert " + t + " to RequestBody", new Object[0]);
                }
            } else {
                throw F.j(method, i, "Body parameter value must not be null.", new Object[0]);
            }
        }
    }

    public static final class b<T> extends w<T> {
        public final String a;
        public final C0266a.d b;
        public final boolean c;

        public b(String str, boolean z) {
            C0266a.d dVar = C0266a.d.a;
            Objects.requireNonNull(str, "name == null");
            this.a = str;
            this.b = dVar;
            this.c = z;
        }

        public final void a(y yVar, @Nullable T t) throws IOException {
            if (t != null) {
                this.b.getClass();
                String obj = t.toString();
                if (obj != null) {
                    FormBody.Builder builder = yVar.j;
                    String str = this.a;
                    if (this.c) {
                        builder.addEncoded(str, obj);
                    } else {
                        builder.add(str, obj);
                    }
                }
            }
        }
    }

    public static final class c<T> extends w<Map<String, T>> {
        public final Method a;
        public final int b;
        public final boolean c;

        public c(Method method, int i, boolean z) {
            this.a = method;
            this.b = i;
            this.c = z;
        }

        public final void a(y yVar, @Nullable Object obj) throws IOException {
            Map map = (Map) obj;
            Method method = this.a;
            int i = this.b;
            if (map != null) {
                for (Map.Entry entry : map.entrySet()) {
                    String str = (String) entry.getKey();
                    if (str != null) {
                        Object value = entry.getValue();
                        if (value != null) {
                            String obj2 = value.toString();
                            if (obj2 != null) {
                                FormBody.Builder builder = yVar.j;
                                if (this.c) {
                                    builder.addEncoded(str, obj2);
                                } else {
                                    builder.add(str, obj2);
                                }
                            } else {
                                throw F.j(method, i, "Field map value '" + value + "' converted to null by " + C0266a.d.class.getName() + " for key '" + str + "'.", new Object[0]);
                            }
                        } else {
                            throw F.j(method, i, P.a("Field map contained null value for key '", str, "'."), new Object[0]);
                        }
                    } else {
                        throw F.j(method, i, "Field map contained null key.", new Object[0]);
                    }
                }
                return;
            }
            throw F.j(method, i, "Field map was null.", new Object[0]);
        }
    }

    public static final class d<T> extends w<T> {
        public final String a;
        public final C0266a.d b;

        public d(String str) {
            C0266a.d dVar = C0266a.d.a;
            Objects.requireNonNull(str, "name == null");
            this.a = str;
            this.b = dVar;
        }

        public final void a(y yVar, @Nullable T t) throws IOException {
            if (t != null) {
                this.b.getClass();
                String obj = t.toString();
                if (obj != null) {
                    yVar.a(this.a, obj);
                }
            }
        }
    }

    public static final class e<T> extends w<Map<String, T>> {
        public final Method a;
        public final int b;

        public e(Method method, int i) {
            this.a = method;
            this.b = i;
        }

        public final void a(y yVar, @Nullable Object obj) throws IOException {
            Map map = (Map) obj;
            Method method = this.a;
            int i = this.b;
            if (map != null) {
                for (Map.Entry entry : map.entrySet()) {
                    String str = (String) entry.getKey();
                    if (str != null) {
                        Object value = entry.getValue();
                        if (value != null) {
                            yVar.a(str, value.toString());
                        } else {
                            throw F.j(method, i, P.a("Header map contained null value for key '", str, "'."), new Object[0]);
                        }
                    } else {
                        throw F.j(method, i, "Header map contained null key.", new Object[0]);
                    }
                }
                return;
            }
            throw F.j(method, i, "Header map was null.", new Object[0]);
        }
    }

    public static final class f extends w<Headers> {
        public final Method a;
        public final int b;

        public f(Method method, int i) {
            this.a = method;
            this.b = i;
        }

        public final void a(y yVar, @Nullable Object obj) throws IOException {
            Headers headers = (Headers) obj;
            if (headers != null) {
                yVar.f.addAll(headers);
                return;
            }
            throw F.j(this.a, this.b, "Headers parameter must not be null.", new Object[0]);
        }
    }

    public static final class g<T> extends w<T> {
        public final Method a;
        public final int b;
        public final Headers c;
        public final i<T, RequestBody> d;

        public g(Method method, int i, Headers headers, i<T, RequestBody> iVar) {
            this.a = method;
            this.b = i;
            this.c = headers;
            this.d = iVar;
        }

        public final void a(y yVar, @Nullable T t) {
            if (t != null) {
                try {
                    yVar.i.addPart(this.c, this.d.a(t));
                } catch (IOException e) {
                    throw F.j(this.a, this.b, "Unable to convert " + t + " to RequestBody", e);
                }
            }
        }
    }

    public static final class h<T> extends w<Map<String, T>> {
        public final Method a;
        public final int b;
        public final i<T, RequestBody> c;
        public final String d;

        public h(Method method, int i, i<T, RequestBody> iVar, String str) {
            this.a = method;
            this.b = i;
            this.c = iVar;
            this.d = str;
        }

        public final void a(y yVar, @Nullable Object obj) throws IOException {
            Map map = (Map) obj;
            Method method = this.a;
            int i = this.b;
            if (map != null) {
                for (Map.Entry entry : map.entrySet()) {
                    String str = (String) entry.getKey();
                    if (str != null) {
                        Object value = entry.getValue();
                        if (value != null) {
                            yVar.i.addPart(Headers.of("Content-Disposition", P.a("form-data; name=\"", str, "\""), "Content-Transfer-Encoding", this.d), this.c.a(value));
                        } else {
                            throw F.j(method, i, P.a("Part map contained null value for key '", str, "'."), new Object[0]);
                        }
                    } else {
                        throw F.j(method, i, "Part map contained null key.", new Object[0]);
                    }
                }
                return;
            }
            throw F.j(method, i, "Part map was null.", new Object[0]);
        }
    }

    public static final class i<T> extends w<T> {
        public final Method a;
        public final int b;
        public final String c;
        public final C0266a.d d;
        public final boolean e;

        public i(Method method, int i, String str, boolean z) {
            C0266a.d dVar = C0266a.d.a;
            this.a = method;
            this.b = i;
            Objects.requireNonNull(str, "name == null");
            this.c = str;
            this.d = dVar;
            this.e = z;
        }

        public final void a(y yVar, @Nullable T t) throws IOException {
            String str;
            boolean z;
            int i;
            int i2;
            y yVar2 = yVar;
            String str2 = this.c;
            if (t != null) {
                this.d.getClass();
                String obj = t.toString();
                if (yVar2.c != null) {
                    int length = obj.length();
                    int i3 = 0;
                    while (true) {
                        if (i3 >= length) {
                            str = obj;
                            break;
                        }
                        int codePointAt = obj.codePointAt(i3);
                        z = this.e;
                        i = 47;
                        i2 = -1;
                        if (codePointAt < 32 || codePointAt >= 127 || " \"<>^`{}|\\?#".indexOf(codePointAt) != -1 || (!z && (codePointAt == 47 || codePointAt == 37))) {
                            Buffer buffer = new Buffer();
                            buffer.writeUtf8(obj, 0, i3);
                            Buffer buffer2 = null;
                        } else {
                            i3 += Character.charCount(codePointAt);
                        }
                    }
                    Buffer buffer3 = new Buffer();
                    buffer3.writeUtf8(obj, 0, i3);
                    Buffer buffer22 = null;
                    while (i3 < length) {
                        int codePointAt2 = obj.codePointAt(i3);
                        if (!z || !(codePointAt2 == 9 || codePointAt2 == 10 || codePointAt2 == 12 || codePointAt2 == 13)) {
                            if (codePointAt2 < 32 || codePointAt2 >= 127 || " \"<>^`{}|\\?#".indexOf(codePointAt2) != i2 || (!z && (codePointAt2 == i || codePointAt2 == 37))) {
                                if (buffer22 == null) {
                                    buffer22 = new Buffer();
                                }
                                buffer22.writeUtf8CodePoint(codePointAt2);
                                while (!buffer22.exhausted()) {
                                    byte readByte = buffer22.readByte();
                                    buffer3.writeByte(37);
                                    char[] cArr = y.l;
                                    buffer3.writeByte((int) cArr[((readByte & 255) >> 4) & 15]);
                                    buffer3.writeByte((int) cArr[readByte & 15]);
                                }
                            } else {
                                buffer3.writeUtf8CodePoint(codePointAt2);
                            }
                        }
                        i3 += Character.charCount(codePointAt2);
                        i = 47;
                        i2 = -1;
                    }
                    str = buffer3.readUtf8();
                    String str3 = yVar2.c;
                    String replace = str3.replace("{" + str2 + "}", str);
                    if (!y.m.matcher(replace).matches()) {
                        yVar2.c = replace;
                        return;
                    }
                    throw new IllegalArgumentException("@Path parameters shouldn't perform path traversal ('.' or '..'): ".concat(obj));
                }
                throw new AssertionError();
            }
            throw F.j(this.a, this.b, P.a("Path parameter \"", str2, "\" value must not be null."), new Object[0]);
        }
    }

    public static final class j<T> extends w<T> {
        public final String a;
        public final C0266a.d b;
        public final boolean c;

        public j(String str, boolean z) {
            C0266a.d dVar = C0266a.d.a;
            Objects.requireNonNull(str, "name == null");
            this.a = str;
            this.b = dVar;
            this.c = z;
        }

        public final void a(y yVar, @Nullable T t) throws IOException {
            if (t != null) {
                this.b.getClass();
                String obj = t.toString();
                if (obj != null) {
                    yVar.b(this.a, obj, this.c);
                }
            }
        }
    }

    public static final class k<T> extends w<Map<String, T>> {
        public final Method a;
        public final int b;
        public final boolean c;

        public k(Method method, int i, boolean z) {
            this.a = method;
            this.b = i;
            this.c = z;
        }

        public final void a(y yVar, @Nullable Object obj) throws IOException {
            Map map = (Map) obj;
            Method method = this.a;
            int i = this.b;
            if (map != null) {
                for (Map.Entry entry : map.entrySet()) {
                    String str = (String) entry.getKey();
                    if (str != null) {
                        Object value = entry.getValue();
                        if (value != null) {
                            String obj2 = value.toString();
                            if (obj2 != null) {
                                yVar.b(str, obj2, this.c);
                            } else {
                                throw F.j(method, i, "Query map value '" + value + "' converted to null by " + C0266a.d.class.getName() + " for key '" + str + "'.", new Object[0]);
                            }
                        } else {
                            throw F.j(method, i, P.a("Query map contained null value for key '", str, "'."), new Object[0]);
                        }
                    } else {
                        throw F.j(method, i, "Query map contained null key.", new Object[0]);
                    }
                }
                return;
            }
            throw F.j(method, i, "Query map was null", new Object[0]);
        }
    }

    public static final class l<T> extends w<T> {
        public final boolean a;

        public l(boolean z) {
            this.a = z;
        }

        public final void a(y yVar, @Nullable T t) throws IOException {
            if (t != null) {
                yVar.b(t.toString(), (String) null, this.a);
            }
        }
    }

    public static final class m extends w<MultipartBody.Part> {
        public static final m a = new Object();

        public final void a(y yVar, @Nullable Object obj) throws IOException {
            MultipartBody.Part part = (MultipartBody.Part) obj;
            if (part != null) {
                yVar.i.addPart(part);
            }
        }
    }

    public static final class n extends w<Object> {
        public final Method a;
        public final int b;

        public n(Method method, int i) {
            this.a = method;
            this.b = i;
        }

        public final void a(y yVar, @Nullable Object obj) {
            if (obj != null) {
                yVar.c = obj.toString();
                return;
            }
            throw F.j(this.a, this.b, "@Url parameter is null.", new Object[0]);
        }
    }

    public static final class o<T> extends w<T> {
        public final Class<T> a;

        public o(Class<T> cls) {
            this.a = cls;
        }

        public final void a(y yVar, @Nullable T t) {
            yVar.e.tag(this.a, t);
        }
    }

    public abstract void a(y yVar, @Nullable T t) throws IOException;
}
