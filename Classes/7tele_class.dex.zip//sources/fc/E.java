package fc;

import java.lang.annotation.Annotation;

public final class E implements D {
    public static final E a = new Object();

    public final Class<? extends Annotation> annotationType() {
        return D.class;
    }

    public final boolean equals(Object obj) {
        return obj instanceof D;
    }

    public final int hashCode() {
        return 0;
    }

    public final String toString() {
        return "@" + D.class.getName() + "()";
    }
}
