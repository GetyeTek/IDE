package fc;

import c6.v;
import ca.C0121i;
import com.huawei.digitalpayment.customer.login_module.upgrade.d;
import javax.annotation.Nullable;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import okhttp3.Call;
import okhttp3.ResponseBody;

public abstract class m<ResponseT, ReturnT> extends C<ReturnT> {
    public final z a;
    public final Call.Factory b;
    public final i<ResponseBody, ResponseT> c;

    public static final class a<ResponseT, ReturnT> extends m<ResponseT, ReturnT> {
        public final C0268c<ResponseT, ReturnT> d;

        public a(z zVar, Call.Factory factory, i<ResponseBody, ResponseT> iVar, C0268c<ResponseT, ReturnT> cVar) {
            super(zVar, factory, iVar);
            this.d = cVar;
        }

        public final Object c(r rVar, Object[] objArr) {
            return this.d.b(rVar);
        }
    }

    public static final class b<ResponseT> extends m<ResponseT, Object> {
        public final C0268c<ResponseT, C0267b<ResponseT>> d;

        public b(z zVar, Call.Factory factory, i iVar, C0268c cVar) {
            super(zVar, factory, iVar);
            this.d = cVar;
        }

        public final Object c(r rVar, Object[] objArr) {
            C0267b bVar = (C0267b) this.d.b(rVar);
            L9.a aVar = objArr[objArr.length - 1];
            try {
                C0121i iVar = new C0121i(1, i3.a.d(aVar));
                iVar.t(new o(bVar));
                bVar.a(new v(iVar));
                Object q = iVar.q();
                CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
                return q;
            } catch (Exception e) {
                return q.a(e, aVar);
            }
        }
    }

    public static final class c<ResponseT> extends m<ResponseT, Object> {
        public final C0268c<ResponseT, C0267b<ResponseT>> d;

        public c(z zVar, Call.Factory factory, i<ResponseBody, ResponseT> iVar, C0268c<ResponseT, C0267b<ResponseT>> cVar) {
            super(zVar, factory, iVar);
            this.d = cVar;
        }

        public final Object c(r rVar, Object[] objArr) {
            C0267b bVar = (C0267b) this.d.b(rVar);
            L9.a aVar = objArr[objArr.length - 1];
            try {
                C0121i iVar = new C0121i(1, i3.a.d(aVar));
                iVar.t(new p(bVar));
                bVar.a(new d(iVar, 1));
                Object q = iVar.q();
                CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
                return q;
            } catch (Exception e) {
                return q.a(e, aVar);
            }
        }
    }

    public m(z zVar, Call.Factory factory, i<ResponseBody, ResponseT> iVar) {
        this.a = zVar;
        this.b = factory;
        this.c = iVar;
    }

    @Nullable
    public final ReturnT a(Object[] objArr) {
        return c(new r(this.a, objArr, this.b, this.c), objArr);
    }

    @Nullable
    public abstract Object c(r rVar, Object[] objArr);
}
