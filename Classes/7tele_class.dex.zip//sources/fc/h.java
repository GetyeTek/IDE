package fc;

import androidx.core.location.p;
import androidx.core.location.q;
import fc.C0268c;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.concurrent.CompletableFuture;
import javax.annotation.Nullable;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;
import retrofit2.HttpException;

@IgnoreJRERequirement
public final class h extends C0268c.a {
    public static final h a = new C0268c.a();

    @IgnoreJRERequirement
    public static final class a<R> implements C0268c<R, CompletableFuture<R>> {
        public final Type a;

        @IgnoreJRERequirement
        /* renamed from: fc.h$a$a  reason: collision with other inner class name */
        public class C0025a implements C0269d<R> {
            public final b a;

            public C0025a(b bVar) {
                this.a = bVar;
            }

            public final void a(C0267b<R> bVar, A<R> a2) {
                boolean isSuccessful = a2.a.isSuccessful();
                b bVar2 = this.a;
                if (isSuccessful) {
                    bVar2.complete(a2.b);
                } else {
                    p.b(bVar2, new HttpException(a2));
                }
            }

            public final void b(C0267b<R> bVar, Throwable th) {
                this.a.completeExceptionally(th);
            }
        }

        public a(Type type) {
            this.a = type;
        }

        public final Type a() {
            return this.a;
        }

        public final Object b(r rVar) {
            b bVar = new b(rVar);
            rVar.a(new C0025a(bVar));
            return bVar;
        }
    }

    @IgnoreJRERequirement
    public static final class b<T> extends CompletableFuture<T> {
        public final r a;

        public b(r rVar) {
            this.a = rVar;
        }

        public final boolean cancel(boolean z) {
            if (z) {
                this.a.cancel();
            }
            return super.cancel(z);
        }
    }

    @IgnoreJRERequirement
    public static final class c<R> implements C0268c<R, CompletableFuture<A<R>>> {
        public final Type a;

        @IgnoreJRERequirement
        public class a implements C0269d<R> {
            public final b a;

            public a(b bVar) {
                this.a = bVar;
            }

            public final void a(C0267b<R> bVar, A<R> a2) {
                q.b(this.a, a2);
            }

            public final void b(C0267b<R> bVar, Throwable th) {
                this.a.completeExceptionally(th);
            }
        }

        public c(Type type) {
            this.a = type;
        }

        public final Type a() {
            return this.a;
        }

        public final Object b(r rVar) {
            b bVar = new b(rVar);
            rVar.a(new a(bVar));
            return bVar;
        }
    }

    @Nullable
    public final C0268c a(Type type, Annotation[] annotationArr) {
        if (F.e(type) != C0270e.a()) {
            return null;
        }
        if (type instanceof ParameterizedType) {
            Type d = F.d(0, (ParameterizedType) type);
            if (F.e(d) != A.class) {
                return new a(d);
            }
            if (d instanceof ParameterizedType) {
                return new c(F.d(0, (ParameterizedType) d));
            }
            throw new IllegalStateException("Response must be parameterized as Response<Foo> or Response<? extends Foo>");
        }
        throw new IllegalStateException("CompletableFuture return type must be parameterized as CompletableFuture<Foo> or CompletableFuture<? extends Foo>");
    }
}
