package fc;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.d;
import androidx.appcompat.app.e;
import androidx.core.app.b;
import androidx.core.app.c;
import androidx.core.content.pm.Q;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.concurrent.Executor;
import javax.annotation.Nullable;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;

public class x {
    public static final x c;
    public final boolean a;
    @Nullable
    public final Constructor<MethodHandles.Lookup> b;

    public static final class a extends x {

        /* renamed from: fc.x$a$a  reason: collision with other inner class name */
        public static final class C0027a implements Executor {
            public final Handler a = new Handler(Looper.getMainLooper());

            public final void execute(Runnable runnable) {
                this.a.post(runnable);
            }
        }

        public final Executor a() {
            return new C0027a();
        }

        @Nullable
        public final Object b(Method method, Class<?> cls, Object obj, Object... objArr) throws Throwable {
            if (Build.VERSION.SDK_INT >= 26) {
                return x.super.b(method, cls, obj, objArr);
            }
            throw new UnsupportedOperationException("Calling default methods on API 24 and 25 is not supported");
        }
    }

    static {
        x xVar;
        boolean z = true;
        if ("Dalvik".equals(System.getProperty("java.vm.name"))) {
            if (Build.VERSION.SDK_INT < 24) {
                z = false;
            }
            xVar = new x(z);
        } else {
            xVar = new x(true);
        }
        c = xVar;
    }

    public x(boolean z) {
        this.a = z;
        Constructor<MethodHandles.Lookup> constructor = null;
        if (z) {
            try {
                constructor = androidx.media.a.c().getDeclaredConstructor(new Class[]{Class.class, Integer.TYPE});
                constructor.setAccessible(true);
            } catch (NoClassDefFoundError | NoSuchMethodException unused) {
            }
        }
        this.b = constructor;
    }

    @Nullable
    public Executor a() {
        return null;
    }

    @Nullable
    @IgnoreJRERequirement
    public Object b(Method method, Class<?> cls, Object obj, Object... objArr) throws Throwable {
        MethodHandles.Lookup lookup;
        Constructor<MethodHandles.Lookup> constructor = this.b;
        if (constructor != null) {
            lookup = Q.c(constructor.newInstance(new Object[]{cls, -1}));
        } else {
            lookup = d.c();
        }
        return c.a(b.b(e.b(lookup, method, cls), obj), objArr);
    }
}
