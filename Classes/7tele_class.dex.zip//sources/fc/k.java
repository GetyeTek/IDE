package fc;

import fc.l;
import java.io.IOException;

public final /* synthetic */ class k implements Runnable {
    public final /* synthetic */ l.a.C0026a a;
    public final /* synthetic */ C0269d b;
    public final /* synthetic */ A c;

    public /* synthetic */ k(l.a.C0026a aVar, C0269d dVar, A a2) {
        this.a = aVar;
        this.b = dVar;
        this.c = a2;
    }

    public final void run() {
        l.a aVar = l.a.this;
        boolean isCanceled = aVar.b.isCanceled();
        C0269d dVar = this.b;
        if (isCanceled) {
            dVar.b(aVar, new IOException("Canceled"));
        } else {
            dVar.a(aVar, this.c);
        }
    }
}
