package fc;

import java.io.IOException;
import java.lang.reflect.Array;
import javax.annotation.Nullable;

public final class v extends w<Object> {
    public final /* synthetic */ w a;

    public v(w wVar) {
        this.a = wVar;
    }

    public final void a(y yVar, @Nullable Object obj) throws IOException {
        if (obj != null) {
            int length = Array.getLength(obj);
            for (int i = 0; i < length; i++) {
                this.a.a(yVar, Array.get(obj, i));
            }
        }
    }
}
