package fc;

import M9.c;
import kotlin.Result;
import kotlin.coroutines.jvm.internal.ContinuationImpl;

public final class q {

    public static final class a implements Runnable {
        public final /* synthetic */ b a;
        public final /* synthetic */ Exception b;

        public a(b bVar, Exception exc) {
            this.a = bVar;
            this.b = exc;
        }

        public final void run() {
            i3.a.d(this.a).resumeWith(Result.m2constructorimpl(kotlin.a.a(this.b)));
        }
    }

    @c(c = "retrofit2.KotlinExtensions", f = "KotlinExtensions.kt", l = {113}, m = "suspendAndThrow")
    public static final class b extends ContinuationImpl {
        public /* synthetic */ Object h;
        public int i;

        public final Object invokeSuspend(Object obj) {
            this.h = obj;
            this.i |= Integer.MIN_VALUE;
            return q.a((Exception) null, this);
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [kotlin.coroutines.jvm.internal.ContinuationImpl] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0031  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.Object a(java.lang.Exception r4, L9.a<?> r5) {
        /*
            boolean r0 = r5 instanceof fc.q.b
            if (r0 == 0) goto L_0x0013
            r0 = r5
            fc.q$b r0 = (fc.q.b) r0
            int r1 = r0.i
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.i = r1
            goto L_0x0018
        L_0x0013:
            fc.q$b r0 = new fc.q$b
            r0.<init>(r5)
        L_0x0018:
            java.lang.Object r5 = r0.h
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.i
            r3 = 1
            if (r2 == 0) goto L_0x0031
            if (r2 != r3) goto L_0x0029
            kotlin.a.b(r5)
            H9.j r4 = H9.j.a
            return r4
        L_0x0029:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L_0x0031:
            kotlin.a.b(r5)
            r0.i = r3
            ha.b r5 = ca.P.a
            kotlin.coroutines.d r2 = r0.getContext()
            fc.q$a r3 = new fc.q$a
            r3.<init>(r0, r4)
            r5.dispatch(r2, r3)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: fc.q.a(java.lang.Exception, L9.a):java.lang.Object");
    }
}
