package fc;

import javax.annotation.Nullable;

public abstract class C<T> {
    /* JADX WARNING: Code restructure failed: missing block: B:368:0x0869, code lost:
        throw fc.F.j(r10, r9, "@Body parameters cannot be used with form or multi-part encoding.", new java.lang.Object[0]);
     */
    /* JADX WARNING: Removed duplicated region for block: B:385:0x08c7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static fc.m b(fc.B r26, java.lang.reflect.Method r27) {
        /*
            r0 = r26
            r1 = r27
            r3 = -1
            r4 = 0
            r5 = 1
            fc.z$a r6 = new fc.z$a
            r6.<init>(r0, r1)
            java.lang.annotation.Annotation[] r7 = r6.c
            int r8 = r7.length
            r9 = 0
        L_0x0010:
            java.lang.reflect.Method r10 = r6.b
            java.lang.String r11 = "HEAD"
            if (r9 >= r8) goto L_0x0145
            r13 = r7[r9]
            boolean r14 = r13 instanceof ic.b
            if (r14 == 0) goto L_0x0029
            ic.b r13 = (ic.b) r13
            java.lang.String r10 = r13.value()
            java.lang.String r11 = "DELETE"
            r6.b(r11, r10, r4)
            goto L_0x0141
        L_0x0029:
            boolean r14 = r13 instanceof ic.f
            if (r14 == 0) goto L_0x003a
            ic.f r13 = (ic.f) r13
            java.lang.String r10 = r13.value()
            java.lang.String r11 = "GET"
            r6.b(r11, r10, r4)
            goto L_0x0141
        L_0x003a:
            boolean r14 = r13 instanceof ic.g
            if (r14 == 0) goto L_0x0049
            ic.g r13 = (ic.g) r13
            java.lang.String r10 = r13.value()
            r6.b(r11, r10, r4)
            goto L_0x0141
        L_0x0049:
            boolean r11 = r13 instanceof ic.n
            if (r11 == 0) goto L_0x005a
            ic.n r13 = (ic.n) r13
            java.lang.String r10 = r13.value()
            java.lang.String r11 = "PATCH"
            r6.b(r11, r10, r5)
            goto L_0x0141
        L_0x005a:
            boolean r11 = r13 instanceof ic.o
            if (r11 == 0) goto L_0x006b
            ic.o r13 = (ic.o) r13
            java.lang.String r10 = r13.value()
            java.lang.String r11 = "POST"
            r6.b(r11, r10, r5)
            goto L_0x0141
        L_0x006b:
            boolean r11 = r13 instanceof ic.p
            if (r11 == 0) goto L_0x007c
            ic.p r13 = (ic.p) r13
            java.lang.String r10 = r13.value()
            java.lang.String r11 = "PUT"
            r6.b(r11, r10, r5)
            goto L_0x0141
        L_0x007c:
            boolean r11 = r13 instanceof ic.m
            if (r11 == 0) goto L_0x008d
            ic.m r13 = (ic.m) r13
            java.lang.String r10 = r13.value()
            java.lang.String r11 = "OPTIONS"
            r6.b(r11, r10, r4)
            goto L_0x0141
        L_0x008d:
            boolean r11 = r13 instanceof ic.h
            if (r11 == 0) goto L_0x00a4
            ic.h r13 = (ic.h) r13
            java.lang.String r10 = r13.method()
            java.lang.String r11 = r13.path()
            boolean r12 = r13.hasBody()
            r6.b(r10, r11, r12)
            goto L_0x0141
        L_0x00a4:
            boolean r11 = r13 instanceof ic.k
            if (r11 == 0) goto L_0x0119
            ic.k r13 = (ic.k) r13
            java.lang.String[] r11 = r13.value()
            int r13 = r11.length
            if (r13 == 0) goto L_0x010f
            okhttp3.Headers$Builder r13 = new okhttp3.Headers$Builder
            r13.<init>()
            int r14 = r11.length
            r15 = 0
        L_0x00b8:
            if (r15 >= r14) goto L_0x0108
            r2 = r11[r15]
            r12 = 58
            int r12 = r2.indexOf(r12)
            if (r12 == r3) goto L_0x00fc
            if (r12 == 0) goto L_0x00fc
            int r16 = r2.length()
            int r3 = r16 + -1
            if (r12 == r3) goto L_0x00fc
            java.lang.String r3 = r2.substring(r4, r12)
            int r12 = r12 + r5
            java.lang.String r2 = r2.substring(r12)
            java.lang.String r2 = r2.trim()
            java.lang.String r12 = "Content-Type"
            boolean r12 = r12.equalsIgnoreCase(r3)
            if (r12 == 0) goto L_0x00f6
            okhttp3.MediaType r3 = okhttp3.MediaType.get(r2)     // Catch:{ IllegalArgumentException -> 0x00ea }
            r6.t = r3     // Catch:{ IllegalArgumentException -> 0x00ea }
            goto L_0x00f9
        L_0x00ea:
            r0 = move-exception
            java.lang.String r1 = "Malformed content type: %s"
            java.lang.Object[] r3 = new java.lang.Object[r5]
            r3[r4] = r2
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r0, r1, r3)
            throw r0
        L_0x00f6:
            r13.add((java.lang.String) r3, (java.lang.String) r2)
        L_0x00f9:
            int r15 = r15 + r5
            r3 = -1
            goto L_0x00b8
        L_0x00fc:
            java.lang.Object[] r0 = new java.lang.Object[r5]
            r0[r4] = r2
            java.lang.String r1 = "@Headers value must be in the form \"Name: Value\". Found: \"%s\""
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r1, r0)
            throw r0
        L_0x0108:
            okhttp3.Headers r2 = r13.build()
            r6.s = r2
            goto L_0x0141
        L_0x010f:
            r2 = 0
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.String r1 = "@Headers annotation is empty."
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r1, r0)
            throw r0
        L_0x0119:
            boolean r2 = r13 instanceof ic.l
            java.lang.String r3 = "Only one encoding annotation is allowed."
            if (r2 == 0) goto L_0x012e
            boolean r2 = r6.p
            if (r2 != 0) goto L_0x0126
            r6.q = r5
            goto L_0x0141
        L_0x0126:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r3, r0)
            throw r0
        L_0x012e:
            r2 = 0
            boolean r11 = r13 instanceof ic.e
            if (r11 == 0) goto L_0x0141
            boolean r11 = r6.q
            if (r11 != 0) goto L_0x013a
            r6.p = r5
            goto L_0x0141
        L_0x013a:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r3, r0)
            throw r0
        L_0x0141:
            int r9 = r9 + r5
            r3 = -1
            goto L_0x0010
        L_0x0145:
            java.lang.String r2 = r6.n
            if (r2 == 0) goto L_0x0ace
            boolean r2 = r6.o
            if (r2 != 0) goto L_0x016a
            boolean r2 = r6.q
            if (r2 != 0) goto L_0x0160
            boolean r2 = r6.p
            if (r2 != 0) goto L_0x0156
            goto L_0x016a
        L_0x0156:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.String r1 = "FormUrlEncoded can only be specified on HTTP methods with request body (e.g., @POST)."
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r1, r0)
            throw r0
        L_0x0160:
            r2 = 0
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.String r1 = "Multipart can only be specified on HTTP methods with request body (e.g., @POST)."
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r1, r0)
            throw r0
        L_0x016a:
            java.lang.annotation.Annotation[][] r2 = r6.d
            int r3 = r2.length
            fc.w[] r8 = new fc.w[r3]
            r6.v = r8
            int r8 = r3 + -1
            r9 = 0
        L_0x0174:
            if (r9 >= r3) goto L_0x0937
            fc.w<?>[] r12 = r6.v
            java.lang.reflect.Type[] r13 = r6.e
            r13 = r13[r9]
            r14 = r2[r9]
            if (r9 != r8) goto L_0x0182
            r15 = 1
            goto L_0x0183
        L_0x0182:
            r15 = 0
        L_0x0183:
            if (r14 == 0) goto L_0x08f8
            int r4 = r14.length
            r5 = 0
            r17 = 0
        L_0x0189:
            r18 = r2
            if (r5 >= r4) goto L_0x08ec
            r2 = r14[r5]
            r19 = r3
            boolean r3 = r2 instanceof ic.y
            r20 = r4
            java.lang.String r4 = "@Path parameters may not be used with @Url."
            r21 = r8
            java.lang.Class<java.lang.String> r8 = java.lang.String.class
            if (r3 == 0) goto L_0x0234
            r6.c(r9, r13)
            boolean r2 = r6.m
            if (r2 != 0) goto L_0x022a
            boolean r2 = r6.i
            if (r2 != 0) goto L_0x0222
            boolean r2 = r6.j
            if (r2 != 0) goto L_0x0218
            boolean r2 = r6.k
            if (r2 != 0) goto L_0x020e
            boolean r2 = r6.l
            if (r2 != 0) goto L_0x0204
            java.lang.String r2 = r6.r
            if (r2 != 0) goto L_0x01f5
            r2 = 1
            r6.m = r2
            java.lang.Class<okhttp3.HttpUrl> r2 = okhttp3.HttpUrl.class
            if (r13 == r2) goto L_0x01d8
            if (r13 == r8) goto L_0x01d8
            java.lang.Class<java.net.URI> r2 = java.net.URI.class
            if (r13 == r2) goto L_0x01d8
            boolean r2 = r13 instanceof java.lang.Class
            if (r2 == 0) goto L_0x01da
            r2 = r13
            java.lang.Class r2 = (java.lang.Class) r2
            java.lang.String r2 = r2.getName()
            java.lang.String r3 = "android.net.Uri"
            boolean r2 = r3.equals(r2)
            if (r2 == 0) goto L_0x01da
        L_0x01d8:
            r2 = 0
            goto L_0x01e4
        L_0x01da:
            java.lang.String r0 = "@Url must be okhttp3.HttpUrl, String, java.net.URI, or android.net.Uri type."
            r2 = 0
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x01e4:
            fc.w$n r3 = new fc.w$n
            r3.<init>(r10, r9)
            r0 = r3
        L_0x01ea:
            r25 = r5
            r22 = r11
            r23 = r12
        L_0x01f0:
            r24 = r15
        L_0x01f2:
            r1 = -1
            goto L_0x08c3
        L_0x01f5:
            r2 = 0
            java.lang.String r0 = r6.n
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r1[r2] = r0
            java.lang.String r0 = "@Url cannot be used with @%s URL"
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0204:
            r2 = 0
            java.lang.String r0 = "A @Url parameter must not come after a @QueryMap."
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x020e:
            r2 = 0
            java.lang.String r0 = "A @Url parameter must not come after a @QueryName."
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0218:
            r2 = 0
            java.lang.String r0 = "A @Url parameter must not come after a @Query."
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0222:
            r2 = 0
            java.lang.Object[] r0 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r4, r0)
            throw r0
        L_0x022a:
            r2 = 0
            java.lang.String r0 = "Multiple @Url method annotations found."
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0234:
            boolean r3 = r2 instanceof ic.s
            fc.B r1 = r6.a
            if (r3 == 0) goto L_0x02da
            r6.c(r9, r13)
            boolean r3 = r6.j
            if (r3 != 0) goto L_0x02d0
            boolean r3 = r6.k
            if (r3 != 0) goto L_0x02c6
            boolean r3 = r6.l
            if (r3 != 0) goto L_0x02bc
            boolean r3 = r6.m
            if (r3 != 0) goto L_0x02b4
            java.lang.String r3 = r6.r
            if (r3 == 0) goto L_0x02a5
            r3 = 1
            r6.i = r3
            ic.s r2 = (ic.s) r2
            java.lang.String r3 = r2.value()
            java.util.regex.Pattern r4 = fc.z.a.y
            java.util.regex.Matcher r4 = r4.matcher(r3)
            boolean r4 = r4.matches()
            if (r4 == 0) goto L_0x028f
            java.util.LinkedHashSet r4 = r6.u
            boolean r4 = r4.contains(r3)
            if (r4 == 0) goto L_0x027d
            r1.e(r13, r14)
            fc.w$i r1 = new fc.w$i
            boolean r2 = r2.encoded()
            r1.<init>(r10, r9, r3, r2)
            r0 = r1
            goto L_0x01ea
        L_0x027d:
            java.lang.String r0 = r6.r
            r4 = 2
            java.lang.Object[] r1 = new java.lang.Object[r4]
            r2 = 0
            r1[r2] = r0
            r5 = 1
            r1[r5] = r3
            java.lang.String r0 = "URL \"%s\" does not contain \"{%s}\"."
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x028f:
            r2 = 0
            r4 = 2
            r5 = 1
            java.util.regex.Pattern r0 = fc.z.a.x
            java.lang.String r0 = r0.pattern()
            java.lang.Object[] r1 = new java.lang.Object[r4]
            r1[r2] = r0
            r1[r5] = r3
            java.lang.String r0 = "@Path parameter name must match %s. Found: %s"
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x02a5:
            r2 = 0
            r5 = 1
            java.lang.String r0 = r6.n
            java.lang.Object[] r1 = new java.lang.Object[r5]
            r1[r2] = r0
            java.lang.String r0 = "@Path can only be used with relative url on @%s"
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x02b4:
            r2 = 0
            java.lang.Object[] r0 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r4, r0)
            throw r0
        L_0x02bc:
            r2 = 0
            java.lang.String r0 = "A @Path parameter must not come after a @QueryMap."
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x02c6:
            r2 = 0
            java.lang.String r0 = "A @Path parameter must not come after a @QueryName."
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x02d0:
            r2 = 0
            java.lang.String r0 = "A @Path parameter must not come after a @Query."
            java.lang.Object[] r1 = new java.lang.Object[r2]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x02da:
            r4 = 2
            boolean r3 = r2 instanceof ic.t
            java.lang.String r4 = "<String>)"
            r22 = r11
            java.lang.String r11 = " must include generic type (e.g., "
            java.lang.Class<java.lang.Iterable> r0 = java.lang.Iterable.class
            if (r3 == 0) goto L_0x036b
            r6.c(r9, r13)
            ic.t r2 = (ic.t) r2
            java.lang.String r3 = r2.value()
            boolean r2 = r2.encoded()
            java.lang.Class r8 = fc.F.e(r13)
            r23 = r12
            r12 = 1
            r6.j = r12
            boolean r0 = r0.isAssignableFrom(r8)
            if (r0 == 0) goto L_0x0346
            boolean r0 = r13 instanceof java.lang.reflect.ParameterizedType
            if (r0 == 0) goto L_0x0321
            r0 = r13
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r4 = 0
            java.lang.reflect.Type r0 = fc.F.d(r4, r0)
            r1.e(r0, r14)
            fc.w$j r0 = new fc.w$j
            r0.<init>(r3, r2)
            fc.u r1 = new fc.u
            r1.<init>(r0)
        L_0x031c:
            r0 = r1
        L_0x031d:
            r25 = r5
            goto L_0x01f0
        L_0x0321:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r11)
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0346:
            boolean r0 = r8.isArray()
            if (r0 == 0) goto L_0x0362
            java.lang.Class r0 = r8.getComponentType()
            java.lang.Class r0 = fc.z.a.a(r0)
            r1.e(r0, r14)
            fc.w$j r0 = new fc.w$j
            r0.<init>(r3, r2)
            fc.v r1 = new fc.v
            r1.<init>(r0)
            goto L_0x031c
        L_0x0362:
            r1.e(r13, r14)
            fc.w$j r0 = new fc.w$j
            r0.<init>(r3, r2)
            goto L_0x031d
        L_0x036b:
            r23 = r12
            boolean r3 = r2 instanceof ic.v
            if (r3 == 0) goto L_0x03ee
            r6.c(r9, r13)
            ic.v r2 = (ic.v) r2
            boolean r2 = r2.encoded()
            java.lang.Class r3 = fc.F.e(r13)
            r8 = 1
            r6.k = r8
            boolean r0 = r0.isAssignableFrom(r3)
            if (r0 == 0) goto L_0x03c7
            boolean r0 = r13 instanceof java.lang.reflect.ParameterizedType
            if (r0 == 0) goto L_0x03a2
            r0 = r13
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r3 = 0
            java.lang.reflect.Type r0 = fc.F.d(r3, r0)
            r1.e(r0, r14)
            fc.w$l r0 = new fc.w$l
            r0.<init>(r2)
            fc.u r1 = new fc.u
            r1.<init>(r0)
            goto L_0x031c
        L_0x03a2:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r3.getSimpleName()
            r0.append(r1)
            r0.append(r11)
            java.lang.String r1 = r3.getSimpleName()
            r0.append(r1)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x03c7:
            boolean r0 = r3.isArray()
            if (r0 == 0) goto L_0x03e4
            java.lang.Class r0 = r3.getComponentType()
            java.lang.Class r0 = fc.z.a.a(r0)
            r1.e(r0, r14)
            fc.w$l r0 = new fc.w$l
            r0.<init>(r2)
            fc.v r1 = new fc.v
            r1.<init>(r0)
            goto L_0x031c
        L_0x03e4:
            r1.e(r13, r14)
            fc.w$l r0 = new fc.w$l
            r0.<init>(r2)
            goto L_0x031d
        L_0x03ee:
            boolean r3 = r2 instanceof ic.u
            java.lang.String r12 = "Map must include generic types (e.g., Map<String, String>)"
            r24 = r15
            java.lang.Class<java.util.Map> r15 = java.util.Map.class
            if (r3 == 0) goto L_0x0457
            r6.c(r9, r13)
            java.lang.Class r0 = fc.F.e(r13)
            r3 = 1
            r6.l = r3
            boolean r4 = r15.isAssignableFrom(r0)
            if (r4 == 0) goto L_0x044d
            java.lang.reflect.Type r0 = fc.F.f(r13, r0)
            boolean r4 = r0 instanceof java.lang.reflect.ParameterizedType
            if (r4 == 0) goto L_0x0445
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r4 = 0
            java.lang.reflect.Type r11 = fc.F.d(r4, r0)
            if (r8 != r11) goto L_0x042f
            java.lang.reflect.Type r0 = fc.F.d(r3, r0)
            r1.e(r0, r14)
            fc.w$k r0 = new fc.w$k
            ic.u r2 = (ic.u) r2
            boolean r1 = r2.encoded()
            r0.<init>(r10, r9, r1)
        L_0x042b:
            r25 = r5
            goto L_0x01f2
        L_0x042f:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "@QueryMap keys must be of type String: "
            r0.<init>(r1)
            r0.append(r11)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0445:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r12, r0)
            throw r0
        L_0x044d:
            r1 = 0
            java.lang.String r0 = "@QueryMap parameter type must be Map."
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0457:
            boolean r3 = r2 instanceof ic.i
            if (r3 == 0) goto L_0x04d4
            r6.c(r9, r13)
            ic.i r2 = (ic.i) r2
            java.lang.String r2 = r2.value()
            java.lang.Class r3 = fc.F.e(r13)
            boolean r0 = r0.isAssignableFrom(r3)
            if (r0 == 0) goto L_0x04ae
            boolean r0 = r13 instanceof java.lang.reflect.ParameterizedType
            if (r0 == 0) goto L_0x0489
            r0 = r13
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r3 = 0
            java.lang.reflect.Type r0 = fc.F.d(r3, r0)
            r1.e(r0, r14)
            fc.w$d r0 = new fc.w$d
            r0.<init>(r2)
            fc.u r1 = new fc.u
            r1.<init>(r0)
        L_0x0487:
            r0 = r1
            goto L_0x042b
        L_0x0489:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r3.getSimpleName()
            r0.append(r1)
            r0.append(r11)
            java.lang.String r1 = r3.getSimpleName()
            r0.append(r1)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x04ae:
            boolean r0 = r3.isArray()
            if (r0 == 0) goto L_0x04ca
            java.lang.Class r0 = r3.getComponentType()
            java.lang.Class r0 = fc.z.a.a(r0)
            r1.e(r0, r14)
            fc.w$d r0 = new fc.w$d
            r0.<init>(r2)
            fc.v r1 = new fc.v
            r1.<init>(r0)
            goto L_0x0487
        L_0x04ca:
            r1.e(r13, r14)
            fc.w$d r0 = new fc.w$d
            r0.<init>(r2)
            goto L_0x042b
        L_0x04d4:
            boolean r3 = r2 instanceof ic.j
            if (r3 == 0) goto L_0x0538
            java.lang.Class<okhttp3.Headers> r0 = okhttp3.Headers.class
            if (r13 != r0) goto L_0x04e3
            fc.w$f r0 = new fc.w$f
            r0.<init>(r10, r9)
            goto L_0x042b
        L_0x04e3:
            r6.c(r9, r13)
            java.lang.Class r0 = fc.F.e(r13)
            boolean r2 = r15.isAssignableFrom(r0)
            if (r2 == 0) goto L_0x052e
            java.lang.reflect.Type r0 = fc.F.f(r13, r0)
            boolean r2 = r0 instanceof java.lang.reflect.ParameterizedType
            if (r2 == 0) goto L_0x0526
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r2 = 0
            java.lang.reflect.Type r3 = fc.F.d(r2, r0)
            if (r8 != r3) goto L_0x0510
            r2 = 1
            java.lang.reflect.Type r0 = fc.F.d(r2, r0)
            r1.e(r0, r14)
            fc.w$e r0 = new fc.w$e
            r0.<init>(r10, r9)
            goto L_0x042b
        L_0x0510:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "@HeaderMap keys must be of type String: "
            r0.<init>(r1)
            r0.append(r3)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0526:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r12, r0)
            throw r0
        L_0x052e:
            r1 = 0
            java.lang.String r0 = "@HeaderMap parameter type must be Map."
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0538:
            boolean r3 = r2 instanceof ic.c
            if (r3 == 0) goto L_0x05cb
            r6.c(r9, r13)
            boolean r3 = r6.p
            if (r3 == 0) goto L_0x05c1
            ic.c r2 = (ic.c) r2
            java.lang.String r3 = r2.value()
            boolean r2 = r2.encoded()
            r8 = 1
            r6.f = r8
            java.lang.Class r8 = fc.F.e(r13)
            boolean r0 = r0.isAssignableFrom(r8)
            if (r0 == 0) goto L_0x059a
            boolean r0 = r13 instanceof java.lang.reflect.ParameterizedType
            if (r0 == 0) goto L_0x0575
            r0 = r13
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r4 = 0
            java.lang.reflect.Type r0 = fc.F.d(r4, r0)
            r1.e(r0, r14)
            fc.w$b r0 = new fc.w$b
            r0.<init>(r3, r2)
            fc.u r1 = new fc.u
            r1.<init>(r0)
            goto L_0x0487
        L_0x0575:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r11)
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x059a:
            boolean r0 = r8.isArray()
            if (r0 == 0) goto L_0x05b7
            java.lang.Class r0 = r8.getComponentType()
            java.lang.Class r0 = fc.z.a.a(r0)
            r1.e(r0, r14)
            fc.w$b r0 = new fc.w$b
            r0.<init>(r3, r2)
            fc.v r1 = new fc.v
            r1.<init>(r0)
            goto L_0x0487
        L_0x05b7:
            r1.e(r13, r14)
            fc.w$b r0 = new fc.w$b
            r0.<init>(r3, r2)
            goto L_0x042b
        L_0x05c1:
            java.lang.String r0 = "@Field parameters can only be used with form encoding."
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x05cb:
            boolean r3 = r2 instanceof ic.d
            if (r3 == 0) goto L_0x063a
            r6.c(r9, r13)
            boolean r0 = r6.p
            if (r0 == 0) goto L_0x0630
            java.lang.Class r0 = fc.F.e(r13)
            boolean r3 = r15.isAssignableFrom(r0)
            if (r3 == 0) goto L_0x0626
            java.lang.reflect.Type r0 = fc.F.f(r13, r0)
            boolean r3 = r0 instanceof java.lang.reflect.ParameterizedType
            if (r3 == 0) goto L_0x061e
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r3 = 0
            java.lang.reflect.Type r4 = fc.F.d(r3, r0)
            if (r8 != r4) goto L_0x0608
            r3 = 1
            java.lang.reflect.Type r0 = fc.F.d(r3, r0)
            r1.e(r0, r14)
            r6.f = r3
            fc.w$c r0 = new fc.w$c
            ic.d r2 = (ic.d) r2
            boolean r1 = r2.encoded()
            r0.<init>(r10, r9, r1)
            goto L_0x042b
        L_0x0608:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "@FieldMap keys must be of type String: "
            r0.<init>(r1)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x061e:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r12, r0)
            throw r0
        L_0x0626:
            r1 = 0
            java.lang.String r0 = "@FieldMap parameter type must be Map."
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0630:
            r1 = 0
            java.lang.String r0 = "@FieldMap parameters can only be used with form encoding."
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x063a:
            boolean r3 = r2 instanceof ic.q
            r25 = r5
            java.lang.Class<okhttp3.MultipartBody$Part> r5 = okhttp3.MultipartBody.Part.class
            if (r3 == 0) goto L_0x07a1
            r6.c(r9, r13)
            boolean r3 = r6.q
            if (r3 == 0) goto L_0x0797
            ic.q r2 = (ic.q) r2
            r3 = 1
            r6.g = r3
            java.lang.String r3 = r2.value()
            java.lang.Class r8 = fc.F.e(r13)
            boolean r12 = r3.isEmpty()
            if (r12 == 0) goto L_0x06df
            boolean r0 = r0.isAssignableFrom(r8)
            fc.w$m r1 = fc.w.m.a
            java.lang.String r2 = "@Part annotation must supply a name or use MultipartBody.Part parameter type."
            if (r0 == 0) goto L_0x06af
            boolean r0 = r13 instanceof java.lang.reflect.ParameterizedType
            if (r0 == 0) goto L_0x068a
            r0 = r13
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r3 = 0
            java.lang.reflect.Type r0 = fc.F.d(r3, r0)
            java.lang.Class r0 = fc.F.e(r0)
            boolean r0 = r5.isAssignableFrom(r0)
            if (r0 == 0) goto L_0x0683
            fc.u r0 = new fc.u
            r0.<init>(r1)
            goto L_0x01f2
        L_0x0683:
            java.lang.Object[] r0 = new java.lang.Object[r3]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r2, r0)
            throw r0
        L_0x068a:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r11)
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x06af:
            boolean r0 = r8.isArray()
            if (r0 == 0) goto L_0x06ce
            java.lang.Class r0 = r8.getComponentType()
            boolean r0 = r5.isAssignableFrom(r0)
            if (r0 == 0) goto L_0x06c6
            fc.v r0 = new fc.v
            r0.<init>(r1)
            goto L_0x01f2
        L_0x06c6:
            r3 = 0
            java.lang.Object[] r0 = new java.lang.Object[r3]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r2, r0)
            throw r0
        L_0x06ce:
            r3 = 0
            boolean r0 = r5.isAssignableFrom(r8)
            if (r0 == 0) goto L_0x06d8
        L_0x06d5:
            r0 = r1
            goto L_0x01f2
        L_0x06d8:
            java.lang.Object[] r0 = new java.lang.Object[r3]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r2, r0)
            throw r0
        L_0x06df:
            java.lang.String r12 = "form-data; name=\""
            java.lang.String r15 = "\""
            java.lang.String r3 = androidx.camera.camera2.internal.P.a(r12, r3, r15)
            java.lang.String r2 = r2.encoding()
            java.lang.String r12 = "Content-Disposition"
            java.lang.String r15 = "Content-Transfer-Encoding"
            java.lang.String[] r2 = new java.lang.String[]{r12, r3, r15, r2}
            okhttp3.Headers r2 = okhttp3.Headers.of((java.lang.String[]) r2)
            boolean r0 = r0.isAssignableFrom(r8)
            java.lang.String r3 = "@Part parameters using the MultipartBody.Part must not include a part name in the annotation."
            if (r0 == 0) goto L_0x0752
            boolean r0 = r13 instanceof java.lang.reflect.ParameterizedType
            if (r0 == 0) goto L_0x072d
            r0 = r13
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r4 = 0
            java.lang.reflect.Type r0 = fc.F.d(r4, r0)
            java.lang.Class r4 = fc.F.e(r0)
            boolean r4 = r5.isAssignableFrom(r4)
            if (r4 != 0) goto L_0x0725
            fc.i r0 = r1.c(r0, r14, r7)
            fc.w$g r1 = new fc.w$g
            r1.<init>(r10, r9, r2, r0)
            fc.u r0 = new fc.u
            r0.<init>(r1)
            goto L_0x01f2
        L_0x0725:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r3, r0)
            throw r0
        L_0x072d:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r11)
            java.lang.String r1 = r8.getSimpleName()
            r0.append(r1)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0752:
            boolean r0 = r8.isArray()
            if (r0 == 0) goto L_0x077e
            java.lang.Class r0 = r8.getComponentType()
            java.lang.Class r0 = fc.z.a.a(r0)
            boolean r4 = r5.isAssignableFrom(r0)
            if (r4 != 0) goto L_0x0776
            fc.i r0 = r1.c(r0, r14, r7)
            fc.w$g r1 = new fc.w$g
            r1.<init>(r10, r9, r2, r0)
            fc.v r0 = new fc.v
            r0.<init>(r1)
            goto L_0x01f2
        L_0x0776:
            r4 = 0
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r3, r0)
            throw r0
        L_0x077e:
            r4 = 0
            boolean r0 = r5.isAssignableFrom(r8)
            if (r0 != 0) goto L_0x0790
            fc.i r0 = r1.c(r13, r14, r7)
            fc.w$g r1 = new fc.w$g
            r1.<init>(r10, r9, r2, r0)
            goto L_0x06d5
        L_0x0790:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r3, r0)
            throw r0
        L_0x0797:
            r4 = 0
            java.lang.String r0 = "@Part parameters can only be used with multipart encoding."
            java.lang.Object[] r1 = new java.lang.Object[r4]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x07a1:
            boolean r0 = r2 instanceof ic.r
            if (r0 == 0) goto L_0x0825
            r6.c(r9, r13)
            boolean r0 = r6.q
            if (r0 == 0) goto L_0x081b
            r3 = 1
            r6.g = r3
            java.lang.Class r0 = fc.F.e(r13)
            boolean r4 = r15.isAssignableFrom(r0)
            if (r4 == 0) goto L_0x0811
            java.lang.reflect.Type r0 = fc.F.f(r13, r0)
            boolean r4 = r0 instanceof java.lang.reflect.ParameterizedType
            if (r4 == 0) goto L_0x0809
            java.lang.reflect.ParameterizedType r0 = (java.lang.reflect.ParameterizedType) r0
            r4 = 0
            java.lang.reflect.Type r11 = fc.F.d(r4, r0)
            if (r8 != r11) goto L_0x07f3
            java.lang.reflect.Type r0 = fc.F.d(r3, r0)
            java.lang.Class r3 = fc.F.e(r0)
            boolean r3 = r5.isAssignableFrom(r3)
            if (r3 != 0) goto L_0x07e9
            fc.i r0 = r1.c(r0, r14, r7)
            ic.r r2 = (ic.r) r2
            fc.w$h r1 = new fc.w$h
            java.lang.String r2 = r2.encoding()
            r1.<init>(r10, r9, r0, r2)
            goto L_0x06d5
        L_0x07e9:
            java.lang.String r0 = "@PartMap values cannot be MultipartBody.Part. Use @Part List<Part> or a different value type instead."
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x07f3:
            r1 = 0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r2 = "@PartMap keys must be of type String: "
            r0.<init>(r2)
            r0.append(r11)
            java.lang.String r0 = r0.toString()
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0809:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r12, r0)
            throw r0
        L_0x0811:
            r1 = 0
            java.lang.String r0 = "@PartMap parameter type must be Map."
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x081b:
            r1 = 0
            java.lang.String r0 = "@PartMap parameters can only be used with multipart encoding."
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0825:
            boolean r0 = r2 instanceof ic.a
            if (r0 == 0) goto L_0x086a
            r6.c(r9, r13)
            boolean r0 = r6.p
            if (r0 != 0) goto L_0x0860
            boolean r0 = r6.q
            if (r0 != 0) goto L_0x0860
            boolean r0 = r6.h
            if (r0 != 0) goto L_0x0856
            fc.i r0 = r1.c(r13, r14, r7)     // Catch:{ RuntimeException -> 0x0847 }
            r1 = 1
            r6.h = r1
            fc.w$a r2 = new fc.w$a
            r2.<init>(r10, r9, r0)
            r0 = r2
            goto L_0x01f2
        L_0x0847:
            r0 = move-exception
            r1 = 1
            r2 = r0
            java.lang.String r0 = "Unable to create @Body converter for %s"
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r3 = 0
            r1[r3] = r13
            java.lang.IllegalArgumentException r0 = fc.F.k(r10, r2, r9, r0, r1)
            throw r0
        L_0x0856:
            r3 = 0
            java.lang.String r0 = "Multiple @Body method annotations found."
            java.lang.Object[] r1 = new java.lang.Object[r3]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0860:
            r3 = 0
            java.lang.String r0 = "@Body parameters cannot be used with form or multi-part encoding."
            java.lang.Object[] r1 = new java.lang.Object[r3]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x086a:
            boolean r0 = r2 instanceof ic.x
            if (r0 == 0) goto L_0x08c1
            r6.c(r9, r13)
            java.lang.Class r0 = fc.F.e(r13)
            r1 = 1
            int r2 = r9 + -1
        L_0x0878:
            if (r2 < 0) goto L_0x08b9
            fc.w<?>[] r1 = r6.v
            r1 = r1[r2]
            boolean r3 = r1 instanceof fc.w.o
            if (r3 == 0) goto L_0x088c
            fc.w$o r1 = (fc.w.o) r1
            java.lang.Class<T> r1 = r1.a
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x088e
        L_0x088c:
            r1 = -1
            goto L_0x08b7
        L_0x088e:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r3 = "@Tag type "
            r1.<init>(r3)
            java.lang.String r0 = r0.getName()
            r1.append(r0)
            java.lang.String r0 = " is duplicate of parameter #"
            r1.append(r0)
            r3 = 1
            int r2 = r2 + r3
            r1.append(r2)
            java.lang.String r0 = " and would always overwrite its value."
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x08b7:
            int r2 = r2 + r1
            goto L_0x0878
        L_0x08b9:
            r1 = -1
            fc.w$o r2 = new fc.w$o
            r2.<init>(r0)
            r0 = r2
            goto L_0x08c3
        L_0x08c1:
            r1 = -1
            r0 = 0
        L_0x08c3:
            if (r0 != 0) goto L_0x08c7
        L_0x08c5:
            r2 = 1
            goto L_0x08cc
        L_0x08c7:
            if (r17 != 0) goto L_0x08e2
            r17 = r0
            goto L_0x08c5
        L_0x08cc:
            int r5 = r25 + 1
            r0 = r26
            r1 = r27
            r2 = r18
            r3 = r19
            r4 = r20
            r8 = r21
            r11 = r22
            r12 = r23
            r15 = r24
            goto L_0x0189
        L_0x08e2:
            java.lang.String r0 = "Multiple Retrofit annotations found, only one allowed."
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x08ec:
            r19 = r3
            r21 = r8
            r22 = r11
            r23 = r12
            r24 = r15
            r1 = -1
            goto L_0x0907
        L_0x08f8:
            r18 = r2
            r19 = r3
            r21 = r8
            r22 = r11
            r23 = r12
            r24 = r15
            r1 = -1
            r17 = 0
        L_0x0907:
            if (r17 != 0) goto L_0x0923
            if (r24 == 0) goto L_0x0919
            java.lang.Class r0 = fc.F.e(r13)     // Catch:{ NoClassDefFoundError -> 0x0919 }
            java.lang.Class<L9.a> r2 = L9.a.class
            if (r0 != r2) goto L_0x0919
            r2 = 1
            r6.w = r2     // Catch:{ NoClassDefFoundError -> 0x0919 }
            r17 = 0
            goto L_0x0923
        L_0x0919:
            java.lang.String r0 = "No Retrofit annotation found."
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.IllegalArgumentException r0 = fc.F.j(r10, r9, r0, r1)
            throw r0
        L_0x0923:
            r23[r9] = r17
            r2 = 1
            int r9 = r9 + r2
            r0 = r26
            r1 = r27
            r2 = r18
            r3 = r19
            r8 = r21
            r11 = r22
            r4 = 0
            r5 = 1
            goto L_0x0174
        L_0x0937:
            r22 = r11
            r2 = 1
            java.lang.String r0 = r6.r
            if (r0 != 0) goto L_0x0952
            boolean r0 = r6.m
            if (r0 == 0) goto L_0x0943
            goto L_0x0952
        L_0x0943:
            java.lang.String r0 = r6.n
            java.lang.Object[] r1 = new java.lang.Object[r2]
            r2 = 0
            r1[r2] = r0
            java.lang.String r0 = "Missing either @%s URL or @Url parameter."
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r0, r1)
            throw r0
        L_0x0952:
            boolean r0 = r6.p
            if (r0 != 0) goto L_0x096e
            boolean r1 = r6.q
            if (r1 != 0) goto L_0x096e
            boolean r1 = r6.o
            if (r1 != 0) goto L_0x096e
            boolean r1 = r6.h
            if (r1 != 0) goto L_0x0963
            goto L_0x096e
        L_0x0963:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.String r1 = "Non-body HTTP method cannot contain @Body."
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r1, r0)
            throw r0
        L_0x096e:
            if (r0 == 0) goto L_0x0980
            boolean r0 = r6.f
            if (r0 == 0) goto L_0x0975
            goto L_0x0980
        L_0x0975:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.String r1 = "Form-encoded method must contain at least one @Field."
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r1, r0)
            throw r0
        L_0x0980:
            boolean r0 = r6.q
            if (r0 == 0) goto L_0x0994
            boolean r0 = r6.g
            if (r0 == 0) goto L_0x0989
            goto L_0x0994
        L_0x0989:
            r1 = 0
            java.lang.Object[] r0 = new java.lang.Object[r1]
            java.lang.String r1 = "Multipart method must contain at least one @Part."
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r2, r1, r0)
            throw r0
        L_0x0994:
            fc.z r0 = new fc.z
            r0.<init>(r6)
            java.lang.reflect.Type r1 = r27.getGenericReturnType()
            boolean r2 = fc.F.g(r1)
            if (r2 != 0) goto L_0x0abe
            java.lang.Class r2 = java.lang.Void.TYPE
            if (r1 == r2) goto L_0x0ab1
            java.lang.annotation.Annotation[] r1 = r27.getAnnotations()
            boolean r2 = r0.k
            java.lang.Class<fc.A> r3 = fc.A.class
            if (r2 == 0) goto L_0x0a08
            java.lang.reflect.Type[] r4 = r27.getGenericParameterTypes()
            int r5 = r4.length
            r6 = 1
            int r5 = r5 - r6
            r4 = r4[r5]
            java.lang.reflect.ParameterizedType r4 = (java.lang.reflect.ParameterizedType) r4
            java.lang.reflect.Type[] r4 = r4.getActualTypeArguments()
            r5 = 0
            r4 = r4[r5]
            boolean r6 = r4 instanceof java.lang.reflect.WildcardType
            if (r6 == 0) goto L_0x09cf
            java.lang.reflect.WildcardType r4 = (java.lang.reflect.WildcardType) r4
            java.lang.reflect.Type[] r4 = r4.getLowerBounds()
            r4 = r4[r5]
        L_0x09cf:
            java.lang.Class r6 = fc.F.e(r4)
            if (r6 != r3) goto L_0x09e1
            boolean r6 = r4 instanceof java.lang.reflect.ParameterizedType
            if (r6 == 0) goto L_0x09e1
            java.lang.reflect.ParameterizedType r4 = (java.lang.reflect.ParameterizedType) r4
            java.lang.reflect.Type r4 = fc.F.d(r5, r4)
            r6 = 1
            goto L_0x09e2
        L_0x09e1:
            r6 = 0
        L_0x09e2:
            fc.F$b r7 = new fc.F$b
            java.lang.Class<fc.b> r8 = fc.C0267b.class
            r9 = 1
            java.lang.reflect.Type[] r10 = new java.lang.reflect.Type[r9]
            r10[r5] = r4
            r4 = 0
            r7.<init>(r4, r8, r10)
            java.lang.Class<fc.D> r4 = fc.D.class
            boolean r4 = fc.F.h(r1, r4)
            if (r4 == 0) goto L_0x09f8
            goto L_0x0a05
        L_0x09f8:
            int r4 = r1.length
            int r4 = r4 + r9
            java.lang.annotation.Annotation[] r4 = new java.lang.annotation.Annotation[r4]
            fc.E r8 = fc.E.a
            r4[r5] = r8
            int r8 = r1.length
            java.lang.System.arraycopy(r1, r5, r4, r9, r8)
            r1 = r4
        L_0x0a05:
            r4 = r26
            goto L_0x0a0e
        L_0x0a08:
            java.lang.reflect.Type r7 = r27.getGenericReturnType()
            r6 = 0
            goto L_0x0a05
        L_0x0a0e:
            fc.c r1 = r4.a(r7, r1)     // Catch:{ RuntimeException -> 0x0aa0 }
            java.lang.reflect.Type r5 = r1.a()
            java.lang.Class<okhttp3.Response> r7 = okhttp3.Response.class
            if (r5 == r7) goto L_0x0a7a
            if (r5 == r3) goto L_0x0a6d
            java.lang.String r3 = r0.c
            r7 = r22
            boolean r3 = r3.equals(r7)
            if (r3 == 0) goto L_0x0a2e
            java.lang.Class<java.lang.Void> r3 = java.lang.Void.class
            boolean r3 = r3.equals(r5)
            if (r3 == 0) goto L_0x0a31
        L_0x0a2e:
            r3 = r27
            goto L_0x0a3e
        L_0x0a31:
            r3 = 0
            java.lang.Object[] r0 = new java.lang.Object[r3]
            java.lang.String r1 = "HEAD method must use Void as response type."
            r3 = r27
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r3, r2, r1, r0)
            throw r0
        L_0x0a3e:
            java.lang.annotation.Annotation[] r7 = r27.getAnnotations()
            fc.i r3 = r4.d(r5, r7)     // Catch:{ RuntimeException -> 0x0a5e }
            okhttp3.Call$Factory r4 = r4.b
            if (r2 != 0) goto L_0x0a50
            fc.m$a r2 = new fc.m$a
            r2.<init>(r0, r4, r3, r1)
            goto L_0x0a5d
        L_0x0a50:
            if (r6 == 0) goto L_0x0a58
            fc.m$c r2 = new fc.m$c
            r2.<init>(r0, r4, r3, r1)
            goto L_0x0a5d
        L_0x0a58:
            fc.m$b r2 = new fc.m$b
            r2.<init>(r0, r4, r3, r1)
        L_0x0a5d:
            return r2
        L_0x0a5e:
            r0 = move-exception
            r1 = r0
            java.lang.String r0 = "Unable to create converter for %s"
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r4 = 0
            r2[r4] = r5
            java.lang.IllegalArgumentException r0 = fc.F.i(r3, r1, r0, r2)
            throw r0
        L_0x0a6d:
            r3 = r27
            r4 = 0
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.String r1 = "Response must include generic type (e.g., Response<String>)"
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r3, r2, r1, r0)
            throw r0
        L_0x0a7a:
            r3 = r27
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "'"
            r0.<init>(r1)
            java.lang.Class r1 = fc.F.e(r5)
            java.lang.String r1 = r1.getName()
            r0.append(r1)
            java.lang.String r1 = "' is not a valid response body type. Did you mean ResponseBody?"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r2 = 0
            java.lang.Object[] r1 = new java.lang.Object[r2]
            r2 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r3, r2, r0, r1)
            throw r0
        L_0x0aa0:
            r0 = move-exception
            r3 = r27
            r2 = 0
            r1 = r0
            java.lang.String r0 = "Unable to create call adapter for %s"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r4[r2] = r7
            java.lang.IllegalArgumentException r0 = fc.F.i(r3, r1, r0, r4)
            throw r0
        L_0x0ab1:
            r3 = r27
            r2 = 0
            java.lang.Object[] r0 = new java.lang.Object[r2]
            java.lang.String r1 = "Service methods cannot return void."
            r5 = 0
            java.lang.IllegalArgumentException r0 = fc.F.i(r3, r5, r1, r0)
            throw r0
        L_0x0abe:
            r3 = r27
            r2 = 0
            r4 = 1
            r5 = 0
            java.lang.Object[] r0 = new java.lang.Object[r4]
            r0[r2] = r1
            java.lang.String r1 = "Method return type must not include a type variable or wildcard: %s"
            java.lang.IllegalArgumentException r0 = fc.F.i(r3, r5, r1, r0)
            throw r0
        L_0x0ace:
            r2 = 0
            r5 = 0
            java.lang.Object[] r0 = new java.lang.Object[r2]
            java.lang.String r1 = "HTTP method annotation is required (e.g., @GET, @POST, etc.)."
            java.lang.IllegalArgumentException r0 = fc.F.i(r10, r5, r1, r0)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: fc.C.b(fc.B, java.lang.reflect.Method):fc.m");
    }

    @Nullable
    public abstract T a(Object[] objArr);
}
