package fc;

import O0.e;
import fc.i;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Optional;
import javax.annotation.Nullable;
import okhttp3.ResponseBody;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;

@IgnoreJRERequirement
public final class t extends i.a {
    public static final t a = new i.a();

    @IgnoreJRERequirement
    public static final class a<T> implements i<ResponseBody, Optional<T>> {
        public final i<ResponseBody, T> a;

        public a(i<ResponseBody, T> iVar) {
            this.a = iVar;
        }

        public final Object a(Object obj) throws IOException {
            return Optional.ofNullable(this.a.a((ResponseBody) obj));
        }
    }

    @Nullable
    public final i<ResponseBody, ?> b(Type type, Annotation[] annotationArr, B b) {
        if (F.e(type) != e.a()) {
            return null;
        }
        return new a(b.d(F.d(0, (ParameterizedType) type), annotationArr));
    }
}
