package fc;

import H9.j;
import T9.l;
import kotlin.jvm.internal.Lambda;

public final class o extends Lambda implements l<Throwable, j> {
    public final /* synthetic */ C0267b a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public o(C0267b bVar) {
        super(1);
        this.a = bVar;
    }

    public final Object invoke(Object obj) {
        Throwable th = (Throwable) obj;
        this.a.cancel();
        return j.a;
    }
}
