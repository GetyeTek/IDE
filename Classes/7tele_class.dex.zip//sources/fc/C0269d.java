package fc;

/* renamed from: fc.d  reason: case insensitive filesystem */
public interface C0269d<T> {
    void a(C0267b<T> bVar, A<T> a);

    void b(C0267b<T> bVar, Throwable th);
}
