package fc;

public final /* synthetic */ class s {
}
