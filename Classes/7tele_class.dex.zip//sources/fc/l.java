package fc;

import com.huawei.kbz.chat.storage.e;
import fc.C0268c;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.concurrent.Executor;
import javax.annotation.Nullable;
import okhttp3.Request;

public final class l extends C0268c.a {
    @Nullable
    public final Executor a;

    public static final class a<T> implements C0267b<T> {
        public final Executor a;
        public final C0267b<T> b;

        /* renamed from: fc.l$a$a  reason: collision with other inner class name */
        public class C0026a implements C0269d<T> {
            public final /* synthetic */ C0269d a;

            public C0026a(C0269d dVar) {
                this.a = dVar;
            }

            public final void a(C0267b<T> bVar, A<T> a2) {
                a.this.a.execute(new k(this, this.a, a2));
            }

            public final void b(C0267b<T> bVar, Throwable th) {
                a.this.a.execute(new e(this, this.a, th, 1));
            }
        }

        public a(Executor executor, C0267b<T> bVar) {
            this.a = executor;
            this.b = bVar;
        }

        public final void a(C0269d<T> dVar) {
            this.b.a(new C0026a(dVar));
        }

        public final void cancel() {
            this.b.cancel();
        }

        public final boolean isCanceled() {
            return this.b.isCanceled();
        }

        public final Request request() {
            return this.b.request();
        }

        public final C0267b<T> clone() {
            return new a(this.a, this.b.clone());
        }
    }

    public l(@Nullable Executor executor) {
        this.a = executor;
    }

    @Nullable
    public final C0268c a(Type type, Annotation[] annotationArr) {
        Executor executor = null;
        if (F.e(type) != C0267b.class) {
            return null;
        }
        if (type instanceof ParameterizedType) {
            Type d = F.d(0, (ParameterizedType) type);
            if (!F.h(annotationArr, D.class)) {
                executor = this.a;
            }
            return new j(d, executor);
        }
        throw new IllegalArgumentException("Call return type must be parameterized as Call<Foo> or Call<? extends Foo>");
    }
}
