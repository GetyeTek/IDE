package fc;

/* renamed from: fc.f  reason: case insensitive filesystem */
public final /* synthetic */ class C0271f {
}
