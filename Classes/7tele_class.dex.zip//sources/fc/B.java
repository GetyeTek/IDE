package fc;

import fc.C0268c;
import fc.i;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import javax.annotation.Nullable;
import okhttp3.Call;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;

public final class B {
    public final ConcurrentHashMap a = new ConcurrentHashMap();
    public final Call.Factory b;
    public final HttpUrl c;
    public final List<i.a> d;
    public final List<C0268c.a> e;
    @Nullable
    public final Executor f;

    public class a implements InvocationHandler {
        public final x a = x.c;
        public final Object[] b = new Object[0];
        public final /* synthetic */ Class c;

        public a(Class cls) {
            this.c = cls;
        }

        @Nullable
        public final Object invoke(Object obj, Method method, @Nullable Object[] objArr) throws Throwable {
            C c2;
            if (method.getDeclaringClass() == Object.class) {
                return method.invoke(this, objArr);
            }
            if (objArr == null) {
                objArr = this.b;
            }
            x xVar = this.a;
            if (xVar.a && O6.a.c(method)) {
                return xVar.b(method, this.c, obj, objArr);
            }
            B b2 = B.this;
            C c3 = (C) b2.a.get(method);
            if (c3 == null) {
                synchronized (b2.a) {
                    try {
                        c2 = (C) b2.a.get(method);
                        if (c2 == null) {
                            c2 = C.b(b2, method);
                            b2.a.put(method, c2);
                        }
                    } catch (Throwable th) {
                        while (true) {
                            throw th;
                        }
                    }
                }
                c3 = c2;
            }
            return c3.a(objArr);
        }
    }

    public static final class b {
        public final x a;
        @Nullable
        public OkHttpClient b;
        @Nullable
        public HttpUrl c;
        public final ArrayList d = new ArrayList();
        public final ArrayList e = new ArrayList();

        public b() {
            x xVar = x.c;
            this.a = xVar;
        }

        public final void a(String str) {
            Objects.requireNonNull(str, "baseUrl == null");
            HttpUrl httpUrl = HttpUrl.get(str);
            Objects.requireNonNull(httpUrl, "baseUrl == null");
            List<String> pathSegments = httpUrl.pathSegments();
            if ("".equals(pathSegments.get(pathSegments.size() - 1))) {
                this.c = httpUrl;
                return;
            }
            throw new IllegalArgumentException("baseUrl must end in /: " + httpUrl);
        }

        /* JADX WARNING: type inference failed for: r6v3, types: [fc.i$a, java.lang.Object, fc.a] */
        public final B b() {
            List list;
            List list2;
            if (this.c != null) {
                OkHttpClient okHttpClient = this.b;
                if (okHttpClient == null) {
                    okHttpClient = new OkHttpClient();
                }
                OkHttpClient okHttpClient2 = okHttpClient;
                x xVar = this.a;
                Executor a2 = xVar.a();
                ArrayList arrayList = new ArrayList(this.e);
                C0268c.a lVar = new l(a2);
                int i = xVar.a;
                if (i != 0) {
                    list = Arrays.asList(new C0268c.a[]{h.a, lVar});
                } else {
                    list = Collections.singletonList(lVar);
                }
                arrayList.addAll(list);
                ArrayList arrayList2 = this.d;
                ArrayList arrayList3 = new ArrayList(arrayList2.size() + 1 + i);
                ? aVar = new i.a();
                aVar.a = true;
                arrayList3.add(aVar);
                arrayList3.addAll(arrayList2);
                if (i != 0) {
                    list2 = Collections.singletonList(t.a);
                } else {
                    list2 = Collections.emptyList();
                }
                arrayList3.addAll(list2);
                return new B(okHttpClient2, this.c, Collections.unmodifiableList(arrayList3), Collections.unmodifiableList(arrayList), a2);
            }
            throw new IllegalStateException("Base URL required.");
        }
    }

    public B(Call.Factory factory, HttpUrl httpUrl, List list, List list2, @Nullable Executor executor) {
        this.b = factory;
        this.c = httpUrl;
        this.d = list;
        this.e = list2;
        this.f = executor;
    }

    public final C0268c<?, ?> a(Type type, Annotation[] annotationArr) {
        Objects.requireNonNull(type, "returnType == null");
        Objects.requireNonNull(annotationArr, "annotations == null");
        List<C0268c.a> list = this.e;
        int indexOf = list.indexOf((Object) null) + 1;
        int size = list.size();
        for (int i = indexOf; i < size; i++) {
            C0268c<?, ?> a2 = list.get(i).a(type, annotationArr);
            if (a2 != null) {
                return a2;
            }
        }
        StringBuilder sb2 = new StringBuilder("Could not locate call adapter for ");
        sb2.append(type);
        sb2.append(".\n  Tried:");
        int size2 = list.size();
        while (indexOf < size2) {
            sb2.append("\n   * ");
            sb2.append(list.get(indexOf).getClass().getName());
            indexOf++;
        }
        throw new IllegalArgumentException(sb2.toString());
    }

    public final <T> T b(Class<T> cls) {
        if (cls.isInterface()) {
            ArrayDeque arrayDeque = new ArrayDeque(1);
            arrayDeque.add(cls);
            while (!arrayDeque.isEmpty()) {
                Class<T> cls2 = (Class) arrayDeque.removeFirst();
                if (cls2.getTypeParameters().length != 0) {
                    StringBuilder sb2 = new StringBuilder("Type parameters are unsupported on ");
                    sb2.append(cls2.getName());
                    if (cls2 != cls) {
                        sb2.append(" which is an interface of ");
                        sb2.append(cls.getName());
                    }
                    throw new IllegalArgumentException(sb2.toString());
                }
                Collections.addAll(arrayDeque, cls2.getInterfaces());
            }
            return Proxy.newProxyInstance(cls.getClassLoader(), new Class[]{cls}, new a(cls));
        }
        throw new IllegalArgumentException("API declarations must be interfaces.");
    }

    public final <T> i<T, RequestBody> c(Type type, Annotation[] annotationArr, Annotation[] annotationArr2) {
        Objects.requireNonNull(type, "type == null");
        Objects.requireNonNull(annotationArr2, "methodAnnotations == null");
        List<i.a> list = this.d;
        int indexOf = list.indexOf((Object) null) + 1;
        int size = list.size();
        for (int i = indexOf; i < size; i++) {
            i<T, RequestBody> a2 = list.get(i).a(type);
            if (a2 != null) {
                return a2;
            }
        }
        StringBuilder sb2 = new StringBuilder("Could not locate RequestBody converter for ");
        sb2.append(type);
        sb2.append(".\n  Tried:");
        int size2 = list.size();
        while (indexOf < size2) {
            sb2.append("\n   * ");
            sb2.append(list.get(indexOf).getClass().getName());
            indexOf++;
        }
        throw new IllegalArgumentException(sb2.toString());
    }

    public final <T> i<ResponseBody, T> d(Type type, Annotation[] annotationArr) {
        Objects.requireNonNull(type, "type == null");
        Objects.requireNonNull(annotationArr, "annotations == null");
        List<i.a> list = this.d;
        int indexOf = list.indexOf((Object) null) + 1;
        int size = list.size();
        for (int i = indexOf; i < size; i++) {
            i<ResponseBody, ?> b2 = list.get(i).b(type, annotationArr, this);
            if (b2 != null) {
                return b2;
            }
        }
        StringBuilder sb2 = new StringBuilder("Could not locate ResponseBody converter for ");
        sb2.append(type);
        sb2.append(".\n  Tried:");
        int size2 = list.size();
        while (indexOf < size2) {
            sb2.append("\n   * ");
            sb2.append(list.get(indexOf).getClass().getName());
            indexOf++;
        }
        throw new IllegalArgumentException(sb2.toString());
    }

    public final void e(Type type, Annotation[] annotationArr) {
        Objects.requireNonNull(type, "type == null");
        List<i.a> list = this.d;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            list.get(i).getClass();
        }
    }
}
