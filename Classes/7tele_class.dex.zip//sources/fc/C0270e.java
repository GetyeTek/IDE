package fc;

import java.util.concurrent.CompletableFuture;

/* renamed from: fc.e  reason: case insensitive filesystem */
public final /* synthetic */ class C0270e {
    public static /* bridge */ /* synthetic */ Class a() {
        return CompletableFuture.class;
    }
}
