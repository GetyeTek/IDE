package fc;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.annotation.Nullable;

/* renamed from: fc.c  reason: case insensitive filesystem */
public interface C0268c<R, T> {

    /* renamed from: fc.c$a */
    public static abstract class a {
        @Nullable
        public abstract C0268c a(Type type, Annotation[] annotationArr);
    }

    Type a();

    Object b(r rVar);
}
