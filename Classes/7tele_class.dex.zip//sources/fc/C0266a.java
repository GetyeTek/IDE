package fc;

import H9.j;
import fc.i;
import ic.w;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.annotation.Nullable;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSource;

/* renamed from: fc.a  reason: case insensitive filesystem */
public final class C0266a extends i.a {
    public boolean a;

    /* renamed from: fc.a$a  reason: collision with other inner class name */
    public static final class C0024a implements i<ResponseBody, ResponseBody> {
        public static final C0024a a = new Object();

        public final Object a(Object obj) throws IOException {
            ResponseBody responseBody = (ResponseBody) obj;
            try {
                Buffer buffer = new Buffer();
                responseBody.source().readAll(buffer);
                return ResponseBody.create(responseBody.contentType(), responseBody.contentLength(), (BufferedSource) buffer);
            } finally {
                responseBody.close();
            }
        }
    }

    /* renamed from: fc.a$b */
    public static final class b implements i<RequestBody, RequestBody> {
        public static final b a = new Object();

        public final Object a(Object obj) throws IOException {
            return (RequestBody) obj;
        }
    }

    /* renamed from: fc.a$c */
    public static final class c implements i<ResponseBody, ResponseBody> {
        public static final c a = new Object();

        public final Object a(Object obj) throws IOException {
            return (ResponseBody) obj;
        }
    }

    /* renamed from: fc.a$d */
    public static final class d implements i<Object, String> {
        public static final d a = new Object();

        public final Object a(Object obj) throws IOException {
            return obj.toString();
        }
    }

    /* renamed from: fc.a$e */
    public static final class e implements i<ResponseBody, j> {
        public static final e a = new Object();

        public final Object a(Object obj) throws IOException {
            ((ResponseBody) obj).close();
            return j.a;
        }
    }

    /* renamed from: fc.a$f */
    public static final class f implements i<ResponseBody, Void> {
        public static final f a = new Object();

        public final Object a(Object obj) throws IOException {
            ((ResponseBody) obj).close();
            return null;
        }
    }

    @Nullable
    public final i a(Type type) {
        if (RequestBody.class.isAssignableFrom(F.e(type))) {
            return b.a;
        }
        return null;
    }

    @Nullable
    public final i<ResponseBody, ?> b(Type type, Annotation[] annotationArr, B b2) {
        if (type == ResponseBody.class) {
            if (F.h(annotationArr, w.class)) {
                return c.a;
            }
            return C0024a.a;
        } else if (type == Void.class) {
            return f.a;
        } else {
            if (!this.a || type != j.class) {
                return null;
            }
            try {
                return e.a;
            } catch (NoClassDefFoundError unused) {
                this.a = false;
                return null;
            }
        }
    }
}
