package fc;

import javax.annotation.Nullable;
import okhttp3.Response;
import okhttp3.ResponseBody;

public final class A<T> {
    public final Response a;
    @Nullable
    public final T b;
    @Nullable
    public final ResponseBody c;

    public A(Response response, @Nullable T t, @Nullable ResponseBody responseBody) {
        this.a = response;
        this.b = t;
        this.c = responseBody;
    }

    public final String toString() {
        return this.a.toString();
    }
}
