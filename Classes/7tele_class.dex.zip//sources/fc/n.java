package fc;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class n {
    public final Method a;
    public final List<?> b;

    public n(Method method, ArrayList arrayList) {
        this.a = method;
        this.b = Collections.unmodifiableList(arrayList);
    }

    public final String toString() {
        Method method = this.a;
        return String.format("%s.%s() %s", new Object[]{method.getDeclaringClass().getName(), method.getName(), this.b});
    }
}
