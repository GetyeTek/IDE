package fc;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.annotation.Nullable;
import okhttp3.ResponseBody;

public interface i<F, T> {

    public static abstract class a {
        @Nullable
        public i a(Type type) {
            return null;
        }

        @Nullable
        public i<ResponseBody, ?> b(Type type, Annotation[] annotationArr, B b) {
            return null;
        }
    }

    @Nullable
    T a(F f) throws IOException;
}
