package f9;

public interface c extends C0249a {
}
