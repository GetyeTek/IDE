package f9;

import android.view.ViewGroup;
import androidx.annotation.NonNull;

public interface d {
    @NonNull
    ViewGroup getLayout();
}
