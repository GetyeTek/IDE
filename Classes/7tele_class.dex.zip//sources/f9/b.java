package f9;

import androidx.annotation.RestrictTo;

public interface b extends C0249a {
    @RestrictTo({RestrictTo.Scope.LIBRARY, RestrictTo.Scope.LIBRARY_GROUP, RestrictTo.Scope.SUBCLASSES})
    boolean c(boolean z);
}
