package Ia;

import Ha.c;
import Ha.i;
import Ia.m;
import androidx.camera.camera2.internal.i1;
import org.bouncycastle.crypto.CryptoServicePurpose;

public final class l extends b implements i {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public l(int i) {
        super(i, CryptoServicePurpose.ANY);
        if (i == 128 || i == 256) {
            return;
        }
        throw new IllegalArgumentException(i1.a(i, "'bitStrength' ", " not supported for SHAKE"));
    }

    public final int b(int i, byte[] bArr) {
        int i2 = this.e / 4;
        e(i, i2, bArr);
        return i2;
    }

    public final int e(int i, int i2, byte[] bArr) {
        if (!this.f) {
            i(15, 4);
        }
        m(i, ((long) i2) * 8, bArr);
        l();
        return i2;
    }

    public final String f() {
        return "SHAKE" + this.e;
    }

    public final int g() {
        return this.e / 4;
    }

    public final c j() {
        return new m.a(f());
    }
}
