package Ia;

import Ha.c;
import Ha.e;
import Ha.g;
import java.util.Arrays;
import org.bouncycastle.crypto.CryptoServicePurpose;

public class b implements g {
    public static final long[] g = {1, 32898, -9223372036854742902L, -9223372034707259392L, 32907, 2147483649L, -9223372034707259263L, -9223372036854743031L, 138, 136, 2147516425L, 2147483658L, 2147516555L, -9223372036854775669L, -9223372036854742903L, -9223372036854743037L, -9223372036854743038L, -9223372036854775680L, 32778, -9223372034707292150L, -9223372034707259263L, -9223372036854742912L, 2147483649L, -9223372034707259384L};
    public final long[] a = new long[25];
    public final byte[] b = new byte[192];
    public int c;
    public int d;
    public int e;
    public boolean f;

    public b(int i, CryptoServicePurpose cryptoServicePurpose) {
        k(i);
        e.a(j());
    }

    public final void a(int i, byte[] bArr) {
        int i2 = this.c >>> 6;
        for (int i3 = 0; i3 < i2; i3++) {
            long[] jArr = this.a;
            jArr[i3] = jArr[i3] ^ Ca.e.b1(i, bArr);
            i += 8;
        }
        h();
    }

    public final void c(byte b2) {
        int i = this.d;
        if (i % 8 != 0) {
            throw new IllegalStateException("attempt to absorb with odd length queue");
        } else if (!this.f) {
            byte[] bArr = this.b;
            bArr[i >>> 3] = b2;
            int i2 = i + 8;
            this.d = i2;
            if (i2 == this.c) {
                a(0, bArr);
                this.d = 0;
            }
        } else {
            throw new IllegalStateException("attempt to absorb while squeezing");
        }
    }

    public final void d(int i, int i2, byte[] bArr) {
        int i3;
        int i4;
        int i5 = this.d;
        if (i5 % 8 != 0) {
            throw new IllegalStateException("attempt to absorb with odd length queue");
        } else if (!this.f) {
            int i6 = i5 >>> 3;
            int i7 = this.c >>> 3;
            int i8 = i7 - i6;
            byte[] bArr2 = this.b;
            if (i2 < i8) {
                System.arraycopy(bArr, i, bArr2, i6, i2);
                i4 = this.d + (i2 << 3);
            } else {
                if (i6 > 0) {
                    System.arraycopy(bArr, i, bArr2, i6, i8);
                    a(0, bArr2);
                } else {
                    i8 = 0;
                }
                while (true) {
                    i3 = i2 - i8;
                    if (i3 < i7) {
                        break;
                    }
                    a(i + i8, bArr);
                    i8 += i7;
                }
                System.arraycopy(bArr, i + i8, bArr2, 0, i3);
                i4 = i3 << 3;
            }
            this.d = i4;
        } else {
            throw new IllegalStateException("attempt to absorb while squeezing");
        }
    }

    public int g() {
        return this.e / 8;
    }

    public final void h() {
        long[] jArr = this.a;
        int i = 0;
        long j = jArr[0];
        boolean z = true;
        long j2 = jArr[1];
        long j3 = jArr[2];
        char c2 = 3;
        long j4 = jArr[3];
        long j5 = jArr[4];
        long j6 = jArr[5];
        long j7 = jArr[6];
        long j8 = jArr[7];
        long j10 = jArr[8];
        long j11 = jArr[9];
        long j12 = jArr[10];
        long j13 = jArr[11];
        long j14 = jArr[12];
        long j15 = jArr[13];
        long j16 = jArr[14];
        long j17 = jArr[15];
        long j18 = jArr[16];
        long j19 = jArr[17];
        long j20 = jArr[18];
        long j21 = jArr[19];
        long j22 = jArr[20];
        long j23 = jArr[21];
        long j24 = jArr[22];
        long j25 = jArr[23];
        int i2 = 24;
        long j26 = jArr[24];
        while (i < i2) {
            long j27 = (((j ^ j6) ^ j12) ^ j17) ^ j22;
            long j28 = (((j2 ^ j7) ^ j13) ^ j18) ^ j23;
            long j29 = (((j3 ^ j8) ^ j14) ^ j19) ^ j24;
            long j30 = (((j4 ^ j10) ^ j15) ^ j20) ^ j25;
            long j31 = (((j5 ^ j11) ^ j16) ^ j21) ^ j26;
            long j32 = ((j28 << (z ? 1 : 0)) | (j28 >>> -1)) ^ j31;
            long j33 = ((j29 << z) | (j29 >>> -1)) ^ j27;
            long j34 = ((j30 << z) | (j30 >>> -1)) ^ j28;
            long j35 = ((j31 << z) | (j31 >>> -1)) ^ j29;
            long j36 = ((j27 << z) | (j27 >>> -1)) ^ j30;
            long j37 = j ^ j32;
            long j38 = j6 ^ j32;
            long j39 = j12 ^ j32;
            long j40 = j17 ^ j32;
            long j41 = j22 ^ j32;
            long j42 = j2 ^ j33;
            long j43 = j7 ^ j33;
            long j44 = j13 ^ j33;
            long j45 = j18 ^ j33;
            long j46 = j23 ^ j33;
            long j47 = j8 ^ j34;
            long j48 = j14 ^ j34;
            long j49 = j19 ^ j34;
            long j50 = j24 ^ j34;
            long j51 = j10 ^ j35;
            long j52 = j15 ^ j35;
            long j53 = j20 ^ j35;
            long j54 = j25 ^ j35;
            long j55 = j11 ^ j36;
            long j56 = j16 ^ j36;
            long j57 = j21 ^ j36;
            long j58 = j26 ^ j36;
            long j59 = (j42 << z) | (j42 >>> 63);
            long j60 = (j43 << 44) | (j43 >>> 20);
            long j61 = j5 ^ j36;
            long j62 = (j55 << 20) | (j55 >>> 44);
            long j63 = j50 << 61;
            long j64 = j50 >>> c2;
            long j65 = j4 ^ j35;
            long j66 = j63 | j64;
            long j67 = j3 ^ j34;
            long j68 = (j56 << 39) | (j56 >>> 25);
            long j69 = (j48 << 43) | (j48 >>> 21);
            long j70 = (j67 << 62) | (j67 >>> 2);
            long j71 = (j52 << 25) | (j52 >>> 39);
            long j72 = (j41 << 18) | (j41 >>> 46);
            long j73 = (j57 << 8) | (j57 >>> 56);
            long j74 = j40 << 41;
            long j75 = j40 >>> 23;
            long j76 = (j54 << 56) | (j54 >>> 8);
            long j77 = j74 | j75;
            long j78 = (j61 << 27) | (j61 >>> 37);
            long j79 = (j58 << 14) | (j58 >>> 50);
            long j80 = j46 << 2;
            long j81 = j46 >>> 62;
            long j82 = j71;
            long j83 = j80 | j81;
            long j84 = (j51 << 55) | (j51 >>> 9);
            long j85 = j45 << 45;
            long j86 = j45 >>> 19;
            long j87 = j84;
            long j88 = j85 | j86;
            long j89 = j66;
            long j90 = (j38 << 36) | (j38 >>> 28);
            long j91 = j65 << 28;
            long j92 = j65 >>> 36;
            long j93 = j90;
            long j94 = j91 | j92;
            long j95 = j53 << 21;
            long j96 = j53 >>> 43;
            long j97 = j88;
            long j98 = j95 | j96;
            long j99 = j49 << 15;
            long j100 = j49 >>> 49;
            long j101 = j94;
            long j102 = j99 | j100;
            long j103 = j44 << 10;
            long j104 = j44 >>> 54;
            long j105 = j102;
            long j106 = j103 | j104;
            long j107 = j47 << 6;
            long j108 = j47 >>> 58;
            long j109 = j106;
            long j110 = j107 | j108;
            long j111 = j39 << 3;
            long j112 = j39 >>> 61;
            long j113 = j111 | j112;
            long j114 = ((~j60) & j69) ^ j37;
            long j115 = ((~j69) & j98) ^ j60;
            j3 = j69 ^ ((~j98) & j79);
            j4 = j98 ^ ((~j79) & j37);
            long j116 = j79 ^ ((~j37) & j60);
            long j117 = j113;
            long j118 = ((~j117) & j97) ^ j62;
            long j119 = j116;
            long j120 = j97;
            long j121 = j101 ^ ((~j62) & j113);
            long j122 = ((~j120) & j89) ^ j117;
            long j123 = j89;
            long j124 = j122;
            long j125 = j120 ^ ((~j123) & j101);
            long j126 = ((~j101) & j62) ^ j123;
            long j127 = j110;
            j12 = j59 ^ ((~j127) & j82);
            long j128 = j125;
            long j129 = j82;
            long j130 = ((~j129) & j73) ^ j127;
            long j131 = j73;
            long j132 = j126;
            long j133 = ((~j131) & j72) ^ j129;
            long j134 = j72;
            long j135 = j133;
            long j136 = j131 ^ ((~j134) & j59);
            long j137 = ((~j59) & j127) ^ j134;
            long j138 = j93;
            long j139 = j78 ^ ((~j138) & j109);
            long j140 = j136;
            long j141 = j109;
            long j142 = j137;
            long j143 = ((~j141) & j105) ^ j138;
            long j144 = j105;
            long j145 = j118;
            long j146 = j76;
            long j147 = j141 ^ ((~j144) & j76);
            long j148 = ((~j146) & j78) ^ j144;
            long j149 = ((~j78) & j138) ^ j146;
            long j150 = j87;
            long j151 = j148;
            long j152 = j68;
            long j153 = j149;
            long j154 = ((~j152) & j77) ^ j150;
            long j155 = j77;
            j22 = j70 ^ ((~j150) & j68);
            long j156 = j83;
            long j157 = j152 ^ ((~j155) & j83);
            long j158 = ((~j156) & j70) ^ j155;
            long j159 = j114 ^ g[i];
            i++;
            j7 = j145;
            j14 = j135;
            j13 = j130;
            j15 = j140;
            j23 = j154;
            c2 = 3;
            j25 = j158;
            j24 = j157;
            j11 = j132;
            jArr = jArr;
            j21 = j153;
            j16 = j142;
            j8 = j124;
            j10 = j128;
            j19 = j147;
            j17 = j139;
            j5 = j119;
            j6 = j121;
            i2 = 24;
            j20 = j151;
            j18 = j143;
            long j160 = j159;
            z = true;
            j2 = j115;
            j26 = ((~j70) & j150) ^ j156;
            j = j160;
        }
        long[] jArr2 = jArr;
        jArr2[0] = j;
        jArr2[1] = j2;
        jArr2[2] = j3;
        jArr2[3] = j4;
        jArr2[4] = j5;
        jArr2[5] = j6;
        jArr2[6] = j7;
        jArr2[7] = j8;
        jArr2[8] = j10;
        jArr2[9] = j11;
        jArr2[10] = j12;
        jArr2[11] = j13;
        jArr2[12] = j14;
        jArr2[13] = j15;
        jArr2[14] = j16;
        jArr2[15] = j17;
        jArr2[16] = j18;
        jArr2[17] = j19;
        jArr2[18] = j20;
        jArr2[19] = j21;
        jArr2[20] = j22;
        jArr2[21] = j23;
        jArr2[22] = j24;
        jArr2[23] = j25;
        jArr2[24] = j26;
    }

    public final void i(int i, int i2) {
        if (i2 < 1 || i2 > 7) {
            throw new IllegalArgumentException("'bits' must be in the range 1 to 7");
        }
        int i3 = this.d;
        if (i3 % 8 != 0) {
            throw new IllegalStateException("attempt to absorb with odd length queue");
        } else if (!this.f) {
            this.b[i3 >>> 3] = (byte) (i & ((1 << i2) - 1));
            this.d = i3 + i2;
        } else {
            throw new IllegalStateException("attempt to absorb while squeezing");
        }
    }

    public c j() {
        return m.a(this);
    }

    public final void k(int i) {
        if (i == 128 || i == 224 || i == 256 || i == 288 || i == 384 || i == 512) {
            int i2 = 1600 - (i << 1);
            if (i2 <= 0 || i2 >= 1600 || i2 % 64 != 0) {
                throw new IllegalStateException("invalid rate value");
            }
            this.c = i2;
            int i3 = 0;
            while (true) {
                long[] jArr = this.a;
                if (i3 < jArr.length) {
                    jArr[i3] = 0;
                    i3++;
                } else {
                    Arrays.fill(this.b, (byte) 0);
                    this.d = 0;
                    this.f = false;
                    this.e = (1600 - i2) / 2;
                    return;
                }
            }
        } else {
            throw new IllegalArgumentException("bitLength must be one of 128, 224, 256, 288, 384, or 512.");
        }
    }

    public final void l() {
        k(this.e);
    }

    public final void m(int i, long j, byte[] bArr) {
        boolean z = this.f;
        long[] jArr = this.a;
        byte[] bArr2 = this.b;
        if (!z) {
            int i2 = this.d;
            int i3 = i2 >>> 3;
            bArr2[i3] = (byte) (bArr2[i3] | ((byte) (1 << (i2 & 7))));
            int i4 = i2 + 1;
            this.d = i4;
            if (i4 == this.c) {
                a(0, bArr2);
            } else {
                int i5 = i4 >>> 6;
                int i6 = i4 & 63;
                int i7 = 0;
                for (int i8 = 0; i8 < i5; i8++) {
                    jArr[i8] = jArr[i8] ^ Ca.e.b1(i7, bArr2);
                    i7 += 8;
                }
                if (i6 > 0) {
                    jArr[i5] = (Ca.e.b1(i7, bArr2) & ((1 << i6) - 1)) ^ jArr[i5];
                }
            }
            int i10 = (this.c - 1) >>> 6;
            jArr[i10] = jArr[i10] ^ Long.MIN_VALUE;
            this.d = 0;
            this.f = true;
        }
        long j2 = 0;
        if (j % 8 == 0) {
            while (j2 < j) {
                if (this.d == 0) {
                    h();
                    int i11 = this.c >>> 6;
                    int i12 = 0;
                    for (int i13 = 0; i13 < i11; i13++) {
                        long j3 = jArr[i13];
                        Ca.e.G0((int) (4294967295L & j3), i12, bArr2);
                        Ca.e.G0((int) (j3 >>> 32), i12 + 4, bArr2);
                        i12 += 8;
                    }
                    this.d = this.c;
                }
                int min = (int) Math.min((long) this.d, j - j2);
                System.arraycopy(bArr2, (this.c - this.d) / 8, bArr, i + ((int) (j2 / 8)), min / 8);
                this.d -= min;
                j2 += (long) min;
            }
            return;
        }
        throw new IllegalStateException("outputLength not a multiple of 8");
    }
}
