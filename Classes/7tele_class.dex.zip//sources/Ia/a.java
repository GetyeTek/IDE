package Ia;

import Ha.g;
import org.bouncycastle.crypto.CryptoServicePurpose;
import org.bouncycastle.util.e;

public abstract class a implements g, e {
    public final CryptoServicePurpose a;
    public final byte[] b = new byte[4];
    public int c;
    public long d;

    public a(a aVar) {
        this.a = aVar.a;
        i(aVar);
    }

    public final void c(byte b2) {
        int i = this.c;
        int i2 = i + 1;
        this.c = i2;
        byte[] bArr = this.b;
        bArr[i] = b2;
        if (i2 == bArr.length) {
            m(0, bArr);
            this.c = 0;
        }
        this.d++;
    }

    public final void d(int i, int i2, byte[] bArr) {
        int i3 = 0;
        int max = Math.max(0, i2);
        int i4 = this.c;
        byte[] bArr2 = this.b;
        if (i4 != 0) {
            int i5 = 0;
            while (true) {
                if (i5 >= max) {
                    i3 = i5;
                    break;
                }
                int i6 = this.c;
                int i7 = i6 + 1;
                this.c = i7;
                int i8 = i5 + 1;
                bArr2[i6] = bArr[i5 + i];
                if (i7 == 4) {
                    m(0, bArr2);
                    this.c = 0;
                    i3 = i8;
                    break;
                }
                i5 = i8;
            }
        }
        int i10 = max - 3;
        while (i3 < i10) {
            m(i + i3, bArr);
            i3 += 4;
        }
        while (i3 < max) {
            int i11 = this.c;
            this.c = i11 + 1;
            bArr2[i11] = bArr[i3 + i];
            i3++;
        }
        this.d += (long) max;
    }

    public final void i(a aVar) {
        byte[] bArr = aVar.b;
        System.arraycopy(bArr, 0, this.b, 0, bArr.length);
        this.c = aVar.c;
        this.d = aVar.d;
    }

    public final void j() {
        long j = this.d << 3;
        byte b2 = Byte.MIN_VALUE;
        while (true) {
            c(b2);
            if (this.c != 0) {
                b2 = 0;
            } else {
                l(j);
                k();
                return;
            }
        }
    }

    public abstract void k();

    public abstract void l(long j);

    public abstract void m(int i, byte[] bArr);

    public void n() {
        this.d = 0;
        this.c = 0;
        int i = 0;
        while (true) {
            byte[] bArr = this.b;
            if (i < bArr.length) {
                bArr[i] = 0;
                i++;
            } else {
                return;
            }
        }
    }

    public a(CryptoServicePurpose cryptoServicePurpose) {
        this.a = cryptoServicePurpose;
        this.c = 0;
    }
}
