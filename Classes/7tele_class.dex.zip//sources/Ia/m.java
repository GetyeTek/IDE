package Ia;

import Ha.c;
import Ha.g;

public final class m {

    public static class a implements c {
        public final String a;

        public a(String str) {
            this.a = str;
        }

        public final String a() {
            return this.a;
        }
    }

    public static class b implements c {
        public final String a;

        public b(String str) {
            this.a = str;
        }

        public final String a() {
            return this.a;
        }
    }

    public static b a(g gVar) {
        gVar.g();
        return new b(gVar.f());
    }
}
