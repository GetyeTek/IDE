package Ia;

import Q8.c;

public final /* synthetic */ class d {
    public static int a(int i, int i2, int i3, int i4, int i5) {
        return e.r(i + i2 + i3, i4) + i5;
    }

    public static void b(c cVar, byte b, long j, byte b2) {
        cVar.g(b);
        cVar.j(j);
        cVar.g(b2);
    }
}
