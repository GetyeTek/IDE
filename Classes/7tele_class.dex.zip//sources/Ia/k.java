package Ia;

import Ha.e;
import org.bouncycastle.crypto.CryptoServicePurpose;

public final class k extends c {
    public k() {
        super(CryptoServicePurpose.ANY);
        e.a(m.a(this));
        p();
    }

    public final org.bouncycastle.util.e a() {
        c cVar = new c((c) this);
        e.a(m.a(cVar));
        return cVar;
    }

    public final int b(int i, byte[] bArr) {
        n();
        Ca.e.c1(i, this.f, bArr);
        Ca.e.c1(i + 8, this.g, bArr);
        Ca.e.c1(i + 16, this.h, bArr);
        Ca.e.c1(i + 24, this.i, bArr);
        Ca.e.c1(i + 32, this.j, bArr);
        Ca.e.c1(i + 40, this.k, bArr);
        Ca.e.c1(i + 48, this.l, bArr);
        Ca.e.c1(i + 56, this.m, bArr);
        p();
        return 64;
    }

    public final String f() {
        return "SHA-512";
    }

    public final int g() {
        return 64;
    }

    public final void h(org.bouncycastle.util.e eVar) {
        m((k) eVar);
    }

    public final void p() {
        super.p();
        this.f = 7640891576956012808L;
        this.g = -4942790177534073029L;
        this.h = 4354685564936845355L;
        this.i = -6534734903238641935L;
        this.j = 5840696475078001361L;
        this.k = -7276294671716946913L;
        this.l = 2270897969802886507L;
        this.m = 6620516959819538809L;
    }
}
