package Ia;

import Ha.e;
import org.bouncycastle.crypto.CryptoServicePurpose;

public final class i extends c {
    public i() {
        super(CryptoServicePurpose.ANY);
        e.a(m.a(this));
        p();
    }

    public final org.bouncycastle.util.e a() {
        c cVar = new c((c) this);
        e.a(m.a(cVar));
        return cVar;
    }

    public final int b(int i, byte[] bArr) {
        n();
        Ca.e.c1(i, this.f, bArr);
        Ca.e.c1(i + 8, this.g, bArr);
        Ca.e.c1(i + 16, this.h, bArr);
        Ca.e.c1(i + 24, this.i, bArr);
        Ca.e.c1(i + 32, this.j, bArr);
        Ca.e.c1(i + 40, this.k, bArr);
        p();
        return 48;
    }

    public final String f() {
        return "SHA-384";
    }

    public final int g() {
        return 48;
    }

    public final void h(org.bouncycastle.util.e eVar) {
        m((i) eVar);
    }

    public final void p() {
        super.p();
        this.f = -3766243637369397544L;
        this.g = 7105036623409894663L;
        this.h = -7973340178411365097L;
        this.i = 1526699215303891257L;
        this.j = 7436329637833083697L;
        this.k = -8163818279084223215L;
        this.l = -2662702644619276377L;
        this.m = 5167115440072839076L;
    }
}
