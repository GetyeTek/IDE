package Ia;

import Ha.g;
import org.bouncycastle.crypto.CryptoServicePurpose;
import org.bouncycastle.util.e;

public abstract class c implements g, e {
    public static final long[] p = {4794697086780616226L, 8158064640168781261L, -5349999486874862801L, -1606136188198331460L, 4131703408338449720L, 6480981068601479193L, -7908458776815382629L, -6116909921290321640L, -2880145864133508542L, 1334009975649890238L, 2608012711638119052L, 6128411473006802146L, 8268148722764581231L, -9160688886553864527L, -7215885187991268811L, -4495734319001033068L, -1973867731355612462L, -1171420211273849373L, 1135362057144423861L, 2597628984639134821L, 3308224258029322869L, 5365058923640841347L, 6679025012923562964L, 8573033837759648693L, -7476448914759557205L, -6327057829258317296L, -5763719355590565569L, -4658551843659510044L, -4116276920077217854L, -3051310485924567259L, 489312712824947311L, 1452737877330783856L, 2861767655752347644L, 3322285676063803686L, 5560940570517711597L, 5996557281743188959L, 7280758554555802590L, 8532644243296465576L, -9096487096722542874L, -7894198246740708037L, -6719396339535248540L, -6333637450476146687L, -4446306890439682159L, -4076793802049405392L, -3345356375505022440L, -2983346525034927856L, -860691631967231958L, 1182934255886127544L, 1847814050463011016L, 2177327727835720531L, 2830643537854262169L, 3796741975233480872L, 4115178125766777443L, 5681478168544905931L, 6601373596472566643L, 7507060721942968483L, 8399075790359081724L, 8693463985226723168L, -8878714635349349518L, -8302665154208450068L, -8016688836872298968L, -6606660893046293015L, -4685533653050689259L, -4147400797238176981L, -3880063495543823972L, -3348786107499101689L, -1523767162380948706L, -757361751448694408L, 500013540394364858L, 748580250866718886L, 1242879168328830382L, 1977374033974150939L, 2944078676154940804L, 3659926193048069267L, 4368137639120453308L, 4836135668995329356L, 5532061633213252278L, 6448918945643986474L, 6902733635092675308L, 7801388544844847127L};
    public final CryptoServicePurpose a;
    public final byte[] b = new byte[8];
    public int c;
    public long d;
    public long e;
    public long f;
    public long g;
    public long h;
    public long i;
    public long j;
    public long k;
    public long l;
    public long m;
    public final long[] n = new long[80];
    public int o;

    public c(c cVar) {
        this.a = cVar.a;
        m(cVar);
    }

    public static long i(long j2, long j3, long j4) {
        return ((~j2) & j4) ^ (j3 & j2);
    }

    public static long j(long j2, long j3, long j4) {
        return ((j2 & j4) ^ (j2 & j3)) ^ (j3 & j4);
    }

    public static long k(long j2) {
        return ((j2 >>> 39) | (j2 << 25)) ^ (((j2 << 36) | (j2 >>> 28)) ^ ((j2 << 30) | (j2 >>> 34)));
    }

    public static long l(long j2) {
        return ((j2 >>> 41) | (j2 << 23)) ^ (((j2 << 50) | (j2 >>> 14)) ^ ((j2 << 46) | (j2 >>> 18)));
    }

    public final void c(byte b2) {
        int i2 = this.c;
        int i3 = i2 + 1;
        this.c = i3;
        byte[] bArr = this.b;
        bArr[i2] = b2;
        if (i3 == bArr.length) {
            this.n[this.o] = Ca.e.C(0, bArr);
            int i4 = this.o + 1;
            this.o = i4;
            if (i4 == 16) {
                o();
            }
            this.c = 0;
        }
        this.d++;
    }

    public final void d(int i2, int i3, byte[] bArr) {
        while (this.c != 0 && i3 > 0) {
            c(bArr[i2]);
            i2++;
            i3--;
        }
        while (true) {
            byte[] bArr2 = this.b;
            if (i3 < bArr2.length) {
                break;
            }
            this.n[this.o] = Ca.e.C(i2, bArr);
            int i4 = this.o + 1;
            this.o = i4;
            if (i4 == 16) {
                o();
            }
            i2 += bArr2.length;
            i3 -= bArr2.length;
            this.d += (long) bArr2.length;
        }
        while (i3 > 0) {
            c(bArr[i2]);
            i2++;
            i3--;
        }
    }

    public final void m(c cVar) {
        byte[] bArr = cVar.b;
        System.arraycopy(bArr, 0, this.b, 0, bArr.length);
        this.c = cVar.c;
        this.d = cVar.d;
        this.e = cVar.e;
        this.f = cVar.f;
        this.g = cVar.g;
        this.h = cVar.h;
        this.i = cVar.i;
        this.j = cVar.j;
        this.k = cVar.k;
        this.l = cVar.l;
        this.m = cVar.m;
        long[] jArr = this.n;
        long[] jArr2 = cVar.n;
        System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
        this.o = cVar.o;
    }

    public final void n() {
        long j2 = this.d;
        if (j2 > 2305843009213693951L) {
            this.e += j2 >>> 61;
            this.d = j2 & 2305843009213693951L;
        }
        long j3 = this.d << 3;
        long j4 = this.e;
        byte b2 = Byte.MIN_VALUE;
        while (true) {
            c(b2);
            if (this.c == 0) {
                break;
            }
            b2 = 0;
        }
        if (this.o > 14) {
            o();
        }
        long[] jArr = this.n;
        jArr[14] = j4;
        jArr[15] = j3;
        o();
    }

    public final void o() {
        long[] jArr;
        long j2 = this.d;
        if (j2 > 2305843009213693951L) {
            this.e += j2 >>> 61;
            this.d = j2 & 2305843009213693951L;
        }
        int i2 = 16;
        while (true) {
            jArr = this.n;
            if (i2 > 79) {
                break;
            }
            long j3 = jArr[i2 - 2];
            long j4 = ((j3 >>> 6) ^ (((j3 << 45) | (j3 >>> 19)) ^ ((j3 << 3) | (j3 >>> 61)))) + jArr[i2 - 7];
            long j5 = jArr[i2 - 15];
            jArr[i2] = j4 + ((((j5 >>> 8) | (j5 << 56)) ^ ((j5 << 63) | (j5 >>> 1))) ^ (j5 >>> 7)) + jArr[i2 - 16];
            i2++;
        }
        long j6 = this.f;
        long j7 = this.g;
        long j8 = this.h;
        long j10 = this.i;
        long j11 = this.j;
        long j12 = j6;
        long j13 = this.k;
        long j14 = this.l;
        long[] jArr2 = jArr;
        long j15 = this.m;
        long j16 = j13;
        long j17 = j11;
        int i3 = 0;
        int i4 = 0;
        long j18 = j14;
        long j19 = j10;
        long j20 = j8;
        long j21 = j7;
        long j22 = j18;
        while (i3 < 10) {
            long[] jArr3 = p;
            int i5 = i4 + 1;
            long l2 = l(j17) + i(j17, j16, j22) + jArr3[i4] + jArr2[i4] + j15;
            long j23 = j19 + l2;
            long k2 = k(j12) + j(j12, j21, j20) + l2;
            int i6 = i4 + 2;
            long l3 = j22 + l(j23) + i(j23, j17, j16) + jArr3[i5] + jArr2[i5];
            long j24 = j20 + l3;
            long k3 = k(k2) + j(k2, j12, j21) + l3;
            int i7 = i4 + 3;
            long l4 = l(j24) + i(j24, j23, j17) + jArr3[i6] + jArr2[i6] + j16;
            long j25 = j21 + l4;
            long k4 = k(k3) + j(k3, k2, j12) + l4;
            int i8 = i4 + 4;
            long l5 = l(j25) + i(j25, j24, j23) + jArr3[i7] + jArr2[i7] + j17;
            long j26 = j12 + l5;
            long k5 = k(k4) + j(k4, k3, k2) + l5;
            int i10 = i4 + 5;
            long l6 = l(j26) + i(j26, j25, j24) + jArr3[i8] + jArr2[i8] + j23;
            long j27 = k2 + l6;
            long k6 = k(k5) + j(k5, k4, k3) + l6;
            int i11 = i4 + 6;
            long l7 = l(j27) + i(j27, j26, j25) + jArr3[i10] + jArr2[i10] + j24;
            j22 = k3 + l7;
            j20 = k(k6) + j(k6, k5, k4) + l7;
            int i12 = i4 + 7;
            long l8 = l(j22) + i(j22, j27, j26) + jArr3[i11] + jArr2[i11] + j25;
            j16 = k4 + l8;
            j21 = k(j20) + j(j20, k6, k5) + l8;
            i4 += 8;
            long l9 = l(j16) + i(j16, j22, j27) + jArr3[i12] + jArr2[i12] + j26;
            i3++;
            j19 = k6;
            j15 = j27;
            j17 = k5 + l9;
            j12 = k(j21) + j(j21, j20, k6) + l9;
        }
        this.f += j12;
        this.g += j21;
        this.h += j20;
        this.i += j19;
        this.j += j17;
        this.k += j16;
        this.l += j22;
        this.m += j15;
        this.o = 0;
        for (int i13 = 0; i13 < 16; i13++) {
            jArr2[i13] = 0;
        }
    }

    public void p() {
        this.d = 0;
        this.e = 0;
        int i2 = 0;
        this.c = 0;
        int i3 = 0;
        while (true) {
            byte[] bArr = this.b;
            if (i3 >= bArr.length) {
                break;
            }
            bArr[i3] = 0;
            i3++;
        }
        this.o = 0;
        while (true) {
            long[] jArr = this.n;
            if (i2 != jArr.length) {
                jArr[i2] = 0;
                i2++;
            } else {
                return;
            }
        }
    }

    public c(CryptoServicePurpose cryptoServicePurpose) {
        this.a = cryptoServicePurpose;
        this.c = 0;
        p();
    }
}
