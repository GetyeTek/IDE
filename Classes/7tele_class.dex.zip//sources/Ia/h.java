package Ia;

import Ha.e;
import org.bouncycastle.crypto.CryptoServicePurpose;

public final class h extends a {
    public static final int[] o = {1116352408, 1899447441, -1245643825, -373957723, 961987163, 1508970993, -1841331548, -1424204075, -670586216, 310598401, 607225278, 1426881987, 1925078388, -2132889090, -1680079193, -1046744716, -459576895, -272742522, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, -1740746414, -1473132947, -1341970488, -1084653625, -958395405, -710438585, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, -2117940946, -1838011259, -1564481375, -1474664885, -1035236496, -949202525, -778901479, -694614492, -200395387, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, -2067236844, -1933114872, -1866530822, -1538233109, -1090935817, -965641998};
    public int e;
    public int f;
    public int g;
    public int h;
    public int i;
    public int j;
    public int k;
    public int l;
    public int[] m = new int[64];
    public int n;

    public h() {
        super(CryptoServicePurpose.ANY);
        e.a(m.a(this));
        n();
    }

    public static int o(int i2, int i3, int i4) {
        return ((~i2) & i4) ^ (i3 & i2);
    }

    public static int p(int i2, int i3, int i4) {
        return ((i2 ^ i3) & i4) | (i2 & i3);
    }

    public static int q(int i2) {
        return ((i2 << 10) | (i2 >>> 22)) ^ (((i2 >>> 2) | (i2 << 30)) ^ ((i2 >>> 13) | (i2 << 19)));
    }

    public static int r(int i2) {
        return ((i2 << 7) | (i2 >>> 25)) ^ (((i2 >>> 6) | (i2 << 26)) ^ ((i2 >>> 11) | (i2 << 21)));
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [Ia.h, Ia.a, org.bouncycastle.util.e] */
    public final org.bouncycastle.util.e a() {
        ? aVar = new a((a) this);
        aVar.m = new int[64];
        aVar.s(this);
        return aVar;
    }

    public final int b(int i2, byte[] bArr) {
        j();
        Ca.e.F0(this.e, i2, bArr);
        Ca.e.F0(this.f, i2 + 4, bArr);
        Ca.e.F0(this.g, i2 + 8, bArr);
        Ca.e.F0(this.h, i2 + 12, bArr);
        Ca.e.F0(this.i, i2 + 16, bArr);
        Ca.e.F0(this.j, i2 + 20, bArr);
        Ca.e.F0(this.k, i2 + 24, bArr);
        Ca.e.F0(this.l, i2 + 28, bArr);
        n();
        return 32;
    }

    public final String f() {
        return "SHA-256";
    }

    public final int g() {
        return 32;
    }

    public final void h(org.bouncycastle.util.e eVar) {
        s((h) eVar);
    }

    public final void k() {
        int[] iArr;
        int i2 = 16;
        while (true) {
            iArr = this.m;
            if (i2 > 63) {
                break;
            }
            int i3 = iArr[i2 - 2];
            int i4 = ((i3 >>> 10) ^ (((i3 >>> 17) | (i3 << 15)) ^ ((i3 >>> 19) | (i3 << 13)))) + iArr[i2 - 7];
            int i5 = iArr[i2 - 15];
            iArr[i2] = i4 + ((i5 >>> 3) ^ (((i5 >>> 7) | (i5 << 25)) ^ ((i5 >>> 18) | (i5 << 14)))) + iArr[i2 - 16];
            i2++;
        }
        int i6 = this.e;
        int i7 = this.f;
        int i8 = this.g;
        int i10 = this.h;
        int i11 = this.i;
        int i12 = this.j;
        int i13 = this.k;
        int i14 = this.l;
        int i15 = 0;
        for (int i16 = 0; i16 < 8; i16++) {
            int o2 = o(i11, i12, i13) + r(i11);
            int[] iArr2 = o;
            int i17 = o2 + iArr2[i15] + iArr[i15] + i14;
            int i18 = i10 + i17;
            int p = p(i6, i7, i8) + q(i6) + i17;
            int i19 = i15 + 1;
            int o3 = o(i18, i11, i12) + r(i18) + iArr2[i19] + iArr[i19] + i13;
            int i20 = i8 + o3;
            int p2 = p(p, i6, i7) + q(p) + o3;
            int i21 = i15 + 2;
            int o4 = o(i20, i18, i11) + r(i20) + iArr2[i21] + iArr[i21] + i12;
            int i22 = i7 + o4;
            int p3 = p(p2, p, i6) + q(p2) + o4;
            int i23 = i15 + 3;
            int o5 = o(i22, i20, i18) + r(i22) + iArr2[i23] + iArr[i23] + i11;
            int i24 = i6 + o5;
            int p4 = p(p3, p2, p) + q(p3) + o5;
            int i25 = i15 + 4;
            int o6 = o(i24, i22, i20) + r(i24) + iArr2[i25] + iArr[i25] + i18;
            i14 = p + o6;
            i10 = p(p4, p3, p2) + q(p4) + o6;
            int i26 = i15 + 5;
            int o7 = o(i14, i24, i22) + r(i14) + iArr2[i26] + iArr[i26] + i20;
            i13 = p2 + o7;
            i8 = p(i10, p4, p3) + q(i10) + o7;
            int i27 = i15 + 6;
            int o8 = o(i13, i14, i24) + r(i13) + iArr2[i27] + iArr[i27] + i22;
            i12 = p3 + o8;
            i7 = p(i8, i10, p4) + q(i8) + o8;
            int i28 = i15 + 7;
            int o9 = o(i12, i13, i14) + r(i12) + iArr2[i28] + iArr[i28] + i24;
            i11 = p4 + o9;
            i6 = p(i7, i8, i10) + q(i7) + o9;
            i15 += 8;
        }
        this.e += i6;
        this.f += i7;
        this.g += i8;
        this.h += i10;
        this.i += i11;
        this.j += i12;
        this.k += i13;
        this.l += i14;
        this.n = 0;
        for (int i29 = 0; i29 < 16; i29++) {
            iArr[i29] = 0;
        }
    }

    public final void l(long j2) {
        if (this.n > 14) {
            k();
        }
        int[] iArr = this.m;
        iArr[14] = (int) (j2 >>> 32);
        iArr[15] = (int) j2;
    }

    public final void m(int i2, byte[] bArr) {
        this.m[this.n] = Ca.e.B(i2, bArr);
        int i3 = this.n + 1;
        this.n = i3;
        if (i3 == 16) {
            k();
        }
    }

    public final void n() {
        super.n();
        this.e = 1779033703;
        this.f = -1150833019;
        this.g = 1013904242;
        this.h = -1521486534;
        this.i = 1359893119;
        this.j = -1694144372;
        this.k = 528734635;
        this.l = 1541459225;
        this.n = 0;
        int i2 = 0;
        while (true) {
            int[] iArr = this.m;
            if (i2 != iArr.length) {
                iArr[i2] = 0;
                i2++;
            } else {
                return;
            }
        }
    }

    public final void s(h hVar) {
        i(hVar);
        this.e = hVar.e;
        this.f = hVar.f;
        this.g = hVar.g;
        this.h = hVar.h;
        this.i = hVar.i;
        this.j = hVar.j;
        this.k = hVar.k;
        this.l = hVar.l;
        int[] iArr = this.m;
        int[] iArr2 = hVar.m;
        System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
        this.n = hVar.n;
    }
}
