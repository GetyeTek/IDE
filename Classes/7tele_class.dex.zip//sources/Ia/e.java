package Ia;

import org.bouncycastle.crypto.CryptoServicePurpose;

public final class e extends a {
    public int e;
    public int f;
    public int g;
    public int h;
    public int[] i = new int[16];
    public int j;

    public e() {
        super(CryptoServicePurpose.ANY);
        Ha.e.a(m.a(this));
        n();
    }

    public static int o(int i2, int i3, int i4) {
        return ((~i2) & i4) | (i3 & i2);
    }

    public static int p(int i2, int i3, int i4) {
        return (i2 & i4) | (i3 & (~i4));
    }

    public static int r(int i2, int i3) {
        return (i2 >>> (32 - i3)) | (i2 << i3);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [Ia.a, Ia.e, org.bouncycastle.util.e] */
    public final org.bouncycastle.util.e a() {
        ? aVar = new a((a) this);
        aVar.i = new int[16];
        aVar.q(this);
        return aVar;
    }

    public final int b(int i2, byte[] bArr) {
        j();
        Ca.e.G0(this.e, i2, bArr);
        Ca.e.G0(this.f, i2 + 4, bArr);
        Ca.e.G0(this.g, i2 + 8, bArr);
        Ca.e.G0(this.h, i2 + 12, bArr);
        n();
        return 16;
    }

    public final String f() {
        return "MD5";
    }

    public final int g() {
        return 16;
    }

    public final void h(org.bouncycastle.util.e eVar) {
        q((e) eVar);
    }

    public final void k() {
        int i2 = this.e;
        int i3 = this.f;
        int i4 = this.g;
        int i5 = this.h;
        int o = o(i3, i4, i5) + i2;
        int[] iArr = this.i;
        int a = d.a(o, iArr[0], -680876936, 7, i3);
        int a2 = d.a(o(a, i3, i4) + i5, iArr[1], -389564586, 12, a);
        int a3 = d.a(o(a2, a, i3) + i4, iArr[2], 606105819, 17, a2);
        int a4 = d.a(o(a3, a2, a) + i3, iArr[3], -1044525330, 22, a3);
        int a5 = d.a(o(a4, a3, a2) + a, iArr[4], -176418897, 7, a4);
        int a6 = d.a(o(a5, a4, a3) + a2, iArr[5], 1200080426, 12, a5);
        int a7 = d.a(o(a6, a5, a4) + a3, iArr[6], -1473231341, 17, a6);
        int a8 = d.a(o(a7, a6, a5) + a4, iArr[7], -45705983, 22, a7);
        int a10 = d.a(o(a8, a7, a6) + a5, iArr[8], 1770035416, 7, a8);
        int a11 = d.a(o(a10, a8, a7) + a6, iArr[9], -1958414417, 12, a10);
        int a12 = d.a(o(a11, a10, a8) + a7, iArr[10], -42063, 17, a11);
        int a13 = d.a(o(a12, a11, a10) + a8, iArr[11], -1990404162, 22, a12);
        int a14 = d.a(o(a13, a12, a11) + a10, iArr[12], 1804603682, 7, a13);
        int a15 = d.a(o(a14, a13, a12) + a11, iArr[13], -40341101, 12, a14);
        int a16 = d.a(o(a15, a14, a13) + a12, iArr[14], -1502002290, 17, a15);
        int a17 = d.a(o(a16, a15, a14) + a13, iArr[15], 1236535329, 22, a16);
        int a18 = d.a(p(a17, a16, a15) + a14, iArr[1], -165796510, 5, a17);
        int a19 = d.a(p(a18, a17, a16) + a15, iArr[6], -1069501632, 9, a18);
        int a20 = d.a(p(a19, a18, a17) + a16, iArr[11], 643717713, 14, a19);
        int a21 = d.a(p(a20, a19, a18) + a17, iArr[0], -373897302, 20, a20);
        int a22 = d.a(p(a21, a20, a19) + a18, iArr[5], -701558691, 5, a21);
        int a23 = d.a(p(a22, a21, a20) + a19, iArr[10], 38016083, 9, a22);
        int a24 = d.a(p(a23, a22, a21) + a20, iArr[15], -660478335, 14, a23);
        int a25 = d.a(p(a24, a23, a22) + a21, iArr[4], -405537848, 20, a24);
        int a26 = d.a(p(a25, a24, a23) + a22, iArr[9], 568446438, 5, a25);
        int a27 = d.a(p(a26, a25, a24) + a23, iArr[14], -1019803690, 9, a26);
        int a28 = d.a(p(a27, a26, a25) + a24, iArr[3], -187363961, 14, a27);
        int a29 = d.a(p(a28, a27, a26) + a25, iArr[8], 1163531501, 20, a28);
        int a30 = d.a(p(a29, a28, a27) + a26, iArr[13], -1444681467, 5, a29);
        int a31 = d.a(p(a30, a29, a28) + a27, iArr[2], -51403784, 9, a30);
        int a32 = d.a(p(a31, a30, a29) + a28, iArr[7], 1735328473, 14, a31);
        int a33 = d.a(p(a32, a31, a30) + a29, iArr[12], -1926607734, 20, a32);
        int a34 = d.a(a30 + ((a33 ^ a32) ^ a31), iArr[5], -378558, 4, a33);
        int a35 = d.a(a31 + ((a34 ^ a33) ^ a32), iArr[8], -2022574463, 11, a34);
        int a36 = d.a(a32 + ((a35 ^ a34) ^ a33), iArr[11], 1839030562, 16, a35);
        int a37 = d.a(a33 + ((a36 ^ a35) ^ a34), iArr[14], -35309556, 23, a36);
        int a38 = d.a(a34 + ((a37 ^ a36) ^ a35), iArr[1], -1530992060, 4, a37);
        int a39 = d.a(a35 + ((a38 ^ a37) ^ a36), iArr[4], 1272893353, 11, a38);
        int a40 = d.a(a36 + ((a39 ^ a38) ^ a37), iArr[7], -155497632, 16, a39);
        int a41 = d.a(a37 + ((a40 ^ a39) ^ a38), iArr[10], -1094730640, 23, a40);
        int a42 = d.a(a38 + ((a41 ^ a40) ^ a39), iArr[13], 681279174, 4, a41);
        int a43 = d.a(a39 + ((a42 ^ a41) ^ a40), iArr[0], -358537222, 11, a42);
        int a44 = d.a(a40 + ((a43 ^ a42) ^ a41), iArr[3], -722521979, 16, a43);
        int r = r(a41 + ((a44 ^ a43) ^ a42) + iArr[6] + 76029189, 23) + a44;
        int a45 = d.a(a42 + ((r ^ a44) ^ a43), iArr[9], -640364487, 4, r);
        int a46 = d.a(a43 + ((a45 ^ r) ^ a44), iArr[12], -421815835, 11, a45);
        int a47 = d.a(a44 + ((a46 ^ a45) ^ r), iArr[15], 530742520, 16, a46);
        int a48 = d.a(r + ((a47 ^ a46) ^ a45), iArr[2], -995338651, 23, a47);
        int a49 = d.a(a45 + (((~a46) | a48) ^ a47), iArr[0], -198630844, 6, a48);
        int a50 = d.a(a46 + (((~a47) | a49) ^ a48), iArr[7], 1126891415, 10, a49);
        int a51 = d.a(a47 + (((~a48) | a50) ^ a49), iArr[14], -1416354905, 15, a50);
        int a52 = d.a(a48 + (((~a49) | a51) ^ a50), iArr[5], -57434055, 21, a51);
        int a53 = d.a(a49 + (((~a50) | a52) ^ a51), iArr[12], 1700485571, 6, a52);
        int a54 = d.a(a50 + (((~a51) | a53) ^ a52), iArr[3], -1894986606, 10, a53);
        int r2 = r(((a51 + (((~a52) | a54) ^ a53)) + iArr[10]) - 1051523, 15) + a54;
        int a55 = d.a(a52 + (((~a53) | r2) ^ a54), iArr[1], -2054922799, 21, r2);
        int a56 = d.a(a53 + (((~a54) | a55) ^ r2), iArr[8], 1873313359, 6, a55);
        int a57 = d.a(a54 + (((~r2) | a56) ^ a55), iArr[15], -30611744, 10, a56);
        int a58 = d.a(r2 + (((~a55) | a57) ^ a56), iArr[6], -1560198380, 15, a57);
        int a59 = d.a(a55 + (((~a56) | a58) ^ a57), iArr[13], 1309151649, 21, a58);
        int a60 = d.a(a56 + (((~a57) | a59) ^ a58), iArr[4], -145523070, 6, a59);
        int a61 = d.a(a57 + (((~a58) | a60) ^ a59), iArr[11], -1120210379, 10, a60);
        int a62 = d.a(a58 + (((~a59) | a61) ^ a60), iArr[2], 718787259, 15, a61);
        int a63 = d.a(a59 + (((~a60) | a62) ^ a61), iArr[9], -343485551, 21, a62);
        this.e += a60;
        this.f += a63;
        this.g += a62;
        this.h += a61;
        this.j = 0;
        for (int i6 = 0; i6 != iArr.length; i6++) {
            iArr[i6] = 0;
        }
    }

    public final void l(long j2) {
        if (this.j > 14) {
            k();
        }
        int[] iArr = this.i;
        iArr[14] = (int) j2;
        iArr[15] = (int) (j2 >>> 32);
    }

    public final void m(int i2, byte[] bArr) {
        int i3 = this.j;
        this.j = i3 + 1;
        this.i[i3] = Ca.e.Z0(i2, bArr);
        if (this.j == 16) {
            k();
        }
    }

    public final void n() {
        super.n();
        this.e = 1732584193;
        this.f = -271733879;
        this.g = -1732584194;
        this.h = 271733878;
        this.j = 0;
        int i2 = 0;
        while (true) {
            int[] iArr = this.i;
            if (i2 != iArr.length) {
                iArr[i2] = 0;
                i2++;
            } else {
                return;
            }
        }
    }

    public final void q(e eVar) {
        i(eVar);
        this.e = eVar.e;
        this.f = eVar.f;
        this.g = eVar.g;
        this.h = eVar.h;
        int[] iArr = this.i;
        int[] iArr2 = eVar.i;
        System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
        this.j = eVar.j;
    }
}
