package Ia;

import Ha.e;
import androidx.appcompat.widget.a;
import org.bouncycastle.crypto.CryptoServicePurpose;

public final class f extends a {
    public int e;
    public int f;
    public int g;
    public int h;
    public int i;
    public int[] j = new int[80];
    public int k;

    public f() {
        super(CryptoServicePurpose.ANY);
        e.a(m.a(this));
        n();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [Ha.g, Ia.f, Ia.a, org.bouncycastle.util.e] */
    public final org.bouncycastle.util.e a() {
        ? aVar = new a((a) this);
        aVar.j = new int[80];
        e.a(m.a(aVar));
        aVar.o(this);
        return aVar;
    }

    public final int b(int i2, byte[] bArr) {
        j();
        Ca.e.F0(this.e, i2, bArr);
        Ca.e.F0(this.f, i2 + 4, bArr);
        Ca.e.F0(this.g, i2 + 8, bArr);
        Ca.e.F0(this.h, i2 + 12, bArr);
        Ca.e.F0(this.i, i2 + 16, bArr);
        n();
        return 20;
    }

    public final String f() {
        return "SHA-1";
    }

    public final int g() {
        return 20;
    }

    public final void h(org.bouncycastle.util.e eVar) {
        f fVar = (f) eVar;
        i(fVar);
        o(fVar);
    }

    public final void k() {
        int[] iArr;
        int i2 = 16;
        while (true) {
            iArr = this.j;
            if (i2 >= 80) {
                break;
            }
            int i3 = ((iArr[i2 - 3] ^ iArr[i2 - 8]) ^ iArr[i2 - 14]) ^ iArr[i2 - 16];
            iArr[i2] = (i3 >>> 31) | (i3 << 1);
            i2++;
        }
        int i4 = this.e;
        int i5 = this.f;
        int i6 = this.g;
        int i7 = this.h;
        int i8 = this.i;
        int i10 = 0;
        for (int i11 = 0; i11 < 4; i11++) {
            int a = a.a(((i5 & i6) | ((~i5) & i7)) + ((i4 << 5) | (i4 >>> 27)), iArr[i10], 1518500249, i8);
            int i12 = (i5 >>> 2) | (i5 << 30);
            int a2 = a.a(((i4 & i12) | ((~i4) & i6)) + ((a << 5) | (a >>> 27)), iArr[i10 + 1], 1518500249, i7);
            int i13 = (i4 >>> 2) | (i4 << 30);
            int a3 = a.a(((a & i13) | ((~a) & i12)) + ((a2 << 5) | (a2 >>> 27)), iArr[i10 + 2], 1518500249, i6);
            i8 = (a >>> 2) | (a << 30);
            int i14 = i10 + 4;
            i5 = a.a(((a2 & i8) | ((~a2) & i13)) + ((a3 << 5) | (a3 >>> 27)), iArr[i10 + 3], 1518500249, i12);
            i7 = (a2 >>> 2) | (a2 << 30);
            i10 += 5;
            i4 = a.a(((a3 & i7) | ((~a3) & i8)) + ((i5 << 5) | (i5 >>> 27)), iArr[i14], 1518500249, i13);
            i6 = (a3 >>> 2) | (a3 << 30);
        }
        for (int i15 = 0; i15 < 4; i15++) {
            int a4 = a.a(((i4 << 5) | (i4 >>> 27)) + ((i5 ^ i6) ^ i7), iArr[i10], 1859775393, i8);
            int i16 = (i5 >>> 2) | (i5 << 30);
            int a5 = a.a(((a4 << 5) | (a4 >>> 27)) + ((i4 ^ i16) ^ i6), iArr[i10 + 1], 1859775393, i7);
            int i17 = (i4 >>> 2) | (i4 << 30);
            int a6 = a.a(((a5 << 5) | (a5 >>> 27)) + ((a4 ^ i17) ^ i16), iArr[i10 + 2], 1859775393, i6);
            i8 = (a4 >>> 2) | (a4 << 30);
            int i18 = i10 + 4;
            i5 = a.a(((a6 << 5) | (a6 >>> 27)) + ((a5 ^ i8) ^ i17), iArr[i10 + 3], 1859775393, i16);
            i7 = (a5 >>> 2) | (a5 << 30);
            i10 += 5;
            i4 = a.a(((i5 << 5) | (i5 >>> 27)) + ((a6 ^ i7) ^ i8), iArr[i18], 1859775393, i17);
            i6 = (a6 >>> 2) | (a6 << 30);
        }
        for (int i19 = 0; i19 < 4; i19++) {
            int a7 = a.a((((i6 | i7) & i5) | (i6 & i7)) + ((i4 << 5) | (i4 >>> 27)), iArr[i10], -1894007588, i8);
            int i20 = (i5 >>> 2) | (i5 << 30);
            int a8 = a.a((((i20 | i6) & i4) | (i20 & i6)) + ((a7 << 5) | (a7 >>> 27)), iArr[i10 + 1], -1894007588, i7);
            int i21 = (i4 >>> 2) | (i4 << 30);
            int a10 = a.a((((i21 | i20) & a7) | (i21 & i20)) + ((a8 << 5) | (a8 >>> 27)), iArr[i10 + 2], -1894007588, i6);
            i8 = (a7 >>> 2) | (a7 << 30);
            int i22 = i10 + 4;
            i5 = a.a((((i8 | i21) & a8) | (i8 & i21)) + ((a10 << 5) | (a10 >>> 27)), iArr[i10 + 3], -1894007588, i20);
            i7 = (a8 >>> 2) | (a8 << 30);
            i10 += 5;
            i4 = a.a((((i7 | i8) & a10) | (i7 & i8)) + ((i5 << 5) | (i5 >>> 27)), iArr[i22], -1894007588, i21);
            i6 = (a10 >>> 2) | (a10 << 30);
        }
        for (int i23 = 0; i23 <= 3; i23++) {
            int a11 = a.a(((i4 << 5) | (i4 >>> 27)) + ((i5 ^ i6) ^ i7), iArr[i10], -899497514, i8);
            int i24 = (i5 >>> 2) | (i5 << 30);
            int a12 = a.a(((a11 << 5) | (a11 >>> 27)) + ((i4 ^ i24) ^ i6), iArr[i10 + 1], -899497514, i7);
            int i25 = (i4 >>> 2) | (i4 << 30);
            int a13 = a.a(((a12 << 5) | (a12 >>> 27)) + ((a11 ^ i25) ^ i24), iArr[i10 + 2], -899497514, i6);
            i8 = (a11 >>> 2) | (a11 << 30);
            int i26 = i10 + 4;
            i5 = a.a(((a13 << 5) | (a13 >>> 27)) + ((a12 ^ i8) ^ i25), iArr[i10 + 3], -899497514, i24);
            i7 = (a12 >>> 2) | (a12 << 30);
            i10 += 5;
            i4 = a.a(((i5 << 5) | (i5 >>> 27)) + ((a13 ^ i7) ^ i8), iArr[i26], -899497514, i25);
            i6 = (a13 >>> 2) | (a13 << 30);
        }
        this.e += i4;
        this.f += i5;
        this.g += i6;
        this.h += i7;
        this.i += i8;
        this.k = 0;
        for (int i27 = 0; i27 < 16; i27++) {
            iArr[i27] = 0;
        }
    }

    public final void l(long j2) {
        if (this.k > 14) {
            k();
        }
        int[] iArr = this.j;
        iArr[14] = (int) (j2 >>> 32);
        iArr[15] = (int) j2;
    }

    public final void m(int i2, byte[] bArr) {
        this.j[this.k] = Ca.e.B(i2, bArr);
        int i3 = this.k + 1;
        this.k = i3;
        if (i3 == 16) {
            k();
        }
    }

    public final void n() {
        super.n();
        this.e = 1732584193;
        this.f = -271733879;
        this.g = -1732584194;
        this.h = 271733878;
        this.i = -1009589776;
        this.k = 0;
        int i2 = 0;
        while (true) {
            int[] iArr = this.j;
            if (i2 != iArr.length) {
                iArr[i2] = 0;
                i2++;
            } else {
                return;
            }
        }
    }

    public final void o(f fVar) {
        this.e = fVar.e;
        this.f = fVar.f;
        this.g = fVar.g;
        this.h = fVar.h;
        this.i = fVar.i;
        int[] iArr = this.j;
        int[] iArr2 = fVar.j;
        System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
        this.k = fVar.k;
    }
}
