package Ia;

import androidx.camera.camera2.internal.i1;
import org.bouncycastle.crypto.CryptoServicePurpose;

public final class j extends b {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j(int i) {
        super(i, CryptoServicePurpose.ANY);
        if (i == 224 || i == 256 || i == 384 || i == 512) {
            return;
        }
        throw new IllegalArgumentException(i1.a(i, "'bitLength' ", " not supported for SHA-3"));
    }

    public final int b(int i, byte[] bArr) {
        i(2, 2);
        m(i, (long) this.e, bArr);
        l();
        return g();
    }

    public final String f() {
        return "SHA3-" + this.e;
    }
}
