package Eb;

import Fa.a;
import Ha.f;
import Ia.g;
import Ia.h;
import Ia.i;
import Ia.k;
import la.C0390u;
import wa.C0468b;
import xa.C0474b;

public final class c {
    public static f a(a aVar) {
        if (aVar.a.l(C0474b.a)) {
            int i = Oa.a.a;
            return new Ia.f();
        }
        C0390u uVar = C0468b.d;
        C0390u uVar2 = aVar.a;
        if (uVar2.l(uVar)) {
            int i2 = Oa.a.a;
            return new g();
        } else if (uVar2.l(C0468b.a)) {
            int i3 = Oa.a.a;
            return new h();
        } else if (uVar2.l(C0468b.b)) {
            int i4 = Oa.a.a;
            return new i();
        } else if (uVar2.l(C0468b.c)) {
            int i5 = Oa.a.a;
            return new k();
        } else {
            throw new IllegalArgumentException("unrecognised OID in digest algorithm identifier: " + uVar2);
        }
    }
}
