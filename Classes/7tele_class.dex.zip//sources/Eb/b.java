package Eb;

import Bb.k;
import Sb.a;
import Sb.g;
import Sb.h;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactorySpi;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import jb.e;
import jb.f;
import la.C0328B;
import la.C0394y;
import org.bouncycastle.pqc.jcajce.provider.mceliece.BCMcEliecePrivateKey;
import org.bouncycastle.pqc.jcajce.provider.mceliece.BCMcEliecePublicKey;
import ya.C0485e;

public final class b extends KeyFactorySpi implements Ta.b {
    public final PrivateKey a(C0485e eVar) throws IOException {
        C0394y i = eVar.i();
        i.getClass();
        e h = e.h(i);
        return new BCMcEliecePrivateKey(new Ob.e(h.a, h.b, new Sb.b(h.c), new h(new Sb.b(h.c), h.d), new g(h.f), new g(h.g), new a(h.e)));
    }

    public final PublicKey b(Fa.g gVar) throws IOException {
        f fVar;
        C0394y i = gVar.i();
        if (i != null) {
            fVar = new f(C0328B.r(i));
        } else {
            fVar = null;
        }
        return new BCMcEliecePublicKey(new Ob.f(fVar.a, fVar.b, new a(fVar.c)));
    }

    public final PrivateKey engineGeneratePrivate(KeySpec keySpec) throws InvalidKeySpecException {
        if (keySpec instanceof PKCS8EncodedKeySpec) {
            try {
                C0485e h = C0485e.h(C0394y.m(((PKCS8EncodedKeySpec) keySpec).getEncoded()));
                try {
                    if (jb.g.b.l(h.b.a)) {
                        e h2 = e.h(h.i());
                        return new BCMcEliecePrivateKey(new Ob.e(h2.a, h2.b, new Sb.b(h2.c), new h(new Sb.b(h2.c), h2.d), new g(h2.f), new g(h2.g), new a(h2.e)));
                    }
                    throw new InvalidKeySpecException("Unable to recognise OID in McEliece private key");
                } catch (IOException unused) {
                    throw new InvalidKeySpecException("Unable to decode PKCS8EncodedKeySpec.");
                }
            } catch (IOException e) {
                throw new InvalidKeySpecException("Unable to decode PKCS8EncodedKeySpec: " + e);
            }
        } else {
            throw new InvalidKeySpecException("Unsupported key specification: " + keySpec.getClass() + ".");
        }
    }

    public final PublicKey engineGeneratePublic(KeySpec keySpec) throws InvalidKeySpecException {
        f fVar;
        if (keySpec instanceof X509EncodedKeySpec) {
            try {
                Fa.g h = Fa.g.h(C0394y.m(((X509EncodedKeySpec) keySpec).getEncoded()));
                try {
                    if (jb.g.b.l(h.a.a)) {
                        C0394y i = h.i();
                        if (i != null) {
                            fVar = new f(C0328B.r(i));
                        } else {
                            fVar = null;
                        }
                        return new BCMcEliecePublicKey(new Ob.f(fVar.a, fVar.b, new a(fVar.c)));
                    }
                    throw new InvalidKeySpecException("Unable to recognise OID in McEliece public key");
                } catch (IOException e) {
                    throw new InvalidKeySpecException(k.a(e, new StringBuilder("Unable to decode X509EncodedKeySpec: ")));
                }
            } catch (IOException e2) {
                throw new InvalidKeySpecException(e2.toString());
            }
        } else {
            throw new InvalidKeySpecException("Unsupported key specification: " + keySpec.getClass() + ".");
        }
    }

    public final KeySpec engineGetKeySpec(Key key, Class cls) throws InvalidKeySpecException {
        return null;
    }

    public final Key engineTranslateKey(Key key) throws InvalidKeyException {
        return null;
    }
}
