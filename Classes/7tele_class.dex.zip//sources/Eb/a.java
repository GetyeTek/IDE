package Eb;

import Bb.k;
import Sb.g;
import Sb.h;
import Ta.b;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactorySpi;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import jb.c;
import jb.d;
import la.C0394y;
import org.bouncycastle.pqc.jcajce.provider.mceliece.BCMcElieceCCA2PrivateKey;
import org.bouncycastle.pqc.jcajce.provider.mceliece.BCMcElieceCCA2PublicKey;
import ya.C0485e;

public final class a extends KeyFactorySpi implements b {
    public final PrivateKey a(C0485e eVar) throws IOException {
        C0394y i = eVar.i();
        i.getClass();
        c h = c.h(i);
        return new BCMcElieceCCA2PrivateKey(new Ob.b(h.a, h.b, new Sb.b(h.c), new h(new Sb.b(h.c), h.d), new g(h.e), (String) null));
    }

    public final PublicKey b(Fa.g gVar) throws IOException {
        d h = d.h(gVar.i());
        return new BCMcElieceCCA2PublicKey(new Ob.c(h.a, h.b, h.c, c.a(h.d).f()));
    }

    public final PrivateKey engineGeneratePrivate(KeySpec keySpec) throws InvalidKeySpecException {
        if (keySpec instanceof PKCS8EncodedKeySpec) {
            try {
                C0485e h = C0485e.h(C0394y.m(((PKCS8EncodedKeySpec) keySpec).getEncoded()));
                try {
                    if (jb.g.c.l(h.b.a)) {
                        c h2 = c.h(h.i());
                        return new BCMcElieceCCA2PrivateKey(new Ob.b(h2.a, h2.b, new Sb.b(h2.c), new h(new Sb.b(h2.c), h2.d), new g(h2.e), c.a(h2.f).f()));
                    }
                    throw new InvalidKeySpecException("Unable to recognise OID in McEliece public key");
                } catch (IOException unused) {
                    throw new InvalidKeySpecException("Unable to decode PKCS8EncodedKeySpec.");
                }
            } catch (IOException e) {
                throw new InvalidKeySpecException("Unable to decode PKCS8EncodedKeySpec: " + e);
            }
        } else {
            throw new InvalidKeySpecException("Unsupported key specification: " + keySpec.getClass() + ".");
        }
    }

    public final PublicKey engineGeneratePublic(KeySpec keySpec) throws InvalidKeySpecException {
        if (keySpec instanceof X509EncodedKeySpec) {
            try {
                Fa.g h = Fa.g.h(C0394y.m(((X509EncodedKeySpec) keySpec).getEncoded()));
                try {
                    if (jb.g.c.l(h.a.a)) {
                        d h2 = d.h(h.i());
                        return new BCMcElieceCCA2PublicKey(new Ob.c(h2.a, h2.b, h2.c, c.a(h2.d).f()));
                    }
                    throw new InvalidKeySpecException("Unable to recognise OID in McEliece private key");
                } catch (IOException e) {
                    throw new InvalidKeySpecException(k.a(e, new StringBuilder("Unable to decode X509EncodedKeySpec: ")));
                }
            } catch (IOException e2) {
                throw new InvalidKeySpecException(e2.toString());
            }
        } else {
            throw new InvalidKeySpecException("Unsupported key specification: " + keySpec.getClass() + ".");
        }
    }

    public final KeySpec engineGetKeySpec(Key key, Class cls) throws InvalidKeySpecException {
        return null;
    }

    public final Key engineTranslateKey(Key key) throws InvalidKeyException {
        return null;
    }
}
