package Na;

import La.C;
import Ma.b;

public final class a implements c {
    public byte[] a;
    public byte[] b;
    public long c;
    public b d;
    public Ka.a e;
    public int f;

    public final int a(byte[] bArr, boolean z) {
        int length = bArr.length * 8;
        if (length > 262144) {
            throw new IllegalArgumentException("Number of bits per request limited to 262144");
        } else if (this.c > 140737488355328L) {
            return -1;
        } else {
            if (z) {
                b((byte[]) null);
            }
            int length2 = bArr.length;
            byte[] bArr2 = new byte[length2];
            int length3 = bArr.length;
            byte[] bArr3 = this.b;
            int length4 = length3 / bArr3.length;
            C c2 = new C(this.a);
            Ka.a aVar = this.e;
            aVar.b(c2);
            for (int i = 0; i < length4; i++) {
                aVar.a.d(0, bArr3.length, bArr3);
                aVar.a(bArr3);
                System.arraycopy(bArr3, 0, bArr2, bArr3.length * i, bArr3.length);
            }
            if (bArr3.length * length4 < length2) {
                aVar.a.d(0, bArr3.length, bArr3);
                aVar.a(bArr3);
                System.arraycopy(bArr3, 0, bArr2, bArr3.length * length4, length2 - (length4 * bArr3.length));
            }
            c((byte[]) null, (byte) 0);
            this.c++;
            System.arraycopy(bArr2, 0, bArr, 0, bArr.length);
            return length;
        }
    }

    public final void b(byte[] bArr) {
        byte[] b2 = this.d.b();
        if (b2.length >= (this.f + 7) / 8) {
            byte[] c2 = org.bouncycastle.util.a.c(b2, bArr);
            c(c2, (byte) 0);
            if (c2 != null) {
                c(c2, (byte) 1);
            }
            this.c = 1;
            return;
        }
        throw new IllegalStateException("Insufficient entropy provided by entropy source");
    }

    public final void c(byte[] bArr, byte b2) {
        byte[] bArr2 = this.a;
        C c2 = new C(bArr2);
        Ka.a aVar = this.e;
        aVar.b(c2);
        byte[] bArr3 = this.b;
        aVar.a.d(0, bArr3.length, bArr3);
        aVar.a.c(b2);
        if (bArr != null) {
            aVar.a.d(0, bArr.length, bArr);
        }
        aVar.a(bArr2);
        aVar.b(new C(bArr2));
        aVar.a.d(0, bArr3.length, bArr3);
        aVar.a(bArr3);
    }
}
