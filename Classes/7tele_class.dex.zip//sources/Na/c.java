package Na;

public interface c {
    int a(byte[] bArr, boolean z);

    void b(byte[] bArr);
}
