package Na;

import Ia.k;
import java.util.Hashtable;

public final class d {
    public static final Hashtable a;

    static {
        Hashtable hashtable = new Hashtable();
        a = hashtable;
        hashtable.put("SHA-1", 128);
        hashtable.put("SHA-224", 192);
        hashtable.put("SHA-256", 256);
        hashtable.put("SHA-384", 256);
        hashtable.put("SHA-512", 256);
        hashtable.put("SHA-512/224", 192);
        hashtable.put("SHA-512/256", 256);
    }

    public static byte[] a(k kVar, byte[] bArr, int i) {
        int i2 = (i + 7) / 8;
        byte[] bArr2 = new byte[i2];
        kVar.getClass();
        int i3 = i2 / 64;
        byte[] bArr3 = new byte[64];
        int i4 = 1;
        int i5 = 0;
        for (int i6 = 0; i6 <= i3; i6++) {
            kVar.c((byte) i4);
            kVar.c((byte) (i >> 24));
            kVar.c((byte) (i >> 16));
            kVar.c((byte) (i >> 8));
            kVar.c((byte) i);
            kVar.d(0, bArr.length, bArr);
            kVar.b(0, bArr3);
            int i7 = i6 * 64;
            int i8 = i2 - i7;
            if (i8 > 64) {
                i8 = 64;
            }
            System.arraycopy(bArr3, 0, bArr2, i7, i8);
            i4++;
        }
        int i10 = i % 8;
        if (i10 != 0) {
            int i11 = 8 - i10;
            byte b = 0;
            while (i5 != i2) {
                byte b2 = bArr2[i5] & 255;
                bArr2[i5] = (byte) ((b << (8 - i11)) | (b2 >>> i11));
                i5++;
                b = b2;
            }
        }
        return bArr2;
    }
}
