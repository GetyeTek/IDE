package Na;

import Ia.k;
import java.util.Hashtable;
import org.bouncycastle.util.a;

public final class b implements c {
    public static final byte[] h = {1};
    public static final Hashtable i;
    public k a;
    public byte[] b;
    public byte[] c;
    public long d;
    public Ma.b e;
    public int f;
    public int g;

    static {
        Hashtable hashtable = new Hashtable();
        i = hashtable;
        hashtable.put("SHA-1", 440);
        hashtable.put("SHA-224", 440);
        hashtable.put("SHA-256", 440);
        hashtable.put("SHA-512/256", 440);
        hashtable.put("SHA-512/224", 440);
        hashtable.put("SHA-384", 888);
        hashtable.put("SHA-512", 888);
    }

    public static void c(byte[] bArr, byte[] bArr2) {
        byte b2;
        byte b3 = 0;
        for (int i2 = 1; i2 <= bArr2.length; i2++) {
            int i3 = (bArr[bArr.length - i2] & 255) + (bArr2[bArr2.length - i2] & 255) + b3;
            if (i3 > 255) {
                b3 = 1;
            } else {
                b3 = 0;
            }
            bArr[bArr.length - i2] = (byte) i3;
        }
        for (int length = bArr2.length + 1; length <= bArr.length; length++) {
            int i4 = (bArr[bArr.length - length] & 255) + b3;
            if (i4 > 255) {
                b2 = 1;
            } else {
                b2 = 0;
            }
            bArr[bArr.length - length] = (byte) i4;
        }
    }

    public final int a(byte[] bArr, boolean z) {
        byte[] bArr2 = bArr;
        int length = bArr2.length * 8;
        if (length > 262144) {
            throw new IllegalArgumentException("Number of bits per request limited to 262144");
        } else if (this.d > 140737488355328L) {
            return -1;
        } else {
            if (z) {
                b((byte[]) null);
            }
            byte[] bArr3 = this.b;
            this.a.getClass();
            int i2 = length / 8;
            int i3 = i2 / 64;
            int length2 = bArr3.length;
            byte[] bArr4 = new byte[length2];
            System.arraycopy(bArr3, 0, bArr4, 0, bArr3.length);
            byte[] bArr5 = new byte[i2];
            byte[] bArr6 = new byte[64];
            for (int i4 = 0; i4 <= i3; i4++) {
                k kVar = this.a;
                kVar.d(0, length2, bArr4);
                kVar.b(0, bArr6);
                int i5 = i4 * 64;
                int i6 = i2 - i5;
                if (i6 > 64) {
                    i6 = 64;
                }
                System.arraycopy(bArr6, 0, bArr5, i5, i6);
                c(bArr4, h);
            }
            byte[] bArr7 = this.b;
            int length3 = bArr7.length + 1;
            byte[] bArr8 = new byte[length3];
            System.arraycopy(bArr7, 0, bArr8, 1, bArr7.length);
            bArr8[0] = 3;
            this.a.getClass();
            byte[] bArr9 = new byte[64];
            k kVar2 = this.a;
            kVar2.d(0, length3, bArr8);
            kVar2.b(0, bArr9);
            c(this.b, bArr9);
            c(this.b, this.c);
            long j = this.d;
            c(this.b, new byte[]{(byte) ((int) (j >> 24)), (byte) ((int) (j >> 16)), (byte) ((int) (j >> 8)), (byte) ((int) j)});
            this.d++;
            System.arraycopy(bArr5, 0, bArr2, 0, bArr2.length);
            return length;
        }
    }

    public final void b(byte[] bArr) {
        byte[] b2 = this.e.b();
        if (b2.length >= (this.f + 7) / 8) {
            byte[] e2 = a.e(h, this.b, b2, bArr);
            k kVar = this.a;
            int i2 = this.g;
            byte[] a2 = d.a(kVar, e2, i2);
            this.b = a2;
            byte[] bArr2 = new byte[(a2.length + 1)];
            bArr2[0] = 0;
            System.arraycopy(a2, 0, bArr2, 1, a2.length);
            this.c = d.a(kVar, bArr2, i2);
            this.d = 1;
            return;
        }
        throw new IllegalStateException("Insufficient entropy provided by entropy source");
    }
}
