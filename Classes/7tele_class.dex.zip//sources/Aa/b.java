package Aa;

import Ga.f;
import java.math.BigInteger;
import la.C0328B;
import la.C0333G;
import la.C0356c;
import la.C0366h;
import la.C0382p;
import la.C0388s;
import la.C0391v;
import la.C0394y;
import la.s0;

public final class b extends C0388s {
    public C0328B a;

    public b(BigInteger bigInteger, C0356c cVar, f fVar) {
        BigInteger bigInteger2 = org.bouncycastle.util.b.a;
        byte[] byteArray = bigInteger.toByteArray();
        if (byteArray[0] == 0 && byteArray.length != 1) {
            int length = byteArray.length - 1;
            byte[] bArr = new byte[length];
            System.arraycopy(byteArray, 1, bArr, 0, length);
            byteArray = bArr;
        }
        C0366h hVar = new C0366h(4);
        hVar.a(new C0382p(1));
        hVar.a(new C0391v(byteArray));
        hVar.a(new C0333G(true, 0, fVar));
        if (cVar != null) {
            hVar.a(new C0333G(true, 1, cVar));
            hVar.a(new C0333G(true, 1, cVar));
        }
        this.a = new s0(hVar);
    }

    public final C0394y b() {
        return this.a;
    }
}
