package Aa;

import Ga.f;
import java.math.BigInteger;
import java.util.Enumeration;
import la.C0328B;
import la.C0333G;
import la.C0356c;
import la.C0364g;
import la.C0366h;
import la.C0382p;
import la.C0388s;
import la.C0391v;
import la.C0394y;
import la.s0;
import org.bouncycastle.util.b;

public final class a extends C0388s {
    public C0328B a;

    public a(int i, BigInteger bigInteger, C0356c cVar, f fVar) {
        byte[] a2 = b.a((i + 7) / 8, bigInteger);
        C0366h hVar = new C0366h(4);
        hVar.a(new C0382p(1));
        hVar.a(new C0391v(a2));
        hVar.a(new C0333G(true, 0, fVar));
        if (cVar != null) {
            hVar.a(new C0333G(true, 1, cVar));
        }
        this.a = new s0(hVar);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [la.s, Aa.a] */
    public static a h(C0394y yVar) {
        if (yVar == null) {
            return null;
        }
        C0328B r = C0328B.r(yVar);
        ? sVar = new C0388s();
        sVar.a = r;
        return sVar;
    }

    public final C0394y b() {
        return this.a;
    }

    public final BigInteger i() {
        return new BigInteger(1, ((C0391v) this.a.s(1)).a);
    }

    public final C0356c j() {
        C0394y yVar;
        Enumeration t = this.a.t();
        while (true) {
            if (!t.hasMoreElements()) {
                yVar = null;
                break;
            }
            C0364g gVar = (C0364g) t.nextElement();
            if (gVar instanceof C0333G) {
                C0333G g = (C0333G) gVar;
                if (g.t()) {
                    yVar = g.q(true, C0356c.b);
                    break;
                }
            }
        }
        return (C0356c) yVar;
    }
}
