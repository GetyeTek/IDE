package j9;

import android.content.res.Resources;
import android.graphics.PointF;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.webkit.WebView;
import android.widget.AbsListView;
import android.widget.ScrollView;
import androidx.annotation.NonNull;
import androidx.appcompat.graphics.drawable.a;
import androidx.core.view.NestedScrollingChild;
import androidx.core.view.NestedScrollingParent;
import androidx.core.view.ScrollingView;
import androidx.viewpager.widget.ViewPager;
import com.scwang.smart.refresh.layout.kernel.R$id;
import f9.C0249a;

/* renamed from: j9.b  reason: case insensitive filesystem */
public final class C0296b implements Interpolator {
    public static final float a = Resources.getSystem().getDisplayMetrics().density;
    public static final float b;
    public static final float c;

    static {
        float h = 1.0f / h(1.0f);
        b = h;
        c = 1.0f - (h(1.0f) * h);
    }

    public static boolean a(@NonNull View view, PointF pointF, boolean z) {
        if (view.canScrollVertically(1) && view.getVisibility() == 0) {
            return false;
        }
        if ((view instanceof ViewGroup) && pointF != null && !e(view)) {
            ViewGroup viewGroup = (ViewGroup) view;
            PointF pointF2 = new PointF();
            for (int childCount = viewGroup.getChildCount(); childCount > 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount - 1);
                if (f(viewGroup, childAt, pointF.x, pointF.y, pointF2)) {
                    Object tag = childAt.getTag(R$id.srl_tag);
                    if ("fixed".equals(tag) || "fixed-top".equals(tag)) {
                        return false;
                    }
                    pointF.offset(pointF2.x, pointF2.y);
                    boolean a2 = a(childAt, pointF, z);
                    pointF.offset(-pointF2.x, -pointF2.y);
                    return a2;
                }
            }
        }
        if (z || view.canScrollVertically(-1)) {
            return true;
        }
        return false;
    }

    public static boolean b(@NonNull View view, PointF pointF) {
        if (view.canScrollVertically(-1) && view.getVisibility() == 0) {
            return false;
        }
        if (!(view instanceof ViewGroup) || pointF == null) {
            return true;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        PointF pointF2 = new PointF();
        for (int childCount = viewGroup.getChildCount(); childCount > 0; childCount--) {
            View childAt = viewGroup.getChildAt(childCount - 1);
            if (f(viewGroup, childAt, pointF.x, pointF.y, pointF2)) {
                Object tag = childAt.getTag(R$id.srl_tag);
                if ("fixed".equals(tag) || "fixed-bottom".equals(tag)) {
                    return false;
                }
                pointF.offset(pointF2.x, pointF2.y);
                boolean b2 = b(childAt, pointF);
                pointF.offset(-pointF2.x, -pointF2.y);
                return b2;
            }
        }
        return true;
    }

    public static int c(float f) {
        return (int) ((f * a) + 0.5f);
    }

    public static boolean d(View view) {
        if (view instanceof C0249a) {
            return false;
        }
        if (e(view) || (view instanceof ViewPager) || (view instanceof NestedScrollingParent)) {
            return true;
        }
        return false;
    }

    public static boolean e(View view) {
        if (view instanceof C0249a) {
            return false;
        }
        if ((view instanceof AbsListView) || (view instanceof ScrollView) || (view instanceof ScrollingView) || (view instanceof WebView) || (view instanceof NestedScrollingChild)) {
            return true;
        }
        return false;
    }

    public static boolean f(@NonNull View view, @NonNull View view2, float f, float f2, PointF pointF) {
        boolean z;
        if (view2.getVisibility() != 0) {
            return false;
        }
        float[] fArr = {f, f2};
        fArr[0] = ((float) (view.getScrollX() - view2.getLeft())) + f;
        float scrollY = fArr[1] + ((float) (view.getScrollY() - view2.getTop()));
        fArr[1] = scrollY;
        float f3 = fArr[0];
        if (f3 < 0.0f || scrollY < 0.0f || f3 >= ((float) view2.getWidth()) || fArr[1] >= ((float) view2.getHeight())) {
            z = false;
        } else {
            z = true;
        }
        if (z) {
            pointF.set(fArr[0] - f, fArr[1] - f2);
        }
        return z;
    }

    public static int g(View view) {
        int i;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams = new ViewGroup.LayoutParams(-1, -2);
        }
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(0, 0, layoutParams.width);
        int i2 = layoutParams.height;
        if (i2 > 0) {
            i = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
        } else {
            i = View.MeasureSpec.makeMeasureSpec(0, 0);
        }
        view.measure(childMeasureSpec, i);
        return view.getMeasuredHeight();
    }

    public static float h(float f) {
        float f2 = f * 8.0f;
        if (f2 < 1.0f) {
            return f2 - (1.0f - ((float) Math.exp((double) (-f2))));
        }
        return a.a(1.0f, (float) Math.exp((double) (1.0f - f2)), 0.63212055f, 0.36787945f);
    }

    public final float getInterpolation(float f) {
        float h = h(f) * b;
        if (h > 0.0f) {
            return h + c;
        }
        return h;
    }
}
