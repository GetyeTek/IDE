package j9;

import com.google.android.material.appbar.AppBarLayout;
import k9.C0299a;

/* renamed from: j9.a  reason: case insensitive filesystem */
public final class C0295a implements AppBarLayout.OnOffsetChangedListener {
    public final /* synthetic */ C0299a a;

    public C0295a(C0299a aVar) {
        this.a = aVar;
    }

    public final void onOffsetChanged(AppBarLayout appBarLayout, int i) {
        boolean z;
        boolean z2 = false;
        if (i >= 0) {
            z = true;
        } else {
            z = false;
        }
        if (appBarLayout.getTotalScrollRange() + i <= 0) {
            z2 = true;
        }
        C0299a aVar = this.a;
        aVar.g = z;
        aVar.h = z2;
    }
}
