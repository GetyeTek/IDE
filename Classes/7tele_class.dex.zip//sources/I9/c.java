package I9;

import android.support.v4.media.b;
import java.io.Externalizable;
import java.io.InvalidObjectException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Map;
import kotlin.collections.builders.MapBuilder;
import kotlin.collections.t;
import kotlin.jvm.internal.h;

public final class c implements Externalizable {
    private static final long serialVersionUID = 0;
    public Map<?, ?> a = t.a;

    private final Object readResolve() {
        return this.a;
    }

    public final void readExternal(ObjectInput objectInput) {
        h.f(objectInput, "input");
        byte readByte = objectInput.readByte();
        if (readByte == 0) {
            int readInt = objectInput.readInt();
            if (readInt >= 0) {
                MapBuilder mapBuilder = new MapBuilder(readInt);
                for (int i = 0; i < readInt; i++) {
                    mapBuilder.put(objectInput.readObject(), objectInput.readObject());
                }
                this.a = mapBuilder.build();
                return;
            }
            throw new InvalidObjectException("Illegal size value: " + readInt + '.');
        }
        throw new InvalidObjectException(b.a(readByte, "Unsupported flags value: "));
    }

    public final void writeExternal(ObjectOutput objectOutput) {
        h.f(objectOutput, "output");
        objectOutput.writeByte(0);
        objectOutput.writeInt(this.a.size());
        for (Map.Entry next : this.a.entrySet()) {
            objectOutput.writeObject(next.getKey());
            objectOutput.writeObject(next.getValue());
        }
    }
}
