package I9;

import java.util.Map;
import java.util.Map.Entry;
import kotlin.collections.g;
import kotlin.jvm.internal.h;

public abstract class a<E extends Map.Entry<? extends K, ? extends V>, K, V> extends g<E> {
    public final boolean contains(Object obj) {
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        h.f(entry, "element");
        return ((kotlin.collections.builders.a) this).a.containsEntry$kotlin_stdlib(entry);
    }

    public final boolean remove(Object obj) {
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        h.f(entry, "element");
        return ((kotlin.collections.builders.a) this).a.removeEntry$kotlin_stdlib(entry);
    }
}
