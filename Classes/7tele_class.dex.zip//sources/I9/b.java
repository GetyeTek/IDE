package I9;

import java.util.List;
import kotlin.collections.e;
import kotlin.jvm.internal.h;

public final class b {
    public static final boolean a(Object[] objArr, int i, int i2, List list) {
        if (i2 != list.size()) {
            return false;
        }
        for (int i3 = 0; i3 < i2; i3++) {
            if (!h.a(objArr[i + i3], list.get(i3))) {
                return false;
            }
        }
        return true;
    }

    public static final String b(Object[] objArr, int i, int i2, e eVar) {
        StringBuilder sb2 = new StringBuilder((i2 * 3) + 2);
        sb2.append("[");
        for (int i3 = 0; i3 < i2; i3++) {
            if (i3 > 0) {
                sb2.append(", ");
            }
            e eVar2 = objArr[i + i3];
            if (eVar2 == eVar) {
                sb2.append("(this Collection)");
            } else {
                sb2.append(eVar2);
            }
        }
        sb2.append("]");
        String sb3 = sb2.toString();
        h.e(sb3, "toString(...)");
        return sb3;
    }

    public static int c(int i) {
        int i2 = -1;
        while (i != 0) {
            i2++;
            i >>>= 1;
        }
        return i2;
    }

    public static int d(int i, int i2, int i3) {
        int e = e(i, i3);
        int e2 = e(i2, i3);
        int i4 = 0;
        if (e2 != 0) {
            int c = 1 << c(i3);
            while (e != 0) {
                if (((byte) (e & 1)) == 1) {
                    i4 ^= e2;
                }
                e >>>= 1;
                e2 <<= 1;
                if (e2 >= c) {
                    e2 ^= i3;
                }
            }
        }
        return i4;
    }

    public static int e(int i, int i2) {
        if (i2 == 0) {
            System.err.println("Error: to be divided by 0");
            return 0;
        }
        while (c(i) >= c(i2)) {
            i ^= i2 << (c(i) - c(i2));
        }
        return i;
    }

    public static final void f(int i, int i2, Object[] objArr) {
        h.f(objArr, "<this>");
        while (i < i2) {
            objArr[i] = null;
            i++;
        }
    }
}
