package Fa;

import java.math.BigInteger;
import java.util.Enumeration;
import la.C0328B;
import la.C0366h;
import la.C0382p;
import la.C0388s;
import la.C0394y;
import la.s0;

public final class d extends C0388s {
    public C0382p a;
    public C0382p b;
    public C0382p c;

    public d(BigInteger bigInteger, BigInteger bigInteger2, BigInteger bigInteger3) {
        this.a = new C0382p(bigInteger);
        this.b = new C0382p(bigInteger2);
        this.c = new C0382p(bigInteger3);
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [Fa.d, la.s] */
    public static d h(Object obj) {
        if (obj instanceof d) {
            return (d) obj;
        }
        if (obj == null) {
            return null;
        }
        C0328B r = C0328B.r(obj);
        ? sVar = new C0388s();
        if (r.size() == 3) {
            Enumeration t = r.t();
            sVar.a = C0382p.p(t.nextElement());
            sVar.b = C0382p.p(t.nextElement());
            sVar.c = C0382p.p(t.nextElement());
            return sVar;
        }
        throw new IllegalArgumentException("Bad sequence size: " + r.size());
    }

    public final C0394y b() {
        C0366h hVar = new C0366h(3);
        hVar.a(this.a);
        hVar.a(this.b);
        hVar.a(this.c);
        return new s0(hVar);
    }
}
