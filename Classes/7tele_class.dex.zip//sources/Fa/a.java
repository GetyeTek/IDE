package Fa;

import la.C0328B;
import la.C0364g;
import la.C0366h;
import la.C0388s;
import la.C0390u;
import la.C0394y;
import la.s0;

public final class a extends C0388s {
    public C0390u a;
    public C0364g b;

    public a(C0390u uVar) {
        this.a = uVar;
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [la.s, Fa.a] */
    public static a h(Object obj) {
        if (obj instanceof a) {
            return (a) obj;
        }
        if (obj == null) {
            return null;
        }
        C0328B r = C0328B.r(obj);
        ? sVar = new C0388s();
        if (r.size() < 1 || r.size() > 2) {
            throw new IllegalArgumentException("Bad sequence size: " + r.size());
        }
        sVar.a = C0390u.t(r.s(0));
        if (r.size() == 2) {
            sVar.b = r.s(1);
        } else {
            sVar.b = null;
        }
        return sVar;
    }

    public final C0394y b() {
        C0366h hVar = new C0366h(2);
        hVar.a(this.a);
        C0364g gVar = this.b;
        if (gVar != null) {
            hVar.a(gVar);
        }
        return new s0(hVar);
    }

    public a(C0390u uVar, C0364g gVar) {
        this.a = uVar;
        this.b = gVar;
    }
}
