package Fa;

import la.C0390u;
import na.C0410a;
import ya.C0483c;

public interface j {
    public static final C0390u a = new C0390u("2.5.4.20").u();
    public static final C0390u b = C0483c.a("2.5.4.41");
    public static final C0390u c = C0483c.a("2.5.4.97");

    static {
        new C0390u("2.5.4.3").u();
        new C0390u("2.5.4.6").u();
        new C0390u("2.5.4.7").u();
        new C0390u("2.5.4.8").u();
        new C0390u("2.5.4.10").u();
        new C0390u("2.5.4.11").u();
        new C0390u("1.3.14.3.2.26").u();
        new C0390u("1.3.36.3.2.1").u();
        new C0390u("1.3.36.3.3.1.2").u();
        new C0390u("2.5.8.1.1").u();
        C0390u uVar = new C0390u("1.3.6.1.5.5.7");
        C0410a.a(uVar, "6.30", "6.31", "6.32", "6.33");
        uVar.p("1");
        new C0390u("2.5.29");
        C0390u uVar2 = new C0390u("48", uVar);
        new C0390u("2", uVar2).u();
        new C0390u("1", uVar2).u();
        new C0390u("1.2.840.113533.7.66.13");
    }
}
