package Fa;

import Ub.c;
import Ub.d;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import la.C0328B;
import la.C0329C;
import la.C0331E;
import la.C0336J;
import la.C0364g;
import la.C0366h;
import la.C0388s;
import la.C0390u;
import la.C0394y;
import la.s0;
import la.t0;
import org.bouncycastle.util.g;
import ya.C0484d;

public class i extends C0388s {
    public static final Hashtable g;
    public static final Boolean h = new Boolean(true);
    public static final Boolean i = new Boolean(false);
    public final Vector a = new Vector();
    public final Vector b = new Vector();
    public final Vector c = new Vector();
    public C0328B d;
    public boolean e;
    public int f;

    static {
        C0390u uVar = new C0390u("2.5.4.6");
        C0390u uVar2 = new C0390u("2.5.4.10");
        C0390u uVar3 = new C0390u("2.5.4.11");
        C0390u uVar4 = new C0390u("2.5.4.12");
        C0390u uVar5 = new C0390u("2.5.4.3");
        C0390u uVar6 = new C0390u("2.5.4.5");
        C0390u uVar7 = new C0390u("2.5.4.9");
        C0390u uVar8 = new C0390u("2.5.4.7");
        C0390u uVar9 = new C0390u("2.5.4.8");
        C0390u uVar10 = new C0390u("2.5.4.4");
        C0390u uVar11 = new C0390u("2.5.4.42");
        C0390u uVar12 = new C0390u("2.5.4.43");
        C0390u uVar13 = new C0390u("2.5.4.44");
        C0390u uVar14 = new C0390u("2.5.4.45");
        C0390u uVar15 = new C0390u("2.5.4.15");
        C0390u uVar16 = new C0390u("2.5.4.17");
        C0390u uVar17 = new C0390u("2.5.4.46");
        C0390u uVar18 = new C0390u("2.5.4.65");
        C0390u uVar19 = new C0390u("1.3.6.1.5.5.7.9.1");
        C0390u uVar20 = new C0390u("1.3.6.1.5.5.7.9.2");
        C0390u uVar21 = new C0390u("1.3.6.1.5.5.7.9.3");
        C0390u uVar22 = new C0390u("1.3.6.1.5.5.7.9.4");
        C0390u uVar23 = new C0390u("1.3.6.1.5.5.7.9.5");
        C0390u uVar24 = new C0390u("1.3.36.8.3.14");
        C0390u uVar25 = new C0390u("2.5.4.16");
        new C0390u("2.5.4.54");
        C0390u uVar26 = j.a;
        C0390u uVar27 = j.b;
        C0390u uVar28 = C0484d.x0;
        C0390u uVar29 = uVar26;
        C0390u uVar30 = uVar14;
        C0390u uVar31 = C0484d.y0;
        C0390u uVar32 = C0484d.z0;
        C0390u uVar33 = new C0390u("0.9.2342.19200300.100.1.25");
        C0390u uVar34 = uVar13;
        C0390u uVar35 = new C0390u("0.9.2342.19200300.100.1.1");
        Hashtable hashtable = new Hashtable();
        g = hashtable;
        C0390u uVar36 = uVar12;
        Hashtable hashtable2 = new Hashtable();
        Hashtable hashtable3 = new Hashtable();
        Hashtable hashtable4 = new Hashtable();
        C0390u uVar37 = uVar11;
        hashtable.put(uVar, "C");
        hashtable.put(uVar2, "O");
        hashtable.put(uVar4, "T");
        hashtable.put(uVar3, "OU");
        C0390u uVar38 = uVar4;
        hashtable.put(uVar5, "CN");
        hashtable.put(uVar8, "L");
        Object obj = "L";
        hashtable.put(uVar9, "ST");
        hashtable.put(uVar6, "SERIALNUMBER");
        hashtable.put(uVar28, "E");
        hashtable.put(uVar33, "DC");
        hashtable.put(uVar35, "UID");
        C0390u uVar39 = uVar6;
        hashtable.put(uVar7, "STREET");
        C0390u uVar40 = uVar35;
        hashtable.put(uVar10, "SURNAME");
        C0390u uVar41 = uVar10;
        hashtable.put(uVar37, "GIVENNAME");
        hashtable.put(uVar36, "INITIALS");
        hashtable.put(uVar34, "GENERATION");
        hashtable.put(uVar32, "unstructuredAddress");
        hashtable.put(uVar31, "unstructuredName");
        hashtable.put(uVar30, "UniqueIdentifier");
        hashtable.put(uVar17, "DN");
        hashtable.put(uVar18, "Pseudonym");
        hashtable.put(uVar25, "PostalAddress");
        hashtable.put(uVar24, "NameAtBirth");
        hashtable.put(uVar22, "CountryOfCitizenship");
        hashtable.put(uVar23, "CountryOfResidence");
        hashtable.put(uVar21, "Gender");
        hashtable.put(uVar20, "PlaceOfBirth");
        hashtable.put(uVar19, "DateOfBirth");
        hashtable.put(uVar16, "PostalCode");
        hashtable.put(uVar15, "BusinessCategory");
        hashtable.put(uVar29, "TelephoneNumber");
        hashtable.put(uVar27, "Name");
        Hashtable hashtable5 = hashtable2;
        hashtable5.put(uVar, "C");
        C0390u uVar42 = uVar2;
        hashtable5.put(uVar42, "O");
        hashtable5.put(uVar3, "OU");
        Object obj2 = "CN";
        hashtable5.put(uVar5, obj2);
        C0390u uVar43 = uVar5;
        hashtable5.put(uVar8, obj);
        Object obj3 = "ST";
        hashtable5.put(uVar9, obj3);
        hashtable5.put(uVar7, "STREET");
        hashtable5.put(uVar33, "DC");
        C0390u uVar44 = uVar40;
        hashtable5.put(uVar44, "UID");
        Hashtable hashtable6 = hashtable3;
        hashtable6.put(uVar, "C");
        hashtable6.put(uVar42, "O");
        hashtable6.put(uVar3, "OU");
        C0390u uVar45 = uVar43;
        hashtable6.put(uVar45, obj2);
        hashtable6.put(uVar8, obj);
        hashtable6.put(uVar9, obj3);
        hashtable6.put(uVar7, "STREET");
        Hashtable hashtable7 = hashtable4;
        hashtable7.put("c", uVar);
        hashtable7.put("o", uVar42);
        hashtable7.put("t", uVar38);
        hashtable7.put("ou", uVar3);
        hashtable7.put("cn", uVar45);
        hashtable7.put("l", uVar8);
        hashtable7.put("st", uVar9);
        C0390u uVar46 = uVar39;
        hashtable7.put("sn", uVar46);
        hashtable7.put("serialnumber", uVar46);
        hashtable7.put("street", uVar7);
        C0390u uVar47 = uVar28;
        hashtable7.put("emailaddress", uVar47);
        hashtable7.put("dc", uVar33);
        hashtable7.put("e", uVar47);
        hashtable7.put("uid", uVar44);
        hashtable7.put("surname", uVar41);
        hashtable7.put("givenname", uVar37);
        hashtable7.put("initials", uVar36);
        hashtable7.put("generation", uVar34);
        hashtable7.put("unstructuredaddress", uVar32);
        hashtable7.put("unstructuredname", uVar31);
        hashtable7.put("uniqueidentifier", uVar30);
        hashtable7.put("dn", uVar17);
        hashtable7.put("pseudonym", uVar18);
        hashtable7.put("postaladdress", uVar25);
        hashtable7.put("nameofbirth", uVar24);
        hashtable7.put("countryofcitizenship", uVar22);
        hashtable7.put("countryofresidence", uVar23);
        hashtable7.put("gender", uVar21);
        hashtable7.put("placeofbirth", uVar20);
        hashtable7.put("dateofbirth", uVar19);
        hashtable7.put("postalcode", uVar16);
        hashtable7.put("businesscategory", uVar15);
        hashtable7.put("telephonenumber", uVar29);
        hashtable7.put("name", uVar27);
    }

    public i() {
    }

    public static void h(StringBuffer stringBuffer, Hashtable hashtable, C0390u uVar, String str) {
        int i2;
        String str2 = (String) hashtable.get(uVar);
        if (str2 != null) {
            stringBuffer.append(str2);
        } else {
            stringBuffer.append(uVar.a);
        }
        stringBuffer.append('=');
        int length = stringBuffer.length();
        stringBuffer.append(str);
        int length2 = stringBuffer.length();
        if (str.length() >= 2 && str.charAt(0) == '\\' && str.charAt(1) == '#') {
            length += 2;
        }
        while (i2 < length2 && stringBuffer.charAt(i2) == ' ') {
            stringBuffer.insert(i2, "\\");
            length = i2 + 2;
            length2++;
        }
        while (true) {
            length2--;
            if (length2 > i2 && stringBuffer.charAt(length2) == ' ') {
                stringBuffer.insert(length2, '\\');
            }
        }
        while (i2 <= length2) {
            char charAt = stringBuffer.charAt(i2);
            if (!(charAt == '\"' || charAt == '\\' || charAt == '+' || charAt == ',')) {
                switch (charAt) {
                    case ';':
                    case '<':
                    case '=':
                    case '>':
                        break;
                    default:
                        i2++;
                        continue;
                }
            }
            stringBuffer.insert(i2, "\\");
            i2 += 2;
            length2++;
        }
    }

    public static String i(String str) {
        String c2 = g.c(str.trim());
        if (c2.length() <= 0 || c2.charAt(0) != '#') {
            return c2;
        }
        try {
            C0394y m = C0394y.m(c.b(c2.length() - 1, c2));
            if (m instanceof C0331E) {
                return g.c(((C0331E) m).c().trim());
            }
            return c2;
        } catch (IOException e2) {
            throw new IllegalStateException("unknown encoding in name: " + e2);
        }
    }

    public static String j(String str) {
        StringBuffer stringBuffer = new StringBuffer();
        if (str.length() != 0) {
            char charAt = str.charAt(0);
            stringBuffer.append(charAt);
            int i2 = 1;
            while (i2 < str.length()) {
                char charAt2 = str.charAt(i2);
                if (charAt != ' ' || charAt2 != ' ') {
                    stringBuffer.append(charAt2);
                }
                i2++;
                charAt = charAt2;
            }
        }
        return stringBuffer.toString();
    }

    public final C0394y b() {
        if (this.d == null) {
            C0366h hVar = new C0366h();
            C0366h hVar2 = new C0366h();
            Vector vector = this.a;
            if (vector.size() == 0) {
                hVar.a(new t0(hVar2));
                this.d = new s0(hVar);
            } else {
                C0364g[] gVarArr = new C0364g[2];
                C0390u uVar = (C0390u) vector.elementAt(0);
                if (uVar != null) {
                    boolean z = true;
                    int i2 = 0 + 1;
                    if (i2 <= gVarArr.length) {
                        z = false;
                    }
                    if (z || false) {
                        C0364g[] gVarArr2 = new C0364g[Math.max(gVarArr.length, i2 + (i2 >> 1))];
                        System.arraycopy(gVarArr, 0, gVarArr2, 0, 0);
                        gVarArr = gVarArr2;
                    }
                    gVarArr[0] = uVar;
                    String str = (String) this.b.elementAt(0);
                    throw null;
                }
                throw new NullPointerException("'element' cannot be null");
            }
        }
        return this.d;
    }

    /* JADX WARNING: type inference failed for: r18v0, types: [java.lang.Object] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(java.lang.Object r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = 1
            if (r1 != r0) goto L_0x0008
            return r2
        L_0x0008:
            boolean r3 = r1 instanceof Fa.i
            r4 = 0
            if (r3 != 0) goto L_0x0012
            boolean r3 = r1 instanceof la.C0328B
            if (r3 != 0) goto L_0x0012
            return r4
        L_0x0012:
            r3 = r1
            la.g r3 = (la.C0364g) r3
            la.y r3 = r3.b()
            la.y r5 = r17.b()
            boolean r3 = r5.l(r3)
            if (r3 == 0) goto L_0x0024
            return r2
        L_0x0024:
            boolean r3 = r1 instanceof Fa.i     // Catch:{ IllegalArgumentException -> 0x00c6 }
            if (r3 == 0) goto L_0x002b
            Fa.i r1 = (Fa.i) r1     // Catch:{ IllegalArgumentException -> 0x00c6 }
            goto L_0x004b
        L_0x002b:
            boolean r3 = r1 instanceof Da.c     // Catch:{ IllegalArgumentException -> 0x00c6 }
            if (r3 == 0) goto L_0x003e
            Fa.i r3 = new Fa.i     // Catch:{ IllegalArgumentException -> 0x00c6 }
            Da.c r1 = (Da.c) r1     // Catch:{ IllegalArgumentException -> 0x00c6 }
            la.s0 r1 = r1.e     // Catch:{ IllegalArgumentException -> 0x00c6 }
            la.B r1 = la.C0328B.r(r1)     // Catch:{ IllegalArgumentException -> 0x00c6 }
            r3.<init>(r1)     // Catch:{ IllegalArgumentException -> 0x00c6 }
        L_0x003c:
            r1 = r3
            goto L_0x004b
        L_0x003e:
            if (r1 == 0) goto L_0x004a
            Fa.i r3 = new Fa.i     // Catch:{ IllegalArgumentException -> 0x00c6 }
            la.B r1 = la.C0328B.r(r18)     // Catch:{ IllegalArgumentException -> 0x00c6 }
            r3.<init>(r1)     // Catch:{ IllegalArgumentException -> 0x00c6 }
            goto L_0x003c
        L_0x004a:
            r1 = 0
        L_0x004b:
            java.util.Vector r3 = r0.a
            int r5 = r3.size()
            java.util.Vector r6 = r1.a
            int r6 = r6.size()
            if (r5 == r6) goto L_0x005a
            return r4
        L_0x005a:
            boolean[] r6 = new boolean[r5]
            java.lang.Object r7 = r3.elementAt(r4)
            java.util.Vector r8 = r1.a
            java.lang.Object r9 = r8.elementAt(r4)
            boolean r7 = r7.equals(r9)
            if (r7 == 0) goto L_0x0070
            r9 = r5
            r7 = 0
            r10 = 1
            goto L_0x0074
        L_0x0070:
            int r7 = r5 + -1
            r9 = -1
            r10 = -1
        L_0x0074:
            if (r7 == r9) goto L_0x00c5
            java.lang.Object r11 = r3.elementAt(r7)
            la.u r11 = (la.C0390u) r11
            java.util.Vector r12 = r0.b
            java.lang.Object r12 = r12.elementAt(r7)
            java.lang.String r12 = (java.lang.String) r12
            r13 = 0
        L_0x0085:
            if (r13 >= r5) goto L_0x00c4
            boolean r14 = r6[r13]
            if (r14 == 0) goto L_0x008c
            goto L_0x00c1
        L_0x008c:
            java.lang.Object r14 = r8.elementAt(r13)
            la.u r14 = (la.C0390u) r14
            boolean r14 = r11.l(r14)
            if (r14 == 0) goto L_0x00c1
            java.util.Vector r14 = r1.b
            java.lang.Object r14 = r14.elementAt(r13)
            java.lang.String r14 = (java.lang.String) r14
            java.lang.String r15 = i(r12)
            java.lang.String r14 = i(r14)
            boolean r16 = r15.equals(r14)
            if (r16 != 0) goto L_0x00bd
            java.lang.String r15 = j(r15)
            java.lang.String r14 = j(r14)
            boolean r14 = r15.equals(r14)
            if (r14 != 0) goto L_0x00bd
            goto L_0x00c1
        L_0x00bd:
            r6[r13] = r2
            int r7 = r7 + r10
            goto L_0x0074
        L_0x00c1:
            int r13 = r13 + 1
            goto L_0x0085
        L_0x00c4:
            return r4
        L_0x00c5:
            return r2
        L_0x00c6:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: Fa.i.equals(java.lang.Object):boolean");
    }

    public final int hashCode() {
        if (this.e) {
            return this.f;
        }
        this.e = true;
        int i2 = 0;
        while (true) {
            Vector vector = this.a;
            if (i2 == vector.size()) {
                return this.f;
            }
            String j = j(i((String) this.b.elementAt(i2)));
            int hashCode = vector.elementAt(i2).hashCode() ^ this.f;
            this.f = hashCode;
            this.f = hashCode ^ j.hashCode();
            i2++;
        }
    }

    public final String toString() {
        Hashtable hashtable = g;
        StringBuffer stringBuffer = new StringBuffer();
        Vector vector = new Vector();
        StringBuffer stringBuffer2 = null;
        int i2 = 0;
        while (true) {
            Vector vector2 = this.a;
            if (i2 >= vector2.size()) {
                break;
            }
            boolean booleanValue = ((Boolean) this.c.elementAt(i2)).booleanValue();
            Vector vector3 = this.b;
            if (booleanValue) {
                stringBuffer2.append('+');
                h(stringBuffer2, hashtable, (C0390u) vector2.elementAt(i2), (String) vector3.elementAt(i2));
            } else {
                stringBuffer2 = new StringBuffer();
                h(stringBuffer2, hashtable, (C0390u) vector2.elementAt(i2), (String) vector3.elementAt(i2));
                vector.addElement(stringBuffer2);
            }
            i2++;
        }
        boolean z = true;
        for (int i3 = 0; i3 < vector.size(); i3++) {
            if (z) {
                z = false;
            } else {
                stringBuffer.append(',');
            }
            stringBuffer.append(vector.elementAt(i3).toString());
        }
        return stringBuffer.toString();
    }

    public i(C0328B b2) {
        Vector vector;
        this.d = b2;
        Enumeration t = b2.t();
        while (t.hasMoreElements()) {
            C0329C q = C0329C.q(((C0364g) t.nextElement()).b());
            int i2 = 0;
            while (true) {
                C0364g[] gVarArr = q.a;
                if (i2 < gVarArr.length) {
                    C0328B r = C0328B.r(gVarArr[i2].b());
                    if (r.size() == 2) {
                        this.a.addElement(C0390u.t(r.s(0)));
                        C0364g s = r.s(1);
                        if (!(s instanceof C0331E) || (s instanceof C0336J)) {
                            try {
                                Vector vector2 = this.b;
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append("#");
                                byte[] g2 = s.b().g();
                                d dVar = c.a;
                                byte[] d2 = c.d(0, g2.length, g2);
                                int length = d2.length;
                                char[] cArr = new char[length];
                                for (int i3 = 0; i3 != length; i3++) {
                                    cArr[i3] = (char) (d2[i3] & 255);
                                }
                                sb2.append(new String(cArr));
                                vector2.addElement(sb2.toString());
                            } catch (IOException unused) {
                                throw new IllegalArgumentException("cannot encode value");
                            }
                        } else {
                            String c2 = ((C0331E) s).c();
                            if (c2.length() <= 0 || c2.charAt(0) != '#') {
                                vector = this.b;
                            } else {
                                vector = this.b;
                                c2 = "\\".concat(c2);
                            }
                            vector.addElement(c2);
                        }
                        this.c.addElement(i2 != 0 ? h : i);
                        i2++;
                    } else {
                        throw new IllegalArgumentException("badly sized pair");
                    }
                }
            }
        }
    }
}
