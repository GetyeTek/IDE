package Fa;

import la.C0388s;

public final class c extends C0388s {
}
