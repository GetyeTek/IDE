package Fa;

import Bb.k;
import java.io.IOException;
import la.C0328B;
import la.C0360e;
import la.C0364g;
import la.C0366h;
import la.C0382p;
import la.C0388s;
import la.C0394y;
import la.s0;

public final class b extends C0388s {
    public C0360e a;
    public C0382p b;

    /* JADX WARNING: type inference failed for: r1v0, types: [la.s, Fa.b] */
    public static b h(C0394y yVar) {
        C0360e eVar;
        if (yVar == null) {
            return null;
        }
        C0328B r = C0328B.r(yVar);
        ? sVar = new C0388s();
        sVar.a = C0360e.c;
        sVar.b = null;
        if (r.size() == 0) {
            sVar.a = null;
            sVar.b = null;
        } else {
            if (r.s(0) instanceof C0360e) {
                C0364g s = r.s(0);
                if (s == null || (s instanceof C0360e)) {
                    eVar = (C0360e) s;
                } else if (s instanceof byte[]) {
                    try {
                        eVar = (C0360e) C0360e.b.b((byte[]) s);
                    } catch (IOException e) {
                        throw new IllegalArgumentException(k.a(e, new StringBuilder("failed to construct boolean from byte[]: ")));
                    }
                } else {
                    throw new IllegalArgumentException("illegal object in getInstance: ".concat(s.getClass().getName()));
                }
                sVar.a = eVar;
            } else {
                sVar.a = null;
                sVar.b = C0382p.p(r.s(0));
            }
            if (r.size() > 1) {
                if (sVar.a != null) {
                    sVar.b = C0382p.p(r.s(1));
                } else {
                    throw new IllegalArgumentException("wrong sequence in constructor");
                }
            }
        }
        return sVar;
    }

    public final C0394y b() {
        C0366h hVar = new C0366h(2);
        C0360e eVar = this.a;
        if (eVar != null) {
            hVar.a(eVar);
        }
        C0382p pVar = this.b;
        if (pVar != null) {
            hVar.a(pVar);
        }
        return new s0(hVar);
    }

    public final String toString() {
        C0382p pVar = this.b;
        boolean z = false;
        if (pVar == null) {
            StringBuilder sb2 = new StringBuilder("BasicConstraints: isCa(");
            C0360e eVar = this.a;
            if (eVar != null && eVar.q()) {
                z = true;
            }
            sb2.append(z);
            sb2.append(")");
            return sb2.toString();
        }
        StringBuilder sb3 = new StringBuilder("BasicConstraints: isCa(");
        C0360e eVar2 = this.a;
        if (eVar2 != null && eVar2.q()) {
            z = true;
        }
        sb3.append(z);
        sb3.append("), pathLenConstraint = ");
        sb3.append(pVar.r());
        return sb3.toString();
    }
}
