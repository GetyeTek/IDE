package Fa;

import Da.c;
import Ea.a;
import android.support.v4.media.b;
import java.io.IOException;
import la.C0328B;
import la.C0333G;
import la.C0362f;
import la.C0378n;
import la.C0388s;
import la.C0390u;
import la.C0391v;
import la.C0394y;
import org.bouncycastle.util.g;

public final class f extends C0388s implements C0362f {
    public final C0388s a;
    public final int b;

    public f(int i, C0388s sVar) {
        this.a = sVar;
        this.b = i;
    }

    public static f h(Object obj) {
        c cVar;
        C0390u uVar;
        if (obj == null || (obj instanceof f)) {
            return (f) obj;
        }
        if (obj instanceof C0333G) {
            C0333G g = (C0333G) obj;
            C0328B.a aVar = C0328B.b;
            int i = g.c;
            switch (i) {
                case 0:
                case 3:
                case 5:
                    return new f(i, (C0328B) aVar.e(g, false));
                case 1:
                case 2:
                case 6:
                    return new f(i, (C0378n) C0378n.b.e(g, false));
                case 4:
                    a aVar2 = c.f;
                    C0328B b2 = (C0328B) aVar.e(g, true);
                    if (b2 != null) {
                        cVar = new c(C0328B.r(b2));
                    } else {
                        cVar = null;
                    }
                    return new f(i, cVar);
                case 7:
                    return new f(i, (C0391v) C0391v.b.e(g, false));
                case 8:
                    C0390u.a aVar3 = C0390u.c;
                    int i2 = g.a;
                    if (!(i2 == 3 || i2 == 4)) {
                        C0394y s = g.s();
                        if (!(s instanceof C0390u)) {
                            uVar = C0390u.q(C0391v.p(s).a, true);
                            return new f(i, uVar);
                        }
                    }
                    uVar = (C0390u) C0390u.c.e(g, false);
                    return new f(i, uVar);
                default:
                    throw new IllegalArgumentException(b.a(i, "unknown tag: "));
            }
        } else if (obj instanceof byte[]) {
            try {
                return h(C0394y.m((byte[]) obj));
            } catch (IOException unused) {
                throw new IllegalArgumentException("unable to parse encoded general name");
            }
        } else {
            throw new IllegalArgumentException("unknown object in getInstance: ".concat(obj.getClass().getName()));
        }
    }

    public final C0394y b() {
        boolean z;
        int i = this.b;
        if (i == 4) {
            z = true;
        } else {
            z = false;
        }
        return new C0333G(z, i, this.a);
    }

    public final String toString() {
        C0378n nVar;
        String a2;
        c cVar;
        StringBuffer stringBuffer = new StringBuffer();
        int i = this.b;
        stringBuffer.append(i);
        stringBuffer.append(": ");
        C0388s sVar = this.a;
        if (!(i == 1 || i == 2)) {
            if (i == 4) {
                a aVar = c.f;
                if (sVar instanceof c) {
                    cVar = (c) sVar;
                } else if (sVar != null) {
                    cVar = new c(C0328B.r(sVar));
                } else {
                    cVar = null;
                }
                a2 = cVar.c.W1(cVar);
                stringBuffer.append(a2);
                return stringBuffer.toString();
            } else if (i != 6) {
                stringBuffer.append(sVar.toString());
                return stringBuffer.toString();
            }
        }
        if (sVar == null || (sVar instanceof C0378n)) {
            nVar = (C0378n) sVar;
        } else {
            C0394y b2 = sVar.b();
            if (b2 instanceof C0378n) {
                nVar = (C0378n) b2;
            } else if (sVar instanceof byte[]) {
                try {
                    C0394y m = C0394y.m((byte[]) sVar);
                    if (C0378n.class.isInstance(m)) {
                        nVar = (C0378n) m;
                    } else {
                        throw new IllegalStateException("unexpected object: ".concat(m.getClass().getName()));
                    }
                } catch (Exception e) {
                    throw new IllegalArgumentException("encoding error in getInstance: " + e.toString());
                }
            } else {
                throw new IllegalArgumentException("illegal object in getInstance: ".concat(sVar.getClass().getName()));
            }
        }
        a2 = g.a(nVar.a);
        stringBuffer.append(a2);
        return stringBuffer.toString();
    }
}
