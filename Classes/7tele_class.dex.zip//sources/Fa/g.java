package Fa;

import java.io.IOException;
import java.util.Enumeration;
import la.C0328B;
import la.C0356c;
import la.C0363f0;
import la.C0366h;
import la.C0388s;
import la.C0394y;
import la.s0;

public final class g extends C0388s {
    public a a;
    public C0363f0 b;

    /* JADX WARNING: type inference failed for: r0v0, types: [la.c, la.f0] */
    public g(a aVar, C0388s sVar) throws IOException {
        this.b = new C0356c(0, sVar.b().g());
        this.a = aVar;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [Fa.g, la.s] */
    public static g h(Object obj) {
        if (obj instanceof g) {
            return (g) obj;
        }
        if (obj == null) {
            return null;
        }
        C0328B r = C0328B.r(obj);
        ? sVar = new C0388s();
        if (r.size() == 2) {
            Enumeration t = r.t();
            sVar.a = a.h(t.nextElement());
            sVar.b = C0363f0.t(t.nextElement());
            return sVar;
        }
        throw new IllegalArgumentException("Bad sequence size: " + r.size());
    }

    public final C0394y b() {
        C0366h hVar = new C0366h(2);
        hVar.a(this.a);
        hVar.a(this.b);
        return new s0(hVar);
    }

    public final C0394y i() throws IOException {
        return C0394y.m(this.b.s());
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [la.c, la.f0] */
    public g(a aVar, byte[] bArr) {
        this.b = new C0356c(0, bArr);
        this.a = aVar;
    }
}
