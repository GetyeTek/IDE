package ha;

/* renamed from: ha.g  reason: case insensitive filesystem */
public final class C0287g {
    public final int a;

    public C0287g(int i) {
        this.a = i;
    }
}
