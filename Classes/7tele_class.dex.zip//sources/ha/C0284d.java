package ha;

import Ca.e;

/* renamed from: ha.d  reason: case insensitive filesystem */
public final class C0284d extends e {
    public static final C0284d a = new Object();
}
