package ha;

import D3.f;
import ca.C0135x;
import kotlin.coroutines.d;

public final class j extends C0135x {
    public static final j a = new C0135x();

    public final void dispatch(d dVar, Runnable runnable) {
        C0282b bVar = C0282b.b;
        bVar.a.b(runnable, C0289i.h, false);
    }

    public final void dispatchYield(d dVar, Runnable runnable) {
        C0282b bVar = C0282b.b;
        bVar.a.b(runnable, C0289i.h, true);
    }

    public final C0135x limitedParallelism(int i) {
        f.b(i);
        if (i >= C0289i.d) {
            return this;
        }
        return super.limitedParallelism(i);
    }
}
