package ha;

import Sb.d;
import fa.C0250A;
import java.util.concurrent.TimeUnit;

/* renamed from: ha.i  reason: case insensitive filesystem */
public final class C0289i {
    public static final String a;
    public static final long b = d.d(100000, 1, Long.MAX_VALUE, "kotlinx.coroutines.scheduler.resolution.ns");
    public static final int c;
    public static final int d = d.e(2097150, 4, "kotlinx.coroutines.scheduler.max.pool.size");
    public static final long e = TimeUnit.SECONDS.toNanos(d.d(60, 1, Long.MAX_VALUE, "kotlinx.coroutines.scheduler.keep.alive.sec"));
    public static final C0284d f = C0284d.a;
    public static final C0287g g = new C0287g(0);
    public static final C0287g h = new C0287g(1);

    static {
        String str;
        int i = C0250A.a;
        try {
            str = System.getProperty("kotlinx.coroutines.scheduler.default.name");
        } catch (SecurityException unused) {
            str = null;
        }
        if (str == null) {
            str = "DefaultDispatcher";
        }
        a = str;
        int i2 = C0250A.a;
        if (i2 < 2) {
            i2 = 2;
        }
        c = d.e(i2, 8, "kotlinx.coroutines.scheduler.core.pool.size");
    }
}
