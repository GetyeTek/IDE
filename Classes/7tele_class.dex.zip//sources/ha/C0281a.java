package ha;

import Sb.d;
import ca.C0135x;
import ca.Z;
import fa.C0250A;
import java.util.concurrent.Executor;
import kotlin.coroutines.EmptyCoroutineContext;

/* renamed from: ha.a  reason: case insensitive filesystem */
public final class C0281a extends Z implements Executor {
    public static final C0281a a = new Z();
    public static final C0135x b;

    /* JADX WARNING: type inference failed for: r0v0, types: [ca.Z, ha.a] */
    static {
        j jVar = j.a;
        int i = C0250A.a;
        if (64 >= i) {
            i = 64;
        }
        b = jVar.limitedParallelism(d.e(i, 12, "kotlinx.coroutines.io.parallelism"));
    }

    public final void close() {
        throw new IllegalStateException("Cannot be invoked on Dispatchers.IO");
    }

    public final void dispatch(kotlin.coroutines.d dVar, Runnable runnable) {
        b.dispatch(dVar, runnable);
    }

    public final void dispatchYield(kotlin.coroutines.d dVar, Runnable runnable) {
        b.dispatchYield(dVar, runnable);
    }

    public final void execute(Runnable runnable) {
        dispatch(EmptyCoroutineContext.INSTANCE, runnable);
    }

    public final C0135x limitedParallelism(int i) {
        return j.a.limitedParallelism(i);
    }

    public final String toString() {
        return "Dispatchers.IO";
    }

    public final Executor f() {
        return this;
    }
}
