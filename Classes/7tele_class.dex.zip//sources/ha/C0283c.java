package ha;

import fa.o;

/* renamed from: ha.c  reason: case insensitive filesystem */
public final class C0283c extends o<C0286f> {
}
