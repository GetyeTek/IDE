package ha;

import D3.f;
import ca.C0135x;
import ca.Z;
import kotlinx.coroutines.scheduling.CoroutineScheduler;

/* renamed from: ha.b  reason: case insensitive filesystem */
public final class C0282b extends C0285e {
    public static final C0282b b;

    /* JADX WARNING: type inference failed for: r0v0, types: [ha.e, ca.Z, ha.b] */
    static {
        int i = C0289i.c;
        int i2 = C0289i.d;
        long j = C0289i.e;
        String str = C0289i.a;
        ? z = new Z();
        z.a = new CoroutineScheduler(i, j, i2, str);
        b = z;
    }

    public final void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    public final C0135x limitedParallelism(int i) {
        f.b(i);
        if (i >= C0289i.c) {
            return this;
        }
        return super.limitedParallelism(i);
    }

    public final String toString() {
        return "Dispatchers.Default";
    }
}
