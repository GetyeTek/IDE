package ha;

import ca.C0105E;

/* renamed from: ha.h  reason: case insensitive filesystem */
public final class C0288h extends C0286f {
    public final Runnable c;

    public C0288h(Runnable runnable, long j, C0287g gVar) {
        super(j, gVar);
        this.c = runnable;
    }

    public final void run() {
        try {
            this.c.run();
        } finally {
            this.b.getClass();
        }
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Task[");
        Runnable runnable = this.c;
        sb2.append(runnable.getClass().getSimpleName());
        sb2.append('@');
        sb2.append(C0105E.c(runnable));
        sb2.append(", ");
        sb2.append(this.a);
        sb2.append(", ");
        sb2.append(this.b);
        sb2.append(']');
        return sb2.toString();
    }
}
