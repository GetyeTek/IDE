package ha;

import ca.Z;
import java.util.concurrent.Executor;
import kotlin.coroutines.d;
import kotlinx.coroutines.scheduling.CoroutineScheduler;

/* renamed from: ha.e  reason: case insensitive filesystem */
public class C0285e extends Z {
    public CoroutineScheduler a;

    public final void dispatch(d dVar, Runnable runnable) {
        CoroutineScheduler.c(this.a, runnable, 6);
    }

    public final void dispatchYield(d dVar, Runnable runnable) {
        CoroutineScheduler.c(this.a, runnable, 2);
    }

    public final Executor f() {
        return this.a;
    }
}
