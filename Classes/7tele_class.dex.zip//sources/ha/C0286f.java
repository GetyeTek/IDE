package ha;

/* renamed from: ha.f  reason: case insensitive filesystem */
public abstract class C0286f implements Runnable {
    public long a;
    public C0287g b;

    public C0286f(long j, C0287g gVar) {
        this.a = j;
        this.b = gVar;
    }

    public C0286f() {
        this(0, C0289i.g);
    }
}
