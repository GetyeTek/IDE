package Nb;

import La.C0073a;

public final class b extends C0073a {
}
