package retrofit2;

import fc.A;
import java.util.Objects;
import javax.annotation.Nullable;
import okhttp3.Response;

public class HttpException extends RuntimeException {
    private final int code;
    private final String message;
    private final transient A<?> response;

    public HttpException(A<?> a) {
        super(getMessage(a));
        this.code = a.a.code();
        this.message = a.a.message();
        this.response = a;
    }

    private static String getMessage(A<?> a) {
        Objects.requireNonNull(a, "response == null");
        StringBuilder sb2 = new StringBuilder("HTTP ");
        Response response2 = a.a;
        sb2.append(response2.code());
        sb2.append(" ");
        sb2.append(response2.message());
        return sb2.toString();
    }

    public int code() {
        return this.code;
    }

    public String message() {
        return this.message;
    }

    @Nullable
    public A<?> response() {
        return this.response;
    }
}
