package retrofit2.adapter.rxjava3;

import fc.A;

@Deprecated
public final class HttpException extends retrofit2.HttpException {
    public HttpException(A<?> a) {
        super(a);
    }
}
