package M8;

public interface b {
    void a();
}
