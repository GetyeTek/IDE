package M8;

import P8.d;

public interface a {
    void __process(d dVar);
}
