package cc;

import D5.a;
import R9.b;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.helpers.NOPLogger;
import org.slf4j.helpers.d;
import org.slf4j.helpers.e;

public final class c {
    public static volatile int a;
    public static final e b = new e();
    public static final a c = new Object();
    public static final String[] d = {"1.6", "1.7"};
    public static final String e = "org/slf4j/impl/StaticLoggerBinder.class";

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, D5.a] */
    static {
        String str;
        try {
            str = System.getProperty("slf4j.detectLoggerNameMismatch");
        } catch (SecurityException unused) {
            str = null;
        }
        if (str != null) {
            str.equalsIgnoreCase("true");
        }
    }

    public static LinkedHashSet a() {
        Enumeration<URL> enumeration;
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        try {
            ClassLoader classLoader = c.class.getClassLoader();
            String str = e;
            if (classLoader == null) {
                enumeration = ClassLoader.getSystemResources(str);
            } else {
                enumeration = classLoader.getResources(str);
            }
            while (enumeration.hasMoreElements()) {
                linkedHashSet.add(enumeration.nextElement());
            }
        } catch (IOException e2) {
            b.d("Error getting resources from path", e2);
        }
        return linkedHashSet;
    }

    public static void b() {
        e eVar = b;
        synchronized (eVar) {
            try {
                eVar.a = true;
                Iterator it = new ArrayList(eVar.b.values()).iterator();
                while (it.hasNext()) {
                    d dVar = (d) it.next();
                    dVar.b = c(dVar.a);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static b c(String str) {
        a aVar;
        if (a == 0) {
            synchronized (c.class) {
                try {
                    if (a == 0) {
                        a = 1;
                        e();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        int i = a;
        if (i == 1) {
            aVar = b;
        } else if (i == 2) {
            throw new IllegalStateException("org.slf4j.LoggerFactory in failed state. Original exception was thrown EARLIER. See also http://www.slf4j.org/codes.html#unsuccessfulInit");
        } else if (i == 3) {
            aVar = ec.c.b.a;
        } else if (i == 4) {
            aVar = c;
        } else {
            throw new IllegalStateException("Unreachable code");
        }
        return aVar.b(str);
    }

    public static boolean d() {
        String str;
        try {
            str = System.getProperty("java.vendor.url");
        } catch (SecurityException unused) {
            str = null;
        }
        if (str == null) {
            return false;
        }
        return str.toLowerCase().contains("android");
    }

    public static final void e() {
        LinkedHashSet linkedHashSet;
        try {
            if (!d()) {
                linkedHashSet = a();
                h(linkedHashSet);
            } else {
                linkedHashSet = null;
            }
            ec.c cVar = ec.c.b;
            a = 3;
            g(linkedHashSet);
            b();
            f();
            e eVar = b;
            eVar.b.clear();
            eVar.c.clear();
        } catch (NoClassDefFoundError e2) {
            String message = e2.getMessage();
            if (message == null || (!message.contains("org/slf4j/impl/StaticLoggerBinder") && !message.contains("org.slf4j.impl.StaticLoggerBinder"))) {
                a = 2;
                b.d("Failed to instantiate SLF4J LoggerFactory", e2);
                throw e2;
            }
            a = 4;
            b.c("Failed to load class \"org.slf4j.impl.StaticLoggerBinder\".");
            b.c("Defaulting to no-operation (NOP) logger implementation");
            b.c("See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.");
        } catch (NoSuchMethodError e3) {
            String message2 = e3.getMessage();
            if (message2 != null && message2.contains("org.slf4j.impl.StaticLoggerBinder.getSingleton()")) {
                a = 2;
                b.c("slf4j-api 1.6.x (or later) is incompatible with this binding.");
                b.c("Your binding is version 1.5.5 or earlier.");
                b.c("Upgrade your binding to version 1.6.x.");
            }
            throw e3;
        } catch (Exception e4) {
            a = 2;
            b.d("Failed to instantiate SLF4J LoggerFactory", e4);
            throw new IllegalStateException("Unexpected initialization failure", e4);
        }
        if (a == 3) {
            String[] strArr = d;
            try {
                String str = ec.c.c;
                boolean z = false;
                for (String startsWith : strArr) {
                    if (str.startsWith(startsWith)) {
                        z = true;
                    }
                }
                if (!z) {
                    b.c("The requested version " + str + " by your slf4j binding is not compatible with " + Arrays.asList(strArr).toString());
                    b.c("See http://www.slf4j.org/codes.html#version_mismatch for further details.");
                }
            } catch (NoSuchFieldError unused) {
            } catch (Throwable th) {
                b.d("Unexpected problem occured during version sanity check", th);
            }
        }
    }

    public static void f() {
        LinkedBlockingQueue<dc.c> linkedBlockingQueue = b.c;
        int size = linkedBlockingQueue.size();
        ArrayList arrayList = new ArrayList(128);
        int i = 0;
        while (linkedBlockingQueue.drainTo(arrayList, 128) != 0) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                dc.c cVar = (dc.c) it.next();
                if (cVar != null) {
                    d dVar = cVar.a;
                    String str = dVar.a;
                    if (dVar.b == null) {
                        throw new IllegalStateException("Delegate logger cannot be null at this state.");
                    } else if (!(dVar.b instanceof NOPLogger)) {
                        if (!dVar.b()) {
                            b.c(str);
                        } else if (dVar.b()) {
                            try {
                                dVar.d.invoke(dVar.b, new Object[]{cVar});
                            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException unused) {
                            }
                        }
                    }
                }
                int i2 = i + 1;
                if (i == 0) {
                    if (cVar.a.b()) {
                        b.c("A number (" + size + ") of logging calls during the initialization phase have been intercepted and are");
                        b.c("now being replayed. These are subject to the filtering rules of the underlying logging system.");
                        b.c("See also http://www.slf4j.org/codes.html#replay");
                    } else if (!(cVar.a.b instanceof NOPLogger)) {
                        b.c("The following set of substitute loggers may have been accessed");
                        b.c("during the initialization phase. Logging calls during this");
                        b.c("phase were not honored. However, subsequent logging calls to these");
                        b.c("loggers will work as normally expected.");
                        b.c("See also http://www.slf4j.org/codes.html#substituteLogger");
                    }
                }
                i = i2;
            }
            arrayList.clear();
        }
    }

    public static void g(LinkedHashSet linkedHashSet) {
        if (linkedHashSet != null && linkedHashSet.size() > 1) {
            StringBuilder sb2 = new StringBuilder("Actual binding is of type [");
            ec.c.b.getClass();
            sb2.append(ec.c.d);
            sb2.append("]");
            b.c(sb2.toString());
        }
    }

    public static void h(LinkedHashSet linkedHashSet) {
        if (linkedHashSet.size() > 1) {
            b.c("Class path contains multiple SLF4J bindings.");
            Iterator it = linkedHashSet.iterator();
            while (it.hasNext()) {
                b.c("Found binding in [" + ((URL) it.next()) + "]");
            }
            b.c("See http://www.slf4j.org/codes.html#multiple_bindings for an explanation.");
        }
    }
}
