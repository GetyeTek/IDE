package cc;

public interface a {
    b b(String str);
}
