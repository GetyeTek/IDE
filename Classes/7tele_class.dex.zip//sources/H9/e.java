package H9;

import kotlin.LazyThreadSafetyMode;
import kotlin.NoWhenBranchMatchedException;
import kotlin.UnsafeLazyImpl;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.h;

public class e {

    public /* synthetic */ class a {
        public static final /* synthetic */ int[] a;

        /* JADX WARNING: Can't wrap try/catch for region: R(9:0|1|2|3|4|5|6|7|9) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0010 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0019 */
        static {
            /*
                kotlin.LazyThreadSafetyMode[] r0 = kotlin.LazyThreadSafetyMode.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                kotlin.LazyThreadSafetyMode r1 = kotlin.LazyThreadSafetyMode.SYNCHRONIZED     // Catch:{ NoSuchFieldError -> 0x0010 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0010 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0010 }
            L_0x0010:
                kotlin.LazyThreadSafetyMode r1 = kotlin.LazyThreadSafetyMode.PUBLICATION     // Catch:{ NoSuchFieldError -> 0x0019 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0019 }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0019 }
            L_0x0019:
                kotlin.LazyThreadSafetyMode r1 = kotlin.LazyThreadSafetyMode.NONE     // Catch:{ NoSuchFieldError -> 0x0022 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0022 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0022 }
            L_0x0022:
                a = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: H9.e.a.<clinit>():void");
        }
    }

    /* JADX WARNING: type inference failed for: r1v4, types: [H9.d<T>, H9.f, java.lang.Object] */
    public static <T> d<T> a(LazyThreadSafetyMode lazyThreadSafetyMode, T9.a<? extends T> aVar) {
        h.f(lazyThreadSafetyMode, "mode");
        h.f(aVar, "initializer");
        int i = a.a[lazyThreadSafetyMode.ordinal()];
        if (i == 1) {
            return new g(aVar);
        }
        if (i == 2) {
            ? obj = new Object();
            obj.a = (Lambda) aVar;
            obj.b = i.a;
            return obj;
        } else if (i == 3) {
            return new UnsafeLazyImpl(aVar);
        } else {
            throw new NoWhenBranchMatchedException();
        }
    }

    public static g b(T9.a aVar) {
        h.f(aVar, "initializer");
        return new g(aVar);
    }
}
