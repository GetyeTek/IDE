package H9;

import O9.b;
import android.text.TextUtils;
import kotlin.jvm.internal.h;

public final class a {
    public static void a(Throwable th, Throwable th2) {
        h.f(th, "<this>");
        h.f(th2, "exception");
        if (th != th2) {
            b.a.a(th, th2);
        }
    }

    public static String b(String str) {
        if (TextUtils.isEmpty("https://www.superapp.ethiomobilemoney.et:38443") || TextUtils.isEmpty(str)) {
            return str;
        }
        if (str.startsWith("/")) {
            return "https://www.superapp.ethiomobilemoney.et:38443".concat(str);
        }
        if (!str.startsWith("h5://")) {
            return str;
        }
        return "https://www.superapp.ethiomobilemoney.et:38443" + str.replace("h5:/", "");
    }
}
