package H9;

public final class i {
    public static final i a = new Object();
}
