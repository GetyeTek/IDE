package H9;

public interface b<R> {
}
