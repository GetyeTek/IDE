package H9;

public interface d<T> {
    T getValue();
}
