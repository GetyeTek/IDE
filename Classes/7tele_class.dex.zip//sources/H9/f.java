package H9;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.InitializedLazyImpl;
import kotlin.jvm.internal.Lambda;

public final class f<T> implements d<T>, Serializable {
    public static final AtomicReferenceFieldUpdater<f<?>, Object> c = AtomicReferenceFieldUpdater.newUpdater(f.class, Object.class, "b");
    public volatile Lambda a;
    public volatile Object b;

    public f() {
        throw null;
    }

    private final Object writeReplace() {
        return new InitializedLazyImpl(getValue());
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [kotlin.jvm.internal.Lambda, T9.a] */
    public final T getValue() {
        T t = this.b;
        T t2 = i.a;
        if (t != t2) {
            return t;
        }
        ? r0 = this.a;
        if (r0 != 0) {
            T invoke = r0.invoke();
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = c;
            while (!atomicReferenceFieldUpdater.compareAndSet(this, t2, invoke)) {
                if (atomicReferenceFieldUpdater.get(this) != t2) {
                }
            }
            this.a = null;
            return invoke;
        }
        return this.b;
    }

    public final String toString() {
        if (this.b != i.a) {
            return String.valueOf(getValue());
        }
        return "Lazy value not initialized yet.";
    }
}
