package H9;

import T9.a;
import java.io.Serializable;
import kotlin.InitializedLazyImpl;
import kotlin.jvm.internal.h;

public final class g<T> implements d<T>, Serializable {
    public a<? extends T> a;
    public volatile Object b = i.a;
    public final Object c = this;

    public g(a aVar) {
        h.f(aVar, "initializer");
        this.a = aVar;
    }

    private final Object writeReplace() {
        return new InitializedLazyImpl(getValue());
    }

    public final T getValue() {
        T t;
        T t2 = this.b;
        T t3 = i.a;
        if (t2 != t3) {
            return t2;
        }
        synchronized (this.c) {
            t = this.b;
            if (t == t3) {
                a aVar = this.a;
                h.c(aVar);
                t = aVar.invoke();
                this.b = t;
                this.a = null;
            }
        }
        return t;
    }

    public final String toString() {
        if (this.b != i.a) {
            return String.valueOf(getValue());
        }
        return "Lazy value not initialized yet.";
    }
}
