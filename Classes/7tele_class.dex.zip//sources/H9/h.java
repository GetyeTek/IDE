package H9;

import kotlin.text.b;

public final class h implements Comparable<h> {
    public final long a;

    public /* synthetic */ h(long j) {
        this.a = j;
    }

    public final int compareTo(Object obj) {
        int i = ((this.a ^ Long.MIN_VALUE) > (((h) obj).a ^ Long.MIN_VALUE) ? 1 : ((this.a ^ Long.MIN_VALUE) == (((h) obj).a ^ Long.MIN_VALUE) ? 0 : -1));
        if (i < 0) {
            return -1;
        }
        if (i == 0) {
            return 0;
        }
        return 1;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof h)) {
            return false;
        }
        if (this.a != ((h) obj).a) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        long j = this.a;
        return (int) (j ^ (j >>> 32));
    }

    public final String toString() {
        long j = this.a;
        if (j >= 0) {
            b.a(10);
            String l = Long.toString(j, 10);
            kotlin.jvm.internal.h.e(l, "toString(...)");
            return l;
        }
        long j2 = (long) 10;
        long j3 = ((j >>> 1) / j2) << 1;
        long j4 = j - (j3 * j2);
        if (j4 >= j2) {
            j4 -= j2;
            j3++;
        }
        b.a(10);
        String l2 = Long.toString(j3, 10);
        kotlin.jvm.internal.h.e(l2, "toString(...)");
        b.a(10);
        String l3 = Long.toString(j4, 10);
        kotlin.jvm.internal.h.e(l3, "toString(...)");
        return l2.concat(l3);
    }
}
