package H9;

import kotlin.jvm.internal.h;

public final class c implements Comparable<c> {
    public static final c b = new c();
    public final int a = 131093;

    public final int compareTo(Object obj) {
        c cVar = (c) obj;
        h.f(cVar, "other");
        return this.a - cVar.a;
    }

    public final boolean equals(Object obj) {
        c cVar;
        if (this == obj) {
            return true;
        }
        if (obj instanceof c) {
            cVar = (c) obj;
        } else {
            cVar = null;
        }
        if (cVar != null && this.a == cVar.a) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.a;
    }

    public final String toString() {
        return "2.0.21";
    }
}
