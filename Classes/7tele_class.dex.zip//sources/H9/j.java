package H9;

public final class j {
    public static final j a = new j();

    public final String toString() {
        return "kotlin.Unit";
    }
}
