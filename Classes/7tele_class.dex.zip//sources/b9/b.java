package b9;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import androidx.annotation.NonNull;

public final class b extends C0093a implements Animatable, ValueAnimator.AnimatorUpdateListener {
    public int b = 0;
    public int c = 0;
    public int d = 0;
    public final ValueAnimator e;
    public final Path f = new Path();

    public b() {
        ValueAnimator ofInt = ValueAnimator.ofInt(new int[]{30, 3600});
        this.e = ofInt;
        ofInt.setDuration(10000);
        ofInt.setInterpolator((TimeInterpolator) null);
        ofInt.setRepeatCount(-1);
        ofInt.setRepeatMode(1);
    }

    public final void draw(@NonNull Canvas canvas) {
        Canvas canvas2 = canvas;
        Rect bounds = getBounds();
        int width = bounds.width();
        int height = bounds.height();
        float f2 = (float) width;
        float max = Math.max(1.0f, f2 / 22.0f);
        int i = this.b;
        Path path = this.f;
        if (!(i == width && this.c == height)) {
            path.reset();
            float f3 = f2 - max;
            float f4 = ((float) height) / 2.0f;
            Path.Direction direction = Path.Direction.CW;
            path.addCircle(f3, f4, max, direction);
            float f5 = f2 - (5.0f * max);
            path.addRect(f5, f4 - max, f3, f4 + max, direction);
            path.addCircle(f5, f4, max, direction);
            this.b = width;
            this.c = height;
        }
        canvas.save();
        float f6 = f2 / 2.0f;
        float f7 = ((float) height) / 2.0f;
        canvas2.rotate((float) this.d, f6, f7);
        for (int i2 = 0; i2 < 12; i2++) {
            Paint paint = this.a;
            paint.setAlpha((i2 + 5) * 17);
            canvas2.rotate(30.0f, f6, f7);
            canvas2.drawPath(path, paint);
        }
        canvas.restore();
    }

    public final boolean isRunning() {
        return this.e.isRunning();
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.d = (((Integer) valueAnimator.getAnimatedValue()).intValue() / 30) * 30;
        invalidateSelf();
    }

    public final void start() {
        ValueAnimator valueAnimator = this.e;
        if (!valueAnimator.isRunning()) {
            valueAnimator.addUpdateListener(this);
            valueAnimator.start();
        }
    }

    public final void stop() {
        ValueAnimator valueAnimator = this.e;
        if (valueAnimator.isRunning()) {
            valueAnimator.removeAllListeners();
            valueAnimator.removeAllUpdateListeners();
            valueAnimator.cancel();
        }
    }
}
