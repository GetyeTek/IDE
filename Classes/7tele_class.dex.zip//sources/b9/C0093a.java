package b9;

import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;

/* renamed from: b9.a  reason: case insensitive filesystem */
public abstract class C0093a extends Drawable {
    public final Paint a;

    public C0093a() {
        Paint paint = new Paint();
        this.a = paint;
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        paint.setColor(-5592406);
    }

    public final void a(int i) {
        this.a.setColor(i);
    }

    public final int getOpacity() {
        return -3;
    }

    public final void setAlpha(int i) {
        this.a.setAlpha(i);
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        this.a.setColorFilter(colorFilter);
    }
}
