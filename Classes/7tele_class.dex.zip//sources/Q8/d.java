package Q8;

import com.onemdos.base.component.aace.packer.PackException;

public interface d {
    void packData(c cVar);

    int size();

    void unpackData(c cVar) throws PackException;
}
