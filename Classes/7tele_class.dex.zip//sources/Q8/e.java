package Q8;

import com.onemdos.base.component.aace.packer.PackException;

public final class e extends c {
    public int e = 0;
    public short f = 0;
    public byte g = 0;
    public byte h = 0;
    public byte i = 0;

    public final int y(int i2, byte[] bArr) {
        byte b;
        this.e = i2;
        byte b2 = 0;
        do {
            byte b3 = (byte) (i2 & 127);
            i2 >>= 7;
            if (i2 > 0) {
                b3 = (byte) (b3 | 128);
            }
            b2 = (byte) (b2 ^ b3);
        } while (i2 > 0);
        try {
            o(bArr);
            this.f = (short) ((int) w());
            this.g = t();
            this.h = t();
            this.i = t();
            int i3 = this.b;
            if (bArr.length < i3) {
                b = 0;
            } else {
                b = 0;
                for (int i4 = 0; i4 < i3; i4++) {
                    b = (byte) (b ^ bArr[i4]);
                }
            }
            if (((byte) (b2 ^ b)) != 0) {
                return 6;
            }
            return 0;
        } catch (PackException e2) {
            return e2.getErrcode();
        } catch (Exception unused) {
            return 7;
        }
    }
}
