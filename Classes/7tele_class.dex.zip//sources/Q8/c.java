package Q8;

import com.onemdos.base.component.aace.packer.PackException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

public class c {
    public byte[] a;
    public int b = 0;
    public byte[] c;
    public int d = 0;

    public static byte[] a(byte[] bArr) throws Exception {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream);
        int length = bArr.length;
        deflaterOutputStream.write(bArr, 0, length);
        deflaterOutputStream.finish();
        deflaterOutputStream.flush();
        deflaterOutputStream.close();
        int size = byteArrayOutputStream.size();
        byte[] bArr2 = new byte[(c((long) length) + size)];
        System.arraycopy(bArr, 0, bArr2, 0, 0);
        c cVar = new c();
        cVar.p(bArr2);
        cVar.d = 0;
        cVar.i(length);
        System.arraycopy(byteArrayOutputStream.toByteArray(), 0, bArr2, cVar.d, size);
        byteArrayOutputStream.close();
        return bArr2;
    }

    public static byte[] b(byte[] bArr) throws Exception {
        c cVar = new c();
        cVar.o(bArr);
        cVar.b = 0;
        try {
            int w = (int) cVar.w();
            int i = cVar.b;
            InflaterInputStream inflaterInputStream = new InflaterInputStream(new ByteArrayInputStream(bArr, i, bArr.length - i));
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr2 = new byte[(w + 100)];
            while (true) {
                int read = inflaterInputStream.read(bArr2);
                if (read > 0) {
                    byteArrayOutputStream.write(bArr2, 0, read);
                } else {
                    inflaterInputStream.close();
                    byte[] byteArray = byteArrayOutputStream.toByteArray();
                    byte[] bArr3 = new byte[byteArray.length];
                    System.arraycopy(bArr, 0, bArr3, 0, 0);
                    System.arraycopy(byteArray, 0, bArr3, 0, byteArray.length);
                    byteArrayOutputStream.close();
                    return bArr3;
                }
            }
        } catch (Exception unused) {
            return "".getBytes();
        }
    }

    public static int c(long j) {
        int i = 0;
        do {
            j >>>= 7;
            i++;
        } while (j > 0);
        return i;
    }

    public static int d(String str) {
        int i = 0;
        if (str != null) {
            try {
                i = str.getBytes("utf-8").length;
            } catch (Exception unused) {
            }
        }
        return c((long) i) + i;
    }

    public static int e(byte[] bArr) {
        if (bArr == null) {
            return 1;
        }
        return c((long) bArr.length) + bArr.length;
    }

    public static boolean f(byte b2, byte b3) {
        if (b2 == b3) {
            return true;
        }
        if (b2 != 2) {
            if (b2 != 3) {
                if (b2 != 7) {
                    if (b2 == 8 && b3 == 3) {
                        return true;
                    }
                    return false;
                } else if (b3 == 2) {
                    return true;
                } else {
                    return false;
                }
            } else if (b3 == 8) {
                return true;
            } else {
                return false;
            }
        } else if (b3 == 7) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean q(byte[] bArr, d dVar) {
        c cVar = new c();
        cVar.o(bArr);
        try {
            dVar.unpackData(cVar);
            return true;
        } catch (PackException unused) {
            return false;
        }
    }

    public static byte[] r(d dVar) {
        byte[] bArr = new byte[dVar.size()];
        c cVar = new c();
        cVar.p(bArr);
        dVar.packData(cVar);
        return bArr;
    }

    public final void g(byte b2) {
        byte[] bArr = this.c;
        int i = this.d;
        this.d = i + 1;
        bArr[i] = b2;
    }

    public final void h(byte[] bArr) {
        if (bArr == null) {
            i(0);
            return;
        }
        int length = bArr.length;
        i(length);
        System.arraycopy(bArr, 0, this.c, this.d, length);
        this.d += length;
    }

    public final void i(int i) {
        j(((long) i) & 4294967295L);
    }

    public final void j(long j) {
        int i;
        do {
            byte b2 = (byte) ((int) (127 & j));
            j >>>= 7;
            i = (j > 0 ? 1 : (j == 0 ? 0 : -1));
            if (i > 0) {
                b2 = (byte) (b2 | 128);
            }
            byte[] bArr = this.c;
            int i2 = this.d;
            this.d = i2 + 1;
            bArr[i2] = b2;
        } while (i > 0);
    }

    public final void k(short s) {
        j((long) (s & 65535));
    }

    public final void l(String str) {
        if (str == null) {
            try {
                i(0);
            } catch (Exception unused) {
            }
        } else {
            h(str.getBytes("utf-8"));
        }
    }

    public final void m() throws PackException {
        n(v());
    }

    public final void n(b bVar) throws PackException {
        int i = 1;
        switch (bVar.a) {
            case 1:
                break;
            case 2:
            case 7:
                w();
                return;
            case 3:
            case 8:
                i = (int) w();
                break;
            case 4:
                int w = (int) w();
                b bVar2 = bVar.b.get(0);
                for (int i2 = 0; i2 < w; i2++) {
                    n(bVar2);
                }
                break;
            case 5:
                int w2 = (int) w();
                b bVar3 = bVar.b.get(0);
                b bVar4 = bVar.b.get(1);
                for (int i3 = 0; i3 < w2; i3++) {
                    n(bVar3);
                    n(bVar4);
                }
                break;
            case 6:
                short t = (short) (t() & 255);
                for (int i4 = 0; i4 < t; i4++) {
                    m();
                }
                break;
            default:
                throw new PackException(6, "PACK_INVALID");
        }
        i = 0;
        int i5 = this.b + i;
        this.b = i5;
        if (this.a.length < i5) {
            throw new PackException(3, "PACK_LENGTH_ERROR");
        }
    }

    public final void o(byte[] bArr) {
        this.a = bArr;
        this.b = 0;
    }

    public final void p(byte[] bArr) {
        this.c = bArr;
        this.d = 0;
    }

    public final boolean s() throws PackException {
        if (t() != 0) {
            return true;
        }
        return false;
    }

    public final byte t() throws PackException {
        byte[] bArr = this.a;
        int length = bArr.length;
        int i = this.b;
        if (length >= i + 1) {
            this.b = i + 1;
            return bArr[i];
        }
        throw new PackException(3, "PACK_LENGTH_ERROR");
    }

    public final byte[] u() throws PackException {
        int w = (int) w();
        if (w == 0) {
            return null;
        }
        byte[] bArr = this.a;
        int length = bArr.length;
        int i = this.b;
        if (length >= i + w) {
            byte[] bArr2 = new byte[w];
            System.arraycopy(bArr, i, bArr2, 0, w);
            this.b += w;
            return bArr2;
        }
        throw new PackException(3, "PACK_LENGTH_ERROR");
    }

    public final b v() throws PackException {
        b bVar = new b();
        byte t = t();
        bVar.a = t;
        if (t == 4) {
            ArrayList<b> arrayList = new ArrayList<>(1);
            bVar.b = arrayList;
            arrayList.add(v());
        } else if (t == 5) {
            ArrayList<b> arrayList2 = new ArrayList<>(2);
            bVar.b = arrayList2;
            arrayList2.add(v());
            bVar.b.add(v());
        }
        return bVar;
    }

    public final long w() throws PackException {
        int i = 0;
        long j = 0;
        while (true) {
            int i2 = this.b;
            byte[] bArr = this.a;
            if (i2 < bArr.length) {
                this.b = i2 + 1;
                byte b2 = bArr[i2];
                if ((b2 & 128) == 0) {
                    return j + (((long) b2) << i);
                }
                j += ((long) ((byte) (b2 & -129))) << i;
                i += 7;
            } else {
                throw new PackException(3, "PACK_LENGTH_ERROR");
            }
        }
    }

    public final String x() throws PackException {
        int w = (int) w();
        String str = null;
        if (w == 0) {
            return null;
        }
        byte[] bArr = this.a;
        int length = bArr.length;
        int i = this.b;
        if (length >= i + w) {
            try {
                str = new String(bArr, i, w, "utf-8");
            } catch (Exception unused) {
            }
            this.b += w;
            return str;
        }
        throw new PackException(3, "PACK_LENGTH_ERROR");
    }
}
