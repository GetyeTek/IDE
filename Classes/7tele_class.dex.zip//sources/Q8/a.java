package Q8;

import com.onemdos.base.component.aace.packer.PackException;
import java.util.Map;
import java.util.TreeMap;

public final class a implements d {
    public String a;
    public String b = "";
    public byte c = 2;
    public long d = 0;
    public TreeMap<String, String> e;

    public final void packData(c cVar) {
        byte b2;
        if (this.e == null) {
            b2 = (byte) 4;
            if (this.d == 0) {
                b2 = (byte) (b2 - 1);
                if (this.c == 2) {
                    b2 = (byte) (b2 - 1);
                    if (this.b == "") {
                        b2 = (byte) (b2 - 1);
                    }
                }
            }
        } else {
            b2 = 5;
        }
        cVar.g(b2);
        cVar.g((byte) 3);
        cVar.l(this.a);
        if (b2 != 1) {
            cVar.g((byte) 3);
            cVar.l(this.b);
            if (b2 != 2) {
                cVar.g((byte) 1);
                cVar.g(this.c);
                if (b2 != 3) {
                    cVar.g((byte) 2);
                    cVar.j(this.d);
                    if (b2 != 4) {
                        cVar.g((byte) 5);
                        cVar.g((byte) 3);
                        cVar.g((byte) 3);
                        TreeMap<String, String> treeMap = this.e;
                        if (treeMap == null) {
                            cVar.g((byte) 0);
                            return;
                        }
                        cVar.i(treeMap.size());
                        for (Map.Entry next : this.e.entrySet()) {
                            cVar.l((String) next.getKey());
                            cVar.l((String) next.getValue());
                        }
                    }
                }
            }
        }
    }

    public final int size() {
        byte b2;
        if (this.e == null) {
            b2 = (byte) 4;
            if (this.d == 0) {
                b2 = (byte) (b2 - 1);
                if (this.c == 2) {
                    b2 = (byte) (b2 - 1);
                    if (this.b == null) {
                        b2 = (byte) (b2 - 1);
                    }
                }
            }
        } else {
            b2 = 5;
        }
        int d2 = c.d(this.a);
        int i = d2 + 2;
        if (b2 == 1) {
            return i;
        }
        int d3 = d2 + 3 + c.d(this.b);
        if (b2 == 2) {
            return d3;
        }
        int i2 = d3 + 2;
        if (b2 == 3) {
            return i2;
        }
        int c2 = c.c(this.d) + d3 + 3;
        if (b2 == 4) {
            return c2;
        }
        int i3 = c2 + 3;
        TreeMap<String, String> treeMap = this.e;
        if (treeMap == null) {
            return c2 + 4;
        }
        int c3 = c.c((long) treeMap.size()) + i3;
        int i4 = c3;
        for (Map.Entry next : this.e.entrySet()) {
            i4 = c.d((String) next.getValue()) + c.d((String) next.getKey()) + i4;
        }
        return i4;
    }

    public final void unpackData(c cVar) throws PackException {
        byte t = cVar.t();
        if (t >= 1) {
            if (c.f(cVar.v().a, (byte) 3)) {
                this.a = cVar.x();
                if (t >= 2) {
                    if (c.f(cVar.v().a, (byte) 3)) {
                        this.b = cVar.x();
                        if (t >= 3) {
                            if (c.f(cVar.v().a, (byte) 1)) {
                                this.c = cVar.t();
                                if (t >= 4) {
                                    if (c.f(cVar.v().a, (byte) 2)) {
                                        this.d = cVar.w();
                                        if (t >= 5) {
                                            if (c.f(cVar.v().a, (byte) 5)) {
                                                int w = (int) cVar.w();
                                                if (w > 10485760 || w < 0) {
                                                    throw new PackException(3, "PACK_LENGTH_ERROR");
                                                }
                                                this.e = new TreeMap<>();
                                                for (int i = 0; i < w; i++) {
                                                    this.e.put(cVar.x(), cVar.x());
                                                }
                                            } else {
                                                throw new PackException(5, "PACK_TYPEMATCH_ERROR");
                                            }
                                        }
                                    } else {
                                        throw new PackException(5, "PACK_TYPEMATCH_ERROR");
                                    }
                                }
                            } else {
                                throw new PackException(5, "PACK_TYPEMATCH_ERROR");
                            }
                        }
                    } else {
                        throw new PackException(5, "PACK_TYPEMATCH_ERROR");
                    }
                }
                for (int i2 = 5; i2 < t; i2++) {
                    cVar.m();
                }
                return;
            }
            throw new PackException(5, "PACK_TYPEMATCH_ERROR");
        }
        throw new PackException(3, "PACK_LENGTH_ERROR");
    }
}
