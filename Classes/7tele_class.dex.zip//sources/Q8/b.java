package Q8;

import java.util.ArrayList;

public final class b {
    public byte a;
    public ArrayList<b> b = null;
}
