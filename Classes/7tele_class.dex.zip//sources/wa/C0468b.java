package wa;

import la.C0390u;
import na.C0410a;

/* renamed from: wa.b  reason: case insensitive filesystem */
public interface C0468b {
    public static final C0390u a;
    public static final C0390u b;
    public static final C0390u c;
    public static final C0390u d;
    public static final C0390u e;
    public static final C0390u f;
    public static final C0390u g;
    public static final C0390u h;
    public static final C0390u i;
    public static final C0390u j;
    public static final C0390u k;
    public static final C0390u l;

    static {
        C0390u uVar = new C0390u("2.16.840.1.101.3.4");
        C0390u uVar2 = new C0390u("2", uVar);
        a = new C0390u("1", uVar2);
        b = new C0390u("2", uVar2);
        c = new C0390u("3", uVar2);
        d = new C0390u("4", uVar2);
        e = new C0390u("5", uVar2);
        f = new C0390u("6", uVar2);
        g = new C0390u("7", uVar2);
        h = new C0390u("8", uVar2);
        i = new C0390u("9", uVar2);
        j = new C0390u("10", uVar2);
        k = new C0390u("11", uVar2);
        l = new C0390u("12", uVar2);
        C0410a.a(uVar2, "13", "14", "15", "16");
        uVar2.p("17");
        uVar2.p("18");
        uVar2.p("19");
        uVar2.p("20");
        C0390u uVar3 = new C0390u("1", uVar);
        uVar3.p("1");
        uVar3.p("2");
        uVar3.p("3");
        C0410a.a(uVar3, "4", "5", "6", "7");
        C0410a.a(uVar3, "8", "9", "21", "22");
        C0410a.a(uVar3, "23", "24", "25", "26");
        C0410a.a(uVar3, "27", "28", "29", "41");
        C0410a.a(uVar3, "42", "43", "44", "45");
        uVar3.p("46");
        uVar3.p("47");
        uVar3.p("48");
        uVar3.p("49");
        C0390u uVar4 = new C0390u("3", uVar);
        C0410a.a(uVar4, "1", "2", "3", "4");
        C0410a.a(uVar4, "5", "6", "7", "8");
        C0410a.a(uVar4, "9", "10", "11", "12");
        C0410a.a(uVar4, "13", "14", "15", "16");
    }
}
