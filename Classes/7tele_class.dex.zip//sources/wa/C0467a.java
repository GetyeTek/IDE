package wa;

import Aa.d;
import java.util.Hashtable;
import la.C0390u;
import org.bouncycastle.util.g;

/* renamed from: wa.a  reason: case insensitive filesystem */
public final class C0467a {
    public static final Hashtable a = new Hashtable();
    public static final Hashtable b = new Hashtable();

    static {
        a("B-571", d.E);
        a("B-409", d.C);
        a("B-283", d.m);
        a("B-233", d.s);
        a("B-163", d.k);
        a("K-571", d.D);
        a("K-409", d.B);
        a("K-283", d.l);
        a("K-233", d.r);
        a("K-163", d.a);
        a("P-521", d.A);
        a("P-384", d.z);
        a("P-256", d.G);
        a("P-224", d.y);
        a("P-192", d.F);
    }

    public static void a(String str, C0390u uVar) {
        a.put(str, uVar);
        b.put(uVar, str);
    }

    public static C0390u b(String str) {
        Hashtable hashtable = a;
        String str2 = g.a;
        char[] charArray = str.toCharArray();
        boolean z = false;
        for (int i = 0; i != charArray.length; i++) {
            char c = charArray[i];
            if ('a' <= c && 'z' >= c) {
                charArray[i] = (char) (c - ' ');
                z = true;
            }
        }
        if (z) {
            str = new String(charArray);
        }
        return (C0390u) hashtable.get(str);
    }
}
